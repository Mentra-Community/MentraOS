(() => {
  var __create = Object.create;
  var __getProtoOf = Object.getPrototypeOf;
  var __defProp = Object.defineProperty;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  function __accessProp(key) {
    return this[key];
  }
  var __toESMCache_node;
  var __toESMCache_esm;
  var __toESM = (mod, isNodeMode, target) => {
    var canCache = mod != null && typeof mod === "object";
    if (canCache) {
      var cache = isNodeMode ? __toESMCache_node ??= new WeakMap : __toESMCache_esm ??= new WeakMap;
      var cached = cache.get(mod);
      if (cached)
        return cached;
    }
    target = mod != null ? __create(__getProtoOf(mod)) : {};
    const to = isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target;
    for (let key of __getOwnPropNames(mod))
      if (!__hasOwnProp.call(to, key))
        __defProp(to, key, {
          get: __accessProp.bind(mod, key),
          enumerable: true
        });
    if (canCache)
      cache.set(mod, to);
    return to;
  };
  var __commonJS = (cb, mod) => () => (mod || cb((mod = { exports: {} }).exports, mod), mod.exports);
  var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
    get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
  }) : x)(function(x) {
    if (typeof require !== "undefined")
      return require.apply(this, arguments);
    throw Error('Dynamic require of "' + x + '" is not supported');
  });

  // ../node_modules/.bun/eventemitter3@5.0.4/node_modules/eventemitter3/index.js
  var require_eventemitter3 = __commonJS((exports, module) => {
    var has = Object.prototype.hasOwnProperty;
    var prefix = "~";
    function Events() {}
    if (Object.create) {
      Events.prototype = Object.create(null);
      if (!new Events().__proto__)
        prefix = false;
    }
    function EE(fn, context, once) {
      this.fn = fn;
      this.context = context;
      this.once = once || false;
    }
    function addListener(emitter, event, fn, context, once) {
      if (typeof fn !== "function") {
        throw new TypeError("The listener must be a function");
      }
      var listener = new EE(fn, context || emitter, once), evt = prefix ? prefix + event : event;
      if (!emitter._events[evt])
        emitter._events[evt] = listener, emitter._eventsCount++;
      else if (!emitter._events[evt].fn)
        emitter._events[evt].push(listener);
      else
        emitter._events[evt] = [emitter._events[evt], listener];
      return emitter;
    }
    function clearEvent(emitter, evt) {
      if (--emitter._eventsCount === 0)
        emitter._events = new Events;
      else
        delete emitter._events[evt];
    }
    function EventEmitter() {
      this._events = new Events;
      this._eventsCount = 0;
    }
    EventEmitter.prototype.eventNames = function eventNames() {
      var names = [], events, name;
      if (this._eventsCount === 0)
        return names;
      for (name in events = this._events) {
        if (has.call(events, name))
          names.push(prefix ? name.slice(1) : name);
      }
      if (Object.getOwnPropertySymbols) {
        return names.concat(Object.getOwnPropertySymbols(events));
      }
      return names;
    };
    EventEmitter.prototype.listeners = function listeners(event) {
      var evt = prefix ? prefix + event : event, handlers = this._events[evt];
      if (!handlers)
        return [];
      if (handlers.fn)
        return [handlers.fn];
      for (var i = 0, l = handlers.length, ee = new Array(l);i < l; i++) {
        ee[i] = handlers[i].fn;
      }
      return ee;
    };
    EventEmitter.prototype.listenerCount = function listenerCount(event) {
      var evt = prefix ? prefix + event : event, listeners = this._events[evt];
      if (!listeners)
        return 0;
      if (listeners.fn)
        return 1;
      return listeners.length;
    };
    EventEmitter.prototype.emit = function emit(event, a1, a2, a3, a4, a5) {
      var evt = prefix ? prefix + event : event;
      if (!this._events[evt])
        return false;
      var listeners = this._events[evt], len = arguments.length, args, i;
      if (listeners.fn) {
        if (listeners.once)
          this.removeListener(event, listeners.fn, undefined, true);
        switch (len) {
          case 1:
            return listeners.fn.call(listeners.context), true;
          case 2:
            return listeners.fn.call(listeners.context, a1), true;
          case 3:
            return listeners.fn.call(listeners.context, a1, a2), true;
          case 4:
            return listeners.fn.call(listeners.context, a1, a2, a3), true;
          case 5:
            return listeners.fn.call(listeners.context, a1, a2, a3, a4), true;
          case 6:
            return listeners.fn.call(listeners.context, a1, a2, a3, a4, a5), true;
        }
        for (i = 1, args = new Array(len - 1);i < len; i++) {
          args[i - 1] = arguments[i];
        }
        listeners.fn.apply(listeners.context, args);
      } else {
        var length = listeners.length, j;
        for (i = 0;i < length; i++) {
          if (listeners[i].once)
            this.removeListener(event, listeners[i].fn, undefined, true);
          switch (len) {
            case 1:
              listeners[i].fn.call(listeners[i].context);
              break;
            case 2:
              listeners[i].fn.call(listeners[i].context, a1);
              break;
            case 3:
              listeners[i].fn.call(listeners[i].context, a1, a2);
              break;
            case 4:
              listeners[i].fn.call(listeners[i].context, a1, a2, a3);
              break;
            default:
              if (!args)
                for (j = 1, args = new Array(len - 1);j < len; j++) {
                  args[j - 1] = arguments[j];
                }
              listeners[i].fn.apply(listeners[i].context, args);
          }
        }
      }
      return true;
    };
    EventEmitter.prototype.on = function on(event, fn, context) {
      return addListener(this, event, fn, context, false);
    };
    EventEmitter.prototype.once = function once(event, fn, context) {
      return addListener(this, event, fn, context, true);
    };
    EventEmitter.prototype.removeListener = function removeListener(event, fn, context, once) {
      var evt = prefix ? prefix + event : event;
      if (!this._events[evt])
        return this;
      if (!fn) {
        clearEvent(this, evt);
        return this;
      }
      var listeners = this._events[evt];
      if (listeners.fn) {
        if (listeners.fn === fn && (!once || listeners.once) && (!context || listeners.context === context)) {
          clearEvent(this, evt);
        }
      } else {
        for (var i = 0, events = [], length = listeners.length;i < length; i++) {
          if (listeners[i].fn !== fn || once && !listeners[i].once || context && listeners[i].context !== context) {
            events.push(listeners[i]);
          }
        }
        if (events.length)
          this._events[evt] = events.length === 1 ? events[0] : events;
        else
          clearEvent(this, evt);
      }
      return this;
    };
    EventEmitter.prototype.removeAllListeners = function removeAllListeners(event) {
      var evt;
      if (event) {
        evt = prefix ? prefix + event : event;
        if (this._events[evt])
          clearEvent(this, evt);
      } else {
        this._events = new Events;
        this._eventsCount = 0;
      }
      return this;
    };
    EventEmitter.prototype.off = EventEmitter.prototype.removeListener;
    EventEmitter.prototype.addListener = EventEmitter.prototype.on;
    EventEmitter.prefixed = prefix;
    EventEmitter.EventEmitter = EventEmitter;
    if (typeof module !== "undefined") {
      module.exports = EventEmitter;
    }
  });
  // ../node_modules/.bun/eventemitter3@5.0.4/node_modules/eventemitter3/index.mjs
  var import__ = __toESM(require_eventemitter3(), 1);

  // ../vendor/miniapp/dist/envelope.js
  function serializeEnvelope(envelope) {
    return JSON.stringify(envelope);
  }
  function parseEnvelope(raw) {
    if (typeof raw !== "string")
      return null;
    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch {
      return null;
    }
    if (typeof parsed !== "object" || parsed === null)
      return null;
    const obj = parsed;
    if (typeof obj.payload !== "object" || obj.payload === null)
      return null;
    if (obj.requestId !== undefined && typeof obj.requestId !== "string")
      return null;
    return {
      payload: obj.payload,
      requestId: obj.requestId
    };
  }
  function makeRequestId() {
    if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
      return crypto.randomUUID();
    }
    return `req_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
  }

  // ../vendor/miniapp/dist/globals.js
  function getMentraOSGlobals() {
    if (typeof window === "undefined")
      return {};
    return window.MentraOS ?? {};
  }

  // ../vendor/miniapp/dist/protocol.js
  var MiniappRequestType;
  (function(MiniappRequestType2) {
    MiniappRequestType2["CONNECT"] = "miniapp_connect";
    MiniappRequestType2["AUTH_REFRESH"] = "miniapp_auth_refresh";
    MiniappRequestType2["SUBSCRIBE"] = "miniapp_subscribe";
    MiniappRequestType2["DISPLAY"] = "miniapp_display";
    MiniappRequestType2["CANVAS"] = "miniapp_canvas";
    MiniappRequestType2["PLAY_AUDIO"] = "miniapp_play_audio";
    MiniappRequestType2["STOP_AUDIO"] = "miniapp_stop_audio";
    MiniappRequestType2["SPEAK"] = "miniapp_speak";
    MiniappRequestType2["RGB_LED"] = "miniapp_rgb_led";
    MiniappRequestType2["LOCATION_POLL"] = "miniapp_location_poll";
    MiniappRequestType2["NAVIGATION_START"] = "miniapp_navigation_start";
    MiniappRequestType2["NAVIGATION_STOP"] = "miniapp_navigation_stop";
    MiniappRequestType2["NAVIGATION_DEVIATE"] = "miniapp_navigation_deviate";
    MiniappRequestType2["NAVIGATION_SET_WRONG_SIDEWALK"] = "miniapp_navigation_set_wrong_sidewalk";
    MiniappRequestType2["NAVIGATION_SET_SKIP_CROSSINGS"] = "miniapp_navigation_set_skip_crossings";
    MiniappRequestType2["NAVIGATION_GET_STATE"] = "miniapp_navigation_get_state";
    MiniappRequestType2["NAVIGATION_COMPUTE_ROUTE"] = "miniapp_navigation_compute_route";
    MiniappRequestType2["NAVIGATION_REVERSE_GEOCODE"] = "miniapp_navigation_reverse_geocode";
    MiniappRequestType2["NAVIGATION_PLACE_AUTOCOMPLETE"] = "miniapp_navigation_place_autocomplete";
    MiniappRequestType2["NAVIGATION_PLACE_DETAILS"] = "miniapp_navigation_place_details";
    MiniappRequestType2["NAVIGATION_REQUEST_PERMISSION"] = "miniapp_navigation_request_permission";
    MiniappRequestType2["STORAGE_GET"] = "miniapp_storage_get";
    MiniappRequestType2["STORAGE_SET"] = "miniapp_storage_set";
    MiniappRequestType2["STORAGE_DELETE"] = "miniapp_storage_delete";
    MiniappRequestType2["STORAGE_LIST"] = "miniapp_storage_list";
    MiniappRequestType2["STORAGE_CLEAR"] = "miniapp_storage_clear";
    MiniappRequestType2["STORAGE_HAS"] = "miniapp_storage_has";
    MiniappRequestType2["STORAGE_GET_ALL"] = "miniapp_storage_get_all";
    MiniappRequestType2["STORAGE_SET_MULTIPLE"] = "miniapp_storage_set_multiple";
    MiniappRequestType2["STORAGE_FLUSH"] = "miniapp_storage_flush";
    MiniappRequestType2["CAMERA_FOV"] = "miniapp_camera_fov";
    MiniappRequestType2["IMU_SET_ENABLED"] = "miniapp_imu_set_enabled";
    MiniappRequestType2["SHARE"] = "miniapp_share";
    MiniappRequestType2["OPEN_URL"] = "miniapp_open_url";
    MiniappRequestType2["COPY_CLIPBOARD"] = "miniapp_copy_clipboard";
    MiniappRequestType2["DOWNLOAD"] = "miniapp_download";
    MiniappRequestType2["BLOB_CREATE"] = "miniapp_blob_create";
    MiniappRequestType2["BLOB_WRITE"] = "miniapp_blob_write";
    MiniappRequestType2["BLOB_COMMIT"] = "miniapp_blob_commit";
    MiniappRequestType2["BLOB_ABORT"] = "miniapp_blob_abort";
    MiniappRequestType2["BLOB_GET"] = "miniapp_blob_get";
    MiniappRequestType2["BLOB_LIST"] = "miniapp_blob_list";
    MiniappRequestType2["BLOB_DELETE"] = "miniapp_blob_delete";
    MiniappRequestType2["BLOB_CLEAR"] = "miniapp_blob_clear";
    MiniappRequestType2["BLOB_USAGE"] = "miniapp_blob_usage";
    MiniappRequestType2["BLOB_OPEN_READ"] = "miniapp_blob_open_read";
    MiniappRequestType2["BLOB_READ"] = "miniapp_blob_read";
    MiniappRequestType2["BLOB_CLOSE_READ"] = "miniapp_blob_close_read";
    MiniappRequestType2["BLOB_SET_FROM_URL"] = "miniapp_blob_set_from_url";
    MiniappRequestType2["BLOB_IMPORT"] = "miniapp_blob_import";
    MiniappRequestType2["BLOB_SHARE"] = "miniapp_blob_share";
    MiniappRequestType2["PING"] = "miniapp_ping";
    MiniappRequestType2["TRANSCRIPTION_CONFIG"] = "miniapp_transcription_config";
    MiniappRequestType2["DASHBOARD_CONTENT_UPDATE"] = "miniapp_dashboard_content_update";
    MiniappRequestType2["PHOTO"] = "miniapp_photo";
    MiniappRequestType2["VIDEO_RECORDING_START"] = "miniapp_video_recording_start";
    MiniappRequestType2["VIDEO_RECORDING_STOP"] = "miniapp_video_recording_stop";
    MiniappRequestType2["STREAM_START"] = "miniapp_stream_start";
    MiniappRequestType2["STREAM_STOP"] = "miniapp_stream_stop";
    MiniappRequestType2["MANAGED_STREAM_START"] = "miniapp_managed_stream_start";
    MiniappRequestType2["MANAGED_STREAM_STOP"] = "miniapp_managed_stream_stop";
    MiniappRequestType2["REQUEST_WIFI_SETUP"] = "miniapp_request_wifi_setup";
    MiniappRequestType2["PHONE_IS_WIFI_ENABLED"] = "miniapp_phone_is_wifi_enabled";
    MiniappRequestType2["PHONE_REQUEST_WIFI_ENABLE"] = "miniapp_phone_request_wifi_enable";
    MiniappRequestType2["MINIAPPS_LIST"] = "miniapp_apps_list";
    MiniappRequestType2["MINIAPPS_START"] = "miniapp_apps_start";
    MiniappRequestType2["MINIAPPS_STOP"] = "miniapp_apps_stop";
    MiniappRequestType2["ACTION_INVOKE"] = "miniapp_action_invoke";
    MiniappRequestType2["ACTION_RESULT"] = "miniapp_action_result";
  })(MiniappRequestType || (MiniappRequestType = {}));
  var MiniappResponseType;
  (function(MiniappResponseType2) {
    MiniappResponseType2["CONNECT_ACK"] = "miniapp_connect_ack";
    MiniappResponseType2["EVENT"] = "miniapp_event";
    MiniappResponseType2["REQUEST_RESULT"] = "miniapp_request_result";
    MiniappResponseType2["CAPABILITIES_UPDATE"] = "miniapp_capabilities_update";
    MiniappResponseType2["VISIBILITY_CHANGE"] = "miniapp_visibility_change";
    MiniappResponseType2["COLOR_SCHEME_CHANGE"] = "miniapp_color_scheme_change";
    MiniappResponseType2["SPEAKER_STATE"] = "miniapp_speaker_state";
    MiniappResponseType2["PERMISSIONS_UPDATE"] = "miniapp_permissions_update";
    MiniappResponseType2["AUTH_UPDATE"] = "miniapp_auth_update";
    MiniappResponseType2["PONG"] = "miniapp_pong";
    MiniappResponseType2["ACTION_CALL"] = "miniapp_action_call";
    MiniappResponseType2["WILL_DISCONNECT"] = "miniapp_will_disconnect";
    MiniappResponseType2["ERROR"] = "miniapp_error";
  })(MiniappResponseType || (MiniappResponseType = {}));
  var MiniappStreamType;
  (function(MiniappStreamType2) {
    MiniappStreamType2["BUTTON_PRESS"] = "button_press";
    MiniappStreamType2["TOUCH_EVENT"] = "touch_event";
    MiniappStreamType2["HEAD_POSITION"] = "head_position";
    MiniappStreamType2["ACCEL_DATA"] = "accel_data";
    MiniappStreamType2["GLASSES_BATTERY"] = "glasses_battery";
    MiniappStreamType2["PHONE_BATTERY"] = "phone_battery";
    MiniappStreamType2["GLASSES_CONNECTION"] = "glasses_connection";
    MiniappStreamType2["GLASSES_WIFI"] = "glasses_wifi";
    MiniappStreamType2["TRANSCRIPTION"] = "transcription";
    MiniappStreamType2["TRANSLATION"] = "translation";
    MiniappStreamType2["AUDIO_CHUNK"] = "audio_chunk";
    MiniappStreamType2["VAD"] = "vad";
    MiniappStreamType2["LOCATION_UPDATE"] = "location_update";
    MiniappStreamType2["HEADING_UPDATE"] = "heading_update";
    MiniappStreamType2["NAVIGATION_UPDATE"] = "navigation_update";
    MiniappStreamType2["NAVIGATION_ROUTE"] = "navigation_route";
    MiniappStreamType2["PHONE_NOTIFICATION"] = "phone_notification";
    MiniappStreamType2["PHONE_NOTIFICATION_DISMISSED"] = "phone_notification_dismissed";
    MiniappStreamType2["CALENDAR_EVENT"] = "calendar_event";
    MiniappStreamType2["PHOTO_TAKEN"] = "photo_taken";
    MiniappStreamType2["STREAM_STATUS"] = "stream_status";
  })(MiniappStreamType || (MiniappStreamType = {}));
  var MiniappErrorCode;
  (function(MiniappErrorCode2) {
    MiniappErrorCode2["PERMISSION_NOT_DECLARED"] = "PERMISSION_NOT_DECLARED";
    MiniappErrorCode2["NOT_IMPLEMENTED"] = "NOT_IMPLEMENTED";
    MiniappErrorCode2["REQUEST_ABORTED"] = "REQUEST_ABORTED";
    MiniappErrorCode2["INTERNAL"] = "INTERNAL";
    MiniappErrorCode2["TTS_TEXT_TOO_LONG"] = "TTS_TEXT_TOO_LONG";
    MiniappErrorCode2["TTS_INVALID_VOICE"] = "TTS_INVALID_VOICE";
    MiniappErrorCode2["TTS_UPSTREAM_ERROR"] = "TTS_UPSTREAM_ERROR";
    MiniappErrorCode2["NOT_CONNECTED"] = "NOT_CONNECTED";
    MiniappErrorCode2["NOT_PERMITTED"] = "NOT_PERMITTED";
    MiniappErrorCode2["APP_NOT_FOUND"] = "APP_NOT_FOUND";
    MiniappErrorCode2["APP_NOT_COMPATIBLE"] = "APP_NOT_COMPATIBLE";
    MiniappErrorCode2["ACTION_NOT_FOUND"] = "ACTION_NOT_FOUND";
    MiniappErrorCode2["NO_ACTION_HANDLER"] = "NO_ACTION_HANDLER";
    MiniappErrorCode2["WAKE_FAILED"] = "WAKE_FAILED";
    MiniappErrorCode2["ACTION_TIMEOUT"] = "ACTION_TIMEOUT";
    MiniappErrorCode2["PAYLOAD_TOO_LARGE"] = "PAYLOAD_TOO_LARGE";
    MiniappErrorCode2["BLOB_NOT_FOUND"] = "BLOB_NOT_FOUND";
    MiniappErrorCode2["BLOB_QUOTA_EXCEEDED"] = "BLOB_QUOTA_EXCEEDED";
    MiniappErrorCode2["BLOB_TOO_LARGE"] = "BLOB_TOO_LARGE";
    MiniappErrorCode2["BLOB_HANDLE_INVALID"] = "BLOB_HANDLE_INVALID";
    MiniappErrorCode2["BLOB_WRITE_FAILED"] = "BLOB_WRITE_FAILED";
    MiniappErrorCode2["BLOB_DOWNLOAD_FAILED"] = "BLOB_DOWNLOAD_FAILED";
    MiniappErrorCode2["BLOB_IMPORT_FAILED"] = "BLOB_IMPORT_FAILED";
  })(MiniappErrorCode || (MiniappErrorCode = {}));

  // ../vendor/miniapp/dist/transport/dispatch.js
  class DispatchTransport {
    constructor() {
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.open_ = false;
    }
    static isAvailable() {
      return typeof globalThis.__dispatch === "function";
    }
    async open() {
      if (!DispatchTransport.isAvailable()) {
        throw new Error("DispatchTransport: __dispatch is not installed on globalThis");
      }
      const g = globalThis;
      g.__mentraDeliverBridgeRaw = (raw) => {
        if (this.messageHandler)
          this.messageHandler(raw);
      };
      this.open_ = true;
    }
    send(raw) {
      if (!this.open_) {
        throw new Error("DispatchTransport: send() before open()");
      }
      const g = globalThis;
      if (typeof g.__dispatch !== "function") {
        this.open_ = false;
        this.disconnectHandler?.("DispatchTransport: __dispatch disappeared");
        return;
      }
      try {
        g.__dispatch("__bridge", "send", JSON.stringify([raw]));
      } catch (e) {
        this.disconnectHandler?.(`DispatchTransport: __dispatch threw: ${String(e)}`);
      }
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      this.open_ = false;
      const g = globalThis;
      if (g.__mentraDeliverBridgeRaw) {
        delete g.__mentraDeliverBridgeRaw;
      }
    }
    isOpen() {
      return this.open_;
    }
  }

  // ../vendor/miniapp/dist/transport/local-socket.js
  var DEFAULT_URL = "ws://127.0.0.1:8765";

  class LocalSocketTransport {
    constructor(options = {}) {
      this.ws = null;
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.url = options.url ?? DEFAULT_URL;
    }
    async open() {
      if (this.ws && this.ws.readyState === WebSocket.OPEN)
        return;
      if (typeof WebSocket === "undefined") {
        throw new Error("LocalSocketTransport: browser WebSocket global not available");
      }
      await new Promise((resolve, reject) => {
        const ws = new WebSocket(this.url);
        let settled = false;
        const settle = (fn) => {
          if (settled)
            return;
          settled = true;
          fn();
        };
        ws.onopen = () => {
          this.ws = ws;
          settle(() => resolve());
        };
        ws.onerror = (ev) => {
          settle(() => reject(new Error(`LocalSocketTransport: failed to connect to ${this.url}: ${String(ev)}`)));
        };
        ws.onmessage = (ev) => {
          const data = ev.data;
          if (typeof data === "string")
            this.messageHandler?.(data);
        };
        ws.onclose = (ev) => {
          if (this.ws === ws)
            this.ws = null;
          this.disconnectHandler?.(`closed: ${ev.code} ${ev.reason}`);
        };
      });
    }
    send(raw) {
      if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
        throw new Error("LocalSocketTransport: not connected");
      }
      this.ws.send(raw);
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      if (!this.ws)
        return;
      try {
        this.ws.close();
      } catch {}
      this.ws = null;
    }
    isOpen() {
      return !!this.ws && this.ws.readyState === WebSocket.OPEN;
    }
  }

  // ../vendor/miniapp/dist/transport/mock.js
  var LOG_PREFIX = "[mock-transport]";
  function isMockExplicitlyRequested() {
    if (typeof window === "undefined")
      return false;
    try {
      if (typeof window.location !== "undefined" && window.location.search) {
        const params = new URLSearchParams(window.location.search);
        if (params.get("mentra") === "mock")
          return true;
      }
    } catch {}
    try {
      if (typeof localStorage !== "undefined" && localStorage.getItem("MENTRA_MOCK") === "1") {
        return true;
      }
    } catch {}
    return false;
  }

  class MockTransport {
    constructor(options = {}) {
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.open_ = false;
      this.userId = options.userId ?? "mock-user";
      this.authToken = options.authToken ?? "mock-miniapp-token";
      this.packageName = options.packageName ?? null;
      this.silent = options.silent === true;
    }
    async open() {
      if (this.open_)
        return;
      this.open_ = true;
      this.log("transport opened (no real host; synthetic responses only)");
    }
    send(raw) {
      if (!this.open_) {
        throw new Error("MockTransport: send() before open()");
      }
      const envelope = parseEnvelope(raw);
      if (!envelope) {
        this.log("dropped unparseable envelope:", raw.slice(0, 200));
        return;
      }
      const payload = envelope.payload;
      const type = payload?.type;
      this.log(`recv ${type ?? "<unknown>"}${envelope.requestId ? ` (rid=${envelope.requestId})` : ""}`);
      switch (type) {
        case MiniappRequestType.CONNECT:
          this.deliverConnectAck(payload);
          return;
        case MiniappRequestType.PING:
          return;
        case MiniappRequestType.SUBSCRIBE:
          return;
        default:
          if (envelope.requestId) {
            this.deliverSyntheticResult(envelope.requestId, type ?? "<unknown>", payload);
          }
          return;
      }
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      if (!this.open_)
        return;
      this.open_ = false;
      this.disconnectHandler?.("MockTransport.close()");
    }
    isOpen() {
      return this.open_;
    }
    deliverConnectAck(connectPayload) {
      const incomingPackage = connectPayload.packageName ?? this.packageName ?? "com.mock.app";
      const ackPayload = {
        type: MiniappResponseType.CONNECT_ACK,
        userId: this.userId,
        packageName: incomingPackage,
        capabilities: null,
        visibility: "foreground",
        colorScheme: "light",
        auth: {
          mentraUserId: this.userId,
          oemId: "mock",
          token: this.authToken,
          expiresAt: Date.now() + 60 * 60 * 1000
        }
      };
      const envelope = { payload: ackPayload };
      this.log(`-> CONNECT_ACK userId=${this.userId} pkg=${incomingPackage}`);
      queueMicrotask(() => this.messageHandler?.(serializeEnvelope(envelope)));
    }
    deliverSyntheticResult(requestId, requestType, requestPayload) {
      const data = syntheticDataFor(requestId, requestType, requestPayload);
      const responsePayload = {
        type: MiniappResponseType.REQUEST_RESULT,
        ok: true,
        data
      };
      const envelope = { payload: responsePayload, requestId };
      this.log(`-> REQUEST_RESULT (rid=${requestId}) synthetic ${requestType}`);
      queueMicrotask(() => this.messageHandler?.(serializeEnvelope(envelope)));
    }
    log(...args) {
      if (this.silent)
        return;
      console.log(LOG_PREFIX, ...args);
    }
  }
  function syntheticDataFor(requestId, requestType, requestPayload) {
    switch (requestType) {
      case MiniappRequestType.CAMERA_FOV: {
        const presetFov = requestPayload.preset === "narrow" ? 82 : requestPayload.preset === "wide" ? 118 : requestPayload.preset === "standard" ? 102 : undefined;
        const fov = typeof requestPayload.fov === "number" ? requestPayload.fov : presetFov ?? 102;
        const roi = requestPayload.roiPosition;
        const roiPosition = roi === "bottom" ? "bottom" : roi === "top" ? "top" : "center";
        return {
          requestId,
          fov,
          roiPosition,
          timestamp: Date.now()
        };
      }
      case MiniappRequestType.PHOTO:
        return {
          photoUrl: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkAAIAAAoAAv/lxKUAAAAASUVORK5CYII=",
          requestId: "mock-photo"
        };
      case MiniappRequestType.RGB_LED:
        return { type: "rgb_led_control_response", state: "success", requestId };
      case MiniappRequestType.LOCATION_POLL:
        return { lat: 37.7956, lng: -122.3933, accuracy: 0, timestamp: Date.now() };
      case MiniappRequestType.STORAGE_GET:
        return { value: null };
      case MiniappRequestType.STORAGE_LIST:
        return { keys: [] };
      case MiniappRequestType.SPEAK:
        return { audioUrl: null, durationMs: 0 };
      case MiniappRequestType.SHARE:
      case MiniappRequestType.OPEN_URL:
      case MiniappRequestType.COPY_CLIPBOARD:
      case MiniappRequestType.DOWNLOAD:
      case MiniappRequestType.REQUEST_WIFI_SETUP:
        return { ok: true };
      default:
        return null;
    }
  }

  // ../vendor/miniapp/dist/transport/postmessage.js
  class PostMessageTransport {
    constructor() {
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.open_ = false;
      this.windowListener = null;
    }
    async open() {
      if (this.open_)
        return;
      if (typeof window === "undefined" || !window.ReactNativeWebView) {
        throw new Error("PostMessageTransport: not running inside a React Native WebView");
      }
      this.windowListener = (ev) => {
        const data = ev.data;
        if (typeof data !== "string")
          return;
        this.messageHandler?.(data);
      };
      window.addEventListener("message", this.windowListener);
      if (typeof document !== "undefined") {
        document.addEventListener("message", this.windowListener);
      }
      window.receiveNativeMessage = (raw) => {
        this.messageHandler?.(raw);
      };
      this.open_ = true;
    }
    send(raw) {
      if (typeof window === "undefined" || !window.ReactNativeWebView) {
        throw new Error("PostMessageTransport: not running inside a React Native WebView");
      }
      window.ReactNativeWebView.postMessage(raw);
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      if (!this.open_)
        return;
      this.open_ = false;
      if (this.windowListener) {
        window.removeEventListener("message", this.windowListener);
        if (typeof document !== "undefined") {
          document.removeEventListener("message", this.windowListener);
        }
        this.windowListener = null;
      }
      if (typeof window !== "undefined" && window.receiveNativeMessage) {
        window.receiveNativeMessage = undefined;
      }
      this.disconnectHandler?.("closed");
    }
    isOpen() {
      return this.open_;
    }
  }

  // ../vendor/miniapp/dist/transport/auto.js
  var LOCAL_SOCKET_OPEN_TIMEOUT_MS = 500;
  function createTransport(options = {}) {
    if (options.transport)
      return options.transport;
    if (DispatchTransport.isAvailable()) {
      return new DispatchTransport;
    }
    if (typeof window !== "undefined" && window.ReactNativeWebView) {
      return new PostMessageTransport;
    }
    if (isMockExplicitlyRequested()) {
      return new MockTransport;
    }
    if (typeof WebSocket !== "undefined") {
      const localSocketOptions = {};
      if (options.localSocketUrl)
        localSocketOptions.url = options.localSocketUrl;
      return new LocalSocketWithMockFallback(localSocketOptions);
    }
    return new MockTransport;
  }

  class LocalSocketWithMockFallback {
    constructor(options) {
      this.options = options;
      this.active = null;
      this.messageHandler = null;
      this.disconnectHandler = null;
    }
    async open() {
      const local = new LocalSocketTransport(this.options);
      let timedOut = false;
      const timeout = new Promise((_, reject) => {
        setTimeout(() => {
          timedOut = true;
          reject(new Error("LocalSocketTransport open timed out"));
        }, LOCAL_SOCKET_OPEN_TIMEOUT_MS);
      });
      try {
        await Promise.race([local.open(), timeout]);
        this.active = local;
      } catch {
        try {
          local.close();
        } catch {}
        const mock = new MockTransport;
        await mock.open();
        this.active = mock;
        console.log(timedOut ? "[mentra-miniapp] No phone WebSocket reachable; using MockTransport so the page can render." : "[mentra-miniapp] LocalSocketTransport failed; using MockTransport.");
      }
      if (this.messageHandler)
        this.active.onMessage(this.messageHandler);
      if (this.disconnectHandler)
        this.active.onDisconnect(this.disconnectHandler);
    }
    send(raw) {
      if (!this.active)
        throw new Error("LocalSocketWithMockFallback: send() before open()");
      this.active.send(raw);
    }
    onMessage(handler) {
      this.messageHandler = handler;
      this.active?.onMessage(handler);
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
      this.active?.onDisconnect(handler);
    }
    close() {
      this.active?.close();
    }
    isOpen() {
      return this.active?.isOpen() === true;
    }
  }

  // ../vendor/miniapp/dist/modules/camera.js
  class CameraModule {
    constructor(session) {
      this.session = session;
    }
    get hasPermission() {
      return this.session._hasManifestPermission("CAMERA");
    }
    async setFov(request) {
      return this.session.sendRequest({
        type: MiniappRequestType.CAMERA_FOV,
        ...request
      });
    }
    async takePhoto(options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.PHOTO,
        size: options.size ?? "medium",
        compress: options.compress ?? "none",
        sound: options.sound ?? true,
        saveToGallery: options.saveToGallery ?? false,
        exposureTimeNs: options.exposureTimeNs
      });
    }
    async startVideoRecording(options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.VIDEO_RECORDING_START,
        width: options.width,
        height: options.height,
        fps: options.fps,
        sound: options.sound ?? true,
        save: options.save ?? false
      });
    }
    async stopVideoRecording(recordingId, options = {}) {
      await this.session.sendRequest({
        type: MiniappRequestType.VIDEO_RECORDING_STOP,
        recordingId,
        uploadUrl: options.uploadUrl,
        uploadAuthToken: options.uploadAuthToken
      });
    }
  }

  // ../vendor/miniapp/dist/modules/canvas.js
  var CanvasOperation;
  (function(CanvasOperation2) {
    CanvasOperation2["SHOW_TEXT"] = "show_text";
    CanvasOperation2["SHOW_BITMAP"] = "show_bitmap";
    CanvasOperation2["CLEAR"] = "clear";
    CanvasOperation2["SHOW_PAGE"] = "show_page";
  })(CanvasOperation || (CanvasOperation = {}));

  class CanvasManager {
    constructor(session) {
      this.session = session;
    }
    send(operation, options) {
      this.session.sendOneShot({
        type: MiniappRequestType.CANVAS,
        operation,
        options
      });
    }
    showText(text, options = {}) {
      this.send(CanvasOperation.SHOW_TEXT, { text, ...options });
    }
    showBitmap(data, options = {}) {
      this.send(CanvasOperation.SHOW_BITMAP, { data, ...options });
    }
    showPage(id, options = {}) {
      this.send(CanvasOperation.SHOW_PAGE, { id, ...options });
    }
    clear(options = {}) {
      this.send(CanvasOperation.CLEAR, options);
    }
  }

  // ../vendor/miniapp/dist/modules/auth.js
  var DEFAULT_MIN_TTL_MS = 30000;

  class AuthModule {
    constructor(session) {
      this.session = session;
    }
    get current() {
      return this.session._getAuth();
    }
    get mentraUserId() {
      return this.current?.mentraUserId ?? null;
    }
    get oemId() {
      return this.current?.oemId ?? null;
    }
    async getToken(options = {}) {
      const auth = await this.session._waitForAuth(options.minTtlMs ?? DEFAULT_MIN_TTL_MS);
      return auth.token;
    }
    async getAuthHeader(options = {}) {
      return `Bearer ${await this.getToken(options)}`;
    }
    async fetch(input, init = {}) {
      const { minTtlMs, ...requestInit } = init;
      const token = await this.getToken({ minTtlMs });
      const headers = mergeHeaders(requestInit.headers, { Authorization: `Bearer ${token}` });
      return fetch(input, { ...requestInit, headers });
    }
    onUpdate(handler) {
      return this.session.on("auth", handler);
    }
  }
  function mergeHeaders(base, next) {
    const headers = {};
    if (Array.isArray(base)) {
      for (const [key, value] of base) {
        headers[key] = value;
      }
    } else if (typeof Headers !== "undefined" && base instanceof Headers) {
      base.forEach((value, key) => {
        headers[key] = value;
      });
    } else if (base && typeof base === "object") {
      for (const [key, value] of Object.entries(base)) {
        if (typeof value === "string")
          headers[key] = value;
      }
    }
    return { ...headers, ...next };
  }

  // ../vendor/miniapp/dist/modules/cloud.js
  var CLOUD_STATUS_STREAM = "_cloud_status";
  var DEFAULT_STATUS = {
    status: "disconnected",
    audioTransport: "none"
  };
  function normalizeCloudStatus(data) {
    if (!data || typeof data !== "object")
      return null;
    const raw = data;
    const status = raw.status;
    const audioTransport = raw.audioTransport;
    if (status !== "connected" && status !== "connecting" && status !== "reconnecting" && status !== "disconnected") {
      return null;
    }
    if (audioTransport !== "udp" && audioTransport !== "ws" && audioTransport !== "offline" && audioTransport !== "none") {
      return null;
    }
    return { status, audioTransport };
  }

  class CloudModule {
    constructor(session) {
      this.session = session;
      this.emitter = new import__.default;
      this.current = { ...DEFAULT_STATUS };
      this.session._subscribe(CLOUD_STATUS_STREAM, (data) => {
        const next = normalizeCloudStatus(data);
        if (!next)
          return;
        if (next.status === this.current.status && next.audioTransport === this.current.audioTransport)
          return;
        this.current = next;
        this.emitter.emit("status", { ...this.current });
      });
    }
    get status() {
      return { ...this.current };
    }
    get connected() {
      return this.current.status === "connected";
    }
    isConnected() {
      return this.connected;
    }
    onStatusChanged(handler) {
      handler({ ...this.current });
      this.emitter.on("status", handler);
      return () => {
        this.emitter.off("status", handler);
      };
    }
  }

  // ../vendor/miniapp/dist/modules/dashboard.js
  class DashboardAPI {
    constructor(session) {
      this.session = session;
      this.warned = false;
    }
    setContent(mode, content) {
      if (!this.warned) {
        console.warn("[@mentra/miniapp] dashboard.setContent() is deferred in v1.");
        this.warned = true;
      }
      this.session.sendOneShot({
        type: MiniappRequestType.DASHBOARD_CONTENT_UPDATE,
        mode,
        content
      });
    }
  }

  // ../vendor/miniapp/dist/modules/display.js
  class DisplayManager {
    constructor(session) {
      this.session = session;
    }
    send(layout, options = {}) {
      const payloadLayout = options.breakMode && supportsBreakMode(layout) ? { ...layout, breakMode: options.breakMode } : layout;
      this.session.sendOneShot({
        type: MiniappRequestType.DISPLAY,
        view: options.view ?? "main",
        layout: payloadLayout,
        durationMs: options.durationMs
      });
    }
    showTextWall(text, options = {}) {
      this.send({ layoutType: "text_wall", text }, options);
    }
    showDoubleTextWall(topText, bottomText, options = {}) {
      this.send({ layoutType: "double_text_wall", topText, bottomText }, options);
    }
    showReferenceCard(title, text, options = {}) {
      this.send({ layoutType: "reference_card", title, text }, options);
    }
    showDashboardCard(leftText, rightText) {
      this.send({ layoutType: "dashboard_card", leftText, rightText }, { view: "dashboard" });
    }
    showBitmapView(data, options = {}) {
      const { x, y, width, height, ...display } = options;
      this.send({ layoutType: "bitmap_view", data, x, y, width, height }, display);
    }
    showTextAt(text, options = {}) {
      const { x, y, width, height, borderWidth, borderRadius, ...display } = options;
      this.send({ layoutType: "positioned_text", text, x, y, width, height, borderWidth, borderRadius }, display);
    }
    clear(view = "main") {
      this.send({ layoutType: "clear_view" }, { view });
    }
  }
  function supportsBreakMode(layout) {
    return layout.layoutType === "text_wall" || layout.layoutType === "double_text_wall" || layout.layoutType === "reference_card";
  }

  // ../vendor/miniapp/dist/modules/events.js
  class EventManager {
    constructor(session) {
      this.session = session;
      this.emitter = new import__.default;
      this.refCounts = new Map;
    }
    subscribe(stream, handler) {
      this.emitter.on(stream, handler);
      const isInternal = stream.startsWith("_");
      if (!isInternal) {
        const before = this.refCounts.get(stream) ?? 0;
        this.refCounts.set(stream, before + 1);
        if (before === 0) {
          this.sendSubscriptionUpdate();
        }
      }
      return () => {
        this.emitter.off(stream, handler);
        if (isInternal)
          return;
        const current = this.refCounts.get(stream) ?? 0;
        if (current <= 1) {
          this.refCounts.delete(stream);
          this.sendSubscriptionUpdate();
        } else {
          this.refCounts.set(stream, current - 1);
        }
      };
    }
    unsubscribeAll() {
      this.emitter.removeAllListeners();
      this.refCounts.clear();
      this.sendSubscriptionUpdate();
    }
    _forwardEvent(stream, data) {
      this.emitter.emit(stream, data);
      if (stream.startsWith("transcription:") && stream !== "transcription:auto") {
        this.emitter.emit("transcription:auto", data);
      } else if (stream.startsWith("translation:")) {
        const parts = stream.split(":");
        const patterns = new Set(["translation:auto"]);
        if (parts.length === 3) {
          const [, source, target] = parts;
          patterns.add("translation:*:*");
          patterns.add(`translation:*:${target}`);
          patterns.add(`translation:${source}:*`);
        }
        patterns.delete(stream);
        for (const pattern of patterns) {
          this.emitter.emit(pattern, data);
        }
      }
    }
    sendSubscriptionUpdate() {
      const subscriptions = Array.from(this.refCounts.keys()).map((stream) => stream === MiniappStreamType.LOCATION_UPDATE ? { stream: "location_stream", rate: "realtime" } : stream);
      this.session.sendOneShot({
        type: MiniappRequestType.SUBSCRIBE,
        subscriptions
      });
    }
  }

  // ../vendor/miniapp/dist/modules/glasses.js
  class GlassesModule {
    constructor(session) {
      this.session = session;
    }
    onBattery(handler) {
      return this.session._subscribe(MiniappStreamType.GLASSES_BATTERY, handler);
    }
    onConnection(handler) {
      return this.session._subscribe(MiniappStreamType.GLASSES_CONNECTION, handler);
    }
    onWifi(handler) {
      return this.session._subscribe(MiniappStreamType.GLASSES_WIFI, handler);
    }
    async requestWifiSetup(reason) {
      await this.session.sendRequest({
        type: MiniappRequestType.REQUEST_WIFI_SETUP,
        reason
      });
    }
  }

  // ../vendor/miniapp/dist/modules/heading.js
  class HeadingModule {
    constructor(session) {
      this.session = session;
    }
    get hasPermission() {
      return this.session._hasManifestPermission("LOCATION");
    }
    onUpdate(handler) {
      return this.session._subscribe(MiniappStreamType.HEADING_UPDATE, handler);
    }
  }

  // ../vendor/miniapp/dist/modules/imu.js
  class ImuModule {
    constructor(session) {
      this.session = session;
    }
    onHeadPosition(handler) {
      return this.session._subscribe(MiniappStreamType.HEAD_POSITION, handler);
    }
    onAccel(handler) {
      return this.session._subscribe(MiniappStreamType.ACCEL_DATA, handler);
    }
    setEnabled(enabled) {
      return this.session.sendRequest({
        type: MiniappRequestType.IMU_SET_ENABLED,
        enabled
      });
    }
  }

  // ../vendor/miniapp/dist/modules/input.js
  class InputModule {
    constructor(session) {
      this.session = session;
    }
    onButtonPress(handler) {
      return this.session._subscribe(MiniappStreamType.BUTTON_PRESS, handler);
    }
    onTouch(gestureOrHandler, maybeHandler) {
      if (typeof gestureOrHandler === "function") {
        return this.session._subscribe(MiniappStreamType.TOUCH_EVENT, gestureOrHandler);
      }
      const handler = maybeHandler;
      const gestures = Array.isArray(gestureOrHandler) ? gestureOrHandler : [gestureOrHandler];
      if (gestures.length === 0)
        return () => {};
      const unsubs = [];
      for (const g of gestures) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TOUCH_EVENT}:${g}`, handler));
      }
      return () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
    }
  }

  // ../vendor/miniapp/dist/modules/led.js
  class LedModule {
    constructor(session) {
      this.session = session;
    }
    async turnOn(options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.RGB_LED,
        action: "on",
        color: options.color ?? "red",
        ontime: options.ontime ?? 1000,
        offtime: options.offtime ?? 0,
        count: options.count ?? 1
      });
    }
    async turnOff() {
      return this.session.sendRequest({
        type: MiniappRequestType.RGB_LED,
        action: "off"
      });
    }
    async blink(color, ontime, offtime, count) {
      return this.turnOn({ color, ontime, offtime, count });
    }
    async solid(color, duration) {
      return this.turnOn({ color, ontime: duration, offtime: 0, count: 1 });
    }
  }

  // ../vendor/miniapp/dist/modules/location.js
  class LocationModule {
    constructor(session) {
      this.session = session;
    }
    get hasPermission() {
      return this.session._hasManifestPermission("LOCATION");
    }
    onUpdate(handler) {
      return this.session._subscribe(MiniappStreamType.LOCATION_UPDATE, handler);
    }
    getOnce() {
      return this.session.sendRequest({
        type: MiniappRequestType.LOCATION_POLL
      });
    }
  }

  // ../vendor/miniapp/dist/modules/mic.js
  class MicModule {
    constructor(session) {
      this.session = session;
      this.unsubs = new Set;
    }
    onVoiceActivity(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.VAD, handler));
    }
    onAudioChunk(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.AUDIO_CHUNK, handler));
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
    get hasPermission() {
      return this.session._hasManifestPermission("MICROPHONE");
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
  }

  // ../vendor/miniapp/dist/modules/pivots/geometry.js
  var TURN_THRESHOLD_DEG = 15;
  var SAME_DIR_MERGE_M = 25;
  var RDP_EPSILON_M = 5;
  var MIN_BEND_PER_POINT_DEG = 10;
  var STRAIGHT_SEGMENT_BREAK_M = 1;
  var INTERSECTION_CLUSTER_M = 30;
  function haversineMeters(a, b) {
    const R = 6371000;
    const toRad = (d) => d * Math.PI / 180;
    const dLat = toRad(b.lat - a.lat);
    const dLng = toRad(b.lng - a.lng);
    const lat1 = toRad(a.lat);
    const lat2 = toRad(b.lat);
    const x = Math.sin(dLat / 2) ** 2 + Math.sin(dLng / 2) ** 2 * Math.cos(lat1) * Math.cos(lat2);
    return 2 * R * Math.asin(Math.sqrt(x));
  }
  function bearingDeg(a, b) {
    const toRad = (d) => d * Math.PI / 180;
    const toDeg = (r) => r * 180 / Math.PI;
    const lat1 = toRad(a.lat);
    const lat2 = toRad(b.lat);
    const dLng = toRad(b.lng - a.lng);
    const y = Math.sin(dLng) * Math.cos(lat2);
    const x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLng);
    return (toDeg(Math.atan2(y, x)) + 360) % 360;
  }
  function signedAngleDiff(target, actual) {
    return (target - actual + 540) % 360 - 180;
  }
  function rdpSimplify(points, epsilonMeters) {
    if (points.length < 3)
      return points.map((_, i) => i);
    const keep = new Array(points.length).fill(false);
    keep[0] = true;
    keep[points.length - 1] = true;
    const stack = [[0, points.length - 1]];
    while (stack.length) {
      const [lo, hi] = stack.pop();
      let maxDist = 0;
      let maxIdx = -1;
      for (let i = lo + 1;i < hi; i++) {
        const d = perpDistMeters(points[i], points[lo], points[hi]);
        if (d > maxDist) {
          maxDist = d;
          maxIdx = i;
        }
      }
      if (maxIdx !== -1 && maxDist > epsilonMeters) {
        keep[maxIdx] = true;
        stack.push([lo, maxIdx], [maxIdx, hi]);
      }
    }
    const out = [];
    for (let i = 0;i < keep.length; i++)
      if (keep[i])
        out.push(i);
    return out;
  }
  function perpDistMeters(p, a, b) {
    const mPerDegLat = 111320;
    const mPerDegLng = 111320 * Math.cos(a.lat * Math.PI / 180);
    const bx = (b.lng - a.lng) * mPerDegLng;
    const by = (b.lat - a.lat) * mPerDegLat;
    const px = (p.lng - a.lng) * mPerDegLng;
    const py = (p.lat - a.lat) * mPerDegLat;
    const dx = bx;
    const dy = by;
    const len = Math.sqrt(dx * dx + dy * dy);
    if (len === 0)
      return Math.sqrt(px * px + py * py);
    return Math.abs(dx * -py - -px * dy) / len;
  }
  function extractPivots(rawPoints) {
    if (rawPoints.length < 3)
      return [];
    const keptIdx = rdpSimplify(rawPoints, RDP_EPSILON_M);
    const simplified = keptIdx.map((i) => rawPoints[i]);
    if (simplified.length < 3)
      return [];
    const deltas = [];
    for (let i = 1;i < simplified.length - 1; i++) {
      const inBearing = bearingDeg(simplified[i - 1], simplified[i]);
      const outBearing = bearingDeg(simplified[i], simplified[i + 1]);
      deltas.push(signedAngleDiff(outBearing, inBearing));
    }
    const candidates = [];
    let runStart = -1;
    let runSum = 0;
    let runSign = 0;
    const flushRun = (endExclusive) => {
      if (runStart === -1)
        return;
      if (Math.abs(runSum) >= TURN_THRESHOLD_DEG) {
        let bestIdx = runStart;
        let bestAbs = 0;
        for (let k = runStart;k < endExclusive; k++) {
          const a = Math.abs(deltas[k]);
          if (a > bestAbs) {
            bestAbs = a;
            bestIdx = k;
          }
        }
        const simplifiedIdx = bestIdx + 1;
        candidates.push({
          lat: simplified[simplifiedIdx].lat,
          lng: simplified[simplifiedIdx].lng,
          direction: runSum > 0 ? "right" : "left",
          simplifiedRouteIndex: simplifiedIdx,
          rawRouteIndex: keptIdx[simplifiedIdx],
          headingDelta: runSum
        });
      }
      runStart = -1;
      runSum = 0;
      runSign = 0;
    };
    let metersSinceLastBend = 0;
    for (let k = 0;k < deltas.length; k++) {
      const d = deltas[k];
      const sign = d > 0 ? 1 : d < 0 ? -1 : 0;
      const segLen = haversineMeters(simplified[k + 1], simplified[k + 2]);
      if (sign === 0 || Math.abs(d) < MIN_BEND_PER_POINT_DEG) {
        if (runStart !== -1) {
          if (sign === runSign || sign === 0)
            runSum += d;
          metersSinceLastBend += segLen;
          if (metersSinceLastBend >= STRAIGHT_SEGMENT_BREAK_M) {
            flushRun(k + 1);
          }
        }
        continue;
      }
      if (runStart === -1) {
        runStart = k;
        runSum = d;
        runSign = sign;
        metersSinceLastBend = segLen;
      } else if (sign === runSign) {
        if (metersSinceLastBend >= STRAIGHT_SEGMENT_BREAK_M) {
          flushRun(k);
          runStart = k;
          runSum = d;
          runSign = sign;
        } else {
          runSum += d;
        }
        metersSinceLastBend = segLen;
      } else {
        flushRun(k);
        runStart = k;
        runSum = d;
        runSign = sign;
        metersSinceLastBend = segLen;
      }
    }
    flushRun(deltas.length);
    const merged = [];
    for (const p of candidates) {
      const last = merged[merged.length - 1];
      if (last && last.direction === p.direction && haversineMeters({ lat: last.lat, lng: last.lng }, { lat: p.lat, lng: p.lng }) < SAME_DIR_MERGE_M) {
        if (Math.abs(p.headingDelta) > Math.abs(last.headingDelta)) {
          merged[merged.length - 1] = p;
        }
        continue;
      }
      merged.push(p);
    }
    const clustered = [];
    for (const p of merged) {
      const last = clustered[clustered.length - 1];
      if (last && haversineMeters({ lat: last.lat, lng: last.lng }, { lat: p.lat, lng: p.lng }) < INTERSECTION_CLUSTER_M) {
        const netDelta = last.headingDelta + p.headingDelta;
        const anchor = Math.abs(p.headingDelta) > Math.abs(last.headingDelta) ? p : last;
        clustered[clustered.length - 1] = {
          ...anchor,
          direction: netDelta > 0 ? "right" : "left",
          headingDelta: netDelta
        };
        continue;
      }
      clustered.push(p);
    }
    return clustered.filter((p) => Math.abs(p.headingDelta) >= TURN_THRESHOLD_DEG);
  }
  function cumulativeDistances(points) {
    const out = new Array(points.length);
    out[0] = 0;
    for (let i = 1;i < points.length; i++) {
      out[i] = out[i - 1] + haversineMeters(points[i - 1], points[i]);
    }
    return out;
  }

  // ../vendor/miniapp/dist/modules/pivots/instructions.js
  var DIRECTION_WORDS = new Set(["right", "left", "the right", "the left", "north", "south", "east", "west"]);
  var MANEUVER_VERBS = /\b(turn|slight|sharp|continue|head|merge|exit|uturn|u-turn|then|keep)\b/i;
  function roadNameFromInstruction(instruction) {
    if (!instruction)
      return null;
    const firstLine = instruction.split(`
`)[0] ?? "";
    const m = firstLine.match(/\bonto\s+(.+)$/i);
    let raw = (m ? m[1] : "").trim();
    if (!raw)
      return null;
    if (raw.includes(","))
      return null;
    raw = raw.split(/\s+(?:toward|towards|to|and|then|for)\b/i)[0]?.trim() ?? "";
    raw = raw.replace(/\s+#.*$/, "").trim();
    if (!raw)
      return null;
    if (DIRECTION_WORDS.has(raw.toLowerCase()))
      return null;
    if (MANEUVER_VERBS.test(raw))
      return null;
    return raw;
  }
  var ROAD_SUFFIXES = /\b(st|street|ave|avenue|blvd|boulevard|rd|road|dr|drive|ln|lane|way|ct|court|pl|place|ter|terrace|hwy|highway)\b\.?/g;
  function normalizeRoad(road) {
    return road.toLowerCase().replace(ROAD_SUFFIXES, "").replace(/[^a-z0-9 ]/g, "").replace(/\s+/g, " ").trim();
  }
  function sameRoad(a, b) {
    return normalizeRoad(a) === normalizeRoad(b);
  }
  function turnDirection(maneuver) {
    if (!maneuver)
      return null;
    const m = maneuver.toUpperCase();
    if (m.includes("LEFT"))
      return "left";
    if (m.includes("RIGHT"))
      return "right";
    return null;
  }
  var PROBE_METERS = 22;
  function signedBendAt(points, junction) {
    if (points.length < 3)
      return null;
    let mid = 0;
    let bestDist = Infinity;
    for (let i = 0;i < points.length; i++) {
      const d = haversineMeters(points[i], junction);
      if (d < bestDist) {
        bestDist = d;
        mid = i;
      }
    }
    let before = mid;
    while (before > 0 && haversineMeters(points[before], points[mid]) < PROBE_METERS)
      before--;
    let after = mid;
    while (after < points.length - 1 && haversineMeters(points[after], points[mid]) < PROBE_METERS)
      after++;
    if (before === mid || after === mid)
      return null;
    const incoming = bearingDeg(points[before], points[mid]);
    const outgoing = bearingDeg(points[mid], points[after]);
    return signedAngleDiff(outgoing, incoming);
  }
  var MIN_TURN_ANGLE_DEG = 30;
  function extractPivotsFromComputedSteps(steps, polyline) {
    if (!steps || steps.length < 2)
      return [];
    const initial = steps.map((s, i) => ({
      stepIdx: i,
      name: s.road ?? roadNameFromInstruction(s.instruction)
    }));
    let annotated = initial;
    for (let pass = 0;pass < 4; pass++) {
      const collapsed = [];
      for (let i = 0;i < annotated.length; i++) {
        const prev = collapsed[collapsed.length - 1];
        const here = annotated[i];
        const next = annotated[i + 1];
        if (prev?.name && next?.name && here.name && !sameRoad(prev.name, here.name) && sameRoad(prev.name, next.name)) {
          continue;
        }
        collapsed.push(here);
      }
      if (collapsed.length === annotated.length)
        break;
      annotated = collapsed;
    }
    const out = [];
    for (let i = 0;i < annotated.length - 1; i++) {
      const here = annotated[i];
      const nextAnn = annotated[i + 1];
      const s = steps[here.stepIdx];
      const next = steps[nextAnn.stepIdx];
      const fromRoad = here.name;
      const toRoad = nextAnn.name;
      if (!fromRoad)
        continue;
      if (toRoad && sameRoad(fromRoad, toRoad))
        continue;
      if (!Number.isFinite(s.endLat) || !Number.isFinite(s.endLng))
        continue;
      const junction = { lat: s.endLat, lng: s.endLng };
      const signedBend = signedBendAt(polyline, junction);
      if (signedBend != null && Math.abs(signedBend) < MIN_TURN_ANGLE_DEG)
        continue;
      const geomDir = signedBend == null ? null : signedBend > 0 ? "right" : "left";
      const direction = geomDir ?? turnDirection(next.maneuver);
      out.push({
        lat: s.endLat,
        lng: s.endLng,
        fromRoad,
        toRoad,
        direction,
        maneuver: next.maneuver ?? (direction === "left" ? "TURN_LEFT" : "TURN_RIGHT")
      });
    }
    return out;
  }

  // ../vendor/miniapp/dist/modules/pivots/engine.js
  var RADIUS_DEFAULTS_M = {
    walking: 7,
    cycling: 15,
    driving: 40,
    two_wheeler: 25
  };
  var APPROACH_DEFAULTS_M = {
    walking: 100,
    cycling: 300,
    driving: 800,
    two_wheeler: 500
  };
  var NON_TURN_MANEUVERS = new Set(["STRAIGHT", "NAME_CHANGE", "DEPART", "ARRIVE"]);
  var STEP_MATCH_MAX_INDEX_DELTA = 8;
  var ON_ROUTE_PERP_TOLERANCE_M = 50;

  class PivotEngine {
    constructor(mode, opts) {
      this.pivots = [];
      this.states = [];
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = [];
      this.cumulative = [];
      this.roadNameResolver = null;
      this.routeGeneration = 0;
      this.subscribers = new Set;
      this.opts = resolveOptions(mode, opts);
    }
    updateOptions(mode, opts) {
      this.opts = resolveOptions(mode, opts);
      for (const p of this.pivots) {
        p.radiusMeters = this.opts.radiusMeters;
      }
    }
    setRoadNameResolver(resolver) {
      this.roadNameResolver = resolver;
    }
    reset() {
      if (this.activePivotIndex !== null) {
        const active = this.pivots[this.activePivotIndex];
        if (active)
          this.emit({ kind: "exited", pivot: active });
      }
      this.pivots = [];
      this.states = [];
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = [];
      this.cumulative = [];
    }
    setRouteFromComputedSteps(route, computedSteps) {
      const points = route.points ?? [];
      if (this.activePivotIndex !== null) {
        const active = this.pivots[this.activePivotIndex];
        if (active)
          this.emit({ kind: "exited", pivot: active });
      }
      if (points.length < 3 || !computedSteps || computedSteps.length < 2) {
        this.setRoute(route, null);
        return;
      }
      const cumulative = cumulativeDistances(points);
      const instructionPivots = extractPivotsFromComputedSteps(computedSteps, points);
      console.log(`[PivotEngine] setRouteFromComputedSteps: steps=${computedSteps.length} instructionPivots=${instructionPivots.length}` + (instructionPivots.length > 0 ? `
` + instructionPivots.map((p, i) => `  pivot[${i}] ${p.fromRoad ?? "—"} → ${p.toRoad ?? "—"} dir=${p.direction} @ (${p.lat.toFixed(5)}, ${p.lng.toFixed(5)})`).join(`
`) : ""));
      if (instructionPivots.length === 0) {
        console.log(`[PivotEngine] falling back to setRoute (geometry) — input steps:
` + computedSteps.map((s, i) => `  step[${i}] road=${s.road ?? "—"} maneuver=${s.maneuver ?? "—"} @ (${s.lat.toFixed(5)}, ${s.lng.toFixed(5)}) → (${s.endLat.toFixed(5)}, ${s.endLng.toFixed(5)})`).join(`
`));
        this.setRoute(route, null);
        return;
      }
      const pivots = instructionPivots.map((p, i) => ({
        index: i,
        lat: p.lat,
        lng: p.lng,
        direction: p.direction === "left" ? "left" : "right",
        fromRoad: p.fromRoad,
        toRoad: p.toRoad,
        maneuver: p.maneuver,
        distanceAlongRouteMeters: alongRouteAtCoord(points, cumulative, { lat: p.lat, lng: p.lng }),
        radiusMeters: this.opts.radiusMeters
      }));
      pivots.sort((a, b) => a.distanceAlongRouteMeters - b.distanceAlongRouteMeters);
      for (let i = 0;i < pivots.length; i++)
        pivots[i].index = i;
      this.pivots = pivots;
      this.states = pivots.map(() => ({ approachingFired: false, entered: false, exited: false }));
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = points;
      this.cumulative = cumulative;
      this.routeGeneration++;
      this._resolveMissingRoadNames(this.routeGeneration);
    }
    setRoute(route, _userPosition) {
      const points = route.points ?? [];
      const steps = route.steps ?? [];
      if (this.activePivotIndex !== null) {
        const active = this.pivots[this.activePivotIndex];
        if (active)
          this.emit({ kind: "exited", pivot: active });
      }
      if (points.length < 3) {
        this.pivots = [];
        this.states = [];
        this.cursor = 0;
        this.activePivotIndex = null;
        this.points = [];
        this.cumulative = [];
        return;
      }
      const cumulative = cumulativeDistances(points);
      const raw = extractPivots(points);
      const stepIndex = buildStepIndex(steps);
      const pivots = [];
      for (let i = 0;i < raw.length; i++) {
        const r = raw[i];
        const matched = matchStep(r, stepIndex);
        if (matched && NON_TURN_MANEUVERS.has(matched.maneuver)) {
          continue;
        }
        pivots.push({
          index: pivots.length,
          lat: r.lat,
          lng: r.lng,
          direction: r.direction,
          fromRoad: matched?.fromRoad ?? null,
          toRoad: matched?.toRoad ?? null,
          maneuver: matched?.maneuver ?? (r.direction === "left" ? "TURN_LEFT" : "TURN_RIGHT"),
          distanceAlongRouteMeters: distanceAtIndex(cumulative, r.rawRouteIndex),
          radiusMeters: this.opts.radiusMeters
        });
      }
      pivots.sort((a, b) => a.distanceAlongRouteMeters - b.distanceAlongRouteMeters);
      for (let i = 0;i < pivots.length; i++)
        pivots[i].index = i;
      this.pivots = pivots;
      this.states = pivots.map(() => ({ approachingFired: false, entered: false, exited: false }));
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = points;
      this.cumulative = cumulative;
      this.routeGeneration++;
      this._resolveMissingRoadNames(this.routeGeneration);
    }
    async _resolveMissingRoadNames(generation) {
      const pivots = this.pivots;
      if (pivots.length === 0)
        return;
      for (let i = 0;i < pivots.length - 1; i++) {
        const here = pivots[i];
        const next = pivots[i + 1];
        if (!here.toRoad && next.fromRoad)
          here.toRoad = next.fromRoad;
        if (!next.fromRoad && here.toRoad)
          next.fromRoad = here.toRoad;
      }
      for (let i = pivots.length - 1;i > 0; i--) {
        const here = pivots[i];
        const prev = pivots[i - 1];
        if (!prev.toRoad && here.fromRoad)
          prev.toRoad = here.fromRoad;
        if (!here.fromRoad && prev.toRoad)
          here.fromRoad = prev.toRoad;
      }
      const resolver = this.roadNameResolver;
      if (!resolver)
        return;
      if (this.points.length < 2)
        return;
      const SAMPLE_OFFSETS_M = [18, 30, 50, 80];
      const points = this.points;
      const cumulative = this.cumulative;
      const geocodeWithExpansion = async (pivotAlong, direction) => {
        for (const offset of SAMPLE_OFFSETS_M) {
          const sample = sampleAlongRoute(points, cumulative, pivotAlong + direction * offset);
          if (!sample)
            continue;
          try {
            const road = await resolver(sample);
            if (generation !== this.routeGeneration)
              return null;
            if (road)
              return road;
          } catch {}
        }
        return null;
      };
      const tasks = [];
      for (const pivot of pivots) {
        if (pivot.fromRoad && pivot.toRoad)
          continue;
        const along = pivot.distanceAlongRouteMeters;
        if (!pivot.fromRoad) {
          tasks.push(geocodeWithExpansion(along, -1).then((road) => {
            if (generation !== this.routeGeneration)
              return;
            if (road && !pivot.fromRoad)
              pivot.fromRoad = road;
          }));
        }
        if (!pivot.toRoad) {
          tasks.push(geocodeWithExpansion(along, 1).then((road) => {
            if (generation !== this.routeGeneration)
              return;
            if (road && !pivot.toRoad)
              pivot.toRoad = road;
          }));
        }
      }
      await Promise.all(tasks);
      if (generation !== this.routeGeneration)
        return;
      for (let i = 0;i < pivots.length - 1; i++) {
        const here = pivots[i];
        const next = pivots[i + 1];
        if (!here.toRoad && next.fromRoad)
          here.toRoad = next.fromRoad;
        if (!next.fromRoad && here.toRoad)
          next.fromRoad = here.toRoad;
      }
    }
    onLocationUpdate(coords) {
      if (this.pivots.length === 0)
        return;
      const projection = projectOntoPolyline(this.points, this.cumulative, coords);
      const useAlongPath = projection !== null && projection.perpMeters <= ON_ROUTE_PERP_TOLERANCE_M;
      const userAlong = projection?.alongMeters ?? 0;
      for (let i = this.cursor;i < this.pivots.length; i++) {
        const pivot = this.pivots[i];
        const state = this.states[i];
        if (state.exited)
          continue;
        const aheadDelta = pivot.distanceAlongRouteMeters - userAlong;
        const distanceToPivot = useAlongPath ? Math.abs(aheadDelta) : haversineMeters(coords, { lat: pivot.lat, lng: pivot.lng });
        const approaching = !state.approachingFired && distanceToPivot <= this.opts.approachThresholdMeters && (!useAlongPath || aheadDelta >= -this.opts.radiusMeters);
        if (approaching) {
          state.approachingFired = true;
          this.emit({ kind: "approaching", pivot, distanceMeters: distanceToPivot });
        }
        if (!state.entered && distanceToPivot <= pivot.radiusMeters) {
          state.entered = true;
          this.activePivotIndex = i;
          this.emit({ kind: "entered", pivot });
        }
        const movedPastOnPath = useAlongPath && aheadDelta < -pivot.radiusMeters;
        if ((state.entered && distanceToPivot > pivot.radiusMeters || !state.entered && movedPastOnPath) && !state.exited) {
          if (!state.entered) {
            state.entered = true;
            this.activePivotIndex = i;
            this.emit({ kind: "entered", pivot });
          }
          state.exited = true;
          if (this.activePivotIndex === i)
            this.activePivotIndex = null;
          this.emit({ kind: "exited", pivot });
          if (this.cursor <= i)
            this.cursor = i + 1;
        }
        if (!state.approachingFired && distanceToPivot > this.opts.approachThresholdMeters * 2) {
          break;
        }
      }
    }
    subscribe(fn) {
      this.subscribers.add(fn);
      return () => {
        this.subscribers.delete(fn);
      };
    }
    getPivots() {
      return this.pivots.slice();
    }
    getActivePivot() {
      if (this.activePivotIndex === null)
        return null;
      return this.pivots[this.activePivotIndex] ?? null;
    }
    getUpcomingPivot() {
      for (let i = this.cursor;i < this.pivots.length; i++) {
        if (!this.states[i].exited)
          return this.pivots[i];
      }
      return null;
    }
    emit(event) {
      for (const fn of this.subscribers) {
        try {
          fn(event);
        } catch (err) {
          console.error("[PivotEngine] subscriber threw:", err);
        }
      }
    }
  }
  function resolveOptions(mode, opts) {
    return {
      radiusMeters: opts?.radiusMeters ?? RADIUS_DEFAULTS_M[mode] ?? RADIUS_DEFAULTS_M.walking,
      approachThresholdMeters: opts?.approachThresholdMeters ?? APPROACH_DEFAULTS_M[mode] ?? APPROACH_DEFAULTS_M.walking
    };
  }
  function projectOntoPolyline(points, cumulative, user) {
    if (points.length < 2 || cumulative.length !== points.length)
      return null;
    const mPerDegLat = 111320;
    const mPerDegLng = 111320 * Math.cos(user.lat * Math.PI / 180);
    const ux = user.lng * mPerDegLng;
    const uy = user.lat * mPerDegLat;
    let bestPerp = Number.POSITIVE_INFINITY;
    let bestAlong = 0;
    for (let i = 0;i < points.length - 1; i++) {
      const a = points[i];
      const b = points[i + 1];
      const ax = a.lng * mPerDegLng;
      const ay = a.lat * mPerDegLat;
      const bx = b.lng * mPerDegLng;
      const by = b.lat * mPerDegLat;
      const dx = bx - ax;
      const dy = by - ay;
      const segLen2 = dx * dx + dy * dy;
      const t = segLen2 > 0 ? Math.max(0, Math.min(1, ((ux - ax) * dx + (uy - ay) * dy) / segLen2)) : 0;
      const px = ax + t * dx;
      const py = ay + t * dy;
      const perp = Math.hypot(ux - px, uy - py);
      if (perp < bestPerp) {
        bestPerp = perp;
        const segLen = Math.sqrt(segLen2);
        bestAlong = cumulative[i] + t * segLen;
      }
    }
    if (!Number.isFinite(bestPerp))
      return null;
    return { perpMeters: bestPerp, alongMeters: bestAlong };
  }
  function alongRouteAtCoord(points, cumulative, coord) {
    const projection = projectOntoPolyline(points, cumulative, coord);
    return projection?.alongMeters ?? 0;
  }
  function sampleAlongRoute(points, cumulative, targetMeters) {
    if (points.length < 2 || cumulative.length !== points.length)
      return null;
    const total = cumulative[cumulative.length - 1];
    if (!Number.isFinite(targetMeters))
      return null;
    if (targetMeters <= 0)
      return { lat: points[0].lat, lng: points[0].lng };
    if (targetMeters >= total) {
      const last = points[points.length - 1];
      return { lat: last.lat, lng: last.lng };
    }
    let lo = 0;
    let hi = cumulative.length - 1;
    while (lo + 1 < hi) {
      const mid = lo + hi >>> 1;
      if (cumulative[mid] <= targetMeters)
        lo = mid;
      else
        hi = mid;
    }
    const segStart = cumulative[lo];
    const segEnd = cumulative[hi];
    const segLen = segEnd - segStart;
    const t = segLen > 0 ? (targetMeters - segStart) / segLen : 0;
    const a = points[lo];
    const b = points[hi];
    return { lat: a.lat + (b.lat - a.lat) * t, lng: a.lng + (b.lng - a.lng) * t };
  }
  function distanceAtIndex(cumulative, idx) {
    if (cumulative.length === 0)
      return 0;
    if (idx < 0)
      return 0;
    if (idx >= cumulative.length)
      return cumulative[cumulative.length - 1];
    return cumulative[idx];
  }
  function buildStepIndex(steps) {
    if (!steps.length)
      return [];
    return steps.slice().sort((a, b) => a.routeIndex - b.routeIndex);
  }
  function matchStep(raw, stepIndex) {
    if (stepIndex.length < 2)
      return null;
    let bestJ = -1;
    let bestDelta = Number.POSITIVE_INFINITY;
    for (let i = 1;i < stepIndex.length; i++) {
      const delta = Math.abs(stepIndex[i].routeIndex - raw.rawRouteIndex);
      if (delta <= bestDelta) {
        bestDelta = delta;
        bestJ = i;
      }
    }
    if (bestJ < 1)
      return null;
    if (bestDelta > STEP_MATCH_MAX_INDEX_DELTA)
      return null;
    const SHORT_TRANSIT_METERS = 25;
    const finalIndex = stepIndex.length - 1;
    let j = bestJ;
    while (j < finalIndex - 1 && stepIndex[j].distanceMeters > 0 && stepIndex[j].distanceMeters < SHORT_TRANSIT_METERS) {
      j++;
    }
    if (j >= finalIndex)
      j = finalIndex - 1;
    const fromStep = stepIndex[bestJ - 1];
    const toStep = stepIndex[j];
    return {
      fromRoad: fromStep.road ?? null,
      toRoad: toStep.road ?? null,
      maneuver: fromStep.maneuver
    };
  }

  // ../vendor/miniapp/dist/modules/navigation.js
  class NavigationModule {
    constructor(session) {
      this.session = session;
      this._pivots = new PivotEngine("walking", undefined);
      this._tripUnsubs = [];
      this._tripStops = null;
      this._tripMode = "walking";
      this._tripAvoid = undefined;
      this._computeRouteSeq = 0;
      this._lastUserPosition = null;
      this._pivots.setRoadNameResolver(async (coord) => {
        try {
          const result = await this.reverseGeocodeRoad(coord);
          if (!result.ok)
            return null;
          return result.road ?? null;
        } catch {
          return null;
        }
      });
    }
    get hasPermission() {
      return this.session._hasManifestPermission("LOCATION");
    }
    requestPermission() {
      if (!this.hasPermission) {
        return Promise.resolve({
          ok: false,
          accepted: false,
          error: "LOCATION permission not declared in miniapp.json (required for navigation.requestPermission)."
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_REQUEST_PERMISSION
      });
    }
    async start(opts) {
      if (!this.hasPermission) {
        return {
          ok: false,
          error: "LOCATION permission not declared in miniapp.json (required for navigation.start)."
        };
      }
      const stops = normalizeStops(opts);
      const mode = opts.mode ?? "driving";
      this._tripStops = stops.length > 0 ? stops : null;
      this._tripMode = mode;
      this._tripAvoid = opts.avoid;
      this._attachPivotTrackingForTrip(mode, opts.pivots);
      const failStart = (error) => {
        this._detachPivotTracking();
        return { ok: false, error };
      };
      if (stops.length === 0) {
        return failStart("navigation.start: no stops");
      }
      let origin = this._lastUserPosition;
      if (!origin) {
        try {
          const fix = await this.session.location.getOnce();
          origin = { lat: fix.lat, lng: fix.lng };
          this._lastUserPosition = origin;
        } catch (err) {
          return failStart(`navigation.start: no GPS fix (${err instanceof Error ? err.message : String(err)})`);
        }
      }
      const restResult = await this.computeRoute({ origin, stops, mode, avoid: opts.avoid });
      if (!restResult.ok || !restResult.routes || restResult.routes.length === 0) {
        return failStart(restResult.error ?? "computeRoute failed");
      }
      const restRoute = restResult.routes[0];
      const nativeResult = await this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_START,
        lat: stops[0]?.lat,
        lng: stops[0]?.lng,
        stops,
        mode,
        avoid: opts.avoid,
        simulate: opts.simulate ?? false,
        speedMultiplier: opts.speedMultiplier ?? 1,
        missedTurnRerouteMeters: opts.missedTurnRerouteMeters
      });
      if (!nativeResult.ok) {
        this._detachPivotTracking();
        return nativeResult;
      }
      const syntheticRoute = buildNavRouteFromComputed(restRoute);
      this.session.events._forwardEvent(MiniappStreamType.NAVIGATION_ROUTE, syntheticRoute);
      return nativeResult;
    }
    stop() {
      this._detachPivotTracking();
      this.session.sendOneShot({ type: MiniappRequestType.NAVIGATION_STOP });
    }
    get dev() {
      return {
        deviate: (offsetMeters = 20) => {
          this.session.sendOneShot({ type: MiniappRequestType.NAVIGATION_DEVIATE, offsetMeters });
        },
        setWrongSidewalkOffset: (enabled) => {
          this.session.sendOneShot({ type: MiniappRequestType.NAVIGATION_SET_WRONG_SIDEWALK, enabled });
        },
        setSkipCrossings: (enabled) => {
          this.session.sendOneShot({ type: MiniappRequestType.NAVIGATION_SET_SKIP_CROSSINGS, enabled });
        }
      };
    }
    onUpdate(handler) {
      return this.session._subscribe(MiniappStreamType.NAVIGATION_UPDATE, handler);
    }
    onRoute(handler) {
      return this.session._subscribe(MiniappStreamType.NAVIGATION_ROUTE, handler);
    }
    async getState() {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_GET_STATE
      });
      return result.ok ? result.state ?? null : null;
    }
    computeRoute(opts) {
      if (!this.hasPermission) {
        return Promise.resolve({
          ok: false,
          error: "LOCATION permission not declared in miniapp.json (required for navigation.computeRoute)."
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_COMPUTE_ROUTE,
        origin: opts.origin,
        stops: opts.stops,
        mode: opts.mode ?? "driving",
        avoid: opts.avoid,
        alternatives: opts.alternatives ?? 1
      });
    }
    reverseGeocodeRoad(coord) {
      if (!this.hasPermission) {
        return Promise.resolve({
          ok: false,
          error: "LOCATION permission not declared in miniapp.json (required for reverseGeocodeRoad)."
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_REVERSE_GEOCODE,
        lat: coord.lat,
        lng: coord.lng
      });
    }
    placeAutocomplete(opts) {
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_PLACE_AUTOCOMPLETE,
        query: opts.query,
        near: opts.near ?? null,
        sessionToken: opts.sessionToken
      });
    }
    placeDetails(opts) {
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_PLACE_DETAILS,
        placeId: opts.placeId,
        sessionToken: opts.sessionToken
      });
    }
    onPivot(handler) {
      return this._pivots.subscribe(handler);
    }
    getPivots() {
      return this._pivots.getPivots();
    }
    getActivePivot() {
      return this._pivots.getActivePivot();
    }
    getUpcomingPivot() {
      return this._pivots.getUpcomingPivot();
    }
    _attachPivotTrackingForTrip(mode, opts) {
      this._detachPivotTracking();
      this._pivots.reset();
      this._pivots.updateOptions(mode, opts);
      this._tripUnsubs.push(this.onRoute((route) => {
        if (route.steps && route.steps.length > 0) {
          const tail = route.points[route.points.length - 1];
          const computedSteps = route.steps.map((s, i) => {
            const next = route.steps?.[i + 1];
            const endLat = next ? next.lat : tail?.lat ?? s.lat;
            const endLng = next ? next.lng : tail?.lng ?? s.lng;
            return {
              lat: s.lat,
              lng: s.lng,
              endLat,
              endLng,
              distanceMeters: s.distanceMeters,
              maneuver: s.maneuver,
              road: s.road ?? undefined
            };
          });
          this._pivots.setRouteFromComputedSteps(route, computedSteps);
          return;
        }
        this._pivots.setRoute(route, null);
        const seq = ++this._computeRouteSeq;
        this._issueComputeRouteForTrip(route).then((result) => {
          if (seq !== this._computeRouteSeq)
            return;
          const computedSteps = result?.routes?.[0]?.steps;
          if (computedSteps && computedSteps.length > 0) {
            this._pivots.setRouteFromComputedSteps(route, computedSteps);
          }
        }).catch((err) => {
          console.warn("[NavigationModule] computeRoute for pivots failed:", err);
        });
      }));
      this._tripUnsubs.push(this.onUpdate((update) => {
        if (update.kind === "arrived") {
          this._pivots.reset();
          return;
        }
      }));
      this._tripUnsubs.push(this.session.location.onUpdate((loc) => {
        this._lastUserPosition = { lat: loc.lat, lng: loc.lng };
        this._pivots.onLocationUpdate({ lat: loc.lat, lng: loc.lng });
      }));
    }
    async _issueComputeRouteForTrip(route) {
      if (!this._tripStops || this._tripStops.length === 0)
        return null;
      const origin = this._lastUserPosition ?? (route?.points && route.points[0] ? { lat: route.points[0].lat, lng: route.points[0].lng } : null);
      if (!origin)
        return null;
      return this.computeRoute({
        origin,
        stops: this._tripStops,
        mode: this._tripMode,
        avoid: this._tripAvoid
      });
    }
    _detachPivotTracking() {
      for (const unsub of this._tripUnsubs) {
        try {
          unsub();
        } catch (err) {
          console.warn("[NavigationModule] pivot-tracking unsubscribe threw:", err);
        }
      }
      this._tripUnsubs = [];
      this._pivots.reset();
      this._tripStops = null;
      this._tripAvoid = undefined;
      this._computeRouteSeq++;
      this._lastUserPosition = null;
    }
  }
  function normalizeStops(opts) {
    if (opts.stops && opts.stops.length > 0) {
      return opts.stops;
    }
    if (typeof opts.lat === "number" && typeof opts.lng === "number") {
      return [{ lat: opts.lat, lng: opts.lng }];
    }
    return [];
  }
  function buildNavRouteFromComputed(computed) {
    const points = computed.points ?? [];
    const steps = (computed.steps ?? []).map((s) => {
      let routeIndex = 0;
      let best = Infinity;
      for (let i = 0;i < points.length; i++) {
        const dLat = points[i].lat - s.lat;
        const dLng = points[i].lng - s.lng;
        const d = dLat * dLat + dLng * dLng;
        if (d < best) {
          best = d;
          routeIndex = i;
        }
      }
      return {
        lat: s.lat,
        lng: s.lng,
        routeIndex,
        road: s.road ?? null,
        maneuver: s.maneuver ?? "STRAIGHT",
        distanceMeters: s.distanceMeters
      };
    });
    return {
      points,
      totalDistanceMeters: computed.totalDistanceMeters,
      totalDurationSeconds: computed.totalDurationSeconds,
      steps: steps.length > 0 ? steps : undefined
    };
  }

  // ../vendor/miniapp/dist/modules/permissions.js
  class PermissionsModule {
    constructor(session) {
      this.session = session;
    }
    has(type) {
      return this.session._getPermissions()[type] === true;
    }
    getAll() {
      return this.session._getPermissions();
    }
    onUpdate(handler) {
      return this.session.on("permissions", handler);
    }
    onPermissionError(handler) {
      return this.session.on("error", (e) => {
        const maybe = e;
        if (maybe?.code === MiniappErrorCode.PERMISSION_NOT_DECLARED) {
          handler({
            code: String(maybe.code),
            message: String(maybe.message ?? ""),
            permission: maybe.permission,
            subscription: maybe.subscription,
            operation: maybe.operation
          });
        }
      });
    }
  }

  // ../vendor/miniapp/dist/modules/phone.js
  class TrackedSubs {
    constructor() {
      this.unsubs = new Set;
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
  }

  class PhoneNotificationsModule extends TrackedSubs {
    constructor(session) {
      super();
      this.session = session;
    }
    on(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.PHONE_NOTIFICATION, handler));
    }
    onDismissed(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.PHONE_NOTIFICATION_DISMISSED, handler));
    }
    get hasPermission() {
      return this.session._hasManifestPermission("READ_NOTIFICATIONS");
    }
  }

  class PhoneCalendarModule extends TrackedSubs {
    constructor(session) {
      super();
      this.session = session;
    }
    on(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.CALENDAR_EVENT, handler));
    }
    get hasPermission() {
      return this.session._hasManifestPermission("CALENDAR");
    }
  }

  class PhoneModule {
    constructor(session) {
      this.session = session;
      this.notifications = new PhoneNotificationsModule(session);
      this.calendar = new PhoneCalendarModule(session);
    }
    isWifiEnabled() {
      return this.session.sendRequest({ type: MiniappRequestType.PHONE_IS_WIFI_ENABLED });
    }
    requestWifiEnable(reason) {
      return this.session.sendRequest({ type: MiniappRequestType.PHONE_REQUEST_WIFI_ENABLE, reason }, { timeoutMs: 0 });
    }
    onBattery(handler) {
      return this.session._subscribe(MiniappStreamType.PHONE_BATTERY, handler);
    }
  }

  // ../vendor/miniapp/dist/modules/transcription.js
  class TranscriptionModule {
    constructor(session) {
      this.session = session;
      this.unsubs = new Set;
      this.currentConfig = null;
    }
    on(handler) {
      return this.track(this.session._subscribe(`${MiniappStreamType.TRANSCRIPTION}:auto`, handler));
    }
    forLanguage(language, handler) {
      const langs = Array.isArray(language) ? language : [language];
      if (langs.length === 0)
        return () => {};
      const unsubs = [];
      for (const lang of langs) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TRANSCRIPTION}:${lang}`, handler));
      }
      const combined = () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
      return this.track(combined);
    }
    configure(config) {
      this.currentConfig = { ...config };
      this.session.sendOneShot({
        type: MiniappRequestType.TRANSCRIPTION_CONFIG,
        config: { ...config }
      });
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
    get hasPermission() {
      return this.session._hasManifestPermission("MICROPHONE");
    }
    _getConfig() {
      return this.currentConfig ? { ...this.currentConfig } : null;
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
  }

  // ../vendor/miniapp/dist/modules/translation.js
  class TranslationModule {
    constructor(session) {
      this.session = session;
      this.unsubs = new Set;
    }
    on(handler) {
      return this.track(this.session._subscribe(`${MiniappStreamType.TRANSLATION}:*:*`, handler));
    }
    to(target, handler) {
      const targets = Array.isArray(target) ? target : [target];
      if (targets.length === 0)
        return () => {};
      const unsubs = [];
      for (const t of targets) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TRANSLATION}:*:${t}`, handler));
      }
      const composite = () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
      return this.track(composite);
    }
    fromTo(source, target, handler) {
      const targets = Array.isArray(target) ? target : [target];
      if (targets.length === 0)
        return () => {};
      const unsubs = [];
      for (const t of targets) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TRANSLATION}:${source}:${t}`, handler));
      }
      const composite = () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
      return this.track(composite);
    }
    forLanguagePair(fromLang, toLang, handler) {
      return this.fromTo(fromLang, toLang, handler);
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
    get hasPermission() {
      return this.session._hasManifestPermission("MICROPHONE");
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
  }

  // ../vendor/miniapp/dist/modules/ui.js
  function rpcErrorFromUnknown(e) {
    if (e instanceof Error) {
      const own = e;
      const cause = own.cause;
      return compactEnvelope({
        message: e.message,
        code: own.code ?? cause?.code,
        stage: own.stage,
        transport: own.transport
      });
    }
    if (e && typeof e === "object") {
      const o = e;
      return compactEnvelope({
        message: typeof o.message === "string" ? o.message : JSON.stringify(e),
        code: typeof o.code === "string" ? o.code : undefined,
        stage: typeof o.stage === "string" ? o.stage : undefined,
        transport: typeof o.transport === "string" ? o.transport : undefined
      });
    }
    return { message: String(e) };
  }
  function compactEnvelope(env) {
    const out = { message: env.message };
    if (env.code)
      out.code = env.code;
    if (env.stage)
      out.stage = env.stage;
    if (env.transport)
      out.transport = env.transport;
    return out;
  }

  class UIModuleImpl {
    constructor(session) {
      this.session = session;
      this.bound = false;
      this.nextSeq = 1;
      this.openHandlers = new Set;
      this.closeHandlers = new Set;
      this.channelHandlers = new Map;
      this.rpcHandlers = new Map;
      this.inflightRpc = new Map;
      this.isOpen = () => {
        return this.bound;
      };
      this.onOpen = (cb) => {
        this.openHandlers.add(cb);
        if (this.bound) {
          if (this.session.ready) {
            try {
              cb();
            } catch (e) {
              console.warn("session.ui.onOpen late-fire threw:", e);
            }
          }
        }
        return () => {
          this.openHandlers.delete(cb);
        };
      };
      this.onClose = (cb) => {
        this.closeHandlers.add(cb);
        return () => {
          this.closeHandlers.delete(cb);
        };
      };
      this.send = (channel, payload) => {
        if (!this.bound) {
          return;
        }
        const seq = this.nextSeq++;
        const envelope = { type: "UI_SEND", channel, payload, seq };
        this.session.sendOneShot(envelope);
      };
      this.on = (channel, cb) => {
        let set = this.channelHandlers.get(channel);
        if (!set) {
          set = new Set;
          this.channelHandlers.set(channel, set);
        }
        set.add(cb);
        return () => {
          set.delete(cb);
        };
      };
      this.handle = (channel, handler) => {
        const key = channel;
        if (this.rpcHandlers.has(key)) {
          throw new Error(`session.ui.handle: a handler is already registered for "${key}"`);
        }
        this.rpcHandlers.set(key, handler);
        return () => {
          this.rpcHandlers.delete(key);
        };
      };
      this.session._subscribe("_ui", (env) => this.handleInbound(env));
    }
    fireOpenHandlers() {
      for (const h of this.openHandlers) {
        try {
          h();
        } catch (e) {
          console.warn("session.ui.onOpen handler threw", e);
        }
      }
    }
    handleInbound(env) {
      if (env.type === "UI_OPEN") {
        this.bound = true;
        this.nextSeq = 1;
        if (this.session.ready) {
          this.fireOpenHandlers();
        } else {
          const off = this.session.on("ready", () => {
            off();
            if (this.bound)
              this.fireOpenHandlers();
          });
        }
        return;
      }
      if (env.type === "UI_CLOSE") {
        this.bound = false;
        for (const h of this.closeHandlers) {
          try {
            h();
          } catch (e) {
            console.warn("session.ui.onClose handler threw", e);
          }
        }
        return;
      }
      if (env.type === "UI_MESSAGE") {
        if (typeof env.requestId === "string") {
          this.dispatchRpcCall(env.channel, env.payload, env.requestId);
          return;
        }
        const set = this.channelHandlers.get(env.channel);
        if (!set || set.size === 0)
          return;
        for (const h of set) {
          try {
            h(env.payload);
          } catch (e) {
            console.warn(`session.ui.on(${env.channel}) threw`, e);
          }
        }
        return;
      }
      if (env.type === "UI_CANCEL") {
        const ctrl = this.inflightRpc.get(env.requestId);
        if (ctrl) {
          try {
            ctrl.abort();
          } catch {}
        }
        return;
      }
    }
    dispatchRpcCall(channel, payload, requestId) {
      const handler = this.rpcHandlers.get(channel);
      if (!handler) {
        this.sendRpcReply(channel, requestId, {
          ok: false,
          error: { message: `no handler registered for "${channel}"` }
        });
        return;
      }
      const ctrl = new AbortController;
      this.inflightRpc.set(requestId, ctrl);
      const ctx = { signal: ctrl.signal };
      const finish = (envelope) => {
        this.inflightRpc.delete(requestId);
        if (ctrl.signal.aborted)
          return;
        this.sendRpcReply(channel, requestId, envelope);
      };
      let result;
      try {
        result = handler(payload, ctx);
      } catch (e) {
        finish({ ok: false, error: rpcErrorFromUnknown(e) });
        return;
      }
      if (result && typeof result.then === "function") {
        result.then((v) => finish({ ok: true, result: v }), (e) => finish({ ok: false, error: rpcErrorFromUnknown(e) }));
      } else {
        finish({ ok: true, result });
      }
    }
    sendRpcReply(channel, requestId, payload) {
      if (!this.bound)
        return;
      const seq = this.nextSeq++;
      const envelope = { type: "UI_SEND", channel, payload, seq, requestId };
      this.session.sendOneShot(envelope);
    }
  }

  // ../vendor/miniapp/dist/modules/storage.js
  class SimpleStorage {
    constructor(session) {
      this.session = session;
    }
    async get(key) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_GET,
        key
      });
      return result?.value ?? null;
    }
    async set(key, value) {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_SET,
        key,
        value
      });
    }
    async delete(key) {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_DELETE,
        key
      });
    }
    async keys() {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_LIST
      });
      return result?.keys ?? [];
    }
    async list() {
      return this.keys();
    }
    async clear() {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_CLEAR
      });
    }
    async has(key) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_HAS,
        key
      });
      return !!result?.has;
    }
    async getAll() {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_GET_ALL
      });
      return result?.values ?? {};
    }
    async setMultiple(values) {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_SET_MULTIPLE,
        values
      });
    }
    async flush() {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_FLUSH
      });
    }
  }

  // ../vendor/miniapp/dist/modules/speaker.js
  class SpeakerModule {
    constructor(session) {
      this.session = session;
      this._state = "idle";
      this._lastEvent = { state: "idle" };
    }
    get state() {
      return this._state;
    }
    get isPlaying() {
      return this._state === "playing";
    }
    async play(options) {
      await this.session.sendRequest({
        type: MiniappRequestType.PLAY_AUDIO,
        audioUrl: options.audioUrl,
        volume: options.volume,
        stopOtherAudio: options.stopOtherAudio ?? false
      }, { timeoutMs: 0 });
    }
    async speak(text, options = {}) {
      try {
        const result = await this.session.sendRequest({
          type: MiniappRequestType.SPEAK,
          text,
          voice_id: options.voice_id,
          voice_settings: options.voice_settings,
          volume: options.volume,
          stopOtherAudio: options.stopOtherAudio ?? false
        }, { timeoutMs: 0 });
        return result ?? { completed: true };
      } catch (err) {
        if (err && typeof err === "object" && "code" in err) {
          throw err;
        }
        throw { code: MiniappErrorCode.INTERNAL, message: String(err) };
      }
    }
    stop() {
      this.session.sendOneShot({ type: MiniappRequestType.STOP_AUDIO });
    }
    onStateChange(handler) {
      return this.session.on("speakerState", handler);
    }
    _applyState(event) {
      if (event.state === this._state && event.state !== "error")
        return;
      this._state = event.state;
      this._lastEvent = event;
    }
    _getLastEvent() {
      return { ...this._lastEvent };
    }
  }

  // ../vendor/miniapp/dist/modules/stream.js
  class StreamModule {
    constructor(session) {
      this.session = session;
    }
    async startStream(options = {}) {
      if (options.direct !== undefined) {
        return this.session.sendRequest({
          type: MiniappRequestType.STREAM_START,
          streamUrl: options.direct,
          video: options.video,
          audio: options.audio,
          sound: options.sound ?? true,
          ...options.authToken ? { authToken: options.authToken } : {}
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.MANAGED_STREAM_START,
        restreamDestinations: options.destinations,
        video: options.video,
        audio: options.audio,
        sound: options.sound ?? true,
        ingest: options.ingest
      });
    }
    async stop(streamId) {
      await this.session.sendRequest({
        type: MiniappRequestType.STREAM_STOP,
        streamId
      });
    }
  }

  // ../vendor/miniapp/dist/modules/system.js
  class SystemModule {
    constructor(session) {
      this.session = session;
    }
    async share(options) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.SHARE,
        ...options
      });
      return result ?? { success: false };
    }
    openUrl(url) {
      this.session.sendOneShot({
        type: MiniappRequestType.OPEN_URL,
        url
      });
    }
    async copyToClipboard(text) {
      await this.session.sendRequest({
        type: MiniappRequestType.COPY_CLIPBOARD,
        text
      });
    }
    async download(options) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.DOWNLOAD,
        ...options
      });
      return result ?? { success: false };
    }
  }

  // ../vendor/miniapp/dist/modules/miniapps.js
  class MiniappsModule {
    constructor(session) {
      this.session = session;
    }
    async list(opts) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.MINIAPPS_LIST,
        includeIncompatible: opts?.includeIncompatible ?? false
      });
      return result ?? [];
    }
    async start(packageName) {
      await this.session.sendRequest({
        type: MiniappRequestType.MINIAPPS_START,
        packageName
      });
    }
    async stop(packageName) {
      await this.session.sendRequest({
        type: MiniappRequestType.MINIAPPS_STOP,
        packageName
      });
    }
  }

  // ../vendor/miniapp/dist/modules/actions.js
  var HANDLER_WAIT_MS = 5000;

  class ActionsModule {
    constructor(session) {
      this.session = session;
      this.handlers = new Map;
      this.buffered = new Map;
    }
    invoke(packageName, actionId, params, opts) {
      return this.session.sendRequest({
        type: MiniappRequestType.ACTION_INVOKE,
        targetPackageName: packageName,
        actionId,
        params: params ?? {},
        ...opts?.timeoutMs != null ? { timeoutMs: opts.timeoutMs } : {}
      });
    }
    handle(actionId, handler) {
      if (this.handlers.has(actionId)) {
        throw new Error(`session.actions.handle: a handler is already registered for "${actionId}"`);
      }
      this.handlers.set(actionId, handler);
      const waiting = this.buffered.get(actionId);
      if (waiting) {
        this.buffered.delete(actionId);
        for (const call of waiting) {
          clearTimeout(call.timer);
          this.dispatch(call.callId, actionId, call.params, call.ctx);
        }
      }
      return () => {
        if (this.handlers.get(actionId) === handler)
          this.handlers.delete(actionId);
      };
    }
    _deliver(callId, actionId, params, ctx) {
      if (this.handlers.has(actionId)) {
        this.dispatch(callId, actionId, params, ctx);
        return;
      }
      const timer = setTimeout(() => {
        const arr2 = this.buffered.get(actionId);
        if (arr2) {
          const idx = arr2.findIndex((c) => c.callId === callId);
          if (idx >= 0)
            arr2.splice(idx, 1);
          if (arr2.length === 0)
            this.buffered.delete(actionId);
        }
        this.sendResult(callId, false, undefined, {
          code: MiniappErrorCode.NO_ACTION_HANDLER,
          message: `No handler registered for action "${actionId}"`
        });
      }, HANDLER_WAIT_MS);
      const arr = this.buffered.get(actionId) ?? [];
      arr.push({ callId, params, ctx, timer });
      this.buffered.set(actionId, arr);
    }
    async dispatch(callId, actionId, params, ctx) {
      const handler = this.handlers.get(actionId);
      if (!handler)
        return;
      try {
        const result = await handler(params, ctx);
        this.sendResult(callId, true, result ?? null);
      } catch (e) {
        this.sendResult(callId, false, undefined, {
          code: MiniappErrorCode.INTERNAL,
          message: e?.message ?? "action handler threw"
        });
      }
    }
    sendResult(callId, ok, result, error) {
      this.session.sendOneShot({
        type: MiniappRequestType.ACTION_RESULT,
        callId,
        ok,
        ...ok ? { result } : { error }
      });
    }
  }

  // ../vendor/miniapp/dist/modules/base64.js
  var ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  var LOOKUP = (() => {
    const t = new Int16Array(256).fill(-1);
    for (let i = 0;i < ALPHABET.length; i++)
      t[ALPHABET.charCodeAt(i)] = i;
    t[61] = 0;
    return t;
  })();
  function toUint8Array(input) {
    if (input instanceof Uint8Array)
      return input;
    if (input instanceof ArrayBuffer)
      return new Uint8Array(input);
    return new Uint8Array(input.buffer, input.byteOffset, input.byteLength);
  }
  function bytesToBase64(input) {
    const bytes = input instanceof Uint8Array ? input : new Uint8Array(input);
    const len = bytes.length;
    let out = "";
    let i = 0;
    for (;i + 2 < len; i += 3) {
      const n = bytes[i] << 16 | bytes[i + 1] << 8 | bytes[i + 2];
      out += ALPHABET[n >> 18 & 63] + ALPHABET[n >> 12 & 63] + ALPHABET[n >> 6 & 63] + ALPHABET[n & 63];
    }
    const rem = len - i;
    if (rem === 1) {
      const n = bytes[i] << 16;
      out += ALPHABET[n >> 18 & 63] + ALPHABET[n >> 12 & 63] + "==";
    } else if (rem === 2) {
      const n = bytes[i] << 16 | bytes[i + 1] << 8;
      out += ALPHABET[n >> 18 & 63] + ALPHABET[n >> 12 & 63] + ALPHABET[n >> 6 & 63] + "=";
    }
    return out;
  }
  function base64ToBytes(b64) {
    let validChars = 0;
    let pad = 0;
    for (let i = 0;i < b64.length; i++) {
      const c = b64.charCodeAt(i);
      if (c === 61) {
        pad++;
        validChars++;
      } else if (LOOKUP[c] !== -1) {
        validChars++;
      }
    }
    const fullGroups = Math.floor(validChars / 4);
    const remChars = validChars - fullGroups * 4;
    let outLen = fullGroups * 3 - (pad > 0 && remChars === 0 ? pad : 0);
    if (remChars === 2)
      outLen += 1;
    else if (remChars === 3)
      outLen += 2;
    if (outLen < 0)
      outLen = 0;
    const out = new Uint8Array(outLen);
    let acc = 0;
    let bits = 0;
    let o = 0;
    for (let i = 0;i < b64.length && o < outLen; i++) {
      const c = b64.charCodeAt(i);
      if (c === 61)
        break;
      const v = LOOKUP[c];
      if (v === -1)
        continue;
      acc = acc << 6 | v;
      bits += 6;
      if (bits >= 8) {
        bits -= 8;
        out[o++] = acc >> bits & 255;
      }
    }
    return out;
  }

  // ../vendor/miniapp/dist/modules/blob.js
  var BLOB_WRITE_CHUNK_BYTES = 1024 * 1024;
  var BLOB_WRITE_CHUNK_B64 = Math.floor(BLOB_WRITE_CHUNK_BYTES / 3) * 4;
  var BLOB_READ_ALL_MAX_BYTES = 32 * 1024 * 1024;

  class BlobWriter {
    constructor(session, key) {
      this.session = session;
      this.key = key;
      this.settled = false;
    }
    async write(chunk) {
      this.assertOpen();
      const bytes = toUint8Array(chunk);
      for (let off = 0;off < bytes.length; off += BLOB_WRITE_CHUNK_BYTES) {
        await this.send(bytesToBase64(bytes.subarray(off, off + BLOB_WRITE_CHUNK_BYTES)));
      }
    }
    async writeBase64(b64) {
      this.assertOpen();
      for (let off = 0;off < b64.length; off += BLOB_WRITE_CHUNK_B64) {
        await this.send(b64.slice(off, off + BLOB_WRITE_CHUNK_B64));
      }
    }
    async writeAt(offset, chunk) {
      this.assertOpen();
      await this.session.sendRequest({
        type: MiniappRequestType.BLOB_WRITE,
        key: this.key,
        offset,
        base64: bytesToBase64(toUint8Array(chunk))
      });
    }
    async close(meta) {
      this.assertOpen();
      this.settled = true;
      return this.session.sendRequest({ type: MiniappRequestType.BLOB_COMMIT, key: this.key, meta });
    }
    async abort() {
      if (this.settled)
        return;
      this.settled = true;
      await this.session.sendRequest({ type: MiniappRequestType.BLOB_ABORT, key: this.key });
    }
    assertOpen() {
      if (this.settled)
        throw new Error("BlobWriter is already closed/aborted");
    }
    send(base64) {
      return this.session.sendRequest({
        type: MiniappRequestType.BLOB_WRITE,
        key: this.key,
        base64
      });
    }
  }

  class BlobReader {
    constructor(session, handle, meta) {
      this.session = session;
      this.handle = handle;
      this.meta = meta;
      this.closed = false;
    }
    async read(maxBytes = BLOB_WRITE_CHUNK_BYTES) {
      if (this.closed)
        throw new Error("BlobReader is closed");
      const res = await this.session.sendRequest({
        type: MiniappRequestType.BLOB_READ,
        handle: this.handle,
        maxBytes
      });
      return { bytes: base64ToBytes(res?.base64 ?? ""), done: !!res?.done };
    }
    async close() {
      if (this.closed)
        return;
      this.closed = true;
      await this.session.sendRequest({ type: MiniappRequestType.BLOB_CLOSE_READ, handle: this.handle });
    }
  }

  class BlobModule {
    constructor(session) {
      this.session = session;
    }
    async set(key, data, opts = {}) {
      const writer = await this.createWriteStream(key, opts);
      try {
        if (typeof data === "string")
          await writer.writeBase64(data);
        else
          await writer.write(data);
        return await writer.close();
      } catch (err) {
        await writer.abort().catch(() => {});
        throw err;
      }
    }
    setFromUrl(key, url, opts = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.BLOB_SET_FROM_URL,
        key,
        url,
        mimeType: opts.mimeType,
        name: opts.name,
        headers: opts.headers,
        meta: opts.meta
      });
    }
    importFile(opts = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.BLOB_IMPORT,
        key: opts.key,
        mimeType: opts.mimeType,
        meta: opts.meta
      });
    }
    async createWriteStream(key, opts = {}) {
      const res = await this.session.sendRequest({
        type: MiniappRequestType.BLOB_CREATE,
        key,
        mimeType: opts.mimeType,
        name: opts.name,
        meta: opts.meta
      });
      return new BlobWriter(this.session, res.key);
    }
    get(key) {
      return this.session.sendRequest({ type: MiniappRequestType.BLOB_GET, key });
    }
    stat(key) {
      return this.get(key);
    }
    async has(key) {
      return await this.get(key) !== null;
    }
    async keys() {
      return (await this.list()).map((m) => m.key);
    }
    async list() {
      const res = await this.session.sendRequest({ type: MiniappRequestType.BLOB_LIST });
      return res?.blobs ?? [];
    }
    async createReadStream(key) {
      const res = await this.session.sendRequest({
        type: MiniappRequestType.BLOB_OPEN_READ,
        key
      });
      return new BlobReader(this.session, res.handle, res.meta);
    }
    async bytes(key) {
      let reader;
      try {
        reader = await this.createReadStream(key);
      } catch {
        return null;
      }
      const parts = [];
      let total = 0;
      try {
        for (;; ) {
          const { bytes, done } = await reader.read();
          if (bytes.length) {
            total += bytes.length;
            if (total > BLOB_READ_ALL_MAX_BYTES) {
              throw new Error(`Blob "${key}" exceeds the in-memory read cap — stream it with createReadStream()`);
            }
            parts.push(bytes);
          }
          if (done)
            break;
        }
      } finally {
        await reader.close().catch(() => {});
      }
      const out = new Uint8Array(total);
      let at = 0;
      for (const p of parts) {
        out.set(p, at);
        at += p.length;
      }
      return out;
    }
    usage() {
      return this.session.sendRequest({
        type: MiniappRequestType.BLOB_USAGE
      });
    }
    async delete(key) {
      await this.session.sendRequest({ type: MiniappRequestType.BLOB_DELETE, key });
    }
    async clear() {
      await this.session.sendRequest({ type: MiniappRequestType.BLOB_CLEAR });
    }
    async share(key) {
      const res = await this.session.sendRequest({
        type: MiniappRequestType.BLOB_SHARE,
        key
      });
      return res ?? { success: false };
    }
  }

  // ../vendor/miniapp/dist/session.js
  var ALL_PERMISSION_TYPES = [
    "location",
    "microphone",
    "camera",
    "notifications",
    "calendar"
  ];

  class NotConnectedError extends Error {
    constructor(message = "MiniappSession is not connected") {
      super(message);
      this.code = MiniappErrorCode.NOT_CONNECTED;
      this.name = "NotConnectedError";
    }
  }
  var DEFAULT_CONNECT_TIMEOUT_MS = 1e4;
  var DEFAULT_REQUEST_TIMEOUT_MS = 60000;

  class MiniappSession {
    constructor(options = {}) {
      this.capabilities = null;
      this.userId = "";
      this.packageName = "";
      this.visibility = "foreground";
      this.colorScheme = "light";
      this.ready = false;
      this.emitter = new import__.default;
      this.authState = null;
      this.authWaiters = new Set;
      this.authRefreshPromise = null;
      this.outboundQueue = [];
      this.pendingRequests = new Map;
      this.connectPromise = null;
      this.disposed = false;
      this._permissions = {
        location: false,
        microphone: false,
        camera: false,
        notifications: false,
        calendar: false
      };
      this.transport = createTransport(options);
      this.connectTimeoutMs = options.connectTimeoutMs ?? DEFAULT_CONNECT_TIMEOUT_MS;
      const injected = getMentraOSGlobals();
      this.packageName = options.packageName ?? injected.packageName ?? "";
      if (injected.colorScheme === "light" || injected.colorScheme === "dark") {
        this.colorScheme = injected.colorScheme;
      }
      this.auth = new AuthModule(this);
      this.events = new EventManager(this);
      this.speaker = new SpeakerModule(this);
      this.camera = new CameraModule(this);
      this.canvas = new CanvasManager(this);
      this.cloud = new CloudModule(this);
      this.dashboard = new DashboardAPI(this);
      this.display = new DisplayManager(this);
      this.glasses = new GlassesModule(this);
      this.heading = new HeadingModule(this);
      this.imu = new ImuModule(this);
      this.input = new InputModule(this);
      this.led = new LedModule(this);
      this.location = new LocationModule(this);
      this.mic = new MicModule(this);
      this.navigation = new NavigationModule(this);
      this.permissions = new PermissionsModule(this);
      this.phone = new PhoneModule(this);
      this.storage = new SimpleStorage(this);
      this.blob = new BlobModule(this);
      this.stream = new StreamModule(this);
      this.system = new SystemModule(this);
      this.transcription = new TranscriptionModule(this);
      this.translation = new TranslationModule(this);
      this.ui = new UIModuleImpl(this);
      this.miniapps = new MiniappsModule(this);
      this.actions = new ActionsModule(this);
    }
    _hasManifestPermission(manifestKey) {
      const canonical = manifestKeyToCanonical(manifestKey);
      if (!canonical)
        return false;
      return this._permissions[canonical] === true;
    }
    _getPermissions() {
      return { ...this._permissions };
    }
    _getAuth() {
      return this.authState ? { ...this.authState } : null;
    }
    _waitForAuth(minTtlMs, timeoutMs = 1e4) {
      const current = this.authState;
      if (current && this.authHasTtl(current, minTtlMs)) {
        return Promise.resolve({ ...current });
      }
      this.requestAuthRefresh(minTtlMs);
      return new Promise((resolve, reject) => {
        const waiter = {
          minTtlMs,
          resolve,
          reject,
          timer: setTimeout(() => {
            this.authWaiters.delete(waiter);
            reject(new NotConnectedError("Miniapp auth token is not available"));
          }, timeoutMs)
        };
        this.authWaiters.add(waiter);
      });
    }
    _subscribe(streamType, handler) {
      return this.events.subscribe(streamType, handler);
    }
    connect() {
      if (this.disposed) {
        return Promise.reject(new NotConnectedError("MiniappSession was disposed"));
      }
      if (this.connectPromise)
        return this.connectPromise;
      const readyPromise = new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
          const err = new Error("MiniappSession: CONNECT_ACK timeout");
          this.failAllPending({ code: MiniappErrorCode.NOT_CONNECTED, message: err.message });
          this.emitter.emit("error", err);
          reject(err);
        }, this.connectTimeoutMs);
        this.emitter.once("ready", () => {
          clearTimeout(timer);
          resolve();
        });
        this.emitter.once("error", (err) => {
          clearTimeout(timer);
          reject(err);
        });
      });
      this.connectPromise = (async () => {
        this.transport.onMessage((raw) => this.handleIncoming(raw));
        this.transport.onDisconnect((reason) => this.handleTransportDisconnect(reason));
        await this.transport.open();
        const requestId = makeRequestId();
        const connectPayload = {
          type: MiniappRequestType.CONNECT,
          packageName: this.packageName
        };
        this.transport.send(serializeEnvelope({ payload: connectPayload, requestId }));
        await readyPromise;
      })();
      return this.connectPromise;
    }
    waitForReady() {
      if (this.ready)
        return Promise.resolve();
      return this.connect();
    }
    isConnected() {
      return this.ready && this.transport.isOpen();
    }
    disconnect() {
      if (this.disposed)
        return;
      this.disposed = true;
      try {
        this.emitter.emit("beforeDisconnect", "disconnect called");
      } catch (err) {
        console.warn("[MiniappSession] beforeDisconnect handler threw:", err);
      }
      this.failAllPending({ code: MiniappErrorCode.REQUEST_ABORTED, message: "Session disconnected" });
      try {
        this.transport.close();
      } catch {}
      this.ready = false;
      this.emitter.emit("disconnect", "disconnect called");
    }
    sendOneShot(payload) {
      const envelope = { payload };
      this.enqueueOrSend(serializeEnvelope(envelope));
    }
    sendRequest(payload, opts) {
      if (this.disposed) {
        return Promise.reject(new NotConnectedError);
      }
      const requestId = makeRequestId();
      const envelope = { payload, requestId };
      const timeoutMs = opts?.timeoutMs ?? DEFAULT_REQUEST_TIMEOUT_MS;
      return new Promise((resolve, reject) => {
        const timer = timeoutMs > 0 ? setTimeout(() => {
          const pending = this.pendingRequests.get(requestId);
          if (!pending)
            return;
          this.pendingRequests.delete(requestId);
          pending.reject({
            code: MiniappErrorCode.ACTION_TIMEOUT,
            message: "Request timed out waiting for a response from the host"
          });
        }, timeoutMs) : undefined;
        this.pendingRequests.set(requestId, {
          requestId,
          resolve,
          reject,
          timer
        });
        this.enqueueOrSend(serializeEnvelope(envelope));
      });
    }
    on(event, handler) {
      this.emitter.on(event, handler);
      return () => this.emitter.off(event, handler);
    }
    off(event, handler) {
      this.emitter.off(event, handler);
    }
    onBeforeDisconnect(handler) {
      return this.on("beforeDisconnect", handler);
    }
    onVisibilityChange(handler) {
      return this.on("visibility", handler);
    }
    onCapabilitiesChange(handler) {
      return this.on("capabilities", handler);
    }
    onColorSchemeChange(handler) {
      return this.on("colorScheme", handler);
    }
    enqueueOrSend(raw) {
      if (this.ready) {
        try {
          this.transport.send(raw);
        } catch (err) {
          this.emitter.emit("error", err);
        }
        return;
      }
      this.outboundQueue.push(raw);
    }
    flushQueue() {
      const queue = this.outboundQueue.splice(0);
      for (const raw of queue) {
        try {
          this.transport.send(raw);
        } catch (err) {
          this.emitter.emit("error", err);
        }
      }
    }
    handleIncoming(raw) {
      const envelope = parseEnvelope(raw);
      if (!envelope)
        return;
      const payload = envelope.payload;
      const type = payload?.type;
      switch (type) {
        case MiniappResponseType.CONNECT_ACK: {
          const ack = payload;
          this.userId = ack.userId ?? "";
          if (ack.packageName)
            this.packageName = ack.packageName;
          this.capabilities = ack.capabilities ?? null;
          if (ack.visibility)
            this.visibility = ack.visibility;
          if (ack.colorScheme === "light" || ack.colorScheme === "dark") {
            this.colorScheme = ack.colorScheme;
          }
          if (ack.auth) {
            this.applyAuth(ack.auth);
            if (!this.userId)
              this.userId = ack.auth.mentraUserId;
          }
          if (ack.permissions)
            this.applyPermissions(ack.permissions);
          this.ready = true;
          this.flushQueue();
          this.emitter.emit("ready");
          return;
        }
        case MiniappResponseType.AUTH_UPDATE: {
          const next = payload.auth;
          if (next) {
            this.applyAuth(next);
            if (!this.userId)
              this.userId = next.mentraUserId;
          }
          return;
        }
        case MiniappResponseType.PERMISSIONS_UPDATE: {
          const next = payload.permissions;
          if (next)
            this.applyPermissions(next);
          return;
        }
        case MiniappResponseType.SPEAKER_STATE: {
          const state = payload.state;
          if (!state)
            return;
          const event = {
            state,
            errorCode: payload.errorCode,
            errorMessage: payload.errorMessage,
            durationMs: payload.durationMs
          };
          this.speaker._applyState(event);
          this.emitter.emit("speakerState", event);
          return;
        }
        case MiniappRequestType.PING: {
          const pong = { type: MiniappResponseType.PONG };
          const env = {
            payload: pong,
            ...envelope.requestId ? { requestId: envelope.requestId } : {}
          };
          try {
            this.transport.send(serializeEnvelope(env));
          } catch {}
          return;
        }
        case MiniappResponseType.EVENT: {
          const streamType = payload.streamType;
          if (!streamType)
            return;
          this.events._forwardEvent(streamType, payload.data);
          return;
        }
        case MiniappResponseType.ACTION_CALL: {
          const callId = payload.callId;
          const actionId = payload.actionId;
          if (!callId || !actionId)
            return;
          const params = payload.params ?? {};
          const callerPackageName = payload.callerPackageName ?? "";
          this.actions._deliver(callId, actionId, params, { callerPackageName });
          return;
        }
        case MiniappResponseType.CAPABILITIES_UPDATE: {
          const cap = payload.capabilities ?? null;
          this.capabilities = cap;
          this.emitter.emit("capabilities", cap);
          return;
        }
        case MiniappResponseType.VISIBILITY_CHANGE: {
          const next = payload.visibility;
          if (next === "foreground" || next === "background") {
            this.visibility = next;
            this.emitter.emit("visibility", next);
          }
          return;
        }
        case MiniappResponseType.COLOR_SCHEME_CHANGE: {
          const next = payload.colorScheme;
          if (next === "light" || next === "dark") {
            this.colorScheme = next;
            this.emitter.emit("colorScheme", next);
          }
          return;
        }
        case MiniappResponseType.REQUEST_RESULT: {
          const requestId = envelope.requestId;
          if (!requestId)
            return;
          const pending = this.pendingRequests.get(requestId);
          if (!pending)
            return;
          this.pendingRequests.delete(requestId);
          if (pending.timer)
            clearTimeout(pending.timer);
          if (payload.ok === false) {
            const err = payload.error ?? {
              code: MiniappErrorCode.INTERNAL,
              message: "Unknown error"
            };
            pending.reject(err);
          } else {
            pending.resolve(payload.data ?? null);
          }
          return;
        }
        case MiniappResponseType.WILL_DISCONNECT: {
          const reason = payload.reason ?? "phone unregistering";
          try {
            this.emitter.emit("beforeDisconnect", reason);
          } catch (err) {
            console.warn("[MiniappSession] beforeDisconnect handler threw:", err);
          }
          return;
        }
        case MiniappResponseType.ERROR: {
          const err = new Error(payload.message ?? "MiniappSession error");
          this.emitter.emit("error", err);
          return;
        }
        default:
          return;
      }
    }
    handleTransportDisconnect(reason) {
      this.ready = false;
      this.failAllPending({ code: MiniappErrorCode.NOT_CONNECTED, message: `Transport disconnected: ${reason}` });
      this.emitter.emit("disconnect", reason);
    }
    failAllPending(error) {
      for (const pending of this.pendingRequests.values()) {
        if (pending.timer)
          clearTimeout(pending.timer);
        pending.reject(error);
      }
      this.pendingRequests.clear();
      for (const waiter of Array.from(this.authWaiters)) {
        clearTimeout(waiter.timer);
        this.authWaiters.delete(waiter);
        waiter.reject(new NotConnectedError(error.message));
      }
    }
    authHasTtl(auth, minTtlMs) {
      return auth.expiresAt - Date.now() > minTtlMs;
    }
    requestAuthRefresh(minTtlMs) {
      if (this.authRefreshPromise)
        return this.authRefreshPromise;
      if (!this.ready || !this.transport.isOpen())
        return Promise.resolve(null);
      this.authRefreshPromise = this.sendRequest({
        type: MiniappRequestType.AUTH_REFRESH,
        minTtlMs
      }).then((result) => {
        const auth = result?.auth;
        if (auth)
          this.applyAuth(auth);
        return auth ?? null;
      }).catch((err) => {
        console.warn("[MiniappSession] auth refresh failed:", err);
        return null;
      }).finally(() => {
        this.authRefreshPromise = null;
      });
      return this.authRefreshPromise;
    }
    applyAuth(next) {
      this.authState = { ...next };
      for (const waiter of Array.from(this.authWaiters)) {
        if (!this.authHasTtl(next, waiter.minTtlMs))
          continue;
        clearTimeout(waiter.timer);
        this.authWaiters.delete(waiter);
        waiter.resolve({ ...next });
      }
      this.emitter.emit("auth", { ...next });
    }
    applyPermissions(next) {
      let changed = false;
      const updated = { ...this._permissions };
      for (const k of ALL_PERMISSION_TYPES) {
        const v = next[k] === true;
        if (updated[k] !== v) {
          updated[k] = v;
          changed = true;
        }
      }
      if (changed) {
        this._permissions = updated;
        this.emitter.emit("permissions", { ...updated });
      }
    }
  }
  function manifestKeyToCanonical(manifestKey) {
    switch (manifestKey.toUpperCase()) {
      case "MICROPHONE":
        return "microphone";
      case "CAMERA":
        return "camera";
      case "LOCATION":
      case "BACKGROUND_LOCATION":
        return "location";
      case "READ_NOTIFICATIONS":
      case "POST_NOTIFICATIONS":
        return "notifications";
      case "CALENDAR":
        return "calendar";
      default:
        return null;
    }
  }

  // ../vendor/miniapp/dist/background/register.js
  function registerMiniapp(handler, options = {}) {
    const g = globalThis;
    g.__mentraInitCallback = (_sessionId) => {
      const session = new MiniappSession(options);
      try {
        const result = handler(session);
        if (result && typeof result.then === "function") {
          result.catch((err) => {
            console.error("[mentra-miniapp] registerMiniapp handler rejected:", err);
          });
        }
      } catch (err) {
        console.error("[mentra-miniapp] registerMiniapp handler threw:", err);
      }
      session.connect().catch((err) => {
        console.error("[mentra-miniapp] session.connect() rejected:", err);
        try {
          const message = err instanceof Error ? err.message : String(err);
          const stack = err instanceof Error && err.stack ? err.stack : "";
          g.__hostError?.(JSON.stringify({ message: `session.connect() failed: ${message}`, stack }));
        } catch {}
      });
    };
  }
  // src/shared/errors.ts
  function errorMessage(error, fallback = "Unknown error") {
    if (error instanceof Error && error.message)
      return error.message;
    if (error && typeof error === "object") {
      const message = error.message;
      if (typeof message === "string" && message)
        return message;
      try {
        return JSON.stringify(error);
      } catch {
        return fallback;
      }
    }
    if (typeof error === "string" && error)
      return error;
    return fallback;
  }

  // src/shared/types.ts
  var STREAM_WIDTH_MIN = 320;
  var STREAM_WIDTH_MAX = 1920;
  var STREAM_HEIGHT_MIN = 240;
  var STREAM_HEIGHT_MAX = 1080;
  var VIDEO_RESOLUTION_OPTIONS = [
    { id: "360p", label: "360p", width: 640, height: 360 },
    { id: "480p", label: "480p", width: 854, height: 480 },
    { id: "720p", label: "720p", width: 1280, height: 720 },
    { id: "1080p", label: "1080p", width: 1920, height: 1080 },
    { id: "custom", label: "Custom" }
  ];
  var VIDEO_FPS_OPTIONS = [5, 10, 15, 20, 24, 30];
  var VIDEO_BITRATE_OPTIONS = [
    500000,
    750000,
    1e6,
    1500000,
    2000000,
    2500000,
    3500000,
    5000000,
    8000000
  ];
  var DEFAULT_VIDEO_ENCODING_SETTINGS = {
    resolution: "720p",
    fps: 15,
    bitrate: 2500000
  };
  var DEFAULT_CUSTOM_VIDEO_SETTINGS = { width: 1280, height: 720 };
  function clampEven(value, min, max) {
    if (!Number.isFinite(value))
      return min;
    const clamped = Math.min(max, Math.max(min, Math.round(value)));
    return clamped - clamped % 2;
  }
  function clampWidth(value) {
    return clampEven(value, STREAM_WIDTH_MIN, STREAM_WIDTH_MAX);
  }
  function clampHeight(value) {
    return clampEven(value, STREAM_HEIGHT_MIN, STREAM_HEIGHT_MAX);
  }
  function normalizeVideoEncodingSettings(input) {
    const candidate = input ?? {};
    const resolution = VIDEO_RESOLUTION_OPTIONS.some((o) => o.id === candidate.resolution) ? candidate.resolution : DEFAULT_VIDEO_ENCODING_SETTINGS.resolution;
    const fps = VIDEO_FPS_OPTIONS.includes(candidate.fps) ? candidate.fps : DEFAULT_VIDEO_ENCODING_SETTINGS.fps;
    const bitrate = VIDEO_BITRATE_OPTIONS.includes(candidate.bitrate) ? candidate.bitrate : DEFAULT_VIDEO_ENCODING_SETTINGS.bitrate;
    if (resolution !== "custom") {
      return { resolution, fps, bitrate };
    }
    const rawCustom = candidate.custom;
    const width = typeof rawCustom?.width === "number" ? rawCustom.width : DEFAULT_CUSTOM_VIDEO_SETTINGS.width;
    const height = typeof rawCustom?.height === "number" ? rawCustom.height : DEFAULT_CUSTOM_VIDEO_SETTINGS.height;
    return {
      resolution: "custom",
      fps,
      bitrate,
      custom: { width: clampWidth(width), height: clampHeight(height) }
    };
  }
  function buildVideoConfig(settings) {
    if (settings.resolution === "custom") {
      const custom = settings.custom ?? DEFAULT_CUSTOM_VIDEO_SETTINGS;
      return {
        width: clampWidth(custom.width),
        height: clampHeight(custom.height),
        bitrate: settings.bitrate,
        frameRate: settings.fps
      };
    }
    const resolution = VIDEO_RESOLUTION_OPTIONS.find((o) => o.id === settings.resolution && o.width) ?? VIDEO_RESOLUTION_OPTIONS.find((o) => o.id === DEFAULT_VIDEO_ENCODING_SETTINGS.resolution);
    return {
      width: resolution.width,
      height: resolution.height,
      bitrate: settings.bitrate,
      frameRate: settings.fps
    };
  }

  // src/shared/config.ts
  var DEFAULT_BACKEND_URL = "https://livestreamer-miniapp-prod.mentraglass.com";
  function backendUrl() {
    const fromEnv = "https://livestreamer-miniapp-prod.mentraglass.com"?.trim();
    return (fromEnv || DEFAULT_BACKEND_URL).replace(/\/+$/, "");
  }

  // src/background/constants/config.ts
  var BACKEND_ROUTES = {
    watchPublish: () => `${backendUrl()}/api/watch/publish`,
    watchUnpublish: () => `${backendUrl()}/api/watch/unpublish`,
    watchStatus: (watchId) => `${backendUrl()}/api/watch/${watchId}/status`
  };

  // src/background/DisplayManager.ts
  var STREAMING = new Set([
    "active",
    "streaming",
    "connected",
    "connecting",
    "starting",
    "pending",
    "stopping",
    "disconnecting",
    "initializing",
    "reconnecting"
  ]);
  var isStreamingStatus = (s) => STREAMING.has(s.toLowerCase());

  class DisplayManager2 {
    session;
    constructor(session) {
      this.session = session;
    }
    show(text, durationMs) {
      try {
        this.session.display.showTextWall(text, durationMs ? { durationMs } : {});
      } catch (err) {
        console.warn("[display] showTextWall failed:", err);
      }
    }
    renderStatus(status) {
      if (status.error) {
        this.show(`Stream error
${status.error}`, 4000);
        return;
      }
      const s = (status.streamStatus ?? "offline").toLowerCase();
      if (s === "offline" || status.streamType === null) {
        this.show("Stream ended", 2500);
        return;
      }
      if (["active", "streaming", "connected"].includes(s)) {
        this.show("● LIVE");
        return;
      }
      if (isStreamingStatus(s))
        this.show("Going live…");
    }
  }

  // src/background/lib/storage.ts
  var CONFIGS_KEY = "livestreamer.configs.v2";
  function isLocalNetworkStreamUrl(rawUrl) {
    try {
      const hostname = new URL(rawUrl).hostname.replace(/^\[|\]$/g, "").toLowerCase();
      if (hostname === "localhost" || hostname.endsWith(".local"))
        return true;
      if (hostname === "::1" || hostname.startsWith("fc") || hostname.startsWith("fd") || /^fe[89ab]/.test(hostname)) {
        return true;
      }
      const octets = hostname.split(".").map(Number);
      if (octets.length !== 4 || octets.some((part) => !Number.isInteger(part) || part < 0 || part > 255)) {
        return false;
      }
      return octets[0] === 10 || octets[0] === 127 || octets[0] === 169 && octets[1] === 254 || octets[0] === 172 && octets[1] >= 16 && octets[1] <= 31 || octets[0] === 192 && octets[1] === 168;
    } catch {
      return false;
    }
  }

  class ConfigStore {
    storage;
    constructor(storage) {
      this.storage = storage;
    }
    async list() {
      const raw = await this.storage.get(CONFIGS_KEY);
      if (!raw)
        return [];
      try {
        const parsed = JSON.parse(raw);
        if (!Array.isArray(parsed))
          return [];
        let migrated = false;
        const configs = parsed.map((config) => {
          if (config.isLocalNetwork !== undefined)
            return config;
          migrated = true;
          return { ...config, isLocalNetwork: isLocalNetworkStreamUrl(config.rtmpUrl) };
        });
        if (migrated)
          await this.write(configs);
        return configs;
      } catch {
        return [];
      }
    }
    async write(configs) {
      await this.storage.set(CONFIGS_KEY, JSON.stringify(configs));
    }
    async save(input) {
      const all = await this.list();
      const existing = all.find((c) => c.platform === input.platform);
      const protocol = input.protocol ?? existing?.protocol;
      const config = {
        _id: input.platform,
        platform: input.platform,
        streamKey: input.streamKey,
        rtmpUrl: input.rtmpUrl ?? "",
        platformName: input.platformName,
        platformLogoIcon: input.platformLogoIcon,
        maskedStreamKey: input.maskedStreamKey,
        createdAt: input.createdAt,
        updatedAt: new Date().toISOString(),
        streamStartTime: existing?.streamStartTime ?? null,
        protocol,
        authToken: protocol === "whip" ? input.authToken !== undefined ? input.authToken || undefined : existing?.authToken : undefined,
        isLocalNetwork: input.isLocalNetwork ?? false
      };
      const next = all.filter((c) => c.platform !== input.platform);
      next.push(config);
      await this.write(next);
      return config;
    }
    async get(platform) {
      return (await this.list()).find((c) => c.platform === platform);
    }
    async delete(platform) {
      const all = await this.list();
      await this.write(all.filter((c) => c.platform !== platform));
    }
    async setStreamStartTime(platform, ts) {
      const all = await this.list();
      let changed = false;
      for (const c of all) {
        if (c.platform === platform) {
          c.streamStartTime = ts;
          changed = true;
        }
      }
      if (changed)
        await this.write(all);
    }
  }

  // src/shared/streamRouting.ts
  function managedIngestForPlatform(platform) {
    return platform === "here" || platform === "streamer" ? "whip" : "srt";
  }
  // src/background/lib/backend.ts
  async function publishWatch(session, payload) {
    try {
      const res = await session.auth.fetch(BACKEND_ROUTES.watchPublish(), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      if (!res.ok) {
        console.warn(`[backend] publishWatch ${res.status}`);
        return null;
      }
      return await res.json();
    } catch (err) {
      console.warn("[backend] publishWatch failed:", err);
      return null;
    }
  }
  async function unpublishWatch(session) {
    try {
      await session.auth.fetch(BACKEND_ROUTES.watchUnpublish(), { method: "POST" });
    } catch (err) {
      console.warn("[backend] unpublishWatch failed:", err);
    }
  }

  // src/background/lib/platforms.ts
  var PLATFORMS = {
    here: { name: "Watch Page" },
    streamer: { name: "Watch Page" },
    youtube: { name: "YouTube", rtmpBase: "rtmps://a.rtmps.youtube.com/live2" },
    twitch: { name: "Twitch", rtmpBase: "rtmps://live.twitch.tv/app" },
    instagram: { name: "Instagram", rtmpBase: "rtmps://live-upload.instagram.com:443/rtmp" },
    x: { name: "X", rtmpBase: "rtmp://ca.pscp.tv:80/x" },
    other: { name: "Custom RTMP" }
  };
  function buildRtmpUrl(platform, streamKey, customRtmpUrl) {
    if (platform === "other" || platform === "here" || platform === "streamer") {
      return customRtmpUrl?.trim() || undefined;
    }
    const base = PLATFORMS[platform]?.rtmpBase;
    if (!base || !streamKey)
      return;
    return `${base}/${streamKey}`;
  }

  // src/background/lib/phone-wifi.ts
  async function preparePhoneWifi(phone) {
    try {
      if (await phone.isWifiEnabled() !== false)
        return;
      const result = await phone.requestWifiEnable("Wi-Fi is required to start the livestream.");
      if (result.cancelled)
        throw new Error("Livestream cancelled.");
      if (result.enabled === false)
        throw new Error("Wi-Fi is still off. Tap Go Live to set up Wi-Fi and try again.");
    } catch (error) {
      if (error?.code === "NOT_IMPLEMENTED")
        return;
      throw error;
    }
  }

  // src/background/StreamManager.ts
  var VIEWER_POLL_MS = 8000;
  var THERMAL_SHUTDOWN_C = 90;
  var RECONNECT_SPEECH_COOLDOWN_MS = 30000;
  function videoConfigForStream(config) {
    const settings = config.videoSettings ?? DEFAULT_VIDEO_ENCODING_SETTINGS;
    const video = buildVideoConfig(settings);
    console.log(`[VideoQuality] built VideoConfig ${video.width}x${video.height}@${video.frameRate}fps/${video.bitrate}bps from settings`, settings);
    return video;
  }
  function shouldStopForTemperature(streamType, temperatureC) {
    return streamType !== null && typeof temperatureC === "number" && Number.isFinite(temperatureC) && temperatureC >= THERMAL_SHUTDOWN_C;
  }
  function mergeStreamStats(current, raw) {
    const merged = { ...current ?? {} };
    const video = raw.resolvedConfig?.video;
    const copyFinite = (key, value) => {
      if (typeof value === "number" && Number.isFinite(value)) {
        merged[key] = value;
      }
    };
    if (video) {
      copyFinite("width", video.width);
      copyFinite("height", video.height);
      copyFinite("bitrate", video.bitrate);
      copyFinite("fps", video.fps);
    }
    if (raw.stats) {
      copyFinite("bitrate", raw.stats.bitrate);
      copyFinite("fps", raw.stats.fps);
      copyFinite("droppedFrames", raw.stats.droppedFrames);
      copyFinite("duration", raw.stats.duration);
      copyFinite("temperatureC", raw.stats.temperatureC);
    }
    return Object.keys(merged).length > 0 ? merged : null;
  }
  function normalizePublisherStatus(raw) {
    const incoming = (raw.status ?? "").toLowerCase();
    if (raw.source === "cloudflare")
      return null;
    if (raw.source === "coordinator" && /^(hls_ready|webrtc_ready|suspended|resumed)$/.test(incoming))
      return null;
    return incoming === "reconnected" ? "streaming" : raw.status;
  }
  var OFFLINE = { streamType: null, streamStatus: "offline", hasActiveSession: true };
  function derivePreviewUrl(result) {
    const { hlsUrl, liveInputId } = result;
    if (liveInputId) {
      if (hlsUrl) {
        try {
          return `${new URL(hlsUrl).origin}/${liveInputId}/iframe`;
        } catch {}
      }
      return `https://iframe.videodelivery.net/${liveInputId}`;
    }
    if (!hlsUrl)
      return null;
    const m = hlsUrl.replace(/\/manifest\/.*$/i, "/iframe");
    return m !== hlsUrl ? m : null;
  }

  class StreamManager {
    session;
    status = { ...OFFLINE };
    statusUnsub = null;
    viewerPollActive = false;
    battery = null;
    listeners = new Set;
    wifiConnected = null;
    stopGeneration = 0;
    lastPublish = null;
    thermalShutdownInProgress = false;
    speechSessionActive = false;
    suppressEndSpeech = false;
    reconnectSpeechPending = false;
    lastReconnectSpeechAt = 0;
    opQueue = Promise.resolve();
    generation = 0;
    failedStartCleanup = false;
    constructor(session) {
      this.session = session;
    }
    getStatus() {
      return { ...this.status, glassesBatteryPercent: this.battery, glassesWifiConnected: this.wifiConnected };
    }
    onStatusChange(listener) {
      this.listeners.add(listener);
      return () => this.listeners.delete(listener);
    }
    setBattery(percent) {
      this.battery = percent;
      this.emit({});
    }
    emit(patch) {
      const previousStatus = this.status.streamStatus;
      this.status = { ...this.status, ...patch };
      const snapshot = this.getStatus();
      for (const l of this.listeners) {
        try {
          l(snapshot);
        } catch (err) {
          console.warn("[stream] listener threw:", err);
        }
      }
      this.handleLifecycleSpeech(previousStatus, snapshot.streamStatus);
    }
    async speak(text) {
      try {
        await this.session.speaker.speak(text, { stopOtherAudio: false });
      } catch (err) {
        console.warn("[stream] lifecycle speech failed:", err);
      }
    }
    handleLifecycleSpeech(previousStatus, nextStatus) {
      if (!this.speechSessionActive || !nextStatus)
        return;
      const previous = (previousStatus ?? "").toLowerCase();
      const next = nextStatus.toLowerCase();
      if (next === previous)
        return;
      if (next === "reconnecting") {
        const now = Date.now();
        if (!this.reconnectSpeechPending && now - this.lastReconnectSpeechAt >= RECONNECT_SPEECH_COOLDOWN_MS) {
          this.reconnectSpeechPending = true;
          this.lastReconnectSpeechAt = now;
          this.speak("Livestream reconnecting.");
        }
        return;
      }
      if (this.reconnectSpeechPending && ["active", "streaming", "connected"].includes(next)) {
        this.reconnectSpeechPending = false;
        this.speak("Livestream reconnected.");
      }
    }
    finishSpeechSession() {
      const shouldAnnounceEnd = this.speechSessionActive && !this.suppressEndSpeech;
      this.speechSessionActive = false;
      this.reconnectSpeechPending = false;
      this.suppressEndSpeech = false;
      if (shouldAnnounceEnd)
        this.speak("Livestream ended.");
    }
    async withLock(fn) {
      const prev = this.opQueue;
      let release;
      this.opQueue = new Promise((resolve) => release = resolve);
      await prev;
      try {
        return await fn();
      } finally {
        release();
      }
    }
    ensureStatusSubscription() {
      if (this.statusUnsub)
        return;
      this.statusUnsub = this.session.events.subscribe("stream_status", (data) => {
        this.onRawStatus(data);
      });
    }
    async onRawStatus(raw) {
      if (this.failedStartCleanup || this.status.streamStatus === "cleanup_pending")
        return;
      if (this.status.streamType === null)
        return;
      if (raw.streamId && this.status.streamId && raw.streamId !== this.status.streamId)
        return;
      const streamStats = this.mergeStats(raw);
      const temperatureC = streamStats?.temperatureC;
      if (!this.thermalShutdownInProgress && shouldStopForTemperature(this.status.streamType, temperatureC)) {
        this.emit({ streamStats });
        await this.stopForThermalSafety(temperatureC, streamStats);
        return;
      }
      const publisherStatus = normalizePublisherStatus(raw);
      if (publisherStatus === null)
        return;
      const incoming = (publisherStatus ?? "").toLowerCase();
      const terminal = raw.terminal === true || /^(stopped|ended|offline|reconnect_failed|failed)$/.test(incoming) || incoming === "error" && raw.willRetry !== true && raw.terminal !== false;
      if (terminal) {
        this.finishSpeechSession();
        await this.afterStopped(raw.errorDetails ?? (incoming === "error" || incoming === "failed" || incoming === "reconnect_failed" ? "Livestream failed." : null));
        return;
      }
      const displayStatus = incoming === "error" ? "reconnecting" : publisherStatus ?? this.status.streamStatus;
      const previousStatus = this.status.streamStatus;
      this.emit({
        streamStatus: displayStatus,
        streamId: raw.streamId ?? this.status.streamId,
        error: raw.errorDetails ?? null,
        streamStats
      });
      if (displayStatus !== previousStatus && this.lastPublish) {
        await publishWatch(this.session, {
          ...this.lastPublish,
          status: displayStatus === "reconnecting" ? "reconnecting" : "active"
        });
      }
    }
    mergeStats(raw) {
      return mergeStreamStats(this.status.streamStats, raw);
    }
    async stopForThermalSafety(temperatureC, streamStats) {
      if (this.thermalShutdownInProgress)
        return;
      this.thermalShutdownInProgress = true;
      const roundedTemperature = Number(temperatureC.toFixed(1));
      const message = `Stream stopped because the glasses reached ${roundedTemperature}C`;
      console.warn(`[stream] thermal safety cutoff: ${message}`);
      this.session.speaker.speak(`Livestream stopped because the glasses temperature reached ${roundedTemperature} degrees Celsius.`, {
        stopOtherAudio: true
      }).catch((err) => console.warn("[stream] thermal warning speech failed:", err));
      try {
        await this.stopFromUser({ announceEnd: false });
      } finally {
        this.emit({
          error: message,
          thermalShutdown: { temperatureC: roundedTemperature, timestamp: Date.now() },
          streamStats
        });
        this.thermalShutdownInProgress = false;
      }
    }
    handleWifiChange(data) {
      this.wifiConnected = data.connected;
      this.emit({});
    }
    async startFromUser(mode, config) {
      const stopGeneration = this.stopGeneration;
      return this.withLock(async () => {
        if (this.status.streamType !== null)
          throw new Error("Stop the current livestream before starting another.");
        if (mode === "managed" && managedIngestForPlatform(config.platform) === "whip") {
          await preparePhoneWifi(this.session.phone);
        }
        if (stopGeneration !== this.stopGeneration)
          throw new Error("Livestream cancelled.");
        this.suppressEndSpeech = false;
        this.reconnectSpeechPending = false;
        this.lastReconnectSpeechAt = 0;
        if (!this.speechSessionActive) {
          this.speechSessionActive = true;
          this.speak("Starting livestream.");
        }
        try {
          await this.doStart(mode, config);
        } catch (err) {
          this.speak("Livestream failed to start.");
          this.speechSessionActive = false;
          this.failedStartCleanup = true;
          try {
            await this.session.stream.stop();
          } catch (cleanupError) {
            const message = `${errorMessage(err)}. Could not stop the livestream: ${errorMessage(cleanupError)}`;
            this.emit({ streamStatus: "cleanup_pending", error: message });
            throw new Error(message);
          } finally {
            this.failedStartCleanup = false;
          }
          await this.afterStopped(errorMessage(err));
          throw err;
        }
      });
    }
    async stopFromUser(options = {}) {
      this.stopGeneration++;
      if (options.announceEnd === false)
        this.suppressEndSpeech = true;
      return this.withLock(async () => {
        const streamId = this.status.streamId ?? undefined;
        try {
          await this.session.stream.stop(streamId);
        } catch (err) {
          const message = err instanceof Error ? err.message : String(err);
          this.emit({ streamStatus: "cleanup_pending", error: `Could not stop livestream: ${message}` });
          throw err;
        }
        this.finishSpeechSession();
        await this.afterStopped(null);
      });
    }
    async doStart(mode, config) {
      const generation = ++this.generation;
      this.ensureStatusSubscription();
      const platform = config.platform;
      const video = videoConfigForStream(config);
      if (mode === "unmanaged") {
        const streamUrl = config.streamUrl || buildRtmpUrl(platform, config.streamKey, config.customRtmpUrl);
        if (!streamUrl)
          throw new Error("No stream URL available for local livestream");
        this.emit({
          streamType: "unmanaged",
          streamPlatform: platform,
          streamStatus: "Connecting",
          streamId: null,
          streamStats: null,
          error: null,
          thermalShutdown: null
        });
        const result2 = await this.session.stream.startStream({
          direct: streamUrl,
          sound: false,
          video: { width: video.width, height: video.height, bitrate: video.bitrate, fps: video.frameRate },
          ...config.authToken ? { authToken: config.authToken } : {}
        });
        if (generation !== this.generation)
          return;
        this.emit({
          streamStatus: result2.status ?? "active",
          streamId: result2.streamId,
          streamStats: mergeStreamStats(this.status.streamStats, {
            resolvedConfig: {
              video: result2.resolvedConfig?.video ?? {
                width: video.width,
                height: video.height,
                bitrate: video.bitrate,
                fps: video.frameRate
              }
            }
          })
        });
        return;
      }
      const restream = this.buildRestream(platform, config.streamKey, config.customRtmpUrl);
      this.emit({
        streamType: "managed",
        streamPlatform: platform,
        streamStatus: "Connecting",
        streamId: null,
        streamStats: null,
        error: null,
        thermalShutdown: null,
        hlsUrl: null,
        webrtcUrl: null,
        previewUrl: null,
        watchId: null
      });
      const result = await this.session.stream.startStream({
        destinations: restream.length ? restream : undefined,
        sound: false,
        video: { width: video.width, height: video.height, bitrate: video.bitrate, fps: video.frameRate },
        ingest: managedIngestForPlatform(platform)
      });
      if (generation !== this.generation)
        return;
      this.emit({
        streamStatus: result.status ?? "active",
        streamId: result.streamId,
        hlsUrl: result.hlsUrl ?? null,
        dashUrl: result.dashUrl ?? null,
        webrtcUrl: result.webrtcUrl ?? null,
        previewUrl: derivePreviewUrl(result),
        streamStats: mergeStreamStats(this.status.streamStats, {
          resolvedConfig: {
            video: result.resolvedConfig?.video ?? {
              width: video.width,
              height: video.height,
              bitrate: video.bitrate,
              fps: video.frameRate
            }
          }
        })
      });
      const payload = {
        status: "active",
        platform,
        mode: result.mode ?? null,
        hlsUrl: result.hlsUrl ?? null,
        dashUrl: result.dashUrl ?? null,
        webrtcUrl: result.webrtcUrl ?? null,
        streamId: result.streamId
      };
      const published = await publishWatch(this.session, payload);
      if (generation !== this.generation)
        return;
      this.lastPublish = payload;
      if (published) {
        this.emit({ watchId: published.watchId });
        this.startViewerPoll(published.watchId);
      }
    }
    async afterStopped(error) {
      this.generation++;
      this.stopViewerPoll();
      const wasManaged = this.status.streamType === "managed";
      this.lastPublish = null;
      this.status = { ...OFFLINE };
      this.emit({ error });
      if (wasManaged)
        await unpublishWatch(this.session);
    }
    buildRestream(platform, key, custom) {
      if (platform === "here")
        return [];
      const url = buildRtmpUrl(platform, key, custom);
      if (!url)
        return [];
      return [{ url, name: PLATFORMS[platform]?.name ?? platform }];
    }
    startViewerPoll(watchId) {
      if (this.viewerPollActive)
        return;
      this.viewerPollActive = true;
      const tick = async () => {
        if (!this.viewerPollActive)
          return;
        try {
          const res = await fetch(BACKEND_ROUTES.watchStatus(watchId));
          if (res.ok) {
            const body = await res.json();
            if (typeof body.viewerCount === "number")
              this.emit({ viewerCount: body.viewerCount });
          }
        } catch {}
        if (this.viewerPollActive)
          setTimeout(tick, VIEWER_POLL_MS);
      };
      setTimeout(tick, VIEWER_POLL_MS);
    }
    stopViewerPoll() {
      this.viewerPollActive = false;
    }
    dispose() {
      this.stopGeneration++;
      this.stopViewerPoll();
      this.statusUnsub?.();
      this.statusUnsub = null;
      this.listeners.clear();
    }
  }

  // src/background/LivestreamerController.ts
  var ORPHAN_CHECK_INTERVAL_MS = 60000;
  var ORPHAN_TIMEOUT_MS = 30 * 60 * 1000;

  class LivestreamerController {
    session;
    ui;
    stream;
    display;
    configs;
    watchId = null;
    batteryUnsub = null;
    wifiUnsub = null;
    wifi = null;
    webviewOpen = false;
    lastWebviewCloseAt = Date.now();
    orphanTimer = null;
    constructor(session) {
      this.session = session;
      this.ui = session.ui;
      this.stream = new StreamManager(session);
      this.display = new DisplayManager2(session);
      this.configs = new ConfigStore(session.storage);
    }
    async start() {
      this.fetchWatchId();
      this.stream.onStatusChange((status) => {
        this.ui.send("stream:status", this.withWatchId(status));
        this.display.renderStatus(status);
      });
      try {
        this.batteryUnsub = this.session.glasses.onBattery((d) => {
          const level = d.level;
          this.stream.setBattery(typeof level === "number" ? level : null);
        });
      } catch {}
      try {
        this.wifiUnsub = this.session.glasses.onWifi((d) => {
          this.wifi = d;
          this.stream.handleWifiChange(d);
        });
      } catch {}
      this.ui.handle("api", (req) => this.handleApi(req));
      this.ui.onOpen(() => {
        this.webviewOpen = true;
        this.ui.send("stream:status", this.withWatchId(this.stream.getStatus()));
      });
      this.ui.onClose(() => {
        this.webviewOpen = false;
        this.lastWebviewCloseAt = Date.now();
      });
      this.orphanTimer = setInterval(() => {
        const streaming = this.stream.getStatus().streamType !== null;
        if (streaming && !this.webviewOpen && Date.now() - this.lastWebviewCloseAt > ORPHAN_TIMEOUT_MS) {
          console.log(`[livestreamer] orphaned stream (no webview for ${ORPHAN_TIMEOUT_MS / 60000} min) — stopping`);
          this.stream.stopFromUser();
        }
      }, ORPHAN_CHECK_INTERVAL_MS);
      console.log("[livestreamer] controller started");
    }
    withWatchId(status) {
      return { ...status, watchId: status.watchId ?? this.watchId };
    }
    async fetchWatchId() {
      try {
        const res = await this.session.auth.fetch(`${backendUrl()}/api/watch/id`);
        if (res.ok) {
          const body = await res.json();
          if (body.watchId) {
            this.watchId = body.watchId;
            this.ui.send("stream:status", this.withWatchId(this.stream.getStatus()));
          }
        }
      } catch {}
    }
    async handleApi(req) {
      const { method, path } = req;
      const body = req.body ?? {};
      if (method === "POST" && path === "/api/stream/managed/start")
        return this.startStream("managed", body);
      if (method === "POST" && path === "/api/stream/managed/stop")
        return this.stopStream("managed");
      if (method === "POST" && path === "/api/stream/unmanaged/start")
        return this.startStream("unmanaged", body);
      if (method === "POST" && path === "/api/stream/unmanaged/stop")
        return this.stopStream("unmanaged");
      if (method === "GET" && path === "/api/stream-configs") {
        return { ok: true, configs: await this.configs.list() };
      }
      if (method === "POST" && path === "/api/stream-configs") {
        const config = await this.configs.save(body);
        return { ok: true, config };
      }
      if (method === "DELETE" && path.startsWith("/api/stream-configs/")) {
        const platform = decodeURIComponent(path.slice("/api/stream-configs/".length));
        await this.configs.delete(platform);
        return { ok: true };
      }
      if (method === "GET" && path === "/api/glass-state") {
        const battery = this.stream.getStatus().glassesBatteryPercent ?? null;
        const wifiConnected = this.wifi ? this.wifi.connected : true;
        return { ok: true, glassState: { wifiConnected, ssid: this.wifi?.ssid, batteryPercent: battery } };
      }
      if (method === "POST" && path === "/api/request-wifi-setup") {
        try {
          const reason = body.message || "Streaming requires your glasses to be connected to Wi-Fi";
          await this.session.glasses.requestWifiSetup(reason);
          return { success: true };
        } catch (err) {
          return { success: false, error: errorMessage(err, "Wi-Fi setup failed") };
        }
      }
      if (method === "GET" && path === "/api/watch-id") {
        if (!this.watchId)
          await this.fetchWatchId();
        return { watchId: this.watchId ?? "" };
      }
      if (method === "GET" && /^\/api\/watch\/[^/]+\/status$/.test(path)) {
        return { ok: true, viewerCount: this.stream.getStatus().viewerCount ?? 0 };
      }
      console.warn(`[livestreamer] unhandled api: ${method} ${path}`);
      return { ok: false, error: `Unhandled ${method} ${path}` };
    }
    async startStream(mode, body) {
      const platform = body.platform ?? "here";
      try {
        await this.stream.startFromUser(mode, {
          platform,
          streamKey: body.streamKey,
          customRtmpUrl: body.customRtmpUrl,
          videoSettings: normalizeVideoEncodingSettings(body.videoSettings),
          authToken: body.authToken,
          streamUrl: body.streamUrl
        });
        if (mode === "managed")
          await this.configs.setStreamStartTime(platform, Date.now());
        return { ok: true };
      } catch (err) {
        const error = errorMessage(err, `${mode === "managed" ? "Managed" : "Unmanaged"} stream start failed`);
        console.warn(`[livestreamer] ${mode} start failed:`, error);
        return { ok: false, error, status: this.stream.getStatus() };
      }
    }
    async stopStream(_mode) {
      const platform = this.stream.getStatus().streamPlatform ?? null;
      try {
        await this.stream.stopFromUser();
        if (platform)
          await this.configs.setStreamStartTime(platform, null);
        return { ok: true };
      } catch (err) {
        return { ok: false, error: errorMessage(err, "Stream stop failed"), status: this.stream.getStatus() };
      }
    }
    dispose() {
      if (this.orphanTimer)
        clearInterval(this.orphanTimer);
      this.batteryUnsub?.();
      this.wifiUnsub?.();
      this.stream.dispose();
    }
  }

  // src/background/index.ts
  registerMiniapp((session) => {
    new LivestreamerController(session).start();
  });
})();
