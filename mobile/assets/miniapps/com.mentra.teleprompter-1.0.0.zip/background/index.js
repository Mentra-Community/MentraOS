(() => {
  var __create = Object.create;
  var __getProtoOf = Object.getPrototypeOf;
  var __defProp = Object.defineProperty;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __toESM = (mod, isNodeMode, target) => {
    target = mod != null ? __create(__getProtoOf(mod)) : {};
    const to = isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target;
    for (let key of __getOwnPropNames(mod))
      if (!__hasOwnProp.call(to, key))
        __defProp(to, key, {
          get: () => mod[key],
          enumerable: true
        });
    return to;
  };
  var __commonJS = (cb, mod) => () => (mod || cb((mod = { exports: {} }).exports, mod), mod.exports);

  // ../../node_modules/.bun/eventemitter3@5.0.4/node_modules/eventemitter3/index.js
  var require_eventemitter3 = __commonJS((exports, module) => {
    var has = Object.prototype.hasOwnProperty;
    var prefix = "~";
    function Events() {}
    if (Object.create) {
      Events.prototype = Object.create(null);
      if (!new Events().__proto__)
        prefix = false;
    }
    function EE(fn, context, once) {
      this.fn = fn;
      this.context = context;
      this.once = once || false;
    }
    function addListener(emitter, event, fn, context, once) {
      if (typeof fn !== "function") {
        throw new TypeError("The listener must be a function");
      }
      var listener = new EE(fn, context || emitter, once), evt = prefix ? prefix + event : event;
      if (!emitter._events[evt])
        emitter._events[evt] = listener, emitter._eventsCount++;
      else if (!emitter._events[evt].fn)
        emitter._events[evt].push(listener);
      else
        emitter._events[evt] = [emitter._events[evt], listener];
      return emitter;
    }
    function clearEvent(emitter, evt) {
      if (--emitter._eventsCount === 0)
        emitter._events = new Events;
      else
        delete emitter._events[evt];
    }
    function EventEmitter() {
      this._events = new Events;
      this._eventsCount = 0;
    }
    EventEmitter.prototype.eventNames = function eventNames() {
      var names = [], events, name;
      if (this._eventsCount === 0)
        return names;
      for (name in events = this._events) {
        if (has.call(events, name))
          names.push(prefix ? name.slice(1) : name);
      }
      if (Object.getOwnPropertySymbols) {
        return names.concat(Object.getOwnPropertySymbols(events));
      }
      return names;
    };
    EventEmitter.prototype.listeners = function listeners(event) {
      var evt = prefix ? prefix + event : event, handlers = this._events[evt];
      if (!handlers)
        return [];
      if (handlers.fn)
        return [handlers.fn];
      for (var i = 0, l = handlers.length, ee = new Array(l);i < l; i++) {
        ee[i] = handlers[i].fn;
      }
      return ee;
    };
    EventEmitter.prototype.listenerCount = function listenerCount(event) {
      var evt = prefix ? prefix + event : event, listeners = this._events[evt];
      if (!listeners)
        return 0;
      if (listeners.fn)
        return 1;
      return listeners.length;
    };
    EventEmitter.prototype.emit = function emit(event, a1, a2, a3, a4, a5) {
      var evt = prefix ? prefix + event : event;
      if (!this._events[evt])
        return false;
      var listeners = this._events[evt], len = arguments.length, args, i;
      if (listeners.fn) {
        if (listeners.once)
          this.removeListener(event, listeners.fn, undefined, true);
        switch (len) {
          case 1:
            return listeners.fn.call(listeners.context), true;
          case 2:
            return listeners.fn.call(listeners.context, a1), true;
          case 3:
            return listeners.fn.call(listeners.context, a1, a2), true;
          case 4:
            return listeners.fn.call(listeners.context, a1, a2, a3), true;
          case 5:
            return listeners.fn.call(listeners.context, a1, a2, a3, a4), true;
          case 6:
            return listeners.fn.call(listeners.context, a1, a2, a3, a4, a5), true;
        }
        for (i = 1, args = new Array(len - 1);i < len; i++) {
          args[i - 1] = arguments[i];
        }
        listeners.fn.apply(listeners.context, args);
      } else {
        var length = listeners.length, j;
        for (i = 0;i < length; i++) {
          if (listeners[i].once)
            this.removeListener(event, listeners[i].fn, undefined, true);
          switch (len) {
            case 1:
              listeners[i].fn.call(listeners[i].context);
              break;
            case 2:
              listeners[i].fn.call(listeners[i].context, a1);
              break;
            case 3:
              listeners[i].fn.call(listeners[i].context, a1, a2);
              break;
            case 4:
              listeners[i].fn.call(listeners[i].context, a1, a2, a3);
              break;
            default:
              if (!args)
                for (j = 1, args = new Array(len - 1);j < len; j++) {
                  args[j - 1] = arguments[j];
                }
              listeners[i].fn.apply(listeners[i].context, args);
          }
        }
      }
      return true;
    };
    EventEmitter.prototype.on = function on(event, fn, context) {
      return addListener(this, event, fn, context, false);
    };
    EventEmitter.prototype.once = function once(event, fn, context) {
      return addListener(this, event, fn, context, true);
    };
    EventEmitter.prototype.removeListener = function removeListener(event, fn, context, once) {
      var evt = prefix ? prefix + event : event;
      if (!this._events[evt])
        return this;
      if (!fn) {
        clearEvent(this, evt);
        return this;
      }
      var listeners = this._events[evt];
      if (listeners.fn) {
        if (listeners.fn === fn && (!once || listeners.once) && (!context || listeners.context === context)) {
          clearEvent(this, evt);
        }
      } else {
        for (var i = 0, events = [], length = listeners.length;i < length; i++) {
          if (listeners[i].fn !== fn || once && !listeners[i].once || context && listeners[i].context !== context) {
            events.push(listeners[i]);
          }
        }
        if (events.length)
          this._events[evt] = events.length === 1 ? events[0] : events;
        else
          clearEvent(this, evt);
      }
      return this;
    };
    EventEmitter.prototype.removeAllListeners = function removeAllListeners(event) {
      var evt;
      if (event) {
        evt = prefix ? prefix + event : event;
        if (this._events[evt])
          clearEvent(this, evt);
      } else {
        this._events = new Events;
        this._eventsCount = 0;
      }
      return this;
    };
    EventEmitter.prototype.off = EventEmitter.prototype.removeListener;
    EventEmitter.prototype.addListener = EventEmitter.prototype.on;
    EventEmitter.prefixed = prefix;
    EventEmitter.EventEmitter = EventEmitter;
    if (typeof module !== "undefined") {
      module.exports = EventEmitter;
    }
  });

  // ../../node_modules/.bun/eventemitter3@5.0.4/node_modules/eventemitter3/index.mjs
  var import__ = __toESM(require_eventemitter3(), 1);

  // ../../mobile/modules/miniapp/dist/envelope.js
  function serializeEnvelope(envelope) {
    return JSON.stringify(envelope);
  }
  function parseEnvelope(raw) {
    if (typeof raw !== "string")
      return null;
    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch {
      return null;
    }
    if (typeof parsed !== "object" || parsed === null)
      return null;
    const obj = parsed;
    if (typeof obj.payload !== "object" || obj.payload === null)
      return null;
    if (obj.requestId !== undefined && typeof obj.requestId !== "string")
      return null;
    return {
      payload: obj.payload,
      requestId: obj.requestId
    };
  }
  function makeRequestId() {
    if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
      return crypto.randomUUID();
    }
    return `req_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
  }

  // ../../mobile/modules/miniapp/dist/globals.js
  function getMentraOSGlobals() {
    if (typeof window === "undefined")
      return {};
    return window.MentraOS ?? {};
  }

  // ../../mobile/modules/miniapp/dist/protocol.js
  var MiniappRequestType;
  (function(MiniappRequestType2) {
    MiniappRequestType2["CONNECT"] = "miniapp_connect";
    MiniappRequestType2["AUTH_REFRESH"] = "miniapp_auth_refresh";
    MiniappRequestType2["SUBSCRIBE"] = "miniapp_subscribe";
    MiniappRequestType2["DISPLAY"] = "miniapp_display";
    MiniappRequestType2["CANVAS"] = "miniapp_canvas";
    MiniappRequestType2["PLAY_AUDIO"] = "miniapp_play_audio";
    MiniappRequestType2["STOP_AUDIO"] = "miniapp_stop_audio";
    MiniappRequestType2["SPEAK"] = "miniapp_speak";
    MiniappRequestType2["RGB_LED"] = "miniapp_rgb_led";
    MiniappRequestType2["LOCATION_POLL"] = "miniapp_location_poll";
    MiniappRequestType2["NAVIGATION_START"] = "miniapp_navigation_start";
    MiniappRequestType2["NAVIGATION_STOP"] = "miniapp_navigation_stop";
    MiniappRequestType2["NAVIGATION_DEVIATE"] = "miniapp_navigation_deviate";
    MiniappRequestType2["NAVIGATION_SET_WRONG_SIDEWALK"] = "miniapp_navigation_set_wrong_sidewalk";
    MiniappRequestType2["NAVIGATION_SET_SKIP_CROSSINGS"] = "miniapp_navigation_set_skip_crossings";
    MiniappRequestType2["NAVIGATION_GET_STATE"] = "miniapp_navigation_get_state";
    MiniappRequestType2["NAVIGATION_COMPUTE_ROUTE"] = "miniapp_navigation_compute_route";
    MiniappRequestType2["NAVIGATION_REVERSE_GEOCODE"] = "miniapp_navigation_reverse_geocode";
    MiniappRequestType2["NAVIGATION_REQUEST_PERMISSION"] = "miniapp_navigation_request_permission";
    MiniappRequestType2["STORAGE_GET"] = "miniapp_storage_get";
    MiniappRequestType2["STORAGE_SET"] = "miniapp_storage_set";
    MiniappRequestType2["STORAGE_DELETE"] = "miniapp_storage_delete";
    MiniappRequestType2["STORAGE_LIST"] = "miniapp_storage_list";
    MiniappRequestType2["STORAGE_CLEAR"] = "miniapp_storage_clear";
    MiniappRequestType2["STORAGE_HAS"] = "miniapp_storage_has";
    MiniappRequestType2["STORAGE_GET_ALL"] = "miniapp_storage_get_all";
    MiniappRequestType2["STORAGE_SET_MULTIPLE"] = "miniapp_storage_set_multiple";
    MiniappRequestType2["STORAGE_FLUSH"] = "miniapp_storage_flush";
    MiniappRequestType2["CAMERA_FOV"] = "miniapp_camera_fov";
    MiniappRequestType2["IMU_SET_ENABLED"] = "miniapp_imu_set_enabled";
    MiniappRequestType2["SHARE"] = "miniapp_share";
    MiniappRequestType2["OPEN_URL"] = "miniapp_open_url";
    MiniappRequestType2["COPY_CLIPBOARD"] = "miniapp_copy_clipboard";
    MiniappRequestType2["DOWNLOAD"] = "miniapp_download";
    MiniappRequestType2["PING"] = "miniapp_ping";
    MiniappRequestType2["TRANSCRIPTION_CONFIG"] = "miniapp_transcription_config";
    MiniappRequestType2["DASHBOARD_CONTENT_UPDATE"] = "miniapp_dashboard_content_update";
    MiniappRequestType2["PHOTO"] = "miniapp_photo";
    MiniappRequestType2["VIDEO_RECORDING_START"] = "miniapp_video_recording_start";
    MiniappRequestType2["VIDEO_RECORDING_STOP"] = "miniapp_video_recording_stop";
    MiniappRequestType2["STREAM_START"] = "miniapp_stream_start";
    MiniappRequestType2["STREAM_STOP"] = "miniapp_stream_stop";
    MiniappRequestType2["MANAGED_STREAM_START"] = "miniapp_managed_stream_start";
    MiniappRequestType2["MANAGED_STREAM_STOP"] = "miniapp_managed_stream_stop";
    MiniappRequestType2["MINIAPPS_LIST"] = "miniapp_apps_list";
    MiniappRequestType2["MINIAPPS_START"] = "miniapp_apps_start";
    MiniappRequestType2["MINIAPPS_STOP"] = "miniapp_apps_stop";
    MiniappRequestType2["ACTION_INVOKE"] = "miniapp_action_invoke";
    MiniappRequestType2["ACTION_RESULT"] = "miniapp_action_result";
  })(MiniappRequestType || (MiniappRequestType = {}));
  var MiniappResponseType;
  (function(MiniappResponseType2) {
    MiniappResponseType2["CONNECT_ACK"] = "miniapp_connect_ack";
    MiniappResponseType2["EVENT"] = "miniapp_event";
    MiniappResponseType2["REQUEST_RESULT"] = "miniapp_request_result";
    MiniappResponseType2["CAPABILITIES_UPDATE"] = "miniapp_capabilities_update";
    MiniappResponseType2["VISIBILITY_CHANGE"] = "miniapp_visibility_change";
    MiniappResponseType2["COLOR_SCHEME_CHANGE"] = "miniapp_color_scheme_change";
    MiniappResponseType2["SPEAKER_STATE"] = "miniapp_speaker_state";
    MiniappResponseType2["PERMISSIONS_UPDATE"] = "miniapp_permissions_update";
    MiniappResponseType2["AUTH_UPDATE"] = "miniapp_auth_update";
    MiniappResponseType2["PONG"] = "miniapp_pong";
    MiniappResponseType2["ACTION_CALL"] = "miniapp_action_call";
    MiniappResponseType2["WILL_DISCONNECT"] = "miniapp_will_disconnect";
    MiniappResponseType2["ERROR"] = "miniapp_error";
  })(MiniappResponseType || (MiniappResponseType = {}));
  var MiniappStreamType;
  (function(MiniappStreamType2) {
    MiniappStreamType2["BUTTON_PRESS"] = "button_press";
    MiniappStreamType2["TOUCH_EVENT"] = "touch_event";
    MiniappStreamType2["HEAD_POSITION"] = "head_position";
    MiniappStreamType2["ACCEL_DATA"] = "accel_data";
    MiniappStreamType2["GLASSES_BATTERY"] = "glasses_battery";
    MiniappStreamType2["PHONE_BATTERY"] = "phone_battery";
    MiniappStreamType2["GLASSES_CONNECTION"] = "glasses_connection";
    MiniappStreamType2["TRANSCRIPTION"] = "transcription";
    MiniappStreamType2["TRANSLATION"] = "translation";
    MiniappStreamType2["AUDIO_CHUNK"] = "audio_chunk";
    MiniappStreamType2["VAD"] = "vad";
    MiniappStreamType2["LOCATION_UPDATE"] = "location_update";
    MiniappStreamType2["HEADING_UPDATE"] = "heading_update";
    MiniappStreamType2["NAVIGATION_UPDATE"] = "navigation_update";
    MiniappStreamType2["NAVIGATION_ROUTE"] = "navigation_route";
    MiniappStreamType2["PHONE_NOTIFICATION"] = "phone_notification";
    MiniappStreamType2["PHONE_NOTIFICATION_DISMISSED"] = "phone_notification_dismissed";
    MiniappStreamType2["CALENDAR_EVENT"] = "calendar_event";
    MiniappStreamType2["PHOTO_TAKEN"] = "photo_taken";
    MiniappStreamType2["STREAM_STATUS"] = "stream_status";
  })(MiniappStreamType || (MiniappStreamType = {}));
  var MiniappErrorCode;
  (function(MiniappErrorCode2) {
    MiniappErrorCode2["PERMISSION_NOT_DECLARED"] = "PERMISSION_NOT_DECLARED";
    MiniappErrorCode2["NOT_IMPLEMENTED"] = "NOT_IMPLEMENTED";
    MiniappErrorCode2["REQUEST_ABORTED"] = "REQUEST_ABORTED";
    MiniappErrorCode2["INTERNAL"] = "INTERNAL";
    MiniappErrorCode2["TTS_TEXT_TOO_LONG"] = "TTS_TEXT_TOO_LONG";
    MiniappErrorCode2["TTS_INVALID_VOICE"] = "TTS_INVALID_VOICE";
    MiniappErrorCode2["TTS_UPSTREAM_ERROR"] = "TTS_UPSTREAM_ERROR";
    MiniappErrorCode2["NOT_CONNECTED"] = "NOT_CONNECTED";
    MiniappErrorCode2["NOT_PERMITTED"] = "NOT_PERMITTED";
    MiniappErrorCode2["APP_NOT_FOUND"] = "APP_NOT_FOUND";
    MiniappErrorCode2["APP_NOT_COMPATIBLE"] = "APP_NOT_COMPATIBLE";
    MiniappErrorCode2["ACTION_NOT_FOUND"] = "ACTION_NOT_FOUND";
    MiniappErrorCode2["NO_ACTION_HANDLER"] = "NO_ACTION_HANDLER";
    MiniappErrorCode2["WAKE_FAILED"] = "WAKE_FAILED";
    MiniappErrorCode2["ACTION_TIMEOUT"] = "ACTION_TIMEOUT";
    MiniappErrorCode2["PAYLOAD_TOO_LARGE"] = "PAYLOAD_TOO_LARGE";
  })(MiniappErrorCode || (MiniappErrorCode = {}));

  // ../../mobile/modules/miniapp/dist/transport/dispatch.js
  class DispatchTransport {
    constructor() {
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.open_ = false;
    }
    static isAvailable() {
      return typeof globalThis.__dispatch === "function";
    }
    async open() {
      if (!DispatchTransport.isAvailable()) {
        throw new Error("DispatchTransport: __dispatch is not installed on globalThis");
      }
      const g = globalThis;
      g.__mentraDeliverBridgeRaw = (raw) => {
        if (this.messageHandler)
          this.messageHandler(raw);
      };
      this.open_ = true;
    }
    send(raw) {
      if (!this.open_) {
        throw new Error("DispatchTransport: send() before open()");
      }
      const g = globalThis;
      if (typeof g.__dispatch !== "function") {
        this.open_ = false;
        this.disconnectHandler?.("DispatchTransport: __dispatch disappeared");
        return;
      }
      try {
        g.__dispatch("__bridge", "send", JSON.stringify([raw]));
      } catch (e) {
        this.disconnectHandler?.(`DispatchTransport: __dispatch threw: ${String(e)}`);
      }
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      this.open_ = false;
      const g = globalThis;
      if (g.__mentraDeliverBridgeRaw) {
        delete g.__mentraDeliverBridgeRaw;
      }
    }
    isOpen() {
      return this.open_;
    }
  }

  // ../../mobile/modules/miniapp/dist/transport/local-socket.js
  var DEFAULT_URL = "ws://127.0.0.1:8765";

  class LocalSocketTransport {
    constructor(options = {}) {
      this.ws = null;
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.url = options.url ?? DEFAULT_URL;
    }
    async open() {
      if (this.ws && this.ws.readyState === WebSocket.OPEN)
        return;
      if (typeof WebSocket === "undefined") {
        throw new Error("LocalSocketTransport: browser WebSocket global not available");
      }
      await new Promise((resolve, reject) => {
        const ws = new WebSocket(this.url);
        let settled = false;
        const settle = (fn) => {
          if (settled)
            return;
          settled = true;
          fn();
        };
        ws.onopen = () => {
          this.ws = ws;
          settle(() => resolve());
        };
        ws.onerror = (ev) => {
          settle(() => reject(new Error(`LocalSocketTransport: failed to connect to ${this.url}: ${String(ev)}`)));
        };
        ws.onmessage = (ev) => {
          const data = ev.data;
          if (typeof data === "string")
            this.messageHandler?.(data);
        };
        ws.onclose = (ev) => {
          if (this.ws === ws)
            this.ws = null;
          this.disconnectHandler?.(`closed: ${ev.code} ${ev.reason}`);
        };
      });
    }
    send(raw) {
      if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
        throw new Error("LocalSocketTransport: not connected");
      }
      this.ws.send(raw);
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      if (!this.ws)
        return;
      try {
        this.ws.close();
      } catch {}
      this.ws = null;
    }
    isOpen() {
      return !!this.ws && this.ws.readyState === WebSocket.OPEN;
    }
  }

  // ../../mobile/modules/miniapp/dist/transport/mock.js
  var LOG_PREFIX = "[mock-transport]";
  function isMockExplicitlyRequested() {
    if (typeof window === "undefined")
      return false;
    try {
      if (typeof window.location !== "undefined" && window.location.search) {
        const params = new URLSearchParams(window.location.search);
        if (params.get("mentra") === "mock")
          return true;
      }
    } catch {}
    try {
      if (typeof localStorage !== "undefined" && localStorage.getItem("MENTRA_MOCK") === "1") {
        return true;
      }
    } catch {}
    return false;
  }

  class MockTransport {
    constructor(options = {}) {
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.open_ = false;
      this.userId = options.userId ?? "mock-user";
      this.authToken = options.authToken ?? "mock-miniapp-token";
      this.packageName = options.packageName ?? null;
      this.silent = options.silent === true;
    }
    async open() {
      if (this.open_)
        return;
      this.open_ = true;
      this.log("transport opened (no real host; synthetic responses only)");
    }
    send(raw) {
      if (!this.open_) {
        throw new Error("MockTransport: send() before open()");
      }
      const envelope = parseEnvelope(raw);
      if (!envelope) {
        this.log("dropped unparseable envelope:", raw.slice(0, 200));
        return;
      }
      const payload = envelope.payload;
      const type = payload?.type;
      this.log(`recv ${type ?? "<unknown>"}${envelope.requestId ? ` (rid=${envelope.requestId})` : ""}`);
      switch (type) {
        case MiniappRequestType.CONNECT:
          this.deliverConnectAck(payload);
          return;
        case MiniappRequestType.PING:
          return;
        case MiniappRequestType.SUBSCRIBE:
          return;
        default:
          if (envelope.requestId) {
            this.deliverSyntheticResult(envelope.requestId, type ?? "<unknown>", payload);
          }
          return;
      }
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      if (!this.open_)
        return;
      this.open_ = false;
      this.disconnectHandler?.("MockTransport.close()");
    }
    isOpen() {
      return this.open_;
    }
    deliverConnectAck(connectPayload) {
      const incomingPackage = connectPayload.packageName ?? this.packageName ?? "com.mock.app";
      const ackPayload = {
        type: MiniappResponseType.CONNECT_ACK,
        userId: this.userId,
        packageName: incomingPackage,
        capabilities: null,
        visibility: "foreground",
        colorScheme: "light",
        auth: {
          mentraUserId: this.userId,
          oemId: "mock",
          token: this.authToken,
          expiresAt: Date.now() + 60 * 60 * 1000
        }
      };
      const envelope = { payload: ackPayload };
      this.log(`-> CONNECT_ACK userId=${this.userId} pkg=${incomingPackage}`);
      queueMicrotask(() => this.messageHandler?.(serializeEnvelope(envelope)));
    }
    deliverSyntheticResult(requestId, requestType, requestPayload) {
      const data = syntheticDataFor(requestId, requestType, requestPayload);
      const responsePayload = {
        type: MiniappResponseType.REQUEST_RESULT,
        ok: true,
        data
      };
      const envelope = { payload: responsePayload, requestId };
      this.log(`-> REQUEST_RESULT (rid=${requestId}) synthetic ${requestType}`);
      queueMicrotask(() => this.messageHandler?.(serializeEnvelope(envelope)));
    }
    log(...args) {
      if (this.silent)
        return;
      console.log(LOG_PREFIX, ...args);
    }
  }
  function syntheticDataFor(requestId, requestType, requestPayload) {
    switch (requestType) {
      case MiniappRequestType.CAMERA_FOV: {
        const presetFov = requestPayload.preset === "narrow" ? 82 : requestPayload.preset === "wide" ? 118 : requestPayload.preset === "standard" ? 102 : undefined;
        const fov = typeof requestPayload.fov === "number" ? requestPayload.fov : presetFov ?? 102;
        const roi = requestPayload.roiPosition;
        const roiPosition = roi === "bottom" ? "bottom" : roi === "top" ? "top" : "center";
        return {
          requestId,
          fov,
          roiPosition,
          timestamp: Date.now()
        };
      }
      case MiniappRequestType.PHOTO:
        return {
          photoUrl: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkAAIAAAoAAv/lxKUAAAAASUVORK5CYII=",
          requestId: "mock-photo"
        };
      case MiniappRequestType.RGB_LED:
        return { type: "rgb_led_control_response", state: "success", requestId };
      case MiniappRequestType.LOCATION_POLL:
        return { lat: 37.7956, lng: -122.3933, accuracy: 0, timestamp: Date.now() };
      case MiniappRequestType.STORAGE_GET:
        return { value: null };
      case MiniappRequestType.STORAGE_LIST:
        return { keys: [] };
      case MiniappRequestType.SPEAK:
        return { audioUrl: null, durationMs: 0 };
      case MiniappRequestType.SHARE:
      case MiniappRequestType.OPEN_URL:
      case MiniappRequestType.COPY_CLIPBOARD:
      case MiniappRequestType.DOWNLOAD:
        return { ok: true };
      default:
        return null;
    }
  }

  // ../../mobile/modules/miniapp/dist/transport/postmessage.js
  class PostMessageTransport {
    constructor() {
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.open_ = false;
      this.windowListener = null;
    }
    async open() {
      if (this.open_)
        return;
      if (typeof window === "undefined" || !window.ReactNativeWebView) {
        throw new Error("PostMessageTransport: not running inside a React Native WebView");
      }
      this.windowListener = (ev) => {
        const data = ev.data;
        if (typeof data !== "string")
          return;
        this.messageHandler?.(data);
      };
      window.addEventListener("message", this.windowListener);
      if (typeof document !== "undefined") {
        document.addEventListener("message", this.windowListener);
      }
      window.receiveNativeMessage = (raw) => {
        this.messageHandler?.(raw);
      };
      this.open_ = true;
    }
    send(raw) {
      if (typeof window === "undefined" || !window.ReactNativeWebView) {
        throw new Error("PostMessageTransport: not running inside a React Native WebView");
      }
      window.ReactNativeWebView.postMessage(raw);
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      if (!this.open_)
        return;
      this.open_ = false;
      if (this.windowListener) {
        window.removeEventListener("message", this.windowListener);
        if (typeof document !== "undefined") {
          document.removeEventListener("message", this.windowListener);
        }
        this.windowListener = null;
      }
      if (typeof window !== "undefined" && window.receiveNativeMessage) {
        window.receiveNativeMessage = undefined;
      }
      this.disconnectHandler?.("closed");
    }
    isOpen() {
      return this.open_;
    }
  }

  // ../../mobile/modules/miniapp/dist/transport/auto.js
  var LOCAL_SOCKET_OPEN_TIMEOUT_MS = 500;
  function createTransport(options = {}) {
    if (options.transport)
      return options.transport;
    if (DispatchTransport.isAvailable()) {
      return new DispatchTransport;
    }
    if (typeof window !== "undefined" && window.ReactNativeWebView) {
      return new PostMessageTransport;
    }
    if (isMockExplicitlyRequested()) {
      return new MockTransport;
    }
    if (typeof WebSocket !== "undefined") {
      const localSocketOptions = {};
      if (options.localSocketUrl)
        localSocketOptions.url = options.localSocketUrl;
      return new LocalSocketWithMockFallback(localSocketOptions);
    }
    return new MockTransport;
  }

  class LocalSocketWithMockFallback {
    constructor(options) {
      this.options = options;
      this.active = null;
      this.messageHandler = null;
      this.disconnectHandler = null;
    }
    async open() {
      const local = new LocalSocketTransport(this.options);
      let timedOut = false;
      const timeout = new Promise((_, reject) => {
        setTimeout(() => {
          timedOut = true;
          reject(new Error("LocalSocketTransport open timed out"));
        }, LOCAL_SOCKET_OPEN_TIMEOUT_MS);
      });
      try {
        await Promise.race([local.open(), timeout]);
        this.active = local;
      } catch {
        try {
          local.close();
        } catch {}
        const mock = new MockTransport;
        await mock.open();
        this.active = mock;
        console.log(timedOut ? "[mentra-miniapp] No phone WebSocket reachable; using MockTransport so the page can render." : "[mentra-miniapp] LocalSocketTransport failed; using MockTransport.");
      }
      if (this.messageHandler)
        this.active.onMessage(this.messageHandler);
      if (this.disconnectHandler)
        this.active.onDisconnect(this.disconnectHandler);
    }
    send(raw) {
      if (!this.active)
        throw new Error("LocalSocketWithMockFallback: send() before open()");
      this.active.send(raw);
    }
    onMessage(handler) {
      this.messageHandler = handler;
      this.active?.onMessage(handler);
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
      this.active?.onDisconnect(handler);
    }
    close() {
      this.active?.close();
    }
    isOpen() {
      return this.active?.isOpen() === true;
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/camera.js
  class CameraModule {
    constructor(session) {
      this.session = session;
    }
    get hasPermission() {
      return this.session._hasManifestPermission("CAMERA");
    }
    async setFov(request) {
      return this.session.sendRequest({
        type: MiniappRequestType.CAMERA_FOV,
        ...request
      });
    }
    async takePhoto(options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.PHOTO,
        size: options.size ?? "medium",
        compress: options.compress ?? "none",
        sound: options.sound ?? true,
        saveToGallery: options.saveToGallery ?? false,
        exposureTimeNs: options.exposureTimeNs
      });
    }
    async startVideoRecording(options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.VIDEO_RECORDING_START,
        width: options.width,
        height: options.height,
        fps: options.fps,
        sound: options.sound ?? true,
        save: options.save ?? false
      });
    }
    async stopVideoRecording(recordingId) {
      await this.session.sendRequest({
        type: MiniappRequestType.VIDEO_RECORDING_STOP,
        recordingId
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/canvas.js
  var CanvasOperation;
  (function(CanvasOperation2) {
    CanvasOperation2["SHOW_TEXT"] = "show_text";
    CanvasOperation2["SHOW_BITMAP"] = "show_bitmap";
    CanvasOperation2["CLEAR"] = "clear";
    CanvasOperation2["SHOW_PAGE"] = "show_page";
  })(CanvasOperation || (CanvasOperation = {}));

  class CanvasManager {
    constructor(session) {
      this.session = session;
    }
    send(operation, options) {
      this.session.sendOneShot({
        type: MiniappRequestType.CANVAS,
        operation,
        options
      });
    }
    showText(text, options = {}) {
      this.send(CanvasOperation.SHOW_TEXT, { text, ...options });
    }
    showBitmap(data, options = {}) {
      this.send(CanvasOperation.SHOW_BITMAP, { data, ...options });
    }
    showPage(id, options = {}) {
      this.send(CanvasOperation.SHOW_PAGE, { id, ...options });
    }
    clear(options = {}) {
      this.send(CanvasOperation.CLEAR, options);
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/auth.js
  var DEFAULT_MIN_TTL_MS = 30000;

  class AuthModule {
    constructor(session) {
      this.session = session;
    }
    get current() {
      return this.session._getAuth();
    }
    get mentraUserId() {
      return this.current?.mentraUserId ?? null;
    }
    get oemId() {
      return this.current?.oemId ?? null;
    }
    async getToken(options = {}) {
      const auth = await this.session._waitForAuth(options.minTtlMs ?? DEFAULT_MIN_TTL_MS);
      return auth.token;
    }
    async getAuthHeader(options = {}) {
      return `Bearer ${await this.getToken(options)}`;
    }
    async fetch(input, init = {}) {
      const { minTtlMs, ...requestInit } = init;
      const token = await this.getToken({ minTtlMs });
      const headers = mergeHeaders(requestInit.headers, { Authorization: `Bearer ${token}` });
      return fetch(input, { ...requestInit, headers });
    }
    onUpdate(handler) {
      return this.session.on("auth", handler);
    }
  }
  function mergeHeaders(base, next) {
    const headers = {};
    if (Array.isArray(base)) {
      for (const [key, value] of base) {
        headers[key] = value;
      }
    } else if (typeof Headers !== "undefined" && base instanceof Headers) {
      base.forEach((value, key) => {
        headers[key] = value;
      });
    } else if (base && typeof base === "object") {
      for (const [key, value] of Object.entries(base)) {
        if (typeof value === "string")
          headers[key] = value;
      }
    }
    return { ...headers, ...next };
  }

  // ../../mobile/modules/miniapp/dist/modules/cloud.js
  var CLOUD_STATUS_STREAM = "_cloud_status";
  var DEFAULT_STATUS = {
    status: "disconnected",
    audioTransport: "none"
  };
  function normalizeCloudStatus(data) {
    if (!data || typeof data !== "object")
      return null;
    const raw = data;
    const status = raw.status;
    const audioTransport = raw.audioTransport;
    if (status !== "connected" && status !== "connecting" && status !== "reconnecting" && status !== "disconnected") {
      return null;
    }
    if (audioTransport !== "udp" && audioTransport !== "ws" && audioTransport !== "offline" && audioTransport !== "none") {
      return null;
    }
    return { status, audioTransport };
  }

  class CloudModule {
    constructor(session) {
      this.session = session;
      this.emitter = new import__.default;
      this.current = { ...DEFAULT_STATUS };
      this.session._subscribe(CLOUD_STATUS_STREAM, (data) => {
        const next = normalizeCloudStatus(data);
        if (!next)
          return;
        if (next.status === this.current.status && next.audioTransport === this.current.audioTransport)
          return;
        this.current = next;
        this.emitter.emit("status", { ...this.current });
      });
    }
    get status() {
      return { ...this.current };
    }
    get connected() {
      return this.current.status === "connected";
    }
    isConnected() {
      return this.connected;
    }
    onStatusChanged(handler) {
      handler({ ...this.current });
      this.emitter.on("status", handler);
      return () => {
        this.emitter.off("status", handler);
      };
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/dashboard.js
  class DashboardAPI {
    constructor(session) {
      this.session = session;
      this.warned = false;
    }
    setContent(mode, content) {
      if (!this.warned) {
        console.warn("[@mentra/miniapp] dashboard.setContent() is deferred in v1.");
        this.warned = true;
      }
      this.session.sendOneShot({
        type: MiniappRequestType.DASHBOARD_CONTENT_UPDATE,
        mode,
        content
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/display.js
  class DisplayManager {
    constructor(session) {
      this.session = session;
    }
    send(layout, options = {}) {
      const payloadLayout = options.breakMode && supportsBreakMode(layout) ? { ...layout, breakMode: options.breakMode } : layout;
      this.session.sendOneShot({
        type: MiniappRequestType.DISPLAY,
        view: options.view ?? "main",
        layout: payloadLayout,
        durationMs: options.durationMs
      });
    }
    showTextWall(text, options = {}) {
      this.send({ layoutType: "text_wall", text }, options);
    }
    showDoubleTextWall(topText, bottomText, options = {}) {
      this.send({ layoutType: "double_text_wall", topText, bottomText }, options);
    }
    showReferenceCard(title, text, options = {}) {
      this.send({ layoutType: "reference_card", title, text }, options);
    }
    showDashboardCard(leftText, rightText) {
      this.send({ layoutType: "dashboard_card", leftText, rightText }, { view: "dashboard" });
    }
    showBitmapView(data, options = {}) {
      const { x, y, width, height, ...display } = options;
      this.send({ layoutType: "bitmap_view", data, x, y, width, height }, display);
    }
    showTextAt(text, options = {}) {
      const { x, y, width, height, borderWidth, borderRadius, ...display } = options;
      this.send({ layoutType: "positioned_text", text, x, y, width, height, borderWidth, borderRadius }, display);
    }
    clear(view = "main") {
      this.send({ layoutType: "clear_view" }, { view });
    }
  }
  function supportsBreakMode(layout) {
    return layout.layoutType === "text_wall" || layout.layoutType === "double_text_wall" || layout.layoutType === "reference_card";
  }

  // ../../mobile/modules/miniapp/dist/modules/events.js
  class EventManager {
    constructor(session) {
      this.session = session;
      this.emitter = new import__.default;
      this.refCounts = new Map;
    }
    subscribe(stream, handler) {
      this.emitter.on(stream, handler);
      const isInternal = stream.startsWith("_");
      if (!isInternal) {
        const before = this.refCounts.get(stream) ?? 0;
        this.refCounts.set(stream, before + 1);
        if (before === 0) {
          this.sendSubscriptionUpdate();
        }
      }
      return () => {
        this.emitter.off(stream, handler);
        if (isInternal)
          return;
        const current = this.refCounts.get(stream) ?? 0;
        if (current <= 1) {
          this.refCounts.delete(stream);
          this.sendSubscriptionUpdate();
        } else {
          this.refCounts.set(stream, current - 1);
        }
      };
    }
    unsubscribeAll() {
      this.emitter.removeAllListeners();
      this.refCounts.clear();
      this.sendSubscriptionUpdate();
    }
    _forwardEvent(stream, data) {
      this.emitter.emit(stream, data);
      if (stream.startsWith("transcription:") && stream !== "transcription:auto") {
        this.emitter.emit("transcription:auto", data);
      } else if (stream.startsWith("translation:")) {
        const parts = stream.split(":");
        const patterns = new Set(["translation:auto"]);
        if (parts.length === 3) {
          const [, source, target] = parts;
          patterns.add("translation:*:*");
          patterns.add(`translation:*:${target}`);
          patterns.add(`translation:${source}:*`);
        }
        patterns.delete(stream);
        for (const pattern of patterns) {
          this.emitter.emit(pattern, data);
        }
      }
    }
    sendSubscriptionUpdate() {
      const subscriptions = Array.from(this.refCounts.keys()).map((stream) => stream === MiniappStreamType.LOCATION_UPDATE ? { stream: "location_stream", rate: "realtime" } : stream);
      this.session.sendOneShot({
        type: MiniappRequestType.SUBSCRIBE,
        subscriptions
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/glasses.js
  class GlassesModule {
    constructor(session) {
      this.session = session;
    }
    onBattery(handler) {
      return this.session._subscribe(MiniappStreamType.GLASSES_BATTERY, handler);
    }
    onConnection(handler) {
      return this.session._subscribe(MiniappStreamType.GLASSES_CONNECTION, handler);
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/heading.js
  class HeadingModule {
    constructor(session) {
      this.session = session;
    }
    get hasPermission() {
      return this.session._hasManifestPermission("LOCATION");
    }
    onUpdate(handler) {
      return this.session._subscribe(MiniappStreamType.HEADING_UPDATE, handler);
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/imu.js
  class ImuModule {
    constructor(session) {
      this.session = session;
    }
    onHeadPosition(handler) {
      return this.session._subscribe(MiniappStreamType.HEAD_POSITION, handler);
    }
    onAccel(handler) {
      return this.session._subscribe(MiniappStreamType.ACCEL_DATA, handler);
    }
    setEnabled(enabled) {
      return this.session.sendRequest({
        type: MiniappRequestType.IMU_SET_ENABLED,
        enabled
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/input.js
  class InputModule {
    constructor(session) {
      this.session = session;
    }
    onButtonPress(handler) {
      return this.session._subscribe(MiniappStreamType.BUTTON_PRESS, handler);
    }
    onTouch(gestureOrHandler, maybeHandler) {
      if (typeof gestureOrHandler === "function") {
        return this.session._subscribe(MiniappStreamType.TOUCH_EVENT, gestureOrHandler);
      }
      const handler = maybeHandler;
      const gestures = Array.isArray(gestureOrHandler) ? gestureOrHandler : [gestureOrHandler];
      if (gestures.length === 0)
        return () => {};
      const unsubs = [];
      for (const g of gestures) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TOUCH_EVENT}:${g}`, handler));
      }
      return () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/led.js
  class LedModule {
    constructor(session) {
      this.session = session;
    }
    async turnOn(options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.RGB_LED,
        action: "on",
        color: options.color ?? "red",
        ontime: options.ontime ?? 1000,
        offtime: options.offtime ?? 0,
        count: options.count ?? 1
      });
    }
    async turnOff() {
      return this.session.sendRequest({
        type: MiniappRequestType.RGB_LED,
        action: "off"
      });
    }
    async blink(color, ontime, offtime, count) {
      return this.turnOn({ color, ontime, offtime, count });
    }
    async solid(color, duration) {
      return this.turnOn({ color, ontime: duration, offtime: 0, count: 1 });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/location.js
  class LocationModule {
    constructor(session) {
      this.session = session;
    }
    get hasPermission() {
      return this.session._hasManifestPermission("LOCATION");
    }
    onUpdate(handler) {
      return this.session._subscribe(MiniappStreamType.LOCATION_UPDATE, handler);
    }
    getOnce() {
      return this.session.sendRequest({
        type: MiniappRequestType.LOCATION_POLL
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/mic.js
  class MicModule {
    constructor(session) {
      this.session = session;
      this.unsubs = new Set;
    }
    onVoiceActivity(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.VAD, handler));
    }
    onAudioChunk(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.AUDIO_CHUNK, handler));
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
    get hasPermission() {
      return this.session._hasManifestPermission("MICROPHONE");
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/pivots/geometry.js
  var TURN_THRESHOLD_DEG = 15;
  var SAME_DIR_MERGE_M = 25;
  var RDP_EPSILON_M = 5;
  var MIN_BEND_PER_POINT_DEG = 10;
  var STRAIGHT_SEGMENT_BREAK_M = 1;
  var INTERSECTION_CLUSTER_M = 30;
  function haversineMeters(a, b) {
    const R = 6371000;
    const toRad = (d) => d * Math.PI / 180;
    const dLat = toRad(b.lat - a.lat);
    const dLng = toRad(b.lng - a.lng);
    const lat1 = toRad(a.lat);
    const lat2 = toRad(b.lat);
    const x = Math.sin(dLat / 2) ** 2 + Math.sin(dLng / 2) ** 2 * Math.cos(lat1) * Math.cos(lat2);
    return 2 * R * Math.asin(Math.sqrt(x));
  }
  function bearingDeg(a, b) {
    const toRad = (d) => d * Math.PI / 180;
    const toDeg = (r) => r * 180 / Math.PI;
    const lat1 = toRad(a.lat);
    const lat2 = toRad(b.lat);
    const dLng = toRad(b.lng - a.lng);
    const y = Math.sin(dLng) * Math.cos(lat2);
    const x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLng);
    return (toDeg(Math.atan2(y, x)) + 360) % 360;
  }
  function signedAngleDiff(target, actual) {
    return (target - actual + 540) % 360 - 180;
  }
  function rdpSimplify(points, epsilonMeters) {
    if (points.length < 3)
      return points.map((_, i) => i);
    const keep = new Array(points.length).fill(false);
    keep[0] = true;
    keep[points.length - 1] = true;
    const stack = [[0, points.length - 1]];
    while (stack.length) {
      const [lo, hi] = stack.pop();
      let maxDist = 0;
      let maxIdx = -1;
      for (let i = lo + 1;i < hi; i++) {
        const d = perpDistMeters(points[i], points[lo], points[hi]);
        if (d > maxDist) {
          maxDist = d;
          maxIdx = i;
        }
      }
      if (maxIdx !== -1 && maxDist > epsilonMeters) {
        keep[maxIdx] = true;
        stack.push([lo, maxIdx], [maxIdx, hi]);
      }
    }
    const out = [];
    for (let i = 0;i < keep.length; i++)
      if (keep[i])
        out.push(i);
    return out;
  }
  function perpDistMeters(p, a, b) {
    const mPerDegLat = 111320;
    const mPerDegLng = 111320 * Math.cos(a.lat * Math.PI / 180);
    const bx = (b.lng - a.lng) * mPerDegLng;
    const by = (b.lat - a.lat) * mPerDegLat;
    const px = (p.lng - a.lng) * mPerDegLng;
    const py = (p.lat - a.lat) * mPerDegLat;
    const dx = bx;
    const dy = by;
    const len = Math.sqrt(dx * dx + dy * dy);
    if (len === 0)
      return Math.sqrt(px * px + py * py);
    return Math.abs(dx * -py - -px * dy) / len;
  }
  function extractPivots(rawPoints) {
    if (rawPoints.length < 3)
      return [];
    const keptIdx = rdpSimplify(rawPoints, RDP_EPSILON_M);
    const simplified = keptIdx.map((i) => rawPoints[i]);
    if (simplified.length < 3)
      return [];
    const deltas = [];
    for (let i = 1;i < simplified.length - 1; i++) {
      const inBearing = bearingDeg(simplified[i - 1], simplified[i]);
      const outBearing = bearingDeg(simplified[i], simplified[i + 1]);
      deltas.push(signedAngleDiff(outBearing, inBearing));
    }
    const candidates = [];
    let runStart = -1;
    let runSum = 0;
    let runSign = 0;
    const flushRun = (endExclusive) => {
      if (runStart === -1)
        return;
      if (Math.abs(runSum) >= TURN_THRESHOLD_DEG) {
        let bestIdx = runStart;
        let bestAbs = 0;
        for (let k = runStart;k < endExclusive; k++) {
          const a = Math.abs(deltas[k]);
          if (a > bestAbs) {
            bestAbs = a;
            bestIdx = k;
          }
        }
        const simplifiedIdx = bestIdx + 1;
        candidates.push({
          lat: simplified[simplifiedIdx].lat,
          lng: simplified[simplifiedIdx].lng,
          direction: runSum > 0 ? "right" : "left",
          simplifiedRouteIndex: simplifiedIdx,
          rawRouteIndex: keptIdx[simplifiedIdx],
          headingDelta: runSum
        });
      }
      runStart = -1;
      runSum = 0;
      runSign = 0;
    };
    let metersSinceLastBend = 0;
    for (let k = 0;k < deltas.length; k++) {
      const d = deltas[k];
      const sign = d > 0 ? 1 : d < 0 ? -1 : 0;
      const segLen = haversineMeters(simplified[k + 1], simplified[k + 2]);
      if (sign === 0 || Math.abs(d) < MIN_BEND_PER_POINT_DEG) {
        if (runStart !== -1) {
          if (sign === runSign || sign === 0)
            runSum += d;
          metersSinceLastBend += segLen;
          if (metersSinceLastBend >= STRAIGHT_SEGMENT_BREAK_M) {
            flushRun(k + 1);
          }
        }
        continue;
      }
      if (runStart === -1) {
        runStart = k;
        runSum = d;
        runSign = sign;
        metersSinceLastBend = segLen;
      } else if (sign === runSign) {
        if (metersSinceLastBend >= STRAIGHT_SEGMENT_BREAK_M) {
          flushRun(k);
          runStart = k;
          runSum = d;
          runSign = sign;
        } else {
          runSum += d;
        }
        metersSinceLastBend = segLen;
      } else {
        flushRun(k);
        runStart = k;
        runSum = d;
        runSign = sign;
        metersSinceLastBend = segLen;
      }
    }
    flushRun(deltas.length);
    const merged = [];
    for (const p of candidates) {
      const last = merged[merged.length - 1];
      if (last && last.direction === p.direction && haversineMeters({ lat: last.lat, lng: last.lng }, { lat: p.lat, lng: p.lng }) < SAME_DIR_MERGE_M) {
        if (Math.abs(p.headingDelta) > Math.abs(last.headingDelta)) {
          merged[merged.length - 1] = p;
        }
        continue;
      }
      merged.push(p);
    }
    const clustered = [];
    for (const p of merged) {
      const last = clustered[clustered.length - 1];
      if (last && haversineMeters({ lat: last.lat, lng: last.lng }, { lat: p.lat, lng: p.lng }) < INTERSECTION_CLUSTER_M) {
        const netDelta = last.headingDelta + p.headingDelta;
        const anchor = Math.abs(p.headingDelta) > Math.abs(last.headingDelta) ? p : last;
        clustered[clustered.length - 1] = {
          ...anchor,
          direction: netDelta > 0 ? "right" : "left",
          headingDelta: netDelta
        };
        continue;
      }
      clustered.push(p);
    }
    return clustered.filter((p) => Math.abs(p.headingDelta) >= TURN_THRESHOLD_DEG);
  }
  function cumulativeDistances(points) {
    const out = new Array(points.length);
    out[0] = 0;
    for (let i = 1;i < points.length; i++) {
      out[i] = out[i - 1] + haversineMeters(points[i - 1], points[i]);
    }
    return out;
  }

  // ../../mobile/modules/miniapp/dist/modules/pivots/instructions.js
  var DIRECTION_WORDS = new Set(["right", "left", "the right", "the left", "north", "south", "east", "west"]);
  var MANEUVER_VERBS = /\b(turn|slight|sharp|continue|head|merge|exit|uturn|u-turn|then|keep)\b/i;
  function roadNameFromInstruction(instruction) {
    if (!instruction)
      return null;
    const firstLine = instruction.split(`
`)[0] ?? "";
    const m = firstLine.match(/\bonto\s+(.+)$/i);
    let raw = (m ? m[1] : "").trim();
    if (!raw)
      return null;
    if (raw.includes(","))
      return null;
    raw = raw.split(/\s+(?:toward|towards|to|and|then|for)\b/i)[0]?.trim() ?? "";
    raw = raw.replace(/\s+#.*$/, "").trim();
    if (!raw)
      return null;
    if (DIRECTION_WORDS.has(raw.toLowerCase()))
      return null;
    if (MANEUVER_VERBS.test(raw))
      return null;
    return raw;
  }
  var ROAD_SUFFIXES = /\b(st|street|ave|avenue|blvd|boulevard|rd|road|dr|drive|ln|lane|way|ct|court|pl|place|ter|terrace|hwy|highway)\b\.?/g;
  function normalizeRoad(road) {
    return road.toLowerCase().replace(ROAD_SUFFIXES, "").replace(/[^a-z0-9 ]/g, "").replace(/\s+/g, " ").trim();
  }
  function sameRoad(a, b) {
    return normalizeRoad(a) === normalizeRoad(b);
  }
  function turnDirection(maneuver) {
    if (!maneuver)
      return null;
    const m = maneuver.toUpperCase();
    if (m.includes("LEFT"))
      return "left";
    if (m.includes("RIGHT"))
      return "right";
    return null;
  }
  var PROBE_METERS = 22;
  function signedBendAt(points, junction) {
    if (points.length < 3)
      return null;
    let mid = 0;
    let bestDist = Infinity;
    for (let i = 0;i < points.length; i++) {
      const d = haversineMeters(points[i], junction);
      if (d < bestDist) {
        bestDist = d;
        mid = i;
      }
    }
    let before = mid;
    while (before > 0 && haversineMeters(points[before], points[mid]) < PROBE_METERS)
      before--;
    let after = mid;
    while (after < points.length - 1 && haversineMeters(points[after], points[mid]) < PROBE_METERS)
      after++;
    if (before === mid || after === mid)
      return null;
    const incoming = bearingDeg(points[before], points[mid]);
    const outgoing = bearingDeg(points[mid], points[after]);
    return signedAngleDiff(outgoing, incoming);
  }
  var MIN_TURN_ANGLE_DEG = 30;
  function extractPivotsFromComputedSteps(steps, polyline) {
    if (!steps || steps.length < 2)
      return [];
    const initial = steps.map((s, i) => ({
      stepIdx: i,
      name: s.road ?? roadNameFromInstruction(s.instruction)
    }));
    let annotated = initial;
    for (let pass = 0;pass < 4; pass++) {
      const collapsed = [];
      for (let i = 0;i < annotated.length; i++) {
        const prev = collapsed[collapsed.length - 1];
        const here = annotated[i];
        const next = annotated[i + 1];
        if (prev?.name && next?.name && here.name && !sameRoad(prev.name, here.name) && sameRoad(prev.name, next.name)) {
          continue;
        }
        collapsed.push(here);
      }
      if (collapsed.length === annotated.length)
        break;
      annotated = collapsed;
    }
    const out = [];
    for (let i = 0;i < annotated.length - 1; i++) {
      const here = annotated[i];
      const nextAnn = annotated[i + 1];
      const s = steps[here.stepIdx];
      const next = steps[nextAnn.stepIdx];
      const fromRoad = here.name;
      const toRoad = nextAnn.name;
      if (!fromRoad)
        continue;
      if (toRoad && sameRoad(fromRoad, toRoad))
        continue;
      if (!Number.isFinite(s.endLat) || !Number.isFinite(s.endLng))
        continue;
      const junction = { lat: s.endLat, lng: s.endLng };
      const signedBend = signedBendAt(polyline, junction);
      if (signedBend != null && Math.abs(signedBend) < MIN_TURN_ANGLE_DEG)
        continue;
      const geomDir = signedBend == null ? null : signedBend > 0 ? "right" : "left";
      const direction = geomDir ?? turnDirection(next.maneuver);
      out.push({
        lat: s.endLat,
        lng: s.endLng,
        fromRoad,
        toRoad,
        direction,
        maneuver: next.maneuver ?? (direction === "left" ? "TURN_LEFT" : "TURN_RIGHT")
      });
    }
    return out;
  }

  // ../../mobile/modules/miniapp/dist/modules/pivots/engine.js
  var RADIUS_DEFAULTS_M = {
    walking: 7,
    cycling: 15,
    driving: 40,
    two_wheeler: 25
  };
  var APPROACH_DEFAULTS_M = {
    walking: 100,
    cycling: 300,
    driving: 800,
    two_wheeler: 500
  };
  var NON_TURN_MANEUVERS = new Set(["STRAIGHT", "NAME_CHANGE", "DEPART", "ARRIVE"]);
  var STEP_MATCH_MAX_INDEX_DELTA = 8;
  var ON_ROUTE_PERP_TOLERANCE_M = 50;

  class PivotEngine {
    constructor(mode, opts) {
      this.pivots = [];
      this.states = [];
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = [];
      this.cumulative = [];
      this.roadNameResolver = null;
      this.routeGeneration = 0;
      this.subscribers = new Set;
      this.opts = resolveOptions(mode, opts);
    }
    updateOptions(mode, opts) {
      this.opts = resolveOptions(mode, opts);
      for (const p of this.pivots) {
        p.radiusMeters = this.opts.radiusMeters;
      }
    }
    setRoadNameResolver(resolver) {
      this.roadNameResolver = resolver;
    }
    reset() {
      if (this.activePivotIndex !== null) {
        const active = this.pivots[this.activePivotIndex];
        if (active)
          this.emit({ kind: "exited", pivot: active });
      }
      this.pivots = [];
      this.states = [];
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = [];
      this.cumulative = [];
    }
    setRouteFromComputedSteps(route, computedSteps) {
      const points = route.points ?? [];
      if (this.activePivotIndex !== null) {
        const active = this.pivots[this.activePivotIndex];
        if (active)
          this.emit({ kind: "exited", pivot: active });
      }
      if (points.length < 3 || !computedSteps || computedSteps.length < 2) {
        this.setRoute(route, null);
        return;
      }
      const cumulative = cumulativeDistances(points);
      const instructionPivots = extractPivotsFromComputedSteps(computedSteps, points);
      console.log(`[PivotEngine] setRouteFromComputedSteps: steps=${computedSteps.length} instructionPivots=${instructionPivots.length}` + (instructionPivots.length > 0 ? `
` + instructionPivots.map((p, i) => `  pivot[${i}] ${p.fromRoad ?? "—"} → ${p.toRoad ?? "—"} dir=${p.direction} @ (${p.lat.toFixed(5)}, ${p.lng.toFixed(5)})`).join(`
`) : ""));
      if (instructionPivots.length === 0) {
        console.log(`[PivotEngine] falling back to setRoute (geometry) — input steps:
` + computedSteps.map((s, i) => `  step[${i}] road=${s.road ?? "—"} maneuver=${s.maneuver ?? "—"} @ (${s.lat.toFixed(5)}, ${s.lng.toFixed(5)}) → (${s.endLat.toFixed(5)}, ${s.endLng.toFixed(5)})`).join(`
`));
        this.setRoute(route, null);
        return;
      }
      const pivots = instructionPivots.map((p, i) => ({
        index: i,
        lat: p.lat,
        lng: p.lng,
        direction: p.direction === "left" ? "left" : "right",
        fromRoad: p.fromRoad,
        toRoad: p.toRoad,
        maneuver: p.maneuver,
        distanceAlongRouteMeters: alongRouteAtCoord(points, cumulative, { lat: p.lat, lng: p.lng }),
        radiusMeters: this.opts.radiusMeters
      }));
      pivots.sort((a, b) => a.distanceAlongRouteMeters - b.distanceAlongRouteMeters);
      for (let i = 0;i < pivots.length; i++)
        pivots[i].index = i;
      this.pivots = pivots;
      this.states = pivots.map(() => ({ approachingFired: false, entered: false, exited: false }));
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = points;
      this.cumulative = cumulative;
      this.routeGeneration++;
      this._resolveMissingRoadNames(this.routeGeneration);
    }
    setRoute(route, _userPosition) {
      const points = route.points ?? [];
      const steps = route.steps ?? [];
      if (this.activePivotIndex !== null) {
        const active = this.pivots[this.activePivotIndex];
        if (active)
          this.emit({ kind: "exited", pivot: active });
      }
      if (points.length < 3) {
        this.pivots = [];
        this.states = [];
        this.cursor = 0;
        this.activePivotIndex = null;
        this.points = [];
        this.cumulative = [];
        return;
      }
      const cumulative = cumulativeDistances(points);
      const raw = extractPivots(points);
      const stepIndex = buildStepIndex(steps);
      const pivots = [];
      for (let i = 0;i < raw.length; i++) {
        const r = raw[i];
        const matched = matchStep(r, stepIndex);
        if (matched && NON_TURN_MANEUVERS.has(matched.maneuver)) {
          continue;
        }
        pivots.push({
          index: pivots.length,
          lat: r.lat,
          lng: r.lng,
          direction: r.direction,
          fromRoad: matched?.fromRoad ?? null,
          toRoad: matched?.toRoad ?? null,
          maneuver: matched?.maneuver ?? (r.direction === "left" ? "TURN_LEFT" : "TURN_RIGHT"),
          distanceAlongRouteMeters: distanceAtIndex(cumulative, r.rawRouteIndex),
          radiusMeters: this.opts.radiusMeters
        });
      }
      pivots.sort((a, b) => a.distanceAlongRouteMeters - b.distanceAlongRouteMeters);
      for (let i = 0;i < pivots.length; i++)
        pivots[i].index = i;
      this.pivots = pivots;
      this.states = pivots.map(() => ({ approachingFired: false, entered: false, exited: false }));
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = points;
      this.cumulative = cumulative;
      this.routeGeneration++;
      this._resolveMissingRoadNames(this.routeGeneration);
    }
    async _resolveMissingRoadNames(generation) {
      const pivots = this.pivots;
      if (pivots.length === 0)
        return;
      for (let i = 0;i < pivots.length - 1; i++) {
        const here = pivots[i];
        const next = pivots[i + 1];
        if (!here.toRoad && next.fromRoad)
          here.toRoad = next.fromRoad;
        if (!next.fromRoad && here.toRoad)
          next.fromRoad = here.toRoad;
      }
      for (let i = pivots.length - 1;i > 0; i--) {
        const here = pivots[i];
        const prev = pivots[i - 1];
        if (!prev.toRoad && here.fromRoad)
          prev.toRoad = here.fromRoad;
        if (!here.fromRoad && prev.toRoad)
          here.fromRoad = prev.toRoad;
      }
      const resolver = this.roadNameResolver;
      if (!resolver)
        return;
      if (this.points.length < 2)
        return;
      const SAMPLE_OFFSETS_M = [18, 30, 50, 80];
      const points = this.points;
      const cumulative = this.cumulative;
      const geocodeWithExpansion = async (pivotAlong, direction) => {
        for (const offset of SAMPLE_OFFSETS_M) {
          const sample = sampleAlongRoute(points, cumulative, pivotAlong + direction * offset);
          if (!sample)
            continue;
          try {
            const road = await resolver(sample);
            if (generation !== this.routeGeneration)
              return null;
            if (road)
              return road;
          } catch {}
        }
        return null;
      };
      const tasks = [];
      for (const pivot of pivots) {
        if (pivot.fromRoad && pivot.toRoad)
          continue;
        const along = pivot.distanceAlongRouteMeters;
        if (!pivot.fromRoad) {
          tasks.push(geocodeWithExpansion(along, -1).then((road) => {
            if (generation !== this.routeGeneration)
              return;
            if (road && !pivot.fromRoad)
              pivot.fromRoad = road;
          }));
        }
        if (!pivot.toRoad) {
          tasks.push(geocodeWithExpansion(along, 1).then((road) => {
            if (generation !== this.routeGeneration)
              return;
            if (road && !pivot.toRoad)
              pivot.toRoad = road;
          }));
        }
      }
      await Promise.all(tasks);
      if (generation !== this.routeGeneration)
        return;
      for (let i = 0;i < pivots.length - 1; i++) {
        const here = pivots[i];
        const next = pivots[i + 1];
        if (!here.toRoad && next.fromRoad)
          here.toRoad = next.fromRoad;
        if (!next.fromRoad && here.toRoad)
          next.fromRoad = here.toRoad;
      }
    }
    onLocationUpdate(coords) {
      if (this.pivots.length === 0)
        return;
      const projection = projectOntoPolyline(this.points, this.cumulative, coords);
      const useAlongPath = projection !== null && projection.perpMeters <= ON_ROUTE_PERP_TOLERANCE_M;
      const userAlong = projection?.alongMeters ?? 0;
      for (let i = this.cursor;i < this.pivots.length; i++) {
        const pivot = this.pivots[i];
        const state = this.states[i];
        if (state.exited)
          continue;
        const aheadDelta = pivot.distanceAlongRouteMeters - userAlong;
        const distanceToPivot = useAlongPath ? Math.abs(aheadDelta) : haversineMeters(coords, { lat: pivot.lat, lng: pivot.lng });
        const approaching = !state.approachingFired && distanceToPivot <= this.opts.approachThresholdMeters && (!useAlongPath || aheadDelta >= -this.opts.radiusMeters);
        if (approaching) {
          state.approachingFired = true;
          this.emit({ kind: "approaching", pivot, distanceMeters: distanceToPivot });
        }
        if (!state.entered && distanceToPivot <= pivot.radiusMeters) {
          state.entered = true;
          this.activePivotIndex = i;
          this.emit({ kind: "entered", pivot });
        }
        const movedPastOnPath = useAlongPath && aheadDelta < -pivot.radiusMeters;
        if ((state.entered && distanceToPivot > pivot.radiusMeters || !state.entered && movedPastOnPath) && !state.exited) {
          if (!state.entered) {
            state.entered = true;
            this.activePivotIndex = i;
            this.emit({ kind: "entered", pivot });
          }
          state.exited = true;
          if (this.activePivotIndex === i)
            this.activePivotIndex = null;
          this.emit({ kind: "exited", pivot });
          if (this.cursor <= i)
            this.cursor = i + 1;
        }
        if (!state.approachingFired && distanceToPivot > this.opts.approachThresholdMeters * 2) {
          break;
        }
      }
    }
    subscribe(fn) {
      this.subscribers.add(fn);
      return () => {
        this.subscribers.delete(fn);
      };
    }
    getPivots() {
      return this.pivots.slice();
    }
    getActivePivot() {
      if (this.activePivotIndex === null)
        return null;
      return this.pivots[this.activePivotIndex] ?? null;
    }
    getUpcomingPivot() {
      for (let i = this.cursor;i < this.pivots.length; i++) {
        if (!this.states[i].exited)
          return this.pivots[i];
      }
      return null;
    }
    emit(event) {
      for (const fn of this.subscribers) {
        try {
          fn(event);
        } catch (err) {
          console.error("[PivotEngine] subscriber threw:", err);
        }
      }
    }
  }
  function resolveOptions(mode, opts) {
    return {
      radiusMeters: opts?.radiusMeters ?? RADIUS_DEFAULTS_M[mode] ?? RADIUS_DEFAULTS_M.walking,
      approachThresholdMeters: opts?.approachThresholdMeters ?? APPROACH_DEFAULTS_M[mode] ?? APPROACH_DEFAULTS_M.walking
    };
  }
  function projectOntoPolyline(points, cumulative, user) {
    if (points.length < 2 || cumulative.length !== points.length)
      return null;
    const mPerDegLat = 111320;
    const mPerDegLng = 111320 * Math.cos(user.lat * Math.PI / 180);
    const ux = user.lng * mPerDegLng;
    const uy = user.lat * mPerDegLat;
    let bestPerp = Number.POSITIVE_INFINITY;
    let bestAlong = 0;
    for (let i = 0;i < points.length - 1; i++) {
      const a = points[i];
      const b = points[i + 1];
      const ax = a.lng * mPerDegLng;
      const ay = a.lat * mPerDegLat;
      const bx = b.lng * mPerDegLng;
      const by = b.lat * mPerDegLat;
      const dx = bx - ax;
      const dy = by - ay;
      const segLen2 = dx * dx + dy * dy;
      const t = segLen2 > 0 ? Math.max(0, Math.min(1, ((ux - ax) * dx + (uy - ay) * dy) / segLen2)) : 0;
      const px = ax + t * dx;
      const py = ay + t * dy;
      const perp = Math.hypot(ux - px, uy - py);
      if (perp < bestPerp) {
        bestPerp = perp;
        const segLen = Math.sqrt(segLen2);
        bestAlong = cumulative[i] + t * segLen;
      }
    }
    if (!Number.isFinite(bestPerp))
      return null;
    return { perpMeters: bestPerp, alongMeters: bestAlong };
  }
  function alongRouteAtCoord(points, cumulative, coord) {
    const projection = projectOntoPolyline(points, cumulative, coord);
    return projection?.alongMeters ?? 0;
  }
  function sampleAlongRoute(points, cumulative, targetMeters) {
    if (points.length < 2 || cumulative.length !== points.length)
      return null;
    const total = cumulative[cumulative.length - 1];
    if (!Number.isFinite(targetMeters))
      return null;
    if (targetMeters <= 0)
      return { lat: points[0].lat, lng: points[0].lng };
    if (targetMeters >= total) {
      const last = points[points.length - 1];
      return { lat: last.lat, lng: last.lng };
    }
    let lo = 0;
    let hi = cumulative.length - 1;
    while (lo + 1 < hi) {
      const mid = lo + hi >>> 1;
      if (cumulative[mid] <= targetMeters)
        lo = mid;
      else
        hi = mid;
    }
    const segStart = cumulative[lo];
    const segEnd = cumulative[hi];
    const segLen = segEnd - segStart;
    const t = segLen > 0 ? (targetMeters - segStart) / segLen : 0;
    const a = points[lo];
    const b = points[hi];
    return { lat: a.lat + (b.lat - a.lat) * t, lng: a.lng + (b.lng - a.lng) * t };
  }
  function distanceAtIndex(cumulative, idx) {
    if (cumulative.length === 0)
      return 0;
    if (idx < 0)
      return 0;
    if (idx >= cumulative.length)
      return cumulative[cumulative.length - 1];
    return cumulative[idx];
  }
  function buildStepIndex(steps) {
    if (!steps.length)
      return [];
    return steps.slice().sort((a, b) => a.routeIndex - b.routeIndex);
  }
  function matchStep(raw, stepIndex) {
    if (stepIndex.length < 2)
      return null;
    let bestJ = -1;
    let bestDelta = Number.POSITIVE_INFINITY;
    for (let i = 1;i < stepIndex.length; i++) {
      const delta = Math.abs(stepIndex[i].routeIndex - raw.rawRouteIndex);
      if (delta <= bestDelta) {
        bestDelta = delta;
        bestJ = i;
      }
    }
    if (bestJ < 1)
      return null;
    if (bestDelta > STEP_MATCH_MAX_INDEX_DELTA)
      return null;
    const SHORT_TRANSIT_METERS = 25;
    const finalIndex = stepIndex.length - 1;
    let j = bestJ;
    while (j < finalIndex - 1 && stepIndex[j].distanceMeters > 0 && stepIndex[j].distanceMeters < SHORT_TRANSIT_METERS) {
      j++;
    }
    if (j >= finalIndex)
      j = finalIndex - 1;
    const fromStep = stepIndex[bestJ - 1];
    const toStep = stepIndex[j];
    return {
      fromRoad: fromStep.road ?? null,
      toRoad: toStep.road ?? null,
      maneuver: fromStep.maneuver
    };
  }

  // ../../mobile/modules/miniapp/dist/modules/navigation.js
  class NavigationModule {
    constructor(session) {
      this.session = session;
      this._pivots = new PivotEngine("walking", undefined);
      this._tripUnsubs = [];
      this._tripStops = null;
      this._tripMode = "walking";
      this._tripAvoid = undefined;
      this._computeRouteSeq = 0;
      this._lastUserPosition = null;
      this._pivots.setRoadNameResolver(async (coord) => {
        try {
          const result = await this.reverseGeocodeRoad(coord);
          if (!result.ok)
            return null;
          return result.road ?? null;
        } catch {
          return null;
        }
      });
    }
    get hasPermission() {
      return this.session._hasManifestPermission("LOCATION");
    }
    requestPermission() {
      if (!this.hasPermission) {
        return Promise.resolve({
          ok: false,
          accepted: false,
          error: "LOCATION permission not declared in miniapp.json (required for navigation.requestPermission)."
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_REQUEST_PERMISSION
      });
    }
    async start(opts) {
      if (!this.hasPermission) {
        return {
          ok: false,
          error: "LOCATION permission not declared in miniapp.json (required for navigation.start)."
        };
      }
      const stops = normalizeStops(opts);
      const mode = opts.mode ?? "driving";
      this._tripStops = stops.length > 0 ? stops : null;
      this._tripMode = mode;
      this._tripAvoid = opts.avoid;
      this._attachPivotTrackingForTrip(mode, opts.pivots);
      const failStart = (error) => {
        this._detachPivotTracking();
        return { ok: false, error };
      };
      if (stops.length === 0) {
        return failStart("navigation.start: no stops");
      }
      let origin = this._lastUserPosition;
      if (!origin) {
        try {
          const fix = await this.session.location.getOnce();
          origin = { lat: fix.lat, lng: fix.lng };
          this._lastUserPosition = origin;
        } catch (err) {
          return failStart(`navigation.start: no GPS fix (${err instanceof Error ? err.message : String(err)})`);
        }
      }
      const restResult = await this.computeRoute({
        origin,
        stops,
        mode,
        avoid: opts.avoid
      });
      if (!restResult.ok || !restResult.routes || restResult.routes.length === 0) {
        return failStart(restResult.error ?? "computeRoute failed");
      }
      const restRoute = restResult.routes[0];
      const nativeResult = await this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_START,
        lat: stops[0]?.lat,
        lng: stops[0]?.lng,
        stops,
        mode,
        avoid: opts.avoid,
        simulate: opts.simulate ?? false,
        speedMultiplier: opts.speedMultiplier ?? 5,
        missedTurnRerouteMeters: opts.missedTurnRerouteMeters
      });
      if (!nativeResult.ok) {
        this._detachPivotTracking();
        return nativeResult;
      }
      const syntheticRoute = buildNavRouteFromComputed(restRoute);
      this.session.events._forwardEvent(MiniappStreamType.NAVIGATION_ROUTE, syntheticRoute);
      return nativeResult;
    }
    stop() {
      this._detachPivotTracking();
      this.session.sendOneShot({ type: MiniappRequestType.NAVIGATION_STOP });
    }
    get dev() {
      return {
        deviate: (offsetMeters = 20) => {
          this.session.sendOneShot({
            type: MiniappRequestType.NAVIGATION_DEVIATE,
            offsetMeters
          });
        },
        setWrongSidewalkOffset: (enabled) => {
          this.session.sendOneShot({
            type: MiniappRequestType.NAVIGATION_SET_WRONG_SIDEWALK,
            enabled
          });
        },
        setSkipCrossings: (enabled) => {
          this.session.sendOneShot({
            type: MiniappRequestType.NAVIGATION_SET_SKIP_CROSSINGS,
            enabled
          });
        }
      };
    }
    onUpdate(handler) {
      return this.session._subscribe(MiniappStreamType.NAVIGATION_UPDATE, handler);
    }
    onRoute(handler) {
      return this.session._subscribe(MiniappStreamType.NAVIGATION_ROUTE, handler);
    }
    async getState() {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_GET_STATE
      });
      return result.ok ? result.state ?? null : null;
    }
    computeRoute(opts) {
      if (!this.hasPermission) {
        return Promise.resolve({
          ok: false,
          error: "LOCATION permission not declared in miniapp.json (required for navigation.computeRoute)."
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_COMPUTE_ROUTE,
        origin: opts.origin,
        stops: opts.stops,
        mode: opts.mode ?? "driving",
        avoid: opts.avoid,
        alternatives: opts.alternatives ?? 1
      });
    }
    reverseGeocodeRoad(coord) {
      if (!this.hasPermission) {
        return Promise.resolve({
          ok: false,
          error: "LOCATION permission not declared in miniapp.json (required for reverseGeocodeRoad)."
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_REVERSE_GEOCODE,
        lat: coord.lat,
        lng: coord.lng
      });
    }
    onPivot(handler) {
      return this._pivots.subscribe(handler);
    }
    getPivots() {
      return this._pivots.getPivots();
    }
    getActivePivot() {
      return this._pivots.getActivePivot();
    }
    getUpcomingPivot() {
      return this._pivots.getUpcomingPivot();
    }
    _attachPivotTrackingForTrip(mode, opts) {
      this._detachPivotTracking();
      this._pivots.reset();
      this._pivots.updateOptions(mode, opts);
      this._tripUnsubs.push(this.onRoute((route) => {
        if (route.steps && route.steps.length > 0) {
          const tail = route.points[route.points.length - 1];
          const computedSteps = route.steps.map((s, i) => {
            const next = route.steps?.[i + 1];
            const endLat = next ? next.lat : tail?.lat ?? s.lat;
            const endLng = next ? next.lng : tail?.lng ?? s.lng;
            return {
              lat: s.lat,
              lng: s.lng,
              endLat,
              endLng,
              distanceMeters: s.distanceMeters,
              maneuver: s.maneuver,
              road: s.road ?? undefined
            };
          });
          this._pivots.setRouteFromComputedSteps(route, computedSteps);
          return;
        }
        this._pivots.setRoute(route, null);
        const seq = ++this._computeRouteSeq;
        this._issueComputeRouteForTrip(route).then((result) => {
          if (seq !== this._computeRouteSeq)
            return;
          const computedSteps = result?.routes?.[0]?.steps;
          if (computedSteps && computedSteps.length > 0) {
            this._pivots.setRouteFromComputedSteps(route, computedSteps);
          }
        }).catch((err) => {
          console.warn("[NavigationModule] computeRoute for pivots failed:", err);
        });
      }));
      this._tripUnsubs.push(this.onUpdate((update) => {
        if (update.kind === "arrived") {
          this._pivots.reset();
          return;
        }
        if (update.kind === "rerouting") {
          this._reissueRouteForReroute();
        }
      }));
      this._tripUnsubs.push(this.session.location.onUpdate((loc) => {
        this._lastUserPosition = { lat: loc.lat, lng: loc.lng };
        this._pivots.onLocationUpdate({ lat: loc.lat, lng: loc.lng });
      }));
    }
    async _issueComputeRouteForTrip(route) {
      if (!this._tripStops || this._tripStops.length === 0)
        return null;
      const origin = this._lastUserPosition ?? (route?.points && route.points[0] ? { lat: route.points[0].lat, lng: route.points[0].lng } : null);
      if (!origin)
        return null;
      return this.computeRoute({
        origin,
        stops: this._tripStops,
        mode: this._tripMode,
        avoid: this._tripAvoid
      });
    }
    _reissueRouteForReroute() {
      if (!this._tripStops || this._tripStops.length === 0)
        return;
      const seq = ++this._computeRouteSeq;
      this._issueComputeRouteForTrip().then((result) => {
        if (seq !== this._computeRouteSeq)
          return;
        const computed = result?.routes?.[0];
        if (!computed)
          return;
        const syntheticRoute = buildNavRouteFromComputed(computed);
        this.session.events._forwardEvent(MiniappStreamType.NAVIGATION_ROUTE, syntheticRoute);
      }).catch((err) => {
        console.warn("[NavigationModule] reroute computeRoute failed:", err);
      });
    }
    _detachPivotTracking() {
      for (const unsub of this._tripUnsubs) {
        try {
          unsub();
        } catch (err) {
          console.warn("[NavigationModule] pivot-tracking unsubscribe threw:", err);
        }
      }
      this._tripUnsubs = [];
      this._pivots.reset();
      this._tripStops = null;
      this._tripAvoid = undefined;
      this._computeRouteSeq++;
      this._lastUserPosition = null;
    }
  }
  function normalizeStops(opts) {
    if (opts.stops && opts.stops.length > 0) {
      return opts.stops;
    }
    if (typeof opts.lat === "number" && typeof opts.lng === "number") {
      return [{ lat: opts.lat, lng: opts.lng }];
    }
    return [];
  }
  function buildNavRouteFromComputed(computed) {
    const points = computed.points ?? [];
    const steps = (computed.steps ?? []).map((s) => {
      let routeIndex = 0;
      let best = Infinity;
      for (let i = 0;i < points.length; i++) {
        const dLat = points[i].lat - s.lat;
        const dLng = points[i].lng - s.lng;
        const d = dLat * dLat + dLng * dLng;
        if (d < best) {
          best = d;
          routeIndex = i;
        }
      }
      return {
        lat: s.lat,
        lng: s.lng,
        routeIndex,
        road: s.road ?? null,
        maneuver: s.maneuver ?? "STRAIGHT",
        distanceMeters: s.distanceMeters
      };
    });
    return {
      points,
      totalDistanceMeters: computed.totalDistanceMeters,
      totalDurationSeconds: computed.totalDurationSeconds,
      steps: steps.length > 0 ? steps : undefined
    };
  }

  // ../../mobile/modules/miniapp/dist/modules/permissions.js
  class PermissionsModule {
    constructor(session) {
      this.session = session;
    }
    has(type) {
      return this.session._getPermissions()[type] === true;
    }
    getAll() {
      return this.session._getPermissions();
    }
    onUpdate(handler) {
      return this.session.on("permissions", handler);
    }
    onPermissionError(handler) {
      return this.session.on("error", (e) => {
        const maybe = e;
        if (maybe?.code === MiniappErrorCode.PERMISSION_NOT_DECLARED) {
          handler({
            code: String(maybe.code),
            message: String(maybe.message ?? ""),
            permission: maybe.permission,
            subscription: maybe.subscription,
            operation: maybe.operation
          });
        }
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/phone.js
  class TrackedSubs {
    constructor() {
      this.unsubs = new Set;
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
  }

  class PhoneNotificationsModule extends TrackedSubs {
    constructor(session) {
      super();
      this.session = session;
    }
    on(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.PHONE_NOTIFICATION, handler));
    }
    onDismissed(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.PHONE_NOTIFICATION_DISMISSED, handler));
    }
    get hasPermission() {
      return this.session._hasManifestPermission("READ_NOTIFICATIONS");
    }
  }

  class PhoneCalendarModule extends TrackedSubs {
    constructor(session) {
      super();
      this.session = session;
    }
    on(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.CALENDAR_EVENT, handler));
    }
    get hasPermission() {
      return this.session._hasManifestPermission("CALENDAR");
    }
  }

  class PhoneModule {
    constructor(session) {
      this.session = session;
      this.notifications = new PhoneNotificationsModule(session);
      this.calendar = new PhoneCalendarModule(session);
    }
    onBattery(handler) {
      return this.session._subscribe(MiniappStreamType.PHONE_BATTERY, handler);
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/transcription.js
  class TranscriptionModule {
    constructor(session) {
      this.session = session;
      this.unsubs = new Set;
      this.currentConfig = null;
    }
    on(handler) {
      return this.track(this.session._subscribe(`${MiniappStreamType.TRANSCRIPTION}:auto`, handler));
    }
    forLanguage(language, handler) {
      const langs = Array.isArray(language) ? language : [language];
      if (langs.length === 0)
        return () => {};
      const unsubs = [];
      for (const lang of langs) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TRANSCRIPTION}:${lang}`, handler));
      }
      const combined = () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
      return this.track(combined);
    }
    configure(config) {
      this.currentConfig = { ...config };
      this.session.sendOneShot({
        type: MiniappRequestType.TRANSCRIPTION_CONFIG,
        config: { ...config }
      });
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
    get hasPermission() {
      return this.session._hasManifestPermission("MICROPHONE");
    }
    _getConfig() {
      return this.currentConfig ? { ...this.currentConfig } : null;
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/translation.js
  class TranslationModule {
    constructor(session) {
      this.session = session;
      this.unsubs = new Set;
    }
    on(handler) {
      return this.track(this.session._subscribe(`${MiniappStreamType.TRANSLATION}:*:*`, handler));
    }
    to(target, handler) {
      const targets = Array.isArray(target) ? target : [target];
      if (targets.length === 0)
        return () => {};
      const unsubs = [];
      for (const t of targets) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TRANSLATION}:*:${t}`, handler));
      }
      const composite = () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
      return this.track(composite);
    }
    fromTo(source, target, handler) {
      const targets = Array.isArray(target) ? target : [target];
      if (targets.length === 0)
        return () => {};
      const unsubs = [];
      for (const t of targets) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TRANSLATION}:${source}:${t}`, handler));
      }
      const composite = () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
      return this.track(composite);
    }
    forLanguagePair(fromLang, toLang, handler) {
      return this.fromTo(fromLang, toLang, handler);
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
    get hasPermission() {
      return this.session._hasManifestPermission("MICROPHONE");
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/ui.js
  function rpcErrorFromUnknown(e) {
    if (e instanceof Error) {
      const own = e;
      const cause = own.cause;
      return compactEnvelope({
        message: e.message,
        code: own.code ?? cause?.code,
        stage: own.stage,
        transport: own.transport
      });
    }
    if (e && typeof e === "object") {
      const o = e;
      return compactEnvelope({
        message: typeof o.message === "string" ? o.message : JSON.stringify(e),
        code: typeof o.code === "string" ? o.code : undefined,
        stage: typeof o.stage === "string" ? o.stage : undefined,
        transport: typeof o.transport === "string" ? o.transport : undefined
      });
    }
    return { message: String(e) };
  }
  function compactEnvelope(env) {
    const out = { message: env.message };
    if (env.code)
      out.code = env.code;
    if (env.stage)
      out.stage = env.stage;
    if (env.transport)
      out.transport = env.transport;
    return out;
  }

  class UIModuleImpl {
    constructor(session) {
      this.session = session;
      this.bound = false;
      this.nextSeq = 1;
      this.openHandlers = new Set;
      this.closeHandlers = new Set;
      this.channelHandlers = new Map;
      this.rpcHandlers = new Map;
      this.inflightRpc = new Map;
      this.isOpen = () => {
        return this.bound;
      };
      this.onOpen = (cb) => {
        this.openHandlers.add(cb);
        if (this.bound) {
          if (this.session.ready) {
            try {
              cb();
            } catch (e) {
              console.warn("session.ui.onOpen late-fire threw:", e);
            }
          }
        }
        return () => {
          this.openHandlers.delete(cb);
        };
      };
      this.onClose = (cb) => {
        this.closeHandlers.add(cb);
        return () => {
          this.closeHandlers.delete(cb);
        };
      };
      this.send = (channel, payload) => {
        if (!this.bound) {
          return;
        }
        const seq = this.nextSeq++;
        const envelope = { type: "UI_SEND", channel, payload, seq };
        this.session.sendOneShot(envelope);
      };
      this.on = (channel, cb) => {
        let set = this.channelHandlers.get(channel);
        if (!set) {
          set = new Set;
          this.channelHandlers.set(channel, set);
        }
        set.add(cb);
        return () => {
          set.delete(cb);
        };
      };
      this.handle = (channel, handler) => {
        const key = channel;
        if (this.rpcHandlers.has(key)) {
          throw new Error(`session.ui.handle: a handler is already registered for "${key}"`);
        }
        this.rpcHandlers.set(key, handler);
        return () => {
          this.rpcHandlers.delete(key);
        };
      };
      this.session._subscribe("_ui", (env) => this.handleInbound(env));
    }
    fireOpenHandlers() {
      for (const h of this.openHandlers) {
        try {
          h();
        } catch (e) {
          console.warn("session.ui.onOpen handler threw", e);
        }
      }
    }
    handleInbound(env) {
      if (env.type === "UI_OPEN") {
        this.bound = true;
        this.nextSeq = 1;
        if (this.session.ready) {
          this.fireOpenHandlers();
        } else {
          const off = this.session.on("ready", () => {
            off();
            if (this.bound)
              this.fireOpenHandlers();
          });
        }
        return;
      }
      if (env.type === "UI_CLOSE") {
        this.bound = false;
        for (const h of this.closeHandlers) {
          try {
            h();
          } catch (e) {
            console.warn("session.ui.onClose handler threw", e);
          }
        }
        return;
      }
      if (env.type === "UI_MESSAGE") {
        if (typeof env.requestId === "string") {
          this.dispatchRpcCall(env.channel, env.payload, env.requestId);
          return;
        }
        const set = this.channelHandlers.get(env.channel);
        if (!set || set.size === 0)
          return;
        for (const h of set) {
          try {
            h(env.payload);
          } catch (e) {
            console.warn(`session.ui.on(${env.channel}) threw`, e);
          }
        }
        return;
      }
      if (env.type === "UI_CANCEL") {
        const ctrl = this.inflightRpc.get(env.requestId);
        if (ctrl) {
          try {
            ctrl.abort();
          } catch {}
        }
        return;
      }
    }
    dispatchRpcCall(channel, payload, requestId) {
      const handler = this.rpcHandlers.get(channel);
      if (!handler) {
        this.sendRpcReply(channel, requestId, {
          ok: false,
          error: { message: `no handler registered for "${channel}"` }
        });
        return;
      }
      const ctrl = new AbortController;
      this.inflightRpc.set(requestId, ctrl);
      const ctx = { signal: ctrl.signal };
      const finish = (envelope) => {
        this.inflightRpc.delete(requestId);
        if (ctrl.signal.aborted)
          return;
        this.sendRpcReply(channel, requestId, envelope);
      };
      let result;
      try {
        result = handler(payload, ctx);
      } catch (e) {
        finish({ ok: false, error: rpcErrorFromUnknown(e) });
        return;
      }
      if (result && typeof result.then === "function") {
        result.then((v) => finish({ ok: true, result: v }), (e) => finish({ ok: false, error: rpcErrorFromUnknown(e) }));
      } else {
        finish({ ok: true, result });
      }
    }
    sendRpcReply(channel, requestId, payload) {
      if (!this.bound)
        return;
      const seq = this.nextSeq++;
      const envelope = { type: "UI_SEND", channel, payload, seq, requestId };
      this.session.sendOneShot(envelope);
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/storage.js
  class SimpleStorage {
    constructor(session) {
      this.session = session;
    }
    async get(key) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_GET,
        key
      });
      return result?.value ?? null;
    }
    async set(key, value) {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_SET,
        key,
        value
      });
    }
    async delete(key) {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_DELETE,
        key
      });
    }
    async keys() {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_LIST
      });
      return result?.keys ?? [];
    }
    async list() {
      return this.keys();
    }
    async clear() {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_CLEAR
      });
    }
    async has(key) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_HAS,
        key
      });
      return !!result?.has;
    }
    async getAll() {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_GET_ALL
      });
      return result?.values ?? {};
    }
    async setMultiple(values) {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_SET_MULTIPLE,
        values
      });
    }
    async flush() {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_FLUSH
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/speaker.js
  class SpeakerModule {
    constructor(session) {
      this.session = session;
      this._state = "idle";
      this._lastEvent = { state: "idle" };
    }
    get state() {
      return this._state;
    }
    get isPlaying() {
      return this._state === "playing";
    }
    async play(options) {
      await this.session.sendRequest({
        type: MiniappRequestType.PLAY_AUDIO,
        audioUrl: options.audioUrl,
        volume: options.volume,
        stopOtherAudio: options.stopOtherAudio ?? false
      });
    }
    async speak(text, options = {}) {
      try {
        const result = await this.session.sendRequest({
          type: MiniappRequestType.SPEAK,
          text,
          voice_id: options.voice_id,
          voice_settings: options.voice_settings,
          volume: options.volume,
          stopOtherAudio: options.stopOtherAudio ?? false
        });
        return result ?? { completed: true };
      } catch (err) {
        if (err && typeof err === "object" && "code" in err) {
          throw err;
        }
        throw { code: MiniappErrorCode.INTERNAL, message: String(err) };
      }
    }
    stop() {
      this.session.sendOneShot({ type: MiniappRequestType.STOP_AUDIO });
    }
    onStateChange(handler) {
      return this.session.on("speakerState", handler);
    }
    _applyState(event) {
      if (event.state === this._state && event.state !== "error")
        return;
      this._state = event.state;
      this._lastEvent = event;
    }
    _getLastEvent() {
      return { ...this._lastEvent };
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/stream.js
  class StreamModule {
    constructor(session) {
      this.session = session;
    }
    async startUnmanaged(options) {
      return this.session.sendRequest({
        type: MiniappRequestType.STREAM_START,
        streamUrl: options.streamUrl,
        video: options.video,
        audio: options.audio,
        sound: options.sound ?? true
      });
    }
    async startManaged(options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.MANAGED_STREAM_START,
        restreamDestinations: options.restreamDestinations,
        video: options.video,
        audio: options.audio,
        sound: options.sound ?? true,
        ingest: options.ingest
      });
    }
    async stop(streamId) {
      await this.session.sendRequest({
        type: MiniappRequestType.STREAM_STOP,
        streamId
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/system.js
  class SystemModule {
    constructor(session) {
      this.session = session;
    }
    async share(options) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.SHARE,
        ...options
      });
      return result ?? { success: false };
    }
    openUrl(url) {
      this.session.sendOneShot({
        type: MiniappRequestType.OPEN_URL,
        url
      });
    }
    async copyToClipboard(text) {
      await this.session.sendRequest({
        type: MiniappRequestType.COPY_CLIPBOARD,
        text
      });
    }
    async download(options) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.DOWNLOAD,
        ...options
      });
      return result ?? { success: false };
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/miniapps.js
  class MiniappsModule {
    constructor(session) {
      this.session = session;
    }
    async list(opts) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.MINIAPPS_LIST,
        includeIncompatible: opts?.includeIncompatible ?? false
      });
      return result ?? [];
    }
    async start(packageName) {
      await this.session.sendRequest({
        type: MiniappRequestType.MINIAPPS_START,
        packageName
      });
    }
    async stop(packageName) {
      await this.session.sendRequest({
        type: MiniappRequestType.MINIAPPS_STOP,
        packageName
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/actions.js
  var HANDLER_WAIT_MS = 5000;

  class ActionsModule {
    constructor(session) {
      this.session = session;
      this.handlers = new Map;
      this.buffered = new Map;
    }
    invoke(packageName, actionId, params, opts) {
      return this.session.sendRequest({
        type: MiniappRequestType.ACTION_INVOKE,
        targetPackageName: packageName,
        actionId,
        params: params ?? {},
        ...opts?.timeoutMs != null ? { timeoutMs: opts.timeoutMs } : {}
      });
    }
    handle(actionId, handler) {
      if (this.handlers.has(actionId)) {
        throw new Error(`session.actions.handle: a handler is already registered for "${actionId}"`);
      }
      this.handlers.set(actionId, handler);
      const waiting = this.buffered.get(actionId);
      if (waiting) {
        this.buffered.delete(actionId);
        for (const call of waiting) {
          clearTimeout(call.timer);
          this.dispatch(call.callId, actionId, call.params, call.ctx);
        }
      }
      return () => {
        if (this.handlers.get(actionId) === handler)
          this.handlers.delete(actionId);
      };
    }
    _deliver(callId, actionId, params, ctx) {
      if (this.handlers.has(actionId)) {
        this.dispatch(callId, actionId, params, ctx);
        return;
      }
      const timer = setTimeout(() => {
        const arr2 = this.buffered.get(actionId);
        if (arr2) {
          const idx = arr2.findIndex((c) => c.callId === callId);
          if (idx >= 0)
            arr2.splice(idx, 1);
          if (arr2.length === 0)
            this.buffered.delete(actionId);
        }
        this.sendResult(callId, false, undefined, {
          code: MiniappErrorCode.NO_ACTION_HANDLER,
          message: `No handler registered for action "${actionId}"`
        });
      }, HANDLER_WAIT_MS);
      const arr = this.buffered.get(actionId) ?? [];
      arr.push({ callId, params, ctx, timer });
      this.buffered.set(actionId, arr);
    }
    async dispatch(callId, actionId, params, ctx) {
      const handler = this.handlers.get(actionId);
      if (!handler)
        return;
      try {
        const result = await handler(params, ctx);
        this.sendResult(callId, true, result ?? null);
      } catch (e) {
        this.sendResult(callId, false, undefined, {
          code: MiniappErrorCode.INTERNAL,
          message: e?.message ?? "action handler threw"
        });
      }
    }
    sendResult(callId, ok, result, error) {
      this.session.sendOneShot({
        type: MiniappRequestType.ACTION_RESULT,
        callId,
        ok,
        ...ok ? { result } : { error }
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/session.js
  var ALL_PERMISSION_TYPES = [
    "location",
    "microphone",
    "camera",
    "notifications",
    "calendar"
  ];

  class NotConnectedError extends Error {
    constructor(message = "MiniappSession is not connected") {
      super(message);
      this.code = MiniappErrorCode.NOT_CONNECTED;
      this.name = "NotConnectedError";
    }
  }
  var DEFAULT_CONNECT_TIMEOUT_MS = 1e4;

  class MiniappSession {
    constructor(options = {}) {
      this.capabilities = null;
      this.userId = "";
      this.packageName = "";
      this.visibility = "foreground";
      this.colorScheme = "light";
      this.ready = false;
      this.emitter = new import__.default;
      this.authState = null;
      this.authWaiters = new Set;
      this.authRefreshPromise = null;
      this.outboundQueue = [];
      this.pendingRequests = new Map;
      this.connectPromise = null;
      this.disposed = false;
      this._permissions = {
        location: false,
        microphone: false,
        camera: false,
        notifications: false,
        calendar: false
      };
      this.transport = createTransport(options);
      this.connectTimeoutMs = options.connectTimeoutMs ?? DEFAULT_CONNECT_TIMEOUT_MS;
      const injected = getMentraOSGlobals();
      this.packageName = options.packageName ?? injected.packageName ?? "";
      if (injected.colorScheme === "light" || injected.colorScheme === "dark") {
        this.colorScheme = injected.colorScheme;
      }
      this.auth = new AuthModule(this);
      this.events = new EventManager(this);
      this.speaker = new SpeakerModule(this);
      this.camera = new CameraModule(this);
      this.canvas = new CanvasManager(this);
      this.cloud = new CloudModule(this);
      this.dashboard = new DashboardAPI(this);
      this.display = new DisplayManager(this);
      this.glasses = new GlassesModule(this);
      this.heading = new HeadingModule(this);
      this.imu = new ImuModule(this);
      this.input = new InputModule(this);
      this.led = new LedModule(this);
      this.location = new LocationModule(this);
      this.mic = new MicModule(this);
      this.navigation = new NavigationModule(this);
      this.permissions = new PermissionsModule(this);
      this.phone = new PhoneModule(this);
      this.storage = new SimpleStorage(this);
      this.stream = new StreamModule(this);
      this.system = new SystemModule(this);
      this.transcription = new TranscriptionModule(this);
      this.translation = new TranslationModule(this);
      this.ui = new UIModuleImpl(this);
      this.miniapps = new MiniappsModule(this);
      this.actions = new ActionsModule(this);
    }
    _hasManifestPermission(manifestKey) {
      const canonical = manifestKeyToCanonical(manifestKey);
      if (!canonical)
        return false;
      return this._permissions[canonical] === true;
    }
    _getPermissions() {
      return { ...this._permissions };
    }
    _getAuth() {
      return this.authState ? { ...this.authState } : null;
    }
    _waitForAuth(minTtlMs, timeoutMs = 1e4) {
      const current = this.authState;
      if (current && this.authHasTtl(current, minTtlMs)) {
        return Promise.resolve({ ...current });
      }
      this.requestAuthRefresh(minTtlMs);
      return new Promise((resolve, reject) => {
        const waiter = {
          minTtlMs,
          resolve,
          reject,
          timer: setTimeout(() => {
            this.authWaiters.delete(waiter);
            reject(new NotConnectedError("Miniapp auth token is not available"));
          }, timeoutMs)
        };
        this.authWaiters.add(waiter);
      });
    }
    _subscribe(streamType, handler) {
      return this.events.subscribe(streamType, handler);
    }
    connect() {
      if (this.disposed) {
        return Promise.reject(new NotConnectedError("MiniappSession was disposed"));
      }
      if (this.connectPromise)
        return this.connectPromise;
      const readyPromise = new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
          const err = new Error("MiniappSession: CONNECT_ACK timeout");
          this.failAllPending({ code: MiniappErrorCode.NOT_CONNECTED, message: err.message });
          this.emitter.emit("error", err);
          reject(err);
        }, this.connectTimeoutMs);
        this.emitter.once("ready", () => {
          clearTimeout(timer);
          resolve();
        });
        this.emitter.once("error", (err) => {
          clearTimeout(timer);
          reject(err);
        });
      });
      this.connectPromise = (async () => {
        this.transport.onMessage((raw) => this.handleIncoming(raw));
        this.transport.onDisconnect((reason) => this.handleTransportDisconnect(reason));
        await this.transport.open();
        const requestId = makeRequestId();
        const connectPayload = {
          type: MiniappRequestType.CONNECT,
          packageName: this.packageName
        };
        this.transport.send(serializeEnvelope({ payload: connectPayload, requestId }));
        await readyPromise;
      })();
      return this.connectPromise;
    }
    waitForReady() {
      if (this.ready)
        return Promise.resolve();
      return this.connect();
    }
    isConnected() {
      return this.ready && this.transport.isOpen();
    }
    disconnect() {
      if (this.disposed)
        return;
      this.disposed = true;
      try {
        this.emitter.emit("beforeDisconnect", "disconnect called");
      } catch (err) {
        console.warn("[MiniappSession] beforeDisconnect handler threw:", err);
      }
      this.failAllPending({ code: MiniappErrorCode.REQUEST_ABORTED, message: "Session disconnected" });
      try {
        this.transport.close();
      } catch {}
      this.ready = false;
      this.emitter.emit("disconnect", "disconnect called");
    }
    sendOneShot(payload) {
      const envelope = { payload };
      this.enqueueOrSend(serializeEnvelope(envelope));
    }
    sendRequest(payload) {
      if (this.disposed) {
        return Promise.reject(new NotConnectedError);
      }
      const requestId = makeRequestId();
      const envelope = { payload, requestId };
      return new Promise((resolve, reject) => {
        this.pendingRequests.set(requestId, {
          requestId,
          resolve,
          reject
        });
        this.enqueueOrSend(serializeEnvelope(envelope));
      });
    }
    on(event, handler) {
      this.emitter.on(event, handler);
      return () => this.emitter.off(event, handler);
    }
    off(event, handler) {
      this.emitter.off(event, handler);
    }
    onBeforeDisconnect(handler) {
      return this.on("beforeDisconnect", handler);
    }
    onVisibilityChange(handler) {
      return this.on("visibility", handler);
    }
    onCapabilitiesChange(handler) {
      return this.on("capabilities", handler);
    }
    onColorSchemeChange(handler) {
      return this.on("colorScheme", handler);
    }
    enqueueOrSend(raw) {
      if (this.ready) {
        try {
          this.transport.send(raw);
        } catch (err) {
          this.emitter.emit("error", err);
        }
        return;
      }
      this.outboundQueue.push(raw);
    }
    flushQueue() {
      const queue = this.outboundQueue.splice(0);
      for (const raw of queue) {
        try {
          this.transport.send(raw);
        } catch (err) {
          this.emitter.emit("error", err);
        }
      }
    }
    handleIncoming(raw) {
      const envelope = parseEnvelope(raw);
      if (!envelope)
        return;
      const payload = envelope.payload;
      const type = payload?.type;
      switch (type) {
        case MiniappResponseType.CONNECT_ACK: {
          const ack = payload;
          this.userId = ack.userId ?? "";
          if (ack.packageName)
            this.packageName = ack.packageName;
          this.capabilities = ack.capabilities ?? null;
          if (ack.visibility)
            this.visibility = ack.visibility;
          if (ack.colorScheme === "light" || ack.colorScheme === "dark") {
            this.colorScheme = ack.colorScheme;
          }
          if (ack.auth) {
            this.applyAuth(ack.auth);
            if (!this.userId)
              this.userId = ack.auth.mentraUserId;
          }
          if (ack.permissions)
            this.applyPermissions(ack.permissions);
          this.ready = true;
          this.flushQueue();
          this.emitter.emit("ready");
          return;
        }
        case MiniappResponseType.AUTH_UPDATE: {
          const next = payload.auth;
          if (next) {
            this.applyAuth(next);
            if (!this.userId)
              this.userId = next.mentraUserId;
          }
          return;
        }
        case MiniappResponseType.PERMISSIONS_UPDATE: {
          const next = payload.permissions;
          if (next)
            this.applyPermissions(next);
          return;
        }
        case MiniappResponseType.SPEAKER_STATE: {
          const state = payload.state;
          if (!state)
            return;
          const event = {
            state,
            errorCode: payload.errorCode,
            errorMessage: payload.errorMessage,
            durationMs: payload.durationMs
          };
          this.speaker._applyState(event);
          this.emitter.emit("speakerState", event);
          return;
        }
        case MiniappRequestType.PING: {
          const pong = { type: MiniappResponseType.PONG };
          const env = {
            payload: pong,
            ...envelope.requestId ? { requestId: envelope.requestId } : {}
          };
          try {
            this.transport.send(serializeEnvelope(env));
          } catch {}
          return;
        }
        case MiniappResponseType.EVENT: {
          const streamType = payload.streamType;
          if (!streamType)
            return;
          this.events._forwardEvent(streamType, payload.data);
          return;
        }
        case MiniappResponseType.ACTION_CALL: {
          const callId = payload.callId;
          const actionId = payload.actionId;
          if (!callId || !actionId)
            return;
          const params = payload.params ?? {};
          const callerPackageName = payload.callerPackageName ?? "";
          this.actions._deliver(callId, actionId, params, { callerPackageName });
          return;
        }
        case MiniappResponseType.CAPABILITIES_UPDATE: {
          const cap = payload.capabilities ?? null;
          this.capabilities = cap;
          this.emitter.emit("capabilities", cap);
          return;
        }
        case MiniappResponseType.VISIBILITY_CHANGE: {
          const next = payload.visibility;
          if (next === "foreground" || next === "background") {
            this.visibility = next;
            this.emitter.emit("visibility", next);
          }
          return;
        }
        case MiniappResponseType.COLOR_SCHEME_CHANGE: {
          const next = payload.colorScheme;
          if (next === "light" || next === "dark") {
            this.colorScheme = next;
            this.emitter.emit("colorScheme", next);
          }
          return;
        }
        case MiniappResponseType.REQUEST_RESULT: {
          const requestId = envelope.requestId;
          if (!requestId)
            return;
          const pending = this.pendingRequests.get(requestId);
          if (!pending)
            return;
          this.pendingRequests.delete(requestId);
          if (payload.ok === false) {
            const err = payload.error ?? {
              code: MiniappErrorCode.INTERNAL,
              message: "Unknown error"
            };
            pending.reject(err);
          } else {
            pending.resolve(payload.data ?? null);
          }
          return;
        }
        case MiniappResponseType.WILL_DISCONNECT: {
          const reason = payload.reason ?? "phone unregistering";
          try {
            this.emitter.emit("beforeDisconnect", reason);
          } catch (err) {
            console.warn("[MiniappSession] beforeDisconnect handler threw:", err);
          }
          return;
        }
        case MiniappResponseType.ERROR: {
          const err = new Error(payload.message ?? "MiniappSession error");
          this.emitter.emit("error", err);
          return;
        }
        default:
          return;
      }
    }
    handleTransportDisconnect(reason) {
      this.ready = false;
      this.failAllPending({ code: MiniappErrorCode.NOT_CONNECTED, message: `Transport disconnected: ${reason}` });
      this.emitter.emit("disconnect", reason);
    }
    failAllPending(error) {
      for (const pending of this.pendingRequests.values()) {
        pending.reject(error);
      }
      this.pendingRequests.clear();
      for (const waiter of Array.from(this.authWaiters)) {
        clearTimeout(waiter.timer);
        this.authWaiters.delete(waiter);
        waiter.reject(new NotConnectedError(error.message));
      }
    }
    authHasTtl(auth, minTtlMs) {
      return auth.expiresAt - Date.now() > minTtlMs;
    }
    requestAuthRefresh(minTtlMs) {
      if (this.authRefreshPromise)
        return this.authRefreshPromise;
      if (!this.ready || !this.transport.isOpen())
        return Promise.resolve(null);
      this.authRefreshPromise = this.sendRequest({
        type: MiniappRequestType.AUTH_REFRESH,
        minTtlMs
      }).then((result) => {
        const auth = result?.auth;
        if (auth)
          this.applyAuth(auth);
        return auth ?? null;
      }).catch((err) => {
        console.warn("[MiniappSession] auth refresh failed:", err);
        return null;
      }).finally(() => {
        this.authRefreshPromise = null;
      });
      return this.authRefreshPromise;
    }
    applyAuth(next) {
      this.authState = { ...next };
      for (const waiter of Array.from(this.authWaiters)) {
        if (!this.authHasTtl(next, waiter.minTtlMs))
          continue;
        clearTimeout(waiter.timer);
        this.authWaiters.delete(waiter);
        waiter.resolve({ ...next });
      }
      this.emitter.emit("auth", { ...next });
    }
    applyPermissions(next) {
      let changed = false;
      const updated = { ...this._permissions };
      for (const k of ALL_PERMISSION_TYPES) {
        const v = next[k] === true;
        if (updated[k] !== v) {
          updated[k] = v;
          changed = true;
        }
      }
      if (changed) {
        this._permissions = updated;
        this.emitter.emit("permissions", { ...updated });
      }
    }
  }
  function manifestKeyToCanonical(manifestKey) {
    switch (manifestKey.toUpperCase()) {
      case "MICROPHONE":
        return "microphone";
      case "CAMERA":
        return "camera";
      case "LOCATION":
      case "BACKGROUND_LOCATION":
        return "location";
      case "READ_NOTIFICATIONS":
      case "POST_NOTIFICATIONS":
        return "notifications";
      case "CALENDAR":
        return "calendar";
      default:
        return null;
    }
  }

  // ../../mobile/modules/miniapp/dist/background/register.js
  function registerMiniapp(handler, options = {}) {
    const g = globalThis;
    g.__mentraInitCallback = (_sessionId) => {
      const session = new MiniappSession(options);
      try {
        const result = handler(session);
        if (result && typeof result.then === "function") {
          result.catch((err) => {
            console.error("[mentra-miniapp] registerMiniapp handler rejected:", err);
          });
        }
      } catch (err) {
        console.error("[mentra-miniapp] registerMiniapp handler threw:", err);
      }
      session.connect().catch((err) => {
        console.error("[mentra-miniapp] session.connect() rejected:", err);
        try {
          const message = err instanceof Error ? err.message : String(err);
          const stack = err instanceof Error && err.stack ? err.stack : "";
          g.__hostError?.(JSON.stringify({ message: `session.connect() failed: ${message}`, stack }));
        } catch {}
      });
    };
  }
  // src/vendor/display-utils/measurer/script-detection.ts
  var SCRIPT_RANGES = {
    cjk: [
      [19968, 40959],
      [13312, 19903],
      [131072, 173791],
      [173824, 177983],
      [177984, 178207],
      [63744, 64255]
    ],
    hiragana: [[12352, 12447]],
    katakana: [
      [12448, 12543],
      [12784, 12799]
    ],
    korean: [
      [44032, 55215],
      [4352, 4607],
      [12592, 12687],
      [43360, 43391],
      [55216, 55295]
    ],
    cyrillic: [
      [1024, 1279],
      [1280, 1327]
    ],
    numbers: [[48, 57]],
    punctuation: [
      [32, 47],
      [58, 64],
      [91, 96],
      [123, 126]
    ],
    arabic: [[1536, 1791]],
    hebrew: [[1424, 1535]],
    thai: [[3584, 3711]],
    emoji: [
      [128512, 128591],
      [127744, 128511],
      [128640, 128767],
      [127456, 127487],
      [9728, 9983],
      [9984, 10175],
      [65024, 65039],
      [129280, 129535]
    ]
  };
  function inRanges(codePoint, ranges) {
    for (const [start, end] of ranges) {
      if (codePoint >= start && codePoint <= end) {
        return true;
      }
    }
    return false;
  }
  function detectScript(char) {
    if (!char || char.length === 0) {
      return "latin";
    }
    const codePoint = char.codePointAt(0);
    if (codePoint === undefined) {
      return "latin";
    }
    if (inRanges(codePoint, SCRIPT_RANGES.cjk)) {
      return "cjk";
    }
    if (inRanges(codePoint, SCRIPT_RANGES.hiragana)) {
      return "hiragana";
    }
    if (inRanges(codePoint, SCRIPT_RANGES.katakana)) {
      return "katakana";
    }
    if (inRanges(codePoint, SCRIPT_RANGES.korean)) {
      return "korean";
    }
    if (inRanges(codePoint, SCRIPT_RANGES.cyrillic)) {
      return "cyrillic";
    }
    if (inRanges(codePoint, SCRIPT_RANGES.numbers)) {
      return "numbers";
    }
    if (inRanges(codePoint, SCRIPT_RANGES.punctuation)) {
      return "punctuation";
    }
    if (inRanges(codePoint, SCRIPT_RANGES.arabic) || inRanges(codePoint, SCRIPT_RANGES.hebrew) || inRanges(codePoint, SCRIPT_RANGES.thai) || inRanges(codePoint, SCRIPT_RANGES.emoji)) {
      return "unsupported";
    }
    return "latin";
  }
  function isCJKCharacter(char) {
    const script = detectScript(char);
    return script === "cjk" || script === "hiragana" || script === "katakana";
  }
  function isUniformWidthScript(char) {
    const script = detectScript(char);
    return script === "cjk" || script === "hiragana" || script === "katakana" || script === "korean" || script === "cyrillic";
  }
  function needsHyphenForBreak(charBefore, charAfter) {
    if (isCJKCharacter(charBefore)) {
      return false;
    }
    if (isCJKCharacter(charAfter)) {
      return false;
    }
    if (charBefore === " " || charBefore === "\t") {
      return false;
    }
    if (charAfter === " " || charAfter === "\t") {
      return false;
    }
    const breakPunctuation = ["-", "–", "—", "/", "\\", "|"];
    if (breakPunctuation.includes(charBefore)) {
      return false;
    }
    return true;
  }

  // src/vendor/display-utils/measurer/TextMeasurer.ts
  class TextMeasurer {
    profile;
    charCache = new Map;
    constructor(profile) {
      this.profile = profile;
      this.buildCharCache();
    }
    buildCharCache() {
      const { glyphWidths, renderFormula } = this.profile.fontMetrics;
      for (const [char, glyphWidth] of glyphWidths.entries()) {
        const renderedWidth = renderFormula(glyphWidth);
        this.charCache.set(char, renderedWidth);
      }
    }
    measureText(text) {
      if (!text || text.length === 0) {
        return 0;
      }
      let totalWidth = 0;
      for (const char of text) {
        totalWidth += this.measureChar(char);
      }
      return totalWidth;
    }
    measureTextDetailed(text) {
      if (!text || text.length === 0) {
        return {
          text: "",
          totalWidthPx: 0,
          charCount: 0,
          chars: []
        };
      }
      const chars = [];
      let totalWidth = 0;
      for (const char of text) {
        const script = detectScript(char);
        const widthPx = this.measureChar(char);
        const fromGlyphMap = this.profile.fontMetrics.glyphWidths.has(char);
        chars.push({
          char,
          widthPx,
          script,
          fromGlyphMap
        });
        totalWidth += widthPx;
      }
      return {
        text,
        totalWidthPx: totalWidth,
        charCount: chars.length,
        chars
      };
    }
    measureChar(char) {
      if (!char || char.length === 0) {
        return 0;
      }
      const cached = this.charCache.get(char);
      if (cached !== undefined) {
        return cached;
      }
      const width = this.calculateCharWidth(char);
      this.charCache.set(char, width);
      return width;
    }
    calculateCharWidth(char) {
      const { fontMetrics } = this.profile;
      const { uniformScripts, fallback, renderFormula, glyphWidths } = fontMetrics;
      const glyphWidth = glyphWidths.get(char);
      if (glyphWidth !== undefined) {
        return renderFormula(glyphWidth);
      }
      const script = detectScript(char);
      switch (script) {
        case "cjk":
          return uniformScripts.cjk;
        case "hiragana":
          return uniformScripts.hiragana;
        case "katakana":
          return uniformScripts.katakana;
        case "korean":
          return uniformScripts.korean;
        case "cyrillic":
          return uniformScripts.cyrillic;
      }
      return fallback.latinMaxWidth;
    }
    getGlyphWidth(char) {
      return this.profile.fontMetrics.glyphWidths.get(char);
    }
    fitsInWidth(text, maxWidthPx) {
      return this.measureText(text) <= maxWidthPx;
    }
    charsThatFit(text, maxWidthPx, startIndex = 0) {
      if (!text || startIndex >= text.length) {
        return 0;
      }
      let currentWidth = 0;
      let count = 0;
      const chars = Array.from(text).slice(startIndex);
      for (const char of chars) {
        const charWidth = this.measureChar(char);
        if (currentWidth + charWidth > maxWidthPx) {
          break;
        }
        currentWidth += charWidth;
        count++;
      }
      return count;
    }
    getPixelOffset(text, index) {
      if (!text || index <= 0) {
        return 0;
      }
      const chars = Array.from(text).slice(0, index);
      let offset = 0;
      for (const char of chars) {
        offset += this.measureChar(char);
      }
      return offset;
    }
    detectScript(char) {
      return detectScript(char);
    }
    isUniformWidth(char) {
      return isUniformWidthScript(char);
    }
    getProfile() {
      return this.profile;
    }
    getDisplayWidthPx() {
      return this.profile.displayWidthPx;
    }
    getMaxLines() {
      return this.profile.maxLines;
    }
    getMaxPayloadBytes() {
      return this.profile.maxPayloadBytes;
    }
    getByteSize(text) {
      return new TextEncoder().encode(text).length;
    }
    getHyphenWidth() {
      return this.measureChar("-");
    }
    getSpaceWidth() {
      return this.measureChar(" ");
    }
    clearCache() {
      this.charCache.clear();
      this.buildCharCache();
    }
  }
  // src/vendor/display-utils/wrapper/types.ts
  var DEFAULT_WRAP_OPTIONS = {
    breakMode: "character-no-hyphen",
    hyphenChar: "-",
    minCharsBeforeHyphen: 3,
    trimLines: true,
    preserveNewlines: true
  };

  // src/vendor/display-utils/wrapper/TextWrapper.ts
  class TextWrapper {
    measurer;
    defaultOptions;
    constructor(measurer, defaultOptions) {
      this.measurer = measurer;
      const profile = measurer.getProfile();
      this.defaultOptions = {
        maxWidthPx: profile.displayWidthPx,
        maxLines: profile.maxLines,
        maxBytes: profile.maxPayloadBytes,
        ...DEFAULT_WRAP_OPTIONS,
        ...defaultOptions
      };
    }
    wrap(text, options) {
      const opts = this.mergeOptions(options);
      const { maxWidthPx, maxLines, maxBytes, breakMode, preserveNewlines } = opts;
      if (!text || text.length === 0) {
        return this.createEmptyResult(opts);
      }
      const paragraphs = preserveNewlines ? text.split(`
`) : [text];
      const allLines = [];
      const allMetrics = [];
      let totalBytes = 0;
      let truncated = false;
      for (let pIndex = 0;pIndex < paragraphs.length; pIndex++) {
        const paragraph = paragraphs[pIndex];
        const isFromNewline = pIndex > 0;
        const paragraphLines = this.wrapParagraph(paragraph, maxWidthPx, breakMode, opts);
        for (let lIndex = 0;lIndex < paragraphLines.length; lIndex++) {
          const line = paragraphLines[lIndex];
          const lineBytes = this.measurer.getByteSize(line);
          if (allLines.length >= maxLines) {
            truncated = true;
            break;
          }
          if (totalBytes + lineBytes > maxBytes) {
            truncated = true;
            break;
          }
          const widthPx = this.measurer.measureText(line);
          const metrics = {
            text: line,
            widthPx,
            bytes: lineBytes,
            utilizationPercent: Math.round(widthPx / maxWidthPx * 100),
            endsWithHyphen: line.endsWith(opts.hyphenChar) && lIndex < paragraphLines.length - 1,
            fromExplicitNewline: isFromNewline && lIndex === 0
          };
          allLines.push(line);
          allMetrics.push(metrics);
          totalBytes += lineBytes;
          if (allLines.length < maxLines) {
            totalBytes += 1;
          }
        }
        if (truncated)
          break;
      }
      const maxLineWidthPx = allMetrics.reduce((max, m) => Math.max(max, m.widthPx), 0);
      return {
        lines: allLines,
        truncated,
        maxLineWidthPx,
        totalBytes,
        lineMetrics: allMetrics,
        originalText: text,
        breakMode
      };
    }
    wrapToLines(text, options) {
      return this.wrap(text, options).lines;
    }
    needsWrap(text, maxWidthPx) {
      const width = maxWidthPx ?? this.defaultOptions.maxWidthPx;
      return this.measurer.measureText(text) > width || text.includes(`
`);
    }
    getOptions() {
      return { ...this.defaultOptions };
    }
    getMeasurer() {
      return this.measurer;
    }
    wrapParagraph(paragraph, maxWidthPx, breakMode, opts) {
      const trimmed = opts.trimLines ? paragraph.trim() : paragraph;
      if (!trimmed) {
        return [""];
      }
      if (this.measurer.fitsInWidth(trimmed, maxWidthPx)) {
        return [trimmed];
      }
      switch (breakMode) {
        case "character":
          return this.wrapCharacterMode(trimmed, maxWidthPx, opts);
        case "character-no-hyphen":
          return this.wrapCharacterNoHyphenMode(trimmed, maxWidthPx, opts);
        case "word":
          return this.wrapWordMode(trimmed, maxWidthPx, opts);
        case "strict-word":
          return this.wrapStrictWordMode(trimmed, maxWidthPx, opts);
        default:
          return this.wrapCharacterMode(trimmed, maxWidthPx, opts);
      }
    }
    wrapCharacterMode(text, maxWidthPx, opts) {
      return this.wrapCharacterModeInternal(text, maxWidthPx, opts, true);
    }
    wrapCharacterNoHyphenMode(text, maxWidthPx, opts) {
      return this.wrapCharacterModeInternal(text, maxWidthPx, opts, false);
    }
    wrapCharacterModeInternal(text, maxWidthPx, opts, useHyphen) {
      const lines = [];
      const hyphenWidth = this.measurer.measureChar(opts.hyphenChar);
      let currentLine = "";
      let currentWidth = 0;
      const chars = Array.from(text);
      for (let i = 0;i < chars.length; i++) {
        const char = chars[i];
        const charWidth = this.measurer.measureChar(char);
        if (currentWidth + charWidth <= maxWidthPx) {
          currentLine += char;
          currentWidth += charWidth;
        } else {
          const prevChar = currentLine.length > 0 ? currentLine[currentLine.length - 1] : "";
          const needsHyphen = useHyphen && currentLine.length >= opts.minCharsBeforeHyphen && needsHyphenForBreak(prevChar, char);
          if (needsHyphen) {
            const result = this.backoffForHyphen(currentLine, currentWidth, maxWidthPx, hyphenWidth, opts);
            if (result.skipHyphen) {
              lines.push(result.line);
            } else {
              lines.push(result.line + opts.hyphenChar);
            }
            currentLine = result.remainder + char;
            currentWidth = this.measurer.measureText(currentLine);
          } else if (useHyphen === false && !isCJKCharacter(char) && char !== " ") {
            const trimmedLine = opts.trimLines ? currentLine.trimEnd() : currentLine;
            if (trimmedLine) {
              lines.push(trimmedLine);
            }
            currentLine = char;
            currentWidth = charWidth;
          } else {
            const trimmedLine = opts.trimLines ? currentLine.trimEnd() : currentLine;
            if (trimmedLine) {
              lines.push(trimmedLine);
            }
            currentLine = char === " " ? "" : char;
            currentWidth = char === " " ? 0 : charWidth;
          }
        }
      }
      if (currentLine) {
        const trimmedLine = opts.trimLines ? currentLine.trim() : currentLine;
        if (trimmedLine) {
          lines.push(trimmedLine);
        }
      }
      return lines.length > 0 ? lines : [""];
    }
    wrapWordMode(text, maxWidthPx, opts) {
      const lines = [];
      const words = this.splitIntoWords(text);
      const spaceWidth = this.measurer.getSpaceWidth();
      let currentLine = "";
      let currentWidth = 0;
      for (const word of words) {
        const wordWidth = this.measurer.measureText(word);
        const needsSpace = currentLine.length > 0;
        const totalWidth = currentWidth + (needsSpace ? spaceWidth : 0) + wordWidth;
        if (totalWidth <= maxWidthPx) {
          if (needsSpace) {
            currentLine += " ";
            currentWidth += spaceWidth;
          }
          currentLine += word;
          currentWidth += wordWidth;
        } else {
          if (currentLine.length > 0) {
            lines.push(opts.trimLines ? currentLine.trim() : currentLine);
            currentLine = "";
            currentWidth = 0;
          }
          if (wordWidth > maxWidthPx) {
            const hyphenatedLines = this.hyphenateLongWord(word, maxWidthPx, opts);
            for (let i = 0;i < hyphenatedLines.length - 1; i++) {
              lines.push(hyphenatedLines[i]);
            }
            currentLine = hyphenatedLines[hyphenatedLines.length - 1];
            currentWidth = this.measurer.measureText(currentLine);
          } else {
            currentLine = word;
            currentWidth = wordWidth;
          }
        }
      }
      if (currentLine) {
        const trimmedLine = opts.trimLines ? currentLine.trim() : currentLine;
        if (trimmedLine) {
          lines.push(trimmedLine);
        }
      }
      return lines.length > 0 ? lines : [""];
    }
    wrapStrictWordMode(text, maxWidthPx, opts) {
      const lines = [];
      const words = this.splitIntoWords(text);
      const spaceWidth = this.measurer.getSpaceWidth();
      let currentLine = "";
      let currentWidth = 0;
      for (const word of words) {
        const wordWidth = this.measurer.measureText(word);
        const needsSpace = currentLine.length > 0;
        const totalWidth = currentWidth + (needsSpace ? spaceWidth : 0) + wordWidth;
        if (totalWidth <= maxWidthPx) {
          if (needsSpace) {
            currentLine += " ";
            currentWidth += spaceWidth;
          }
          currentLine += word;
          currentWidth += wordWidth;
        } else {
          if (currentLine.length > 0) {
            lines.push(opts.trimLines ? currentLine.trim() : currentLine);
          }
          currentLine = word;
          currentWidth = wordWidth;
        }
      }
      if (currentLine) {
        const trimmedLine = opts.trimLines ? currentLine.trim() : currentLine;
        if (trimmedLine) {
          lines.push(trimmedLine);
        }
      }
      return lines.length > 0 ? lines : [""];
    }
    splitIntoWords(text) {
      const words = [];
      let currentWord = "";
      for (const char of text) {
        if (char === " " || char === "\t") {
          if (currentWord) {
            words.push(currentWord);
            currentWord = "";
          }
        } else if (isCJKCharacter(char)) {
          if (currentWord) {
            words.push(currentWord);
            currentWord = "";
          }
          words.push(char);
        } else {
          currentWord += char;
        }
      }
      if (currentWord) {
        words.push(currentWord);
      }
      return words;
    }
    hyphenateLongWord(word, maxWidthPx, opts) {
      const lines = [];
      const hyphenWidth = this.measurer.measureChar(opts.hyphenChar);
      const chars = Array.from(word);
      let currentLine = "";
      let currentWidth = 0;
      for (let i = 0;i < chars.length; i++) {
        const char = chars[i];
        const charWidth = this.measurer.measureChar(char);
        const isLastChar = i === chars.length - 1;
        const widthNeeded = isLastChar ? charWidth : charWidth + hyphenWidth;
        if (currentWidth + widthNeeded <= maxWidthPx) {
          currentLine += char;
          currentWidth += charWidth;
        } else {
          if (currentLine.length >= opts.minCharsBeforeHyphen) {
            const result = this.backoffForHyphen(currentLine, currentWidth, maxWidthPx, hyphenWidth, opts);
            if (result.skipHyphen) {
              lines.push(result.line);
            } else {
              lines.push(result.line + opts.hyphenChar);
            }
            currentLine = result.remainder + char;
            currentWidth = this.measurer.measureText(currentLine);
          } else {
            if (currentLine) {
              lines.push(currentLine);
            }
            currentLine = char;
            currentWidth = charWidth;
          }
        }
      }
      if (currentLine) {
        lines.push(currentLine);
      }
      return lines.length > 0 ? lines : [word];
    }
    backoffForHyphen(line, lineWidth, maxWidthPx, hyphenWidth, opts) {
      let adjustedLine = line;
      let adjustedWidth = lineWidth;
      let remainder = "";
      while (adjustedWidth + hyphenWidth > maxWidthPx && adjustedLine.length > opts.minCharsBeforeHyphen) {
        const lastChar = adjustedLine[adjustedLine.length - 1];
        const lastCharWidth = this.measurer.measureChar(lastChar);
        adjustedLine = adjustedLine.slice(0, -1);
        adjustedWidth -= lastCharWidth;
        remainder = lastChar + remainder;
        if (adjustedLine.length > 0 && adjustedLine[adjustedLine.length - 1] === " ") {
          adjustedLine = adjustedLine.trimEnd();
          return { line: adjustedLine, remainder, skipHyphen: true };
        }
      }
      return { line: adjustedLine, remainder, skipHyphen: false };
    }
    mergeOptions(options) {
      return {
        ...this.defaultOptions,
        ...options
      };
    }
    createEmptyResult(opts) {
      return {
        lines: [""],
        truncated: false,
        maxLineWidthPx: 0,
        totalBytes: 0,
        lineMetrics: [
          {
            text: "",
            widthPx: 0,
            bytes: 0,
            utilizationPercent: 0,
            endsWithHyphen: false,
            fromExplicitNewline: false
          }
        ],
        originalText: "",
        breakMode: opts.breakMode
      };
    }
  }
  // src/vendor/display-utils/profiles/g1.ts
  var G1_GLYPH_WIDTHS = {
    " ": 2,
    "!": 1,
    '"': 2,
    "#": 6,
    $: 5,
    "%": 6,
    "&": 7,
    "'": 1,
    "(": 2,
    ")": 2,
    "*": 3,
    "+": 4,
    ",": 1,
    "-": 4,
    ".": 1,
    "/": 3,
    "0": 5,
    "1": 3,
    "2": 5,
    "3": 5,
    "4": 5,
    "5": 5,
    "6": 5,
    "7": 5,
    "8": 5,
    "9": 5,
    ":": 1,
    ";": 1,
    "<": 4,
    "=": 4,
    ">": 4,
    "?": 5,
    "@": 7,
    A: 6,
    B: 5,
    C: 5,
    D: 5,
    E: 4,
    F: 4,
    G: 5,
    H: 5,
    I: 2,
    J: 3,
    K: 5,
    L: 4,
    M: 7,
    N: 5,
    O: 5,
    P: 5,
    Q: 5,
    R: 5,
    S: 5,
    T: 5,
    U: 5,
    V: 6,
    W: 7,
    X: 6,
    Y: 6,
    Z: 5,
    "[": 2,
    "\\": 3,
    "]": 2,
    "^": 4,
    _: 3,
    "`": 2,
    a: 5,
    b: 4,
    c: 4,
    d: 4,
    e: 4,
    f: 4,
    g: 4,
    h: 4,
    i: 1,
    j: 2,
    k: 4,
    l: 1,
    m: 7,
    n: 4,
    o: 4,
    p: 4,
    q: 4,
    r: 3,
    s: 4,
    t: 3,
    u: 5,
    v: 5,
    w: 7,
    x: 5,
    y: 5,
    z: 4,
    "{": 3,
    "|": 1,
    "}": 3,
    "~": 7
  };
  var G1_PROFILE = {
    id: "even-realities-g1",
    name: "Even Realities G1",
    displayWidthPx: 576,
    maxLines: 5,
    maxPayloadBytes: 390,
    bleChunkSize: 176,
    fontMetrics: {
      glyphWidths: new Map(Object.entries(G1_GLYPH_WIDTHS)),
      defaultGlyphWidth: 7,
      renderFormula: (glyphWidth) => (glyphWidth + 1) * 2,
      uniformScripts: {
        cjk: 18,
        hiragana: 18,
        katakana: 18,
        korean: 24,
        cyrillic: 18
      },
      fallback: {
        latinMaxWidth: 16,
        unknownBehavior: "useLatinMax"
      }
    },
    constraints: {
      minCharsBeforeHyphen: 3,
      noStartChars: [".", ",", "!", "?", ":", ";", ")", "]", "}", "。", "，", "！", "？", "：", "；", "）", "】", "」"],
      noEndChars: ["(", "[", "{", "（", "【", "「"]
    }
  };
  var G1_PROFILE_LEGACY = {
    id: "even-realities-g1-legacy",
    name: "Even Realities G1 (Legacy Client Compatibility)",
    displayWidthPx: 420,
    maxLines: 5,
    maxPayloadBytes: 390,
    bleChunkSize: 176,
    fontMetrics: {
      glyphWidths: new Map(Object.entries(G1_GLYPH_WIDTHS)),
      defaultGlyphWidth: 7,
      renderFormula: (glyphWidth) => (glyphWidth + 1) * 2,
      uniformScripts: {
        cjk: 18,
        hiragana: 18,
        katakana: 18,
        korean: 24,
        cyrillic: 18
      },
      fallback: {
        latinMaxWidth: 16,
        unknownBehavior: "useLatinMax"
      }
    },
    constraints: {
      minCharsBeforeHyphen: 3,
      noStartChars: [".", ",", "!", "?", ":", ";", ")", "]", "}", "。", "，", "！", "？", "：", "；", "）", "】", "」"],
      noEndChars: ["(", "[", "{", "（", "【", "「"]
    }
  };
  // src/vendor/display-utils/profiles/z100.ts
  var Z100_GLYPH_WIDTHS = {
    " ": 5,
    "!": 6,
    '"': 9,
    "#": 14,
    $: 12,
    "%": 17,
    "&": 15,
    "'": 5,
    "(": 6,
    ")": 6,
    "*": 12,
    "+": 12,
    ",": 6,
    "-": 7,
    ".": 6,
    "/": 8,
    "0": 12,
    "1": 12,
    "2": 12,
    "3": 12,
    "4": 12,
    "5": 12,
    "6": 12,
    "7": 12,
    "8": 12,
    "9": 12,
    ":": 6,
    ";": 6,
    "<": 12,
    "=": 12,
    ">": 12,
    "?": 9,
    "@": 19,
    A: 13,
    B: 14,
    C: 13,
    D: 15,
    E: 12,
    F: 11,
    G: 15,
    H: 16,
    I: 7,
    J: 6,
    K: 13,
    L: 11,
    M: 19,
    N: 16,
    O: 16,
    P: 13,
    Q: 16,
    R: 13,
    S: 12,
    T: 12,
    U: 15,
    V: 13,
    W: 20,
    X: 12,
    Y: 12,
    Z: 12,
    "[": 7,
    "\\": 8,
    "]": 7,
    "^": 12,
    _: 9,
    "`": 6,
    a: 12,
    b: 13,
    c: 10,
    d: 13,
    e: 12,
    f: 7,
    g: 13,
    h: 13,
    i: 5,
    j: 5,
    k: 11,
    l: 5,
    m: 20,
    n: 13,
    o: 13,
    p: 13,
    q: 13,
    r: 9,
    s: 10,
    t: 8,
    u: 13,
    v: 11,
    w: 17,
    x: 11,
    y: 11,
    z: 10,
    "{": 8,
    "|": 12,
    "}": 8,
    "~": 12
  };
  var Z100_PROFILE = {
    id: "vuzix-z100",
    name: "Vuzix Z100",
    displayWidthPx: 390,
    maxLines: 7,
    maxPayloadBytes: 512,
    bleChunkSize: 180,
    fontMetrics: {
      glyphWidths: new Map(Object.entries(Z100_GLYPH_WIDTHS)),
      defaultGlyphWidth: 12,
      renderFormula: (glyphWidth) => glyphWidth,
      uniformScripts: {
        cjk: 21,
        hiragana: 21,
        katakana: 21,
        korean: 21,
        cyrillic: 14
      },
      fallback: {
        latinMaxWidth: 20,
        unknownBehavior: "useLatinMax"
      }
    },
    constraints: {
      minCharsBeforeHyphen: 3,
      noStartChars: [
        ".",
        ",",
        "!",
        "?",
        ":",
        ";",
        ")",
        "]",
        "}",
        "。",
        "，",
        "！",
        "？",
        "：",
        "；",
        "）",
        "】",
        "」"
      ],
      noEndChars: ["(", "[", "{", "（", "【", "「"]
    }
  };
  // src/vendor/display-utils/profiles/nex.ts
  var NEX_GLYPH_WIDTHS = {
    " ": 2,
    "!": 1,
    '"': 2,
    "#": 6,
    $: 5,
    "%": 6,
    "&": 7,
    "'": 1,
    "(": 2,
    ")": 2,
    "*": 3,
    "+": 4,
    ",": 1,
    "-": 4,
    ".": 1,
    "/": 3,
    "0": 5,
    "1": 3,
    "2": 5,
    "3": 5,
    "4": 5,
    "5": 5,
    "6": 5,
    "7": 5,
    "8": 5,
    "9": 5,
    ":": 1,
    ";": 1,
    "<": 4,
    "=": 4,
    ">": 4,
    "?": 5,
    "@": 7,
    A: 6,
    B: 5,
    C: 5,
    D: 5,
    E: 4,
    F: 4,
    G: 5,
    H: 5,
    I: 2,
    J: 3,
    K: 5,
    L: 4,
    M: 7,
    N: 5,
    O: 5,
    P: 5,
    Q: 5,
    R: 5,
    S: 5,
    T: 5,
    U: 5,
    V: 6,
    W: 7,
    X: 6,
    Y: 6,
    Z: 5,
    "[": 2,
    "\\": 3,
    "]": 2,
    "^": 4,
    _: 3,
    "`": 2,
    a: 5,
    b: 4,
    c: 4,
    d: 4,
    e: 4,
    f: 4,
    g: 4,
    h: 4,
    i: 1,
    j: 2,
    k: 4,
    l: 1,
    m: 7,
    n: 4,
    o: 4,
    p: 4,
    q: 4,
    r: 3,
    s: 4,
    t: 3,
    u: 5,
    v: 5,
    w: 7,
    x: 5,
    y: 5,
    z: 4,
    "{": 3,
    "|": 1,
    "}": 3,
    "~": 7
  };
  var NEX_PROFILE = {
    id: "mentra-nex",
    name: "Mentra Nex",
    displayWidthPx: 576,
    maxLines: 5,
    maxPayloadBytes: 390,
    bleChunkSize: 176,
    fontMetrics: {
      glyphWidths: new Map(Object.entries(NEX_GLYPH_WIDTHS)),
      defaultGlyphWidth: 7,
      renderFormula: (glyphWidth) => (glyphWidth + 1) * 2,
      uniformScripts: {
        cjk: 18,
        hiragana: 18,
        katakana: 18,
        korean: 24,
        cyrillic: 18
      },
      fallback: {
        latinMaxWidth: 16,
        unknownBehavior: "useLatinMax"
      }
    },
    constraints: {
      minCharsBeforeHyphen: 3,
      noStartChars: [".", ",", "!", "?", ":", ";", ")", "]", "}", "。", "，", "！", "？", "：", "；", "）", "】", "」"],
      noEndChars: ["(", "[", "{", "（", "【", "「"]
    }
  };
  // src/background/core/ScriptEngine.ts
  function widthFraction(setting) {
    switch (setting) {
      case 0:
        return 0.7;
      case 1:
        return 0.85;
      case 2:
      default:
        return 1;
    }
  }
  function normalizeWord(raw) {
    return raw.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, "");
  }
  function normalizeWords(text) {
    const out = [];
    for (const raw of text.split(/\s+/)) {
      const n = normalizeWord(raw);
      if (n)
        out.push(n);
    }
    return out;
  }

  class ScriptEngine {
    profile;
    widthSetting;
    numberOfLines;
    measurer;
    wrapper;
    text = "";
    allLines = [];
    wordNorms = [];
    wordLines = [];
    constructor(config) {
      this.profile = config.profile;
      this.widthSetting = config.widthSetting;
      this.numberOfLines = this.clampLines(config.numberOfLines);
      this.measurer = new TextMeasurer(this.profile);
      this.wrapper = new TextWrapper(this.measurer);
      this.rewrap();
    }
    setScript(text) {
      this.text = text ?? "";
      this.rewrap();
    }
    setLayout(partial) {
      if (partial.profile && partial.profile.id !== this.profile.id) {
        this.profile = partial.profile;
        this.measurer = new TextMeasurer(this.profile);
        this.wrapper = new TextWrapper(this.measurer);
      }
      if (partial.widthSetting !== undefined)
        this.widthSetting = partial.widthSetting;
      if (partial.numberOfLines !== undefined)
        this.numberOfLines = this.clampLines(partial.numberOfLines);
      this.rewrap();
    }
    get viewportLines() {
      return this.numberOfLines;
    }
    get totalWords() {
      return this.wordNorms.length;
    }
    get totalLines() {
      return this.allLines.length;
    }
    get maxTopLine() {
      return Math.max(0, this.allLines.length - this.numberOfLines);
    }
    lineForWord(wordIndex) {
      if (this.wordLines.length === 0)
        return 0;
      const i = Math.max(0, Math.min(wordIndex, this.wordLines.length - 1));
      return this.wordLines[i];
    }
    topLineForWord(wordIndex) {
      return Math.min(this.lineForWord(wordIndex), this.maxTopLine);
    }
    firstWordOfLine(line) {
      for (let i = 0;i < this.wordLines.length; i++) {
        if (this.wordLines[i] >= line)
          return i;
      }
      return this.totalWords;
    }
    windowAt(topLine) {
      const top = Math.max(0, Math.min(topLine, this.maxTopLine));
      const out = this.allLines.slice(top, top + this.numberOfLines);
      while (out.length < this.numberOfLines)
        out.push("");
      return out;
    }
    wordForPercent(percent) {
      if (this.totalWords === 0)
        return 0;
      const p = Math.max(0, Math.min(100, percent)) / 100;
      return Math.round(p * this.totalWords);
    }
    progressForWord(wordIndex) {
      if (this.totalWords === 0)
        return 0;
      return Math.max(0, Math.min(100, Math.round(wordIndex / this.totalWords * 100)));
    }
    matchSpoken(probe, cursor) {
      if (probe.length === 0 || this.totalWords === 0)
        return cursor;
      const AHEAD = 60;
      const BACK = 4;
      const MAX_RUN = 6;
      const start = Math.max(0, cursor - BACK);
      const end = Math.min(this.totalWords, cursor + AHEAD);
      let bestPos = -1;
      let bestScore = 0;
      for (let i = start;i < end; i++) {
        let score = 0;
        let pi = probe.length - 1;
        let si = i;
        while (pi >= 0 && si >= 0 && probe[pi] === this.wordNorms[si]) {
          score++;
          pi--;
          si--;
          if (score >= MAX_RUN)
            break;
        }
        if (score > bestScore) {
          bestScore = score;
          bestPos = i;
        } else if (score === bestScore && score > 0 && bestPos >= 0) {
          if (Math.abs(i - cursor) < Math.abs(bestPos - cursor))
            bestPos = i;
        }
      }
      if (bestPos < 0)
        return cursor;
      const needed = probe.length === 1 ? 1 : 2;
      if (bestScore < needed)
        return cursor;
      const candidate = bestPos + 1;
      if (candidate <= cursor)
        return cursor;
      if (bestScore === 1 && candidate > cursor + 8)
        return cursor;
      return Math.min(candidate, this.totalWords);
    }
    clampLines(n) {
      return Math.max(2, Math.min(Math.round(n), this.profile.maxLines));
    }
    rewrap() {
      const widthPx = Math.round(this.profile.displayWidthPx * widthFraction(this.widthSetting));
      const result = this.wrapper.wrap(this.text, {
        maxWidthPx: widthPx,
        maxLines: Infinity,
        maxBytes: Infinity,
        breakMode: "word",
        trimLines: true,
        preserveNewlines: true
      });
      this.allLines = result.lines;
      const norms = [];
      const lines = [];
      for (let lineIdx = 0;lineIdx < this.allLines.length; lineIdx++) {
        for (const raw of this.allLines[lineIdx].split(/\s+/)) {
          const n = normalizeWord(raw);
          if (!n)
            continue;
          norms.push(n);
          lines.push(lineIdx);
        }
      }
      this.wordNorms = norms;
      this.wordLines = lines;
    }
  }

  // src/background/core/DisplayProfiles.ts
  function getProfileForModel(modelName) {
    if (!modelName)
      return G1_PROFILE;
    const lower = modelName.toLowerCase();
    if (lower.includes("g1") || lower.includes("even realities") || lower.includes("even_g1")) {
      return G1_PROFILE;
    }
    if (lower.includes("z100") || lower.includes("vuzix") || lower.includes("mach1") || lower.includes("mach 1")) {
      return Z100_PROFILE;
    }
    if (lower.includes("nex") || lower.includes("mentra display") || lower.includes("mentra_nex")) {
      return NEX_PROFILE;
    }
    return G1_PROFILE;
  }
  function getModelName(session) {
    try {
      const caps = session.capabilities;
      const m = caps?.modelName;
      return typeof m === "string" ? m : null;
    } catch {
      return null;
    }
  }
  function hasDisplayCapability(session) {
    try {
      const caps = session.capabilities;
      if (!caps)
        return false;
      if (typeof caps.hasDisplay === "boolean")
        return caps.hasDisplay;
      const display = caps.display;
      if (typeof display === "boolean")
        return display;
      if (display && typeof display === "object")
        return display.present !== false;
      return typeof caps.modelName === "string";
    } catch {
      return false;
    }
  }
  function hasMicrophoneCapability(session) {
    try {
      const caps = session.capabilities;
      if (!caps)
        return true;
      if (typeof caps.hasMicrophone === "boolean")
        return caps.hasMicrophone;
      const mic = caps.microphone;
      if (typeof mic === "boolean")
        return mic;
      if (mic && typeof mic === "object")
        return mic.present !== false;
      return true;
    } catch {
      return true;
    }
  }

  // src/background/controllers/TeleprompterController.ts
  var DEFAULT_SCRIPT = [
    "Welcome to your teleprompter.",
    "",
    "Paste or type your script here, put on your glasses, and press play. The words appear in front of you, line by line.",
    "",
    "Leave voice-follow on and the prompter listens — it advances as you speak, and waits when you pause. Turn it off to scroll at a steady pace you set in words per minute.",
    "",
    "That's it. Look up, speak naturally, and never lose your place."
  ].join(`
`);
  var DEFAULT_SETTINGS = {
    script: DEFAULT_SCRIPT,
    wpm: 130,
    numberOfLines: 4,
    lineWidth: 2,
    voiceFollow: true,
    autoRestart: false,
    showTimecode: false
  };
  var STORAGE_KEYS = {
    script: "script",
    wpm: "wpm",
    numberOfLines: "numberOfLines",
    lineWidth: "lineWidth",
    voiceFollow: "voiceFollow",
    autoRestart: "autoRestart",
    showTimecode: "showTimecode"
  };
  var WPM_MIN = 30;
  var WPM_MAX = 400;
  var TICK_MS = 350;
  var PROBE_WORDS = 6;
  var SPOKEN_HISTORY = 16;

  class TeleprompterController {
    session;
    started = false;
    unsubs = [];
    ui;
    settings = { ...DEFAULT_SETTINGS };
    engine;
    profile;
    hasDisplay = false;
    hasMic = true;
    state = "idle";
    cursor = 0;
    currentTopLine = 0;
    currentVisible = [];
    lastRenderedText = "";
    timer = null;
    timerStartMs = 0;
    timerStartWord = 0;
    transcriptionCleanup = null;
    voiceActive = false;
    recentSpoken = [];
    constructor(session) {
      this.session = session;
    }
    async start() {
      if (this.started)
        return;
      this.started = true;
      this.ui = this.session.ui;
      this.profile = getProfileForModel(getModelName(this.session));
      this.hasDisplay = hasDisplayCapability(this.session);
      this.hasMic = hasMicrophoneCapability(this.session);
      await this.loadSettings();
      this.engine = new ScriptEngine({
        profile: this.profile,
        widthSetting: this.settings.lineWidth,
        numberOfLines: this.settings.numberOfLines
      });
      this.engine.setScript(this.settings.script);
      this.applyViewport();
      try {
        this.unsubs.push(this.session.onCapabilitiesChange(() => this.onCapabilitiesChanged()));
      } catch {}
      try {
        this.unsubs.push(this.session.on("ready", () => this.onCapabilitiesChanged()));
      } catch {}
      if (this.session.ready) {
        this.profile = getProfileForModel(getModelName(this.session));
        this.hasDisplay = hasDisplayCapability(this.session);
        this.hasMic = hasMicrophoneCapability(this.session);
        this.engine.setLayout({ profile: this.profile });
        this.applyViewport();
      }
      try {
        this.unsubs.push(this.session.onVisibilityChange((v) => {
          if (v === "foreground") {
            this.lastRenderedText = "";
            this.render();
            this.broadcastStatus();
          }
        }));
      } catch {}
      this.registerUiHandlers();
      this.render();
      this.broadcastStatus();
      console.log(`Teleprompter: started (words=${this.engine.totalWords}, lines=${this.engine.totalLines}, profile=${this.profile.id})`);
    }
    stop() {
      this.clearTimer();
      this.unsubscribeTranscription();
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.length = 0;
      this.started = false;
    }
    registerUiHandlers() {
      this.unsubs.push(this.ui.onOpen(() => this.sendSnapshot()));
      this.unsubs.push(this.ui.on("tp:request-snapshot", () => this.sendSnapshot()));
      this.unsubs.push(this.ui.on("tp:set-script", ({ script }) => void this.setScript(script)));
      this.unsubs.push(this.ui.on("tp:set-wpm", ({ wpm }) => void this.setWpm(wpm)));
      this.unsubs.push(this.ui.on("tp:set-lines", ({ lines }) => void this.setLines(lines)));
      this.unsubs.push(this.ui.on("tp:set-width", ({ width }) => void this.setWidth(width)));
      this.unsubs.push(this.ui.on("tp:set-voice-follow", ({ enabled }) => void this.setVoiceFollow(enabled)));
      this.unsubs.push(this.ui.on("tp:set-auto-restart", ({ enabled }) => void this.setAutoRestart(enabled)));
      this.unsubs.push(this.ui.on("tp:set-show-timecode", ({ enabled }) => void this.setShowTimecode(enabled)));
      this.unsubs.push(this.ui.on("tp:play", () => this.play()));
      this.unsubs.push(this.ui.on("tp:pause", () => this.pause()));
      this.unsubs.push(this.ui.on("tp:restart", () => this.restart()));
      this.unsubs.push(this.ui.on("tp:seek", ({ percent }) => this.seek(percent)));
      this.unsubs.push(this.ui.on("tp:nudge", ({ lines }) => this.nudge(lines)));
    }
    sendSnapshot() {
      this.ui.send("tp:snapshot", { settings: { ...this.settings }, status: this.buildStatus() });
    }
    broadcastStatus() {
      this.ui.send("tp:status", this.buildStatus());
    }
    broadcastSettings() {
      this.ui.send("tp:settings-update", { ...this.settings });
    }
    play() {
      if (this.engine.totalWords === 0)
        return;
      if (this.state === "finished" || this.cursor >= this.engine.totalWords) {
        this.cursor = 0;
      }
      this.state = "playing";
      this.recentSpoken = [];
      if (this.settings.voiceFollow) {
        this.clearTimer();
        this.startVoiceFollow();
      } else {
        this.unsubscribeTranscription();
        this.startTimer();
      }
      this.render();
      this.broadcastStatus();
    }
    pause() {
      if (this.state !== "playing")
        return;
      this.state = "paused";
      this.clearTimer();
      this.unsubscribeTranscription();
      this.render();
      this.broadcastStatus();
    }
    restart() {
      this.cursor = 0;
      this.recentSpoken = [];
      if (this.state === "finished")
        this.state = "paused";
      if (this.state === "playing" && !this.voiceActive) {
        this.timerStartWord = 0;
        this.timerStartMs = this.now();
      }
      this.render();
      this.broadcastStatus();
    }
    seek(percent) {
      this.moveCursorTo(this.engine.wordForPercent(percent));
    }
    nudge(lines) {
      const newTop = Math.max(0, Math.min(this.currentTopLine + lines, this.engine.maxTopLine));
      this.moveCursorTo(this.engine.firstWordOfLine(newTop));
    }
    moveCursorTo(word) {
      this.cursor = Math.max(0, Math.min(word, this.engine.totalWords));
      this.recentSpoken = [];
      if (this.state === "playing" && this.cursor >= this.engine.totalWords) {
        this.handleEnd();
        return;
      }
      if (this.state === "finished" && this.cursor < this.engine.totalWords)
        this.state = "paused";
      if (this.state === "playing" && !this.voiceActive) {
        this.timerStartWord = this.cursor;
        this.timerStartMs = this.now();
      }
      this.render();
      this.broadcastStatus();
    }
    startTimer() {
      this.voiceActive = false;
      this.timerStartWord = this.cursor;
      this.timerStartMs = this.now();
      this.clearTimer();
      this.timer = setInterval(() => this.onTick(), TICK_MS);
    }
    clearTimer() {
      if (this.timer) {
        clearInterval(this.timer);
        this.timer = null;
      }
    }
    onTick() {
      if (this.state !== "playing" || this.voiceActive)
        return;
      const elapsedSec = (this.now() - this.timerStartMs) / 1000;
      const advanced = Math.floor(elapsedSec * this.settings.wpm / 60);
      const next = Math.min(this.timerStartWord + advanced, this.engine.totalWords);
      if (next !== this.cursor) {
        this.cursor = next;
        if (this.cursor >= this.engine.totalWords) {
          this.handleEnd();
          return;
        }
        this.render();
      }
      this.broadcastStatus();
    }
    startVoiceFollow() {
      this.unsubscribeTranscription();
      if (!this.hasMic) {
        console.log("Teleprompter: no microphone on device, using timed scroll");
        this.voiceActive = false;
        this.startTimer();
        return;
      }
      try {
        this.transcriptionCleanup = this.session.transcription.on((data) => this.handleTranscription(data));
        this.voiceActive = true;
      } catch (err) {
        console.log("Teleprompter: voice-follow subscribe failed, using timed scroll", err);
        this.voiceActive = false;
        this.startTimer();
      }
    }
    unsubscribeTranscription() {
      if (this.transcriptionCleanup) {
        try {
          this.transcriptionCleanup();
        } catch {}
        this.transcriptionCleanup = null;
      }
      this.voiceActive = false;
    }
    handleTranscription(data) {
      if (this.state !== "playing" || !this.voiceActive)
        return;
      const spoken = normalizeWords(data.text || "");
      if (spoken.length === 0)
        return;
      let probe;
      if (data.isFinal) {
        this.recentSpoken.push(...spoken);
        if (this.recentSpoken.length > SPOKEN_HISTORY) {
          this.recentSpoken = this.recentSpoken.slice(-SPOKEN_HISTORY);
        }
        probe = this.recentSpoken.slice(-PROBE_WORDS);
      } else {
        probe = [...this.recentSpoken, ...spoken].slice(-PROBE_WORDS);
      }
      const next = this.engine.matchSpoken(probe, this.cursor);
      if (next !== this.cursor) {
        this.cursor = next;
        if (this.cursor >= this.engine.totalWords) {
          this.handleEnd();
          return;
        }
        this.render();
        this.broadcastStatus();
      }
    }
    handleEnd() {
      if (this.settings.autoRestart) {
        this.cursor = 0;
        this.recentSpoken = [];
        if (!this.voiceActive) {
          this.timerStartWord = 0;
          this.timerStartMs = this.now();
        }
        this.render();
        this.broadcastStatus();
        return;
      }
      this.state = "finished";
      this.clearTimer();
      this.unsubscribeTranscription();
      this.render();
      this.broadcastStatus();
    }
    async loadSettings() {
      try {
        const [script, wpm, lines, width, voice, replay, timecode] = await Promise.all([
          this.session.storage.get(STORAGE_KEYS.script),
          this.session.storage.get(STORAGE_KEYS.wpm),
          this.session.storage.get(STORAGE_KEYS.numberOfLines),
          this.session.storage.get(STORAGE_KEYS.lineWidth),
          this.session.storage.get(STORAGE_KEYS.voiceFollow),
          this.session.storage.get(STORAGE_KEYS.autoRestart),
          this.session.storage.get(STORAGE_KEYS.showTimecode)
        ]);
        this.settings = {
          script: script ?? DEFAULT_SETTINGS.script,
          wpm: this.clampWpm(this.parseIntOr(wpm, DEFAULT_SETTINGS.wpm)),
          numberOfLines: this.clampLines(this.parseIntOr(lines, DEFAULT_SETTINGS.numberOfLines)),
          lineWidth: this.clampWidth(this.parseIntOr(width, DEFAULT_SETTINGS.lineWidth)),
          voiceFollow: voice == null ? DEFAULT_SETTINGS.voiceFollow : voice === "true",
          autoRestart: replay == null ? DEFAULT_SETTINGS.autoRestart : replay === "true",
          showTimecode: timecode == null ? DEFAULT_SETTINGS.showTimecode : timecode === "true"
        };
      } catch (err) {
        console.log("Teleprompter: failed to load settings, using defaults", err);
        this.settings = { ...DEFAULT_SETTINGS };
      }
    }
    async setScript(text) {
      const next = text ?? "";
      if (next === this.settings.script)
        return;
      this.settings.script = next;
      this.engine.setScript(next);
      this.toIdle();
      this.render();
      this.broadcastSettings();
      this.broadcastStatus();
      await this.persist(STORAGE_KEYS.script, next);
    }
    async setWpm(wpm) {
      this.settings.wpm = this.clampWpm(wpm);
      await this.persist(STORAGE_KEYS.wpm, String(this.settings.wpm));
      if (this.state === "playing" && !this.voiceActive) {
        this.timerStartWord = this.cursor;
        this.timerStartMs = this.now();
      }
      if (this.settings.showTimecode)
        this.render();
      this.broadcastSettings();
      this.broadcastStatus();
    }
    async setLines(lines) {
      this.settings.numberOfLines = this.clampLines(lines);
      await this.persist(STORAGE_KEYS.numberOfLines, String(this.settings.numberOfLines));
      this.applyViewport();
      this.render();
      this.broadcastSettings();
      this.broadcastStatus();
    }
    async setWidth(width) {
      this.settings.lineWidth = this.clampWidth(width);
      await this.persist(STORAGE_KEYS.lineWidth, String(this.settings.lineWidth));
      this.engine.setLayout({ widthSetting: this.settings.lineWidth });
      this.render();
      this.broadcastSettings();
      this.broadcastStatus();
    }
    async setVoiceFollow(enabled) {
      this.settings.voiceFollow = enabled;
      await this.persist(STORAGE_KEYS.voiceFollow, String(enabled));
      if (this.state === "playing") {
        this.recentSpoken = [];
        if (enabled) {
          this.clearTimer();
          this.startVoiceFollow();
        } else {
          this.unsubscribeTranscription();
          this.startTimer();
        }
      }
      this.broadcastSettings();
      this.broadcastStatus();
    }
    async setAutoRestart(enabled) {
      this.settings.autoRestart = enabled;
      await this.persist(STORAGE_KEYS.autoRestart, String(enabled));
      this.broadcastSettings();
      this.broadcastStatus();
    }
    async setShowTimecode(enabled) {
      this.settings.showTimecode = enabled;
      await this.persist(STORAGE_KEYS.showTimecode, String(enabled));
      this.applyViewport();
      this.render();
      this.broadcastSettings();
      this.broadcastStatus();
    }
    async persist(key, value) {
      try {
        await this.session.storage.set(key, value);
      } catch (err) {
        console.log(`Teleprompter: failed to persist ${key}`, err);
      }
    }
    onCapabilitiesChanged() {
      const prevHasMic = this.hasMic;
      const newProfile = getProfileForModel(getModelName(this.session));
      this.hasDisplay = hasDisplayCapability(this.session);
      this.hasMic = hasMicrophoneCapability(this.session);
      if (newProfile.id !== this.profile.id) {
        this.profile = newProfile;
        this.engine.setLayout({ profile: newProfile });
      }
      this.applyViewport();
      if (this.state === "playing" && this.settings.voiceFollow && this.hasMic !== prevHasMic) {
        this.recentSpoken = [];
        this.clearTimer();
        this.startVoiceFollow();
      }
      this.lastRenderedText = "";
      this.render();
      this.broadcastStatus();
    }
    render() {
      this.currentTopLine = this.engine.topLineForWord(this.cursor);
      const content = this.engine.windowAt(this.currentTopLine);
      const display = this.composeDisplay(content);
      this.currentVisible = display;
      const text = display.join(`
`);
      if (this.hasDisplay && text !== this.lastRenderedText) {
        try {
          this.session.display.showTextWall(text, { view: "main" });
          this.lastRenderedText = text;
        } catch (err) {
          console.log("Teleprompter: display error", err);
        }
      }
    }
    composeDisplay(content) {
      if (!this.settings.showTimecode)
        return content;
      return [...content, this.timecodeLine()];
    }
    applyViewport() {
      const footer = this.settings.showTimecode ? 1 : 0;
      const effective = Math.min(this.settings.numberOfLines, Math.max(2, this.profile.maxLines - footer));
      this.engine.setLayout({ numberOfLines: effective });
    }
    timecodeLine() {
      const total = this.engine.totalWords;
      const posSec = total > 0 ? this.cursor / this.settings.wpm * 60 : 0;
      const totalSec = total / this.settings.wpm * 60;
      return `${fmtClock(posSec)} / ${fmtClock(totalSec)}`;
    }
    buildStatus() {
      const total = this.engine.totalWords;
      const remainingWords = Math.max(0, total - this.cursor);
      return {
        state: this.state,
        voiceMode: this.state === "playing" ? this.voiceActive : this.settings.voiceFollow && this.hasMic,
        wordIndex: this.cursor,
        totalWords: total,
        topLine: this.currentTopLine,
        totalLines: this.engine.totalLines,
        visibleLines: [...this.currentVisible],
        progress: this.engine.progressForWord(this.cursor),
        estimatedTotalSec: total / this.settings.wpm * 60,
        remainingSec: remainingWords / this.settings.wpm * 60,
        hasDisplay: this.hasDisplay
      };
    }
    toIdle() {
      this.state = "idle";
      this.cursor = 0;
      this.recentSpoken = [];
      this.clearTimer();
      this.unsubscribeTranscription();
    }
    now() {
      return Date.now();
    }
    parseIntOr(raw, fallback) {
      if (raw == null)
        return fallback;
      const p = parseInt(raw, 10);
      return Number.isNaN(p) ? fallback : p;
    }
    clampWpm(n) {
      if (Number.isNaN(n))
        return DEFAULT_SETTINGS.wpm;
      return Math.max(WPM_MIN, Math.min(WPM_MAX, Math.round(n)));
    }
    clampLines(n) {
      if (Number.isNaN(n))
        return DEFAULT_SETTINGS.numberOfLines;
      return Math.max(2, Math.min(5, Math.round(n)));
    }
    clampWidth(n) {
      if (n <= 0)
        return 0;
      if (n >= 2)
        return 2;
      return 1;
    }
  }
  function fmtClock(sec) {
    const s = Math.max(0, Math.round(sec));
    const m = Math.floor(s / 60);
    const r = s % 60;
    return `${m}:${r.toString().padStart(2, "0")}`;
  }

  // src/background/index.ts
  registerMiniapp((session) => {
    new TeleprompterController(session).start();
  });
})();
