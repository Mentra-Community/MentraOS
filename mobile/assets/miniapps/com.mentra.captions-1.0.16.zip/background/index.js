(() => {
  var __create = Object.create;
  var __getProtoOf = Object.getPrototypeOf;
  var __defProp = Object.defineProperty;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  function __accessProp(key) {
    return this[key];
  }
  var __toESMCache_node;
  var __toESMCache_esm;
  var __toESM = (mod, isNodeMode, target) => {
    var canCache = mod != null && typeof mod === "object";
    if (canCache) {
      var cache = isNodeMode ? __toESMCache_node ??= new WeakMap : __toESMCache_esm ??= new WeakMap;
      var cached = cache.get(mod);
      if (cached)
        return cached;
    }
    target = mod != null ? __create(__getProtoOf(mod)) : {};
    const to = isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target;
    for (let key of __getOwnPropNames(mod))
      if (!__hasOwnProp.call(to, key))
        __defProp(to, key, {
          get: __accessProp.bind(mod, key),
          enumerable: true
        });
    if (canCache)
      cache.set(mod, to);
    return to;
  };
  var __commonJS = (cb, mod) => () => (mod || cb((mod = { exports: {} }).exports, mod), mod.exports);
  var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
    get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
  }) : x)(function(x) {
    if (typeof require !== "undefined")
      return require.apply(this, arguments);
    throw Error('Dynamic require of "' + x + '" is not supported');
  });

  // ../../node_modules/.bun/eventemitter3@5.0.4/node_modules/eventemitter3/index.js
  var require_eventemitter3 = __commonJS((exports, module) => {
    var has = Object.prototype.hasOwnProperty;
    var prefix = "~";
    function Events() {}
    if (Object.create) {
      Events.prototype = Object.create(null);
      if (!new Events().__proto__)
        prefix = false;
    }
    function EE(fn, context, once) {
      this.fn = fn;
      this.context = context;
      this.once = once || false;
    }
    function addListener(emitter, event, fn, context, once) {
      if (typeof fn !== "function") {
        throw new TypeError("The listener must be a function");
      }
      var listener = new EE(fn, context || emitter, once), evt = prefix ? prefix + event : event;
      if (!emitter._events[evt])
        emitter._events[evt] = listener, emitter._eventsCount++;
      else if (!emitter._events[evt].fn)
        emitter._events[evt].push(listener);
      else
        emitter._events[evt] = [emitter._events[evt], listener];
      return emitter;
    }
    function clearEvent(emitter, evt) {
      if (--emitter._eventsCount === 0)
        emitter._events = new Events;
      else
        delete emitter._events[evt];
    }
    function EventEmitter() {
      this._events = new Events;
      this._eventsCount = 0;
    }
    EventEmitter.prototype.eventNames = function eventNames() {
      var names = [], events, name;
      if (this._eventsCount === 0)
        return names;
      for (name in events = this._events) {
        if (has.call(events, name))
          names.push(prefix ? name.slice(1) : name);
      }
      if (Object.getOwnPropertySymbols) {
        return names.concat(Object.getOwnPropertySymbols(events));
      }
      return names;
    };
    EventEmitter.prototype.listeners = function listeners(event) {
      var evt = prefix ? prefix + event : event, handlers = this._events[evt];
      if (!handlers)
        return [];
      if (handlers.fn)
        return [handlers.fn];
      for (var i = 0, l = handlers.length, ee = new Array(l);i < l; i++) {
        ee[i] = handlers[i].fn;
      }
      return ee;
    };
    EventEmitter.prototype.listenerCount = function listenerCount(event) {
      var evt = prefix ? prefix + event : event, listeners = this._events[evt];
      if (!listeners)
        return 0;
      if (listeners.fn)
        return 1;
      return listeners.length;
    };
    EventEmitter.prototype.emit = function emit(event, a1, a2, a3, a4, a5) {
      var evt = prefix ? prefix + event : event;
      if (!this._events[evt])
        return false;
      var listeners = this._events[evt], len = arguments.length, args, i;
      if (listeners.fn) {
        if (listeners.once)
          this.removeListener(event, listeners.fn, undefined, true);
        switch (len) {
          case 1:
            return listeners.fn.call(listeners.context), true;
          case 2:
            return listeners.fn.call(listeners.context, a1), true;
          case 3:
            return listeners.fn.call(listeners.context, a1, a2), true;
          case 4:
            return listeners.fn.call(listeners.context, a1, a2, a3), true;
          case 5:
            return listeners.fn.call(listeners.context, a1, a2, a3, a4), true;
          case 6:
            return listeners.fn.call(listeners.context, a1, a2, a3, a4, a5), true;
        }
        for (i = 1, args = new Array(len - 1);i < len; i++) {
          args[i - 1] = arguments[i];
        }
        listeners.fn.apply(listeners.context, args);
      } else {
        var length = listeners.length, j;
        for (i = 0;i < length; i++) {
          if (listeners[i].once)
            this.removeListener(event, listeners[i].fn, undefined, true);
          switch (len) {
            case 1:
              listeners[i].fn.call(listeners[i].context);
              break;
            case 2:
              listeners[i].fn.call(listeners[i].context, a1);
              break;
            case 3:
              listeners[i].fn.call(listeners[i].context, a1, a2);
              break;
            case 4:
              listeners[i].fn.call(listeners[i].context, a1, a2, a3);
              break;
            default:
              if (!args)
                for (j = 1, args = new Array(len - 1);j < len; j++) {
                  args[j - 1] = arguments[j];
                }
              listeners[i].fn.apply(listeners[i].context, args);
          }
        }
      }
      return true;
    };
    EventEmitter.prototype.on = function on(event, fn, context) {
      return addListener(this, event, fn, context, false);
    };
    EventEmitter.prototype.once = function once(event, fn, context) {
      return addListener(this, event, fn, context, true);
    };
    EventEmitter.prototype.removeListener = function removeListener(event, fn, context, once) {
      var evt = prefix ? prefix + event : event;
      if (!this._events[evt])
        return this;
      if (!fn) {
        clearEvent(this, evt);
        return this;
      }
      var listeners = this._events[evt];
      if (listeners.fn) {
        if (listeners.fn === fn && (!once || listeners.once) && (!context || listeners.context === context)) {
          clearEvent(this, evt);
        }
      } else {
        for (var i = 0, events = [], length = listeners.length;i < length; i++) {
          if (listeners[i].fn !== fn || once && !listeners[i].once || context && listeners[i].context !== context) {
            events.push(listeners[i]);
          }
        }
        if (events.length)
          this._events[evt] = events.length === 1 ? events[0] : events;
        else
          clearEvent(this, evt);
      }
      return this;
    };
    EventEmitter.prototype.removeAllListeners = function removeAllListeners(event) {
      var evt;
      if (event) {
        evt = prefix ? prefix + event : event;
        if (this._events[evt])
          clearEvent(this, evt);
      } else {
        this._events = new Events;
        this._eventsCount = 0;
      }
      return this;
    };
    EventEmitter.prototype.off = EventEmitter.prototype.removeListener;
    EventEmitter.prototype.addListener = EventEmitter.prototype.on;
    EventEmitter.prefixed = prefix;
    EventEmitter.EventEmitter = EventEmitter;
    if (typeof module !== "undefined") {
      module.exports = EventEmitter;
    }
  });
  // ../../node_modules/.bun/eventemitter3@5.0.4/node_modules/eventemitter3/index.mjs
  var import__ = __toESM(require_eventemitter3(), 1);

  // ../../mobile/modules/miniapp/dist/envelope.js
  function serializeEnvelope(envelope) {
    return JSON.stringify(envelope);
  }
  function parseEnvelope(raw) {
    if (typeof raw !== "string")
      return null;
    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch {
      return null;
    }
    if (typeof parsed !== "object" || parsed === null)
      return null;
    const obj = parsed;
    if (typeof obj.payload !== "object" || obj.payload === null)
      return null;
    if (obj.requestId !== undefined && typeof obj.requestId !== "string")
      return null;
    return {
      payload: obj.payload,
      requestId: obj.requestId
    };
  }
  function makeRequestId() {
    if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
      return crypto.randomUUID();
    }
    return `req_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
  }

  // ../../mobile/modules/miniapp/dist/globals.js
  function getMentraOSGlobals() {
    if (typeof window === "undefined")
      return {};
    return window.MentraOS ?? {};
  }

  // ../../mobile/modules/miniapp/dist/protocol.js
  var MiniappRequestType;
  (function(MiniappRequestType2) {
    MiniappRequestType2["CONNECT"] = "miniapp_connect";
    MiniappRequestType2["AUTH_REFRESH"] = "miniapp_auth_refresh";
    MiniappRequestType2["SUBSCRIBE"] = "miniapp_subscribe";
    MiniappRequestType2["DISPLAY"] = "miniapp_display";
    MiniappRequestType2["RENDER"] = "miniapp_render";
    MiniappRequestType2["PLAY_AUDIO"] = "miniapp_play_audio";
    MiniappRequestType2["STOP_AUDIO"] = "miniapp_stop_audio";
    MiniappRequestType2["SPEAK"] = "miniapp_speak";
    MiniappRequestType2["SPEAKER_STREAM_OPEN"] = "miniapp_speaker_stream_open";
    MiniappRequestType2["SPEAKER_STREAM_WRITE"] = "miniapp_speaker_stream_write";
    MiniappRequestType2["SPEAKER_STREAM_CLOSE"] = "miniapp_speaker_stream_close";
    MiniappRequestType2["SPEAKER_STREAM_ABORT"] = "miniapp_speaker_stream_abort";
    MiniappRequestType2["RGB_LED"] = "miniapp_rgb_led";
    MiniappRequestType2["LOCATION_POLL"] = "miniapp_location_poll";
    MiniappRequestType2["CALENDAR_LIST_EVENTS"] = "miniapp_calendar_list_events";
    MiniappRequestType2["NAVIGATION_START"] = "miniapp_navigation_start";
    MiniappRequestType2["NAVIGATION_STOP"] = "miniapp_navigation_stop";
    MiniappRequestType2["NAVIGATION_DEVIATE"] = "miniapp_navigation_deviate";
    MiniappRequestType2["NAVIGATION_SET_WRONG_SIDEWALK"] = "miniapp_navigation_set_wrong_sidewalk";
    MiniappRequestType2["NAVIGATION_SET_SKIP_CROSSINGS"] = "miniapp_navigation_set_skip_crossings";
    MiniappRequestType2["NAVIGATION_GET_STATE"] = "miniapp_navigation_get_state";
    MiniappRequestType2["NAVIGATION_COMPUTE_ROUTE"] = "miniapp_navigation_compute_route";
    MiniappRequestType2["NAVIGATION_REVERSE_GEOCODE"] = "miniapp_navigation_reverse_geocode";
    MiniappRequestType2["NAVIGATION_PLACE_AUTOCOMPLETE"] = "miniapp_navigation_place_autocomplete";
    MiniappRequestType2["NAVIGATION_PLACE_DETAILS"] = "miniapp_navigation_place_details";
    MiniappRequestType2["NAVIGATION_REQUEST_PERMISSION"] = "miniapp_navigation_request_permission";
    MiniappRequestType2["STORAGE_GET"] = "miniapp_storage_get";
    MiniappRequestType2["STORAGE_SET"] = "miniapp_storage_set";
    MiniappRequestType2["STORAGE_DELETE"] = "miniapp_storage_delete";
    MiniappRequestType2["STORAGE_LIST"] = "miniapp_storage_list";
    MiniappRequestType2["STORAGE_CLEAR"] = "miniapp_storage_clear";
    MiniappRequestType2["STORAGE_HAS"] = "miniapp_storage_has";
    MiniappRequestType2["STORAGE_GET_ALL"] = "miniapp_storage_get_all";
    MiniappRequestType2["STORAGE_SET_MULTIPLE"] = "miniapp_storage_set_multiple";
    MiniappRequestType2["STORAGE_FLUSH"] = "miniapp_storage_flush";
    MiniappRequestType2["CAMERA_FOV"] = "miniapp_camera_fov";
    MiniappRequestType2["CAMERA_WARM_UP"] = "miniapp_camera_warm_up";
    MiniappRequestType2["IMU_SET_ENABLED"] = "miniapp_imu_set_enabled";
    MiniappRequestType2["MIC_SET_VAD_ENABLED"] = "miniapp_mic_set_vad_enabled";
    MiniappRequestType2["MIC_SET_LOUDNESS_GATE_ENABLED"] = "miniapp_mic_set_loudness_gate_enabled";
    MiniappRequestType2["SET_WIFI_ADB_STATE"] = "miniapp_set_wifi_adb_state";
    MiniappRequestType2["SHARE"] = "miniapp_share";
    MiniappRequestType2["OPEN_URL"] = "miniapp_open_url";
    MiniappRequestType2["COPY_CLIPBOARD"] = "miniapp_copy_clipboard";
    MiniappRequestType2["DOWNLOAD"] = "miniapp_download";
    MiniappRequestType2["SCAN_QR"] = "miniapp_scan_qr";
    MiniappRequestType2["BLOB_CREATE"] = "miniapp_blob_create";
    MiniappRequestType2["BLOB_WRITE"] = "miniapp_blob_write";
    MiniappRequestType2["BLOB_COMMIT"] = "miniapp_blob_commit";
    MiniappRequestType2["BLOB_ABORT"] = "miniapp_blob_abort";
    MiniappRequestType2["BLOB_GET"] = "miniapp_blob_get";
    MiniappRequestType2["BLOB_LIST"] = "miniapp_blob_list";
    MiniappRequestType2["BLOB_DELETE"] = "miniapp_blob_delete";
    MiniappRequestType2["BLOB_CLEAR"] = "miniapp_blob_clear";
    MiniappRequestType2["BLOB_USAGE"] = "miniapp_blob_usage";
    MiniappRequestType2["BLOB_OPEN_READ"] = "miniapp_blob_open_read";
    MiniappRequestType2["BLOB_READ"] = "miniapp_blob_read";
    MiniappRequestType2["BLOB_CLOSE_READ"] = "miniapp_blob_close_read";
    MiniappRequestType2["BLOB_SET_FROM_URL"] = "miniapp_blob_set_from_url";
    MiniappRequestType2["BLOB_IMPORT"] = "miniapp_blob_import";
    MiniappRequestType2["BLOB_SHARE"] = "miniapp_blob_share";
    MiniappRequestType2["PING"] = "miniapp_ping";
    MiniappRequestType2["TRANSCRIPTION_CONFIG"] = "miniapp_transcription_config";
    MiniappRequestType2["DASHBOARD_CONTENT_UPDATE"] = "miniapp_dashboard_content_update";
    MiniappRequestType2["PHOTO"] = "miniapp_photo";
    MiniappRequestType2["VIDEO_RECORDING_START"] = "miniapp_video_recording_start";
    MiniappRequestType2["VIDEO_RECORDING_STOP"] = "miniapp_video_recording_stop";
    MiniappRequestType2["STREAM_START"] = "miniapp_stream_start";
    MiniappRequestType2["STREAM_STOP"] = "miniapp_stream_stop";
    MiniappRequestType2["MANAGED_STREAM_START"] = "miniapp_managed_stream_start";
    MiniappRequestType2["MANAGED_STREAM_STOP"] = "miniapp_managed_stream_stop";
    MiniappRequestType2["REQUEST_WIFI_SETUP"] = "miniapp_request_wifi_setup";
    MiniappRequestType2["MINIAPPS_LIST"] = "miniapp_apps_list";
    MiniappRequestType2["MINIAPPS_START"] = "miniapp_apps_start";
    MiniappRequestType2["MINIAPPS_STOP"] = "miniapp_apps_stop";
    MiniappRequestType2["ACTION_INVOKE"] = "miniapp_action_invoke";
    MiniappRequestType2["ACTION_RESULT"] = "miniapp_action_result";
  })(MiniappRequestType || (MiniappRequestType = {}));
  var MiniappResponseType;
  (function(MiniappResponseType2) {
    MiniappResponseType2["CONNECT_ACK"] = "miniapp_connect_ack";
    MiniappResponseType2["EVENT"] = "miniapp_event";
    MiniappResponseType2["REQUEST_RESULT"] = "miniapp_request_result";
    MiniappResponseType2["CAPABILITIES_UPDATE"] = "miniapp_capabilities_update";
    MiniappResponseType2["VISIBILITY_CHANGE"] = "miniapp_visibility_change";
    MiniappResponseType2["COLOR_SCHEME_CHANGE"] = "miniapp_color_scheme_change";
    MiniappResponseType2["SPEAKER_STATE"] = "miniapp_speaker_state";
    MiniappResponseType2["PERMISSIONS_UPDATE"] = "miniapp_permissions_update";
    MiniappResponseType2["AUTH_UPDATE"] = "miniapp_auth_update";
    MiniappResponseType2["PONG"] = "miniapp_pong";
    MiniappResponseType2["ACTION_CALL"] = "miniapp_action_call";
    MiniappResponseType2["WILL_DISCONNECT"] = "miniapp_will_disconnect";
    MiniappResponseType2["ERROR"] = "miniapp_error";
  })(MiniappResponseType || (MiniappResponseType = {}));
  var MiniappStreamType;
  (function(MiniappStreamType2) {
    MiniappStreamType2["BUTTON_PRESS"] = "button_press";
    MiniappStreamType2["TOUCH_EVENT"] = "touch_event";
    MiniappStreamType2["HEAD_POSITION"] = "head_position";
    MiniappStreamType2["ACCEL_DATA"] = "accel_data";
    MiniappStreamType2["GLASSES_BATTERY"] = "glasses_battery";
    MiniappStreamType2["PHONE_BATTERY"] = "phone_battery";
    MiniappStreamType2["GLASSES_CONNECTION"] = "glasses_connection";
    MiniappStreamType2["GLASSES_WIFI"] = "glasses_wifi";
    MiniappStreamType2["TRANSCRIPTION"] = "transcription";
    MiniappStreamType2["TRANSLATION"] = "translation";
    MiniappStreamType2["AUDIO_CHUNK"] = "audio_chunk";
    MiniappStreamType2["VAD"] = "vad";
    MiniappStreamType2["LOCATION_UPDATE"] = "location_update";
    MiniappStreamType2["HEADING_UPDATE"] = "heading_update";
    MiniappStreamType2["NAVIGATION_UPDATE"] = "navigation_update";
    MiniappStreamType2["NAVIGATION_ROUTE"] = "navigation_route";
    MiniappStreamType2["PHONE_NOTIFICATION"] = "phone_notification";
    MiniappStreamType2["PHONE_NOTIFICATION_DISMISSED"] = "phone_notification_dismissed";
    MiniappStreamType2["PHOTO_TAKEN"] = "photo_taken";
    MiniappStreamType2["STREAM_STATUS"] = "stream_status";
  })(MiniappStreamType || (MiniappStreamType = {}));
  var MiniappErrorCode;
  (function(MiniappErrorCode2) {
    MiniappErrorCode2["INVALID_ARGUMENT"] = "INVALID_ARGUMENT";
    MiniappErrorCode2["PERMISSION_NOT_DECLARED"] = "PERMISSION_NOT_DECLARED";
    MiniappErrorCode2["PERMISSION_DENIED"] = "PERMISSION_DENIED";
    MiniappErrorCode2["NOT_IMPLEMENTED"] = "NOT_IMPLEMENTED";
    MiniappErrorCode2["REQUEST_ABORTED"] = "REQUEST_ABORTED";
    MiniappErrorCode2["INTERNAL"] = "INTERNAL";
    MiniappErrorCode2["TTS_TEXT_TOO_LONG"] = "TTS_TEXT_TOO_LONG";
    MiniappErrorCode2["TTS_INVALID_VOICE"] = "TTS_INVALID_VOICE";
    MiniappErrorCode2["TTS_UPSTREAM_ERROR"] = "TTS_UPSTREAM_ERROR";
    MiniappErrorCode2["TTS_LOCAL_UNAVAILABLE"] = "TTS_LOCAL_UNAVAILABLE";
    MiniappErrorCode2["NOT_CONNECTED"] = "NOT_CONNECTED";
    MiniappErrorCode2["NOT_PERMITTED"] = "NOT_PERMITTED";
    MiniappErrorCode2["APP_NOT_FOUND"] = "APP_NOT_FOUND";
    MiniappErrorCode2["APP_NOT_COMPATIBLE"] = "APP_NOT_COMPATIBLE";
    MiniappErrorCode2["ACTION_NOT_FOUND"] = "ACTION_NOT_FOUND";
    MiniappErrorCode2["NO_ACTION_HANDLER"] = "NO_ACTION_HANDLER";
    MiniappErrorCode2["WAKE_FAILED"] = "WAKE_FAILED";
    MiniappErrorCode2["ACTION_TIMEOUT"] = "ACTION_TIMEOUT";
    MiniappErrorCode2["PAYLOAD_TOO_LARGE"] = "PAYLOAD_TOO_LARGE";
    MiniappErrorCode2["BLOB_NOT_FOUND"] = "BLOB_NOT_FOUND";
    MiniappErrorCode2["BLOB_QUOTA_EXCEEDED"] = "BLOB_QUOTA_EXCEEDED";
    MiniappErrorCode2["BLOB_TOO_LARGE"] = "BLOB_TOO_LARGE";
    MiniappErrorCode2["BLOB_HANDLE_INVALID"] = "BLOB_HANDLE_INVALID";
    MiniappErrorCode2["BLOB_WRITE_FAILED"] = "BLOB_WRITE_FAILED";
    MiniappErrorCode2["BLOB_DOWNLOAD_FAILED"] = "BLOB_DOWNLOAD_FAILED";
    MiniappErrorCode2["BLOB_IMPORT_FAILED"] = "BLOB_IMPORT_FAILED";
  })(MiniappErrorCode || (MiniappErrorCode = {}));

  // ../../mobile/modules/miniapp/dist/transport/dispatch.js
  class DispatchTransport {
    constructor() {
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.open_ = false;
    }
    static isAvailable() {
      return typeof globalThis.__dispatch === "function";
    }
    async open() {
      if (!DispatchTransport.isAvailable()) {
        throw new Error("DispatchTransport: __dispatch is not installed on globalThis");
      }
      const g = globalThis;
      g.__mentraDeliverBridgeRaw = (raw) => {
        if (this.messageHandler)
          this.messageHandler(raw);
      };
      this.open_ = true;
    }
    send(raw) {
      if (!this.open_) {
        throw new Error("DispatchTransport: send() before open()");
      }
      const g = globalThis;
      if (typeof g.__dispatch !== "function") {
        this.open_ = false;
        this.disconnectHandler?.("DispatchTransport: __dispatch disappeared");
        return;
      }
      try {
        g.__dispatch("__bridge", "send", JSON.stringify([raw]));
      } catch (e) {
        this.disconnectHandler?.(`DispatchTransport: __dispatch threw: ${String(e)}`);
      }
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      this.open_ = false;
      const g = globalThis;
      if (g.__mentraDeliverBridgeRaw) {
        delete g.__mentraDeliverBridgeRaw;
      }
    }
    isOpen() {
      return this.open_;
    }
  }

  // ../../mobile/modules/miniapp/dist/transport/local-socket.js
  var DEFAULT_URL = "ws://127.0.0.1:8765";

  class LocalSocketTransport {
    constructor(options = {}) {
      this.ws = null;
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.url = options.url ?? DEFAULT_URL;
    }
    async open() {
      if (this.ws && this.ws.readyState === WebSocket.OPEN)
        return;
      if (typeof WebSocket === "undefined") {
        throw new Error("LocalSocketTransport: browser WebSocket global not available");
      }
      await new Promise((resolve, reject) => {
        const ws = new WebSocket(this.url);
        let settled = false;
        const settle = (fn) => {
          if (settled)
            return;
          settled = true;
          fn();
        };
        ws.onopen = () => {
          this.ws = ws;
          settle(() => resolve());
        };
        ws.onerror = (ev) => {
          settle(() => reject(new Error(`LocalSocketTransport: failed to connect to ${this.url}: ${String(ev)}`)));
        };
        ws.onmessage = (ev) => {
          const data = ev.data;
          if (typeof data === "string")
            this.messageHandler?.(data);
        };
        ws.onclose = (ev) => {
          if (this.ws === ws)
            this.ws = null;
          this.disconnectHandler?.(`closed: ${ev.code} ${ev.reason}`);
        };
      });
    }
    send(raw) {
      if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
        throw new Error("LocalSocketTransport: not connected");
      }
      this.ws.send(raw);
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      if (!this.ws)
        return;
      try {
        this.ws.close();
      } catch {}
      this.ws = null;
    }
    isOpen() {
      return !!this.ws && this.ws.readyState === WebSocket.OPEN;
    }
  }

  // ../../mobile/modules/miniapp/dist/transport/mock.js
  var LOG_PREFIX = "[mock-transport]";
  function isMockExplicitlyRequested() {
    if (typeof window === "undefined")
      return false;
    try {
      if (typeof window.location !== "undefined" && window.location.search) {
        const params = new URLSearchParams(window.location.search);
        if (params.get("mentra") === "mock")
          return true;
      }
    } catch {}
    try {
      if (typeof localStorage !== "undefined" && localStorage.getItem("MENTRA_MOCK") === "1") {
        return true;
      }
    } catch {}
    return false;
  }

  class MockTransport {
    constructor(options = {}) {
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.open_ = false;
      this.userId = options.userId ?? "mock-user";
      this.authToken = options.authToken ?? "mock-miniapp-token";
      this.packageName = options.packageName ?? null;
      this.silent = options.silent === true;
    }
    async open() {
      if (this.open_)
        return;
      this.open_ = true;
      this.log("transport opened (no real host; synthetic responses only)");
    }
    send(raw) {
      if (!this.open_) {
        throw new Error("MockTransport: send() before open()");
      }
      const envelope = parseEnvelope(raw);
      if (!envelope) {
        this.log("dropped unparseable envelope:", raw.slice(0, 200));
        return;
      }
      const payload = envelope.payload;
      const type = payload?.type;
      this.log(`recv ${type ?? "<unknown>"}${envelope.requestId ? ` (rid=${envelope.requestId})` : ""}`);
      switch (type) {
        case MiniappRequestType.CONNECT:
          this.deliverConnectAck(payload);
          return;
        case MiniappRequestType.PING:
          return;
        case MiniappRequestType.SUBSCRIBE:
          return;
        default:
          if (envelope.requestId) {
            this.deliverSyntheticResult(envelope.requestId, type ?? "<unknown>", payload);
          }
          return;
      }
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      if (!this.open_)
        return;
      this.open_ = false;
      this.disconnectHandler?.("MockTransport.close()");
    }
    isOpen() {
      return this.open_;
    }
    deliverConnectAck(connectPayload) {
      const incomingPackage = connectPayload.packageName ?? this.packageName ?? "com.mock.app";
      const ackPayload = {
        type: MiniappResponseType.CONNECT_ACK,
        userId: this.userId,
        packageName: incomingPackage,
        capabilities: null,
        visibility: "foreground",
        colorScheme: "light",
        auth: {
          mentraUserId: this.userId,
          oemId: "mock",
          token: this.authToken,
          expiresAt: Date.now() + 60 * 60 * 1000
        }
      };
      const envelope = { payload: ackPayload };
      this.log(`-> CONNECT_ACK userId=${this.userId} pkg=${incomingPackage}`);
      queueMicrotask(() => this.messageHandler?.(serializeEnvelope(envelope)));
    }
    deliverSyntheticResult(requestId, requestType, requestPayload) {
      const data = syntheticDataFor(requestId, requestType, requestPayload);
      const responsePayload = {
        type: MiniappResponseType.REQUEST_RESULT,
        ok: true,
        data
      };
      const envelope = { payload: responsePayload, requestId };
      this.log(`-> REQUEST_RESULT (rid=${requestId}) synthetic ${requestType}`);
      queueMicrotask(() => this.messageHandler?.(serializeEnvelope(envelope)));
    }
    log(...args) {
      if (this.silent)
        return;
      console.log(LOG_PREFIX, ...args);
    }
  }
  function syntheticDataFor(requestId, requestType, requestPayload) {
    switch (requestType) {
      case MiniappRequestType.CAMERA_FOV: {
        const presetFov = requestPayload.preset === "narrow" ? 82 : requestPayload.preset === "wide" ? 118 : requestPayload.preset === "standard" ? 102 : undefined;
        const fov = typeof requestPayload.fov === "number" ? requestPayload.fov : presetFov ?? 102;
        const roi = requestPayload.roiPosition;
        const roiPosition = roi === "bottom" ? "bottom" : roi === "top" ? "top" : "center";
        return {
          requestId,
          fov,
          roiPosition,
          timestamp: Date.now()
        };
      }
      case MiniappRequestType.PHOTO:
        return {
          photoUrl: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkAAIAAAoAAv/lxKUAAAAASUVORK5CYII=",
          requestId: "mock-photo"
        };
      case MiniappRequestType.RGB_LED:
        return { type: "rgb_led_control_response", state: "success", requestId };
      case MiniappRequestType.LOCATION_POLL:
        return { lat: 37.7956, lng: -122.3933, accuracy: 0, timestamp: Date.now() };
      case MiniappRequestType.CALENDAR_LIST_EVENTS:
        return { events: [], truncated: false };
      case MiniappRequestType.STORAGE_GET:
        return { value: null };
      case MiniappRequestType.STORAGE_LIST:
        return { keys: [] };
      case MiniappRequestType.SPEAK:
        return { audioUrl: null, durationMs: 0 };
      case MiniappRequestType.SHARE:
      case MiniappRequestType.OPEN_URL:
      case MiniappRequestType.COPY_CLIPBOARD:
      case MiniappRequestType.DOWNLOAD:
      case MiniappRequestType.REQUEST_WIFI_SETUP:
      case MiniappRequestType.SET_WIFI_ADB_STATE:
        return { ok: true };
      case MiniappRequestType.SCAN_QR:
        return { cancelled: true };
      default:
        return null;
    }
  }

  // ../../mobile/modules/miniapp/dist/transport/postmessage.js
  class PostMessageTransport {
    constructor() {
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.open_ = false;
      this.windowListener = null;
    }
    async open() {
      if (this.open_)
        return;
      if (typeof window === "undefined" || !window.ReactNativeWebView) {
        throw new Error("PostMessageTransport: not running inside a React Native WebView");
      }
      this.windowListener = (ev) => {
        const data = ev.data;
        if (typeof data !== "string")
          return;
        this.messageHandler?.(data);
      };
      window.addEventListener("message", this.windowListener);
      if (typeof document !== "undefined") {
        document.addEventListener("message", this.windowListener);
      }
      window.receiveNativeMessage = (raw) => {
        this.messageHandler?.(raw);
      };
      this.open_ = true;
    }
    send(raw) {
      if (typeof window === "undefined" || !window.ReactNativeWebView) {
        throw new Error("PostMessageTransport: not running inside a React Native WebView");
      }
      window.ReactNativeWebView.postMessage(raw);
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      if (!this.open_)
        return;
      this.open_ = false;
      if (this.windowListener) {
        window.removeEventListener("message", this.windowListener);
        if (typeof document !== "undefined") {
          document.removeEventListener("message", this.windowListener);
        }
        this.windowListener = null;
      }
      if (typeof window !== "undefined" && window.receiveNativeMessage) {
        window.receiveNativeMessage = undefined;
      }
      this.disconnectHandler?.("closed");
    }
    isOpen() {
      return this.open_;
    }
  }

  // ../../mobile/modules/miniapp/dist/transport/auto.js
  var LOCAL_SOCKET_OPEN_TIMEOUT_MS = 500;
  function createTransport(options = {}) {
    if (options.transport)
      return options.transport;
    if (DispatchTransport.isAvailable()) {
      return new DispatchTransport;
    }
    if (typeof window !== "undefined" && window.ReactNativeWebView) {
      return new PostMessageTransport;
    }
    if (isMockExplicitlyRequested()) {
      return new MockTransport;
    }
    if (typeof WebSocket !== "undefined") {
      const localSocketOptions = {};
      if (options.localSocketUrl)
        localSocketOptions.url = options.localSocketUrl;
      return new LocalSocketWithMockFallback(localSocketOptions);
    }
    return new MockTransport;
  }

  class LocalSocketWithMockFallback {
    constructor(options) {
      this.options = options;
      this.active = null;
      this.messageHandler = null;
      this.disconnectHandler = null;
    }
    async open() {
      const local = new LocalSocketTransport(this.options);
      let timedOut = false;
      const timeout = new Promise((_, reject) => {
        setTimeout(() => {
          timedOut = true;
          reject(new Error("LocalSocketTransport open timed out"));
        }, LOCAL_SOCKET_OPEN_TIMEOUT_MS);
      });
      try {
        await Promise.race([local.open(), timeout]);
        this.active = local;
      } catch {
        try {
          local.close();
        } catch {}
        const mock = new MockTransport;
        await mock.open();
        this.active = mock;
        console.log(timedOut ? "[mentra-miniapp] No phone WebSocket reachable; using MockTransport so the page can render." : "[mentra-miniapp] LocalSocketTransport failed; using MockTransport.");
      }
      if (this.messageHandler)
        this.active.onMessage(this.messageHandler);
      if (this.disconnectHandler)
        this.active.onDisconnect(this.disconnectHandler);
    }
    send(raw) {
      if (!this.active)
        throw new Error("LocalSocketWithMockFallback: send() before open()");
      this.active.send(raw);
    }
    onMessage(handler) {
      this.messageHandler = handler;
      this.active?.onMessage(handler);
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
      this.active?.onDisconnect(handler);
    }
    close() {
      this.active?.close();
    }
    isOpen() {
      return this.active?.isOpen() === true;
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/camera.js
  class CameraModule {
    constructor(session) {
      this.session = session;
    }
    get hasPermission() {
      return this.session._hasManifestPermission("CAMERA");
    }
    async setFov(request) {
      return this.session.sendRequest({
        type: MiniappRequestType.CAMERA_FOV,
        ...request
      });
    }
    async takePhoto(options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.PHOTO,
        size: options.size ?? "medium",
        mode: options.mode ?? "photo",
        ...options.transferMethod !== undefined ? { transferMethod: options.transferMethod } : {},
        compress: options.compress ?? "none",
        sound: options.sound ?? true,
        saveToGallery: options.saveToGallery ?? false,
        exposureTimeNs: options.exposureTimeNs,
        iso: options.iso,
        aeExposureDivisor: options.aeExposureDivisor,
        isoCap: options.isoCap,
        noiseReduction: options.noiseReduction,
        edgeEnhancement: options.edgeEnhancement,
        zsl: options.zsl,
        mfnr: options.mfnr,
        ispDigitalGain: options.ispDigitalGain,
        ispAnalogGain: options.ispAnalogGain
      }, options.timeoutMs != null ? { timeoutMs: options.timeoutMs } : undefined);
    }
    async warmUp(options = {}) {
      await this.session.sendRequest({
        type: MiniappRequestType.CAMERA_WARM_UP,
        size: options.size ?? "medium",
        mode: options.mode ?? "photo",
        exposureTimeNs: options.exposureTimeNs,
        durationMs: options.durationMs ?? 15000,
        zsl: options.zsl,
        mfnr: options.mfnr
      });
    }
    async startVideoRecording(options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.VIDEO_RECORDING_START,
        width: options.width,
        height: options.height,
        fps: options.fps,
        sound: options.sound ?? true,
        save: options.save ?? false
      });
    }
    async stopVideoRecording(recordingId, options = {}) {
      await this.session.sendRequest({
        type: MiniappRequestType.VIDEO_RECORDING_STOP,
        recordingId,
        uploadUrl: options.uploadUrl,
        uploadAuthToken: options.uploadAuthToken
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/auth.js
  var DEFAULT_MIN_TTL_MS = 30000;

  class AuthModule {
    constructor(session) {
      this.session = session;
    }
    get current() {
      return this.session._getAuth();
    }
    get mentraUserId() {
      return this.current?.mentraUserId ?? null;
    }
    get oemId() {
      return this.current?.oemId ?? null;
    }
    async getToken(options = {}) {
      const auth = await this.session._waitForAuth(options.minTtlMs ?? DEFAULT_MIN_TTL_MS);
      return auth.token;
    }
    async getAuthHeader(options = {}) {
      return `Bearer ${await this.getToken(options)}`;
    }
    async fetch(input, init = {}) {
      const { minTtlMs, ...requestInit } = init;
      const token = await this.getToken({ minTtlMs });
      const headers = mergeHeaders(requestInit.headers, { Authorization: `Bearer ${token}` });
      return fetch(input, { ...requestInit, headers });
    }
    onUpdate(handler) {
      return this.session.on("auth", handler);
    }
  }
  function mergeHeaders(base, next) {
    const headers = {};
    if (Array.isArray(base)) {
      for (const [key, value] of base) {
        headers[key] = value;
      }
    } else if (typeof Headers !== "undefined" && base instanceof Headers) {
      base.forEach((value, key) => {
        headers[key] = value;
      });
    } else if (base && typeof base === "object") {
      for (const [key, value] of Object.entries(base)) {
        if (typeof value === "string")
          headers[key] = value;
      }
    }
    return { ...headers, ...next };
  }

  // ../../mobile/modules/miniapp/dist/modules/cloud.js
  var CLOUD_STATUS_STREAM = "_cloud_status";
  var DEFAULT_STATUS = {
    status: "disconnected",
    audioTransport: "none"
  };
  function normalizeCloudStatus(data) {
    if (!data || typeof data !== "object")
      return null;
    const raw = data;
    const status = raw.status;
    const audioTransport = raw.audioTransport;
    if (status !== "connected" && status !== "connecting" && status !== "reconnecting" && status !== "disconnected") {
      return null;
    }
    if (audioTransport !== "udp" && audioTransport !== "ws" && audioTransport !== "offline" && audioTransport !== "none") {
      return null;
    }
    return { status, audioTransport };
  }

  class CloudModule {
    constructor(session) {
      this.session = session;
      this.emitter = new import__.default;
      this.current = { ...DEFAULT_STATUS };
      this.session._subscribe(CLOUD_STATUS_STREAM, (data) => {
        const next = normalizeCloudStatus(data);
        if (!next)
          return;
        if (next.status === this.current.status && next.audioTransport === this.current.audioTransport)
          return;
        this.current = next;
        this.emitter.emit("status", { ...this.current });
      });
    }
    get status() {
      return { ...this.current };
    }
    get connected() {
      return this.current.status === "connected";
    }
    isConnected() {
      return this.connected;
    }
    onStatusChanged(handler) {
      handler({ ...this.current });
      this.emitter.on("status", handler);
      return () => {
        this.emitter.off("status", handler);
      };
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/dashboard.js
  class DashboardAPI {
    constructor(session) {
      this.session = session;
      this.warned = false;
    }
    setContent(mode, content) {
      if (!this.warned) {
        console.warn("[@mentra/miniapp] dashboard.setContent() is deferred in v1.");
        this.warned = true;
      }
      this.session.sendOneShot({
        type: MiniappRequestType.DASHBOARD_CONTENT_UPDATE,
        mode,
        content
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/display.js
  class DisplayManager {
    constructor(session) {
      this.session = session;
    }
    render(elements, options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.RENDER,
        view: options.view ?? "main",
        elements,
        durationMs: options.durationMs
      }).catch((err) => ({
        status: "blocked",
        reason: typeof err === "object" && err !== null && "message" in err ? String(err.message) : String(err)
      }));
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/events.js
  class EventManager {
    constructor(session) {
      this.session = session;
      this.emitter = new import__.default;
      this.refCounts = new Map;
      this.forceLocalRefCounts = new Map;
    }
    subscribe(stream, handler, options = {}) {
      const isInternal = stream.startsWith("_");
      const forceLocal = options.forceLocal === true && stream.startsWith(`${MiniappStreamType.TRANSCRIPTION}:`);
      const listener = (data, route) => {
        if (stream.startsWith(`${MiniappStreamType.TRANSCRIPTION}:`)) {
          if (forceLocal ? route !== "forceLocal" && route !== "all" : route === "forceLocal")
            return;
        }
        handler(data);
      };
      this.emitter.on(stream, listener);
      if (!isInternal) {
        const before = this.refCounts.get(stream) ?? 0;
        this.refCounts.set(stream, before + 1);
        const forceLocalBefore = this.forceLocalRefCounts.get(stream) ?? 0;
        const defaultBefore = before - forceLocalBefore;
        if (forceLocal)
          this.forceLocalRefCounts.set(stream, forceLocalBefore + 1);
        if (before === 0 || forceLocal && forceLocalBefore === 0 || !forceLocal && defaultBefore === 0) {
          this.sendSubscriptionUpdate();
        }
      }
      return () => {
        this.emitter.off(stream, listener);
        if (isInternal)
          return;
        const current = this.refCounts.get(stream) ?? 0;
        const forceLocalCurrent = this.forceLocalRefCounts.get(stream) ?? 0;
        let subscriptionChanged = current <= 1;
        if (current <= 1) {
          this.refCounts.delete(stream);
        } else {
          this.refCounts.set(stream, current - 1);
        }
        if (forceLocal) {
          if (forceLocalCurrent <= 1) {
            this.forceLocalRefCounts.delete(stream);
            subscriptionChanged = true;
          } else {
            this.forceLocalRefCounts.set(stream, forceLocalCurrent - 1);
          }
        } else if (current - forceLocalCurrent <= 1) {
          subscriptionChanged = true;
        }
        if (subscriptionChanged)
          this.sendSubscriptionUpdate();
      };
    }
    unsubscribeAll() {
      this.emitter.removeAllListeners();
      this.refCounts.clear();
      this.forceLocalRefCounts.clear();
      this.sendSubscriptionUpdate();
    }
    _forwardEvent(stream, data, transcriptionRoute) {
      this.emitter.emit(stream, data, transcriptionRoute);
      if (stream.startsWith("transcription:") && stream !== "transcription:auto") {
        this.emitter.emit("transcription:auto", data, transcriptionRoute);
      } else if (stream.startsWith("translation:")) {
        const parts = stream.split(":");
        const patterns = new Set(["translation:auto"]);
        if (parts.length === 3) {
          const [, source, target] = parts;
          patterns.add("translation:*:*");
          patterns.add(`translation:*:${target}`);
          patterns.add(`translation:${source}:*`);
        }
        patterns.delete(stream);
        for (const pattern of patterns) {
          this.emitter.emit(pattern, data);
        }
      }
    }
    sendSubscriptionUpdate() {
      const subscriptions = Array.from(this.refCounts.keys()).map((stream) => {
        if (stream === MiniappStreamType.LOCATION_UPDATE)
          return { stream: "location_stream", rate: "realtime" };
        const forceLocalRefs = this.forceLocalRefCounts.get(stream) ?? 0;
        if (forceLocalRefs === 0)
          return stream;
        const totalRefs = this.refCounts.get(stream) ?? 0;
        return {
          stream,
          forceLocal: true,
          ...totalRefs > forceLocalRefs ? { includeCloud: true } : {}
        };
      });
      this.session.sendOneShot({
        type: MiniappRequestType.SUBSCRIBE,
        subscriptions
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/glasses.js
  class GlassesModule {
    constructor(session) {
      this.session = session;
    }
    onBattery(handler) {
      return this.session._subscribe(MiniappStreamType.GLASSES_BATTERY, handler);
    }
    onConnection(handler) {
      return this.session._subscribe(MiniappStreamType.GLASSES_CONNECTION, handler);
    }
    onWifi(handler) {
      return this.session._subscribe(MiniappStreamType.GLASSES_WIFI, handler);
    }
    async requestWifiSetup(reason) {
      await this.session.sendRequest({
        type: MiniappRequestType.REQUEST_WIFI_SETUP,
        reason
      });
    }
    async setWifiAdbState(enabled) {
      await this.session.sendRequest({
        type: MiniappRequestType.SET_WIFI_ADB_STATE,
        enabled
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/heading.js
  class HeadingModule {
    constructor(session) {
      this.session = session;
    }
    get hasPermission() {
      return this.session._hasManifestPermission("LOCATION");
    }
    onUpdate(handler) {
      return this.session._subscribe(MiniappStreamType.HEADING_UPDATE, handler);
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/imu.js
  class ImuModule {
    constructor(session) {
      this.session = session;
    }
    onHeadPosition(handler) {
      return this.session._subscribe(MiniappStreamType.HEAD_POSITION, handler);
    }
    onAccel(handler) {
      return this.session._subscribe(MiniappStreamType.ACCEL_DATA, handler);
    }
    setEnabled(enabled) {
      return this.session.sendRequest({
        type: MiniappRequestType.IMU_SET_ENABLED,
        enabled
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/input.js
  class InputModule {
    constructor(session) {
      this.session = session;
    }
    onButtonPress(handler) {
      return this.session._subscribe(MiniappStreamType.BUTTON_PRESS, handler);
    }
    onTouch(gestureOrHandler, maybeHandler) {
      if (typeof gestureOrHandler === "function") {
        return this.session._subscribe(MiniappStreamType.TOUCH_EVENT, gestureOrHandler);
      }
      const handler = maybeHandler;
      const gestures = Array.isArray(gestureOrHandler) ? gestureOrHandler : [gestureOrHandler];
      if (gestures.length === 0)
        return () => {};
      const unsubs = [];
      for (const g of gestures) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TOUCH_EVENT}:${g}`, handler));
      }
      return () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/led.js
  class LedModule {
    constructor(session) {
      this.session = session;
    }
    async turnOn(options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.RGB_LED,
        action: "on",
        color: options.color ?? "red",
        ontime: options.ontime ?? 1000,
        offtime: options.offtime ?? 0,
        count: options.count ?? 1
      });
    }
    async turnOff() {
      return this.session.sendRequest({
        type: MiniappRequestType.RGB_LED,
        action: "off"
      });
    }
    async blink(color, ontime, offtime, count) {
      return this.turnOn({ color, ontime, offtime, count });
    }
    async solid(color, duration) {
      return this.turnOn({ color, ontime: duration, offtime: 0, count: 1 });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/location.js
  class LocationModule {
    constructor(session) {
      this.session = session;
    }
    get hasPermission() {
      return this.session._hasManifestPermission("LOCATION");
    }
    onUpdate(handler) {
      return this.session._subscribe(MiniappStreamType.LOCATION_UPDATE, handler);
    }
    getOnce() {
      return this.session.sendRequest({
        type: MiniappRequestType.LOCATION_POLL
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/mic.js
  class MicModule {
    constructor(session) {
      this.session = session;
      this.unsubs = new Set;
    }
    onVoiceActivity(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.VAD, handler));
    }
    onAudioChunk(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.AUDIO_CHUNK, handler));
    }
    setVoiceActivityDetectionEnabled(enabled) {
      return this.session.sendRequest({
        type: MiniappRequestType.MIC_SET_VAD_ENABLED,
        enabled
      });
    }
    setLoudnessGateEnabled(enabled) {
      return this.session.sendRequest({
        type: MiniappRequestType.MIC_SET_LOUDNESS_GATE_ENABLED,
        enabled
      });
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
    get hasPermission() {
      return this.session._hasManifestPermission("MICROPHONE");
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/pivots/geometry.js
  var TURN_THRESHOLD_DEG = 15;
  var SAME_DIR_MERGE_M = 25;
  var RDP_EPSILON_M = 5;
  var MIN_BEND_PER_POINT_DEG = 10;
  var STRAIGHT_SEGMENT_BREAK_M = 1;
  var INTERSECTION_CLUSTER_M = 30;
  function haversineMeters(a, b) {
    const R = 6371000;
    const toRad = (d) => d * Math.PI / 180;
    const dLat = toRad(b.lat - a.lat);
    const dLng = toRad(b.lng - a.lng);
    const lat1 = toRad(a.lat);
    const lat2 = toRad(b.lat);
    const x = Math.sin(dLat / 2) ** 2 + Math.sin(dLng / 2) ** 2 * Math.cos(lat1) * Math.cos(lat2);
    return 2 * R * Math.asin(Math.sqrt(x));
  }
  function bearingDeg(a, b) {
    const toRad = (d) => d * Math.PI / 180;
    const toDeg = (r) => r * 180 / Math.PI;
    const lat1 = toRad(a.lat);
    const lat2 = toRad(b.lat);
    const dLng = toRad(b.lng - a.lng);
    const y = Math.sin(dLng) * Math.cos(lat2);
    const x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLng);
    return (toDeg(Math.atan2(y, x)) + 360) % 360;
  }
  function signedAngleDiff(target, actual) {
    return (target - actual + 540) % 360 - 180;
  }
  function rdpSimplify(points, epsilonMeters) {
    if (points.length < 3)
      return points.map((_, i) => i);
    const keep = new Array(points.length).fill(false);
    keep[0] = true;
    keep[points.length - 1] = true;
    const stack = [[0, points.length - 1]];
    while (stack.length) {
      const [lo, hi] = stack.pop();
      let maxDist = 0;
      let maxIdx = -1;
      for (let i = lo + 1;i < hi; i++) {
        const d = perpDistMeters(points[i], points[lo], points[hi]);
        if (d > maxDist) {
          maxDist = d;
          maxIdx = i;
        }
      }
      if (maxIdx !== -1 && maxDist > epsilonMeters) {
        keep[maxIdx] = true;
        stack.push([lo, maxIdx], [maxIdx, hi]);
      }
    }
    const out = [];
    for (let i = 0;i < keep.length; i++)
      if (keep[i])
        out.push(i);
    return out;
  }
  function perpDistMeters(p, a, b) {
    const mPerDegLat = 111320;
    const mPerDegLng = 111320 * Math.cos(a.lat * Math.PI / 180);
    const bx = (b.lng - a.lng) * mPerDegLng;
    const by = (b.lat - a.lat) * mPerDegLat;
    const px = (p.lng - a.lng) * mPerDegLng;
    const py = (p.lat - a.lat) * mPerDegLat;
    const dx = bx;
    const dy = by;
    const len = Math.sqrt(dx * dx + dy * dy);
    if (len === 0)
      return Math.sqrt(px * px + py * py);
    return Math.abs(dx * -py - -px * dy) / len;
  }
  function extractPivots(rawPoints) {
    if (rawPoints.length < 3)
      return [];
    const keptIdx = rdpSimplify(rawPoints, RDP_EPSILON_M);
    const simplified = keptIdx.map((i) => rawPoints[i]);
    if (simplified.length < 3)
      return [];
    const deltas = [];
    for (let i = 1;i < simplified.length - 1; i++) {
      const inBearing = bearingDeg(simplified[i - 1], simplified[i]);
      const outBearing = bearingDeg(simplified[i], simplified[i + 1]);
      deltas.push(signedAngleDiff(outBearing, inBearing));
    }
    const candidates = [];
    let runStart = -1;
    let runSum = 0;
    let runSign = 0;
    const flushRun = (endExclusive) => {
      if (runStart === -1)
        return;
      if (Math.abs(runSum) >= TURN_THRESHOLD_DEG) {
        let bestIdx = runStart;
        let bestAbs = 0;
        for (let k = runStart;k < endExclusive; k++) {
          const a = Math.abs(deltas[k]);
          if (a > bestAbs) {
            bestAbs = a;
            bestIdx = k;
          }
        }
        const simplifiedIdx = bestIdx + 1;
        candidates.push({
          lat: simplified[simplifiedIdx].lat,
          lng: simplified[simplifiedIdx].lng,
          direction: runSum > 0 ? "right" : "left",
          simplifiedRouteIndex: simplifiedIdx,
          rawRouteIndex: keptIdx[simplifiedIdx],
          headingDelta: runSum
        });
      }
      runStart = -1;
      runSum = 0;
      runSign = 0;
    };
    let metersSinceLastBend = 0;
    for (let k = 0;k < deltas.length; k++) {
      const d = deltas[k];
      const sign = d > 0 ? 1 : d < 0 ? -1 : 0;
      const segLen = haversineMeters(simplified[k + 1], simplified[k + 2]);
      if (sign === 0 || Math.abs(d) < MIN_BEND_PER_POINT_DEG) {
        if (runStart !== -1) {
          if (sign === runSign || sign === 0)
            runSum += d;
          metersSinceLastBend += segLen;
          if (metersSinceLastBend >= STRAIGHT_SEGMENT_BREAK_M) {
            flushRun(k + 1);
          }
        }
        continue;
      }
      if (runStart === -1) {
        runStart = k;
        runSum = d;
        runSign = sign;
        metersSinceLastBend = segLen;
      } else if (sign === runSign) {
        if (metersSinceLastBend >= STRAIGHT_SEGMENT_BREAK_M) {
          flushRun(k);
          runStart = k;
          runSum = d;
          runSign = sign;
        } else {
          runSum += d;
        }
        metersSinceLastBend = segLen;
      } else {
        flushRun(k);
        runStart = k;
        runSum = d;
        runSign = sign;
        metersSinceLastBend = segLen;
      }
    }
    flushRun(deltas.length);
    const merged = [];
    for (const p of candidates) {
      const last = merged[merged.length - 1];
      if (last && last.direction === p.direction && haversineMeters({ lat: last.lat, lng: last.lng }, { lat: p.lat, lng: p.lng }) < SAME_DIR_MERGE_M) {
        if (Math.abs(p.headingDelta) > Math.abs(last.headingDelta)) {
          merged[merged.length - 1] = p;
        }
        continue;
      }
      merged.push(p);
    }
    const clustered = [];
    for (const p of merged) {
      const last = clustered[clustered.length - 1];
      if (last && haversineMeters({ lat: last.lat, lng: last.lng }, { lat: p.lat, lng: p.lng }) < INTERSECTION_CLUSTER_M) {
        const netDelta = last.headingDelta + p.headingDelta;
        const anchor = Math.abs(p.headingDelta) > Math.abs(last.headingDelta) ? p : last;
        clustered[clustered.length - 1] = {
          ...anchor,
          direction: netDelta > 0 ? "right" : "left",
          headingDelta: netDelta
        };
        continue;
      }
      clustered.push(p);
    }
    return clustered.filter((p) => Math.abs(p.headingDelta) >= TURN_THRESHOLD_DEG);
  }
  function cumulativeDistances(points) {
    const out = new Array(points.length);
    out[0] = 0;
    for (let i = 1;i < points.length; i++) {
      out[i] = out[i - 1] + haversineMeters(points[i - 1], points[i]);
    }
    return out;
  }

  // ../../mobile/modules/miniapp/dist/modules/pivots/instructions.js
  var DIRECTION_WORDS = new Set(["right", "left", "the right", "the left", "north", "south", "east", "west"]);
  var MANEUVER_VERBS = /\b(turn|slight|sharp|continue|head|merge|exit|uturn|u-turn|then|keep)\b/i;
  function roadNameFromInstruction(instruction) {
    if (!instruction)
      return null;
    const firstLine = instruction.split(`
`)[0] ?? "";
    const m = firstLine.match(/\bonto\s+(.+)$/i);
    let raw = (m ? m[1] : "").trim();
    if (!raw)
      return null;
    if (raw.includes(","))
      return null;
    raw = raw.split(/\s+(?:toward|towards|to|and|then|for)\b/i)[0]?.trim() ?? "";
    raw = raw.replace(/\s+#.*$/, "").trim();
    if (!raw)
      return null;
    if (DIRECTION_WORDS.has(raw.toLowerCase()))
      return null;
    if (MANEUVER_VERBS.test(raw))
      return null;
    return raw;
  }
  var ROAD_SUFFIXES = /\b(st|street|ave|avenue|blvd|boulevard|rd|road|dr|drive|ln|lane|way|ct|court|pl|place|ter|terrace|hwy|highway)\b\.?/g;
  function normalizeRoad(road) {
    return road.toLowerCase().replace(ROAD_SUFFIXES, "").replace(/[^a-z0-9 ]/g, "").replace(/\s+/g, " ").trim();
  }
  function sameRoad(a, b) {
    return normalizeRoad(a) === normalizeRoad(b);
  }
  function turnDirection(maneuver) {
    if (!maneuver)
      return null;
    const m = maneuver.toUpperCase();
    if (m.includes("LEFT"))
      return "left";
    if (m.includes("RIGHT"))
      return "right";
    return null;
  }
  var PROBE_METERS = 22;
  function signedBendAt(points, junction) {
    if (points.length < 3)
      return null;
    let mid = 0;
    let bestDist = Infinity;
    for (let i = 0;i < points.length; i++) {
      const d = haversineMeters(points[i], junction);
      if (d < bestDist) {
        bestDist = d;
        mid = i;
      }
    }
    let before = mid;
    while (before > 0 && haversineMeters(points[before], points[mid]) < PROBE_METERS)
      before--;
    let after = mid;
    while (after < points.length - 1 && haversineMeters(points[after], points[mid]) < PROBE_METERS)
      after++;
    if (before === mid || after === mid)
      return null;
    const incoming = bearingDeg(points[before], points[mid]);
    const outgoing = bearingDeg(points[mid], points[after]);
    return signedAngleDiff(outgoing, incoming);
  }
  var MIN_TURN_ANGLE_DEG = 30;
  function extractPivotsFromComputedSteps(steps, polyline) {
    if (!steps || steps.length < 2)
      return [];
    const initial = steps.map((s, i) => ({
      stepIdx: i,
      name: s.road ?? roadNameFromInstruction(s.instruction)
    }));
    let annotated = initial;
    for (let pass = 0;pass < 4; pass++) {
      const collapsed = [];
      for (let i = 0;i < annotated.length; i++) {
        const prev = collapsed[collapsed.length - 1];
        const here = annotated[i];
        const next = annotated[i + 1];
        if (prev?.name && next?.name && here.name && !sameRoad(prev.name, here.name) && sameRoad(prev.name, next.name)) {
          continue;
        }
        collapsed.push(here);
      }
      if (collapsed.length === annotated.length)
        break;
      annotated = collapsed;
    }
    const out = [];
    for (let i = 0;i < annotated.length - 1; i++) {
      const here = annotated[i];
      const nextAnn = annotated[i + 1];
      const s = steps[here.stepIdx];
      const next = steps[nextAnn.stepIdx];
      const fromRoad = here.name;
      const toRoad = nextAnn.name;
      if (!fromRoad)
        continue;
      if (toRoad && sameRoad(fromRoad, toRoad))
        continue;
      if (!Number.isFinite(s.endLat) || !Number.isFinite(s.endLng))
        continue;
      const junction = { lat: s.endLat, lng: s.endLng };
      const signedBend = signedBendAt(polyline, junction);
      if (signedBend != null && Math.abs(signedBend) < MIN_TURN_ANGLE_DEG)
        continue;
      const geomDir = signedBend == null ? null : signedBend > 0 ? "right" : "left";
      const direction = geomDir ?? turnDirection(next.maneuver);
      out.push({
        lat: s.endLat,
        lng: s.endLng,
        fromRoad,
        toRoad,
        direction,
        maneuver: next.maneuver ?? (direction === "left" ? "TURN_LEFT" : "TURN_RIGHT")
      });
    }
    return out;
  }

  // ../../mobile/modules/miniapp/dist/modules/pivots/engine.js
  var RADIUS_DEFAULTS_M = {
    walking: 7,
    cycling: 15,
    driving: 40,
    two_wheeler: 25
  };
  var APPROACH_DEFAULTS_M = {
    walking: 100,
    cycling: 300,
    driving: 800,
    two_wheeler: 500
  };
  var NON_TURN_MANEUVERS = new Set(["STRAIGHT", "NAME_CHANGE", "DEPART", "ARRIVE"]);
  var STEP_MATCH_MAX_INDEX_DELTA = 8;
  var ON_ROUTE_PERP_TOLERANCE_M = 50;

  class PivotEngine {
    constructor(mode, opts) {
      this.pivots = [];
      this.states = [];
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = [];
      this.cumulative = [];
      this.roadNameResolver = null;
      this.routeGeneration = 0;
      this.subscribers = new Set;
      this.opts = resolveOptions(mode, opts);
    }
    updateOptions(mode, opts) {
      this.opts = resolveOptions(mode, opts);
      for (const p of this.pivots) {
        p.radiusMeters = this.opts.radiusMeters;
      }
    }
    setRoadNameResolver(resolver) {
      this.roadNameResolver = resolver;
    }
    reset() {
      if (this.activePivotIndex !== null) {
        const active = this.pivots[this.activePivotIndex];
        if (active)
          this.emit({ kind: "exited", pivot: active });
      }
      this.pivots = [];
      this.states = [];
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = [];
      this.cumulative = [];
    }
    setRouteFromComputedSteps(route, computedSteps) {
      const points = route.points ?? [];
      if (this.activePivotIndex !== null) {
        const active = this.pivots[this.activePivotIndex];
        if (active)
          this.emit({ kind: "exited", pivot: active });
      }
      if (points.length < 3 || !computedSteps || computedSteps.length < 2) {
        this.setRoute(route, null);
        return;
      }
      const cumulative = cumulativeDistances(points);
      const instructionPivots = extractPivotsFromComputedSteps(computedSteps, points);
      console.log(`[PivotEngine] setRouteFromComputedSteps: steps=${computedSteps.length} instructionPivots=${instructionPivots.length}` + (instructionPivots.length > 0 ? `
` + instructionPivots.map((p, i) => `  pivot[${i}] ${p.fromRoad ?? "—"} → ${p.toRoad ?? "—"} dir=${p.direction} @ (${p.lat.toFixed(5)}, ${p.lng.toFixed(5)})`).join(`
`) : ""));
      if (instructionPivots.length === 0) {
        console.log(`[PivotEngine] falling back to setRoute (geometry) — input steps:
` + computedSteps.map((s, i) => `  step[${i}] road=${s.road ?? "—"} maneuver=${s.maneuver ?? "—"} @ (${s.lat.toFixed(5)}, ${s.lng.toFixed(5)}) → (${s.endLat.toFixed(5)}, ${s.endLng.toFixed(5)})`).join(`
`));
        this.setRoute(route, null);
        return;
      }
      const pivots = instructionPivots.map((p, i) => ({
        index: i,
        lat: p.lat,
        lng: p.lng,
        direction: p.direction === "left" ? "left" : "right",
        fromRoad: p.fromRoad,
        toRoad: p.toRoad,
        maneuver: p.maneuver,
        distanceAlongRouteMeters: alongRouteAtCoord(points, cumulative, { lat: p.lat, lng: p.lng }),
        radiusMeters: this.opts.radiusMeters
      }));
      pivots.sort((a, b) => a.distanceAlongRouteMeters - b.distanceAlongRouteMeters);
      for (let i = 0;i < pivots.length; i++)
        pivots[i].index = i;
      this.pivots = pivots;
      this.states = pivots.map(() => ({ approachingFired: false, entered: false, exited: false }));
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = points;
      this.cumulative = cumulative;
      this.routeGeneration++;
      this._resolveMissingRoadNames(this.routeGeneration);
    }
    setRoute(route, _userPosition) {
      const points = route.points ?? [];
      const steps = route.steps ?? [];
      if (this.activePivotIndex !== null) {
        const active = this.pivots[this.activePivotIndex];
        if (active)
          this.emit({ kind: "exited", pivot: active });
      }
      if (points.length < 3) {
        this.pivots = [];
        this.states = [];
        this.cursor = 0;
        this.activePivotIndex = null;
        this.points = [];
        this.cumulative = [];
        return;
      }
      const cumulative = cumulativeDistances(points);
      const raw = extractPivots(points);
      const stepIndex = buildStepIndex(steps);
      const pivots = [];
      for (let i = 0;i < raw.length; i++) {
        const r = raw[i];
        const matched = matchStep(r, stepIndex);
        if (matched && NON_TURN_MANEUVERS.has(matched.maneuver)) {
          continue;
        }
        pivots.push({
          index: pivots.length,
          lat: r.lat,
          lng: r.lng,
          direction: r.direction,
          fromRoad: matched?.fromRoad ?? null,
          toRoad: matched?.toRoad ?? null,
          maneuver: matched?.maneuver ?? (r.direction === "left" ? "TURN_LEFT" : "TURN_RIGHT"),
          distanceAlongRouteMeters: distanceAtIndex(cumulative, r.rawRouteIndex),
          radiusMeters: this.opts.radiusMeters
        });
      }
      pivots.sort((a, b) => a.distanceAlongRouteMeters - b.distanceAlongRouteMeters);
      for (let i = 0;i < pivots.length; i++)
        pivots[i].index = i;
      this.pivots = pivots;
      this.states = pivots.map(() => ({ approachingFired: false, entered: false, exited: false }));
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = points;
      this.cumulative = cumulative;
      this.routeGeneration++;
      this._resolveMissingRoadNames(this.routeGeneration);
    }
    async _resolveMissingRoadNames(generation) {
      const pivots = this.pivots;
      if (pivots.length === 0)
        return;
      for (let i = 0;i < pivots.length - 1; i++) {
        const here = pivots[i];
        const next = pivots[i + 1];
        if (!here.toRoad && next.fromRoad)
          here.toRoad = next.fromRoad;
        if (!next.fromRoad && here.toRoad)
          next.fromRoad = here.toRoad;
      }
      for (let i = pivots.length - 1;i > 0; i--) {
        const here = pivots[i];
        const prev = pivots[i - 1];
        if (!prev.toRoad && here.fromRoad)
          prev.toRoad = here.fromRoad;
        if (!here.fromRoad && prev.toRoad)
          here.fromRoad = prev.toRoad;
      }
      const resolver = this.roadNameResolver;
      if (!resolver)
        return;
      if (this.points.length < 2)
        return;
      const SAMPLE_OFFSETS_M = [18, 30, 50, 80];
      const points = this.points;
      const cumulative = this.cumulative;
      const geocodeWithExpansion = async (pivotAlong, direction) => {
        for (const offset of SAMPLE_OFFSETS_M) {
          const sample = sampleAlongRoute(points, cumulative, pivotAlong + direction * offset);
          if (!sample)
            continue;
          try {
            const road = await resolver(sample);
            if (generation !== this.routeGeneration)
              return null;
            if (road)
              return road;
          } catch {}
        }
        return null;
      };
      const tasks = [];
      for (const pivot of pivots) {
        if (pivot.fromRoad && pivot.toRoad)
          continue;
        const along = pivot.distanceAlongRouteMeters;
        if (!pivot.fromRoad) {
          tasks.push(geocodeWithExpansion(along, -1).then((road) => {
            if (generation !== this.routeGeneration)
              return;
            if (road && !pivot.fromRoad)
              pivot.fromRoad = road;
          }));
        }
        if (!pivot.toRoad) {
          tasks.push(geocodeWithExpansion(along, 1).then((road) => {
            if (generation !== this.routeGeneration)
              return;
            if (road && !pivot.toRoad)
              pivot.toRoad = road;
          }));
        }
      }
      await Promise.all(tasks);
      if (generation !== this.routeGeneration)
        return;
      for (let i = 0;i < pivots.length - 1; i++) {
        const here = pivots[i];
        const next = pivots[i + 1];
        if (!here.toRoad && next.fromRoad)
          here.toRoad = next.fromRoad;
        if (!next.fromRoad && here.toRoad)
          next.fromRoad = here.toRoad;
      }
    }
    onLocationUpdate(coords) {
      if (this.pivots.length === 0)
        return;
      const projection = projectOntoPolyline(this.points, this.cumulative, coords);
      const useAlongPath = projection !== null && projection.perpMeters <= ON_ROUTE_PERP_TOLERANCE_M;
      const userAlong = projection?.alongMeters ?? 0;
      for (let i = this.cursor;i < this.pivots.length; i++) {
        const pivot = this.pivots[i];
        const state = this.states[i];
        if (state.exited)
          continue;
        const aheadDelta = pivot.distanceAlongRouteMeters - userAlong;
        const distanceToPivot = useAlongPath ? Math.abs(aheadDelta) : haversineMeters(coords, { lat: pivot.lat, lng: pivot.lng });
        const approaching = !state.approachingFired && distanceToPivot <= this.opts.approachThresholdMeters && (!useAlongPath || aheadDelta >= -this.opts.radiusMeters);
        if (approaching) {
          state.approachingFired = true;
          this.emit({ kind: "approaching", pivot, distanceMeters: distanceToPivot });
        }
        if (!state.entered && distanceToPivot <= pivot.radiusMeters) {
          state.entered = true;
          this.activePivotIndex = i;
          this.emit({ kind: "entered", pivot });
        }
        const movedPastOnPath = useAlongPath && aheadDelta < -pivot.radiusMeters;
        if ((state.entered && distanceToPivot > pivot.radiusMeters || !state.entered && movedPastOnPath) && !state.exited) {
          if (!state.entered) {
            state.entered = true;
            this.activePivotIndex = i;
            this.emit({ kind: "entered", pivot });
          }
          state.exited = true;
          if (this.activePivotIndex === i)
            this.activePivotIndex = null;
          this.emit({ kind: "exited", pivot });
          if (this.cursor <= i)
            this.cursor = i + 1;
        }
        if (!state.approachingFired && distanceToPivot > this.opts.approachThresholdMeters * 2) {
          break;
        }
      }
    }
    subscribe(fn) {
      this.subscribers.add(fn);
      return () => {
        this.subscribers.delete(fn);
      };
    }
    getPivots() {
      return this.pivots.slice();
    }
    getActivePivot() {
      if (this.activePivotIndex === null)
        return null;
      return this.pivots[this.activePivotIndex] ?? null;
    }
    getUpcomingPivot() {
      for (let i = this.cursor;i < this.pivots.length; i++) {
        if (!this.states[i].exited)
          return this.pivots[i];
      }
      return null;
    }
    emit(event) {
      for (const fn of this.subscribers) {
        try {
          fn(event);
        } catch (err) {
          console.error("[PivotEngine] subscriber threw:", err);
        }
      }
    }
  }
  function resolveOptions(mode, opts) {
    return {
      radiusMeters: opts?.radiusMeters ?? RADIUS_DEFAULTS_M[mode] ?? RADIUS_DEFAULTS_M.walking,
      approachThresholdMeters: opts?.approachThresholdMeters ?? APPROACH_DEFAULTS_M[mode] ?? APPROACH_DEFAULTS_M.walking
    };
  }
  function projectOntoPolyline(points, cumulative, user) {
    if (points.length < 2 || cumulative.length !== points.length)
      return null;
    const mPerDegLat = 111320;
    const mPerDegLng = 111320 * Math.cos(user.lat * Math.PI / 180);
    const ux = user.lng * mPerDegLng;
    const uy = user.lat * mPerDegLat;
    let bestPerp = Number.POSITIVE_INFINITY;
    let bestAlong = 0;
    for (let i = 0;i < points.length - 1; i++) {
      const a = points[i];
      const b = points[i + 1];
      const ax = a.lng * mPerDegLng;
      const ay = a.lat * mPerDegLat;
      const bx = b.lng * mPerDegLng;
      const by = b.lat * mPerDegLat;
      const dx = bx - ax;
      const dy = by - ay;
      const segLen2 = dx * dx + dy * dy;
      const t = segLen2 > 0 ? Math.max(0, Math.min(1, ((ux - ax) * dx + (uy - ay) * dy) / segLen2)) : 0;
      const px = ax + t * dx;
      const py = ay + t * dy;
      const perp = Math.hypot(ux - px, uy - py);
      if (perp < bestPerp) {
        bestPerp = perp;
        const segLen = Math.sqrt(segLen2);
        bestAlong = cumulative[i] + t * segLen;
      }
    }
    if (!Number.isFinite(bestPerp))
      return null;
    return { perpMeters: bestPerp, alongMeters: bestAlong };
  }
  function alongRouteAtCoord(points, cumulative, coord) {
    const projection = projectOntoPolyline(points, cumulative, coord);
    return projection?.alongMeters ?? 0;
  }
  function sampleAlongRoute(points, cumulative, targetMeters) {
    if (points.length < 2 || cumulative.length !== points.length)
      return null;
    const total = cumulative[cumulative.length - 1];
    if (!Number.isFinite(targetMeters))
      return null;
    if (targetMeters <= 0)
      return { lat: points[0].lat, lng: points[0].lng };
    if (targetMeters >= total) {
      const last = points[points.length - 1];
      return { lat: last.lat, lng: last.lng };
    }
    let lo = 0;
    let hi = cumulative.length - 1;
    while (lo + 1 < hi) {
      const mid = lo + hi >>> 1;
      if (cumulative[mid] <= targetMeters)
        lo = mid;
      else
        hi = mid;
    }
    const segStart = cumulative[lo];
    const segEnd = cumulative[hi];
    const segLen = segEnd - segStart;
    const t = segLen > 0 ? (targetMeters - segStart) / segLen : 0;
    const a = points[lo];
    const b = points[hi];
    return { lat: a.lat + (b.lat - a.lat) * t, lng: a.lng + (b.lng - a.lng) * t };
  }
  function distanceAtIndex(cumulative, idx) {
    if (cumulative.length === 0)
      return 0;
    if (idx < 0)
      return 0;
    if (idx >= cumulative.length)
      return cumulative[cumulative.length - 1];
    return cumulative[idx];
  }
  function buildStepIndex(steps) {
    if (!steps.length)
      return [];
    return steps.slice().sort((a, b) => a.routeIndex - b.routeIndex);
  }
  function matchStep(raw, stepIndex) {
    if (stepIndex.length < 2)
      return null;
    let bestJ = -1;
    let bestDelta = Number.POSITIVE_INFINITY;
    for (let i = 1;i < stepIndex.length; i++) {
      const delta = Math.abs(stepIndex[i].routeIndex - raw.rawRouteIndex);
      if (delta <= bestDelta) {
        bestDelta = delta;
        bestJ = i;
      }
    }
    if (bestJ < 1)
      return null;
    if (bestDelta > STEP_MATCH_MAX_INDEX_DELTA)
      return null;
    const SHORT_TRANSIT_METERS = 25;
    const finalIndex = stepIndex.length - 1;
    let j = bestJ;
    while (j < finalIndex - 1 && stepIndex[j].distanceMeters > 0 && stepIndex[j].distanceMeters < SHORT_TRANSIT_METERS) {
      j++;
    }
    if (j >= finalIndex)
      j = finalIndex - 1;
    const fromStep = stepIndex[bestJ - 1];
    const toStep = stepIndex[j];
    return {
      fromRoad: fromStep.road ?? null,
      toRoad: toStep.road ?? null,
      maneuver: fromStep.maneuver
    };
  }

  // ../../mobile/modules/miniapp/dist/modules/navigation.js
  class NavigationModule {
    constructor(session) {
      this.session = session;
      this._pivots = new PivotEngine("walking", undefined);
      this._tripUnsubs = [];
      this._tripStops = null;
      this._tripMode = "walking";
      this._tripAvoid = undefined;
      this._computeRouteSeq = 0;
      this._lastUserPosition = null;
      this._pivots.setRoadNameResolver(async (coord) => {
        try {
          const result = await this.reverseGeocodeRoad(coord);
          if (!result.ok)
            return null;
          return result.road ?? null;
        } catch {
          return null;
        }
      });
    }
    get hasPermission() {
      return this.session._hasManifestPermission("LOCATION");
    }
    requestPermission() {
      if (!this.hasPermission) {
        return Promise.resolve({
          ok: false,
          accepted: false,
          error: "LOCATION permission not declared in miniapp.json (required for navigation.requestPermission)."
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_REQUEST_PERMISSION
      });
    }
    async start(opts) {
      if (!this.hasPermission) {
        return {
          ok: false,
          error: "LOCATION permission not declared in miniapp.json (required for navigation.start)."
        };
      }
      const stops = normalizeStops(opts);
      const mode = opts.mode ?? "driving";
      this._tripStops = stops.length > 0 ? stops : null;
      this._tripMode = mode;
      this._tripAvoid = opts.avoid;
      this._attachPivotTrackingForTrip(mode, opts.pivots);
      const failStart = (error) => {
        this._detachPivotTracking();
        return { ok: false, error };
      };
      if (stops.length === 0) {
        return failStart("navigation.start: no stops");
      }
      let origin = this._lastUserPosition;
      if (!origin) {
        try {
          const fix = await this.session.location.getOnce();
          origin = { lat: fix.lat, lng: fix.lng };
          this._lastUserPosition = origin;
        } catch (err) {
          return failStart(`navigation.start: no GPS fix (${err instanceof Error ? err.message : String(err)})`);
        }
      }
      const restResult = await this.computeRoute({ origin, stops, mode, avoid: opts.avoid });
      if (!restResult.ok || !restResult.routes || restResult.routes.length === 0) {
        return failStart(restResult.error ?? "computeRoute failed");
      }
      const restRoute = restResult.routes[0];
      const nativeResult = await this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_START,
        lat: stops[0]?.lat,
        lng: stops[0]?.lng,
        stops,
        mode,
        avoid: opts.avoid,
        simulate: opts.simulate ?? false,
        speedMultiplier: opts.speedMultiplier ?? 1,
        missedTurnRerouteMeters: opts.missedTurnRerouteMeters
      });
      if (!nativeResult.ok) {
        this._detachPivotTracking();
        return nativeResult;
      }
      const syntheticRoute = buildNavRouteFromComputed(restRoute);
      this.session.events._forwardEvent(MiniappStreamType.NAVIGATION_ROUTE, syntheticRoute);
      return nativeResult;
    }
    stop() {
      this._detachPivotTracking();
      this.session.sendOneShot({ type: MiniappRequestType.NAVIGATION_STOP });
    }
    get dev() {
      return {
        deviate: (offsetMeters = 20) => {
          this.session.sendOneShot({ type: MiniappRequestType.NAVIGATION_DEVIATE, offsetMeters });
        },
        setWrongSidewalkOffset: (enabled) => {
          this.session.sendOneShot({ type: MiniappRequestType.NAVIGATION_SET_WRONG_SIDEWALK, enabled });
        },
        setSkipCrossings: (enabled) => {
          this.session.sendOneShot({ type: MiniappRequestType.NAVIGATION_SET_SKIP_CROSSINGS, enabled });
        }
      };
    }
    onUpdate(handler) {
      return this.session._subscribe(MiniappStreamType.NAVIGATION_UPDATE, handler);
    }
    onRoute(handler) {
      return this.session._subscribe(MiniappStreamType.NAVIGATION_ROUTE, handler);
    }
    async getState() {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_GET_STATE
      });
      return result.ok ? result.state ?? null : null;
    }
    computeRoute(opts) {
      if (!this.hasPermission) {
        return Promise.resolve({
          ok: false,
          error: "LOCATION permission not declared in miniapp.json (required for navigation.computeRoute)."
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_COMPUTE_ROUTE,
        origin: opts.origin,
        stops: opts.stops,
        mode: opts.mode ?? "driving",
        avoid: opts.avoid,
        alternatives: opts.alternatives ?? 1
      });
    }
    reverseGeocodeRoad(coord) {
      if (!this.hasPermission) {
        return Promise.resolve({
          ok: false,
          error: "LOCATION permission not declared in miniapp.json (required for reverseGeocodeRoad)."
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_REVERSE_GEOCODE,
        lat: coord.lat,
        lng: coord.lng
      });
    }
    placeAutocomplete(opts) {
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_PLACE_AUTOCOMPLETE,
        query: opts.query,
        near: opts.near ?? null,
        sessionToken: opts.sessionToken
      });
    }
    placeDetails(opts) {
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_PLACE_DETAILS,
        placeId: opts.placeId,
        sessionToken: opts.sessionToken
      });
    }
    onPivot(handler) {
      return this._pivots.subscribe(handler);
    }
    getPivots() {
      return this._pivots.getPivots();
    }
    getActivePivot() {
      return this._pivots.getActivePivot();
    }
    getUpcomingPivot() {
      return this._pivots.getUpcomingPivot();
    }
    _attachPivotTrackingForTrip(mode, opts) {
      this._detachPivotTracking();
      this._pivots.reset();
      this._pivots.updateOptions(mode, opts);
      this._tripUnsubs.push(this.onRoute((route) => {
        if (route.steps && route.steps.length > 0) {
          const tail = route.points[route.points.length - 1];
          const computedSteps = route.steps.map((s, i) => {
            const next = route.steps?.[i + 1];
            const endLat = next ? next.lat : tail?.lat ?? s.lat;
            const endLng = next ? next.lng : tail?.lng ?? s.lng;
            return {
              lat: s.lat,
              lng: s.lng,
              endLat,
              endLng,
              distanceMeters: s.distanceMeters,
              maneuver: s.maneuver,
              road: s.road ?? undefined
            };
          });
          this._pivots.setRouteFromComputedSteps(route, computedSteps);
          return;
        }
        this._pivots.setRoute(route, null);
        const seq = ++this._computeRouteSeq;
        this._issueComputeRouteForTrip(route).then((result) => {
          if (seq !== this._computeRouteSeq)
            return;
          const computedSteps = result?.routes?.[0]?.steps;
          if (computedSteps && computedSteps.length > 0) {
            this._pivots.setRouteFromComputedSteps(route, computedSteps);
          }
        }).catch((err) => {
          console.warn("[NavigationModule] computeRoute for pivots failed:", err);
        });
      }));
      this._tripUnsubs.push(this.onUpdate((update) => {
        if (update.kind === "arrived") {
          this._pivots.reset();
          return;
        }
      }));
      this._tripUnsubs.push(this.session.location.onUpdate((loc) => {
        this._lastUserPosition = { lat: loc.lat, lng: loc.lng };
        this._pivots.onLocationUpdate({ lat: loc.lat, lng: loc.lng });
      }));
    }
    async _issueComputeRouteForTrip(route) {
      if (!this._tripStops || this._tripStops.length === 0)
        return null;
      const origin = this._lastUserPosition ?? (route?.points && route.points[0] ? { lat: route.points[0].lat, lng: route.points[0].lng } : null);
      if (!origin)
        return null;
      return this.computeRoute({
        origin,
        stops: this._tripStops,
        mode: this._tripMode,
        avoid: this._tripAvoid
      });
    }
    _detachPivotTracking() {
      for (const unsub of this._tripUnsubs) {
        try {
          unsub();
        } catch (err) {
          console.warn("[NavigationModule] pivot-tracking unsubscribe threw:", err);
        }
      }
      this._tripUnsubs = [];
      this._pivots.reset();
      this._tripStops = null;
      this._tripAvoid = undefined;
      this._computeRouteSeq++;
      this._lastUserPosition = null;
    }
  }
  function normalizeStops(opts) {
    if (opts.stops && opts.stops.length > 0) {
      return opts.stops;
    }
    if (typeof opts.lat === "number" && typeof opts.lng === "number") {
      return [{ lat: opts.lat, lng: opts.lng }];
    }
    return [];
  }
  function buildNavRouteFromComputed(computed) {
    const points = computed.points ?? [];
    const steps = (computed.steps ?? []).map((s) => {
      let routeIndex = 0;
      let best = Infinity;
      for (let i = 0;i < points.length; i++) {
        const dLat = points[i].lat - s.lat;
        const dLng = points[i].lng - s.lng;
        const d = dLat * dLat + dLng * dLng;
        if (d < best) {
          best = d;
          routeIndex = i;
        }
      }
      return {
        lat: s.lat,
        lng: s.lng,
        routeIndex,
        road: s.road ?? null,
        maneuver: s.maneuver ?? "STRAIGHT",
        distanceMeters: s.distanceMeters
      };
    });
    return {
      points,
      totalDistanceMeters: computed.totalDistanceMeters,
      totalDurationSeconds: computed.totalDurationSeconds,
      steps: steps.length > 0 ? steps : undefined
    };
  }

  // ../../mobile/modules/miniapp/dist/modules/permissions.js
  class PermissionsModule {
    constructor(session) {
      this.session = session;
    }
    has(type) {
      return this.session._getPermissions()[type] === true;
    }
    getAll() {
      return this.session._getPermissions();
    }
    onUpdate(handler) {
      return this.session.on("permissions", handler);
    }
    onPermissionError(handler) {
      return this.session.on("error", (e) => {
        const maybe = e;
        if (maybe?.code === MiniappErrorCode.PERMISSION_NOT_DECLARED) {
          handler({
            code: String(maybe.code),
            message: String(maybe.message ?? ""),
            permission: maybe.permission,
            subscription: maybe.subscription,
            operation: maybe.operation
          });
        }
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/phone.js
  class TrackedSubs {
    constructor() {
      this.unsubs = new Set;
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
  }

  class PhoneNotificationsModule extends TrackedSubs {
    constructor(session) {
      super();
      this.session = session;
    }
    on(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.PHONE_NOTIFICATION, handler));
    }
    onDismissed(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.PHONE_NOTIFICATION_DISMISSED, handler));
    }
    get hasPermission() {
      return this.session._hasManifestPermission("READ_NOTIFICATIONS");
    }
  }

  class PhoneCalendarModule {
    constructor(session) {
      this.session = session;
    }
    listEvents(options) {
      const startsAt = normalizeCalendarDate(options?.startsAt, "startsAt");
      const endsAt = normalizeCalendarDate(options?.endsAt, "endsAt");
      return this.session.sendRequest({
        type: MiniappRequestType.CALENDAR_LIST_EVENTS,
        startsAt,
        endsAt,
        ...options.limit === undefined ? {} : { limit: options.limit }
      });
    }
    get hasPermission() {
      return this.session._hasManifestPermission("CALENDAR");
    }
  }
  function normalizeCalendarDate(value, field) {
    const date = value instanceof Date ? value : new Date(value ?? "");
    if (Number.isNaN(date.getTime()))
      throw new TypeError(`${field} must be a valid Date or ISO 8601 string`);
    return date.toISOString();
  }

  class PhoneModule {
    constructor(session) {
      this.session = session;
      this.notifications = new PhoneNotificationsModule(session);
      this.calendar = new PhoneCalendarModule(session);
    }
    onBattery(handler) {
      return this.session._subscribe(MiniappStreamType.PHONE_BATTERY, handler);
    }
  }

  // ../../cloud-v2/packages/protocol/src/languages.ts
  var CANONICAL_TAG_BY_CODE = {
    af: "af-ZA",
    am: "am-ET",
    ar: "ar-AE",
    az: "az-AZ",
    be: "be-BY",
    bg: "bg-BG",
    bn: "bn-IN",
    bs: "bs-BA",
    ca: "ca-ES",
    cs: "cs-CZ",
    cy: "cy-GB",
    da: "da-DK",
    de: "de-DE",
    el: "el-GR",
    en: "en-US",
    es: "es-ES",
    et: "et-EE",
    eu: "eu-ES",
    fa: "fa-IR",
    fi: "fi-FI",
    fr: "fr-FR",
    gl: "gl-ES",
    gu: "gu-IN",
    he: "he-IL",
    hi: "hi-IN",
    hr: "hr-HR",
    hu: "hu-HU",
    hy: "hy-AM",
    id: "id-ID",
    it: "it-IT",
    ja: "ja-JP",
    ka: "ka-GE",
    kk: "kk-KZ",
    kn: "kn-IN",
    ko: "ko-KR",
    lt: "lt-LT",
    lv: "lv-LV",
    mk: "mk-MK",
    ml: "ml-IN",
    mr: "mr-IN",
    ms: "ms-MY",
    nb: "nb-NO",
    ne: "ne-NP",
    nl: "nl-NL",
    no: "nb-NO",
    pa: "pa-IN",
    pl: "pl-PL",
    pt: "pt-BR",
    ro: "ro-RO",
    ru: "ru-RU",
    sk: "sk-SK",
    sl: "sl-SI",
    sq: "sq-AL",
    sr: "sr-RS",
    sv: "sv-SE",
    sw: "sw-KE",
    ta: "ta-IN",
    te: "te-IN",
    th: "th-TH",
    tl: "fil-PH",
    tr: "tr-TR",
    uk: "uk-UA",
    ur: "ur-IN",
    vi: "vi-VN",
    zh: "zh-CN"
  };
  var EXTRA_REGIONAL_TAGS = [
    "ar-EG",
    "ar-SA",
    "de-AT",
    "de-CH",
    "en-AU",
    "en-CA",
    "en-GB",
    "en-IN",
    "es-419",
    "es-MX",
    "es-US",
    "fr-CA",
    "nl-BE",
    "pt-PT",
    "zh-HK",
    "zh-TW"
  ];
  var SUPPORTED_LANGUAGE_HINTS = Object.freeze([...new Set(Object.keys(CANONICAL_TAG_BY_CODE))].sort());
  var SUPPORTED_TRANSCRIPTION_LANGUAGES = Object.freeze([
    ...new Set([
      ...Object.values(CANONICAL_TAG_BY_CODE),
      ...EXTRA_REGIONAL_TAGS
    ])
  ].sort());
  var TAG_SET = new Set(SUPPORTED_TRANSCRIPTION_LANGUAGES);
  var HINT_SET = new Set(SUPPORTED_LANGUAGE_HINTS);
  function toTranscriptionLanguage(value) {
    if (TAG_SET.has(value))
      return value;
    const canonical = CANONICAL_TAG_BY_CODE[value.toLowerCase()];
    return canonical ?? null;
  }
  function toLanguageHint(value) {
    const primary = value.split("-")[0].toLowerCase();
    return HINT_SET.has(primary) ? primary : null;
  }
  function suggestTranscriptionLanguage(value) {
    const normalized = value.replace(/_/g, "-");
    const parts = normalized.split("-");
    const recased = parts.length >= 2 ? `${parts[0].toLowerCase()}-${parts[1].toUpperCase()}` : normalized.toLowerCase();
    return toTranscriptionLanguage(recased);
  }

  // ../../mobile/modules/miniapp/dist/modules/languages.js
  class MiniappValidationError extends Error {
    constructor(message) {
      super(message);
      this.name = "MiniappValidationError";
    }
  }
  function requireTranscriptionLanguage(value, param) {
    const canonical = toTranscriptionLanguage(value);
    if (canonical)
      return canonical;
    const suggestion = suggestTranscriptionLanguage(value);
    throw new MiniappValidationError(`${param}: unknown language ${JSON.stringify(value)}` + (suggestion ? ` — did you mean ${JSON.stringify(suggestion)}?` : "") + ` Supported values are BCP-47 tags from SUPPORTED_TRANSCRIPTION_LANGUAGES (e.g. "en-US", "fr-FR").`);
  }
  function requireLanguageHint(value, param) {
    const hint = toLanguageHint(value);
    if (hint)
      return hint;
    throw new MiniappValidationError(`${param}: unknown language hint ${JSON.stringify(value)}. ` + `Hints are bare ISO 639-1 codes from SUPPORTED_LANGUAGE_HINTS (e.g. "en", "fr").`);
  }

  // ../../mobile/modules/miniapp/dist/modules/transcription.js
  class TranscriptionModule {
    constructor(session) {
      this.session = session;
      this.unsubs = new Set;
      this.currentConfig = null;
    }
    on(handler, options = {}) {
      return this.track(this.session._subscribe(`${MiniappStreamType.TRANSCRIPTION}:auto`, handler, options));
    }
    forLanguage(language, handler, options = {}) {
      const langs = (Array.isArray(language) ? language : [language]).map((lang) => requireTranscriptionLanguage(lang, "transcription.forLanguage(language)"));
      if (langs.length === 0)
        return () => {};
      const unsubs = [];
      for (const lang of langs) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TRANSCRIPTION}:${lang}`, handler, options));
      }
      const combined = () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
      return this.track(combined);
    }
    configure(config) {
      const normalized = {
        ...config,
        languageHints: config.languageHints?.map((hint) => requireLanguageHint(hint, "transcription.configure(languageHints)"))
      };
      this.currentConfig = { ...normalized };
      return this.session.sendRequest({
        type: MiniappRequestType.TRANSCRIPTION_CONFIG,
        config: { ...normalized }
      }).then(() => {
        return;
      });
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
    get hasPermission() {
      return this.session._hasManifestPermission("MICROPHONE");
    }
    _getConfig() {
      return this.currentConfig ? { ...this.currentConfig } : null;
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/translation.js
  class TranslationModule {
    constructor(session) {
      this.session = session;
      this.unsubs = new Set;
    }
    on(handler) {
      return this.track(this.session._subscribe(`${MiniappStreamType.TRANSLATION}:*:*`, handler));
    }
    to(target, handler) {
      const targets = (Array.isArray(target) ? target : [target]).map((t) => requireTranscriptionLanguage(t, "translation.to(target)"));
      if (targets.length === 0)
        return () => {};
      const unsubs = [];
      for (const t of targets) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TRANSLATION}:*:${t}`, handler));
      }
      const composite = () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
      return this.track(composite);
    }
    fromTo(source, target, handler) {
      const validSource = source === "auto" ? "auto" : requireTranscriptionLanguage(source, "translation.fromTo(source)");
      const targets = (Array.isArray(target) ? target : [target]).map((t) => requireTranscriptionLanguage(t, "translation.fromTo(target)"));
      if (targets.length === 0)
        return () => {};
      const unsubs = [];
      for (const t of targets) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TRANSLATION}:${validSource}:${t}`, handler));
      }
      const composite = () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
      return this.track(composite);
    }
    forLanguagePair(fromLang, toLang, handler) {
      return this.fromTo(fromLang, toLang, handler);
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
    get hasPermission() {
      return this.session._hasManifestPermission("MICROPHONE");
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/ui.js
  function rpcErrorFromUnknown(e) {
    if (e instanceof Error) {
      const own = e;
      const cause = own.cause;
      return compactEnvelope({
        message: e.message,
        code: own.code ?? cause?.code,
        stage: own.stage,
        transport: own.transport
      });
    }
    if (e && typeof e === "object") {
      const o = e;
      return compactEnvelope({
        message: typeof o.message === "string" ? o.message : JSON.stringify(e),
        code: typeof o.code === "string" ? o.code : undefined,
        stage: typeof o.stage === "string" ? o.stage : undefined,
        transport: typeof o.transport === "string" ? o.transport : undefined
      });
    }
    return { message: String(e) };
  }
  function compactEnvelope(env) {
    const out = { message: env.message };
    if (env.code)
      out.code = env.code;
    if (env.stage)
      out.stage = env.stage;
    if (env.transport)
      out.transport = env.transport;
    return out;
  }

  class UIModuleImpl {
    constructor(session) {
      this.session = session;
      this.bound = false;
      this.nextSeq = 1;
      this.openHandlers = new Set;
      this.closeHandlers = new Set;
      this.channelHandlers = new Map;
      this.rpcHandlers = new Map;
      this.inflightRpc = new Map;
      this.isOpen = () => {
        return this.bound;
      };
      this.onOpen = (cb) => {
        this.openHandlers.add(cb);
        if (this.bound) {
          if (this.session.ready) {
            try {
              cb();
            } catch (e) {
              console.warn("session.ui.onOpen late-fire threw:", e);
            }
          }
        }
        return () => {
          this.openHandlers.delete(cb);
        };
      };
      this.onClose = (cb) => {
        this.closeHandlers.add(cb);
        return () => {
          this.closeHandlers.delete(cb);
        };
      };
      this.send = (channel, payload) => {
        if (!this.bound) {
          return;
        }
        const seq = this.nextSeq++;
        const envelope = { type: "UI_SEND", channel, payload, seq };
        this.session.sendOneShot(envelope);
      };
      this.on = (channel, cb) => {
        let set = this.channelHandlers.get(channel);
        if (!set) {
          set = new Set;
          this.channelHandlers.set(channel, set);
        }
        set.add(cb);
        return () => {
          set.delete(cb);
        };
      };
      this.handle = (channel, handler) => {
        const key = channel;
        if (this.rpcHandlers.has(key)) {
          throw new Error(`session.ui.handle: a handler is already registered for "${key}"`);
        }
        this.rpcHandlers.set(key, handler);
        return () => {
          this.rpcHandlers.delete(key);
        };
      };
      this.session._subscribe("_ui", (env) => this.handleInbound(env));
    }
    fireOpenHandlers() {
      for (const h of this.openHandlers) {
        try {
          h();
        } catch (e) {
          console.warn("session.ui.onOpen handler threw", e);
        }
      }
    }
    handleInbound(env) {
      if (env.type === "UI_OPEN") {
        this.bound = true;
        this.nextSeq = 1;
        if (this.session.ready) {
          this.fireOpenHandlers();
        } else {
          const off = this.session.on("ready", () => {
            off();
            if (this.bound)
              this.fireOpenHandlers();
          });
        }
        return;
      }
      if (env.type === "UI_CLOSE") {
        this.bound = false;
        for (const h of this.closeHandlers) {
          try {
            h();
          } catch (e) {
            console.warn("session.ui.onClose handler threw", e);
          }
        }
        return;
      }
      if (env.type === "UI_MESSAGE") {
        if (typeof env.requestId === "string") {
          this.dispatchRpcCall(env.channel, env.payload, env.requestId);
          return;
        }
        const set = this.channelHandlers.get(env.channel);
        if (!set || set.size === 0)
          return;
        for (const h of set) {
          try {
            h(env.payload);
          } catch (e) {
            console.warn(`session.ui.on(${env.channel}) threw`, e);
          }
        }
        return;
      }
      if (env.type === "UI_CANCEL") {
        const ctrl = this.inflightRpc.get(env.requestId);
        if (ctrl) {
          try {
            ctrl.abort();
          } catch {}
        }
        return;
      }
    }
    dispatchRpcCall(channel, payload, requestId) {
      const handler = this.rpcHandlers.get(channel);
      if (!handler) {
        this.sendRpcReply(channel, requestId, {
          ok: false,
          error: { message: `no handler registered for "${channel}"` }
        });
        return;
      }
      const ctrl = new AbortController;
      this.inflightRpc.set(requestId, ctrl);
      const ctx = { signal: ctrl.signal };
      const finish = (envelope) => {
        this.inflightRpc.delete(requestId);
        if (ctrl.signal.aborted)
          return;
        this.sendRpcReply(channel, requestId, envelope);
      };
      let result;
      try {
        result = handler(payload, ctx);
      } catch (e) {
        finish({ ok: false, error: rpcErrorFromUnknown(e) });
        return;
      }
      if (result && typeof result.then === "function") {
        result.then((v) => finish({ ok: true, result: v }), (e) => finish({ ok: false, error: rpcErrorFromUnknown(e) }));
      } else {
        finish({ ok: true, result });
      }
    }
    sendRpcReply(channel, requestId, payload) {
      if (!this.bound)
        return;
      const seq = this.nextSeq++;
      const envelope = { type: "UI_SEND", channel, payload, seq, requestId };
      this.session.sendOneShot(envelope);
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/storage.js
  class SimpleStorage {
    constructor(session) {
      this.session = session;
    }
    async get(key) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_GET,
        key
      });
      return result?.value ?? null;
    }
    async set(key, value) {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_SET,
        key,
        value
      });
    }
    async delete(key) {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_DELETE,
        key
      });
    }
    async keys() {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_LIST
      });
      return result?.keys ?? [];
    }
    async list() {
      return this.keys();
    }
    async clear() {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_CLEAR
      });
    }
    async has(key) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_HAS,
        key
      });
      return !!result?.has;
    }
    async getAll() {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_GET_ALL
      });
      return result?.values ?? {};
    }
    async setMultiple(values) {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_SET_MULTIPLE,
        values
      });
    }
    async flush() {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_FLUSH
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/base64.js
  var ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  var LOOKUP = (() => {
    const t = new Int16Array(256).fill(-1);
    for (let i = 0;i < ALPHABET.length; i++)
      t[ALPHABET.charCodeAt(i)] = i;
    t[61] = 0;
    return t;
  })();
  function toUint8Array(input) {
    if (input instanceof Uint8Array)
      return input;
    if (input instanceof ArrayBuffer)
      return new Uint8Array(input);
    return new Uint8Array(input.buffer, input.byteOffset, input.byteLength);
  }
  function bytesToBase64(input) {
    const bytes = input instanceof Uint8Array ? input : new Uint8Array(input);
    const len = bytes.length;
    let out = "";
    let i = 0;
    for (;i + 2 < len; i += 3) {
      const n = bytes[i] << 16 | bytes[i + 1] << 8 | bytes[i + 2];
      out += ALPHABET[n >> 18 & 63] + ALPHABET[n >> 12 & 63] + ALPHABET[n >> 6 & 63] + ALPHABET[n & 63];
    }
    const rem = len - i;
    if (rem === 1) {
      const n = bytes[i] << 16;
      out += ALPHABET[n >> 18 & 63] + ALPHABET[n >> 12 & 63] + "==";
    } else if (rem === 2) {
      const n = bytes[i] << 16 | bytes[i + 1] << 8;
      out += ALPHABET[n >> 18 & 63] + ALPHABET[n >> 12 & 63] + ALPHABET[n >> 6 & 63] + "=";
    }
    return out;
  }
  function base64ToBytes(b64) {
    let validChars = 0;
    let pad = 0;
    for (let i = 0;i < b64.length; i++) {
      const c = b64.charCodeAt(i);
      if (c === 61) {
        pad++;
        validChars++;
      } else if (LOOKUP[c] !== -1) {
        validChars++;
      }
    }
    const fullGroups = Math.floor(validChars / 4);
    const remChars = validChars - fullGroups * 4;
    let outLen = fullGroups * 3 - (pad > 0 && remChars === 0 ? pad : 0);
    if (remChars === 2)
      outLen += 1;
    else if (remChars === 3)
      outLen += 2;
    if (outLen < 0)
      outLen = 0;
    const out = new Uint8Array(outLen);
    let acc = 0;
    let bits = 0;
    let o = 0;
    for (let i = 0;i < b64.length && o < outLen; i++) {
      const c = b64.charCodeAt(i);
      if (c === 61)
        break;
      const v = LOOKUP[c];
      if (v === -1)
        continue;
      acc = acc << 6 | v;
      bits += 6;
      if (bits >= 8) {
        bits -= 8;
        out[o++] = acc >> bits & 255;
      }
    }
    return out;
  }

  // ../../mobile/modules/miniapp/dist/modules/speaker.js
  var SPEAKER_WRITE_CHUNK_BYTES = 256 * 1024;
  var SPEAKER_WRITE_CHUNK_B64 = Math.floor(SPEAKER_WRITE_CHUNK_BYTES / 6) * 8;
  class SpeakerStreamWriter {
    constructor(session, streamId) {
      this.session = session;
      this.streamId = streamId;
      this.settled = false;
      this.writeChain = Promise.resolve();
    }
    async write(chunk) {
      this.assertOpen();
      const bytes = toUint8Array(chunk);
      if (bytes.byteLength === 0)
        throw new Error("PCM chunk cannot be empty");
      if (bytes.byteLength % 2 !== 0)
        throw new Error("PCM chunk must contain complete 16-bit samples");
      return this.enqueueWrite(async () => {
        let last = { bufferedMs: 0 };
        for (let off = 0;off < bytes.length; off += SPEAKER_WRITE_CHUNK_BYTES) {
          last = await this.send(bytesToBase64(bytes.subarray(off, off + SPEAKER_WRITE_CHUNK_BYTES)));
        }
        return last;
      });
    }
    async writeBase64(b64) {
      this.assertOpen();
      if (b64.length === 0 || b64.length % 4 !== 0)
        throw new Error("PCM base64 must be non-empty and padded");
      const padding = b64.endsWith("==") ? 2 : b64.endsWith("=") ? 1 : 0;
      const decodedBytes = b64.length / 4 * 3 - padding;
      if (decodedBytes % 2 !== 0)
        throw new Error("PCM base64 must contain complete 16-bit samples");
      return this.enqueueWrite(async () => {
        let last = { bufferedMs: 0 };
        for (let off = 0;off < b64.length; off += SPEAKER_WRITE_CHUNK_B64) {
          last = await this.send(b64.slice(off, off + SPEAKER_WRITE_CHUNK_B64));
        }
        return last;
      });
    }
    async close() {
      this.assertOpen();
      this.settled = true;
      await this.writeChain;
      const res = await this.session.sendRequest({ type: MiniappRequestType.SPEAKER_STREAM_CLOSE, streamId: this.streamId }, { timeoutMs: 0 });
      return res ?? {};
    }
    async abort() {
      if (this.settled)
        return;
      this.settled = true;
      await this.session.sendRequest({
        type: MiniappRequestType.SPEAKER_STREAM_ABORT,
        streamId: this.streamId
      });
    }
    assertOpen() {
      if (this.settled)
        throw new Error("SpeakerStreamWriter is already closed/aborted");
    }
    async send(base64) {
      const res = await this.session.sendRequest({
        type: MiniappRequestType.SPEAKER_STREAM_WRITE,
        streamId: this.streamId,
        base64
      });
      return res ?? { bufferedMs: 0 };
    }
    enqueueWrite(operation) {
      const result = this.writeChain.then(operation);
      this.writeChain = result.then(() => {
        return;
      }, () => {
        return;
      });
      return result;
    }
  }

  class SpeakerModule {
    constructor(session) {
      this.session = session;
      this._state = "idle";
      this._lastEvent = { state: "idle" };
    }
    get state() {
      return this._state;
    }
    get isPlaying() {
      return this._state === "playing";
    }
    async play(options) {
      await this.session.sendRequest({
        type: MiniappRequestType.PLAY_AUDIO,
        audioUrl: options.audioUrl,
        volume: options.volume,
        stopOtherAudio: options.stopOtherAudio ?? false
      }, { timeoutMs: 0 });
    }
    async speak(text, options = {}) {
      const normalized = Array.isArray(text) ? text.map((sentence) => sentence.trim()).filter(Boolean) : text.trim();
      if (Array.isArray(normalized) && normalized.length === 0 || normalized === "") {
        throw { code: MiniappErrorCode.INTERNAL, message: "speak requires at least one non-empty sentence" };
      }
      try {
        const result = await this.session.sendRequest({
          type: MiniappRequestType.SPEAK,
          text: normalized,
          voice_id: options.voice_id,
          voice_settings: options.voice_settings,
          volume: options.volume,
          stopOtherAudio: options.stopOtherAudio ?? false,
          enableSanitization: options.enableSanitization ?? true,
          forceLocal: options.forceLocal ?? false
        }, { timeoutMs: 0 });
        return result ?? { completed: true };
      } catch (err) {
        if (err && typeof err === "object" && "code" in err) {
          throw err;
        }
        throw { code: MiniappErrorCode.INTERNAL, message: String(err) };
      }
    }
    async createStream(options = {}) {
      if (options.volume !== undefined && (!Number.isFinite(options.volume) || options.volume < 0 || options.volume > 1)) {
        throw new RangeError("speaker stream volume must be between 0 and 1");
      }
      const res = await this.session.sendRequest({
        type: MiniappRequestType.SPEAKER_STREAM_OPEN,
        sampleRate: options.sampleRate ?? 16000,
        channels: options.channels ?? 1,
        volume: options.volume,
        stopOtherAudio: options.stopOtherAudio ?? true
      });
      return new SpeakerStreamWriter(this.session, res.streamId);
    }
    stop() {
      this.session.sendOneShot({ type: MiniappRequestType.STOP_AUDIO });
    }
    onStateChange(handler) {
      return this.session.on("speakerState", handler);
    }
    _applyState(event) {
      if (event.state === this._state && event.state !== "error")
        return;
      this._state = event.state;
      this._lastEvent = event;
    }
    _getLastEvent() {
      return { ...this._lastEvent };
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/stream.js
  class StreamModule {
    constructor(session) {
      this.session = session;
    }
    async startStream(options = {}) {
      if (options.direct !== undefined) {
        return this.session.sendRequest({
          type: MiniappRequestType.STREAM_START,
          streamUrl: options.direct,
          video: options.video,
          audio: options.audio,
          sound: options.sound ?? true,
          ...options.authToken ? { authToken: options.authToken } : {}
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.MANAGED_STREAM_START,
        restreamDestinations: options.destinations,
        video: options.video,
        audio: options.audio,
        sound: options.sound ?? true,
        ingest: options.ingest
      });
    }
    async stop(streamId) {
      await this.session.sendRequest({
        type: MiniappRequestType.STREAM_STOP,
        streamId
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/system.js
  class SystemModule {
    constructor(session) {
      this.session = session;
    }
    async share(options) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.SHARE,
        ...options
      });
      return result ?? { success: false };
    }
    openUrl(url) {
      this.session.sendOneShot({
        type: MiniappRequestType.OPEN_URL,
        url
      });
    }
    async copyToClipboard(text) {
      await this.session.sendRequest({
        type: MiniappRequestType.COPY_CLIPBOARD,
        text
      });
    }
    async download(options) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.DOWNLOAD,
        ...options
      });
      return result ?? { success: false };
    }
    async scanQr(options = {}) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.SCAN_QR,
        ...options
      }, { timeoutMs: 0 });
      return result ?? { cancelled: true };
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/miniapps.js
  class MiniappsModule {
    constructor(session) {
      this.session = session;
    }
    async list(opts) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.MINIAPPS_LIST,
        includeIncompatible: opts?.includeIncompatible ?? false
      });
      return result ?? [];
    }
    async start(packageName) {
      await this.session.sendRequest({
        type: MiniappRequestType.MINIAPPS_START,
        packageName
      });
    }
    async stop(packageName) {
      await this.session.sendRequest({
        type: MiniappRequestType.MINIAPPS_STOP,
        packageName
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/actions.js
  var HANDLER_WAIT_MS = 5000;

  class ActionsModule {
    constructor(session) {
      this.session = session;
      this.handlers = new Map;
      this.buffered = new Map;
    }
    invoke(packageName, actionId, params, opts) {
      return this.session.sendRequest({
        type: MiniappRequestType.ACTION_INVOKE,
        targetPackageName: packageName,
        actionId,
        params: params ?? {},
        ...opts?.timeoutMs != null ? { timeoutMs: opts.timeoutMs } : {}
      });
    }
    handle(actionId, handler) {
      if (this.handlers.has(actionId)) {
        throw new Error(`session.actions.handle: a handler is already registered for "${actionId}"`);
      }
      this.handlers.set(actionId, handler);
      const waiting = this.buffered.get(actionId);
      if (waiting) {
        this.buffered.delete(actionId);
        for (const call of waiting) {
          clearTimeout(call.timer);
          this.dispatch(call.callId, actionId, call.params, call.ctx);
        }
      }
      return () => {
        if (this.handlers.get(actionId) === handler)
          this.handlers.delete(actionId);
      };
    }
    _deliver(callId, actionId, params, ctx) {
      if (this.handlers.has(actionId)) {
        this.dispatch(callId, actionId, params, ctx);
        return;
      }
      const timer = setTimeout(() => {
        const arr2 = this.buffered.get(actionId);
        if (arr2) {
          const idx = arr2.findIndex((c) => c.callId === callId);
          if (idx >= 0)
            arr2.splice(idx, 1);
          if (arr2.length === 0)
            this.buffered.delete(actionId);
        }
        this.sendResult(callId, false, undefined, {
          code: MiniappErrorCode.NO_ACTION_HANDLER,
          message: `No handler registered for action "${actionId}"`
        });
      }, HANDLER_WAIT_MS);
      const arr = this.buffered.get(actionId) ?? [];
      arr.push({ callId, params, ctx, timer });
      this.buffered.set(actionId, arr);
    }
    async dispatch(callId, actionId, params, ctx) {
      const handler = this.handlers.get(actionId);
      if (!handler)
        return;
      try {
        const result = await handler(params, ctx);
        this.sendResult(callId, true, result ?? null);
      } catch (e) {
        this.sendResult(callId, false, undefined, {
          code: MiniappErrorCode.INTERNAL,
          message: e?.message ?? "action handler threw"
        });
      }
    }
    sendResult(callId, ok, result, error) {
      this.session.sendOneShot({
        type: MiniappRequestType.ACTION_RESULT,
        callId,
        ok,
        ...ok ? { result } : { error }
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/blob.js
  var BLOB_WRITE_CHUNK_BYTES = 1024 * 1024;
  var BLOB_WRITE_CHUNK_B64 = Math.floor(BLOB_WRITE_CHUNK_BYTES / 3) * 4;
  var BLOB_READ_ALL_MAX_BYTES = 32 * 1024 * 1024;

  class BlobWriter {
    constructor(session, key) {
      this.session = session;
      this.key = key;
      this.settled = false;
    }
    async write(chunk) {
      this.assertOpen();
      const bytes = toUint8Array(chunk);
      for (let off = 0;off < bytes.length; off += BLOB_WRITE_CHUNK_BYTES) {
        await this.send(bytesToBase64(bytes.subarray(off, off + BLOB_WRITE_CHUNK_BYTES)));
      }
    }
    async writeBase64(b64) {
      this.assertOpen();
      for (let off = 0;off < b64.length; off += BLOB_WRITE_CHUNK_B64) {
        await this.send(b64.slice(off, off + BLOB_WRITE_CHUNK_B64));
      }
    }
    async writeAt(offset, chunk) {
      this.assertOpen();
      await this.session.sendRequest({
        type: MiniappRequestType.BLOB_WRITE,
        key: this.key,
        offset,
        base64: bytesToBase64(toUint8Array(chunk))
      });
    }
    async close(meta) {
      this.assertOpen();
      this.settled = true;
      return this.session.sendRequest({ type: MiniappRequestType.BLOB_COMMIT, key: this.key, meta });
    }
    async abort() {
      if (this.settled)
        return;
      this.settled = true;
      await this.session.sendRequest({ type: MiniappRequestType.BLOB_ABORT, key: this.key });
    }
    assertOpen() {
      if (this.settled)
        throw new Error("BlobWriter is already closed/aborted");
    }
    send(base64) {
      return this.session.sendRequest({
        type: MiniappRequestType.BLOB_WRITE,
        key: this.key,
        base64
      });
    }
  }

  class BlobReader {
    constructor(session, handle, meta) {
      this.session = session;
      this.handle = handle;
      this.meta = meta;
      this.closed = false;
    }
    async read(maxBytes = BLOB_WRITE_CHUNK_BYTES) {
      if (this.closed)
        throw new Error("BlobReader is closed");
      const res = await this.session.sendRequest({
        type: MiniappRequestType.BLOB_READ,
        handle: this.handle,
        maxBytes
      });
      return { bytes: base64ToBytes(res?.base64 ?? ""), done: !!res?.done };
    }
    async close() {
      if (this.closed)
        return;
      this.closed = true;
      await this.session.sendRequest({ type: MiniappRequestType.BLOB_CLOSE_READ, handle: this.handle });
    }
  }

  class BlobModule {
    constructor(session) {
      this.session = session;
    }
    async set(key, data, opts = {}) {
      const writer = await this.createWriteStream(key, opts);
      try {
        if (typeof data === "string")
          await writer.writeBase64(data);
        else
          await writer.write(data);
        return await writer.close();
      } catch (err) {
        await writer.abort().catch(() => {});
        throw err;
      }
    }
    setFromUrl(key, url, opts = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.BLOB_SET_FROM_URL,
        key,
        url,
        mimeType: opts.mimeType,
        name: opts.name,
        headers: opts.headers,
        meta: opts.meta
      });
    }
    importFile(opts = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.BLOB_IMPORT,
        key: opts.key,
        mimeType: opts.mimeType,
        meta: opts.meta
      });
    }
    async createWriteStream(key, opts = {}) {
      const res = await this.session.sendRequest({
        type: MiniappRequestType.BLOB_CREATE,
        key,
        mimeType: opts.mimeType,
        name: opts.name,
        meta: opts.meta
      });
      return new BlobWriter(this.session, res.key);
    }
    get(key) {
      return this.session.sendRequest({ type: MiniappRequestType.BLOB_GET, key });
    }
    stat(key) {
      return this.get(key);
    }
    async has(key) {
      return await this.get(key) !== null;
    }
    async keys() {
      return (await this.list()).map((m) => m.key);
    }
    async list() {
      const res = await this.session.sendRequest({ type: MiniappRequestType.BLOB_LIST });
      return res?.blobs ?? [];
    }
    async createReadStream(key) {
      const res = await this.session.sendRequest({
        type: MiniappRequestType.BLOB_OPEN_READ,
        key
      });
      return new BlobReader(this.session, res.handle, res.meta);
    }
    async bytes(key) {
      let reader;
      try {
        reader = await this.createReadStream(key);
      } catch {
        return null;
      }
      const parts = [];
      let total = 0;
      try {
        for (;; ) {
          const { bytes, done } = await reader.read();
          if (bytes.length) {
            total += bytes.length;
            if (total > BLOB_READ_ALL_MAX_BYTES) {
              throw new Error(`Blob "${key}" exceeds the in-memory read cap — stream it with createReadStream()`);
            }
            parts.push(bytes);
          }
          if (done)
            break;
        }
      } finally {
        await reader.close().catch(() => {});
      }
      const out = new Uint8Array(total);
      let at = 0;
      for (const p of parts) {
        out.set(p, at);
        at += p.length;
      }
      return out;
    }
    usage() {
      return this.session.sendRequest({
        type: MiniappRequestType.BLOB_USAGE
      });
    }
    async delete(key) {
      await this.session.sendRequest({ type: MiniappRequestType.BLOB_DELETE, key });
    }
    async clear() {
      await this.session.sendRequest({ type: MiniappRequestType.BLOB_CLEAR });
    }
    async share(key) {
      const res = await this.session.sendRequest({
        type: MiniappRequestType.BLOB_SHARE,
        key
      });
      return res ?? { success: false };
    }
  }

  // ../../mobile/modules/miniapp/dist/session.js
  var ALL_PERMISSION_TYPES = [
    "location",
    "microphone",
    "camera",
    "notifications",
    "calendar"
  ];

  class NotConnectedError extends Error {
    constructor(message = "MiniappSession is not connected") {
      super(message);
      this.code = MiniappErrorCode.NOT_CONNECTED;
      this.name = "NotConnectedError";
    }
  }
  var DEFAULT_CONNECT_TIMEOUT_MS = 1e4;
  var DEFAULT_REQUEST_TIMEOUT_MS = 60000;

  class MiniappSession {
    constructor(options = {}) {
      this.capabilities = null;
      this.userId = "";
      this.packageName = "";
      this.visibility = "foreground";
      this.colorScheme = "light";
      this.ready = false;
      this.emitter = new import__.default;
      this.authState = null;
      this.authWaiters = new Set;
      this.authRefreshPromise = null;
      this.outboundQueue = [];
      this.pendingRequests = new Map;
      this.connectPromise = null;
      this.disposed = false;
      this._permissions = {
        location: false,
        microphone: false,
        camera: false,
        notifications: false,
        calendar: false
      };
      this.transport = createTransport(options);
      this.connectTimeoutMs = options.connectTimeoutMs ?? DEFAULT_CONNECT_TIMEOUT_MS;
      const injected = getMentraOSGlobals();
      this.packageName = options.packageName ?? injected.packageName ?? "";
      if (injected.colorScheme === "light" || injected.colorScheme === "dark") {
        this.colorScheme = injected.colorScheme;
      }
      this.auth = new AuthModule(this);
      this.events = new EventManager(this);
      this.speaker = new SpeakerModule(this);
      this.camera = new CameraModule(this);
      this.cloud = new CloudModule(this);
      this.dashboard = new DashboardAPI(this);
      this.display = new DisplayManager(this);
      this.glasses = new GlassesModule(this);
      this.heading = new HeadingModule(this);
      this.imu = new ImuModule(this);
      this.input = new InputModule(this);
      this.led = new LedModule(this);
      this.location = new LocationModule(this);
      this.mic = new MicModule(this);
      this.navigation = new NavigationModule(this);
      this.permissions = new PermissionsModule(this);
      this.phone = new PhoneModule(this);
      this.storage = new SimpleStorage(this);
      this.blob = new BlobModule(this);
      this.stream = new StreamModule(this);
      this.system = new SystemModule(this);
      this.transcription = new TranscriptionModule(this);
      this.translation = new TranslationModule(this);
      this.ui = new UIModuleImpl(this);
      this.miniapps = new MiniappsModule(this);
      this.actions = new ActionsModule(this);
    }
    _hasManifestPermission(manifestKey) {
      const canonical = manifestKeyToCanonical(manifestKey);
      if (!canonical)
        return false;
      return this._permissions[canonical] === true;
    }
    _getPermissions() {
      return { ...this._permissions };
    }
    _getAuth() {
      return this.authState ? { ...this.authState } : null;
    }
    _waitForAuth(minTtlMs, timeoutMs = 1e4) {
      const current = this.authState;
      if (current && this.authHasTtl(current, minTtlMs)) {
        return Promise.resolve({ ...current });
      }
      this.requestAuthRefresh(minTtlMs);
      return new Promise((resolve, reject) => {
        const waiter = {
          minTtlMs,
          resolve,
          reject,
          timer: setTimeout(() => {
            this.authWaiters.delete(waiter);
            reject(new NotConnectedError("Miniapp auth token is not available"));
          }, timeoutMs)
        };
        this.authWaiters.add(waiter);
      });
    }
    _subscribe(streamType, handler, options = {}) {
      return this.events.subscribe(streamType, handler, options);
    }
    connect() {
      if (this.disposed) {
        return Promise.reject(new NotConnectedError("MiniappSession was disposed"));
      }
      if (this.connectPromise)
        return this.connectPromise;
      const readyPromise = new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
          const err = new Error("MiniappSession: CONNECT_ACK timeout");
          this.failAllPending({ code: MiniappErrorCode.NOT_CONNECTED, message: err.message });
          this.emitter.emit("error", err);
          reject(err);
        }, this.connectTimeoutMs);
        this.emitter.once("ready", () => {
          clearTimeout(timer);
          resolve();
        });
        this.emitter.once("error", (err) => {
          clearTimeout(timer);
          reject(err);
        });
      });
      this.connectPromise = (async () => {
        this.transport.onMessage((raw) => this.handleIncoming(raw));
        this.transport.onDisconnect((reason) => this.handleTransportDisconnect(reason));
        await this.transport.open();
        const requestId = makeRequestId();
        const connectPayload = {
          type: MiniappRequestType.CONNECT,
          packageName: this.packageName
        };
        this.transport.send(serializeEnvelope({ payload: connectPayload, requestId }));
        await readyPromise;
      })();
      return this.connectPromise;
    }
    waitForReady() {
      if (this.ready)
        return Promise.resolve();
      return this.connect();
    }
    isConnected() {
      return this.ready && this.transport.isOpen();
    }
    disconnect() {
      if (this.disposed)
        return;
      this.disposed = true;
      try {
        this.emitter.emit("beforeDisconnect", "disconnect called");
      } catch (err) {
        console.warn("[MiniappSession] beforeDisconnect handler threw:", err);
      }
      this.failAllPending({ code: MiniappErrorCode.REQUEST_ABORTED, message: "Session disconnected" });
      try {
        this.transport.close();
      } catch {}
      this.ready = false;
      this.emitter.emit("disconnect", "disconnect called");
    }
    sendOneShot(payload) {
      const envelope = { payload };
      this.enqueueOrSend(serializeEnvelope(envelope));
    }
    sendRequest(payload, opts) {
      if (this.disposed) {
        return Promise.reject(new NotConnectedError);
      }
      const requestId = makeRequestId();
      const envelope = { payload, requestId };
      const timeoutMs = opts?.timeoutMs ?? DEFAULT_REQUEST_TIMEOUT_MS;
      return new Promise((resolve, reject) => {
        const timer = timeoutMs > 0 ? setTimeout(() => {
          const pending = this.pendingRequests.get(requestId);
          if (!pending)
            return;
          this.pendingRequests.delete(requestId);
          pending.reject({
            code: MiniappErrorCode.ACTION_TIMEOUT,
            message: "Request timed out waiting for a response from the host"
          });
        }, timeoutMs) : undefined;
        this.pendingRequests.set(requestId, {
          requestId,
          resolve,
          reject,
          timer
        });
        this.enqueueOrSend(serializeEnvelope(envelope));
      });
    }
    on(event, handler) {
      this.emitter.on(event, handler);
      return () => this.emitter.off(event, handler);
    }
    off(event, handler) {
      this.emitter.off(event, handler);
    }
    onBeforeDisconnect(handler) {
      return this.on("beforeDisconnect", handler);
    }
    onVisibilityChange(handler) {
      return this.on("visibility", handler);
    }
    onCapabilitiesChange(handler) {
      return this.on("capabilities", handler);
    }
    onColorSchemeChange(handler) {
      return this.on("colorScheme", handler);
    }
    enqueueOrSend(raw) {
      if (this.ready) {
        try {
          this.transport.send(raw);
        } catch (err) {
          this.emitter.emit("error", err);
        }
        return;
      }
      this.outboundQueue.push(raw);
    }
    flushQueue() {
      const queue = this.outboundQueue.splice(0);
      for (const raw of queue) {
        try {
          this.transport.send(raw);
        } catch (err) {
          this.emitter.emit("error", err);
        }
      }
    }
    handleIncoming(raw) {
      const envelope = parseEnvelope(raw);
      if (!envelope)
        return;
      const payload = envelope.payload;
      const type = payload?.type;
      switch (type) {
        case MiniappResponseType.CONNECT_ACK: {
          const ack = payload;
          this.userId = ack.userId ?? "";
          if (ack.packageName)
            this.packageName = ack.packageName;
          this.capabilities = ack.capabilities ?? null;
          if (ack.visibility)
            this.visibility = ack.visibility;
          if (ack.colorScheme === "light" || ack.colorScheme === "dark") {
            this.colorScheme = ack.colorScheme;
          }
          if (ack.auth) {
            this.applyAuth(ack.auth);
            if (!this.userId)
              this.userId = ack.auth.mentraUserId;
          }
          if (ack.permissions)
            this.applyPermissions(ack.permissions);
          this.ready = true;
          this.flushQueue();
          this.emitter.emit("ready");
          return;
        }
        case MiniappResponseType.AUTH_UPDATE: {
          const next = payload.auth;
          if (next) {
            this.applyAuth(next);
            if (!this.userId)
              this.userId = next.mentraUserId;
          }
          return;
        }
        case MiniappResponseType.PERMISSIONS_UPDATE: {
          const next = payload.permissions;
          if (next)
            this.applyPermissions(next);
          return;
        }
        case MiniappResponseType.SPEAKER_STATE: {
          const state = payload.state;
          if (!state)
            return;
          const event = {
            state,
            errorCode: payload.errorCode,
            errorMessage: payload.errorMessage,
            durationMs: payload.durationMs
          };
          this.speaker._applyState(event);
          this.emitter.emit("speakerState", event);
          return;
        }
        case MiniappRequestType.PING: {
          const pong = { type: MiniappResponseType.PONG };
          const env = {
            payload: pong,
            ...envelope.requestId ? { requestId: envelope.requestId } : {}
          };
          try {
            this.transport.send(serializeEnvelope(env));
          } catch {}
          return;
        }
        case MiniappResponseType.EVENT: {
          const streamType = payload.streamType;
          if (!streamType)
            return;
          this.events._forwardEvent(streamType, payload.data, payload.transcriptionRoute);
          return;
        }
        case MiniappResponseType.ACTION_CALL: {
          const callId = payload.callId;
          const actionId = payload.actionId;
          if (!callId || !actionId)
            return;
          const params = payload.params ?? {};
          const callerPackageName = payload.callerPackageName ?? "";
          this.actions._deliver(callId, actionId, params, { callerPackageName });
          return;
        }
        case MiniappResponseType.CAPABILITIES_UPDATE: {
          const cap = payload.capabilities ?? null;
          this.capabilities = cap;
          this.emitter.emit("capabilities", cap);
          return;
        }
        case MiniappResponseType.VISIBILITY_CHANGE: {
          const next = payload.visibility;
          if (next === "foreground" || next === "background") {
            this.visibility = next;
            this.emitter.emit("visibility", next);
          }
          return;
        }
        case MiniappResponseType.COLOR_SCHEME_CHANGE: {
          const next = payload.colorScheme;
          if (next === "light" || next === "dark") {
            this.colorScheme = next;
            this.emitter.emit("colorScheme", next);
          }
          return;
        }
        case MiniappResponseType.REQUEST_RESULT: {
          const requestId = envelope.requestId;
          if (!requestId)
            return;
          const pending = this.pendingRequests.get(requestId);
          if (!pending)
            return;
          this.pendingRequests.delete(requestId);
          if (pending.timer)
            clearTimeout(pending.timer);
          if (payload.ok === false) {
            const err = payload.error ?? {
              code: MiniappErrorCode.INTERNAL,
              message: "Unknown error"
            };
            pending.reject(err);
          } else {
            pending.resolve(payload.data ?? null);
          }
          return;
        }
        case MiniappResponseType.WILL_DISCONNECT: {
          const reason = payload.reason ?? "phone unregistering";
          try {
            this.emitter.emit("beforeDisconnect", reason);
          } catch (err) {
            console.warn("[MiniappSession] beforeDisconnect handler threw:", err);
          }
          return;
        }
        case MiniappResponseType.ERROR: {
          const err = new Error(payload.message ?? "MiniappSession error");
          this.emitter.emit("error", err);
          return;
        }
        default:
          return;
      }
    }
    handleTransportDisconnect(reason) {
      this.ready = false;
      this.failAllPending({ code: MiniappErrorCode.NOT_CONNECTED, message: `Transport disconnected: ${reason}` });
      this.emitter.emit("disconnect", reason);
    }
    failAllPending(error) {
      for (const pending of this.pendingRequests.values()) {
        if (pending.timer)
          clearTimeout(pending.timer);
        pending.reject(error);
      }
      this.pendingRequests.clear();
      for (const waiter of Array.from(this.authWaiters)) {
        clearTimeout(waiter.timer);
        this.authWaiters.delete(waiter);
        waiter.reject(new NotConnectedError(error.message));
      }
    }
    authHasTtl(auth, minTtlMs) {
      return auth.expiresAt - Date.now() > minTtlMs;
    }
    requestAuthRefresh(minTtlMs) {
      if (this.authRefreshPromise)
        return this.authRefreshPromise;
      if (!this.ready || !this.transport.isOpen())
        return Promise.resolve(null);
      this.authRefreshPromise = this.sendRequest({
        type: MiniappRequestType.AUTH_REFRESH,
        minTtlMs
      }).then((result) => {
        const auth = result?.auth;
        if (auth)
          this.applyAuth(auth);
        return auth ?? null;
      }).catch((err) => {
        console.warn("[MiniappSession] auth refresh failed:", err);
        return null;
      }).finally(() => {
        this.authRefreshPromise = null;
      });
      return this.authRefreshPromise;
    }
    applyAuth(next) {
      this.authState = { ...next };
      for (const waiter of Array.from(this.authWaiters)) {
        if (!this.authHasTtl(next, waiter.minTtlMs))
          continue;
        clearTimeout(waiter.timer);
        this.authWaiters.delete(waiter);
        waiter.resolve({ ...next });
      }
      this.emitter.emit("auth", { ...next });
    }
    applyPermissions(next) {
      let changed = false;
      const updated = { ...this._permissions };
      for (const k of ALL_PERMISSION_TYPES) {
        const v = next[k] === true;
        if (updated[k] !== v) {
          updated[k] = v;
          changed = true;
        }
      }
      if (changed) {
        this._permissions = updated;
        this.emitter.emit("permissions", { ...updated });
      }
    }
  }
  function manifestKeyToCanonical(manifestKey) {
    switch (manifestKey.toUpperCase()) {
      case "MICROPHONE":
        return "microphone";
      case "CAMERA":
        return "camera";
      case "LOCATION":
      case "BACKGROUND_LOCATION":
        return "location";
      case "READ_NOTIFICATIONS":
      case "POST_NOTIFICATIONS":
        return "notifications";
      case "CALENDAR":
        return "calendar";
      default:
        return null;
    }
  }

  // ../../mobile/modules/miniapp/dist/background/register.js
  function registerMiniapp(handler, options = {}) {
    const g = globalThis;
    g.__mentraInitCallback = (_sessionId) => {
      const session = new MiniappSession(options);
      try {
        const result = handler(session);
        if (result && typeof result.then === "function") {
          result.catch((err) => {
            console.error("[mentra-miniapp] registerMiniapp handler rejected:", err);
          });
        }
      } catch (err) {
        console.error("[mentra-miniapp] registerMiniapp handler threw:", err);
      }
      session.connect().catch((err) => {
        console.error("[mentra-miniapp] session.connect() rejected:", err);
        try {
          const message = err instanceof Error ? err.message : String(err);
          const stack = err instanceof Error && err.stack ? err.stack : "";
          g.__hostError?.(JSON.stringify({ message: `session.connect() failed: ${message}`, stack }));
        } catch {}
      });
    };
  }
  // src/vendor/display-utils/profiles/g1.ts
  var G1_GLYPH_WIDTHS = {
    " ": 2,
    "!": 1,
    '"': 2,
    "#": 6,
    $: 5,
    "%": 6,
    "&": 7,
    "'": 1,
    "(": 2,
    ")": 2,
    "*": 3,
    "+": 4,
    ",": 1,
    "-": 4,
    ".": 1,
    "/": 3,
    "0": 5,
    "1": 3,
    "2": 5,
    "3": 5,
    "4": 5,
    "5": 5,
    "6": 5,
    "7": 5,
    "8": 5,
    "9": 5,
    ":": 1,
    ";": 1,
    "<": 4,
    "=": 4,
    ">": 4,
    "?": 5,
    "@": 7,
    A: 6,
    B: 5,
    C: 5,
    D: 5,
    E: 4,
    F: 4,
    G: 5,
    H: 5,
    I: 2,
    J: 3,
    K: 5,
    L: 4,
    M: 7,
    N: 5,
    O: 5,
    P: 5,
    Q: 5,
    R: 5,
    S: 5,
    T: 5,
    U: 5,
    V: 6,
    W: 7,
    X: 6,
    Y: 6,
    Z: 5,
    "[": 2,
    "\\": 3,
    "]": 2,
    "^": 4,
    _: 3,
    "`": 2,
    a: 5,
    b: 4,
    c: 4,
    d: 4,
    e: 4,
    f: 4,
    g: 4,
    h: 4,
    i: 1,
    j: 2,
    k: 4,
    l: 1,
    m: 7,
    n: 4,
    o: 4,
    p: 4,
    q: 4,
    r: 3,
    s: 4,
    t: 3,
    u: 5,
    v: 5,
    w: 7,
    x: 5,
    y: 5,
    z: 4,
    "{": 3,
    "|": 1,
    "}": 3,
    "~": 7
  };
  var G1_PROFILE = {
    id: "even-realities-g1",
    name: "Even Realities G1",
    displayWidthPx: 576,
    maxLines: 5,
    maxPayloadBytes: 390,
    bleChunkSize: 176,
    fontMetrics: {
      glyphWidths: new Map(Object.entries(G1_GLYPH_WIDTHS)),
      defaultGlyphWidth: 7,
      renderFormula: (glyphWidth) => (glyphWidth + 1) * 2,
      uniformScripts: {
        cjk: 18,
        hiragana: 18,
        katakana: 18,
        korean: 24,
        cyrillic: 18
      },
      fallback: {
        latinMaxWidth: 16,
        unknownBehavior: "useLatinMax"
      }
    },
    constraints: {
      minCharsBeforeHyphen: 3,
      noStartChars: [".", ",", "!", "?", ":", ";", ")", "]", "}", "。", "，", "！", "？", "：", "；", "）", "】", "」"],
      noEndChars: ["(", "[", "{", "（", "【", "「"]
    }
  };
  var G1_PROFILE_LEGACY = {
    id: "even-realities-g1-legacy",
    name: "Even Realities G1 (Legacy Client Compatibility)",
    displayWidthPx: 420,
    maxLines: 5,
    maxPayloadBytes: 390,
    bleChunkSize: 176,
    fontMetrics: {
      glyphWidths: new Map(Object.entries(G1_GLYPH_WIDTHS)),
      defaultGlyphWidth: 7,
      renderFormula: (glyphWidth) => (glyphWidth + 1) * 2,
      uniformScripts: {
        cjk: 18,
        hiragana: 18,
        katakana: 18,
        korean: 24,
        cyrillic: 18
      },
      fallback: {
        latinMaxWidth: 16,
        unknownBehavior: "useLatinMax"
      }
    },
    constraints: {
      minCharsBeforeHyphen: 3,
      noStartChars: [".", ",", "!", "?", ":", ";", ")", "]", "}", "。", "，", "！", "？", "：", "；", "）", "】", "」"],
      noEndChars: ["(", "[", "{", "（", "【", "「"]
    }
  };
  // src/vendor/display-utils/profiles/g2.ts
  var G2_PROFILE = {
    ...G1_PROFILE,
    id: "even-realities-g2",
    name: "Even Realities G2",
    displayHeightPx: 288,
    maxLines: 8,
    lineHeightPx: 40
  };
  // src/vendor/display-utils/profiles/z100.ts
  var Z100_GLYPH_WIDTHS = {
    " ": 5,
    "!": 6,
    '"': 9,
    "#": 14,
    $: 12,
    "%": 17,
    "&": 15,
    "'": 5,
    "(": 6,
    ")": 6,
    "*": 12,
    "+": 12,
    ",": 6,
    "-": 7,
    ".": 6,
    "/": 8,
    "0": 12,
    "1": 12,
    "2": 12,
    "3": 12,
    "4": 12,
    "5": 12,
    "6": 12,
    "7": 12,
    "8": 12,
    "9": 12,
    ":": 6,
    ";": 6,
    "<": 12,
    "=": 12,
    ">": 12,
    "?": 9,
    "@": 19,
    A: 13,
    B: 14,
    C: 13,
    D: 15,
    E: 12,
    F: 11,
    G: 15,
    H: 16,
    I: 7,
    J: 6,
    K: 13,
    L: 11,
    M: 19,
    N: 16,
    O: 16,
    P: 13,
    Q: 16,
    R: 13,
    S: 12,
    T: 12,
    U: 15,
    V: 13,
    W: 20,
    X: 12,
    Y: 12,
    Z: 12,
    "[": 7,
    "\\": 8,
    "]": 7,
    "^": 12,
    _: 9,
    "`": 6,
    a: 12,
    b: 13,
    c: 10,
    d: 13,
    e: 12,
    f: 7,
    g: 13,
    h: 13,
    i: 5,
    j: 5,
    k: 11,
    l: 5,
    m: 20,
    n: 13,
    o: 13,
    p: 13,
    q: 13,
    r: 9,
    s: 10,
    t: 8,
    u: 13,
    v: 11,
    w: 17,
    x: 11,
    y: 11,
    z: 10,
    "{": 8,
    "|": 12,
    "}": 8,
    "~": 12
  };
  var Z100_PROFILE = {
    id: "vuzix-z100",
    name: "Vuzix Z100",
    displayWidthPx: 390,
    maxLines: 7,
    maxPayloadBytes: 512,
    bleChunkSize: 180,
    fontMetrics: {
      glyphWidths: new Map(Object.entries(Z100_GLYPH_WIDTHS)),
      defaultGlyphWidth: 12,
      renderFormula: (glyphWidth) => glyphWidth,
      uniformScripts: {
        cjk: 21,
        hiragana: 21,
        katakana: 21,
        korean: 21,
        cyrillic: 14
      },
      fallback: {
        latinMaxWidth: 20,
        unknownBehavior: "useLatinMax"
      }
    },
    constraints: {
      minCharsBeforeHyphen: 3,
      noStartChars: [
        ".",
        ",",
        "!",
        "?",
        ":",
        ";",
        ")",
        "]",
        "}",
        "。",
        "，",
        "！",
        "？",
        "：",
        "；",
        "）",
        "】",
        "」"
      ],
      noEndChars: ["(", "[", "{", "（", "【", "「"]
    }
  };
  // src/vendor/display-utils/profiles/nex.ts
  var NEX_GLYPH_WIDTHS = {
    " ": 2,
    "!": 1,
    '"': 2,
    "#": 6,
    $: 5,
    "%": 6,
    "&": 7,
    "'": 1,
    "(": 2,
    ")": 2,
    "*": 3,
    "+": 4,
    ",": 1,
    "-": 4,
    ".": 1,
    "/": 3,
    "0": 5,
    "1": 3,
    "2": 5,
    "3": 5,
    "4": 5,
    "5": 5,
    "6": 5,
    "7": 5,
    "8": 5,
    "9": 5,
    ":": 1,
    ";": 1,
    "<": 4,
    "=": 4,
    ">": 4,
    "?": 5,
    "@": 7,
    A: 6,
    B: 5,
    C: 5,
    D: 5,
    E: 4,
    F: 4,
    G: 5,
    H: 5,
    I: 2,
    J: 3,
    K: 5,
    L: 4,
    M: 7,
    N: 5,
    O: 5,
    P: 5,
    Q: 5,
    R: 5,
    S: 5,
    T: 5,
    U: 5,
    V: 6,
    W: 7,
    X: 6,
    Y: 6,
    Z: 5,
    "[": 2,
    "\\": 3,
    "]": 2,
    "^": 4,
    _: 3,
    "`": 2,
    a: 5,
    b: 4,
    c: 4,
    d: 4,
    e: 4,
    f: 4,
    g: 4,
    h: 4,
    i: 1,
    j: 2,
    k: 4,
    l: 1,
    m: 7,
    n: 4,
    o: 4,
    p: 4,
    q: 4,
    r: 3,
    s: 4,
    t: 3,
    u: 5,
    v: 5,
    w: 7,
    x: 5,
    y: 5,
    z: 4,
    "{": 3,
    "|": 1,
    "}": 3,
    "~": 7
  };
  var NEX_PROFILE = {
    id: "mentra-nex",
    name: "Mentra Nex",
    displayWidthPx: 576,
    maxLines: 5,
    lineHeightPx: 27,
    maxPayloadBytes: 390,
    bleChunkSize: 176,
    fontMetrics: {
      glyphWidths: new Map(Object.entries(NEX_GLYPH_WIDTHS)),
      defaultGlyphWidth: 7,
      renderFormula: (glyphWidth) => (glyphWidth + 1) * 2,
      uniformScripts: {
        cjk: 18,
        hiragana: 18,
        katakana: 18,
        korean: 24,
        cyrillic: 18
      },
      fallback: {
        latinMaxWidth: 16,
        unknownBehavior: "useLatinMax"
      }
    },
    constraints: {
      minCharsBeforeHyphen: 3,
      noStartChars: [".", ",", "!", "?", ":", ";", ")", "]", "}", "。", "，", "！", "？", "：", "；", "）", "】", "」"],
      noEndChars: ["(", "[", "{", "（", "【", "「"]
    }
  };
  // src/vendor/display-utils/measurer/script-detection.ts
  var SCRIPT_RANGES = {
    cjk: [
      [19968, 40959],
      [13312, 19903],
      [131072, 173791],
      [173824, 177983],
      [177984, 178207],
      [63744, 64255]
    ],
    hiragana: [[12352, 12447]],
    katakana: [
      [12448, 12543],
      [12784, 12799]
    ],
    korean: [
      [44032, 55215],
      [4352, 4607],
      [12592, 12687],
      [43360, 43391],
      [55216, 55295]
    ],
    cyrillic: [
      [1024, 1279],
      [1280, 1327]
    ],
    numbers: [[48, 57]],
    punctuation: [
      [32, 47],
      [58, 64],
      [91, 96],
      [123, 126]
    ],
    arabic: [[1536, 1791]],
    hebrew: [[1424, 1535]],
    thai: [[3584, 3711]],
    emoji: [
      [128512, 128591],
      [127744, 128511],
      [128640, 128767],
      [127456, 127487],
      [9728, 9983],
      [9984, 10175],
      [65024, 65039],
      [129280, 129535]
    ]
  };
  function inRanges(codePoint, ranges) {
    for (const [start, end] of ranges) {
      if (codePoint >= start && codePoint <= end) {
        return true;
      }
    }
    return false;
  }
  function detectScript(char) {
    if (!char || char.length === 0) {
      return "latin";
    }
    const codePoint = char.codePointAt(0);
    if (codePoint === undefined) {
      return "latin";
    }
    if (inRanges(codePoint, SCRIPT_RANGES.cjk)) {
      return "cjk";
    }
    if (inRanges(codePoint, SCRIPT_RANGES.hiragana)) {
      return "hiragana";
    }
    if (inRanges(codePoint, SCRIPT_RANGES.katakana)) {
      return "katakana";
    }
    if (inRanges(codePoint, SCRIPT_RANGES.korean)) {
      return "korean";
    }
    if (inRanges(codePoint, SCRIPT_RANGES.cyrillic)) {
      return "cyrillic";
    }
    if (inRanges(codePoint, SCRIPT_RANGES.numbers)) {
      return "numbers";
    }
    if (inRanges(codePoint, SCRIPT_RANGES.punctuation)) {
      return "punctuation";
    }
    if (inRanges(codePoint, SCRIPT_RANGES.arabic) || inRanges(codePoint, SCRIPT_RANGES.hebrew) || inRanges(codePoint, SCRIPT_RANGES.thai) || inRanges(codePoint, SCRIPT_RANGES.emoji)) {
      return "unsupported";
    }
    return "latin";
  }
  function isCJKCharacter(char) {
    const script = detectScript(char);
    return script === "cjk" || script === "hiragana" || script === "katakana";
  }
  function isUniformWidthScript(char) {
    const script = detectScript(char);
    return script === "cjk" || script === "hiragana" || script === "katakana" || script === "korean" || script === "cyrillic";
  }
  function needsHyphenForBreak(charBefore, charAfter) {
    if (isCJKCharacter(charBefore)) {
      return false;
    }
    if (isCJKCharacter(charAfter)) {
      return false;
    }
    if (charBefore === " " || charBefore === "\t") {
      return false;
    }
    if (charAfter === " " || charAfter === "\t") {
      return false;
    }
    const breakPunctuation = ["-", "–", "—", "/", "\\", "|"];
    if (breakPunctuation.includes(charBefore)) {
      return false;
    }
    return true;
  }

  // src/vendor/display-utils/measurer/TextMeasurer.ts
  class TextMeasurer {
    profile;
    charCache = new Map;
    constructor(profile) {
      this.profile = profile;
      this.buildCharCache();
    }
    buildCharCache() {
      const { glyphWidths, renderFormula } = this.profile.fontMetrics;
      for (const [char, glyphWidth] of glyphWidths.entries()) {
        const renderedWidth = renderFormula(glyphWidth);
        this.charCache.set(char, renderedWidth);
      }
    }
    measureText(text) {
      if (!text || text.length === 0) {
        return 0;
      }
      let totalWidth = 0;
      for (const char of text) {
        totalWidth += this.measureChar(char);
      }
      return totalWidth;
    }
    measureTextDetailed(text) {
      if (!text || text.length === 0) {
        return {
          text: "",
          totalWidthPx: 0,
          charCount: 0,
          chars: []
        };
      }
      const chars = [];
      let totalWidth = 0;
      for (const char of text) {
        const script = detectScript(char);
        const widthPx = this.measureChar(char);
        const fromGlyphMap = this.profile.fontMetrics.glyphWidths.has(char);
        chars.push({
          char,
          widthPx,
          script,
          fromGlyphMap
        });
        totalWidth += widthPx;
      }
      return {
        text,
        totalWidthPx: totalWidth,
        charCount: chars.length,
        chars
      };
    }
    measureChar(char) {
      if (!char || char.length === 0) {
        return 0;
      }
      const cached = this.charCache.get(char);
      if (cached !== undefined) {
        return cached;
      }
      const width = this.calculateCharWidth(char);
      this.charCache.set(char, width);
      return width;
    }
    calculateCharWidth(char) {
      const { fontMetrics } = this.profile;
      const { uniformScripts, fallback, renderFormula, glyphWidths } = fontMetrics;
      const glyphWidth = glyphWidths.get(char);
      if (glyphWidth !== undefined) {
        return renderFormula(glyphWidth);
      }
      const script = detectScript(char);
      switch (script) {
        case "cjk":
          return uniformScripts.cjk;
        case "hiragana":
          return uniformScripts.hiragana;
        case "katakana":
          return uniformScripts.katakana;
        case "korean":
          return uniformScripts.korean;
        case "cyrillic":
          return uniformScripts.cyrillic;
      }
      return fallback.latinMaxWidth;
    }
    getGlyphWidth(char) {
      return this.profile.fontMetrics.glyphWidths.get(char);
    }
    fitsInWidth(text, maxWidthPx) {
      return this.measureText(text) <= maxWidthPx;
    }
    charsThatFit(text, maxWidthPx, startIndex = 0) {
      if (!text || startIndex >= text.length) {
        return 0;
      }
      let currentWidth = 0;
      let count = 0;
      const chars = Array.from(text).slice(startIndex);
      for (const char of chars) {
        const charWidth = this.measureChar(char);
        if (currentWidth + charWidth > maxWidthPx) {
          break;
        }
        currentWidth += charWidth;
        count++;
      }
      return count;
    }
    getPixelOffset(text, index) {
      if (!text || index <= 0) {
        return 0;
      }
      const chars = Array.from(text).slice(0, index);
      let offset = 0;
      for (const char of chars) {
        offset += this.measureChar(char);
      }
      return offset;
    }
    detectScript(char) {
      return detectScript(char);
    }
    isUniformWidth(char) {
      return isUniformWidthScript(char);
    }
    getProfile() {
      return this.profile;
    }
    getDisplayWidthPx() {
      return this.profile.displayWidthPx;
    }
    getMaxLines() {
      return this.profile.maxLines;
    }
    getMaxPayloadBytes() {
      return this.profile.maxPayloadBytes;
    }
    getByteSize(text) {
      return new TextEncoder().encode(text).length;
    }
    getHyphenWidth() {
      return this.measureChar("-");
    }
    getSpaceWidth() {
      return this.measureChar(" ");
    }
    clearCache() {
      this.charCache.clear();
      this.buildCharCache();
    }
  }
  // src/vendor/display-utils/wrapper/types.ts
  var DEFAULT_WRAP_OPTIONS = {
    breakMode: "character-no-hyphen",
    hyphenChar: "-",
    minCharsBeforeHyphen: 3,
    trimLines: true,
    preserveNewlines: true
  };

  // src/vendor/display-utils/wrapper/TextWrapper.ts
  class TextWrapper {
    measurer;
    defaultOptions;
    constructor(measurer, defaultOptions) {
      this.measurer = measurer;
      const profile = measurer.getProfile();
      this.defaultOptions = {
        maxWidthPx: profile.displayWidthPx,
        maxLines: profile.maxLines,
        maxBytes: profile.maxPayloadBytes,
        ...DEFAULT_WRAP_OPTIONS,
        ...defaultOptions
      };
    }
    wrap(text, options) {
      const opts = this.mergeOptions(options);
      const { maxWidthPx, maxLines, maxBytes, breakMode, preserveNewlines } = opts;
      if (!text || text.length === 0) {
        return this.createEmptyResult(opts);
      }
      const paragraphs = preserveNewlines ? text.split(`
`) : [text];
      const allLines = [];
      const allMetrics = [];
      let totalBytes = 0;
      let truncated = false;
      for (let pIndex = 0;pIndex < paragraphs.length; pIndex++) {
        const paragraph = paragraphs[pIndex];
        const isFromNewline = pIndex > 0;
        const paragraphLines = this.wrapParagraph(paragraph, maxWidthPx, breakMode, opts);
        for (let lIndex = 0;lIndex < paragraphLines.length; lIndex++) {
          const line = paragraphLines[lIndex];
          const lineBytes = this.measurer.getByteSize(line);
          if (allLines.length >= maxLines) {
            truncated = true;
            break;
          }
          if (totalBytes + lineBytes > maxBytes) {
            truncated = true;
            break;
          }
          const widthPx = this.measurer.measureText(line);
          const metrics = {
            text: line,
            widthPx,
            bytes: lineBytes,
            utilizationPercent: Math.round(widthPx / maxWidthPx * 100),
            endsWithHyphen: line.endsWith(opts.hyphenChar) && lIndex < paragraphLines.length - 1,
            fromExplicitNewline: isFromNewline && lIndex === 0
          };
          allLines.push(line);
          allMetrics.push(metrics);
          totalBytes += lineBytes;
          if (allLines.length < maxLines) {
            totalBytes += 1;
          }
        }
        if (truncated)
          break;
      }
      const maxLineWidthPx = allMetrics.reduce((max, m) => Math.max(max, m.widthPx), 0);
      return {
        lines: allLines,
        truncated,
        maxLineWidthPx,
        totalBytes,
        lineMetrics: allMetrics,
        originalText: text,
        breakMode
      };
    }
    wrapToLines(text, options) {
      return this.wrap(text, options).lines;
    }
    needsWrap(text, maxWidthPx) {
      const width = maxWidthPx ?? this.defaultOptions.maxWidthPx;
      return this.measurer.measureText(text) > width || text.includes(`
`);
    }
    getOptions() {
      return { ...this.defaultOptions };
    }
    getMeasurer() {
      return this.measurer;
    }
    wrapParagraph(paragraph, maxWidthPx, breakMode, opts) {
      const trimmed = opts.trimLines ? paragraph.trim() : paragraph;
      if (!trimmed) {
        return [""];
      }
      if (this.measurer.fitsInWidth(trimmed, maxWidthPx)) {
        return [trimmed];
      }
      switch (breakMode) {
        case "character":
          return this.wrapCharacterMode(trimmed, maxWidthPx, opts);
        case "character-no-hyphen":
          return this.wrapCharacterNoHyphenMode(trimmed, maxWidthPx, opts);
        case "word":
          return this.wrapWordMode(trimmed, maxWidthPx, opts);
        case "strict-word":
          return this.wrapStrictWordMode(trimmed, maxWidthPx, opts);
        default:
          return this.wrapCharacterMode(trimmed, maxWidthPx, opts);
      }
    }
    wrapCharacterMode(text, maxWidthPx, opts) {
      return this.wrapCharacterModeInternal(text, maxWidthPx, opts, true);
    }
    wrapCharacterNoHyphenMode(text, maxWidthPx, opts) {
      return this.wrapCharacterModeInternal(text, maxWidthPx, opts, false);
    }
    wrapCharacterModeInternal(text, maxWidthPx, opts, useHyphen) {
      const lines = [];
      const hyphenWidth = this.measurer.measureChar(opts.hyphenChar);
      let currentLine = "";
      let currentWidth = 0;
      const chars = Array.from(text);
      for (let i = 0;i < chars.length; i++) {
        const char = chars[i];
        const charWidth = this.measurer.measureChar(char);
        if (currentWidth + charWidth <= maxWidthPx) {
          currentLine += char;
          currentWidth += charWidth;
        } else {
          const prevChar = currentLine.length > 0 ? currentLine[currentLine.length - 1] : "";
          const needsHyphen = useHyphen && currentLine.length >= opts.minCharsBeforeHyphen && needsHyphenForBreak(prevChar, char);
          if (needsHyphen) {
            const result = this.backoffForHyphen(currentLine, currentWidth, maxWidthPx, hyphenWidth, opts);
            if (result.skipHyphen) {
              lines.push(result.line);
            } else {
              lines.push(result.line + opts.hyphenChar);
            }
            currentLine = result.remainder + char;
            currentWidth = this.measurer.measureText(currentLine);
          } else if (useHyphen === false && !isCJKCharacter(char) && char !== " ") {
            const trimmedLine = opts.trimLines ? currentLine.trimEnd() : currentLine;
            if (trimmedLine) {
              lines.push(trimmedLine);
            }
            currentLine = char;
            currentWidth = charWidth;
          } else {
            const trimmedLine = opts.trimLines ? currentLine.trimEnd() : currentLine;
            if (trimmedLine) {
              lines.push(trimmedLine);
            }
            currentLine = char === " " ? "" : char;
            currentWidth = char === " " ? 0 : charWidth;
          }
        }
      }
      if (currentLine) {
        const trimmedLine = opts.trimLines ? currentLine.trim() : currentLine;
        if (trimmedLine) {
          lines.push(trimmedLine);
        }
      }
      return lines.length > 0 ? lines : [""];
    }
    wrapWordMode(text, maxWidthPx, opts) {
      const lines = [];
      const words = this.splitIntoWords(text);
      const spaceWidth = this.measurer.getSpaceWidth();
      let currentLine = "";
      let currentWidth = 0;
      for (const word of words) {
        const wordWidth = this.measurer.measureText(word);
        const needsSpace = currentLine.length > 0;
        const totalWidth = currentWidth + (needsSpace ? spaceWidth : 0) + wordWidth;
        if (totalWidth <= maxWidthPx) {
          if (needsSpace) {
            currentLine += " ";
            currentWidth += spaceWidth;
          }
          currentLine += word;
          currentWidth += wordWidth;
        } else {
          if (currentLine.length > 0) {
            lines.push(opts.trimLines ? currentLine.trim() : currentLine);
            currentLine = "";
            currentWidth = 0;
          }
          if (wordWidth > maxWidthPx) {
            const hyphenatedLines = this.hyphenateLongWord(word, maxWidthPx, opts);
            for (let i = 0;i < hyphenatedLines.length - 1; i++) {
              lines.push(hyphenatedLines[i]);
            }
            currentLine = hyphenatedLines[hyphenatedLines.length - 1];
            currentWidth = this.measurer.measureText(currentLine);
          } else {
            currentLine = word;
            currentWidth = wordWidth;
          }
        }
      }
      if (currentLine) {
        const trimmedLine = opts.trimLines ? currentLine.trim() : currentLine;
        if (trimmedLine) {
          lines.push(trimmedLine);
        }
      }
      return lines.length > 0 ? lines : [""];
    }
    wrapStrictWordMode(text, maxWidthPx, opts) {
      const lines = [];
      const words = this.splitIntoWords(text);
      const spaceWidth = this.measurer.getSpaceWidth();
      let currentLine = "";
      let currentWidth = 0;
      for (const word of words) {
        const wordWidth = this.measurer.measureText(word);
        const needsSpace = currentLine.length > 0;
        const totalWidth = currentWidth + (needsSpace ? spaceWidth : 0) + wordWidth;
        if (totalWidth <= maxWidthPx) {
          if (needsSpace) {
            currentLine += " ";
            currentWidth += spaceWidth;
          }
          currentLine += word;
          currentWidth += wordWidth;
        } else {
          if (currentLine.length > 0) {
            lines.push(opts.trimLines ? currentLine.trim() : currentLine);
          }
          currentLine = word;
          currentWidth = wordWidth;
        }
      }
      if (currentLine) {
        const trimmedLine = opts.trimLines ? currentLine.trim() : currentLine;
        if (trimmedLine) {
          lines.push(trimmedLine);
        }
      }
      return lines.length > 0 ? lines : [""];
    }
    splitIntoWords(text) {
      const words = [];
      let currentWord = "";
      for (const char of text) {
        if (char === " " || char === "\t") {
          if (currentWord) {
            words.push(currentWord);
            currentWord = "";
          }
        } else if (isCJKCharacter(char)) {
          if (currentWord) {
            words.push(currentWord);
            currentWord = "";
          }
          words.push(char);
        } else {
          currentWord += char;
        }
      }
      if (currentWord) {
        words.push(currentWord);
      }
      return words;
    }
    hyphenateLongWord(word, maxWidthPx, opts) {
      const lines = [];
      const hyphenWidth = this.measurer.measureChar(opts.hyphenChar);
      const chars = Array.from(word);
      let currentLine = "";
      let currentWidth = 0;
      for (let i = 0;i < chars.length; i++) {
        const char = chars[i];
        const charWidth = this.measurer.measureChar(char);
        const isLastChar = i === chars.length - 1;
        const widthNeeded = isLastChar ? charWidth : charWidth + hyphenWidth;
        if (currentWidth + widthNeeded <= maxWidthPx) {
          currentLine += char;
          currentWidth += charWidth;
        } else {
          if (currentLine.length >= opts.minCharsBeforeHyphen) {
            const result = this.backoffForHyphen(currentLine, currentWidth, maxWidthPx, hyphenWidth, opts);
            if (result.skipHyphen) {
              lines.push(result.line);
            } else {
              lines.push(result.line + opts.hyphenChar);
            }
            currentLine = result.remainder + char;
            currentWidth = this.measurer.measureText(currentLine);
          } else {
            if (currentLine) {
              lines.push(currentLine);
            }
            currentLine = char;
            currentWidth = charWidth;
          }
        }
      }
      if (currentLine) {
        lines.push(currentLine);
      }
      return lines.length > 0 ? lines : [word];
    }
    backoffForHyphen(line, lineWidth, maxWidthPx, hyphenWidth, opts) {
      let adjustedLine = line;
      let adjustedWidth = lineWidth;
      let remainder = "";
      while (adjustedWidth + hyphenWidth > maxWidthPx && adjustedLine.length > opts.minCharsBeforeHyphen) {
        const lastChar = adjustedLine[adjustedLine.length - 1];
        const lastCharWidth = this.measurer.measureChar(lastChar);
        adjustedLine = adjustedLine.slice(0, -1);
        adjustedWidth -= lastCharWidth;
        remainder = lastChar + remainder;
        if (adjustedLine.length > 0 && adjustedLine[adjustedLine.length - 1] === " ") {
          adjustedLine = adjustedLine.trimEnd();
          return { line: adjustedLine, remainder, skipHyphen: true };
        }
      }
      return { line: adjustedLine, remainder, skipHyphen: false };
    }
    mergeOptions(options) {
      return {
        ...this.defaultOptions,
        ...options
      };
    }
    createEmptyResult(opts) {
      return {
        lines: [""],
        truncated: false,
        maxLineWidthPx: 0,
        totalBytes: 0,
        lineMetrics: [
          {
            text: "",
            widthPx: 0,
            bytes: 0,
            utilizationPercent: 0,
            endsWithHyphen: false,
            fromExplicitNewline: false
          }
        ],
        originalText: "",
        breakMode: opts.breakMode
      };
    }
  }
  // src/vendor/display-utils/helpers/DisplayHelpers.ts
  class DisplayHelpers {
    measurer;
    wrapper;
    profile;
    constructor(measurer, wrapper) {
      this.measurer = measurer;
      this.wrapper = wrapper;
      this.profile = measurer.getProfile();
    }
    truncateToLines(lines, maxLines, fromEnd = false) {
      if (lines.length <= maxLines) {
        return lines;
      }
      if (fromEnd) {
        return lines.slice(-maxLines);
      } else {
        return lines.slice(0, maxLines);
      }
    }
    truncateWithEllipsis(text, maxWidthPx, ellipsis = "...") {
      const width = maxWidthPx ?? this.profile.displayWidthPx;
      const textWidth = this.measurer.measureText(text);
      if (textWidth <= width) {
        return {
          text,
          wasTruncated: false,
          widthPx: textWidth,
          originalLength: text.length,
          truncatedLength: text.length
        };
      }
      const ellipsisWidth = this.measurer.measureText(ellipsis);
      const targetWidth = width - ellipsisWidth;
      let truncated = "";
      let currentWidth = 0;
      for (const char of text) {
        const charWidth = this.measurer.measureChar(char);
        if (currentWidth + charWidth > targetWidth) {
          break;
        }
        truncated += char;
        currentWidth += charWidth;
      }
      truncated = truncated.trimEnd();
      const finalText = truncated + ellipsis;
      return {
        text: finalText,
        wasTruncated: true,
        widthPx: this.measurer.measureText(finalText),
        originalLength: text.length,
        truncatedLength: truncated.length
      };
    }
    estimateLineCount(text, maxWidthPx) {
      if (!text)
        return 1;
      const width = maxWidthPx ?? this.profile.displayWidthPx;
      const textWidth = this.measurer.measureText(text);
      const newlineCount = (text.match(/\n/g) || []).length;
      const wrappedLines = Math.ceil(textWidth / width);
      return wrappedLines + newlineCount;
    }
    fitToScreen(text, options) {
      const result = this.wrapper.wrap(text, options);
      return result.lines.slice(0, this.profile.maxLines);
    }
    paginate(text, options) {
      const wrapResult = this.wrapper.wrap(text, {
        ...options,
        maxLines: Infinity,
        maxBytes: Infinity
      });
      const linesPerPage = options?.maxLines ?? this.profile.maxLines;
      const allLines = wrapResult.lines;
      const pages = [];
      for (let i = 0;i < allLines.length; i += linesPerPage) {
        const pageLines = allLines.slice(i, i + linesPerPage);
        const pageNumber = Math.floor(i / linesPerPage) + 1;
        const totalPages = Math.ceil(allLines.length / linesPerPage);
        pages.push({
          lines: pageLines,
          pageNumber,
          totalPages,
          isFirst: pageNumber === 1,
          isLast: pageNumber === totalPages
        });
      }
      return pages.length > 0 ? pages : [
        {
          lines: [""],
          pageNumber: 1,
          totalPages: 1,
          isFirst: true,
          isLast: true
        }
      ];
    }
    calculateByteSize(text) {
      return this.measurer.getByteSize(text);
    }
    exceedsByteLimit(text, maxBytes) {
      const limit = maxBytes ?? this.profile.maxPayloadBytes;
      return this.calculateByteSize(text) > limit;
    }
    splitIntoChunks(text, chunkSize) {
      const size = chunkSize ?? this.profile.bleChunkSize;
      const encoder = new TextEncoder;
      const bytes = encoder.encode(text);
      if (bytes.length <= size) {
        return [
          {
            text,
            index: 0,
            totalChunks: 1,
            bytes: bytes.length
          }
        ];
      }
      const chunks = [];
      let offset = 0;
      while (offset < bytes.length) {
        let endOffset = Math.min(offset + size, bytes.length);
        if (endOffset < bytes.length) {
          while (endOffset > offset && (bytes[endOffset] & 192) === 128) {
            endOffset--;
          }
          let breakPoint = endOffset;
          for (let i = endOffset - 1;i > offset + size / 2; i--) {
            if (bytes[i] === 32 || bytes[i] === 10) {
              breakPoint = i + 1;
              break;
            }
          }
          if (breakPoint > offset) {
            endOffset = breakPoint;
          }
        }
        const chunkBytes = bytes.slice(offset, endOffset);
        const chunkText = new TextDecoder().decode(chunkBytes);
        chunks.push({
          text: chunkText,
          index: chunks.length,
          totalChunks: 0,
          bytes: chunkBytes.length
        });
        offset = endOffset;
      }
      for (const chunk of chunks) {
        chunk.totalChunks = chunks.length;
      }
      return chunks;
    }
    calculateUtilization(result) {
      if (result.lines.length === 0 || result.lineMetrics.length === 0) {
        return {
          averageUtilization: 0,
          minUtilization: 0,
          maxUtilization: 0,
          totalWastedPx: 0
        };
      }
      const maxWidthPx = this.profile.displayWidthPx;
      let totalUtilization = 0;
      let minUtilization = 100;
      let maxUtilization = 0;
      let totalWastedPx = 0;
      for (const metric of result.lineMetrics) {
        totalUtilization += metric.utilizationPercent;
        minUtilization = Math.min(minUtilization, metric.utilizationPercent);
        maxUtilization = Math.max(maxUtilization, metric.utilizationPercent);
        totalWastedPx += maxWidthPx - metric.widthPx;
      }
      return {
        averageUtilization: Math.round(totalUtilization / result.lineMetrics.length),
        minUtilization,
        maxUtilization,
        totalWastedPx
      };
    }
    padToLineCount(lines, targetCount, padAtEnd = true) {
      if (lines.length >= targetCount) {
        return lines.slice(0, targetCount);
      }
      const padding = Array(targetCount - lines.length).fill("");
      if (padAtEnd) {
        return [...lines, ...padding];
      } else {
        return [...padding, ...lines];
      }
    }
    joinLines(lines) {
      return lines.join(`
`);
    }
    getMeasurer() {
      return this.measurer;
    }
    getWrapper() {
      return this.wrapper;
    }
    getProfile() {
      return this.profile;
    }
  }
  // src/core/CaptionsFormatter.ts
  class CaptionsFormatter {
    measurer;
    wrapper;
    helpers;
    profile;
    finalTranscriptHistory = [];
    maxFinalTranscripts;
    partialSpeakerId = undefined;
    partialHadSpeakerChange = false;
    displayWidthPx;
    maxLines;
    constructor(profile = G1_PROFILE, options = {}) {
      this.profile = profile;
      this.maxFinalTranscripts = options.maxFinalTranscripts ?? 30;
      this.displayWidthPx = options.displayWidthPx ?? profile.displayWidthPx;
      this.maxLines = options.maxLines ?? profile.maxLines;
      const breakMode = options.breakMode ?? (options.useCharacterBreaking !== false ? "character" : "word");
      this.measurer = new TextMeasurer(profile);
      this.wrapper = new TextWrapper(this.measurer, {
        breakMode,
        hyphenChar: "-",
        minCharsBeforeHyphen: 3
      });
      this.helpers = new DisplayHelpers(this.measurer, this.wrapper);
    }
    processTranscription(text, isFinal, speakerId, speakerChanged) {
      const cleanText = text?.trim() ?? "";
      if (!isFinal) {
        return this.processInterim(cleanText, speakerId, speakerChanged);
      } else {
        return this.processFinal(cleanText, speakerId, speakerChanged);
      }
    }
    processInterim(text, speakerId, speakerChanged) {
      if (speakerChanged && speakerId) {
        this.partialSpeakerId = speakerId;
        this.partialHadSpeakerChange = true;
      } else if (speakerId && speakerId !== this.partialSpeakerId) {
        this.partialSpeakerId = speakerId;
        this.partialHadSpeakerChange = true;
      }
      const displayText = this.buildDisplayText(text, this.partialSpeakerId, this.partialHadSpeakerChange);
      return this.wrapAndFormat(displayText);
    }
    processFinal(text, speakerId, speakerChanged) {
      const finalSpeakerId = speakerId || this.partialSpeakerId;
      const finalSpeakerChanged = speakerChanged || this.partialHadSpeakerChange;
      this.partialSpeakerId = undefined;
      this.partialHadSpeakerChange = false;
      if (text) {
        this.addToHistory(text, finalSpeakerId, finalSpeakerChanged);
      }
      const displayText = this.buildDisplayText("", undefined, false);
      return this.wrapAndFormat(displayText);
    }
    buildDisplayText(partialText, partialSpeakerId, partialSpeakerChanged) {
      let result = "";
      for (const entry of this.finalTranscriptHistory) {
        if (entry.hadSpeakerChange && entry.speakerId) {
          if (result.length > 0) {
            result += `
`;
          }
          result += `[${entry.speakerId}]: ${entry.text}`;
        } else {
          if (result.length > 0) {
            result += " ";
          }
          result += entry.text;
        }
      }
      if (partialText) {
        if (partialSpeakerChanged && partialSpeakerId) {
          if (result.length > 0) {
            result += `
`;
          }
          result += `[${partialSpeakerId}]: ${partialText}`;
        } else {
          if (result.length > 0) {
            result += " ";
          }
          result += partialText;
        }
      }
      return result;
    }
    wrapAndFormat(displayText) {
      const result = this.wrapper.wrap(displayText, {
        maxWidthPx: this.displayWidthPx,
        maxLines: Infinity,
        maxBytes: Infinity
      });
      let lines = result.lines;
      if (lines.length > this.maxLines) {
        lines = lines.slice(-this.maxLines);
      }
      const wasTruncated = result.lines.length > this.maxLines;
      return {
        lines,
        displayText: lines.join(`
`),
        truncated: wasTruncated,
        lineMetrics: result.lineMetrics.slice(-this.maxLines)
      };
    }
    addToHistory(transcript, speakerId, speakerChanged) {
      if (!transcript.trim())
        return;
      this.finalTranscriptHistory.push({
        text: transcript,
        speakerId,
        hadSpeakerChange: speakerChanged ?? false
      });
      while (this.finalTranscriptHistory.length > this.maxFinalTranscripts) {
        this.finalTranscriptHistory.shift();
      }
    }
    getFinalTranscriptHistory() {
      return [...this.finalTranscriptHistory];
    }
    getCombinedTranscriptHistory() {
      return this.finalTranscriptHistory.map((entry) => entry.text).join(" ");
    }
    clear() {
      this.finalTranscriptHistory = [];
      this.partialSpeakerId = undefined;
      this.partialHadSpeakerChange = false;
    }
    setMaxFinalTranscripts(max) {
      this.maxFinalTranscripts = max;
      while (this.finalTranscriptHistory.length > this.maxFinalTranscripts) {
        this.finalTranscriptHistory.shift();
      }
    }
    getMaxFinalTranscripts() {
      return this.maxFinalTranscripts;
    }
    getProfile() {
      return this.profile;
    }
    getMeasurer() {
      return this.measurer;
    }
    getWrapper() {
      return this.wrapper;
    }
    getHelpers() {
      return this.helpers;
    }
    getMaxLines() {
      return this.maxLines;
    }
    getDisplayWidthPx() {
      return this.displayWidthPx;
    }
  }

  // src/core/ChineseUtils.ts
  var jiebaInstance = null;
  var pinyinFn = null;
  function optionalRequire(id) {
    try {
      const req = globalThis.require;
      if (typeof req !== "function")
        return;
      return req(id);
    } catch {
      return;
    }
  }
  function getJieba() {
    if (jiebaInstance !== null)
      return jiebaInstance || null;
    try {
      const mod = optionalRequire("@node-rs/jieba");
      const dictMod = optionalRequire("@node-rs/jieba/dict");
      if (!mod || !dictMod) {
        jiebaInstance = false;
        return null;
      }
      jiebaInstance = mod.Jieba.withDict(dictMod.dict);
      return jiebaInstance;
    } catch {
      jiebaInstance = false;
      return null;
    }
  }
  function getPinyin() {
    if (pinyinFn !== null)
      return pinyinFn || null;
    try {
      const mod = optionalRequire("pinyin-pro");
      if (!mod) {
        pinyinFn = false;
        return null;
      }
      pinyinFn = mod.pinyin;
      return pinyinFn;
    } catch {
      pinyinFn = false;
      return null;
    }
  }
  function isChinese(text) {
    return /[一-龥]/.test(text);
  }
  function convertToPinyin(text) {
    if (!isChinese(text))
      return text;
    const jieba = getJieba();
    const pinyin = getPinyin();
    if (!jieba || !pinyin)
      return text;
    try {
      const parts = text.split(/([一-龥]+)/g);
      const processedParts = parts.map((part) => {
        if (!isChinese(part))
          return part;
        const words = jieba.cut(part);
        const pinyinWords = words.map((word) => {
          if (!isChinese(word))
            return word;
          return pinyin(word, {
            toneType: "symbol",
            type: "array",
            nonZh: "removed",
            mode: "normal"
          }).join("");
        });
        return pinyinWords.join(" ");
      });
      return processedParts.join("");
    } catch {
      return text;
    }
  }

  // src/shared/types.ts
  var CAPTION_TIMEOUT_OPTIONS_SECONDS = [3, 5, 10, 30, 40];
  var DEFAULT_CAPTION_TIMEOUT_SECONDS = 40;

  // src/background/controllers/CaptionsController.ts
  var DEFAULT_SETTINGS = {
    language: "auto",
    languageHints: [],
    useOfflineStt: false,
    displayLines: 3,
    displayWidth: 1,
    captionPosition: "top",
    wordBreaking: false,
    captionTimeoutSeconds: DEFAULT_CAPTION_TIMEOUT_SECONDS
  };
  var STORAGE_KEYS = {
    language: "language",
    languageHints: "languageHints",
    useOfflineStt: "useOfflineStt",
    displayLines: "displayLines",
    displayWidth: "displayWidth",
    captionPosition: "captionPosition",
    wordBreaking: "wordBreaking",
    captionTimeoutSeconds: "captionTimeoutSeconds"
  };
  var TRANSCRIPT_TIMING_TELEMETRY = globalThis.__DEV__ === true;
  function getProfileForModel(modelName) {
    if (!modelName)
      return G1_PROFILE;
    const lower = modelName.toLowerCase();
    if (lower.includes("g2") || lower.includes("even_g2")) {
      return G2_PROFILE;
    }
    if (lower.includes("g1") || lower.includes("even realities") || lower.includes("even_g1")) {
      return G1_PROFILE;
    }
    if (lower.includes("z100") || lower.includes("vuzix") || lower.includes("mach1") || lower.includes("mach 1")) {
      return Z100_PROFILE;
    }
    if (lower.includes("nex") || lower.includes("mentra display") || lower.includes("mentra_nex")) {
      return NEX_PROFILE;
    }
    return G1_PROFILE;
  }
  function getModelName(session) {
    try {
      const caps = session.capabilities;
      const m = caps?.modelName;
      return typeof m === "string" ? m : null;
    } catch {
      return null;
    }
  }
  function calculateCaptionBox({
    canvasWidth,
    canvasHeight,
    canPosition,
    position,
    lineCount,
    maxTextLines,
    lineHeightPx
  }) {
    const width = Number.isFinite(canvasWidth) && canvasWidth > 0 ? Math.floor(canvasWidth) : 576;
    const height = Number.isFinite(canvasHeight) && canvasHeight > 0 ? Math.floor(canvasHeight) : 288;
    if (!canPosition) {
      return { x: 0, y: 0, w: width, h: height };
    }
    const lines = Math.max(1, Math.floor(lineCount));
    const deviceMaxLines = maxTextLines !== undefined && Number.isFinite(maxTextLines) && maxTextLines > 0 ? Math.floor(maxTextLines) : lines;
    const inferredLineHeight = Math.max(1, Math.floor(height / deviceMaxLines));
    const lineHeight = lineHeightPx !== undefined && Number.isFinite(lineHeightPx) && lineHeightPx > 0 ? Math.floor(lineHeightPx) : inferredLineHeight;
    const bandHeight = Math.min(height, Math.max(lineHeight, lines * lineHeight));
    return {
      x: 0,
      y: position === "bottom" ? height - bandHeight : 0,
      w: width,
      h: bandHeight
    };
  }

  class CaptionsController {
    session;
    subscribed = false;
    unsubs = [];
    transcriptionCleanup = null;
    inactivityTimer = null;
    ui;
    settings = { ...DEFAULT_SETTINGS };
    transcripts = [];
    maxTranscripts = 100;
    formatter;
    currentProfile = G1_PROFILE;
    currentDisplayWidthPx = G1_PROFILE.displayWidthPx;
    currentMaxLines = G1_PROFILE.maxLines;
    currentWordBreaking = true;
    currentWidthSetting = 1;
    lastSpeakerId = undefined;
    lastDisplayPreview = null;
    cloudStatus = { status: "disconnected", audioTransport: "none" };
    constructor(session) {
      this.session = session;
    }
    async start() {
      if (this.subscribed)
        return;
      this.subscribed = true;
      this.ui = this.session.ui;
      this.currentProfile = getProfileForModel(getModelName(this.session));
      this.currentDisplayWidthPx = this.currentProfile.displayWidthPx;
      this.currentMaxLines = this.currentProfile.maxLines;
      this.createFormatter();
      try {
        this.unsubs.push(this.session.onCapabilitiesChange(() => {
          const newProfile = getProfileForModel(getModelName(this.session));
          if (newProfile.id !== this.currentProfile.id) {
            this.updateProfile(newProfile);
          } else {
            this.refreshDisplay();
          }
          this.broadcastDisplayCapabilities();
        }));
      } catch {}
      await this.loadSettings();
      this.applySettingsToDisplay();
      this.subscribeTranscription();
      this.subscribeCloudStatus();
      this.registerUiHandlers();
      console.log(`LocalCaptions: started (lang=${this.settings.language}, profile=${this.currentProfile.id})`);
    }
    stop() {
      if (this.transcriptionCleanup) {
        try {
          this.transcriptionCleanup();
        } catch {}
        this.transcriptionCleanup = null;
      }
      if (this.inactivityTimer) {
        clearTimeout(this.inactivityTimer);
        this.inactivityTimer = null;
      }
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.length = 0;
      this.subscribed = false;
    }
    registerUiHandlers() {
      this.unsubs.push(this.ui.onOpen(() => {
        this.sendSnapshot();
      }));
      this.unsubs.push(this.ui.on("captions:request-snapshot", () => {
        this.sendSnapshot();
      }));
      this.unsubs.push(this.ui.on("captions:set-language", ({ language }) => {
        this.setLanguage(language);
      }));
      this.unsubs.push(this.ui.on("captions:set-language-hints", ({ hints }) => {
        this.setLanguageHints(hints);
      }));
      this.unsubs.push(this.ui.on("captions:set-use-offline-stt", ({ enabled }) => {
        this.setUseOfflineStt(enabled);
      }));
      this.unsubs.push(this.ui.on("captions:set-display-lines", ({ lines }) => {
        this.setDisplayLines(lines);
      }));
      this.unsubs.push(this.ui.on("captions:set-display-width", ({ width }) => {
        this.setDisplayWidth(width);
      }));
      this.unsubs.push(this.ui.on("captions:set-caption-position", ({ position }) => {
        this.setCaptionPosition(position);
      }));
      this.unsubs.push(this.ui.on("captions:set-word-breaking", ({ enabled }) => {
        this.setWordBreaking(enabled);
      }));
      this.unsubs.push(this.ui.on("captions:set-caption-timeout", ({ seconds }) => {
        this.setCaptionTimeoutSeconds(seconds);
      }));
      this.unsubs.push(this.ui.on("captions:clear", () => {
        this.clearTranscripts();
      }));
    }
    sendSnapshot() {
      const snapshot = {
        settings: { ...this.settings },
        transcripts: this.publicTranscripts(),
        displayPreview: this.lastDisplayPreview,
        cloudStatus: { ...this.cloudStatus },
        displayCapabilities: this.getDisplayCapabilities()
      };
      this.ui.send("captions:snapshot", snapshot);
    }
    async loadSettings() {
      try {
        const [language, hintsRaw, useOfflineSttRaw, linesRaw, widthRaw, positionRaw, wbRaw, timeoutRaw] = await Promise.all([
          this.session.storage.get(STORAGE_KEYS.language),
          this.session.storage.get(STORAGE_KEYS.languageHints),
          this.session.storage.get(STORAGE_KEYS.useOfflineStt),
          this.session.storage.get(STORAGE_KEYS.displayLines),
          this.session.storage.get(STORAGE_KEYS.displayWidth),
          this.session.storage.get(STORAGE_KEYS.captionPosition),
          this.session.storage.get(STORAGE_KEYS.wordBreaking),
          this.session.storage.get(STORAGE_KEYS.captionTimeoutSeconds)
        ]);
        this.settings.language = language || "auto";
        this.settings.languageHints = (() => {
          if (!hintsRaw)
            return [];
          try {
            const parsed = JSON.parse(hintsRaw);
            return Array.isArray(parsed) ? parsed : [];
          } catch {
            return [];
          }
        })();
        this.settings.useOfflineStt = useOfflineSttRaw == null ? DEFAULT_SETTINGS.useOfflineStt : useOfflineSttRaw === "true";
        this.settings.displayLines = (() => {
          if (!linesRaw)
            return 3;
          const p = parseInt(linesRaw, 10);
          return isNaN(p) ? 3 : p;
        })();
        this.settings.displayWidth = (() => {
          if (!widthRaw)
            return 1;
          const p = parseInt(widthRaw, 10);
          if (isNaN(p) || p < 0 || p > 2)
            return 1;
          return p;
        })();
        this.settings.captionPosition = positionRaw === "bottom" ? "bottom" : "top";
        this.settings.wordBreaking = wbRaw == null ? DEFAULT_SETTINGS.wordBreaking : wbRaw === "true";
        this.settings.captionTimeoutSeconds = (() => {
          if (!timeoutRaw)
            return DEFAULT_CAPTION_TIMEOUT_SECONDS;
          const parsed = parseInt(timeoutRaw, 10);
          return isSupportedCaptionTimeoutSeconds(parsed) ? parsed : DEFAULT_CAPTION_TIMEOUT_SECONDS;
        })();
      } catch (err) {
        console.log("LocalCaptions: failed to load settings, using defaults", err);
        this.settings = { ...DEFAULT_SETTINGS };
      }
    }
    async setLanguage(language) {
      this.settings.language = language;
      await this.persist(STORAGE_KEYS.language, language);
      this.subscribeTranscription();
      this.broadcastSettings();
    }
    async setLanguageHints(hints) {
      this.settings.languageHints = hints;
      await this.persist(STORAGE_KEYS.languageHints, JSON.stringify(hints));
      this.subscribeTranscription();
      this.broadcastSettings();
    }
    async setUseOfflineStt(enabled) {
      this.settings.useOfflineStt = enabled;
      await this.persist(STORAGE_KEYS.useOfflineStt, enabled.toString());
      this.subscribeTranscription();
      this.broadcastSettings();
    }
    async setDisplayLines(lines) {
      if (lines < 2 || lines > 5)
        return;
      this.settings.displayLines = lines;
      await this.persist(STORAGE_KEYS.displayLines, lines.toString());
      this.applySettingsToDisplay();
      this.broadcastSettings();
    }
    async setDisplayWidth(width) {
      if (width < 0 || width > 2)
        return;
      this.settings.displayWidth = width;
      await this.persist(STORAGE_KEYS.displayWidth, width.toString());
      this.applySettingsToDisplay();
      this.broadcastSettings();
    }
    async setCaptionPosition(position) {
      if (position !== "top" && position !== "bottom")
        return;
      this.settings.captionPosition = position;
      await this.persist(STORAGE_KEYS.captionPosition, position);
      this.refreshDisplay();
      this.broadcastSettings();
    }
    async setWordBreaking(enabled) {
      this.settings.wordBreaking = enabled;
      await this.persist(STORAGE_KEYS.wordBreaking, enabled.toString());
      this.applySettingsToDisplay();
      this.broadcastSettings();
    }
    async setCaptionTimeoutSeconds(seconds) {
      if (!isSupportedCaptionTimeoutSeconds(seconds))
        return;
      this.settings.captionTimeoutSeconds = seconds;
      await this.persist(STORAGE_KEYS.captionTimeoutSeconds, seconds.toString());
      if (this.inactivityTimer !== null) {
        this.resetInactivityTimer();
      }
      this.broadcastSettings();
    }
    async persist(key, value) {
      try {
        await this.session.storage.set(key, value);
      } catch (err) {
        console.log(`LocalCaptions: failed to persist ${key}`, err);
      }
    }
    broadcastSettings() {
      this.ui.send("captions:settings-update", { ...this.settings });
    }
    getDisplayCapabilities() {
      return { canPosition: this.session.capabilities?.display?.canPosition === true };
    }
    broadcastDisplayCapabilities() {
      this.ui.send("captions:display-capabilities", this.getDisplayCapabilities());
    }
    subscribeTranscription() {
      if (this.transcriptionCleanup) {
        try {
          this.transcriptionCleanup();
        } catch {}
        this.transcriptionCleanup = null;
      }
      const language = this.settings.language;
      const hints = this.settings.languageHints;
      const options = this.settings.useOfflineStt ? { forceLocal: true } : {};
      try {
        if (hints.length > 0) {
          this.session.transcription.configure({ languageHints: hints }).catch((err) => console.error("LocalCaptions: language hints not applied", err));
        }
        const handler = (data) => {
          this.handleTranscription(data);
        };
        if (language === "auto") {
          this.transcriptionCleanup = this.session.transcription.on(handler, options);
        } else {
          this.transcriptionCleanup = this.session.transcription.forLanguage(language, handler, options);
        }
      } catch (err) {
        console.error("LocalCaptions: transcription subscribe failed, falling back to auto", err);
        this.transcriptionCleanup = this.session.transcription.on((data) => {
          this.handleTranscription(data);
        }, options);
      }
    }
    subscribeCloudStatus() {
      try {
        this.unsubs.push(this.session.cloud.onStatusChanged((status) => {
          this.cloudStatus = { ...status };
          this.ui.send("captions:cloud-status", { ...this.cloudStatus });
        }));
      } catch (err) {
        console.log("LocalCaptions: cloud status subscribe failed", err);
      }
    }
    async handleTranscription(data) {
      const controllerReceivedAt = Date.now();
      const hostReceivedAt = data.__hostReceivedAt;
      if (TRANSCRIPT_TIMING_TELEMETRY) {
        console.log(`LocalCaptions: transcript bg_recv t=${controllerReceivedAt} final=${data.isFinal} hostDelta=${hostReceivedAt ? controllerReceivedAt - hostReceivedAt : -1}ms text="${data.text.slice(0, 48)}"`);
      }
      const utteranceId = data.utteranceId ?? null;
      const speakerId = data.speakerId;
      const entry = this.createEntry(data, utteranceId, speakerId);
      if (utteranceId) {
        this.updateByUtteranceId(entry);
      } else {
        if (data.isFinal) {
          this.legacyReplaceInterim(entry);
        } else {
          this.legacyUpdateInterim(entry);
        }
      }
      if (TRANSCRIPT_TIMING_TELEMETRY) {
        const now = Date.now();
        console.log(`LocalCaptions: transcript ui_send t=${now} final=${entry.isFinal} bgDelta=${now - controllerReceivedAt}ms text="${entry.text.slice(0, 48)}"`);
      }
      this.ui.send("captions:live-transcript", {
        type: entry.isFinal ? "final" : "interim",
        id: entry.id,
        utteranceId: entry.utteranceId,
        speaker: entry.speaker,
        text: entry.text,
        timestamp: entry.timestamp
      });
      let displayText = data.text;
      if (this.settings.language === "Chinese (Pinyin)") {
        displayText = convertToPinyin(displayText);
      }
      this.processAndDisplay(displayText, data.isFinal, speakerId);
    }
    createEntry(data, utteranceId, speakerId) {
      const id = utteranceId || this.randomId();
      return {
        id,
        utteranceId,
        speaker: this.formatSpeakerId(speakerId),
        text: data.text,
        timestamp: data.isFinal ? Date.now() : null,
        isFinal: data.isFinal,
        receivedAt: Date.now()
      };
    }
    formatSpeakerId(speakerId) {
      if (!speakerId)
        return "Speaker 1";
      return `Speaker ${speakerId}`;
    }
    updateByUtteranceId(entry) {
      const existingIndex = this.transcripts.findIndex((t) => t.utteranceId === entry.utteranceId);
      if (existingIndex >= 0) {
        this.transcripts[existingIndex] = entry;
      } else {
        this.transcripts.push(entry);
      }
      if (this.transcripts.length > this.maxTranscripts) {
        const finals = this.transcripts.filter((t) => t.isFinal);
        const interims = this.transcripts.filter((t) => !t.isFinal);
        const maxFinals = this.maxTranscripts - interims.length;
        const trimmedFinals = finals.slice(-maxFinals);
        this.transcripts = [...trimmedFinals, ...interims];
      }
    }
    legacyUpdateInterim(entry) {
      this.transcripts = this.transcripts.filter((t) => t.isFinal);
      this.transcripts.push(entry);
    }
    legacyReplaceInterim(entry) {
      this.transcripts = this.transcripts.filter((t) => t.isFinal);
      this.transcripts.push(entry);
      if (this.transcripts.length > this.maxTranscripts) {
        this.transcripts = this.transcripts.slice(-this.maxTranscripts);
      }
    }
    clearTranscripts() {
      this.transcripts = [];
      this.ui.send("captions:transcripts-update", { transcripts: [] });
    }
    publicTranscripts() {
      return this.transcripts.map((t) => ({
        id: t.id,
        utteranceId: t.utteranceId,
        speaker: t.speaker,
        text: t.text,
        timestamp: t.timestamp,
        isFinal: t.isFinal
      }));
    }
    randomId() {
      try {
        const c = globalThis.crypto;
        if (c && typeof c.randomUUID === "function")
          return c.randomUUID();
      } catch {}
      return `tx-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
    }
    createFormatter() {
      this.formatter = new CaptionsFormatter(this.currentProfile, {
        maxFinalTranscripts: 30,
        breakMode: this.currentWordBreaking ? "character" : "word",
        displayWidthPx: this.currentDisplayWidthPx,
        maxLines: this.currentMaxLines
      });
    }
    calculateDisplayWidth(widthSetting, profile) {
      const maxWidthPx = profile.displayWidthPx;
      let widthPercent;
      switch (widthSetting) {
        case 0:
          widthPercent = 0.7;
          break;
        case 1:
          widthPercent = 0.85;
          break;
        case 2:
        default:
          widthPercent = 1;
          break;
      }
      return Math.round(maxWidthPx * widthPercent);
    }
    applySettingsToDisplay() {
      this.updateDisplaySettings(this.settings.displayWidth, this.settings.displayLines, this.settings.wordBreaking);
    }
    updateDisplaySettings(displayWidth, numberOfLines, wordBreaking) {
      this.currentWidthSetting = displayWidth;
      this.currentDisplayWidthPx = this.calculateDisplayWidth(displayWidth, this.currentProfile);
      this.currentMaxLines = Math.min(Math.max(2, numberOfLines), this.currentProfile.maxLines);
      this.currentWordBreaking = wordBreaking;
      const previousHistory = this.formatter.getFinalTranscriptHistory();
      this.createFormatter();
      this.restoreHistory(previousHistory);
      this.refreshDisplay();
    }
    updateProfile(newProfile) {
      const previousHistory = this.formatter.getFinalTranscriptHistory();
      this.currentProfile = newProfile;
      this.currentDisplayWidthPx = this.calculateDisplayWidth(this.currentWidthSetting, newProfile);
      this.currentMaxLines = Math.min(this.currentMaxLines, newProfile.maxLines);
      this.createFormatter();
      this.restoreHistory(previousHistory);
      this.refreshDisplay();
    }
    restoreHistory(previousHistory) {
      for (const e of previousHistory) {
        this.formatter.processTranscription(e.text, true, e.speakerId, e.hadSpeakerChange);
      }
    }
    refreshDisplay() {
      const history = this.formatter.getFinalTranscriptHistory();
      if (history.length === 0) {
        this.broadcastDisplayPreview("", [""], true);
        return;
      }
      const result = this.formatter.processTranscription("", true, undefined, false);
      if (result.displayText.trim()) {
        const cleaned = this.cleanTranscriptText(result.displayText);
        const lines = cleaned.split(`
`);
        this.showTextWall(cleaned);
        this.broadcastDisplayPreview(cleaned, lines, true);
      }
    }
    processAndDisplay(text, isFinal, speakerId) {
      const speakerChanged = speakerId !== undefined && speakerId !== this.lastSpeakerId;
      if (speakerChanged) {
        this.lastSpeakerId = speakerId;
      }
      const result = this.formatter.processTranscription(text, isFinal, speakerId, speakerChanged);
      this.showOnGlasses(result.displayText, isFinal);
      this.resetInactivityTimer();
    }
    showOnGlasses(text, isFinal) {
      const cleaned = this.cleanTranscriptText(text);
      const lines = cleaned.split(`
`);
      this.showTextWall(cleaned);
      this.broadcastDisplayPreview(cleaned, lines, isFinal);
    }
    showTextWall(text) {
      const d = this.session.capabilities?.display;
      const maxTextLines = typeof d?.maxTextLines === "number" ? d.maxTextLines : undefined;
      const box = calculateCaptionBox({
        canvasWidth: d?.width ?? 576,
        canvasHeight: d?.height ?? 288,
        canPosition: d?.canPosition === true,
        position: this.settings.captionPosition,
        lineCount: this.currentMaxLines,
        maxTextLines,
        lineHeightPx: this.currentProfile.lineHeightPx
      });
      this.session.display.render([{ type: "text", id: "caption", box, text }]);
    }
    cleanTranscriptText(text) {
      return text.split(`
`).map((line) => {
        const speakerLabelMatch = line.match(/^\[\d+\]:\s*/);
        if (speakerLabelMatch) {
          const label = speakerLabelMatch[0];
          const rest = line.substring(label.length);
          return label + rest.replace(/^[.,;:!?。，；：！？]+/, "").trim();
        }
        return line.replace(/^[.,;:!?。，；：！？]+/, "").trim();
      }).join(`
`);
    }
    resetInactivityTimer() {
      if (this.inactivityTimer) {
        clearTimeout(this.inactivityTimer);
      }
      this.inactivityTimer = setTimeout(() => {
        this.inactivityTimer = null;
        this.formatter.clear();
        this.lastSpeakerId = undefined;
        this.session.display.render([]);
      }, this.settings.captionTimeoutSeconds * 1000);
    }
    broadcastDisplayPreview(text, lines, isFinal) {
      const preview = { text, lines, isFinal, timestamp: Date.now() };
      this.lastDisplayPreview = preview;
      this.ui.send("captions:display-preview", preview);
    }
  }
  function isSupportedCaptionTimeoutSeconds(seconds) {
    return CAPTION_TIMEOUT_OPTIONS_SECONDS.some((option) => option === seconds);
  }

  // src/background/index.ts
  registerMiniapp((session) => {
    new CaptionsController(session).start();
  });
})();
