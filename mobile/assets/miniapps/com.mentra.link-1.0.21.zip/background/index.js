(() => {
  var __create = Object.create;
  var __getProtoOf = Object.getPrototypeOf;
  var __defProp = Object.defineProperty;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  function __accessProp(key) {
    return this[key];
  }
  var __toESMCache_node;
  var __toESMCache_esm;
  var __toESM = (mod, isNodeMode, target) => {
    var canCache = mod != null && typeof mod === "object";
    if (canCache) {
      var cache = isNodeMode ? __toESMCache_node ??= new WeakMap : __toESMCache_esm ??= new WeakMap;
      var cached = cache.get(mod);
      if (cached)
        return cached;
    }
    target = mod != null ? __create(__getProtoOf(mod)) : {};
    const to = isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target;
    for (let key of __getOwnPropNames(mod))
      if (!__hasOwnProp.call(to, key))
        __defProp(to, key, {
          get: __accessProp.bind(mod, key),
          enumerable: true
        });
    if (canCache)
      cache.set(mod, to);
    return to;
  };
  var __commonJS = (cb, mod) => () => (mod || cb((mod = { exports: {} }).exports, mod), mod.exports);
  var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
    get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
  }) : x)(function(x) {
    if (typeof require !== "undefined")
      return require.apply(this, arguments);
    throw Error('Dynamic require of "' + x + '" is not supported');
  });

  // ../node_modules/.bun/eventemitter3@5.0.4/node_modules/eventemitter3/index.js
  var require_eventemitter3 = __commonJS((exports, module) => {
    var has = Object.prototype.hasOwnProperty;
    var prefix = "~";
    function Events() {}
    if (Object.create) {
      Events.prototype = Object.create(null);
      if (!new Events().__proto__)
        prefix = false;
    }
    function EE(fn, context, once) {
      this.fn = fn;
      this.context = context;
      this.once = once || false;
    }
    function addListener(emitter, event, fn, context, once) {
      if (typeof fn !== "function") {
        throw new TypeError("The listener must be a function");
      }
      var listener = new EE(fn, context || emitter, once), evt = prefix ? prefix + event : event;
      if (!emitter._events[evt])
        emitter._events[evt] = listener, emitter._eventsCount++;
      else if (!emitter._events[evt].fn)
        emitter._events[evt].push(listener);
      else
        emitter._events[evt] = [emitter._events[evt], listener];
      return emitter;
    }
    function clearEvent(emitter, evt) {
      if (--emitter._eventsCount === 0)
        emitter._events = new Events;
      else
        delete emitter._events[evt];
    }
    function EventEmitter() {
      this._events = new Events;
      this._eventsCount = 0;
    }
    EventEmitter.prototype.eventNames = function eventNames() {
      var names = [], events, name;
      if (this._eventsCount === 0)
        return names;
      for (name in events = this._events) {
        if (has.call(events, name))
          names.push(prefix ? name.slice(1) : name);
      }
      if (Object.getOwnPropertySymbols) {
        return names.concat(Object.getOwnPropertySymbols(events));
      }
      return names;
    };
    EventEmitter.prototype.listeners = function listeners(event) {
      var evt = prefix ? prefix + event : event, handlers = this._events[evt];
      if (!handlers)
        return [];
      if (handlers.fn)
        return [handlers.fn];
      for (var i = 0, l = handlers.length, ee = new Array(l);i < l; i++) {
        ee[i] = handlers[i].fn;
      }
      return ee;
    };
    EventEmitter.prototype.listenerCount = function listenerCount(event) {
      var evt = prefix ? prefix + event : event, listeners = this._events[evt];
      if (!listeners)
        return 0;
      if (listeners.fn)
        return 1;
      return listeners.length;
    };
    EventEmitter.prototype.emit = function emit(event, a1, a2, a3, a4, a5) {
      var evt = prefix ? prefix + event : event;
      if (!this._events[evt])
        return false;
      var listeners = this._events[evt], len = arguments.length, args, i;
      if (listeners.fn) {
        if (listeners.once)
          this.removeListener(event, listeners.fn, undefined, true);
        switch (len) {
          case 1:
            return listeners.fn.call(listeners.context), true;
          case 2:
            return listeners.fn.call(listeners.context, a1), true;
          case 3:
            return listeners.fn.call(listeners.context, a1, a2), true;
          case 4:
            return listeners.fn.call(listeners.context, a1, a2, a3), true;
          case 5:
            return listeners.fn.call(listeners.context, a1, a2, a3, a4), true;
          case 6:
            return listeners.fn.call(listeners.context, a1, a2, a3, a4, a5), true;
        }
        for (i = 1, args = new Array(len - 1);i < len; i++) {
          args[i - 1] = arguments[i];
        }
        listeners.fn.apply(listeners.context, args);
      } else {
        var length = listeners.length, j;
        for (i = 0;i < length; i++) {
          if (listeners[i].once)
            this.removeListener(event, listeners[i].fn, undefined, true);
          switch (len) {
            case 1:
              listeners[i].fn.call(listeners[i].context);
              break;
            case 2:
              listeners[i].fn.call(listeners[i].context, a1);
              break;
            case 3:
              listeners[i].fn.call(listeners[i].context, a1, a2);
              break;
            case 4:
              listeners[i].fn.call(listeners[i].context, a1, a2, a3);
              break;
            default:
              if (!args)
                for (j = 1, args = new Array(len - 1);j < len; j++) {
                  args[j - 1] = arguments[j];
                }
              listeners[i].fn.apply(listeners[i].context, args);
          }
        }
      }
      return true;
    };
    EventEmitter.prototype.on = function on(event, fn, context) {
      return addListener(this, event, fn, context, false);
    };
    EventEmitter.prototype.once = function once(event, fn, context) {
      return addListener(this, event, fn, context, true);
    };
    EventEmitter.prototype.removeListener = function removeListener(event, fn, context, once) {
      var evt = prefix ? prefix + event : event;
      if (!this._events[evt])
        return this;
      if (!fn) {
        clearEvent(this, evt);
        return this;
      }
      var listeners = this._events[evt];
      if (listeners.fn) {
        if (listeners.fn === fn && (!once || listeners.once) && (!context || listeners.context === context)) {
          clearEvent(this, evt);
        }
      } else {
        for (var i = 0, events = [], length = listeners.length;i < length; i++) {
          if (listeners[i].fn !== fn || once && !listeners[i].once || context && listeners[i].context !== context) {
            events.push(listeners[i]);
          }
        }
        if (events.length)
          this._events[evt] = events.length === 1 ? events[0] : events;
        else
          clearEvent(this, evt);
      }
      return this;
    };
    EventEmitter.prototype.removeAllListeners = function removeAllListeners(event) {
      var evt;
      if (event) {
        evt = prefix ? prefix + event : event;
        if (this._events[evt])
          clearEvent(this, evt);
      } else {
        this._events = new Events;
        this._eventsCount = 0;
      }
      return this;
    };
    EventEmitter.prototype.off = EventEmitter.prototype.removeListener;
    EventEmitter.prototype.addListener = EventEmitter.prototype.on;
    EventEmitter.prefixed = prefix;
    EventEmitter.EventEmitter = EventEmitter;
    if (typeof module !== "undefined") {
      module.exports = EventEmitter;
    }
  });
  // ../node_modules/.bun/eventemitter3@5.0.4/node_modules/eventemitter3/index.mjs
  var import__ = __toESM(require_eventemitter3(), 1);

  // ../vendor/miniapp/dist/envelope.js
  function serializeEnvelope(envelope) {
    return JSON.stringify(envelope);
  }
  function parseEnvelope(raw) {
    if (typeof raw !== "string")
      return null;
    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch {
      return null;
    }
    if (typeof parsed !== "object" || parsed === null)
      return null;
    const obj = parsed;
    if (typeof obj.payload !== "object" || obj.payload === null)
      return null;
    if (obj.requestId !== undefined && typeof obj.requestId !== "string")
      return null;
    return {
      payload: obj.payload,
      requestId: obj.requestId
    };
  }
  function makeRequestId() {
    if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
      return crypto.randomUUID();
    }
    return `req_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
  }

  // ../vendor/miniapp/dist/globals.js
  function getMentraOSGlobals() {
    if (typeof window === "undefined")
      return {};
    return window.MentraOS ?? {};
  }

  // ../vendor/miniapp/dist/protocol.js
  var MiniappRequestType;
  (function(MiniappRequestType2) {
    MiniappRequestType2["CONNECT"] = "miniapp_connect";
    MiniappRequestType2["AUTH_REFRESH"] = "miniapp_auth_refresh";
    MiniappRequestType2["SUBSCRIBE"] = "miniapp_subscribe";
    MiniappRequestType2["DISPLAY"] = "miniapp_display";
    MiniappRequestType2["CANVAS"] = "miniapp_canvas";
    MiniappRequestType2["PLAY_AUDIO"] = "miniapp_play_audio";
    MiniappRequestType2["STOP_AUDIO"] = "miniapp_stop_audio";
    MiniappRequestType2["SPEAK"] = "miniapp_speak";
    MiniappRequestType2["RGB_LED"] = "miniapp_rgb_led";
    MiniappRequestType2["LOCATION_POLL"] = "miniapp_location_poll";
    MiniappRequestType2["NAVIGATION_START"] = "miniapp_navigation_start";
    MiniappRequestType2["NAVIGATION_STOP"] = "miniapp_navigation_stop";
    MiniappRequestType2["NAVIGATION_DEVIATE"] = "miniapp_navigation_deviate";
    MiniappRequestType2["NAVIGATION_SET_WRONG_SIDEWALK"] = "miniapp_navigation_set_wrong_sidewalk";
    MiniappRequestType2["NAVIGATION_SET_SKIP_CROSSINGS"] = "miniapp_navigation_set_skip_crossings";
    MiniappRequestType2["NAVIGATION_GET_STATE"] = "miniapp_navigation_get_state";
    MiniappRequestType2["NAVIGATION_COMPUTE_ROUTE"] = "miniapp_navigation_compute_route";
    MiniappRequestType2["NAVIGATION_REVERSE_GEOCODE"] = "miniapp_navigation_reverse_geocode";
    MiniappRequestType2["NAVIGATION_PLACE_AUTOCOMPLETE"] = "miniapp_navigation_place_autocomplete";
    MiniappRequestType2["NAVIGATION_PLACE_DETAILS"] = "miniapp_navigation_place_details";
    MiniappRequestType2["NAVIGATION_REQUEST_PERMISSION"] = "miniapp_navigation_request_permission";
    MiniappRequestType2["STORAGE_GET"] = "miniapp_storage_get";
    MiniappRequestType2["STORAGE_SET"] = "miniapp_storage_set";
    MiniappRequestType2["STORAGE_DELETE"] = "miniapp_storage_delete";
    MiniappRequestType2["STORAGE_LIST"] = "miniapp_storage_list";
    MiniappRequestType2["STORAGE_CLEAR"] = "miniapp_storage_clear";
    MiniappRequestType2["STORAGE_HAS"] = "miniapp_storage_has";
    MiniappRequestType2["STORAGE_GET_ALL"] = "miniapp_storage_get_all";
    MiniappRequestType2["STORAGE_SET_MULTIPLE"] = "miniapp_storage_set_multiple";
    MiniappRequestType2["STORAGE_FLUSH"] = "miniapp_storage_flush";
    MiniappRequestType2["CAMERA_FOV"] = "miniapp_camera_fov";
    MiniappRequestType2["IMU_SET_ENABLED"] = "miniapp_imu_set_enabled";
    MiniappRequestType2["SHARE"] = "miniapp_share";
    MiniappRequestType2["OPEN_URL"] = "miniapp_open_url";
    MiniappRequestType2["COPY_CLIPBOARD"] = "miniapp_copy_clipboard";
    MiniappRequestType2["DOWNLOAD"] = "miniapp_download";
    MiniappRequestType2["BLOB_CREATE"] = "miniapp_blob_create";
    MiniappRequestType2["BLOB_WRITE"] = "miniapp_blob_write";
    MiniappRequestType2["BLOB_COMMIT"] = "miniapp_blob_commit";
    MiniappRequestType2["BLOB_ABORT"] = "miniapp_blob_abort";
    MiniappRequestType2["BLOB_GET"] = "miniapp_blob_get";
    MiniappRequestType2["BLOB_LIST"] = "miniapp_blob_list";
    MiniappRequestType2["BLOB_DELETE"] = "miniapp_blob_delete";
    MiniappRequestType2["BLOB_CLEAR"] = "miniapp_blob_clear";
    MiniappRequestType2["BLOB_USAGE"] = "miniapp_blob_usage";
    MiniappRequestType2["BLOB_OPEN_READ"] = "miniapp_blob_open_read";
    MiniappRequestType2["BLOB_READ"] = "miniapp_blob_read";
    MiniappRequestType2["BLOB_CLOSE_READ"] = "miniapp_blob_close_read";
    MiniappRequestType2["BLOB_SET_FROM_URL"] = "miniapp_blob_set_from_url";
    MiniappRequestType2["BLOB_IMPORT"] = "miniapp_blob_import";
    MiniappRequestType2["BLOB_SHARE"] = "miniapp_blob_share";
    MiniappRequestType2["PING"] = "miniapp_ping";
    MiniappRequestType2["TRANSCRIPTION_CONFIG"] = "miniapp_transcription_config";
    MiniappRequestType2["DASHBOARD_CONTENT_UPDATE"] = "miniapp_dashboard_content_update";
    MiniappRequestType2["PHOTO"] = "miniapp_photo";
    MiniappRequestType2["VIDEO_RECORDING_START"] = "miniapp_video_recording_start";
    MiniappRequestType2["VIDEO_RECORDING_STOP"] = "miniapp_video_recording_stop";
    MiniappRequestType2["STREAM_START"] = "miniapp_stream_start";
    MiniappRequestType2["STREAM_STOP"] = "miniapp_stream_stop";
    MiniappRequestType2["MANAGED_STREAM_START"] = "miniapp_managed_stream_start";
    MiniappRequestType2["MANAGED_STREAM_STOP"] = "miniapp_managed_stream_stop";
    MiniappRequestType2["REQUEST_WIFI_SETUP"] = "miniapp_request_wifi_setup";
    MiniappRequestType2["MINIAPPS_LIST"] = "miniapp_apps_list";
    MiniappRequestType2["MINIAPPS_START"] = "miniapp_apps_start";
    MiniappRequestType2["MINIAPPS_STOP"] = "miniapp_apps_stop";
    MiniappRequestType2["ACTION_INVOKE"] = "miniapp_action_invoke";
    MiniappRequestType2["ACTION_RESULT"] = "miniapp_action_result";
  })(MiniappRequestType || (MiniappRequestType = {}));
  var MiniappResponseType;
  (function(MiniappResponseType2) {
    MiniappResponseType2["CONNECT_ACK"] = "miniapp_connect_ack";
    MiniappResponseType2["EVENT"] = "miniapp_event";
    MiniappResponseType2["REQUEST_RESULT"] = "miniapp_request_result";
    MiniappResponseType2["CAPABILITIES_UPDATE"] = "miniapp_capabilities_update";
    MiniappResponseType2["VISIBILITY_CHANGE"] = "miniapp_visibility_change";
    MiniappResponseType2["COLOR_SCHEME_CHANGE"] = "miniapp_color_scheme_change";
    MiniappResponseType2["SPEAKER_STATE"] = "miniapp_speaker_state";
    MiniappResponseType2["PERMISSIONS_UPDATE"] = "miniapp_permissions_update";
    MiniappResponseType2["AUTH_UPDATE"] = "miniapp_auth_update";
    MiniappResponseType2["PONG"] = "miniapp_pong";
    MiniappResponseType2["ACTION_CALL"] = "miniapp_action_call";
    MiniappResponseType2["WILL_DISCONNECT"] = "miniapp_will_disconnect";
    MiniappResponseType2["ERROR"] = "miniapp_error";
  })(MiniappResponseType || (MiniappResponseType = {}));
  var MiniappStreamType;
  (function(MiniappStreamType2) {
    MiniappStreamType2["BUTTON_PRESS"] = "button_press";
    MiniappStreamType2["TOUCH_EVENT"] = "touch_event";
    MiniappStreamType2["HEAD_POSITION"] = "head_position";
    MiniappStreamType2["ACCEL_DATA"] = "accel_data";
    MiniappStreamType2["GLASSES_BATTERY"] = "glasses_battery";
    MiniappStreamType2["PHONE_BATTERY"] = "phone_battery";
    MiniappStreamType2["GLASSES_CONNECTION"] = "glasses_connection";
    MiniappStreamType2["GLASSES_WIFI"] = "glasses_wifi";
    MiniappStreamType2["TRANSCRIPTION"] = "transcription";
    MiniappStreamType2["TRANSLATION"] = "translation";
    MiniappStreamType2["AUDIO_CHUNK"] = "audio_chunk";
    MiniappStreamType2["VAD"] = "vad";
    MiniappStreamType2["LOCATION_UPDATE"] = "location_update";
    MiniappStreamType2["HEADING_UPDATE"] = "heading_update";
    MiniappStreamType2["NAVIGATION_UPDATE"] = "navigation_update";
    MiniappStreamType2["NAVIGATION_ROUTE"] = "navigation_route";
    MiniappStreamType2["PHONE_NOTIFICATION"] = "phone_notification";
    MiniappStreamType2["PHONE_NOTIFICATION_DISMISSED"] = "phone_notification_dismissed";
    MiniappStreamType2["CALENDAR_EVENT"] = "calendar_event";
    MiniappStreamType2["PHOTO_TAKEN"] = "photo_taken";
    MiniappStreamType2["STREAM_STATUS"] = "stream_status";
  })(MiniappStreamType || (MiniappStreamType = {}));
  var MiniappErrorCode;
  (function(MiniappErrorCode2) {
    MiniappErrorCode2["PERMISSION_NOT_DECLARED"] = "PERMISSION_NOT_DECLARED";
    MiniappErrorCode2["NOT_IMPLEMENTED"] = "NOT_IMPLEMENTED";
    MiniappErrorCode2["REQUEST_ABORTED"] = "REQUEST_ABORTED";
    MiniappErrorCode2["INTERNAL"] = "INTERNAL";
    MiniappErrorCode2["TTS_TEXT_TOO_LONG"] = "TTS_TEXT_TOO_LONG";
    MiniappErrorCode2["TTS_INVALID_VOICE"] = "TTS_INVALID_VOICE";
    MiniappErrorCode2["TTS_UPSTREAM_ERROR"] = "TTS_UPSTREAM_ERROR";
    MiniappErrorCode2["NOT_CONNECTED"] = "NOT_CONNECTED";
    MiniappErrorCode2["NOT_PERMITTED"] = "NOT_PERMITTED";
    MiniappErrorCode2["APP_NOT_FOUND"] = "APP_NOT_FOUND";
    MiniappErrorCode2["APP_NOT_COMPATIBLE"] = "APP_NOT_COMPATIBLE";
    MiniappErrorCode2["ACTION_NOT_FOUND"] = "ACTION_NOT_FOUND";
    MiniappErrorCode2["NO_ACTION_HANDLER"] = "NO_ACTION_HANDLER";
    MiniappErrorCode2["WAKE_FAILED"] = "WAKE_FAILED";
    MiniappErrorCode2["ACTION_TIMEOUT"] = "ACTION_TIMEOUT";
    MiniappErrorCode2["PAYLOAD_TOO_LARGE"] = "PAYLOAD_TOO_LARGE";
    MiniappErrorCode2["BLOB_NOT_FOUND"] = "BLOB_NOT_FOUND";
    MiniappErrorCode2["BLOB_QUOTA_EXCEEDED"] = "BLOB_QUOTA_EXCEEDED";
    MiniappErrorCode2["BLOB_TOO_LARGE"] = "BLOB_TOO_LARGE";
    MiniappErrorCode2["BLOB_HANDLE_INVALID"] = "BLOB_HANDLE_INVALID";
    MiniappErrorCode2["BLOB_WRITE_FAILED"] = "BLOB_WRITE_FAILED";
    MiniappErrorCode2["BLOB_DOWNLOAD_FAILED"] = "BLOB_DOWNLOAD_FAILED";
    MiniappErrorCode2["BLOB_IMPORT_FAILED"] = "BLOB_IMPORT_FAILED";
  })(MiniappErrorCode || (MiniappErrorCode = {}));

  // ../vendor/miniapp/dist/transport/dispatch.js
  class DispatchTransport {
    constructor() {
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.open_ = false;
    }
    static isAvailable() {
      return typeof globalThis.__dispatch === "function";
    }
    async open() {
      if (!DispatchTransport.isAvailable()) {
        throw new Error("DispatchTransport: __dispatch is not installed on globalThis");
      }
      const g = globalThis;
      g.__mentraDeliverBridgeRaw = (raw) => {
        if (this.messageHandler)
          this.messageHandler(raw);
      };
      this.open_ = true;
    }
    send(raw) {
      if (!this.open_) {
        throw new Error("DispatchTransport: send() before open()");
      }
      const g = globalThis;
      if (typeof g.__dispatch !== "function") {
        this.open_ = false;
        this.disconnectHandler?.("DispatchTransport: __dispatch disappeared");
        return;
      }
      try {
        g.__dispatch("__bridge", "send", JSON.stringify([raw]));
      } catch (e) {
        this.disconnectHandler?.(`DispatchTransport: __dispatch threw: ${String(e)}`);
      }
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      this.open_ = false;
      const g = globalThis;
      if (g.__mentraDeliverBridgeRaw) {
        delete g.__mentraDeliverBridgeRaw;
      }
    }
    isOpen() {
      return this.open_;
    }
  }

  // ../vendor/miniapp/dist/transport/local-socket.js
  var DEFAULT_URL = "ws://127.0.0.1:8765";

  class LocalSocketTransport {
    constructor(options = {}) {
      this.ws = null;
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.url = options.url ?? DEFAULT_URL;
    }
    async open() {
      if (this.ws && this.ws.readyState === WebSocket.OPEN)
        return;
      if (typeof WebSocket === "undefined") {
        throw new Error("LocalSocketTransport: browser WebSocket global not available");
      }
      await new Promise((resolve, reject) => {
        const ws = new WebSocket(this.url);
        let settled = false;
        const settle = (fn) => {
          if (settled)
            return;
          settled = true;
          fn();
        };
        ws.onopen = () => {
          this.ws = ws;
          settle(() => resolve());
        };
        ws.onerror = (ev) => {
          settle(() => reject(new Error(`LocalSocketTransport: failed to connect to ${this.url}: ${String(ev)}`)));
        };
        ws.onmessage = (ev) => {
          const data = ev.data;
          if (typeof data === "string")
            this.messageHandler?.(data);
        };
        ws.onclose = (ev) => {
          if (this.ws === ws)
            this.ws = null;
          this.disconnectHandler?.(`closed: ${ev.code} ${ev.reason}`);
        };
      });
    }
    send(raw) {
      if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
        throw new Error("LocalSocketTransport: not connected");
      }
      this.ws.send(raw);
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      if (!this.ws)
        return;
      try {
        this.ws.close();
      } catch {}
      this.ws = null;
    }
    isOpen() {
      return !!this.ws && this.ws.readyState === WebSocket.OPEN;
    }
  }

  // ../vendor/miniapp/dist/transport/mock.js
  var LOG_PREFIX = "[mock-transport]";
  function isMockExplicitlyRequested() {
    if (typeof window === "undefined")
      return false;
    try {
      if (typeof window.location !== "undefined" && window.location.search) {
        const params = new URLSearchParams(window.location.search);
        if (params.get("mentra") === "mock")
          return true;
      }
    } catch {}
    try {
      if (typeof localStorage !== "undefined" && localStorage.getItem("MENTRA_MOCK") === "1") {
        return true;
      }
    } catch {}
    return false;
  }

  class MockTransport {
    constructor(options = {}) {
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.open_ = false;
      this.userId = options.userId ?? "mock-user";
      this.authToken = options.authToken ?? "mock-miniapp-token";
      this.packageName = options.packageName ?? null;
      this.silent = options.silent === true;
    }
    async open() {
      if (this.open_)
        return;
      this.open_ = true;
      this.log("transport opened (no real host; synthetic responses only)");
    }
    send(raw) {
      if (!this.open_) {
        throw new Error("MockTransport: send() before open()");
      }
      const envelope = parseEnvelope(raw);
      if (!envelope) {
        this.log("dropped unparseable envelope:", raw.slice(0, 200));
        return;
      }
      const payload = envelope.payload;
      const type = payload?.type;
      this.log(`recv ${type ?? "<unknown>"}${envelope.requestId ? ` (rid=${envelope.requestId})` : ""}`);
      switch (type) {
        case MiniappRequestType.CONNECT:
          this.deliverConnectAck(payload);
          return;
        case MiniappRequestType.PING:
          return;
        case MiniappRequestType.SUBSCRIBE:
          return;
        default:
          if (envelope.requestId) {
            this.deliverSyntheticResult(envelope.requestId, type ?? "<unknown>", payload);
          }
          return;
      }
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      if (!this.open_)
        return;
      this.open_ = false;
      this.disconnectHandler?.("MockTransport.close()");
    }
    isOpen() {
      return this.open_;
    }
    deliverConnectAck(connectPayload) {
      const incomingPackage = connectPayload.packageName ?? this.packageName ?? "com.mock.app";
      const ackPayload = {
        type: MiniappResponseType.CONNECT_ACK,
        userId: this.userId,
        packageName: incomingPackage,
        capabilities: null,
        visibility: "foreground",
        colorScheme: "light",
        auth: {
          mentraUserId: this.userId,
          oemId: "mock",
          token: this.authToken,
          expiresAt: Date.now() + 60 * 60 * 1000
        }
      };
      const envelope = { payload: ackPayload };
      this.log(`-> CONNECT_ACK userId=${this.userId} pkg=${incomingPackage}`);
      queueMicrotask(() => this.messageHandler?.(serializeEnvelope(envelope)));
    }
    deliverSyntheticResult(requestId, requestType, requestPayload) {
      const data = syntheticDataFor(requestId, requestType, requestPayload);
      const responsePayload = {
        type: MiniappResponseType.REQUEST_RESULT,
        ok: true,
        data
      };
      const envelope = { payload: responsePayload, requestId };
      this.log(`-> REQUEST_RESULT (rid=${requestId}) synthetic ${requestType}`);
      queueMicrotask(() => this.messageHandler?.(serializeEnvelope(envelope)));
    }
    log(...args) {
      if (this.silent)
        return;
      console.log(LOG_PREFIX, ...args);
    }
  }
  function syntheticDataFor(requestId, requestType, requestPayload) {
    switch (requestType) {
      case MiniappRequestType.CAMERA_FOV: {
        const presetFov = requestPayload.preset === "narrow" ? 82 : requestPayload.preset === "wide" ? 118 : requestPayload.preset === "standard" ? 102 : undefined;
        const fov = typeof requestPayload.fov === "number" ? requestPayload.fov : presetFov ?? 102;
        const roi = requestPayload.roiPosition;
        const roiPosition = roi === "bottom" ? "bottom" : roi === "top" ? "top" : "center";
        return {
          requestId,
          fov,
          roiPosition,
          timestamp: Date.now()
        };
      }
      case MiniappRequestType.PHOTO:
        return {
          photoUrl: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkAAIAAAoAAv/lxKUAAAAASUVORK5CYII=",
          requestId: "mock-photo"
        };
      case MiniappRequestType.RGB_LED:
        return { type: "rgb_led_control_response", state: "success", requestId };
      case MiniappRequestType.LOCATION_POLL:
        return { lat: 37.7956, lng: -122.3933, accuracy: 0, timestamp: Date.now() };
      case MiniappRequestType.STORAGE_GET:
        return { value: null };
      case MiniappRequestType.STORAGE_LIST:
        return { keys: [] };
      case MiniappRequestType.SPEAK:
        return { audioUrl: null, durationMs: 0 };
      case MiniappRequestType.SHARE:
      case MiniappRequestType.OPEN_URL:
      case MiniappRequestType.COPY_CLIPBOARD:
      case MiniappRequestType.DOWNLOAD:
      case MiniappRequestType.REQUEST_WIFI_SETUP:
        return { ok: true };
      default:
        return null;
    }
  }

  // ../vendor/miniapp/dist/transport/postmessage.js
  class PostMessageTransport {
    constructor() {
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.open_ = false;
      this.windowListener = null;
    }
    async open() {
      if (this.open_)
        return;
      if (typeof window === "undefined" || !window.ReactNativeWebView) {
        throw new Error("PostMessageTransport: not running inside a React Native WebView");
      }
      this.windowListener = (ev) => {
        const data = ev.data;
        if (typeof data !== "string")
          return;
        this.messageHandler?.(data);
      };
      window.addEventListener("message", this.windowListener);
      if (typeof document !== "undefined") {
        document.addEventListener("message", this.windowListener);
      }
      window.receiveNativeMessage = (raw) => {
        this.messageHandler?.(raw);
      };
      this.open_ = true;
    }
    send(raw) {
      if (typeof window === "undefined" || !window.ReactNativeWebView) {
        throw new Error("PostMessageTransport: not running inside a React Native WebView");
      }
      window.ReactNativeWebView.postMessage(raw);
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      if (!this.open_)
        return;
      this.open_ = false;
      if (this.windowListener) {
        window.removeEventListener("message", this.windowListener);
        if (typeof document !== "undefined") {
          document.removeEventListener("message", this.windowListener);
        }
        this.windowListener = null;
      }
      if (typeof window !== "undefined" && window.receiveNativeMessage) {
        window.receiveNativeMessage = undefined;
      }
      this.disconnectHandler?.("closed");
    }
    isOpen() {
      return this.open_;
    }
  }

  // ../vendor/miniapp/dist/transport/auto.js
  var LOCAL_SOCKET_OPEN_TIMEOUT_MS = 500;
  function createTransport(options = {}) {
    if (options.transport)
      return options.transport;
    if (DispatchTransport.isAvailable()) {
      return new DispatchTransport;
    }
    if (typeof window !== "undefined" && window.ReactNativeWebView) {
      return new PostMessageTransport;
    }
    if (isMockExplicitlyRequested()) {
      return new MockTransport;
    }
    if (typeof WebSocket !== "undefined") {
      const localSocketOptions = {};
      if (options.localSocketUrl)
        localSocketOptions.url = options.localSocketUrl;
      return new LocalSocketWithMockFallback(localSocketOptions);
    }
    return new MockTransport;
  }

  class LocalSocketWithMockFallback {
    constructor(options) {
      this.options = options;
      this.active = null;
      this.messageHandler = null;
      this.disconnectHandler = null;
    }
    async open() {
      const local = new LocalSocketTransport(this.options);
      let timedOut = false;
      const timeout = new Promise((_, reject) => {
        setTimeout(() => {
          timedOut = true;
          reject(new Error("LocalSocketTransport open timed out"));
        }, LOCAL_SOCKET_OPEN_TIMEOUT_MS);
      });
      try {
        await Promise.race([local.open(), timeout]);
        this.active = local;
      } catch {
        try {
          local.close();
        } catch {}
        const mock = new MockTransport;
        await mock.open();
        this.active = mock;
        console.log(timedOut ? "[mentra-miniapp] No phone WebSocket reachable; using MockTransport so the page can render." : "[mentra-miniapp] LocalSocketTransport failed; using MockTransport.");
      }
      if (this.messageHandler)
        this.active.onMessage(this.messageHandler);
      if (this.disconnectHandler)
        this.active.onDisconnect(this.disconnectHandler);
    }
    send(raw) {
      if (!this.active)
        throw new Error("LocalSocketWithMockFallback: send() before open()");
      this.active.send(raw);
    }
    onMessage(handler) {
      this.messageHandler = handler;
      this.active?.onMessage(handler);
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
      this.active?.onDisconnect(handler);
    }
    close() {
      this.active?.close();
    }
    isOpen() {
      return this.active?.isOpen() === true;
    }
  }

  // ../vendor/miniapp/dist/modules/camera.js
  class CameraModule {
    constructor(session) {
      this.session = session;
    }
    get hasPermission() {
      return this.session._hasManifestPermission("CAMERA");
    }
    async setFov(request) {
      return this.session.sendRequest({
        type: MiniappRequestType.CAMERA_FOV,
        ...request
      });
    }
    async takePhoto(options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.PHOTO,
        size: options.size ?? "medium",
        compress: options.compress ?? "none",
        sound: options.sound ?? true,
        saveToGallery: options.saveToGallery ?? false,
        exposureTimeNs: options.exposureTimeNs
      });
    }
    async startVideoRecording(options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.VIDEO_RECORDING_START,
        width: options.width,
        height: options.height,
        fps: options.fps,
        sound: options.sound ?? true,
        save: options.save ?? false
      });
    }
    async stopVideoRecording(recordingId, options = {}) {
      await this.session.sendRequest({
        type: MiniappRequestType.VIDEO_RECORDING_STOP,
        recordingId,
        uploadUrl: options.uploadUrl,
        uploadAuthToken: options.uploadAuthToken
      });
    }
  }

  // ../vendor/miniapp/dist/modules/canvas.js
  var CanvasOperation;
  (function(CanvasOperation2) {
    CanvasOperation2["SHOW_TEXT"] = "show_text";
    CanvasOperation2["SHOW_BITMAP"] = "show_bitmap";
    CanvasOperation2["CLEAR"] = "clear";
    CanvasOperation2["SHOW_PAGE"] = "show_page";
  })(CanvasOperation || (CanvasOperation = {}));

  class CanvasManager {
    constructor(session) {
      this.session = session;
    }
    send(operation, options) {
      this.session.sendOneShot({
        type: MiniappRequestType.CANVAS,
        operation,
        options
      });
    }
    showText(text, options = {}) {
      this.send(CanvasOperation.SHOW_TEXT, { text, ...options });
    }
    showBitmap(data, options = {}) {
      this.send(CanvasOperation.SHOW_BITMAP, { data, ...options });
    }
    showPage(id, options = {}) {
      this.send(CanvasOperation.SHOW_PAGE, { id, ...options });
    }
    clear(options = {}) {
      this.send(CanvasOperation.CLEAR, options);
    }
  }

  // ../vendor/miniapp/dist/modules/auth.js
  var DEFAULT_MIN_TTL_MS = 30000;

  class AuthModule {
    constructor(session) {
      this.session = session;
    }
    get current() {
      return this.session._getAuth();
    }
    get mentraUserId() {
      return this.current?.mentraUserId ?? null;
    }
    get oemId() {
      return this.current?.oemId ?? null;
    }
    async getToken(options = {}) {
      const auth = await this.session._waitForAuth(options.minTtlMs ?? DEFAULT_MIN_TTL_MS);
      return auth.token;
    }
    async getAuthHeader(options = {}) {
      return `Bearer ${await this.getToken(options)}`;
    }
    async fetch(input, init = {}) {
      const { minTtlMs, ...requestInit } = init;
      const token = await this.getToken({ minTtlMs });
      const headers = mergeHeaders(requestInit.headers, { Authorization: `Bearer ${token}` });
      return fetch(input, { ...requestInit, headers });
    }
    onUpdate(handler) {
      return this.session.on("auth", handler);
    }
  }
  function mergeHeaders(base, next) {
    const headers = {};
    if (Array.isArray(base)) {
      for (const [key, value] of base) {
        headers[key] = value;
      }
    } else if (typeof Headers !== "undefined" && base instanceof Headers) {
      base.forEach((value, key) => {
        headers[key] = value;
      });
    } else if (base && typeof base === "object") {
      for (const [key, value] of Object.entries(base)) {
        if (typeof value === "string")
          headers[key] = value;
      }
    }
    return { ...headers, ...next };
  }

  // ../vendor/miniapp/dist/modules/cloud.js
  var CLOUD_STATUS_STREAM = "_cloud_status";
  var DEFAULT_STATUS = {
    status: "disconnected",
    audioTransport: "none"
  };
  function normalizeCloudStatus(data) {
    if (!data || typeof data !== "object")
      return null;
    const raw = data;
    const status = raw.status;
    const audioTransport = raw.audioTransport;
    if (status !== "connected" && status !== "connecting" && status !== "reconnecting" && status !== "disconnected") {
      return null;
    }
    if (audioTransport !== "udp" && audioTransport !== "ws" && audioTransport !== "offline" && audioTransport !== "none") {
      return null;
    }
    return { status, audioTransport };
  }

  class CloudModule {
    constructor(session) {
      this.session = session;
      this.emitter = new import__.default;
      this.current = { ...DEFAULT_STATUS };
      this.session._subscribe(CLOUD_STATUS_STREAM, (data) => {
        const next = normalizeCloudStatus(data);
        if (!next)
          return;
        if (next.status === this.current.status && next.audioTransport === this.current.audioTransport)
          return;
        this.current = next;
        this.emitter.emit("status", { ...this.current });
      });
    }
    get status() {
      return { ...this.current };
    }
    get connected() {
      return this.current.status === "connected";
    }
    isConnected() {
      return this.connected;
    }
    onStatusChanged(handler) {
      handler({ ...this.current });
      this.emitter.on("status", handler);
      return () => {
        this.emitter.off("status", handler);
      };
    }
  }

  // ../vendor/miniapp/dist/modules/dashboard.js
  class DashboardAPI {
    constructor(session) {
      this.session = session;
      this.warned = false;
    }
    setContent(mode, content) {
      if (!this.warned) {
        console.warn("[@mentra/miniapp] dashboard.setContent() is deferred in v1.");
        this.warned = true;
      }
      this.session.sendOneShot({
        type: MiniappRequestType.DASHBOARD_CONTENT_UPDATE,
        mode,
        content
      });
    }
  }

  // ../vendor/miniapp/dist/modules/display.js
  class DisplayManager {
    constructor(session) {
      this.session = session;
    }
    send(layout, options = {}) {
      const payloadLayout = options.breakMode && supportsBreakMode(layout) ? { ...layout, breakMode: options.breakMode } : layout;
      this.session.sendOneShot({
        type: MiniappRequestType.DISPLAY,
        view: options.view ?? "main",
        layout: payloadLayout,
        durationMs: options.durationMs
      });
    }
    showTextWall(text, options = {}) {
      this.send({ layoutType: "text_wall", text }, options);
    }
    showDoubleTextWall(topText, bottomText, options = {}) {
      this.send({ layoutType: "double_text_wall", topText, bottomText }, options);
    }
    showReferenceCard(title, text, options = {}) {
      this.send({ layoutType: "reference_card", title, text }, options);
    }
    showDashboardCard(leftText, rightText) {
      this.send({ layoutType: "dashboard_card", leftText, rightText }, { view: "dashboard" });
    }
    showBitmapView(data, options = {}) {
      const { x, y, width, height, ...display } = options;
      this.send({ layoutType: "bitmap_view", data, x, y, width, height }, display);
    }
    showTextAt(text, options = {}) {
      const { x, y, width, height, borderWidth, borderRadius, ...display } = options;
      this.send({ layoutType: "positioned_text", text, x, y, width, height, borderWidth, borderRadius }, display);
    }
    clear(view = "main") {
      this.send({ layoutType: "clear_view" }, { view });
    }
  }
  function supportsBreakMode(layout) {
    return layout.layoutType === "text_wall" || layout.layoutType === "double_text_wall" || layout.layoutType === "reference_card";
  }

  // ../vendor/miniapp/dist/modules/events.js
  class EventManager {
    constructor(session) {
      this.session = session;
      this.emitter = new import__.default;
      this.refCounts = new Map;
    }
    subscribe(stream, handler) {
      this.emitter.on(stream, handler);
      const isInternal = stream.startsWith("_");
      if (!isInternal) {
        const before = this.refCounts.get(stream) ?? 0;
        this.refCounts.set(stream, before + 1);
        if (before === 0) {
          this.sendSubscriptionUpdate();
        }
      }
      return () => {
        this.emitter.off(stream, handler);
        if (isInternal)
          return;
        const current = this.refCounts.get(stream) ?? 0;
        if (current <= 1) {
          this.refCounts.delete(stream);
          this.sendSubscriptionUpdate();
        } else {
          this.refCounts.set(stream, current - 1);
        }
      };
    }
    unsubscribeAll() {
      this.emitter.removeAllListeners();
      this.refCounts.clear();
      this.sendSubscriptionUpdate();
    }
    _forwardEvent(stream, data) {
      this.emitter.emit(stream, data);
      if (stream.startsWith("transcription:") && stream !== "transcription:auto") {
        this.emitter.emit("transcription:auto", data);
      } else if (stream.startsWith("translation:")) {
        const parts = stream.split(":");
        const patterns = new Set(["translation:auto"]);
        if (parts.length === 3) {
          const [, source, target] = parts;
          patterns.add("translation:*:*");
          patterns.add(`translation:*:${target}`);
          patterns.add(`translation:${source}:*`);
        }
        patterns.delete(stream);
        for (const pattern of patterns) {
          this.emitter.emit(pattern, data);
        }
      }
    }
    sendSubscriptionUpdate() {
      const subscriptions = Array.from(this.refCounts.keys()).map((stream) => stream === MiniappStreamType.LOCATION_UPDATE ? { stream: "location_stream", rate: "realtime" } : stream);
      this.session.sendOneShot({
        type: MiniappRequestType.SUBSCRIBE,
        subscriptions
      });
    }
  }

  // ../vendor/miniapp/dist/modules/glasses.js
  class GlassesModule {
    constructor(session) {
      this.session = session;
    }
    onBattery(handler) {
      return this.session._subscribe(MiniappStreamType.GLASSES_BATTERY, handler);
    }
    onConnection(handler) {
      return this.session._subscribe(MiniappStreamType.GLASSES_CONNECTION, handler);
    }
    onWifi(handler) {
      return this.session._subscribe(MiniappStreamType.GLASSES_WIFI, handler);
    }
    async requestWifiSetup(reason) {
      await this.session.sendRequest({
        type: MiniappRequestType.REQUEST_WIFI_SETUP,
        reason
      });
    }
  }

  // ../vendor/miniapp/dist/modules/heading.js
  class HeadingModule {
    constructor(session) {
      this.session = session;
    }
    get hasPermission() {
      return this.session._hasManifestPermission("LOCATION");
    }
    onUpdate(handler) {
      return this.session._subscribe(MiniappStreamType.HEADING_UPDATE, handler);
    }
  }

  // ../vendor/miniapp/dist/modules/imu.js
  class ImuModule {
    constructor(session) {
      this.session = session;
    }
    onHeadPosition(handler) {
      return this.session._subscribe(MiniappStreamType.HEAD_POSITION, handler);
    }
    onAccel(handler) {
      return this.session._subscribe(MiniappStreamType.ACCEL_DATA, handler);
    }
    setEnabled(enabled) {
      return this.session.sendRequest({
        type: MiniappRequestType.IMU_SET_ENABLED,
        enabled
      });
    }
  }

  // ../vendor/miniapp/dist/modules/input.js
  class InputModule {
    constructor(session) {
      this.session = session;
    }
    onButtonPress(handler) {
      return this.session._subscribe(MiniappStreamType.BUTTON_PRESS, handler);
    }
    onTouch(gestureOrHandler, maybeHandler) {
      if (typeof gestureOrHandler === "function") {
        return this.session._subscribe(MiniappStreamType.TOUCH_EVENT, gestureOrHandler);
      }
      const handler = maybeHandler;
      const gestures = Array.isArray(gestureOrHandler) ? gestureOrHandler : [gestureOrHandler];
      if (gestures.length === 0)
        return () => {};
      const unsubs = [];
      for (const g of gestures) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TOUCH_EVENT}:${g}`, handler));
      }
      return () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
    }
  }

  // ../vendor/miniapp/dist/modules/led.js
  class LedModule {
    constructor(session) {
      this.session = session;
    }
    async turnOn(options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.RGB_LED,
        action: "on",
        color: options.color ?? "red",
        ontime: options.ontime ?? 1000,
        offtime: options.offtime ?? 0,
        count: options.count ?? 1
      });
    }
    async turnOff() {
      return this.session.sendRequest({
        type: MiniappRequestType.RGB_LED,
        action: "off"
      });
    }
    async blink(color, ontime, offtime, count) {
      return this.turnOn({ color, ontime, offtime, count });
    }
    async solid(color, duration) {
      return this.turnOn({ color, ontime: duration, offtime: 0, count: 1 });
    }
  }

  // ../vendor/miniapp/dist/modules/location.js
  class LocationModule {
    constructor(session) {
      this.session = session;
    }
    get hasPermission() {
      return this.session._hasManifestPermission("LOCATION");
    }
    onUpdate(handler) {
      return this.session._subscribe(MiniappStreamType.LOCATION_UPDATE, handler);
    }
    getOnce() {
      return this.session.sendRequest({
        type: MiniappRequestType.LOCATION_POLL
      });
    }
  }

  // ../vendor/miniapp/dist/modules/mic.js
  class MicModule {
    constructor(session) {
      this.session = session;
      this.unsubs = new Set;
    }
    onVoiceActivity(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.VAD, handler));
    }
    onAudioChunk(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.AUDIO_CHUNK, handler));
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
    get hasPermission() {
      return this.session._hasManifestPermission("MICROPHONE");
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
  }

  // ../vendor/miniapp/dist/modules/pivots/geometry.js
  var TURN_THRESHOLD_DEG = 15;
  var SAME_DIR_MERGE_M = 25;
  var RDP_EPSILON_M = 5;
  var MIN_BEND_PER_POINT_DEG = 10;
  var STRAIGHT_SEGMENT_BREAK_M = 1;
  var INTERSECTION_CLUSTER_M = 30;
  function haversineMeters(a, b) {
    const R = 6371000;
    const toRad = (d) => d * Math.PI / 180;
    const dLat = toRad(b.lat - a.lat);
    const dLng = toRad(b.lng - a.lng);
    const lat1 = toRad(a.lat);
    const lat2 = toRad(b.lat);
    const x = Math.sin(dLat / 2) ** 2 + Math.sin(dLng / 2) ** 2 * Math.cos(lat1) * Math.cos(lat2);
    return 2 * R * Math.asin(Math.sqrt(x));
  }
  function bearingDeg(a, b) {
    const toRad = (d) => d * Math.PI / 180;
    const toDeg = (r) => r * 180 / Math.PI;
    const lat1 = toRad(a.lat);
    const lat2 = toRad(b.lat);
    const dLng = toRad(b.lng - a.lng);
    const y = Math.sin(dLng) * Math.cos(lat2);
    const x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLng);
    return (toDeg(Math.atan2(y, x)) + 360) % 360;
  }
  function signedAngleDiff(target, actual) {
    return (target - actual + 540) % 360 - 180;
  }
  function rdpSimplify(points, epsilonMeters) {
    if (points.length < 3)
      return points.map((_, i) => i);
    const keep = new Array(points.length).fill(false);
    keep[0] = true;
    keep[points.length - 1] = true;
    const stack = [[0, points.length - 1]];
    while (stack.length) {
      const [lo, hi] = stack.pop();
      let maxDist = 0;
      let maxIdx = -1;
      for (let i = lo + 1;i < hi; i++) {
        const d = perpDistMeters(points[i], points[lo], points[hi]);
        if (d > maxDist) {
          maxDist = d;
          maxIdx = i;
        }
      }
      if (maxIdx !== -1 && maxDist > epsilonMeters) {
        keep[maxIdx] = true;
        stack.push([lo, maxIdx], [maxIdx, hi]);
      }
    }
    const out = [];
    for (let i = 0;i < keep.length; i++)
      if (keep[i])
        out.push(i);
    return out;
  }
  function perpDistMeters(p, a, b) {
    const mPerDegLat = 111320;
    const mPerDegLng = 111320 * Math.cos(a.lat * Math.PI / 180);
    const bx = (b.lng - a.lng) * mPerDegLng;
    const by = (b.lat - a.lat) * mPerDegLat;
    const px = (p.lng - a.lng) * mPerDegLng;
    const py = (p.lat - a.lat) * mPerDegLat;
    const dx = bx;
    const dy = by;
    const len = Math.sqrt(dx * dx + dy * dy);
    if (len === 0)
      return Math.sqrt(px * px + py * py);
    return Math.abs(dx * -py - -px * dy) / len;
  }
  function extractPivots(rawPoints) {
    if (rawPoints.length < 3)
      return [];
    const keptIdx = rdpSimplify(rawPoints, RDP_EPSILON_M);
    const simplified = keptIdx.map((i) => rawPoints[i]);
    if (simplified.length < 3)
      return [];
    const deltas = [];
    for (let i = 1;i < simplified.length - 1; i++) {
      const inBearing = bearingDeg(simplified[i - 1], simplified[i]);
      const outBearing = bearingDeg(simplified[i], simplified[i + 1]);
      deltas.push(signedAngleDiff(outBearing, inBearing));
    }
    const candidates = [];
    let runStart = -1;
    let runSum = 0;
    let runSign = 0;
    const flushRun = (endExclusive) => {
      if (runStart === -1)
        return;
      if (Math.abs(runSum) >= TURN_THRESHOLD_DEG) {
        let bestIdx = runStart;
        let bestAbs = 0;
        for (let k = runStart;k < endExclusive; k++) {
          const a = Math.abs(deltas[k]);
          if (a > bestAbs) {
            bestAbs = a;
            bestIdx = k;
          }
        }
        const simplifiedIdx = bestIdx + 1;
        candidates.push({
          lat: simplified[simplifiedIdx].lat,
          lng: simplified[simplifiedIdx].lng,
          direction: runSum > 0 ? "right" : "left",
          simplifiedRouteIndex: simplifiedIdx,
          rawRouteIndex: keptIdx[simplifiedIdx],
          headingDelta: runSum
        });
      }
      runStart = -1;
      runSum = 0;
      runSign = 0;
    };
    let metersSinceLastBend = 0;
    for (let k = 0;k < deltas.length; k++) {
      const d = deltas[k];
      const sign = d > 0 ? 1 : d < 0 ? -1 : 0;
      const segLen = haversineMeters(simplified[k + 1], simplified[k + 2]);
      if (sign === 0 || Math.abs(d) < MIN_BEND_PER_POINT_DEG) {
        if (runStart !== -1) {
          if (sign === runSign || sign === 0)
            runSum += d;
          metersSinceLastBend += segLen;
          if (metersSinceLastBend >= STRAIGHT_SEGMENT_BREAK_M) {
            flushRun(k + 1);
          }
        }
        continue;
      }
      if (runStart === -1) {
        runStart = k;
        runSum = d;
        runSign = sign;
        metersSinceLastBend = segLen;
      } else if (sign === runSign) {
        if (metersSinceLastBend >= STRAIGHT_SEGMENT_BREAK_M) {
          flushRun(k);
          runStart = k;
          runSum = d;
          runSign = sign;
        } else {
          runSum += d;
        }
        metersSinceLastBend = segLen;
      } else {
        flushRun(k);
        runStart = k;
        runSum = d;
        runSign = sign;
        metersSinceLastBend = segLen;
      }
    }
    flushRun(deltas.length);
    const merged = [];
    for (const p of candidates) {
      const last = merged[merged.length - 1];
      if (last && last.direction === p.direction && haversineMeters({ lat: last.lat, lng: last.lng }, { lat: p.lat, lng: p.lng }) < SAME_DIR_MERGE_M) {
        if (Math.abs(p.headingDelta) > Math.abs(last.headingDelta)) {
          merged[merged.length - 1] = p;
        }
        continue;
      }
      merged.push(p);
    }
    const clustered = [];
    for (const p of merged) {
      const last = clustered[clustered.length - 1];
      if (last && haversineMeters({ lat: last.lat, lng: last.lng }, { lat: p.lat, lng: p.lng }) < INTERSECTION_CLUSTER_M) {
        const netDelta = last.headingDelta + p.headingDelta;
        const anchor = Math.abs(p.headingDelta) > Math.abs(last.headingDelta) ? p : last;
        clustered[clustered.length - 1] = {
          ...anchor,
          direction: netDelta > 0 ? "right" : "left",
          headingDelta: netDelta
        };
        continue;
      }
      clustered.push(p);
    }
    return clustered.filter((p) => Math.abs(p.headingDelta) >= TURN_THRESHOLD_DEG);
  }
  function cumulativeDistances(points) {
    const out = new Array(points.length);
    out[0] = 0;
    for (let i = 1;i < points.length; i++) {
      out[i] = out[i - 1] + haversineMeters(points[i - 1], points[i]);
    }
    return out;
  }

  // ../vendor/miniapp/dist/modules/pivots/instructions.js
  var DIRECTION_WORDS = new Set(["right", "left", "the right", "the left", "north", "south", "east", "west"]);
  var MANEUVER_VERBS = /\b(turn|slight|sharp|continue|head|merge|exit|uturn|u-turn|then|keep)\b/i;
  function roadNameFromInstruction(instruction) {
    if (!instruction)
      return null;
    const firstLine = instruction.split(`
`)[0] ?? "";
    const m = firstLine.match(/\bonto\s+(.+)$/i);
    let raw = (m ? m[1] : "").trim();
    if (!raw)
      return null;
    if (raw.includes(","))
      return null;
    raw = raw.split(/\s+(?:toward|towards|to|and|then|for)\b/i)[0]?.trim() ?? "";
    raw = raw.replace(/\s+#.*$/, "").trim();
    if (!raw)
      return null;
    if (DIRECTION_WORDS.has(raw.toLowerCase()))
      return null;
    if (MANEUVER_VERBS.test(raw))
      return null;
    return raw;
  }
  var ROAD_SUFFIXES = /\b(st|street|ave|avenue|blvd|boulevard|rd|road|dr|drive|ln|lane|way|ct|court|pl|place|ter|terrace|hwy|highway)\b\.?/g;
  function normalizeRoad(road) {
    return road.toLowerCase().replace(ROAD_SUFFIXES, "").replace(/[^a-z0-9 ]/g, "").replace(/\s+/g, " ").trim();
  }
  function sameRoad(a, b) {
    return normalizeRoad(a) === normalizeRoad(b);
  }
  function turnDirection(maneuver) {
    if (!maneuver)
      return null;
    const m = maneuver.toUpperCase();
    if (m.includes("LEFT"))
      return "left";
    if (m.includes("RIGHT"))
      return "right";
    return null;
  }
  var PROBE_METERS = 22;
  function signedBendAt(points, junction) {
    if (points.length < 3)
      return null;
    let mid = 0;
    let bestDist = Infinity;
    for (let i = 0;i < points.length; i++) {
      const d = haversineMeters(points[i], junction);
      if (d < bestDist) {
        bestDist = d;
        mid = i;
      }
    }
    let before = mid;
    while (before > 0 && haversineMeters(points[before], points[mid]) < PROBE_METERS)
      before--;
    let after = mid;
    while (after < points.length - 1 && haversineMeters(points[after], points[mid]) < PROBE_METERS)
      after++;
    if (before === mid || after === mid)
      return null;
    const incoming = bearingDeg(points[before], points[mid]);
    const outgoing = bearingDeg(points[mid], points[after]);
    return signedAngleDiff(outgoing, incoming);
  }
  var MIN_TURN_ANGLE_DEG = 30;
  function extractPivotsFromComputedSteps(steps, polyline) {
    if (!steps || steps.length < 2)
      return [];
    const initial = steps.map((s, i) => ({
      stepIdx: i,
      name: s.road ?? roadNameFromInstruction(s.instruction)
    }));
    let annotated = initial;
    for (let pass = 0;pass < 4; pass++) {
      const collapsed = [];
      for (let i = 0;i < annotated.length; i++) {
        const prev = collapsed[collapsed.length - 1];
        const here = annotated[i];
        const next = annotated[i + 1];
        if (prev?.name && next?.name && here.name && !sameRoad(prev.name, here.name) && sameRoad(prev.name, next.name)) {
          continue;
        }
        collapsed.push(here);
      }
      if (collapsed.length === annotated.length)
        break;
      annotated = collapsed;
    }
    const out = [];
    for (let i = 0;i < annotated.length - 1; i++) {
      const here = annotated[i];
      const nextAnn = annotated[i + 1];
      const s = steps[here.stepIdx];
      const next = steps[nextAnn.stepIdx];
      const fromRoad = here.name;
      const toRoad = nextAnn.name;
      if (!fromRoad)
        continue;
      if (toRoad && sameRoad(fromRoad, toRoad))
        continue;
      if (!Number.isFinite(s.endLat) || !Number.isFinite(s.endLng))
        continue;
      const junction = { lat: s.endLat, lng: s.endLng };
      const signedBend = signedBendAt(polyline, junction);
      if (signedBend != null && Math.abs(signedBend) < MIN_TURN_ANGLE_DEG)
        continue;
      const geomDir = signedBend == null ? null : signedBend > 0 ? "right" : "left";
      const direction = geomDir ?? turnDirection(next.maneuver);
      out.push({
        lat: s.endLat,
        lng: s.endLng,
        fromRoad,
        toRoad,
        direction,
        maneuver: next.maneuver ?? (direction === "left" ? "TURN_LEFT" : "TURN_RIGHT")
      });
    }
    return out;
  }

  // ../vendor/miniapp/dist/modules/pivots/engine.js
  var RADIUS_DEFAULTS_M = {
    walking: 7,
    cycling: 15,
    driving: 40,
    two_wheeler: 25
  };
  var APPROACH_DEFAULTS_M = {
    walking: 100,
    cycling: 300,
    driving: 800,
    two_wheeler: 500
  };
  var NON_TURN_MANEUVERS = new Set(["STRAIGHT", "NAME_CHANGE", "DEPART", "ARRIVE"]);
  var STEP_MATCH_MAX_INDEX_DELTA = 8;
  var ON_ROUTE_PERP_TOLERANCE_M = 50;

  class PivotEngine {
    constructor(mode, opts) {
      this.pivots = [];
      this.states = [];
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = [];
      this.cumulative = [];
      this.roadNameResolver = null;
      this.routeGeneration = 0;
      this.subscribers = new Set;
      this.opts = resolveOptions(mode, opts);
    }
    updateOptions(mode, opts) {
      this.opts = resolveOptions(mode, opts);
      for (const p of this.pivots) {
        p.radiusMeters = this.opts.radiusMeters;
      }
    }
    setRoadNameResolver(resolver) {
      this.roadNameResolver = resolver;
    }
    reset() {
      if (this.activePivotIndex !== null) {
        const active = this.pivots[this.activePivotIndex];
        if (active)
          this.emit({ kind: "exited", pivot: active });
      }
      this.pivots = [];
      this.states = [];
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = [];
      this.cumulative = [];
    }
    setRouteFromComputedSteps(route, computedSteps) {
      const points = route.points ?? [];
      if (this.activePivotIndex !== null) {
        const active = this.pivots[this.activePivotIndex];
        if (active)
          this.emit({ kind: "exited", pivot: active });
      }
      if (points.length < 3 || !computedSteps || computedSteps.length < 2) {
        this.setRoute(route, null);
        return;
      }
      const cumulative = cumulativeDistances(points);
      const instructionPivots = extractPivotsFromComputedSteps(computedSteps, points);
      console.log(`[PivotEngine] setRouteFromComputedSteps: steps=${computedSteps.length} instructionPivots=${instructionPivots.length}` + (instructionPivots.length > 0 ? `
` + instructionPivots.map((p, i) => `  pivot[${i}] ${p.fromRoad ?? "—"} → ${p.toRoad ?? "—"} dir=${p.direction} @ (${p.lat.toFixed(5)}, ${p.lng.toFixed(5)})`).join(`
`) : ""));
      if (instructionPivots.length === 0) {
        console.log(`[PivotEngine] falling back to setRoute (geometry) — input steps:
` + computedSteps.map((s, i) => `  step[${i}] road=${s.road ?? "—"} maneuver=${s.maneuver ?? "—"} @ (${s.lat.toFixed(5)}, ${s.lng.toFixed(5)}) → (${s.endLat.toFixed(5)}, ${s.endLng.toFixed(5)})`).join(`
`));
        this.setRoute(route, null);
        return;
      }
      const pivots = instructionPivots.map((p, i) => ({
        index: i,
        lat: p.lat,
        lng: p.lng,
        direction: p.direction === "left" ? "left" : "right",
        fromRoad: p.fromRoad,
        toRoad: p.toRoad,
        maneuver: p.maneuver,
        distanceAlongRouteMeters: alongRouteAtCoord(points, cumulative, { lat: p.lat, lng: p.lng }),
        radiusMeters: this.opts.radiusMeters
      }));
      pivots.sort((a, b) => a.distanceAlongRouteMeters - b.distanceAlongRouteMeters);
      for (let i = 0;i < pivots.length; i++)
        pivots[i].index = i;
      this.pivots = pivots;
      this.states = pivots.map(() => ({ approachingFired: false, entered: false, exited: false }));
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = points;
      this.cumulative = cumulative;
      this.routeGeneration++;
      this._resolveMissingRoadNames(this.routeGeneration);
    }
    setRoute(route, _userPosition) {
      const points = route.points ?? [];
      const steps = route.steps ?? [];
      if (this.activePivotIndex !== null) {
        const active = this.pivots[this.activePivotIndex];
        if (active)
          this.emit({ kind: "exited", pivot: active });
      }
      if (points.length < 3) {
        this.pivots = [];
        this.states = [];
        this.cursor = 0;
        this.activePivotIndex = null;
        this.points = [];
        this.cumulative = [];
        return;
      }
      const cumulative = cumulativeDistances(points);
      const raw = extractPivots(points);
      const stepIndex = buildStepIndex(steps);
      const pivots = [];
      for (let i = 0;i < raw.length; i++) {
        const r = raw[i];
        const matched = matchStep(r, stepIndex);
        if (matched && NON_TURN_MANEUVERS.has(matched.maneuver)) {
          continue;
        }
        pivots.push({
          index: pivots.length,
          lat: r.lat,
          lng: r.lng,
          direction: r.direction,
          fromRoad: matched?.fromRoad ?? null,
          toRoad: matched?.toRoad ?? null,
          maneuver: matched?.maneuver ?? (r.direction === "left" ? "TURN_LEFT" : "TURN_RIGHT"),
          distanceAlongRouteMeters: distanceAtIndex(cumulative, r.rawRouteIndex),
          radiusMeters: this.opts.radiusMeters
        });
      }
      pivots.sort((a, b) => a.distanceAlongRouteMeters - b.distanceAlongRouteMeters);
      for (let i = 0;i < pivots.length; i++)
        pivots[i].index = i;
      this.pivots = pivots;
      this.states = pivots.map(() => ({ approachingFired: false, entered: false, exited: false }));
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = points;
      this.cumulative = cumulative;
      this.routeGeneration++;
      this._resolveMissingRoadNames(this.routeGeneration);
    }
    async _resolveMissingRoadNames(generation) {
      const pivots = this.pivots;
      if (pivots.length === 0)
        return;
      for (let i = 0;i < pivots.length - 1; i++) {
        const here = pivots[i];
        const next = pivots[i + 1];
        if (!here.toRoad && next.fromRoad)
          here.toRoad = next.fromRoad;
        if (!next.fromRoad && here.toRoad)
          next.fromRoad = here.toRoad;
      }
      for (let i = pivots.length - 1;i > 0; i--) {
        const here = pivots[i];
        const prev = pivots[i - 1];
        if (!prev.toRoad && here.fromRoad)
          prev.toRoad = here.fromRoad;
        if (!here.fromRoad && prev.toRoad)
          here.fromRoad = prev.toRoad;
      }
      const resolver = this.roadNameResolver;
      if (!resolver)
        return;
      if (this.points.length < 2)
        return;
      const SAMPLE_OFFSETS_M = [18, 30, 50, 80];
      const points = this.points;
      const cumulative = this.cumulative;
      const geocodeWithExpansion = async (pivotAlong, direction) => {
        for (const offset of SAMPLE_OFFSETS_M) {
          const sample = sampleAlongRoute(points, cumulative, pivotAlong + direction * offset);
          if (!sample)
            continue;
          try {
            const road = await resolver(sample);
            if (generation !== this.routeGeneration)
              return null;
            if (road)
              return road;
          } catch {}
        }
        return null;
      };
      const tasks = [];
      for (const pivot of pivots) {
        if (pivot.fromRoad && pivot.toRoad)
          continue;
        const along = pivot.distanceAlongRouteMeters;
        if (!pivot.fromRoad) {
          tasks.push(geocodeWithExpansion(along, -1).then((road) => {
            if (generation !== this.routeGeneration)
              return;
            if (road && !pivot.fromRoad)
              pivot.fromRoad = road;
          }));
        }
        if (!pivot.toRoad) {
          tasks.push(geocodeWithExpansion(along, 1).then((road) => {
            if (generation !== this.routeGeneration)
              return;
            if (road && !pivot.toRoad)
              pivot.toRoad = road;
          }));
        }
      }
      await Promise.all(tasks);
      if (generation !== this.routeGeneration)
        return;
      for (let i = 0;i < pivots.length - 1; i++) {
        const here = pivots[i];
        const next = pivots[i + 1];
        if (!here.toRoad && next.fromRoad)
          here.toRoad = next.fromRoad;
        if (!next.fromRoad && here.toRoad)
          next.fromRoad = here.toRoad;
      }
    }
    onLocationUpdate(coords) {
      if (this.pivots.length === 0)
        return;
      const projection = projectOntoPolyline(this.points, this.cumulative, coords);
      const useAlongPath = projection !== null && projection.perpMeters <= ON_ROUTE_PERP_TOLERANCE_M;
      const userAlong = projection?.alongMeters ?? 0;
      for (let i = this.cursor;i < this.pivots.length; i++) {
        const pivot = this.pivots[i];
        const state = this.states[i];
        if (state.exited)
          continue;
        const aheadDelta = pivot.distanceAlongRouteMeters - userAlong;
        const distanceToPivot = useAlongPath ? Math.abs(aheadDelta) : haversineMeters(coords, { lat: pivot.lat, lng: pivot.lng });
        const approaching = !state.approachingFired && distanceToPivot <= this.opts.approachThresholdMeters && (!useAlongPath || aheadDelta >= -this.opts.radiusMeters);
        if (approaching) {
          state.approachingFired = true;
          this.emit({ kind: "approaching", pivot, distanceMeters: distanceToPivot });
        }
        if (!state.entered && distanceToPivot <= pivot.radiusMeters) {
          state.entered = true;
          this.activePivotIndex = i;
          this.emit({ kind: "entered", pivot });
        }
        const movedPastOnPath = useAlongPath && aheadDelta < -pivot.radiusMeters;
        if ((state.entered && distanceToPivot > pivot.radiusMeters || !state.entered && movedPastOnPath) && !state.exited) {
          if (!state.entered) {
            state.entered = true;
            this.activePivotIndex = i;
            this.emit({ kind: "entered", pivot });
          }
          state.exited = true;
          if (this.activePivotIndex === i)
            this.activePivotIndex = null;
          this.emit({ kind: "exited", pivot });
          if (this.cursor <= i)
            this.cursor = i + 1;
        }
        if (!state.approachingFired && distanceToPivot > this.opts.approachThresholdMeters * 2) {
          break;
        }
      }
    }
    subscribe(fn) {
      this.subscribers.add(fn);
      return () => {
        this.subscribers.delete(fn);
      };
    }
    getPivots() {
      return this.pivots.slice();
    }
    getActivePivot() {
      if (this.activePivotIndex === null)
        return null;
      return this.pivots[this.activePivotIndex] ?? null;
    }
    getUpcomingPivot() {
      for (let i = this.cursor;i < this.pivots.length; i++) {
        if (!this.states[i].exited)
          return this.pivots[i];
      }
      return null;
    }
    emit(event) {
      for (const fn of this.subscribers) {
        try {
          fn(event);
        } catch (err) {
          console.error("[PivotEngine] subscriber threw:", err);
        }
      }
    }
  }
  function resolveOptions(mode, opts) {
    return {
      radiusMeters: opts?.radiusMeters ?? RADIUS_DEFAULTS_M[mode] ?? RADIUS_DEFAULTS_M.walking,
      approachThresholdMeters: opts?.approachThresholdMeters ?? APPROACH_DEFAULTS_M[mode] ?? APPROACH_DEFAULTS_M.walking
    };
  }
  function projectOntoPolyline(points, cumulative, user) {
    if (points.length < 2 || cumulative.length !== points.length)
      return null;
    const mPerDegLat = 111320;
    const mPerDegLng = 111320 * Math.cos(user.lat * Math.PI / 180);
    const ux = user.lng * mPerDegLng;
    const uy = user.lat * mPerDegLat;
    let bestPerp = Number.POSITIVE_INFINITY;
    let bestAlong = 0;
    for (let i = 0;i < points.length - 1; i++) {
      const a = points[i];
      const b = points[i + 1];
      const ax = a.lng * mPerDegLng;
      const ay = a.lat * mPerDegLat;
      const bx = b.lng * mPerDegLng;
      const by = b.lat * mPerDegLat;
      const dx = bx - ax;
      const dy = by - ay;
      const segLen2 = dx * dx + dy * dy;
      const t = segLen2 > 0 ? Math.max(0, Math.min(1, ((ux - ax) * dx + (uy - ay) * dy) / segLen2)) : 0;
      const px = ax + t * dx;
      const py = ay + t * dy;
      const perp = Math.hypot(ux - px, uy - py);
      if (perp < bestPerp) {
        bestPerp = perp;
        const segLen = Math.sqrt(segLen2);
        bestAlong = cumulative[i] + t * segLen;
      }
    }
    if (!Number.isFinite(bestPerp))
      return null;
    return { perpMeters: bestPerp, alongMeters: bestAlong };
  }
  function alongRouteAtCoord(points, cumulative, coord) {
    const projection = projectOntoPolyline(points, cumulative, coord);
    return projection?.alongMeters ?? 0;
  }
  function sampleAlongRoute(points, cumulative, targetMeters) {
    if (points.length < 2 || cumulative.length !== points.length)
      return null;
    const total = cumulative[cumulative.length - 1];
    if (!Number.isFinite(targetMeters))
      return null;
    if (targetMeters <= 0)
      return { lat: points[0].lat, lng: points[0].lng };
    if (targetMeters >= total) {
      const last = points[points.length - 1];
      return { lat: last.lat, lng: last.lng };
    }
    let lo = 0;
    let hi = cumulative.length - 1;
    while (lo + 1 < hi) {
      const mid = lo + hi >>> 1;
      if (cumulative[mid] <= targetMeters)
        lo = mid;
      else
        hi = mid;
    }
    const segStart = cumulative[lo];
    const segEnd = cumulative[hi];
    const segLen = segEnd - segStart;
    const t = segLen > 0 ? (targetMeters - segStart) / segLen : 0;
    const a = points[lo];
    const b = points[hi];
    return { lat: a.lat + (b.lat - a.lat) * t, lng: a.lng + (b.lng - a.lng) * t };
  }
  function distanceAtIndex(cumulative, idx) {
    if (cumulative.length === 0)
      return 0;
    if (idx < 0)
      return 0;
    if (idx >= cumulative.length)
      return cumulative[cumulative.length - 1];
    return cumulative[idx];
  }
  function buildStepIndex(steps) {
    if (!steps.length)
      return [];
    return steps.slice().sort((a, b) => a.routeIndex - b.routeIndex);
  }
  function matchStep(raw, stepIndex) {
    if (stepIndex.length < 2)
      return null;
    let bestJ = -1;
    let bestDelta = Number.POSITIVE_INFINITY;
    for (let i = 1;i < stepIndex.length; i++) {
      const delta = Math.abs(stepIndex[i].routeIndex - raw.rawRouteIndex);
      if (delta <= bestDelta) {
        bestDelta = delta;
        bestJ = i;
      }
    }
    if (bestJ < 1)
      return null;
    if (bestDelta > STEP_MATCH_MAX_INDEX_DELTA)
      return null;
    const SHORT_TRANSIT_METERS = 25;
    const finalIndex = stepIndex.length - 1;
    let j = bestJ;
    while (j < finalIndex - 1 && stepIndex[j].distanceMeters > 0 && stepIndex[j].distanceMeters < SHORT_TRANSIT_METERS) {
      j++;
    }
    if (j >= finalIndex)
      j = finalIndex - 1;
    const fromStep = stepIndex[bestJ - 1];
    const toStep = stepIndex[j];
    return {
      fromRoad: fromStep.road ?? null,
      toRoad: toStep.road ?? null,
      maneuver: fromStep.maneuver
    };
  }

  // ../vendor/miniapp/dist/modules/navigation.js
  class NavigationModule {
    constructor(session) {
      this.session = session;
      this._pivots = new PivotEngine("walking", undefined);
      this._tripUnsubs = [];
      this._tripStops = null;
      this._tripMode = "walking";
      this._tripAvoid = undefined;
      this._computeRouteSeq = 0;
      this._lastUserPosition = null;
      this._pivots.setRoadNameResolver(async (coord) => {
        try {
          const result = await this.reverseGeocodeRoad(coord);
          if (!result.ok)
            return null;
          return result.road ?? null;
        } catch {
          return null;
        }
      });
    }
    get hasPermission() {
      return this.session._hasManifestPermission("LOCATION");
    }
    requestPermission() {
      if (!this.hasPermission) {
        return Promise.resolve({
          ok: false,
          accepted: false,
          error: "LOCATION permission not declared in miniapp.json (required for navigation.requestPermission)."
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_REQUEST_PERMISSION
      });
    }
    async start(opts) {
      if (!this.hasPermission) {
        return {
          ok: false,
          error: "LOCATION permission not declared in miniapp.json (required for navigation.start)."
        };
      }
      const stops = normalizeStops(opts);
      const mode = opts.mode ?? "driving";
      this._tripStops = stops.length > 0 ? stops : null;
      this._tripMode = mode;
      this._tripAvoid = opts.avoid;
      this._attachPivotTrackingForTrip(mode, opts.pivots);
      const failStart = (error) => {
        this._detachPivotTracking();
        return { ok: false, error };
      };
      if (stops.length === 0) {
        return failStart("navigation.start: no stops");
      }
      let origin = this._lastUserPosition;
      if (!origin) {
        try {
          const fix = await this.session.location.getOnce();
          origin = { lat: fix.lat, lng: fix.lng };
          this._lastUserPosition = origin;
        } catch (err) {
          return failStart(`navigation.start: no GPS fix (${err instanceof Error ? err.message : String(err)})`);
        }
      }
      const restResult = await this.computeRoute({ origin, stops, mode, avoid: opts.avoid });
      if (!restResult.ok || !restResult.routes || restResult.routes.length === 0) {
        return failStart(restResult.error ?? "computeRoute failed");
      }
      const restRoute = restResult.routes[0];
      const nativeResult = await this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_START,
        lat: stops[0]?.lat,
        lng: stops[0]?.lng,
        stops,
        mode,
        avoid: opts.avoid,
        simulate: opts.simulate ?? false,
        speedMultiplier: opts.speedMultiplier ?? 1,
        missedTurnRerouteMeters: opts.missedTurnRerouteMeters
      });
      if (!nativeResult.ok) {
        this._detachPivotTracking();
        return nativeResult;
      }
      const syntheticRoute = buildNavRouteFromComputed(restRoute);
      this.session.events._forwardEvent(MiniappStreamType.NAVIGATION_ROUTE, syntheticRoute);
      return nativeResult;
    }
    stop() {
      this._detachPivotTracking();
      this.session.sendOneShot({ type: MiniappRequestType.NAVIGATION_STOP });
    }
    get dev() {
      return {
        deviate: (offsetMeters = 20) => {
          this.session.sendOneShot({ type: MiniappRequestType.NAVIGATION_DEVIATE, offsetMeters });
        },
        setWrongSidewalkOffset: (enabled) => {
          this.session.sendOneShot({ type: MiniappRequestType.NAVIGATION_SET_WRONG_SIDEWALK, enabled });
        },
        setSkipCrossings: (enabled) => {
          this.session.sendOneShot({ type: MiniappRequestType.NAVIGATION_SET_SKIP_CROSSINGS, enabled });
        }
      };
    }
    onUpdate(handler) {
      return this.session._subscribe(MiniappStreamType.NAVIGATION_UPDATE, handler);
    }
    onRoute(handler) {
      return this.session._subscribe(MiniappStreamType.NAVIGATION_ROUTE, handler);
    }
    async getState() {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_GET_STATE
      });
      return result.ok ? result.state ?? null : null;
    }
    computeRoute(opts) {
      if (!this.hasPermission) {
        return Promise.resolve({
          ok: false,
          error: "LOCATION permission not declared in miniapp.json (required for navigation.computeRoute)."
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_COMPUTE_ROUTE,
        origin: opts.origin,
        stops: opts.stops,
        mode: opts.mode ?? "driving",
        avoid: opts.avoid,
        alternatives: opts.alternatives ?? 1
      });
    }
    reverseGeocodeRoad(coord) {
      if (!this.hasPermission) {
        return Promise.resolve({
          ok: false,
          error: "LOCATION permission not declared in miniapp.json (required for reverseGeocodeRoad)."
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_REVERSE_GEOCODE,
        lat: coord.lat,
        lng: coord.lng
      });
    }
    placeAutocomplete(opts) {
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_PLACE_AUTOCOMPLETE,
        query: opts.query,
        near: opts.near ?? null,
        sessionToken: opts.sessionToken
      });
    }
    placeDetails(opts) {
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_PLACE_DETAILS,
        placeId: opts.placeId,
        sessionToken: opts.sessionToken
      });
    }
    onPivot(handler) {
      return this._pivots.subscribe(handler);
    }
    getPivots() {
      return this._pivots.getPivots();
    }
    getActivePivot() {
      return this._pivots.getActivePivot();
    }
    getUpcomingPivot() {
      return this._pivots.getUpcomingPivot();
    }
    _attachPivotTrackingForTrip(mode, opts) {
      this._detachPivotTracking();
      this._pivots.reset();
      this._pivots.updateOptions(mode, opts);
      this._tripUnsubs.push(this.onRoute((route) => {
        if (route.steps && route.steps.length > 0) {
          const tail = route.points[route.points.length - 1];
          const computedSteps = route.steps.map((s, i) => {
            const next = route.steps?.[i + 1];
            const endLat = next ? next.lat : tail?.lat ?? s.lat;
            const endLng = next ? next.lng : tail?.lng ?? s.lng;
            return {
              lat: s.lat,
              lng: s.lng,
              endLat,
              endLng,
              distanceMeters: s.distanceMeters,
              maneuver: s.maneuver,
              road: s.road ?? undefined
            };
          });
          this._pivots.setRouteFromComputedSteps(route, computedSteps);
          return;
        }
        this._pivots.setRoute(route, null);
        const seq = ++this._computeRouteSeq;
        this._issueComputeRouteForTrip(route).then((result) => {
          if (seq !== this._computeRouteSeq)
            return;
          const computedSteps = result?.routes?.[0]?.steps;
          if (computedSteps && computedSteps.length > 0) {
            this._pivots.setRouteFromComputedSteps(route, computedSteps);
          }
        }).catch((err) => {
          console.warn("[NavigationModule] computeRoute for pivots failed:", err);
        });
      }));
      this._tripUnsubs.push(this.onUpdate((update) => {
        if (update.kind === "arrived") {
          this._pivots.reset();
          return;
        }
      }));
      this._tripUnsubs.push(this.session.location.onUpdate((loc) => {
        this._lastUserPosition = { lat: loc.lat, lng: loc.lng };
        this._pivots.onLocationUpdate({ lat: loc.lat, lng: loc.lng });
      }));
    }
    async _issueComputeRouteForTrip(route) {
      if (!this._tripStops || this._tripStops.length === 0)
        return null;
      const origin = this._lastUserPosition ?? (route?.points && route.points[0] ? { lat: route.points[0].lat, lng: route.points[0].lng } : null);
      if (!origin)
        return null;
      return this.computeRoute({
        origin,
        stops: this._tripStops,
        mode: this._tripMode,
        avoid: this._tripAvoid
      });
    }
    _detachPivotTracking() {
      for (const unsub of this._tripUnsubs) {
        try {
          unsub();
        } catch (err) {
          console.warn("[NavigationModule] pivot-tracking unsubscribe threw:", err);
        }
      }
      this._tripUnsubs = [];
      this._pivots.reset();
      this._tripStops = null;
      this._tripAvoid = undefined;
      this._computeRouteSeq++;
      this._lastUserPosition = null;
    }
  }
  function normalizeStops(opts) {
    if (opts.stops && opts.stops.length > 0) {
      return opts.stops;
    }
    if (typeof opts.lat === "number" && typeof opts.lng === "number") {
      return [{ lat: opts.lat, lng: opts.lng }];
    }
    return [];
  }
  function buildNavRouteFromComputed(computed) {
    const points = computed.points ?? [];
    const steps = (computed.steps ?? []).map((s) => {
      let routeIndex = 0;
      let best = Infinity;
      for (let i = 0;i < points.length; i++) {
        const dLat = points[i].lat - s.lat;
        const dLng = points[i].lng - s.lng;
        const d = dLat * dLat + dLng * dLng;
        if (d < best) {
          best = d;
          routeIndex = i;
        }
      }
      return {
        lat: s.lat,
        lng: s.lng,
        routeIndex,
        road: s.road ?? null,
        maneuver: s.maneuver ?? "STRAIGHT",
        distanceMeters: s.distanceMeters
      };
    });
    return {
      points,
      totalDistanceMeters: computed.totalDistanceMeters,
      totalDurationSeconds: computed.totalDurationSeconds,
      steps: steps.length > 0 ? steps : undefined
    };
  }

  // ../vendor/miniapp/dist/modules/permissions.js
  class PermissionsModule {
    constructor(session) {
      this.session = session;
    }
    has(type) {
      return this.session._getPermissions()[type] === true;
    }
    getAll() {
      return this.session._getPermissions();
    }
    onUpdate(handler) {
      return this.session.on("permissions", handler);
    }
    onPermissionError(handler) {
      return this.session.on("error", (e) => {
        const maybe = e;
        if (maybe?.code === MiniappErrorCode.PERMISSION_NOT_DECLARED) {
          handler({
            code: String(maybe.code),
            message: String(maybe.message ?? ""),
            permission: maybe.permission,
            subscription: maybe.subscription,
            operation: maybe.operation
          });
        }
      });
    }
  }

  // ../vendor/miniapp/dist/modules/phone.js
  class TrackedSubs {
    constructor() {
      this.unsubs = new Set;
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
  }

  class PhoneNotificationsModule extends TrackedSubs {
    constructor(session) {
      super();
      this.session = session;
    }
    on(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.PHONE_NOTIFICATION, handler));
    }
    onDismissed(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.PHONE_NOTIFICATION_DISMISSED, handler));
    }
    get hasPermission() {
      return this.session._hasManifestPermission("READ_NOTIFICATIONS");
    }
  }

  class PhoneCalendarModule extends TrackedSubs {
    constructor(session) {
      super();
      this.session = session;
    }
    on(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.CALENDAR_EVENT, handler));
    }
    get hasPermission() {
      return this.session._hasManifestPermission("CALENDAR");
    }
  }

  class PhoneModule {
    constructor(session) {
      this.session = session;
      this.notifications = new PhoneNotificationsModule(session);
      this.calendar = new PhoneCalendarModule(session);
    }
    onBattery(handler) {
      return this.session._subscribe(MiniappStreamType.PHONE_BATTERY, handler);
    }
  }

  // ../vendor/miniapp/dist/modules/transcription.js
  class TranscriptionModule {
    constructor(session) {
      this.session = session;
      this.unsubs = new Set;
      this.currentConfig = null;
    }
    on(handler) {
      return this.track(this.session._subscribe(`${MiniappStreamType.TRANSCRIPTION}:auto`, handler));
    }
    forLanguage(language, handler) {
      const langs = Array.isArray(language) ? language : [language];
      if (langs.length === 0)
        return () => {};
      const unsubs = [];
      for (const lang of langs) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TRANSCRIPTION}:${lang}`, handler));
      }
      const combined = () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
      return this.track(combined);
    }
    configure(config) {
      this.currentConfig = { ...config };
      this.session.sendOneShot({
        type: MiniappRequestType.TRANSCRIPTION_CONFIG,
        config: { ...config }
      });
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
    get hasPermission() {
      return this.session._hasManifestPermission("MICROPHONE");
    }
    _getConfig() {
      return this.currentConfig ? { ...this.currentConfig } : null;
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
  }

  // ../vendor/miniapp/dist/modules/translation.js
  class TranslationModule {
    constructor(session) {
      this.session = session;
      this.unsubs = new Set;
    }
    on(handler) {
      return this.track(this.session._subscribe(`${MiniappStreamType.TRANSLATION}:*:*`, handler));
    }
    to(target, handler) {
      const targets = Array.isArray(target) ? target : [target];
      if (targets.length === 0)
        return () => {};
      const unsubs = [];
      for (const t of targets) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TRANSLATION}:*:${t}`, handler));
      }
      const composite = () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
      return this.track(composite);
    }
    fromTo(source, target, handler) {
      const targets = Array.isArray(target) ? target : [target];
      if (targets.length === 0)
        return () => {};
      const unsubs = [];
      for (const t of targets) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TRANSLATION}:${source}:${t}`, handler));
      }
      const composite = () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
      return this.track(composite);
    }
    forLanguagePair(fromLang, toLang, handler) {
      return this.fromTo(fromLang, toLang, handler);
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
    get hasPermission() {
      return this.session._hasManifestPermission("MICROPHONE");
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
  }

  // ../vendor/miniapp/dist/modules/ui.js
  function rpcErrorFromUnknown(e) {
    if (e instanceof Error) {
      const own = e;
      const cause = own.cause;
      return compactEnvelope({
        message: e.message,
        code: own.code ?? cause?.code,
        stage: own.stage,
        transport: own.transport
      });
    }
    if (e && typeof e === "object") {
      const o = e;
      return compactEnvelope({
        message: typeof o.message === "string" ? o.message : JSON.stringify(e),
        code: typeof o.code === "string" ? o.code : undefined,
        stage: typeof o.stage === "string" ? o.stage : undefined,
        transport: typeof o.transport === "string" ? o.transport : undefined
      });
    }
    return { message: String(e) };
  }
  function compactEnvelope(env) {
    const out = { message: env.message };
    if (env.code)
      out.code = env.code;
    if (env.stage)
      out.stage = env.stage;
    if (env.transport)
      out.transport = env.transport;
    return out;
  }

  class UIModuleImpl {
    constructor(session) {
      this.session = session;
      this.bound = false;
      this.nextSeq = 1;
      this.openHandlers = new Set;
      this.closeHandlers = new Set;
      this.channelHandlers = new Map;
      this.rpcHandlers = new Map;
      this.inflightRpc = new Map;
      this.isOpen = () => {
        return this.bound;
      };
      this.onOpen = (cb) => {
        this.openHandlers.add(cb);
        if (this.bound) {
          if (this.session.ready) {
            try {
              cb();
            } catch (e) {
              console.warn("session.ui.onOpen late-fire threw:", e);
            }
          }
        }
        return () => {
          this.openHandlers.delete(cb);
        };
      };
      this.onClose = (cb) => {
        this.closeHandlers.add(cb);
        return () => {
          this.closeHandlers.delete(cb);
        };
      };
      this.send = (channel, payload) => {
        if (!this.bound) {
          return;
        }
        const seq = this.nextSeq++;
        const envelope = { type: "UI_SEND", channel, payload, seq };
        this.session.sendOneShot(envelope);
      };
      this.on = (channel, cb) => {
        let set = this.channelHandlers.get(channel);
        if (!set) {
          set = new Set;
          this.channelHandlers.set(channel, set);
        }
        set.add(cb);
        return () => {
          set.delete(cb);
        };
      };
      this.handle = (channel, handler) => {
        const key = channel;
        if (this.rpcHandlers.has(key)) {
          throw new Error(`session.ui.handle: a handler is already registered for "${key}"`);
        }
        this.rpcHandlers.set(key, handler);
        return () => {
          this.rpcHandlers.delete(key);
        };
      };
      this.session._subscribe("_ui", (env) => this.handleInbound(env));
    }
    fireOpenHandlers() {
      for (const h of this.openHandlers) {
        try {
          h();
        } catch (e) {
          console.warn("session.ui.onOpen handler threw", e);
        }
      }
    }
    handleInbound(env) {
      if (env.type === "UI_OPEN") {
        this.bound = true;
        this.nextSeq = 1;
        if (this.session.ready) {
          this.fireOpenHandlers();
        } else {
          const off = this.session.on("ready", () => {
            off();
            if (this.bound)
              this.fireOpenHandlers();
          });
        }
        return;
      }
      if (env.type === "UI_CLOSE") {
        this.bound = false;
        for (const h of this.closeHandlers) {
          try {
            h();
          } catch (e) {
            console.warn("session.ui.onClose handler threw", e);
          }
        }
        return;
      }
      if (env.type === "UI_MESSAGE") {
        if (typeof env.requestId === "string") {
          this.dispatchRpcCall(env.channel, env.payload, env.requestId);
          return;
        }
        const set = this.channelHandlers.get(env.channel);
        if (!set || set.size === 0)
          return;
        for (const h of set) {
          try {
            h(env.payload);
          } catch (e) {
            console.warn(`session.ui.on(${env.channel}) threw`, e);
          }
        }
        return;
      }
      if (env.type === "UI_CANCEL") {
        const ctrl = this.inflightRpc.get(env.requestId);
        if (ctrl) {
          try {
            ctrl.abort();
          } catch {}
        }
        return;
      }
    }
    dispatchRpcCall(channel, payload, requestId) {
      const handler = this.rpcHandlers.get(channel);
      if (!handler) {
        this.sendRpcReply(channel, requestId, {
          ok: false,
          error: { message: `no handler registered for "${channel}"` }
        });
        return;
      }
      const ctrl = new AbortController;
      this.inflightRpc.set(requestId, ctrl);
      const ctx = { signal: ctrl.signal };
      const finish = (envelope) => {
        this.inflightRpc.delete(requestId);
        if (ctrl.signal.aborted)
          return;
        this.sendRpcReply(channel, requestId, envelope);
      };
      let result;
      try {
        result = handler(payload, ctx);
      } catch (e) {
        finish({ ok: false, error: rpcErrorFromUnknown(e) });
        return;
      }
      if (result && typeof result.then === "function") {
        result.then((v) => finish({ ok: true, result: v }), (e) => finish({ ok: false, error: rpcErrorFromUnknown(e) }));
      } else {
        finish({ ok: true, result });
      }
    }
    sendRpcReply(channel, requestId, payload) {
      if (!this.bound)
        return;
      const seq = this.nextSeq++;
      const envelope = { type: "UI_SEND", channel, payload, seq, requestId };
      this.session.sendOneShot(envelope);
    }
  }

  // ../vendor/miniapp/dist/modules/storage.js
  class SimpleStorage {
    constructor(session) {
      this.session = session;
    }
    async get(key) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_GET,
        key
      });
      return result?.value ?? null;
    }
    async set(key, value) {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_SET,
        key,
        value
      });
    }
    async delete(key) {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_DELETE,
        key
      });
    }
    async keys() {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_LIST
      });
      return result?.keys ?? [];
    }
    async list() {
      return this.keys();
    }
    async clear() {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_CLEAR
      });
    }
    async has(key) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_HAS,
        key
      });
      return !!result?.has;
    }
    async getAll() {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_GET_ALL
      });
      return result?.values ?? {};
    }
    async setMultiple(values) {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_SET_MULTIPLE,
        values
      });
    }
    async flush() {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_FLUSH
      });
    }
  }

  // ../vendor/miniapp/dist/modules/speaker.js
  class SpeakerModule {
    constructor(session) {
      this.session = session;
      this._state = "idle";
      this._lastEvent = { state: "idle" };
    }
    get state() {
      return this._state;
    }
    get isPlaying() {
      return this._state === "playing";
    }
    async play(options) {
      await this.session.sendRequest({
        type: MiniappRequestType.PLAY_AUDIO,
        audioUrl: options.audioUrl,
        volume: options.volume,
        stopOtherAudio: options.stopOtherAudio ?? false
      }, { timeoutMs: 0 });
    }
    async speak(text, options = {}) {
      try {
        const result = await this.session.sendRequest({
          type: MiniappRequestType.SPEAK,
          text,
          voice_id: options.voice_id,
          voice_settings: options.voice_settings,
          volume: options.volume,
          stopOtherAudio: options.stopOtherAudio ?? false
        }, { timeoutMs: 0 });
        return result ?? { completed: true };
      } catch (err) {
        if (err && typeof err === "object" && "code" in err) {
          throw err;
        }
        throw { code: MiniappErrorCode.INTERNAL, message: String(err) };
      }
    }
    stop() {
      this.session.sendOneShot({ type: MiniappRequestType.STOP_AUDIO });
    }
    onStateChange(handler) {
      return this.session.on("speakerState", handler);
    }
    _applyState(event) {
      if (event.state === this._state && event.state !== "error")
        return;
      this._state = event.state;
      this._lastEvent = event;
    }
    _getLastEvent() {
      return { ...this._lastEvent };
    }
  }

  // ../vendor/miniapp/dist/modules/stream.js
  class StreamModule {
    constructor(session) {
      this.session = session;
    }
    async startStream(options = {}) {
      if (options.direct !== undefined) {
        return this.session.sendRequest({
          type: MiniappRequestType.STREAM_START,
          streamUrl: options.direct,
          video: options.video,
          audio: options.audio,
          sound: options.sound ?? true,
          ...options.authToken ? { authToken: options.authToken } : {}
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.MANAGED_STREAM_START,
        restreamDestinations: options.destinations,
        video: options.video,
        audio: options.audio,
        sound: options.sound ?? true,
        ingest: options.ingest
      });
    }
    async stop(streamId) {
      await this.session.sendRequest({
        type: MiniappRequestType.STREAM_STOP,
        streamId
      });
    }
  }

  // ../vendor/miniapp/dist/modules/system.js
  class SystemModule {
    constructor(session) {
      this.session = session;
    }
    async share(options) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.SHARE,
        ...options
      });
      return result ?? { success: false };
    }
    openUrl(url) {
      this.session.sendOneShot({
        type: MiniappRequestType.OPEN_URL,
        url
      });
    }
    async copyToClipboard(text) {
      await this.session.sendRequest({
        type: MiniappRequestType.COPY_CLIPBOARD,
        text
      });
    }
    async download(options) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.DOWNLOAD,
        ...options
      });
      return result ?? { success: false };
    }
  }

  // ../vendor/miniapp/dist/modules/miniapps.js
  class MiniappsModule {
    constructor(session) {
      this.session = session;
    }
    async list(opts) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.MINIAPPS_LIST,
        includeIncompatible: opts?.includeIncompatible ?? false
      });
      return result ?? [];
    }
    async start(packageName) {
      await this.session.sendRequest({
        type: MiniappRequestType.MINIAPPS_START,
        packageName
      });
    }
    async stop(packageName) {
      await this.session.sendRequest({
        type: MiniappRequestType.MINIAPPS_STOP,
        packageName
      });
    }
  }

  // ../vendor/miniapp/dist/modules/actions.js
  var HANDLER_WAIT_MS = 5000;

  class ActionsModule {
    constructor(session) {
      this.session = session;
      this.handlers = new Map;
      this.buffered = new Map;
    }
    invoke(packageName, actionId, params, opts) {
      return this.session.sendRequest({
        type: MiniappRequestType.ACTION_INVOKE,
        targetPackageName: packageName,
        actionId,
        params: params ?? {},
        ...opts?.timeoutMs != null ? { timeoutMs: opts.timeoutMs } : {}
      });
    }
    handle(actionId, handler) {
      if (this.handlers.has(actionId)) {
        throw new Error(`session.actions.handle: a handler is already registered for "${actionId}"`);
      }
      this.handlers.set(actionId, handler);
      const waiting = this.buffered.get(actionId);
      if (waiting) {
        this.buffered.delete(actionId);
        for (const call of waiting) {
          clearTimeout(call.timer);
          this.dispatch(call.callId, actionId, call.params, call.ctx);
        }
      }
      return () => {
        if (this.handlers.get(actionId) === handler)
          this.handlers.delete(actionId);
      };
    }
    _deliver(callId, actionId, params, ctx) {
      if (this.handlers.has(actionId)) {
        this.dispatch(callId, actionId, params, ctx);
        return;
      }
      const timer = setTimeout(() => {
        const arr2 = this.buffered.get(actionId);
        if (arr2) {
          const idx = arr2.findIndex((c) => c.callId === callId);
          if (idx >= 0)
            arr2.splice(idx, 1);
          if (arr2.length === 0)
            this.buffered.delete(actionId);
        }
        this.sendResult(callId, false, undefined, {
          code: MiniappErrorCode.NO_ACTION_HANDLER,
          message: `No handler registered for action "${actionId}"`
        });
      }, HANDLER_WAIT_MS);
      const arr = this.buffered.get(actionId) ?? [];
      arr.push({ callId, params, ctx, timer });
      this.buffered.set(actionId, arr);
    }
    async dispatch(callId, actionId, params, ctx) {
      const handler = this.handlers.get(actionId);
      if (!handler)
        return;
      try {
        const result = await handler(params, ctx);
        this.sendResult(callId, true, result ?? null);
      } catch (e) {
        this.sendResult(callId, false, undefined, {
          code: MiniappErrorCode.INTERNAL,
          message: e?.message ?? "action handler threw"
        });
      }
    }
    sendResult(callId, ok, result, error) {
      this.session.sendOneShot({
        type: MiniappRequestType.ACTION_RESULT,
        callId,
        ok,
        ...ok ? { result } : { error }
      });
    }
  }

  // ../vendor/miniapp/dist/modules/base64.js
  var ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  var LOOKUP = (() => {
    const t = new Int16Array(256).fill(-1);
    for (let i = 0;i < ALPHABET.length; i++)
      t[ALPHABET.charCodeAt(i)] = i;
    t[61] = 0;
    return t;
  })();
  function toUint8Array(input) {
    if (input instanceof Uint8Array)
      return input;
    if (input instanceof ArrayBuffer)
      return new Uint8Array(input);
    return new Uint8Array(input.buffer, input.byteOffset, input.byteLength);
  }
  function bytesToBase64(input) {
    const bytes = input instanceof Uint8Array ? input : new Uint8Array(input);
    const len = bytes.length;
    let out = "";
    let i = 0;
    for (;i + 2 < len; i += 3) {
      const n = bytes[i] << 16 | bytes[i + 1] << 8 | bytes[i + 2];
      out += ALPHABET[n >> 18 & 63] + ALPHABET[n >> 12 & 63] + ALPHABET[n >> 6 & 63] + ALPHABET[n & 63];
    }
    const rem = len - i;
    if (rem === 1) {
      const n = bytes[i] << 16;
      out += ALPHABET[n >> 18 & 63] + ALPHABET[n >> 12 & 63] + "==";
    } else if (rem === 2) {
      const n = bytes[i] << 16 | bytes[i + 1] << 8;
      out += ALPHABET[n >> 18 & 63] + ALPHABET[n >> 12 & 63] + ALPHABET[n >> 6 & 63] + "=";
    }
    return out;
  }
  function base64ToBytes(b64) {
    let validChars = 0;
    let pad = 0;
    for (let i = 0;i < b64.length; i++) {
      const c = b64.charCodeAt(i);
      if (c === 61) {
        pad++;
        validChars++;
      } else if (LOOKUP[c] !== -1) {
        validChars++;
      }
    }
    const fullGroups = Math.floor(validChars / 4);
    const remChars = validChars - fullGroups * 4;
    let outLen = fullGroups * 3 - (pad > 0 && remChars === 0 ? pad : 0);
    if (remChars === 2)
      outLen += 1;
    else if (remChars === 3)
      outLen += 2;
    if (outLen < 0)
      outLen = 0;
    const out = new Uint8Array(outLen);
    let acc = 0;
    let bits = 0;
    let o = 0;
    for (let i = 0;i < b64.length && o < outLen; i++) {
      const c = b64.charCodeAt(i);
      if (c === 61)
        break;
      const v = LOOKUP[c];
      if (v === -1)
        continue;
      acc = acc << 6 | v;
      bits += 6;
      if (bits >= 8) {
        bits -= 8;
        out[o++] = acc >> bits & 255;
      }
    }
    return out;
  }

  // ../vendor/miniapp/dist/modules/blob.js
  var BLOB_WRITE_CHUNK_BYTES = 1024 * 1024;
  var BLOB_WRITE_CHUNK_B64 = Math.floor(BLOB_WRITE_CHUNK_BYTES / 3) * 4;
  var BLOB_READ_ALL_MAX_BYTES = 32 * 1024 * 1024;

  class BlobWriter {
    constructor(session, key) {
      this.session = session;
      this.key = key;
      this.settled = false;
    }
    async write(chunk) {
      this.assertOpen();
      const bytes = toUint8Array(chunk);
      for (let off = 0;off < bytes.length; off += BLOB_WRITE_CHUNK_BYTES) {
        await this.send(bytesToBase64(bytes.subarray(off, off + BLOB_WRITE_CHUNK_BYTES)));
      }
    }
    async writeBase64(b64) {
      this.assertOpen();
      for (let off = 0;off < b64.length; off += BLOB_WRITE_CHUNK_B64) {
        await this.send(b64.slice(off, off + BLOB_WRITE_CHUNK_B64));
      }
    }
    async writeAt(offset, chunk) {
      this.assertOpen();
      await this.session.sendRequest({
        type: MiniappRequestType.BLOB_WRITE,
        key: this.key,
        offset,
        base64: bytesToBase64(toUint8Array(chunk))
      });
    }
    async close(meta) {
      this.assertOpen();
      this.settled = true;
      return this.session.sendRequest({ type: MiniappRequestType.BLOB_COMMIT, key: this.key, meta });
    }
    async abort() {
      if (this.settled)
        return;
      this.settled = true;
      await this.session.sendRequest({ type: MiniappRequestType.BLOB_ABORT, key: this.key });
    }
    assertOpen() {
      if (this.settled)
        throw new Error("BlobWriter is already closed/aborted");
    }
    send(base64) {
      return this.session.sendRequest({
        type: MiniappRequestType.BLOB_WRITE,
        key: this.key,
        base64
      });
    }
  }

  class BlobReader {
    constructor(session, handle, meta) {
      this.session = session;
      this.handle = handle;
      this.meta = meta;
      this.closed = false;
    }
    async read(maxBytes = BLOB_WRITE_CHUNK_BYTES) {
      if (this.closed)
        throw new Error("BlobReader is closed");
      const res = await this.session.sendRequest({
        type: MiniappRequestType.BLOB_READ,
        handle: this.handle,
        maxBytes
      });
      return { bytes: base64ToBytes(res?.base64 ?? ""), done: !!res?.done };
    }
    async close() {
      if (this.closed)
        return;
      this.closed = true;
      await this.session.sendRequest({ type: MiniappRequestType.BLOB_CLOSE_READ, handle: this.handle });
    }
  }

  class BlobModule {
    constructor(session) {
      this.session = session;
    }
    async set(key, data, opts = {}) {
      const writer = await this.createWriteStream(key, opts);
      try {
        if (typeof data === "string")
          await writer.writeBase64(data);
        else
          await writer.write(data);
        return await writer.close();
      } catch (err) {
        await writer.abort().catch(() => {});
        throw err;
      }
    }
    setFromUrl(key, url, opts = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.BLOB_SET_FROM_URL,
        key,
        url,
        mimeType: opts.mimeType,
        name: opts.name,
        headers: opts.headers,
        meta: opts.meta
      });
    }
    importFile(opts = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.BLOB_IMPORT,
        key: opts.key,
        mimeType: opts.mimeType,
        meta: opts.meta
      });
    }
    async createWriteStream(key, opts = {}) {
      const res = await this.session.sendRequest({
        type: MiniappRequestType.BLOB_CREATE,
        key,
        mimeType: opts.mimeType,
        name: opts.name,
        meta: opts.meta
      });
      return new BlobWriter(this.session, res.key);
    }
    get(key) {
      return this.session.sendRequest({ type: MiniappRequestType.BLOB_GET, key });
    }
    stat(key) {
      return this.get(key);
    }
    async has(key) {
      return await this.get(key) !== null;
    }
    async keys() {
      return (await this.list()).map((m) => m.key);
    }
    async list() {
      const res = await this.session.sendRequest({ type: MiniappRequestType.BLOB_LIST });
      return res?.blobs ?? [];
    }
    async createReadStream(key) {
      const res = await this.session.sendRequest({
        type: MiniappRequestType.BLOB_OPEN_READ,
        key
      });
      return new BlobReader(this.session, res.handle, res.meta);
    }
    async bytes(key) {
      let reader;
      try {
        reader = await this.createReadStream(key);
      } catch {
        return null;
      }
      const parts = [];
      let total = 0;
      try {
        for (;; ) {
          const { bytes, done } = await reader.read();
          if (bytes.length) {
            total += bytes.length;
            if (total > BLOB_READ_ALL_MAX_BYTES) {
              throw new Error(`Blob "${key}" exceeds the in-memory read cap — stream it with createReadStream()`);
            }
            parts.push(bytes);
          }
          if (done)
            break;
        }
      } finally {
        await reader.close().catch(() => {});
      }
      const out = new Uint8Array(total);
      let at = 0;
      for (const p of parts) {
        out.set(p, at);
        at += p.length;
      }
      return out;
    }
    usage() {
      return this.session.sendRequest({
        type: MiniappRequestType.BLOB_USAGE
      });
    }
    async delete(key) {
      await this.session.sendRequest({ type: MiniappRequestType.BLOB_DELETE, key });
    }
    async clear() {
      await this.session.sendRequest({ type: MiniappRequestType.BLOB_CLEAR });
    }
    async share(key) {
      const res = await this.session.sendRequest({
        type: MiniappRequestType.BLOB_SHARE,
        key
      });
      return res ?? { success: false };
    }
  }

  // ../vendor/miniapp/dist/session.js
  var ALL_PERMISSION_TYPES = [
    "location",
    "microphone",
    "camera",
    "notifications",
    "calendar"
  ];

  class NotConnectedError extends Error {
    constructor(message = "MiniappSession is not connected") {
      super(message);
      this.code = MiniappErrorCode.NOT_CONNECTED;
      this.name = "NotConnectedError";
    }
  }
  var DEFAULT_CONNECT_TIMEOUT_MS = 1e4;
  var DEFAULT_REQUEST_TIMEOUT_MS = 60000;

  class MiniappSession {
    constructor(options = {}) {
      this.capabilities = null;
      this.userId = "";
      this.packageName = "";
      this.visibility = "foreground";
      this.colorScheme = "light";
      this.ready = false;
      this.emitter = new import__.default;
      this.authState = null;
      this.authWaiters = new Set;
      this.authRefreshPromise = null;
      this.outboundQueue = [];
      this.pendingRequests = new Map;
      this.connectPromise = null;
      this.disposed = false;
      this._permissions = {
        location: false,
        microphone: false,
        camera: false,
        notifications: false,
        calendar: false
      };
      this.transport = createTransport(options);
      this.connectTimeoutMs = options.connectTimeoutMs ?? DEFAULT_CONNECT_TIMEOUT_MS;
      const injected = getMentraOSGlobals();
      this.packageName = options.packageName ?? injected.packageName ?? "";
      if (injected.colorScheme === "light" || injected.colorScheme === "dark") {
        this.colorScheme = injected.colorScheme;
      }
      this.auth = new AuthModule(this);
      this.events = new EventManager(this);
      this.speaker = new SpeakerModule(this);
      this.camera = new CameraModule(this);
      this.canvas = new CanvasManager(this);
      this.cloud = new CloudModule(this);
      this.dashboard = new DashboardAPI(this);
      this.display = new DisplayManager(this);
      this.glasses = new GlassesModule(this);
      this.heading = new HeadingModule(this);
      this.imu = new ImuModule(this);
      this.input = new InputModule(this);
      this.led = new LedModule(this);
      this.location = new LocationModule(this);
      this.mic = new MicModule(this);
      this.navigation = new NavigationModule(this);
      this.permissions = new PermissionsModule(this);
      this.phone = new PhoneModule(this);
      this.storage = new SimpleStorage(this);
      this.blob = new BlobModule(this);
      this.stream = new StreamModule(this);
      this.system = new SystemModule(this);
      this.transcription = new TranscriptionModule(this);
      this.translation = new TranslationModule(this);
      this.ui = new UIModuleImpl(this);
      this.miniapps = new MiniappsModule(this);
      this.actions = new ActionsModule(this);
    }
    _hasManifestPermission(manifestKey) {
      const canonical = manifestKeyToCanonical(manifestKey);
      if (!canonical)
        return false;
      return this._permissions[canonical] === true;
    }
    _getPermissions() {
      return { ...this._permissions };
    }
    _getAuth() {
      return this.authState ? { ...this.authState } : null;
    }
    _waitForAuth(minTtlMs, timeoutMs = 1e4) {
      const current = this.authState;
      if (current && this.authHasTtl(current, minTtlMs)) {
        return Promise.resolve({ ...current });
      }
      this.requestAuthRefresh(minTtlMs);
      return new Promise((resolve, reject) => {
        const waiter = {
          minTtlMs,
          resolve,
          reject,
          timer: setTimeout(() => {
            this.authWaiters.delete(waiter);
            reject(new NotConnectedError("Miniapp auth token is not available"));
          }, timeoutMs)
        };
        this.authWaiters.add(waiter);
      });
    }
    _subscribe(streamType, handler) {
      return this.events.subscribe(streamType, handler);
    }
    connect() {
      if (this.disposed) {
        return Promise.reject(new NotConnectedError("MiniappSession was disposed"));
      }
      if (this.connectPromise)
        return this.connectPromise;
      const readyPromise = new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
          const err = new Error("MiniappSession: CONNECT_ACK timeout");
          this.failAllPending({ code: MiniappErrorCode.NOT_CONNECTED, message: err.message });
          this.emitter.emit("error", err);
          reject(err);
        }, this.connectTimeoutMs);
        this.emitter.once("ready", () => {
          clearTimeout(timer);
          resolve();
        });
        this.emitter.once("error", (err) => {
          clearTimeout(timer);
          reject(err);
        });
      });
      this.connectPromise = (async () => {
        this.transport.onMessage((raw) => this.handleIncoming(raw));
        this.transport.onDisconnect((reason) => this.handleTransportDisconnect(reason));
        await this.transport.open();
        const requestId = makeRequestId();
        const connectPayload = {
          type: MiniappRequestType.CONNECT,
          packageName: this.packageName
        };
        this.transport.send(serializeEnvelope({ payload: connectPayload, requestId }));
        await readyPromise;
      })();
      return this.connectPromise;
    }
    waitForReady() {
      if (this.ready)
        return Promise.resolve();
      return this.connect();
    }
    isConnected() {
      return this.ready && this.transport.isOpen();
    }
    disconnect() {
      if (this.disposed)
        return;
      this.disposed = true;
      try {
        this.emitter.emit("beforeDisconnect", "disconnect called");
      } catch (err) {
        console.warn("[MiniappSession] beforeDisconnect handler threw:", err);
      }
      this.failAllPending({ code: MiniappErrorCode.REQUEST_ABORTED, message: "Session disconnected" });
      try {
        this.transport.close();
      } catch {}
      this.ready = false;
      this.emitter.emit("disconnect", "disconnect called");
    }
    sendOneShot(payload) {
      const envelope = { payload };
      this.enqueueOrSend(serializeEnvelope(envelope));
    }
    sendRequest(payload, opts) {
      if (this.disposed) {
        return Promise.reject(new NotConnectedError);
      }
      const requestId = makeRequestId();
      const envelope = { payload, requestId };
      const timeoutMs = opts?.timeoutMs ?? DEFAULT_REQUEST_TIMEOUT_MS;
      return new Promise((resolve, reject) => {
        const timer = timeoutMs > 0 ? setTimeout(() => {
          const pending = this.pendingRequests.get(requestId);
          if (!pending)
            return;
          this.pendingRequests.delete(requestId);
          pending.reject({
            code: MiniappErrorCode.ACTION_TIMEOUT,
            message: "Request timed out waiting for a response from the host"
          });
        }, timeoutMs) : undefined;
        this.pendingRequests.set(requestId, {
          requestId,
          resolve,
          reject,
          timer
        });
        this.enqueueOrSend(serializeEnvelope(envelope));
      });
    }
    on(event, handler) {
      this.emitter.on(event, handler);
      return () => this.emitter.off(event, handler);
    }
    off(event, handler) {
      this.emitter.off(event, handler);
    }
    onBeforeDisconnect(handler) {
      return this.on("beforeDisconnect", handler);
    }
    onVisibilityChange(handler) {
      return this.on("visibility", handler);
    }
    onCapabilitiesChange(handler) {
      return this.on("capabilities", handler);
    }
    onColorSchemeChange(handler) {
      return this.on("colorScheme", handler);
    }
    enqueueOrSend(raw) {
      if (this.ready) {
        try {
          this.transport.send(raw);
        } catch (err) {
          this.emitter.emit("error", err);
        }
        return;
      }
      this.outboundQueue.push(raw);
    }
    flushQueue() {
      const queue = this.outboundQueue.splice(0);
      for (const raw of queue) {
        try {
          this.transport.send(raw);
        } catch (err) {
          this.emitter.emit("error", err);
        }
      }
    }
    handleIncoming(raw) {
      const envelope = parseEnvelope(raw);
      if (!envelope)
        return;
      const payload = envelope.payload;
      const type = payload?.type;
      switch (type) {
        case MiniappResponseType.CONNECT_ACK: {
          const ack = payload;
          this.userId = ack.userId ?? "";
          if (ack.packageName)
            this.packageName = ack.packageName;
          this.capabilities = ack.capabilities ?? null;
          if (ack.visibility)
            this.visibility = ack.visibility;
          if (ack.colorScheme === "light" || ack.colorScheme === "dark") {
            this.colorScheme = ack.colorScheme;
          }
          if (ack.auth) {
            this.applyAuth(ack.auth);
            if (!this.userId)
              this.userId = ack.auth.mentraUserId;
          }
          if (ack.permissions)
            this.applyPermissions(ack.permissions);
          this.ready = true;
          this.flushQueue();
          this.emitter.emit("ready");
          return;
        }
        case MiniappResponseType.AUTH_UPDATE: {
          const next = payload.auth;
          if (next) {
            this.applyAuth(next);
            if (!this.userId)
              this.userId = next.mentraUserId;
          }
          return;
        }
        case MiniappResponseType.PERMISSIONS_UPDATE: {
          const next = payload.permissions;
          if (next)
            this.applyPermissions(next);
          return;
        }
        case MiniappResponseType.SPEAKER_STATE: {
          const state = payload.state;
          if (!state)
            return;
          const event = {
            state,
            errorCode: payload.errorCode,
            errorMessage: payload.errorMessage,
            durationMs: payload.durationMs
          };
          this.speaker._applyState(event);
          this.emitter.emit("speakerState", event);
          return;
        }
        case MiniappRequestType.PING: {
          const pong = { type: MiniappResponseType.PONG };
          const env = {
            payload: pong,
            ...envelope.requestId ? { requestId: envelope.requestId } : {}
          };
          try {
            this.transport.send(serializeEnvelope(env));
          } catch {}
          return;
        }
        case MiniappResponseType.EVENT: {
          const streamType = payload.streamType;
          if (!streamType)
            return;
          this.events._forwardEvent(streamType, payload.data);
          return;
        }
        case MiniappResponseType.ACTION_CALL: {
          const callId = payload.callId;
          const actionId = payload.actionId;
          if (!callId || !actionId)
            return;
          const params = payload.params ?? {};
          const callerPackageName = payload.callerPackageName ?? "";
          this.actions._deliver(callId, actionId, params, { callerPackageName });
          return;
        }
        case MiniappResponseType.CAPABILITIES_UPDATE: {
          const cap = payload.capabilities ?? null;
          this.capabilities = cap;
          this.emitter.emit("capabilities", cap);
          return;
        }
        case MiniappResponseType.VISIBILITY_CHANGE: {
          const next = payload.visibility;
          if (next === "foreground" || next === "background") {
            this.visibility = next;
            this.emitter.emit("visibility", next);
          }
          return;
        }
        case MiniappResponseType.COLOR_SCHEME_CHANGE: {
          const next = payload.colorScheme;
          if (next === "light" || next === "dark") {
            this.colorScheme = next;
            this.emitter.emit("colorScheme", next);
          }
          return;
        }
        case MiniappResponseType.REQUEST_RESULT: {
          const requestId = envelope.requestId;
          if (!requestId)
            return;
          const pending = this.pendingRequests.get(requestId);
          if (!pending)
            return;
          this.pendingRequests.delete(requestId);
          if (pending.timer)
            clearTimeout(pending.timer);
          if (payload.ok === false) {
            const err = payload.error ?? {
              code: MiniappErrorCode.INTERNAL,
              message: "Unknown error"
            };
            pending.reject(err);
          } else {
            pending.resolve(payload.data ?? null);
          }
          return;
        }
        case MiniappResponseType.WILL_DISCONNECT: {
          const reason = payload.reason ?? "phone unregistering";
          try {
            this.emitter.emit("beforeDisconnect", reason);
          } catch (err) {
            console.warn("[MiniappSession] beforeDisconnect handler threw:", err);
          }
          return;
        }
        case MiniappResponseType.ERROR: {
          const err = new Error(payload.message ?? "MiniappSession error");
          this.emitter.emit("error", err);
          return;
        }
        default:
          return;
      }
    }
    handleTransportDisconnect(reason) {
      this.ready = false;
      this.failAllPending({ code: MiniappErrorCode.NOT_CONNECTED, message: `Transport disconnected: ${reason}` });
      this.emitter.emit("disconnect", reason);
    }
    failAllPending(error) {
      for (const pending of this.pendingRequests.values()) {
        if (pending.timer)
          clearTimeout(pending.timer);
        pending.reject(error);
      }
      this.pendingRequests.clear();
      for (const waiter of Array.from(this.authWaiters)) {
        clearTimeout(waiter.timer);
        this.authWaiters.delete(waiter);
        waiter.reject(new NotConnectedError(error.message));
      }
    }
    authHasTtl(auth, minTtlMs) {
      return auth.expiresAt - Date.now() > minTtlMs;
    }
    requestAuthRefresh(minTtlMs) {
      if (this.authRefreshPromise)
        return this.authRefreshPromise;
      if (!this.ready || !this.transport.isOpen())
        return Promise.resolve(null);
      this.authRefreshPromise = this.sendRequest({
        type: MiniappRequestType.AUTH_REFRESH,
        minTtlMs
      }).then((result) => {
        const auth = result?.auth;
        if (auth)
          this.applyAuth(auth);
        return auth ?? null;
      }).catch((err) => {
        console.warn("[MiniappSession] auth refresh failed:", err);
        return null;
      }).finally(() => {
        this.authRefreshPromise = null;
      });
      return this.authRefreshPromise;
    }
    applyAuth(next) {
      this.authState = { ...next };
      for (const waiter of Array.from(this.authWaiters)) {
        if (!this.authHasTtl(next, waiter.minTtlMs))
          continue;
        clearTimeout(waiter.timer);
        this.authWaiters.delete(waiter);
        waiter.resolve({ ...next });
      }
      this.emitter.emit("auth", { ...next });
    }
    applyPermissions(next) {
      let changed = false;
      const updated = { ...this._permissions };
      for (const k of ALL_PERMISSION_TYPES) {
        const v = next[k] === true;
        if (updated[k] !== v) {
          updated[k] = v;
          changed = true;
        }
      }
      if (changed) {
        this._permissions = updated;
        this.emitter.emit("permissions", { ...updated });
      }
    }
  }
  function manifestKeyToCanonical(manifestKey) {
    switch (manifestKey.toUpperCase()) {
      case "MICROPHONE":
        return "microphone";
      case "CAMERA":
        return "camera";
      case "LOCATION":
      case "BACKGROUND_LOCATION":
        return "location";
      case "READ_NOTIFICATIONS":
      case "POST_NOTIFICATIONS":
        return "notifications";
      case "CALENDAR":
        return "calendar";
      default:
        return null;
    }
  }

  // ../vendor/miniapp/dist/background/register.js
  function registerMiniapp(handler, options = {}) {
    const g = globalThis;
    g.__mentraInitCallback = (_sessionId) => {
      const session = new MiniappSession(options);
      try {
        const result = handler(session);
        if (result && typeof result.then === "function") {
          result.catch((err) => {
            console.error("[mentra-miniapp] registerMiniapp handler rejected:", err);
          });
        }
      } catch (err) {
        console.error("[mentra-miniapp] registerMiniapp handler threw:", err);
      }
      session.connect().catch((err) => {
        console.error("[mentra-miniapp] session.connect() rejected:", err);
        try {
          const message = err instanceof Error ? err.message : String(err);
          const stack = err instanceof Error && err.stack ? err.stack : "";
          g.__hostError?.(JSON.stringify({ message: `session.connect() failed: ${message}`, stack }));
        } catch {}
      });
    };
  }
  // src/shared/types.ts
  var REVERSE_KNOWN_RANK_LIMITS = [100, 20000];
  var SETTINGS_SCHEMA_VERSION = 3;
  var HUD_WORD_ROWS = 3;
  var HUD_CAPTION_LINES = 3;
  var DEFAULT_SETTINGS = {
    schemaVersion: SETTINGS_SCHEMA_VERSION,
    sourceLanguage: "zh",
    targetLanguage: "en",
    swapDirection: false,
    proficiency: 33,
    mode: "gloss-captions",
    wordUpgrades: false,
    displayLines: HUD_CAPTION_LINES,
    displayWidth: 1,
    wordBreaking: false,
    pinyinDisplay: true,
    interimTrigger: true,
    fastCooldown: true,
    reverseGloss: true,
    reverseKnownRank: 500,
    prefs: {}
  };
  function wordRowsFor(_mode) {
    return HUD_WORD_ROWS;
  }
  function knownRankFor(proficiency) {
    const raw = Number.isFinite(proficiency) ? proficiency : 50;
    const p = Math.min(100, Math.max(0, raw)) / 100;
    return Math.round(300 * Math.pow(50, p));
  }
  function inputLanguage(settings) {
    return settings.swapDirection ? settings.targetLanguage : settings.sourceLanguage;
  }
  function outputLanguage(settings) {
    return settings.swapDirection ? settings.sourceLanguage : settings.targetLanguage;
  }

  // src/shared/blocks.ts
  var BLOCK_KIT_VERSION = 1;

  // src/shared/serverContract.ts
  var SETTABLE_KEYS = [
    "reverseGloss",
    "reverseKnownRank",
    "wordUpgrades",
    "pinyinDisplay",
    "interimTrigger",
    "fastCooldown",
    "wordBreaking",
    "proficiency",
    "displayLines",
    "displayWidth"
  ];
  var TUNABLE_LIMITS = {
    glossCooldownMs: [0, 5000],
    cooldownBypassChars: [1, 100],
    interimStableMs: [50, 3000],
    interimGrowthChars: [1, 50],
    wordTtlMs: [3000, 120000],
    wordDedupMs: [1000, 300000],
    reverseMaxWords: [1, 3]
  };
  var DEFAULT_TUNABLES = {
    glossCooldownMs: 600,
    cooldownBypassChars: 8,
    interimStableMs: 300,
    interimGrowthChars: 6,
    wordTtlMs: 25000,
    wordDedupMs: 20000,
    reverseMaxWords: 2
  };

  // src/shared/defaultConfig.ts
  var DEFAULT_CONFIG = {
    kit: BLOCK_KIT_VERSION,
    revision: "bundled",
    tunables: { ...DEFAULT_TUNABLES },
    settings: [
      {
        type: "toggle",
        key: "reverseGloss",
        title: "Gloss my {output} too",
        detail: "When you fall back to {output} mid-sentence, show it in {input}",
        disabledWhen: { key: "mode", equals: "translation" }
      },
      {
        type: "select",
        key: "reverseKnownRank",
        title: "Skip the most common {output}",
        detail: "Words this frequent are never glossed back",
        options: [300, 500, 1000, 2000].map((rank) => ({ value: rank, label: `Top ${rank.toLocaleString("en-US")}` })),
        visibleWhen: { key: "reverseGloss", equals: true }
      }
    ],
    screens: [{ id: "reports", title: "Reports", period: true }],
    prefDefaults: {}
  };

  // src/background/identity.ts
  var CLIENT_VERSION = "1.0.21";
  var CLIENT_BUILD_ID = "6b658be";
  var SESSION_ID = randomId(10);
  var seq = 0;
  function nextRequestSeq() {
    seq += 1;
    return seq;
  }
  function newRequestId() {
    return randomId(12);
  }
  function randomId(length) {
    let out = Date.now().toString(36);
    while (out.length < length)
      out += Math.random().toString(36).slice(2);
    return out.slice(-length);
  }

  // src/background/glossTelemetry.ts
  class GlossTelemetry {
    previous = null;
    open = null;
    lastBackendRequestAt = null;
    noteBackendRequest(now = Date.now()) {
      this.lastBackendRequestAt = now;
    }
    msSinceBackendRequest(now = Date.now()) {
      return this.lastBackendRequestAt == null ? undefined : now - this.lastBackendRequestAt;
    }
    begin(attempt, now = Date.now()) {
      const requestId = newRequestId();
      const networkIdleMs = this.lastBackendRequestAt == null ? undefined : Math.max(0, now - this.lastBackendRequestAt);
      this.noteBackendRequest(now);
      this.open = { requestId, eligibleAt: attempt.eligibleAt };
      return {
        requestId,
        client: {
          version: CLIENT_VERSION,
          buildId: CLIENT_BUILD_ID,
          sessionId: SESSION_ID,
          current: {
            requestId,
            requestSeq: nextRequestSeq(),
            utteranceId: attempt.utteranceId,
            trigger: attempt.trigger,
            eligibleAt: attempt.eligibleAt,
            queueReason: attempt.queueReason,
            queueWaitMs: Math.max(0, now - attempt.eligibleAt),
            networkIdleMs
          },
          previousRequestMetrics: this.previous ?? undefined
        }
      };
    }
    noteResponse(requestId, roundTripMs, outcome, now = Date.now()) {
      if (this.open?.requestId === requestId)
        this.open.responseAt = now;
      this.previous = { requestId, roundTripMs, outcome };
    }
    noteRendered(requestId, now = Date.now()) {
      const open = this.open;
      if (!open || open.requestId !== requestId)
        return;
      if (this.previous?.requestId !== requestId)
        return;
      this.previous = {
        ...this.previous,
        renderMs: open.responseAt == null ? undefined : Math.max(0, now - open.responseAt),
        triggerToRenderMs: Math.max(0, now - open.eligibleAt)
      };
      this.open = null;
    }
    peekPrevious() {
      return this.previous;
    }
  }
  var glossTelemetry = new GlossTelemetry;

  // src/background/observability.ts
  var LEVEL_WEIGHT = {
    debug: 10,
    info: 20,
    warn: 30,
    error: 40,
    silent: 100
  };
  var CONFIGURED_LEVEL = "info".toLowerCase();
  var activeLevel = CONFIGURED_LEVEL in LEVEL_WEIGHT ? CONFIGURED_LEVEL : "info";
  function render(fields) {
    if (!fields)
      return "";
    const parts = [];
    for (const [key, value] of Object.entries(fields)) {
      if (value === undefined)
        continue;
      if (value instanceof Error) {
        parts.push(`${key}=${value.name}:${value.message}`);
        continue;
      }
      if (typeof value === "object" && value !== null) {
        try {
          parts.push(`${key}=${JSON.stringify(value)}`);
        } catch {
          parts.push(`${key}=[unserializable]`);
        }
        continue;
      }
      const text = String(value);
      parts.push(`${key}=${/\s/.test(text) ? JSON.stringify(text) : text}`);
    }
    return parts.length > 0 ? ` ${parts.join(" ")}` : "";
  }
  function createLogger(scope, bound = {}) {
    const emit = (level, message, fields) => {
      if (LEVEL_WEIGHT[level] < LEVEL_WEIGHT[activeLevel])
        return;
      const merged = fields ? { ...bound, ...fields } : bound;
      const line = `[linklingo:${scope}] ${message}${render(merged)}`;
      if (level === "error")
        console.error(line);
      else if (level === "warn")
        console.warn(line);
      else
        console.log(line);
    };
    return {
      debug: (message, fields) => emit("debug", message, fields),
      info: (message, fields) => emit("info", message, fields),
      warn: (message, fields) => emit("warn", message, fields),
      error: (message, fields) => emit("error", message, fields),
      child: (fields) => createLogger(scope, { ...bound, ...fields })
    };
  }

  class BackgroundDiagnostics {
    startedAt = Date.now();
    counters = {};
    timings = {};
    lastError = null;
    lastErrorAt = null;
    increment(name, by = 1) {
      this.counters[name] = (this.counters[name] ?? 0) + by;
    }
    observe(name, ms) {
      if (!Number.isFinite(ms) || ms < 0)
        return;
      const entry = this.timings[name] ?? { count: 0, total: 0, last: 0, max: 0 };
      entry.count += 1;
      entry.total += ms;
      entry.last = ms;
      if (ms > entry.max)
        entry.max = ms;
      this.timings[name] = entry;
    }
    recordError(message) {
      this.lastError = message;
      this.lastErrorAt = Date.now();
      this.increment("errors");
    }
    snapshot() {
      const timings = {};
      for (const [name, entry] of Object.entries(this.timings)) {
        timings[name] = {
          count: entry.count,
          avgMs: Math.round(entry.total / entry.count),
          lastMs: Math.round(entry.last),
          maxMs: Math.round(entry.max)
        };
      }
      return {
        startedAt: this.startedAt,
        uptimeSeconds: Math.round((Date.now() - this.startedAt) / 1000),
        counters: { ...this.counters },
        timings,
        lastError: this.lastError,
        lastErrorAt: this.lastErrorAt
      };
    }
  }
  var diagnostics = new BackgroundDiagnostics;
  var logLevel = activeLevel;

  // src/background/backend.ts
  var log = createLogger("api");
  var BACKEND_URL = "https://linklingo-miniapp-dev.mentraglass.com";
  log.info("backend target configured", { url: BACKEND_URL });
  var PRECONNECT_IDLE_MS = 20000;
  function preconnect(force = false) {
    const idle = glossTelemetry.msSinceBackendRequest();
    if (!force && idle != null && idle < PRECONNECT_IDLE_MS)
      return;
    glossTelemetry.noteBackendRequest();
    diagnostics.increment("preconnect.attempts");
    fetch(url("/ping"), { method: "GET" }).then(() => diagnostics.increment("preconnect.ok")).catch(() => diagnostics.increment("preconnect.failed"));
  }
  function url(path) {
    return `${BACKEND_URL.replace(/\/$/, "")}${path}`;
  }
  var prefsHeader = "";
  function setPrefs(prefs) {
    prefsHeader = Object.keys(prefs).length > 0 ? encodeURIComponent(JSON.stringify(prefs)) : "";
  }
  function authed(session, path, init) {
    const headers = new Headers(init.headers);
    if (prefsHeader && prefsHeader.length <= 2048)
      headers.set("X-LinkLingo-Prefs", prefsHeader);
    return session.auth.fetch(url(path), { ...init, headers });
  }
  async function describeFailure(label, res, durationMs) {
    let detail = "";
    try {
      const text = await res.text();
      try {
        detail = JSON.parse(text).error ?? text;
      } catch {
        detail = text;
      }
    } catch {
      detail = "";
    }
    diagnostics.increment(`${label}.http_${res.status}`);
    log.warn(`${label} rejected`, {
      status: res.status,
      durationMs,
      requestId: res.headers.get("x-request-id") ?? undefined,
      detail: detail ? detail.slice(0, 300) : undefined
    });
    if (res.status === 429)
      return "Translation quota exhausted";
    if (res.status === 503)
      return "Translation service unavailable";
    if (res.status === 401 || res.status === 403)
      return "Sign-in expired";
    return `${label} failed (${res.status})`;
  }
  async function requestGloss(session, body, attempt) {
    const started = Date.now();
    const { requestId, client } = glossTelemetry.begin(attempt, started);
    diagnostics.increment("gloss.requests");
    log.debug("gloss request", {
      requestId,
      contextChars: body.conversationContext.length,
      in: body.inputLanguage,
      out: body.outputLanguage,
      recentCount: body.recentWords.length,
      queueReason: attempt.queueReason,
      queueWaitMs: client.current.queueWaitMs
    });
    try {
      const res = await authed(session, "/api/gloss", {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-Request-Id": requestId },
        body: JSON.stringify({ ...body, client })
      });
      const durationMs = Date.now() - started;
      diagnostics.observe("gloss.roundTrip", durationMs);
      if (!res.ok) {
        glossTelemetry.noteResponse(requestId, durationMs, "error");
        const message = await describeFailure("gloss", res, durationMs);
        diagnostics.recordError(message);
        return { ok: false, message };
      }
      glossTelemetry.noteResponse(requestId, durationMs, "ok");
      const data = await res.json();
      const words = data.words ?? [];
      diagnostics.increment("gloss.ok");
      diagnostics.increment("gloss.words", words.length);
      log.info("gloss ok", {
        requestId,
        durationMs,
        queueWaitMs: client.current.queueWaitMs,
        words: words.length,
        serverMs: data.profiling?.totalMs,
        modelMs: data.profiling?.llmMs ?? data.profiling?.geminiMs
      });
      return {
        ok: true,
        data: {
          words,
          profiling: { ...data.profiling, clientRoundTripMs: durationMs, requestId }
        }
      };
    } catch (err) {
      const durationMs = Date.now() - started;
      glossTelemetry.noteResponse(requestId, durationMs, "error");
      diagnostics.increment("gloss.transport_error");
      diagnostics.recordError("Cannot reach LinkLingo backend");
      log.error("gloss transport failure", { requestId, durationMs, url: BACKEND_URL, error: err });
      return { ok: false, message: "Cannot reach LinkLingo backend" };
    }
  }
  function reportTranscript(session, body) {
    const started = Date.now();
    const payload = { ...body, clientVersion: CLIENT_VERSION, clientBuildId: CLIENT_BUILD_ID };
    diagnostics.increment("transcript.reports");
    glossTelemetry.noteBackendRequest(started);
    authed(session, "/api/transcript", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    }).then((res) => {
      diagnostics.observe("transcript.roundTrip", Date.now() - started);
      if (!res.ok) {
        diagnostics.increment(`transcript.http_${res.status}`);
        log.debug("transcript report rejected", { status: res.status, disposition: body.disposition });
        return;
      }
      diagnostics.increment("transcript.ok");
    }).catch((err) => {
      diagnostics.increment("transcript.transport_error");
      log.debug("transcript report failed", { error: err });
    });
  }
  async function requestFeedback(session, body) {
    const started = Date.now();
    diagnostics.increment("feedback.requests");
    try {
      const res = await authed(session, "/api/feedback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      const durationMs = Date.now() - started;
      diagnostics.observe("feedback.roundTrip", durationMs);
      if (!res.ok) {
        const message = await describeFailure("feedback", res, durationMs);
        return { ok: false, message };
      }
      const data = await res.json();
      diagnostics.increment("feedback.ok");
      log.info("feedback answered", { durationMs, model: data.model, answerChars: data.answer.length });
      return { ok: true, data };
    } catch (err) {
      diagnostics.increment("feedback.transport_error");
      log.error("feedback transport failure", { url: BACKEND_URL, error: err });
      return { ok: false, message: "Cannot reach LinkLingo backend" };
    }
  }
  async function getJson(session, label, path) {
    const started = Date.now();
    diagnostics.increment(`${label}.requests`);
    try {
      const res = await authed(session, path, { method: "GET" });
      const durationMs = Date.now() - started;
      diagnostics.observe(`${label}.roundTrip`, durationMs);
      if (!res.ok)
        return { ok: false, message: await describeFailure(label, res, durationMs) };
      diagnostics.increment(`${label}.ok`);
      return { ok: true, data: await res.json() };
    } catch (err) {
      diagnostics.increment(`${label}.transport_error`);
      log.error(`${label} transport failure`, { url: BACKEND_URL, error: err });
      return { ok: false, message: "Cannot reach LinkLingo backend" };
    }
  }
  function requestConfig(session) {
    return getJson(session, "config", "/api/config");
  }
  function requestView(session, screen, query) {
    const params = new URLSearchParams(query);
    return getJson(session, "views", `/api/views/${encodeURIComponent(screen)}?${params}`);
  }
  async function requestUpgrade(session, body) {
    const started = Date.now();
    diagnostics.increment("upgrade.requests");
    glossTelemetry.noteBackendRequest(started);
    try {
      const res = await authed(session, "/api/upgrade", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      const durationMs = Date.now() - started;
      diagnostics.observe("upgrade.roundTrip", durationMs);
      if (!res.ok) {
        const message = await describeFailure("upgrade", res, durationMs);
        diagnostics.recordError(message);
        return { ok: false, message };
      }
      const data = await res.json();
      diagnostics.increment(data.word ? "upgrade.suggested" : "upgrade.empty");
      log.info("upgrade ok", {
        durationMs,
        suggested: Boolean(data.word),
        serverMs: data.profiling?.totalMs,
        requestId: res.headers.get("x-request-id") ?? undefined
      });
      return {
        ok: true,
        data: { ...data, profiling: { ...data.profiling, clientRoundTripMs: durationMs } }
      };
    } catch (err) {
      const durationMs = Date.now() - started;
      diagnostics.increment("upgrade.transport_error");
      diagnostics.recordError("Cannot reach LinkLingo backend");
      log.error("upgrade transport failure", { durationMs, url: BACKEND_URL, error: err });
      return { ok: false, message: "Cannot reach LinkLingo backend" };
    }
  }

  // src/background/remoteConfig.ts
  var log2 = createLogger("config");
  var KEY = "linklingo:config";
  var CONFIG_STALE_MS = 10 * 60000;
  function validConfig(raw) {
    const c = raw;
    if (!c || typeof c !== "object")
      return null;
    if (typeof c.revision !== "string" || !Array.isArray(c.settings) || !Array.isArray(c.screens))
      return null;
    if (!c.tunables || typeof c.tunables !== "object")
      return null;
    const screens = c.screens.filter((s) => !!s && typeof s.id === "string" && /^[a-z][a-z0-9-]{0,30}$/.test(s.id) && typeof s.title === "string");
    return {
      kit: typeof c.kit === "number" ? c.kit : 1,
      revision: c.revision,
      tunables: c.tunables,
      settings: c.settings,
      screens,
      prefDefaults: c.prefDefaults && typeof c.prefDefaults === "object" ? c.prefDefaults : {}
    };
  }
  async function loadCachedConfig(session) {
    try {
      const raw = await session.storage.get(KEY);
      const cached = raw ? validConfig(JSON.parse(raw)) : null;
      if (cached)
        return cached;
    } catch (err) {
      diagnostics.increment("config.cache_unreadable");
      log2.warn("cached config unreadable; using the bundled default", { error: err });
    }
    return DEFAULT_CONFIG;
  }
  async function saveConfig(session, config) {
    try {
      await session.storage.set(KEY, JSON.stringify(config));
    } catch (err) {
      diagnostics.increment("config.save_failures");
      log2.warn("could not cache config", { error: err });
    }
  }

  // src/background/tunables.ts
  var current = { ...DEFAULT_TUNABLES };
  function tunable(name) {
    return current[name];
  }
  function applyTunables(incoming) {
    const next = { ...DEFAULT_TUNABLES };
    const applied = [];
    for (const [name, value] of Object.entries(incoming ?? {})) {
      const limits = TUNABLE_LIMITS[name];
      if (!limits || !(name in DEFAULT_TUNABLES))
        continue;
      if (typeof value !== "number" || !Number.isFinite(value) || value < limits[0] || value > limits[1])
        continue;
      next[name] = value;
      applied.push(name);
    }
    current = next;
    return applied;
  }

  // src/vendor/display-utils/profiles/g1.ts
  var G1_GLYPH_WIDTHS = {
    " ": 2,
    "!": 1,
    '"': 2,
    "#": 6,
    $: 5,
    "%": 6,
    "&": 7,
    "'": 1,
    "(": 2,
    ")": 2,
    "*": 3,
    "+": 4,
    ",": 1,
    "-": 4,
    ".": 1,
    "/": 3,
    "0": 5,
    "1": 3,
    "2": 5,
    "3": 5,
    "4": 5,
    "5": 5,
    "6": 5,
    "7": 5,
    "8": 5,
    "9": 5,
    ":": 1,
    ";": 1,
    "<": 4,
    "=": 4,
    ">": 4,
    "?": 5,
    "@": 7,
    A: 6,
    B: 5,
    C: 5,
    D: 5,
    E: 4,
    F: 4,
    G: 5,
    H: 5,
    I: 2,
    J: 3,
    K: 5,
    L: 4,
    M: 7,
    N: 5,
    O: 5,
    P: 5,
    Q: 5,
    R: 5,
    S: 5,
    T: 5,
    U: 5,
    V: 6,
    W: 7,
    X: 6,
    Y: 6,
    Z: 5,
    "[": 2,
    "\\": 3,
    "]": 2,
    "^": 4,
    _: 3,
    "`": 2,
    a: 5,
    b: 4,
    c: 4,
    d: 4,
    e: 4,
    f: 4,
    g: 4,
    h: 4,
    i: 1,
    j: 2,
    k: 4,
    l: 1,
    m: 7,
    n: 4,
    o: 4,
    p: 4,
    q: 4,
    r: 3,
    s: 4,
    t: 3,
    u: 5,
    v: 5,
    w: 7,
    x: 5,
    y: 5,
    z: 4,
    "{": 3,
    "|": 1,
    "}": 3,
    "~": 7
  };
  var G1_PROFILE = {
    id: "even-realities-g1",
    name: "Even Realities G1",
    displayWidthPx: 576,
    maxLines: 5,
    maxPayloadBytes: 390,
    bleChunkSize: 176,
    fontMetrics: {
      glyphWidths: new Map(Object.entries(G1_GLYPH_WIDTHS)),
      defaultGlyphWidth: 7,
      renderFormula: (glyphWidth) => (glyphWidth + 1) * 2,
      uniformScripts: {
        cjk: 18,
        hiragana: 18,
        katakana: 18,
        korean: 24,
        cyrillic: 18
      },
      fallback: {
        latinMaxWidth: 16,
        unknownBehavior: "useLatinMax"
      }
    },
    constraints: {
      minCharsBeforeHyphen: 3,
      noStartChars: [".", ",", "!", "?", ":", ";", ")", "]", "}", "。", "，", "！", "？", "：", "；", "）", "】", "」"],
      noEndChars: ["(", "[", "{", "（", "【", "「"]
    }
  };
  var G1_PROFILE_LEGACY = {
    id: "even-realities-g1-legacy",
    name: "Even Realities G1 (Legacy Client Compatibility)",
    displayWidthPx: 420,
    maxLines: 5,
    maxPayloadBytes: 390,
    bleChunkSize: 176,
    fontMetrics: {
      glyphWidths: new Map(Object.entries(G1_GLYPH_WIDTHS)),
      defaultGlyphWidth: 7,
      renderFormula: (glyphWidth) => (glyphWidth + 1) * 2,
      uniformScripts: {
        cjk: 18,
        hiragana: 18,
        katakana: 18,
        korean: 24,
        cyrillic: 18
      },
      fallback: {
        latinMaxWidth: 16,
        unknownBehavior: "useLatinMax"
      }
    },
    constraints: {
      minCharsBeforeHyphen: 3,
      noStartChars: [".", ",", "!", "?", ":", ";", ")", "]", "}", "。", "，", "！", "？", "：", "；", "）", "】", "」"],
      noEndChars: ["(", "[", "{", "（", "【", "「"]
    }
  };
  // src/vendor/display-utils/profiles/z100.ts
  var Z100_GLYPH_WIDTHS = {
    " ": 5,
    "!": 6,
    '"': 9,
    "#": 14,
    $: 12,
    "%": 17,
    "&": 15,
    "'": 5,
    "(": 6,
    ")": 6,
    "*": 12,
    "+": 12,
    ",": 6,
    "-": 7,
    ".": 6,
    "/": 8,
    "0": 12,
    "1": 12,
    "2": 12,
    "3": 12,
    "4": 12,
    "5": 12,
    "6": 12,
    "7": 12,
    "8": 12,
    "9": 12,
    ":": 6,
    ";": 6,
    "<": 12,
    "=": 12,
    ">": 12,
    "?": 9,
    "@": 19,
    A: 13,
    B: 14,
    C: 13,
    D: 15,
    E: 12,
    F: 11,
    G: 15,
    H: 16,
    I: 7,
    J: 6,
    K: 13,
    L: 11,
    M: 19,
    N: 16,
    O: 16,
    P: 13,
    Q: 16,
    R: 13,
    S: 12,
    T: 12,
    U: 15,
    V: 13,
    W: 20,
    X: 12,
    Y: 12,
    Z: 12,
    "[": 7,
    "\\": 8,
    "]": 7,
    "^": 12,
    _: 9,
    "`": 6,
    a: 12,
    b: 13,
    c: 10,
    d: 13,
    e: 12,
    f: 7,
    g: 13,
    h: 13,
    i: 5,
    j: 5,
    k: 11,
    l: 5,
    m: 20,
    n: 13,
    o: 13,
    p: 13,
    q: 13,
    r: 9,
    s: 10,
    t: 8,
    u: 13,
    v: 11,
    w: 17,
    x: 11,
    y: 11,
    z: 10,
    "{": 8,
    "|": 12,
    "}": 8,
    "~": 12
  };
  var Z100_PROFILE = {
    id: "vuzix-z100",
    name: "Vuzix Z100",
    displayWidthPx: 390,
    maxLines: 7,
    maxPayloadBytes: 512,
    bleChunkSize: 180,
    fontMetrics: {
      glyphWidths: new Map(Object.entries(Z100_GLYPH_WIDTHS)),
      defaultGlyphWidth: 12,
      renderFormula: (glyphWidth) => glyphWidth,
      uniformScripts: {
        cjk: 21,
        hiragana: 21,
        katakana: 21,
        korean: 21,
        cyrillic: 14
      },
      fallback: {
        latinMaxWidth: 20,
        unknownBehavior: "useLatinMax"
      }
    },
    constraints: {
      minCharsBeforeHyphen: 3,
      noStartChars: [
        ".",
        ",",
        "!",
        "?",
        ":",
        ";",
        ")",
        "]",
        "}",
        "。",
        "，",
        "！",
        "？",
        "：",
        "；",
        "）",
        "】",
        "」"
      ],
      noEndChars: ["(", "[", "{", "（", "【", "「"]
    }
  };
  // src/vendor/display-utils/profiles/nex.ts
  var NEX_GLYPH_WIDTHS = {
    " ": 2,
    "!": 1,
    '"': 2,
    "#": 6,
    $: 5,
    "%": 6,
    "&": 7,
    "'": 1,
    "(": 2,
    ")": 2,
    "*": 3,
    "+": 4,
    ",": 1,
    "-": 4,
    ".": 1,
    "/": 3,
    "0": 5,
    "1": 3,
    "2": 5,
    "3": 5,
    "4": 5,
    "5": 5,
    "6": 5,
    "7": 5,
    "8": 5,
    "9": 5,
    ":": 1,
    ";": 1,
    "<": 4,
    "=": 4,
    ">": 4,
    "?": 5,
    "@": 7,
    A: 6,
    B: 5,
    C: 5,
    D: 5,
    E: 4,
    F: 4,
    G: 5,
    H: 5,
    I: 2,
    J: 3,
    K: 5,
    L: 4,
    M: 7,
    N: 5,
    O: 5,
    P: 5,
    Q: 5,
    R: 5,
    S: 5,
    T: 5,
    U: 5,
    V: 6,
    W: 7,
    X: 6,
    Y: 6,
    Z: 5,
    "[": 2,
    "\\": 3,
    "]": 2,
    "^": 4,
    _: 3,
    "`": 2,
    a: 5,
    b: 4,
    c: 4,
    d: 4,
    e: 4,
    f: 4,
    g: 4,
    h: 4,
    i: 1,
    j: 2,
    k: 4,
    l: 1,
    m: 7,
    n: 4,
    o: 4,
    p: 4,
    q: 4,
    r: 3,
    s: 4,
    t: 3,
    u: 5,
    v: 5,
    w: 7,
    x: 5,
    y: 5,
    z: 4,
    "{": 3,
    "|": 1,
    "}": 3,
    "~": 7
  };
  var NEX_PROFILE = {
    id: "mentra-nex",
    name: "Mentra Nex",
    displayWidthPx: 576,
    maxLines: 5,
    maxPayloadBytes: 390,
    bleChunkSize: 176,
    fontMetrics: {
      glyphWidths: new Map(Object.entries(NEX_GLYPH_WIDTHS)),
      defaultGlyphWidth: 7,
      renderFormula: (glyphWidth) => (glyphWidth + 1) * 2,
      uniformScripts: {
        cjk: 18,
        hiragana: 18,
        katakana: 18,
        korean: 24,
        cyrillic: 18
      },
      fallback: {
        latinMaxWidth: 16,
        unknownBehavior: "useLatinMax"
      }
    },
    constraints: {
      minCharsBeforeHyphen: 3,
      noStartChars: [".", ",", "!", "?", ":", ";", ")", "]", "}", "。", "，", "！", "？", "：", "；", "）", "】", "」"],
      noEndChars: ["(", "[", "{", "（", "【", "「"]
    }
  };
  // src/vendor/display-utils/measurer/script-detection.ts
  var SCRIPT_RANGES = {
    cjk: [
      [19968, 40959],
      [13312, 19903],
      [131072, 173791],
      [173824, 177983],
      [177984, 178207],
      [63744, 64255]
    ],
    hiragana: [[12352, 12447]],
    katakana: [
      [12448, 12543],
      [12784, 12799]
    ],
    korean: [
      [44032, 55215],
      [4352, 4607],
      [12592, 12687],
      [43360, 43391],
      [55216, 55295]
    ],
    cyrillic: [
      [1024, 1279],
      [1280, 1327]
    ],
    numbers: [[48, 57]],
    punctuation: [
      [32, 47],
      [58, 64],
      [91, 96],
      [123, 126]
    ],
    arabic: [[1536, 1791]],
    hebrew: [[1424, 1535]],
    thai: [[3584, 3711]],
    emoji: [
      [128512, 128591],
      [127744, 128511],
      [128640, 128767],
      [127456, 127487],
      [9728, 9983],
      [9984, 10175],
      [65024, 65039],
      [129280, 129535]
    ]
  };
  function inRanges(codePoint, ranges) {
    for (const [start, end] of ranges) {
      if (codePoint >= start && codePoint <= end) {
        return true;
      }
    }
    return false;
  }
  function detectScript(char) {
    if (!char || char.length === 0) {
      return "latin";
    }
    const codePoint = char.codePointAt(0);
    if (codePoint === undefined) {
      return "latin";
    }
    if (inRanges(codePoint, SCRIPT_RANGES.cjk)) {
      return "cjk";
    }
    if (inRanges(codePoint, SCRIPT_RANGES.hiragana)) {
      return "hiragana";
    }
    if (inRanges(codePoint, SCRIPT_RANGES.katakana)) {
      return "katakana";
    }
    if (inRanges(codePoint, SCRIPT_RANGES.korean)) {
      return "korean";
    }
    if (inRanges(codePoint, SCRIPT_RANGES.cyrillic)) {
      return "cyrillic";
    }
    if (inRanges(codePoint, SCRIPT_RANGES.numbers)) {
      return "numbers";
    }
    if (inRanges(codePoint, SCRIPT_RANGES.punctuation)) {
      return "punctuation";
    }
    if (inRanges(codePoint, SCRIPT_RANGES.arabic) || inRanges(codePoint, SCRIPT_RANGES.hebrew) || inRanges(codePoint, SCRIPT_RANGES.thai) || inRanges(codePoint, SCRIPT_RANGES.emoji)) {
      return "unsupported";
    }
    return "latin";
  }
  function isCJKCharacter(char) {
    const script = detectScript(char);
    return script === "cjk" || script === "hiragana" || script === "katakana";
  }
  function isUniformWidthScript(char) {
    const script = detectScript(char);
    return script === "cjk" || script === "hiragana" || script === "katakana" || script === "korean" || script === "cyrillic";
  }
  function needsHyphenForBreak(charBefore, charAfter) {
    if (isCJKCharacter(charBefore)) {
      return false;
    }
    if (isCJKCharacter(charAfter)) {
      return false;
    }
    if (charBefore === " " || charBefore === "\t") {
      return false;
    }
    if (charAfter === " " || charAfter === "\t") {
      return false;
    }
    const breakPunctuation = ["-", "–", "—", "/", "\\", "|"];
    if (breakPunctuation.includes(charBefore)) {
      return false;
    }
    return true;
  }

  // src/vendor/display-utils/measurer/TextMeasurer.ts
  class TextMeasurer {
    profile;
    charCache = new Map;
    constructor(profile) {
      this.profile = profile;
      this.buildCharCache();
    }
    buildCharCache() {
      const { glyphWidths, renderFormula } = this.profile.fontMetrics;
      for (const [char, glyphWidth] of glyphWidths.entries()) {
        const renderedWidth = renderFormula(glyphWidth);
        this.charCache.set(char, renderedWidth);
      }
    }
    measureText(text) {
      if (!text || text.length === 0) {
        return 0;
      }
      let totalWidth = 0;
      for (const char of text) {
        totalWidth += this.measureChar(char);
      }
      return totalWidth;
    }
    measureTextDetailed(text) {
      if (!text || text.length === 0) {
        return {
          text: "",
          totalWidthPx: 0,
          charCount: 0,
          chars: []
        };
      }
      const chars = [];
      let totalWidth = 0;
      for (const char of text) {
        const script = detectScript(char);
        const widthPx = this.measureChar(char);
        const fromGlyphMap = this.profile.fontMetrics.glyphWidths.has(char);
        chars.push({
          char,
          widthPx,
          script,
          fromGlyphMap
        });
        totalWidth += widthPx;
      }
      return {
        text,
        totalWidthPx: totalWidth,
        charCount: chars.length,
        chars
      };
    }
    measureChar(char) {
      if (!char || char.length === 0) {
        return 0;
      }
      const cached = this.charCache.get(char);
      if (cached !== undefined) {
        return cached;
      }
      const width = this.calculateCharWidth(char);
      this.charCache.set(char, width);
      return width;
    }
    calculateCharWidth(char) {
      const { fontMetrics } = this.profile;
      const { uniformScripts, fallback, renderFormula, glyphWidths } = fontMetrics;
      const glyphWidth = glyphWidths.get(char);
      if (glyphWidth !== undefined) {
        return renderFormula(glyphWidth);
      }
      const script = detectScript(char);
      switch (script) {
        case "cjk":
          return uniformScripts.cjk;
        case "hiragana":
          return uniformScripts.hiragana;
        case "katakana":
          return uniformScripts.katakana;
        case "korean":
          return uniformScripts.korean;
        case "cyrillic":
          return uniformScripts.cyrillic;
      }
      return fallback.latinMaxWidth;
    }
    getGlyphWidth(char) {
      return this.profile.fontMetrics.glyphWidths.get(char);
    }
    fitsInWidth(text, maxWidthPx) {
      return this.measureText(text) <= maxWidthPx;
    }
    charsThatFit(text, maxWidthPx, startIndex = 0) {
      if (!text || startIndex >= text.length) {
        return 0;
      }
      let currentWidth = 0;
      let count = 0;
      const chars = Array.from(text).slice(startIndex);
      for (const char of chars) {
        const charWidth = this.measureChar(char);
        if (currentWidth + charWidth > maxWidthPx) {
          break;
        }
        currentWidth += charWidth;
        count++;
      }
      return count;
    }
    getPixelOffset(text, index) {
      if (!text || index <= 0) {
        return 0;
      }
      const chars = Array.from(text).slice(0, index);
      let offset = 0;
      for (const char of chars) {
        offset += this.measureChar(char);
      }
      return offset;
    }
    detectScript(char) {
      return detectScript(char);
    }
    isUniformWidth(char) {
      return isUniformWidthScript(char);
    }
    getProfile() {
      return this.profile;
    }
    getDisplayWidthPx() {
      return this.profile.displayWidthPx;
    }
    getMaxLines() {
      return this.profile.maxLines;
    }
    getMaxPayloadBytes() {
      return this.profile.maxPayloadBytes;
    }
    getByteSize(text) {
      return new TextEncoder().encode(text).length;
    }
    getHyphenWidth() {
      return this.measureChar("-");
    }
    getSpaceWidth() {
      return this.measureChar(" ");
    }
    clearCache() {
      this.charCache.clear();
      this.buildCharCache();
    }
  }
  // src/vendor/display-utils/wrapper/types.ts
  var DEFAULT_WRAP_OPTIONS = {
    breakMode: "character-no-hyphen",
    hyphenChar: "-",
    minCharsBeforeHyphen: 3,
    trimLines: true,
    preserveNewlines: true
  };

  // src/vendor/display-utils/wrapper/TextWrapper.ts
  class TextWrapper {
    measurer;
    defaultOptions;
    constructor(measurer, defaultOptions) {
      this.measurer = measurer;
      const profile = measurer.getProfile();
      this.defaultOptions = {
        maxWidthPx: profile.displayWidthPx,
        maxLines: profile.maxLines,
        maxBytes: profile.maxPayloadBytes,
        ...DEFAULT_WRAP_OPTIONS,
        ...defaultOptions
      };
    }
    wrap(text, options) {
      const opts = this.mergeOptions(options);
      const { maxWidthPx, maxLines, maxBytes, breakMode, preserveNewlines } = opts;
      if (!text || text.length === 0) {
        return this.createEmptyResult(opts);
      }
      const paragraphs = preserveNewlines ? text.split(`
`) : [text];
      const allLines = [];
      const allMetrics = [];
      let totalBytes = 0;
      let truncated = false;
      for (let pIndex = 0;pIndex < paragraphs.length; pIndex++) {
        const paragraph = paragraphs[pIndex];
        const isFromNewline = pIndex > 0;
        const paragraphLines = this.wrapParagraph(paragraph, maxWidthPx, breakMode, opts);
        for (let lIndex = 0;lIndex < paragraphLines.length; lIndex++) {
          const line = paragraphLines[lIndex];
          const lineBytes = this.measurer.getByteSize(line);
          if (allLines.length >= maxLines) {
            truncated = true;
            break;
          }
          if (totalBytes + lineBytes > maxBytes) {
            truncated = true;
            break;
          }
          const widthPx = this.measurer.measureText(line);
          const metrics = {
            text: line,
            widthPx,
            bytes: lineBytes,
            utilizationPercent: Math.round(widthPx / maxWidthPx * 100),
            endsWithHyphen: line.endsWith(opts.hyphenChar) && lIndex < paragraphLines.length - 1,
            fromExplicitNewline: isFromNewline && lIndex === 0
          };
          allLines.push(line);
          allMetrics.push(metrics);
          totalBytes += lineBytes;
          if (allLines.length < maxLines) {
            totalBytes += 1;
          }
        }
        if (truncated)
          break;
      }
      const maxLineWidthPx = allMetrics.reduce((max, m) => Math.max(max, m.widthPx), 0);
      return {
        lines: allLines,
        truncated,
        maxLineWidthPx,
        totalBytes,
        lineMetrics: allMetrics,
        originalText: text,
        breakMode
      };
    }
    wrapToLines(text, options) {
      return this.wrap(text, options).lines;
    }
    needsWrap(text, maxWidthPx) {
      const width = maxWidthPx ?? this.defaultOptions.maxWidthPx;
      return this.measurer.measureText(text) > width || text.includes(`
`);
    }
    getOptions() {
      return { ...this.defaultOptions };
    }
    getMeasurer() {
      return this.measurer;
    }
    wrapParagraph(paragraph, maxWidthPx, breakMode, opts) {
      const trimmed = opts.trimLines ? paragraph.trim() : paragraph;
      if (!trimmed) {
        return [""];
      }
      if (this.measurer.fitsInWidth(trimmed, maxWidthPx)) {
        return [trimmed];
      }
      switch (breakMode) {
        case "character":
          return this.wrapCharacterMode(trimmed, maxWidthPx, opts);
        case "character-no-hyphen":
          return this.wrapCharacterNoHyphenMode(trimmed, maxWidthPx, opts);
        case "word":
          return this.wrapWordMode(trimmed, maxWidthPx, opts);
        case "strict-word":
          return this.wrapStrictWordMode(trimmed, maxWidthPx, opts);
        default:
          return this.wrapCharacterMode(trimmed, maxWidthPx, opts);
      }
    }
    wrapCharacterMode(text, maxWidthPx, opts) {
      return this.wrapCharacterModeInternal(text, maxWidthPx, opts, true);
    }
    wrapCharacterNoHyphenMode(text, maxWidthPx, opts) {
      return this.wrapCharacterModeInternal(text, maxWidthPx, opts, false);
    }
    wrapCharacterModeInternal(text, maxWidthPx, opts, useHyphen) {
      const lines = [];
      const hyphenWidth = this.measurer.measureChar(opts.hyphenChar);
      let currentLine = "";
      let currentWidth = 0;
      const chars = Array.from(text);
      for (let i = 0;i < chars.length; i++) {
        const char = chars[i];
        const charWidth = this.measurer.measureChar(char);
        if (currentWidth + charWidth <= maxWidthPx) {
          currentLine += char;
          currentWidth += charWidth;
        } else {
          const prevChar = currentLine.length > 0 ? currentLine[currentLine.length - 1] : "";
          const needsHyphen = useHyphen && currentLine.length >= opts.minCharsBeforeHyphen && needsHyphenForBreak(prevChar, char);
          if (needsHyphen) {
            const result = this.backoffForHyphen(currentLine, currentWidth, maxWidthPx, hyphenWidth, opts);
            if (result.skipHyphen) {
              lines.push(result.line);
            } else {
              lines.push(result.line + opts.hyphenChar);
            }
            currentLine = result.remainder + char;
            currentWidth = this.measurer.measureText(currentLine);
          } else if (useHyphen === false && !isCJKCharacter(char) && char !== " ") {
            const trimmedLine = opts.trimLines ? currentLine.trimEnd() : currentLine;
            if (trimmedLine) {
              lines.push(trimmedLine);
            }
            currentLine = char;
            currentWidth = charWidth;
          } else {
            const trimmedLine = opts.trimLines ? currentLine.trimEnd() : currentLine;
            if (trimmedLine) {
              lines.push(trimmedLine);
            }
            currentLine = char === " " ? "" : char;
            currentWidth = char === " " ? 0 : charWidth;
          }
        }
      }
      if (currentLine) {
        const trimmedLine = opts.trimLines ? currentLine.trim() : currentLine;
        if (trimmedLine) {
          lines.push(trimmedLine);
        }
      }
      return lines.length > 0 ? lines : [""];
    }
    wrapWordMode(text, maxWidthPx, opts) {
      const lines = [];
      const words = this.splitIntoWords(text);
      const spaceWidth = this.measurer.getSpaceWidth();
      let currentLine = "";
      let currentWidth = 0;
      for (const word of words) {
        const wordWidth = this.measurer.measureText(word);
        const needsSpace = currentLine.length > 0;
        const totalWidth = currentWidth + (needsSpace ? spaceWidth : 0) + wordWidth;
        if (totalWidth <= maxWidthPx) {
          if (needsSpace) {
            currentLine += " ";
            currentWidth += spaceWidth;
          }
          currentLine += word;
          currentWidth += wordWidth;
        } else {
          if (currentLine.length > 0) {
            lines.push(opts.trimLines ? currentLine.trim() : currentLine);
            currentLine = "";
            currentWidth = 0;
          }
          if (wordWidth > maxWidthPx) {
            const hyphenatedLines = this.hyphenateLongWord(word, maxWidthPx, opts);
            for (let i = 0;i < hyphenatedLines.length - 1; i++) {
              lines.push(hyphenatedLines[i]);
            }
            currentLine = hyphenatedLines[hyphenatedLines.length - 1];
            currentWidth = this.measurer.measureText(currentLine);
          } else {
            currentLine = word;
            currentWidth = wordWidth;
          }
        }
      }
      if (currentLine) {
        const trimmedLine = opts.trimLines ? currentLine.trim() : currentLine;
        if (trimmedLine) {
          lines.push(trimmedLine);
        }
      }
      return lines.length > 0 ? lines : [""];
    }
    wrapStrictWordMode(text, maxWidthPx, opts) {
      const lines = [];
      const words = this.splitIntoWords(text);
      const spaceWidth = this.measurer.getSpaceWidth();
      let currentLine = "";
      let currentWidth = 0;
      for (const word of words) {
        const wordWidth = this.measurer.measureText(word);
        const needsSpace = currentLine.length > 0;
        const totalWidth = currentWidth + (needsSpace ? spaceWidth : 0) + wordWidth;
        if (totalWidth <= maxWidthPx) {
          if (needsSpace) {
            currentLine += " ";
            currentWidth += spaceWidth;
          }
          currentLine += word;
          currentWidth += wordWidth;
        } else {
          if (currentLine.length > 0) {
            lines.push(opts.trimLines ? currentLine.trim() : currentLine);
          }
          currentLine = word;
          currentWidth = wordWidth;
        }
      }
      if (currentLine) {
        const trimmedLine = opts.trimLines ? currentLine.trim() : currentLine;
        if (trimmedLine) {
          lines.push(trimmedLine);
        }
      }
      return lines.length > 0 ? lines : [""];
    }
    splitIntoWords(text) {
      const words = [];
      let currentWord = "";
      for (const char of text) {
        if (char === " " || char === "\t") {
          if (currentWord) {
            words.push(currentWord);
            currentWord = "";
          }
        } else if (isCJKCharacter(char)) {
          if (currentWord) {
            words.push(currentWord);
            currentWord = "";
          }
          words.push(char);
        } else {
          currentWord += char;
        }
      }
      if (currentWord) {
        words.push(currentWord);
      }
      return words;
    }
    hyphenateLongWord(word, maxWidthPx, opts) {
      const lines = [];
      const hyphenWidth = this.measurer.measureChar(opts.hyphenChar);
      const chars = Array.from(word);
      let currentLine = "";
      let currentWidth = 0;
      for (let i = 0;i < chars.length; i++) {
        const char = chars[i];
        const charWidth = this.measurer.measureChar(char);
        const isLastChar = i === chars.length - 1;
        const widthNeeded = isLastChar ? charWidth : charWidth + hyphenWidth;
        if (currentWidth + widthNeeded <= maxWidthPx) {
          currentLine += char;
          currentWidth += charWidth;
        } else {
          if (currentLine.length >= opts.minCharsBeforeHyphen) {
            const result = this.backoffForHyphen(currentLine, currentWidth, maxWidthPx, hyphenWidth, opts);
            if (result.skipHyphen) {
              lines.push(result.line);
            } else {
              lines.push(result.line + opts.hyphenChar);
            }
            currentLine = result.remainder + char;
            currentWidth = this.measurer.measureText(currentLine);
          } else {
            if (currentLine) {
              lines.push(currentLine);
            }
            currentLine = char;
            currentWidth = charWidth;
          }
        }
      }
      if (currentLine) {
        lines.push(currentLine);
      }
      return lines.length > 0 ? lines : [word];
    }
    backoffForHyphen(line, lineWidth, maxWidthPx, hyphenWidth, opts) {
      let adjustedLine = line;
      let adjustedWidth = lineWidth;
      let remainder = "";
      while (adjustedWidth + hyphenWidth > maxWidthPx && adjustedLine.length > opts.minCharsBeforeHyphen) {
        const lastChar = adjustedLine[adjustedLine.length - 1];
        const lastCharWidth = this.measurer.measureChar(lastChar);
        adjustedLine = adjustedLine.slice(0, -1);
        adjustedWidth -= lastCharWidth;
        remainder = lastChar + remainder;
        if (adjustedLine.length > 0 && adjustedLine[adjustedLine.length - 1] === " ") {
          adjustedLine = adjustedLine.trimEnd();
          return { line: adjustedLine, remainder, skipHyphen: true };
        }
      }
      return { line: adjustedLine, remainder, skipHyphen: false };
    }
    mergeOptions(options) {
      return {
        ...this.defaultOptions,
        ...options
      };
    }
    createEmptyResult(opts) {
      return {
        lines: [""],
        truncated: false,
        maxLineWidthPx: 0,
        totalBytes: 0,
        lineMetrics: [
          {
            text: "",
            widthPx: 0,
            bytes: 0,
            utilizationPercent: 0,
            endsWithHyphen: false,
            fromExplicitNewline: false
          }
        ],
        originalText: "",
        breakMode: opts.breakMode
      };
    }
  }
  // src/vendor/display-utils/helpers/DisplayHelpers.ts
  class DisplayHelpers {
    measurer;
    wrapper;
    profile;
    constructor(measurer, wrapper) {
      this.measurer = measurer;
      this.wrapper = wrapper;
      this.profile = measurer.getProfile();
    }
    truncateToLines(lines, maxLines, fromEnd = false) {
      if (lines.length <= maxLines) {
        return lines;
      }
      if (fromEnd) {
        return lines.slice(-maxLines);
      } else {
        return lines.slice(0, maxLines);
      }
    }
    truncateWithEllipsis(text, maxWidthPx, ellipsis = "...") {
      const width = maxWidthPx ?? this.profile.displayWidthPx;
      const textWidth = this.measurer.measureText(text);
      if (textWidth <= width) {
        return {
          text,
          wasTruncated: false,
          widthPx: textWidth,
          originalLength: text.length,
          truncatedLength: text.length
        };
      }
      const ellipsisWidth = this.measurer.measureText(ellipsis);
      const targetWidth = width - ellipsisWidth;
      let truncated = "";
      let currentWidth = 0;
      for (const char of text) {
        const charWidth = this.measurer.measureChar(char);
        if (currentWidth + charWidth > targetWidth) {
          break;
        }
        truncated += char;
        currentWidth += charWidth;
      }
      truncated = truncated.trimEnd();
      const finalText = truncated + ellipsis;
      return {
        text: finalText,
        wasTruncated: true,
        widthPx: this.measurer.measureText(finalText),
        originalLength: text.length,
        truncatedLength: truncated.length
      };
    }
    estimateLineCount(text, maxWidthPx) {
      if (!text)
        return 1;
      const width = maxWidthPx ?? this.profile.displayWidthPx;
      const textWidth = this.measurer.measureText(text);
      const newlineCount = (text.match(/\n/g) || []).length;
      const wrappedLines = Math.ceil(textWidth / width);
      return wrappedLines + newlineCount;
    }
    fitToScreen(text, options) {
      const result = this.wrapper.wrap(text, options);
      return result.lines.slice(0, this.profile.maxLines);
    }
    paginate(text, options) {
      const wrapResult = this.wrapper.wrap(text, {
        ...options,
        maxLines: Infinity,
        maxBytes: Infinity
      });
      const linesPerPage = options?.maxLines ?? this.profile.maxLines;
      const allLines = wrapResult.lines;
      const pages = [];
      for (let i = 0;i < allLines.length; i += linesPerPage) {
        const pageLines = allLines.slice(i, i + linesPerPage);
        const pageNumber = Math.floor(i / linesPerPage) + 1;
        const totalPages = Math.ceil(allLines.length / linesPerPage);
        pages.push({
          lines: pageLines,
          pageNumber,
          totalPages,
          isFirst: pageNumber === 1,
          isLast: pageNumber === totalPages
        });
      }
      return pages.length > 0 ? pages : [
        {
          lines: [""],
          pageNumber: 1,
          totalPages: 1,
          isFirst: true,
          isLast: true
        }
      ];
    }
    calculateByteSize(text) {
      return this.measurer.getByteSize(text);
    }
    exceedsByteLimit(text, maxBytes) {
      const limit = maxBytes ?? this.profile.maxPayloadBytes;
      return this.calculateByteSize(text) > limit;
    }
    splitIntoChunks(text, chunkSize) {
      const size = chunkSize ?? this.profile.bleChunkSize;
      const encoder = new TextEncoder;
      const bytes = encoder.encode(text);
      if (bytes.length <= size) {
        return [
          {
            text,
            index: 0,
            totalChunks: 1,
            bytes: bytes.length
          }
        ];
      }
      const chunks = [];
      let offset = 0;
      while (offset < bytes.length) {
        let endOffset = Math.min(offset + size, bytes.length);
        if (endOffset < bytes.length) {
          while (endOffset > offset && (bytes[endOffset] & 192) === 128) {
            endOffset--;
          }
          let breakPoint = endOffset;
          for (let i = endOffset - 1;i > offset + size / 2; i--) {
            if (bytes[i] === 32 || bytes[i] === 10) {
              breakPoint = i + 1;
              break;
            }
          }
          if (breakPoint > offset) {
            endOffset = breakPoint;
          }
        }
        const chunkBytes = bytes.slice(offset, endOffset);
        const chunkText = new TextDecoder().decode(chunkBytes);
        chunks.push({
          text: chunkText,
          index: chunks.length,
          totalChunks: 0,
          bytes: chunkBytes.length
        });
        offset = endOffset;
      }
      for (const chunk of chunks) {
        chunk.totalChunks = chunks.length;
      }
      return chunks;
    }
    calculateUtilization(result) {
      if (result.lines.length === 0 || result.lineMetrics.length === 0) {
        return {
          averageUtilization: 0,
          minUtilization: 0,
          maxUtilization: 0,
          totalWastedPx: 0
        };
      }
      const maxWidthPx = this.profile.displayWidthPx;
      let totalUtilization = 0;
      let minUtilization = 100;
      let maxUtilization = 0;
      let totalWastedPx = 0;
      for (const metric of result.lineMetrics) {
        totalUtilization += metric.utilizationPercent;
        minUtilization = Math.min(minUtilization, metric.utilizationPercent);
        maxUtilization = Math.max(maxUtilization, metric.utilizationPercent);
        totalWastedPx += maxWidthPx - metric.widthPx;
      }
      return {
        averageUtilization: Math.round(totalUtilization / result.lineMetrics.length),
        minUtilization,
        maxUtilization,
        totalWastedPx
      };
    }
    padToLineCount(lines, targetCount, padAtEnd = true) {
      if (lines.length >= targetCount) {
        return lines.slice(0, targetCount);
      }
      const padding = Array(targetCount - lines.length).fill("");
      if (padAtEnd) {
        return [...lines, ...padding];
      } else {
        return [...padding, ...lines];
      }
    }
    joinLines(lines) {
      return lines.join(`
`);
    }
    getMeasurer() {
      return this.measurer;
    }
    getWrapper() {
      return this.wrapper;
    }
    getProfile() {
      return this.profile;
    }
  }
  // src/core/CaptionsFormatter.ts
  class CaptionsFormatter {
    measurer;
    wrapper;
    helpers;
    profile;
    finalTranscriptHistory = [];
    maxFinalTranscripts;
    partialSpeakerId = undefined;
    partialHadSpeakerChange = false;
    displayWidthPx;
    maxLines;
    constructor(profile = G1_PROFILE, options = {}) {
      this.profile = profile;
      this.maxFinalTranscripts = options.maxFinalTranscripts ?? 30;
      this.displayWidthPx = options.displayWidthPx ?? profile.displayWidthPx;
      this.maxLines = options.maxLines ?? profile.maxLines;
      const breakMode = options.breakMode ?? (options.useCharacterBreaking !== false ? "character" : "word");
      this.measurer = new TextMeasurer(profile);
      this.wrapper = new TextWrapper(this.measurer, {
        breakMode,
        hyphenChar: "-",
        minCharsBeforeHyphen: 3
      });
      this.helpers = new DisplayHelpers(this.measurer, this.wrapper);
    }
    processTranscription(text, isFinal, speakerId, speakerChanged) {
      const cleanText = text?.trim() ?? "";
      if (!isFinal) {
        return this.processInterim(cleanText, speakerId, speakerChanged);
      } else {
        return this.processFinal(cleanText, speakerId, speakerChanged);
      }
    }
    processInterim(text, speakerId, speakerChanged) {
      if (speakerChanged && speakerId) {
        this.partialSpeakerId = speakerId;
        this.partialHadSpeakerChange = true;
      } else if (speakerId && speakerId !== this.partialSpeakerId) {
        this.partialSpeakerId = speakerId;
        this.partialHadSpeakerChange = true;
      }
      const displayText = this.buildDisplayText(text, this.partialSpeakerId, this.partialHadSpeakerChange);
      return this.wrapAndFormat(displayText);
    }
    processFinal(text, speakerId, speakerChanged) {
      const finalSpeakerId = speakerId || this.partialSpeakerId;
      const finalSpeakerChanged = speakerChanged || this.partialHadSpeakerChange;
      this.partialSpeakerId = undefined;
      this.partialHadSpeakerChange = false;
      if (text) {
        this.addToHistory(text, finalSpeakerId, finalSpeakerChanged);
      }
      const displayText = this.buildDisplayText("", undefined, false);
      return this.wrapAndFormat(displayText);
    }
    buildDisplayText(partialText, partialSpeakerId, partialSpeakerChanged) {
      let result = "";
      for (const entry of this.finalTranscriptHistory) {
        if (entry.hadSpeakerChange && entry.speakerId) {
          if (result.length > 0) {
            result += `
`;
          }
          result += `[${entry.speakerId}]: ${entry.text}`;
        } else {
          if (result.length > 0) {
            result += " ";
          }
          result += entry.text;
        }
      }
      if (partialText) {
        if (partialSpeakerChanged && partialSpeakerId) {
          if (result.length > 0) {
            result += `
`;
          }
          result += `[${partialSpeakerId}]: ${partialText}`;
        } else {
          if (result.length > 0) {
            result += " ";
          }
          result += partialText;
        }
      }
      return result;
    }
    wrapAndFormat(displayText) {
      const result = this.wrapper.wrap(displayText, {
        maxWidthPx: this.displayWidthPx,
        maxLines: Infinity,
        maxBytes: Infinity
      });
      let lines = result.lines;
      if (lines.length > this.maxLines) {
        lines = lines.slice(-this.maxLines);
      }
      const wasTruncated = result.lines.length > this.maxLines;
      return {
        lines,
        displayText: lines.join(`
`),
        truncated: wasTruncated,
        lineMetrics: result.lineMetrics.slice(-this.maxLines)
      };
    }
    addToHistory(transcript, speakerId, speakerChanged) {
      if (!transcript.trim())
        return;
      this.finalTranscriptHistory.push({
        text: transcript,
        speakerId,
        hadSpeakerChange: speakerChanged ?? false
      });
      while (this.finalTranscriptHistory.length > this.maxFinalTranscripts) {
        this.finalTranscriptHistory.shift();
      }
    }
    getFinalTranscriptHistory() {
      return [...this.finalTranscriptHistory];
    }
    getCombinedTranscriptHistory() {
      return this.finalTranscriptHistory.map((entry) => entry.text).join(" ");
    }
    clear() {
      this.finalTranscriptHistory = [];
      this.partialSpeakerId = undefined;
      this.partialHadSpeakerChange = false;
    }
    setMaxFinalTranscripts(max) {
      this.maxFinalTranscripts = max;
      while (this.finalTranscriptHistory.length > this.maxFinalTranscripts) {
        this.finalTranscriptHistory.shift();
      }
    }
    getMaxFinalTranscripts() {
      return this.maxFinalTranscripts;
    }
    getProfile() {
      return this.profile;
    }
    getMeasurer() {
      return this.measurer;
    }
    getWrapper() {
      return this.wrapper;
    }
    getHelpers() {
      return this.helpers;
    }
    getMaxLines() {
      return this.maxLines;
    }
    getDisplayWidthPx() {
      return this.displayWidthPx;
    }
  }

  // src/core/ChineseUtils.ts
  var jiebaInstance = null;
  var pinyinFn = null;
  function optionalRequire(id) {
    try {
      const req = globalThis.require;
      if (typeof req !== "function")
        return;
      return req(id);
    } catch {
      return;
    }
  }
  function getJieba() {
    if (jiebaInstance !== null)
      return jiebaInstance || null;
    try {
      const mod = optionalRequire("@node-rs/jieba");
      const dictMod = optionalRequire("@node-rs/jieba/dict");
      if (!mod || !dictMod) {
        jiebaInstance = false;
        return null;
      }
      jiebaInstance = mod.Jieba.withDict(dictMod.dict);
      return jiebaInstance;
    } catch {
      jiebaInstance = false;
      return null;
    }
  }
  function getPinyin() {
    if (pinyinFn !== null)
      return pinyinFn || null;
    try {
      const mod = optionalRequire("pinyin-pro");
      if (!mod) {
        pinyinFn = false;
        return null;
      }
      pinyinFn = mod.pinyin;
      return pinyinFn;
    } catch {
      pinyinFn = false;
      return null;
    }
  }
  function isChinese(text) {
    return /[一-龥]/.test(text);
  }
  function convertToPinyin(text) {
    if (!isChinese(text))
      return text;
    const jieba = getJieba();
    const pinyin = getPinyin();
    if (!jieba || !pinyin)
      return text;
    try {
      const parts = text.split(/([一-龥]+)/g);
      const processedParts = parts.map((part) => {
        if (!isChinese(part))
          return part;
        const words = jieba.cut(part);
        const pinyinWords = words.map((word) => {
          if (!isChinese(word))
            return word;
          return pinyin(word, {
            toneType: "symbol",
            type: "array",
            nonZh: "removed",
            mode: "normal"
          }).join("");
        });
        return pinyinWords.join(" ");
      });
      return processedParts.join("");
    } catch {
      return text;
    }
  }

  // src/background/DisplayRenderer.ts
  var log3 = createLogger("display");
  var INACTIVITY_MS = 40000;
  var IDLE_LINE = "LinkLingo · listening";
  var EMPTY_ROW = " ";
  var MIN_SEND_INTERVAL_MS = 900;

  class DisplayRenderer {
    session;
    formatter;
    inactivityTimer = null;
    lastCaption = "";
    lastTranslation = "";
    lastOriginal = "";
    lastWords = [];
    lastSentText = "";
    lastSentAt = 0;
    pendingTimer = null;
    pendingSettings = null;
    constructor(session) {
      this.session = session;
      this.formatter = this.makeFormatter({
        displayLines: HUD_CAPTION_LINES,
        displayWidth: 1,
        wordBreaking: false
      });
    }
    applySettings(settings) {
      this.formatter = this.makeFormatter(settings);
    }
    showIdle(settings) {
      this.paint(settings);
    }
    showCaption(text, isFinal, settings, words) {
      const display = maybePinyin(text, settings);
      const formatted = this.formatter.processTranscription(display, isFinal);
      this.lastCaption = formatted.displayText;
      this.lastWords = words;
      this.paint(settings);
    }
    showTranslation(original, translated, settings) {
      this.lastOriginal = maybePinyin(original, settings);
      this.lastTranslation = maybePinyin(translated, settings);
      this.paint(settings);
    }
    showWords(words, settings) {
      this.lastWords = words;
      this.paint(settings);
    }
    clear(settings) {
      this.lastCaption = "";
      this.lastTranslation = "";
      this.lastOriginal = "";
      this.lastWords = [];
      this.formatter.clear();
      if (this.pendingTimer) {
        clearTimeout(this.pendingTimer);
        this.pendingTimer = null;
      }
      this.paint(settings);
    }
    paint(settings) {
      this.pendingSettings = settings;
      const text = this.compose(settings);
      if (text === this.lastSentText) {
        diagnostics.increment("display.deduped");
        return;
      }
      const wait = MIN_SEND_INTERVAL_MS - (Date.now() - this.lastSentAt);
      if (wait <= 0) {
        this.send(text, settings);
        return;
      }
      if (this.pendingTimer)
        return;
      this.pendingTimer = setTimeout(() => {
        this.pendingTimer = null;
        const latest = this.pendingSettings ?? settings;
        const frame = this.compose(latest);
        if (frame !== this.lastSentText)
          this.send(frame, latest);
      }, wait);
    }
    compose(settings) {
      return composeHud({
        words: this.lastWords,
        caption: this.lastCaption,
        translation: this.lastTranslation,
        original: this.lastOriginal
      }, settings);
    }
    send(text, settings) {
      const breakMode = settings.wordBreaking ? "character" : "word";
      const options = { breakMode };
      const started = Date.now();
      try {
        this.session.display.showTextWall(text, options);
        diagnostics.increment("display.paints");
        diagnostics.observe("display.paintMs", Date.now() - started);
      } catch (err) {
        diagnostics.increment("display.paint_failures");
        log3.error("display paint failed", {
          mode: settings.mode,
          wordRows: this.lastWords.length,
          error: err
        });
        return;
      }
      this.lastSentText = text;
      this.lastSentAt = Date.now();
      log3.debug("painted hud", {
        mode: settings.mode,
        wordRows: this.lastWords.length,
        captionChars: this.lastCaption.trim().length,
        translationChars: this.lastTranslation.trim().length,
        sentChars: text.length,
        paintMs: Date.now() - started
      });
      this.bumpInactivity(settings);
    }
    bumpInactivity(settings) {
      if (this.inactivityTimer)
        clearTimeout(this.inactivityTimer);
      this.inactivityTimer = setTimeout(() => {
        diagnostics.increment("display.inactivity_clears");
        log3.info("idling hud after silence", { afterMs: INACTIVITY_MS });
        this.lastCaption = "";
        this.lastTranslation = "";
        this.lastOriginal = "";
        this.lastWords = [];
        this.formatter.clear();
        this.paint(settings);
      }, INACTIVITY_MS);
    }
    makeFormatter(settings) {
      const profile = G1_PROFILE;
      const widthScale = settings.displayWidth === 0 ? 0.7 : settings.displayWidth === 1 ? 0.85 : 1;
      return new CaptionsFormatter(profile, {
        maxFinalTranscripts: 10,
        maxLines: Math.min(HUD_CAPTION_LINES, Math.max(1, settings.displayLines)),
        displayWidthPx: Math.floor(profile.displayWidthPx * widthScale),
        breakMode: settings.wordBreaking ? "character" : "word"
      });
    }
  }
  function composeHud(state, settings) {
    const wordRows = formatWords(state.words).slice(-HUD_WORD_ROWS);
    const captionLines = state.caption.split(`
`).map((line) => line.trim()).filter((line) => line.length > 0).slice(-HUD_CAPTION_LINES);
    const translation = state.translation.trim();
    const original = state.original.trim();
    if (settings.mode === "translation") {
      return joinRows([translation, original]) || IDLE_LINE;
    }
    if (wordRows.length === 0 && captionLines.length === 0)
      return IDLE_LINE;
    return [
      ...padRows(wordRows, wordRowsFor(settings.mode)),
      EMPTY_ROW,
      ...padRows(captionLines, HUD_CAPTION_LINES)
    ].join(`
`);
  }
  function padRows(rows, count) {
    return [...rows, ...Array(Math.max(0, count - rows.length)).fill(EMPTY_ROW)];
  }
  function joinRows(rows) {
    return rows.filter((row) => row.length > 0).join(`
`);
  }
  function formatWords(words) {
    return words.map((w) => `${w.isUpgrade ? "^ " : ""}${w.word} -> ${w.translation}`);
  }
  function maybePinyin(text, settings) {
    if (!settings.pinyinDisplay)
      return text;
    if (!/[\u4e00-\u9fff]/.test(text))
      return text;
    return convertToPinyin(text);
  }

  // src/shared/script.ts
  var LANGUAGE_SCRIPTS = {
    zh: "han",
    en: "latin",
    es: "latin",
    fr: "latin",
    de: "latin",
    it: "latin",
    pt: "latin",
    nl: "latin",
    tr: "latin",
    ru: "cyrillic",
    ar: "arabic",
    ko: "hangul"
  };
  var COUNTERS = [
    ["han", /[\u4e00-\u9fff]/g, 3],
    ["hangul", /[\uac00-\ud7af\u1100-\u11ff]/g, 3],
    ["cyrillic", /[\u0400-\u04ff]/g, 1],
    ["arabic", /[\u0600-\u06ff]/g, 1],
    ["latin", /[A-Za-z\u00c0-\u024f]/g, 1]
  ];
  var ANNOTATION = /\([^)]*\)/g;
  function scriptOfLanguage(language) {
    const bare = language.toLowerCase().split(/[-_]/)[0] ?? language;
    return LANGUAGE_SCRIPTS[bare] ?? "unknown";
  }
  function scriptOfText(text) {
    const body = text.replace(ANNOTATION, "");
    let best = "unknown";
    let bestScore = 0;
    for (const [script, pattern, weight] of COUNTERS) {
      const score = (body.match(pattern)?.length ?? 0) * weight;
      if (score > bestScore) {
        best = script;
        bestScore = score;
      }
    }
    return best;
  }
  function utteranceInInputLanguage(text, inputLanguage2, outputLanguage2) {
    const input = scriptOfLanguage(inputLanguage2);
    const output = scriptOfLanguage(outputLanguage2);
    if (input === "unknown" || output === "unknown" || input === output)
      return true;
    const got = scriptOfText(text);
    return got === "unknown" || got === input;
  }

  // src/generated/known-en.json
  var known_en_default = ["you", "i", "the", "to", "a", "'s", "it", "and", "that", "'t", "of", "is", "in", "what", "we", "me", "this", "he", "for", "my", "on", "have", "your", "do", "was", "'m", "no", "not", "be", "are", "don", "'re", "know", "can", "with", "but", "all", "so", "just", "there", "here", "they", "like", "'ll", "get", "she", "go", "if", "right", "out", "about", "up", "at", "him", "now", "oh", "one", "come", "well", "her", "how", "yeah", "'ve", "will", "got", "want", "think", "as", "see", "did", "good", "who", "why", "from", "let", "his", "yes", "when", "going", "time", "an", "okay", "back", "look", "us", "would", "them", "where", "were", "take", "then", "had", "or", "been", "our", "gonna", "tell", "really", "man", "some", "say", "hey", "could", "'d", "didn", "by", "need", "something", "has", "too", "more", "way", "down", "make", "very", "never", "only", "people", "over", "because", "little", "please", "love", "should", "mean", "said", "sorry", "give", "off", "am", "thank", "any", "two", "even", "much", "doing", "sure", "thing", "these", "help", "first", "into", "anything", "still", "find", "life", "nothing", "sir", "day", "god", "work", "their", "uh", "again", "maybe", "must", "before", "other", "wait", "stop", "call", "after", "won", "talk", "away", "than", "thought", "home", "night", "put", "great", "those", "last", "better", "everything", "told", "mr.", "new", "things", "always", "keep", "long", "years", "leave", "does", "money", "around", "doesn", "name", "place", "ever", "feel", "guys", "father", "guy", "made", "old", "isn", "which", "big", "lot", "done", "hello", "nice", "believe", "girl", "someone", "fine", "thanks", "wanted", "kind", "coming", "house", "every", "ok", "through", "being", "course", "stay", "left", "dad", "enough", "happened", "came", "may", "mother", "wrong", "world", "bad", "might", "three", "today", "listen", "another", "understand", "hear", "remember", "ask", "own", "same", "show", "else", "kill", "talking", "found", "next", "getting", "care", "car", "looking", "son", "try", "woman", "went", "hi", "dead", "many", "mind", "wasn", "friend", "best", "mom", "hell", "morning", "trying", "boy", "together", "yourself", "job", "saw", "family", "real", "without", "baby", "room", "wouldn", "already", "move", "most", "seen", "live", "miss", "actually", "huh", "shit", "both", "heard", "once", "ready", "head", "called", "used", "idea", "knew", "hold", "happy", "door", "such", "fuck", "brother", "also", "pretty", "bit", "took", "haven", "yet", "men", "whole", "start", "use", "while", "since", "wife", "days", "guess", "tomorrow", "matter", "meet", "bring", "tonight", "everyone", "run", "wanna", "hard", "ah", "alone", "myself", "school", "gone", "um", "end", "saying", "phone", "play", "looks", "couldn", "fucking", "problem", "few", "friends", "gotta", "ago", "open", "anyone", "killed", "hope", "face", "until", "lost", "police", "excuse", "turn", "business", "case", "wants", "says", "true", "die", "heart", "soon", "each", "worry", "later", "year", "watch", "music", "hand", "having", "probably", "beautiful", "doctor", "sit", "eat", "thinking", "young", "second", "working", "water", "person", "part", "kids", "late", "stuff", "exactly", "under", "death", "minute", "pay", "crazy", "forget", "everybody", "kid", "change", "gave", "happen", "damn", "five", "drink", "far", "knows", "its", "whatever", "eyes", "shut", "aren", "hit", "taking", "easy", "times", "check", "hands", "minutes", "deal", "different", "means", "point", "inside", "makes", "asked", "somebody", "mine", "making", "body", "afraid", "sleep", "chance", "dear", "quite", "four", "anyway", "close", "ain", "party", "fun", "against", "word", "comes", "important", "set", "shall", "story", "number", "daughter", "least", "waiting", "hurt", "wish", "moment", "fight", "week", "husband", "girls", "rest", "married", "fire", "game", "nobody", "mr", "children", "side", "stand", "read", "though", "cut", "started", "sister", "supposed", "between", "child", "goes", "hours", "speak", "women", "behind", "almost", "truth", "blood", "able", "lady", "anymore", "playing", "gets", "shot", "reason", "trouble", "break", "war", "city", "walk", "town", "trust", "dr.", "met", "office", "question", "brought", "yours", "welcome", "high", "wow", "couple", "half", "died", "cool", "free", "either", "seems", "power", "whoa", "bye", "buy", "telling", "honey", "tried", "front", "team", "answer", "gun", "boys", "line", "send", "news", "stupid", "bed", "hurry", "full", "months", "save", "sometimes", "become", "along", "hate", "food", "outside", "light", "l", "needs", "dog", "country", "clear", "order", "em", "fact", "lord", "captain", "six", "hot", "funny", "black", "mrs.", "alive", "pick", "feeling", "living", "cause", "ahead", "lose", "king", "plan", "dinner", "sighs", "sort", "leaving", "shouldn", "running", "boss", "alright", "promise", "taken", "safe", "ma", "book", "sent", "white", "hour", "anybody", "small", "perfect", "'cause", "lives", "special", "parents", "s", "john", "himself", "perhaps", "sounds", "serious", "sick", "company", "ha", "scared", "uncle", "poor", "red", "past", "earth", "possible", "shoot", "touch", "sound", "top", "ass", "laughs", "cannot", "asking", "win", "glad", "control", "hmm", "human", "drive", "hair", "jack", "bitch", "luck", "murder", "happens", "air", "ten", "daddy", "finally", "chuckles", "fast", "cold", "seem", "laughing", "words", "hospital", "street", "hang", "dance", "meeting", "till", "others", "catch", "follow", "sense", "sex", "lie", "evening", "master", "known", "dream", "write", "million", "voice", "sweet", "rather", "felt", "sign", "lucky", "somewhere", "bet", "o", "jesus", "longer", "calling", "worked", "quiet", "looked", "less", "pull", "beat", "careful", "coffee", "return", "secret", "weeks", "weren", "date", "seeing", "fall", "given", "ooh", "fault", "straight", "takes", "song", "future", "gentlemen", "loved", "changed", "road", "calm", "wonderful", "mad", "turned", "drop", "ladies", "learn", "step", "absolutely", "early", "explain", "clean", "piece", "yesterday", "throw", "picture", "land", "feet", "wonder", "questions", "speaking", "worth", "darling", "dude", "giving", "president", "eye", "quick", "moving", "figure", "state", "strong", "sam", "none", "amazing", "ones", "works", "act", "needed", "weird", "law", "worried", "report", "goodbye", "missing", "choice", "happening", "chief", "wedding", "strange", "general", "pain", "'am", "kidding", "decided", "ya", "pass", "tired", "class", "officer", "kept", "wake", "worse", "busy", "eh", "mistake", "kiss", "court", "building", "finish", "during", "age", "ship", "caught", "marry", "meant", "sell", "dark", "watching", "system", "suppose", "evidence", "movie", "ride", "t", "completely", "mouth", "totally", "birthday", "tv", "forgive", "born", "imagine", "information", "instead", "definitely", "security", "certainly", "film", "month", "lying", "unless", "train", "seven", "wear", "clothes", "michael", "hotel", "christmas", "attack", "hasn", "round", "expect", "sing", "terrible", "george", "bag", "history", "blue", "near", "broke", "station", "seriously", "forever", "david", "frank", "except", "thinks", "message", "entire", "joe", "table", "talked", "across", "rock", "lovely", "handle", "middle", "buddy", "paid", "protect", "using", "floor", "ran", "swear", "spend", "situation", "ring", "anywhere", "dangerous", "bill", "york", "army", "lead", "bought", "finished", "fair", "sun", "letter", "fool", "attention", "club", "simple", "interesting", "space", "test", "box", "group", "single", "sitting", "marriage", "join", "fear", "d", "peace", "forgot", "force", "short", "normal", "charlie", "present", "enjoy", "mike", "crime", "horse", "ground", "american", "count", "area", "charge", "honor", "lunch", "miles", "radio", "idiot", "ball", "surprise", "paper", "key", "boat", "quickly", "gold", "bar", "fish", "mark", "tom", "wearing", "crying", "accident", "government", "eight", "fell", "cover", "certain", "interested", "deep", "star", "sea", "agree", "problems", "detective", "prison", "major", "stick", "offer", "difficult", "smart", "personal", "record", "stopped", "hide", "whether", "bank", "trip", "relax", "america", "public", "list", "afternoon", "brain", "fix", "bastard", "proud", "tea", "service", "screaming", "forward", "angry", "park", "soul", "fighting", "peter", "rich", "agent", "blow", "paul", "dress", "mary", "missed", "scene", "killing", "standing", "saved", "mm", "respect", "killer", "ice", "mess", "tough", "feels", "church", "sad", "cell", "drunk", "share", "camera", "mm-hmm", "within", "card", "fly", "ben", "girlfriend", "laugh", "smell", "broken", "mum", "honest", "often", "starting", "calls", "y", "spent", "third", "english", "visit", "mama", "judge", "window", "hungry", "dare", "relationship", "moved", "prove", "private", "wall", "seat", "i-i", "position", "lieutenant", "realize", "lt", "especially", "machine", "walking", "art", "pleasure", "bloody", "college", "french", "involved", "cry", "became", "lived", "impossible", "obviously", "neither", "accept", "boyfriend", "besides", "queen", "teacher", "cops", "sake", "loves", "carry", "teach", "apartment", "upset", "green", "la", "liked", "cute", "evil", "professor", "contact", "joke", "cop", "huge", "holy", "store", "jail", "likes", "lawyer", "doubt", "continue", "appreciate", "cat", "shop", "driving", "congratulations", "wrote", "village", "quit", "field", "james", "wine", "decision", "south", "sleeping", "slow", "laughter", "island", "glass", "beginning", "cash", "dying", "hundred", "whose", "difference", "plane", "push", "continues", "mmm", "singing", "eating", "north", "mrs", "tree", "madam", "gift", "truck", "putting", "bear", "board", "grab", "beer", "stuck", "magic", "support", "rules", "grunts", "partner", "reach", "wind", "colonel", "max", "immediately", "seconds", "thousand", "gives", "experience", "cheers", "victim", "upon", "computer", "christ", "planet", "promised", "bus", "henry", "dirty", "search", "staying", "dreams", "arrest", "holding", "suddenly", "usually", "lots", "shoes", "er", "jump", "rid", "yo", "knock", "owe", "harry", "grow", "worst", "river", "aunt", "patient", "kitchen", "aah", "fat", "passed", "m", "final", "summer", "bob", "listening", "escape", "everywhere", "moon", "arms", "turns", "address", "ow", "match", "gasps", "grand", "yep", "shh", "nervous", "de", "choose", "themselves", "decide", "mate", "drinking", "press", "bother", "foot", "hadn", "blame", "crap", "drugs", "type", "rings", "mission", "named", "heaven", "'ii", "picked", "paris", "race", "risk", "books", "further", "danny", "action", "allowed", "orders", "learned", "price", "arrived", "nick", "otherwise", "pictures", "fit", "smoke", "favor", "played", "notice", "awesome", "smile", "director", "guard", "begin", "spot", "surprised", "innocent", "narrator", "herself", "london", "feelings", "enemy", "battle", "ourselves", "alex", "dollars", "allow", "nine", "gay", "department", "guilty", "apart", "earlier", "duty", "jim", "suit", "bell", "west", "legs", "hero", "destroy", "stage", "bunch", "according", "chicken", "bigger", "grunting", "low", "helping", "admit", "closed", "names", "witness", "upstairs", "arm", "steal", "jimmy", "kick", "twice", "cross", "ways", "sergeant", "indeed", "gas", "keeping", "energy", "pregnant", "waste", "helped", "fired", "favorite", "tony", "taste", "locked", "places", "writing", "adam", "brothers", "starts", "prince", "form", "sold", "silly", "mention", "build", "throat", "hole", "figured", "track", "ringing", "lock", "leg", "above", "hiding", "steve", "seemed", "breakfast", "engine", "written", "complete", "video", "applause", "however", "pressure", "fresh", "weapon", "sky", "ms.", "stole", "study", "burn", "reading", "crowd", "treat", "roll", "double", "spirit", "danger", "cost", "empty", "level", "memory", "itself", "acting", "interest", "nose", "plans", "following", "bathroom", "built", "closer", "ray", "sarah", "band", "groans", "apparently", "excited", "richard", "losing", "animals", "flight", "nature", "raise", "pop", "client", "bomb", "neck", "suspect", "warm", "extra", "bottle", "van", "heavy", "mommy", "dogs", "wild", "ridiculous", "simply", "lee", "animal", "showed", "billy", "shooting", "keeps", "camp", "guns", "medical", "shame", "hoping", "whom", "bird", "majesty", "flowers", "famous", "asleep", "beauty", "driver", "keys", "rain", "awful", "large", "local", "deserve", "goddamn", "stone", "jane", "grace", "consider", "weekend", "wondering", "lay", "plenty", "willing", "pants", "sweetheart", "skin", "excellent", "asshole", "beach", "c", "faith", "beg", "fuckin", "responsible", "military", "cheering", "opportunity", "common", "bottom", "german", "whoever", "cook", "walked", "papers", "justice", "hall", "commander", "drug", "main", "knife", "devil", "necessary", "although", "princess", "lights", "flying", "dick", "rose", "knowing", "clearly", "hat", "agreed", "johnny", "corner", "code", "note", "tommy", "due", "correct", "apologize", "language", "stars", "faster", "cars", "folks", "bullshit", "i.", "fellow", "several", "grandma", "shows", "leader", "leaves", "restaurant", "east", "shouting", "blind", "ghost", "cup", "gotten", "tight", "conversation", "tells", "lies", "nor", "pulled", "hanging", "speed", "stories", "health", "advice", "held", "uh-huh", "murdered", "beyond", "rule", "hardly", "possibly", "inspector", "cousin", "trial", "emergency", "ought", "eddie", "somehow", "hearing", "states", "account", "spoke", "file", "understood", "angel", "tape", "milk", "powerful", "weapons", "practice", "manager", "pardon", "vote", "jake", "national", "career", "minister", "super", "taught", "robert", "biggest", "plays", "natural", "dancing", "copy", "plus", "martin", "cake", "freedom", "among", "breath", "operation", "chris", "crew", "challenge", "market", "meat", "towards", "bringing", "dropped", "student", "lied", "strength", "size", "breathe", "color", "monster", "loud", "photo", "aw", "nearly", "sight", "greatest", "games", "bridge", "dressed", "arrested", "horrible", "coach", "planning", "checked", "breaking", "noticed", "fantastic", "screams", "serve", "ideas", "investigation", "center", "older", "pack", "soldiers", "nonsense", "doc", "project", "training", "example", "trick", "prepared", "science", "united", "travel", "incredible", "grandpa", "paying", "character", "teeth", "criminal", "charles", "chinese", "truly", "honestly", "bro", "survive", "bobby", "target", "feed", "nurse", "e", "fake", "records", "breathing", "sweetie", "numbers", "oil", "suicide", "belong", "whoo", "perfectly", "amy", "forgotten", "remain", "original", "papa", "onto", "concerned", "credit", "ugh", "invited", "discuss", "research", "easier", "view", "chair", "hurts", "strike", "roger", "fill", "condition", "mountain", "dr", "nowhere", "sheriff", "kim", "turning", "brown", "recognize", "heads", "audience", "'all", "jealous", "pretend", "society", "finding", "shirt", "comfortable", "meaning", "guest", "pieces", "dry", "letting", "began", "aye", "jeff", "female", "release", "ho", "cards", "pray", "unfortunately", "balls", "destroyed", "ended", "universe", "prepare", "opinion", "movies", "soldier", "wash", "program", "heat", "usual", "ticket", "stolen", "prefer", "aware", "surely", "male", "base", "matters", "lift", "lab", "command", "proof", "cream", "selling", "believed", "create", "h", "afford", "sunday", "total", "dumb", "threw", "france", "birth", "created", "realized", "british", "noise", "nuts", "students", "birds", "social", "brilliant", "bodies", "tie", "opened", "ours", "bucks", "kevin", "mister", "ugly", "ryan", "focus", "dan", "opens", "exist", "followed", "england", "draw", "purpose", "letters", "daniel", "opening", "bullet", "anna", "lately", "stayed", "falling", "season", "ends", "suggest", "joy", "distance", "responsibility", "whenever", "issue", "thousands", "process", "sword", "shower", "weak", "fucked", "lonely", "happiness", "eric", "tiny", "desk", "pool", "property", "forced", "settle", "indistinct", "weight", "received", "gang", "bite", "friday", "disappeared", "interview", "expecting", "kinda", "surgery", "horses", "mayor", "babe", "ancient", "handsome", "thomas", "saturday", "staff", "lines", "unit", "fan", "gentleman", "introduce", "fate", "split", "recently", "expected", "add", "ordered", "slowly", "alarm", "member", "slept", "signed", "enter", "spanish", "garden", "brings", "brave", "pig", "model", "finger", "medicine", "access", "failed", "flat", "easily", "discovered", "based", "screw", "insane", "cares", "weather", "fingers", "san", "scott", "path", "soft", "harm", "style", "community", "sees", "basically", "al", "signal", "nope", "spare", "speech", "covered", "shake", "loose", "snow", "russian", "lake", "bright", "roof", "ohh", "sending", "paint", "remind", "pal", "naked", "post", "sugar", "heading", "streets", "damage", "silence", "doors", "pete", "ed", "success", "wet", "nah", "amount", "members", "kate", "manage", "safety", "returned", "harder", "fbi", "block", "showing", "fancy", "chef", "contract", "dig", "chest", "good-bye", "drinks", "dave", "buried", "brian", "trade", "journey", "stomach", "changes", "details", "thoughts", "divorce", "funeral", "maria", "football", "reality", "theory", "gosh", "ruined", "gate", "william", "spread", "outta", "japanese", "sudden", "coat", "sooner", "cheese", "larry", "spring", "page", "ears", "simon", "castle", "hidden", "storm", "cos", "personally", "artist", "hill", "exciting", "permission", "jerry", "expensive", "tickets", "forest", "barely", "eggs", "goin", "regret", "lesson", "lover", "bread", "andy", "subject", "legal", "growing", "ill", "jason", "mood", "owner", "caused", "beeping", "points", "dating", "loss", "secretary", "revenge", "santa", "likely", "rent", "connection", "assistant", "reasons", "yelling", "painting", "trees", "doctors", "rush", "foreign", "rough", "murderer", "century", "nights", "pair", "runs", "pocket", "farm", "matt", "bike", "obvious", "ate", "grew", "professional", "tim", "goodness", "parts", "alan", "university", "square", "grandfather", "europe", "genius", "cases", "ruin", "winter", "tongue", "memories", "da", "buying", "cancer", "clock", "ocean", "dna", "liar", "tour", "thief", "bleep", "lisa", "rights", "including", "competition", "smith", "planned", "emily", "boring", "victims", "mentioned", "bones", "plant", "bless", "warning", "knocking", "re", "crash", "bedroom", "lower", "silver", "groaning", "madame", "defense", "results", "toilet", "event", "complicated", "shape", "priest", "royal", "cheap", "romantic", "downstairs", "invite", "fortune", "tears", "avoid", "reached", "higher", "familiar", "telephone", "burning", "filled", "kelly", "alice", "airport", "jobs", "grown", "walter", "rachel", "giant", "insurance", "woods", "n", "scare", "pleased", "period", "political", "player", "stops", "secrets", "laura", "repeat", "photos", "finds", "statement", "suck", "younger", "china", "humans", "delicious", "particular", "proper", "rome", "belongs", "attacked", "bath", "hired", "site", "knowledge", "b", "led", "guests", "celebrate", "map", "horn", "eventually", "pity", "powers", "ashamed", "assume", "glasses", "rise", "fixed", "request", "officers", "pounds", "data", "carefully", "per", "depends", "jury", "waited", "positive", "attorney", "direction", "families", "'clock", "doin", "forces", "location", "walls", "useless", "grant", "saving", "speaks", "fought", "meal", "deliver", "answers", "changing", "temple", "scary", "millions", "offered", "regular", "carrying", "official", "jacket", "switch", "grave", "chase", "role", "odd", "sexy", "faces", "becomes", "closes", "badly", "tall", "confused", "affair", "television", "shock", "raised", "panting", "pizza", "image", "clears", "golden", "patients", "watched", "committed", "sexual", "suffer", "arthur", "wherever", "plate", "appear", "chocolate", "clever", "hm", "mercy", "shots", "lucy", "dealing", "trap", "charges", "phil", "bang", "poison", "butt", "drove", "yourselves", "headed", "babies", "yellow", "soup", "mystery", "picking", "sat", "wound", "traffic", "courage", "hunt", "indian", "rat", "terms", "italian", "emma", "checking", "disease", "managed", "winner", "council", "appointment", "monday", "crack", "threat", "jenny", "physical", "nation", "source", "chose", "healthy", "carl", "victory", "rick", "stood", "kicked", "annie", "disgusting", "palace", "below", "shopping", "neighborhood", "march", "lips", "midnight", "piss", "advantage", "pure", "india", "aside", "jerk", "mail", "dawn", "effect", "spell", "freak", "wood", "screwed", "enemies", "gary", "awake", "chuckling", "vacation", "violence", "leo", "grandmother", "modern", "luke", "firm", "prime", "heh", "touched", "talent", "whore", "piano", "license", "cooking", "honour", "concern", "moves", "available", "factory", "gods", "value", "central", "union", "mirror", "studio", "media", "taxi", "dies", "iron", "hearts", "desire", "rob", "claire", "fred", "songs", "washington", "monkey", "pride", "pills", "miracle", "swim", "burned", "smells", "joking", "christian", "bleeding", "hook", "beating", "protection", "treatment", "ear", "carter", "metal", "disappear", "grateful", "extremely", "treasure", "rescue", "capable", "passing", "chatter", "result", "suffering", "sisters", "laid", "governor", "guards", "louis", "text", "literally", "remove", "becoming", "performance", "stronger", "rate", "deeply", "scream", "desert", "vehicle", "illegal", "pulling", "throwing", "josh", "unbelievable", "ted", "zero", "dean", "curious", "sean", "candy", "bone", "tied", "edge", "load", "susan", "ahh", "mountains", "boom", "former", "holiday", "riding", "scoffs", "hundreds", "motherfucker", "sue", "bags", "stealing", "appears", "arrive", "remains", "decent", "issues", "tip", "fail", "bride", "pissed", "penny", "claim", "friendship", "desperate", "flower", "dramatic", "refuse", "solve", "theme", "loving", "properly", "dragon", "mostly", "chuck", "directly", "surface", "false", "cast", "junior", "hunting", "silent", "thou", "egg", "germany", "punch", "africa", "woke", "intelligence", "borrow", "winning", "falls", "popular", "escaped", "witch", "convinced", "warn", "announcer", "champagne", "dust", "kyle", "someday", "fallen", "stranger", "presence", "tear", "st.", "internet", "monsieur", "therefore", "technology", "tires", "toast", "wise", "clark", "americans", "notes", "smoking", "hank", "ls", "april", "wolf", "precious", "rooms", "coast", "treated", "material", "released", "uniform", "hated", "considered", "rice", "exchange", "steps", "blake", "convince", "beast", "cow", "files", "signs", "drag", "cab", "hung", "carried", "ordinary", "successful", "eve", "mistakes", "houses", "chattering", "brains", "japan", "creature", "fourth", "separate", "cleaning", "california", "lf", "ll", "shift", "elizabeth", "chicago", "exact", "karen", "goal", "expert", "served", "direct", "score", "row", "marks", "twenty", "receive", "series", "section", "pilot", "jackson", "darkness", "thy", "sale", "destiny", "cure", "spoken", "armed", "rare", "helen", "grade", "juice", "wide", "tower", "solution", "schedule", "explosion", "wheel", "cigarette", "julie", "fruit", "blew", "victor", "talks", "sacrifice", "range", "button", "reports", "prisoner", "pie", "effort", "youth", "pot", "eaten", "taylor", "knees", "garage", "parking", "ambulance", "staring", "chances", "circumstances", "sin", "gordon", "progress", "unusual", "county", "stairs", "campaign", "'mon", "vision", "reporter", "equipment", "moments", "joey", "mass", "alien", "trapped", "helps", "route", "defend", "trace", "nasty", "tests", "magazine", "rocks", "dump", "rude", "searching", "clue", "connected", "amen", "pushed", "merry", "zone", "senior", "closing", "freeze", "emperor", "incident", "snake", "mexico", "lily", "actor", "newspaper", "sentence", "greg", "leading", "friendly", "jones", "chosen", "engaged", "julia", "charming", "mustn", "anger", "spending", "learning", "spy", "sharp", "shadow", "warrant", "elevator", "kingdom", "ricky", "jamie", "squad", "shoulder", "wave", "amanda", "highness", "kinds", "fishing", "sometime", "attitude", "sucks", "negative", "screen", "workers", "bored", "cameras", "similar", "understanding", "beeps", "chain", "bull", "gasping", "fully", "robin", "collect", "gorgeous", "morgan", "passion", "writer", "empire", "international", "curse", "hire", "bastards", "puts", "leads", "id", "blows", "sons", "estate", "customers", "maggie", "gunshot", "i-", "device", "troops", "hug", "design", "movement", "thunder", "object", "loser", "pen", "sobbing", "politics", "despite", "alcohol", "climb", "clients", "conference", "provide", "marty", "seek", "witnesses", "earn", "trash", "valley", "fashion", "howard", "episode", "prize", "previously", "sports", "wanting", "debt", "wishes", "hitler", "wire", "thee", "circle", "approach", "stock", "facts", "remembered", "percent", "normally", "tail", "joined", "education", "bravo", "library", "rape", "wings", "growling", "thrown", "tank", "exhales", "authority", "current", "failure", "nightmare", "hitting", "glory", "knocked", "studying", "barry", "agency", "apple", "border", "rope", "duck", "reputation", "confidence", "yard", "beloved", "lack", "actual", "skills", "films", "mental", "salt", "flesh", "anne", "secure", "highly", "federal", "sand", "emotional", "setting", "nothin", "senator", "services", "robbery", "hates", "fed", "reward", "theater", "johnson", "commit", "patrick", "entirely", "extraordinary", "ships", "opposite", "parties", "stands", "terry", "chat", "events", "mummy", "bay", "slip", "disappointed", "settled", "begins", "andrew", "alert", "detail", "pink", "fellas", "accepted", "background", "garbage", "panic", "minds", "belt", "blowing", "hollywood", "agreement", "jackie", "pushing", "ability", "tiger", "whispering", "culture", "saint", "jesse", "task", "solid", "doll", "intend", "district", "pa", "gee", "custody", "ignore", "naturally", "useful", "attempt", "abandoned", "cutting", "kissed", "guarantee", "barking", "gather", "policy", "u.s.", "violent", "maid", "embarrassing", "childhood", "wasting", "bow", "chick", "sara", "disaster", "revolution", "online", "f", "demon", "heavily", "coincidence", "perform", "thin", "terrific", "mac", "crown", "identity", "virgin", "impressive", "windows", "no-one", "potential", "guitar", "committee", "dozen", "delivery", "advance", "quietly", "stan", "teaching", "hunter", "latest", "hurting", "swing", "capital", "counting", "drew", "dirt", "whistle", "marie", "hits", "doug", "deny", "urgent", "threatened", "behavior", "molly", "mixed", "stays", "assure", "subtitles", "explanation", "wins", "unique", "chasing", "billion", "duke", "production", "slave", "agents", "carol", "lets", "cruel", "mask", "sally", "behave", "bury", "massive", "pathetic", "species", "approaching", "jo", "loan", "struggle", "dish", "trusted", "jumped", "firing", "channel", "abby", "stopping", "asks", "jean", "swimming", "daily", "basement", "linda", "quarter", "erm", "bound", "navy", "article", "guide", "accused", "transfer", "guts", "quality", "fella", "roman", "greater", "damned", "couch", "cheer", "vegas", "shoe", "title", "shy", "punishment", "los", "clicks", "'you", "closet", "bye-bye", "fever", "coward", "flash", "impressed", "bruce", "siren", "prisoners", "sides", "bowl", "katie", "supply", "sensitive", "hopefully", "rolling", "roy", "dollar", "tone", "voices", "g", "'i", "cheating", "confess", "demand", "museum", "unknown", "drama", "suspicious", "adult", "todd", "frightened", "warned", "steady", "kills", "crossed", "lou", "particularly", "sandwich", "laws", "joint", "bullets", "package", "trained", "thursday", "boots", "possibility", "albert", "civil", "june", "germans", "baseball", "express", "miserable", "tuesday", "parker", "lion", "joseph", "refused", "shine", "assault", "hong", "jokes", "breaks", "argue", "you-", "trail", "option", "recall", "mighty", "collection", "oliver", "wilson", "accent", "believes", "decisions", "embarrassed", "mobile", "customer", "terribly", "sec", "charity", "considering", "pussy", "donna", "protecting", "flag", "kidnapped", "italy", "balance", "creatures", "nuclear", "wallet", "shout", "vincent", "entered", "impression", "angela", "jay", "degrees", "favour", "reaction", "network", "jessica", "version", "concert", "gear", "singer", "diamond", "defeat", "steven", "lane", "blast", "wounded", "anytime", "partners", "ages", "charlotte", "ceremony", "league", "bars", "orange", "specific", "conditions", "plastic", "crisis", "fifth", "term", "self", "offering", "bud", "suffered", "reported", "commissioner", "rip", "mysterious", "entrance", "messed", "tunnel", "designed", "neighbor", "aboard", "sweat", "justin", "ghosts", "crimes", "costs", "deserves", "dreaming", "bust", "el", "teddy", "kong", "messages", "enjoying", "afterwards", "comfort", "mason", "surrender", "gym", "kitty", "crush", "yup", "arranged", "suits", "pee", "stress", "cave", "wing", "jordan", "arrange", "comrade", "noble", "tricks", "betty", "launch", "legend", "mix", "golf", "imagination", "fox", "kissing", "butter", "tax", "gross", "edward", "texas", "insist", "marcus", "classic", "selfish", "skull", "frankie", "shown", "bat", "survived", "print", "champion", "bills", "therapy", "lifetime", "throughout", "a.m.", "nathan", "toward", "sauce", "experiment", "margaret", "describe", "ross", "grass", "cheat", "attend", "homework", "lewis", "betrayed", "servant", "cap", "tyler", "bible", "practically", "catherine", "steel", "wipe", "burns", "j", "generation", "cabin", "financial", "industry", "bond", "sheep", "scientists", "beaten", "heck", "deck", "fans", "script", "brand", "degree", "painful", "coughing", "religion", "cats", "stephen", "influence", "fuel", "drawing", "uh-oh", "rabbit", "exercise", "attractive", "touching", "virus", "realise", "torture", "blessed", "plain", "rebecca", "recent", "barbara", "footsteps", "sacred", "removed", "pretending", "wasted", "jewish", "goodnight", "robot", "crystal", "confirm", "lad", "mile", "division", "scratch", "reminds", "walks", "ending", "russia", "contest", "valuable", "distant", "dumped", "motion", "electricity", "centre", "murders", "tina", "jeremy", "seal", "standard", "ellen", "wore", "surrounded", "struck", "inform", "gentle", "status", "purse", "prints", "players", "charged", "begging", "delivered", "kenny", "buck", "nina", "construction", "confirmed", "confession", "trigger", "cells", "frankly", "ali", "exit", "response", "cancel", "argument", "principal", "turkey", "lucas", "clinic", "greetings", "neighbors", "vice", "toy", "hannah", "everyday", "generous", "gain", "idiots", "holly", "enjoyed", "jungle", "link", "underground", "smiling", "mistress", "teams", "product", "beef", "whispers", "religious", "presents", "identify", "chip", "chffffff", "surveillance", "carlos", "vampire", "routine", "uses", "michelle", "underneath", "systems", "temperature", "waves", "tribe", "brad", "deputy", "sophie", "headquarters", "equal", "phones", "ken", "reckon", "related", "incredibly", "chill", "spit", "tracks", "oscar", "makeup", "bug", "sounded", "spirits", "nerve", "divorced", "stake", "port", "doorbell", "worries", "nephew", "miller", "units", "just-", "proceed", "landing", "traitor", "outfit", "chloe", "bail", "fields", "patience", "recording", "foolish", "loaded", "tokyo", "davis", "costume", "wayne", "injured", "somethin", "ian", "pet", "cage", "digging", "spain", "seats", "awkward", "cleaned", "pattern", "filthy", "visiting", "jews", "answering", "concentrate", "someplace", "citizens", "aim", "nancy", "affairs", "thick", "sport", "basic", "electric", "pleasant", "cliff", "nail", "russell", "environment", "western", "average", "ease", "raped", "interrupt", "judy", "satisfied", "beep", "starving", "documents", "anniversary", "beth", "election", "warrior", "r", "forth", "fetch", "banks", "placed", "timing", "stones", "complex", "frozen", "replace", "prayer", "skip", "angeles", "guilt", "tune", "woo", "actions", "conscience", "officially", "martha", "machines", "smaller", "determined", "blown", "hail", "unhappy", "booth", "pour", "berlin", "cleared", "packed", "wrap", "randy", "behalf", "reasonable", "trunk", "homes", "festival", "tradition", "cigarettes", "le", "beside", "harvey", "motive", "beings", "bishop", "dealer", "defendant", "backup", "wounds", "ouch", "ann", "nearby", "drank", "effects", "jonathan", "dennis", "benefit", "adventure", "p", "territory", "ve", "apology", "dylan", "unlike", "owns", "boxes", "thus", "clay", "developed", "busted", "pipe", "gray", "no.", "goods", "favourite", "salad", "loyal", "atmosphere", "eva", "freaking", "dropping", "strangers", "mouse", "downtown", "francisco", "heroes", "pit", "rotten", "paradise", "meantime", "jess", "organization", "hills", "exam", "cock", "fairy", "earl", "comment", "activity", "frame", "knight", "testing", "habit", "shelter", "flow", "jennifer", "holes", "prevent", "anthony", "lend", "cooper", "figures", "boston", "sample", "strip", "landed", "buzzing", "monk", "slightly", "produce", "annoying", "judgment", "laundry", "ron", "lousy", "souls", "existence", "belly", "tries", "foster", "returning", "answered", "ward", "plants", "actress", "chairman", "individual", "hopes", "tattoo", "fence", "sink", "punk", "confident", "yay", "mistaken", "limit", "bothering", "st", "uncomfortable", "wednesday", "gifts", "policeman", "na", "precisely", "lawyers", "greek", "merely", "criminals", "underwear", "hoped", "earned", "reveal", "appeared", "derek", "heavens", "personality", "batman", "virginia", "wives", "colour", "worker", "pope", "instructions", "intelligent", "worrying", "vince", "comin", "cried", "traveling", "bells", "x", "impact", "robbed", "relief", "host", "footage", "odds", "patrol", "circus", "mud", "captured", "lessons", "occasion", "sets", "pulse", "ad", "invented", "diamonds", "matthew", "auntie", "cloud", "francis", "angels", "hers", "classes", "mm-hm", "signature", "complain", "blah", "monitor", "options", "claims", "flies", "pat", "britain", "hid", "wailing", "listened", "countries", "vic", "yell", "rats", "wondered", "smooth", "resist", "companies", "fantasy", "passport", "pitch", "hammer", "homicide", "casey", "holds", "flew", "jacob", "noon", "helicopter", "dishes", "spin", "charm", "slap", "apply", "fools", "screeching", "discover", "previous", "kit", "authorities", "moaning", "photograph", "sales", "fifty", "mickey", "beneath", "farewell", "clouds", "slipped", "represent", "deaf", "facing", "offense", "citizen", "clown", "snap", "messing", "hood", "twelve", "interests", "cheated", "liz", "informed", "humanity", "producer", "technically", "accounts", "extreme", "gettin", "cia", "ii", "pays", "profile", "oxygen", "jeez", "gene", "shed", "minor", "ex", "theatre", "scientific", "lovers", "chaos", "l.a.", "rocket", "math", "stubborn", "august", "oi", "chips", "intense", "grey", "talkin", "terrorist", "angle", "invitation", "gus", "gambling", "respond", "thirty", "procedure", "absolute", "investigate", "tragedy", "stable", "session", "capture", "marrying", "ripped", "attacks", "stretch", "bush", "dates", "unable", "gates", "mars", "artists", "increase", "tastes", "cared", "bottles", "highest", "whirring", "meanwhile", "nate", "grabbed", "pigs", "chop", "olivia", "wheels", "shocked", "reverend", "commercial", "escort", "engagement", "corpse", "louise", "worthy", "scale", "beats", "williams", "threatening", "exists", "academy", "acts", "hop", "judges", "furniture", "shared", "ralph", "consequences", "engineer", "schools", "softly", "bombs", "caroline", "shark", "transport", "population", "succeed", "creepy", "sneak", "studies", "destruction", "keith", "protected", "monsters", "joining", "punished", "lightning", "malcolm", "shell", "fascinating", "chamber", "ethan", "romance", "instance", "jumping", "groups", "exhausted", "testify", "studied", "walker", "pin", "imagined", "drill", "investigating", "ye", "experienced", "elena", "necklace", "loyalty", "junk", "cole", "cries", "stanley", "rita", "southern", "blocks", "emotions", "begun", "maya", "liver", "serving", "matches", "surgeon", "granted", "jazz", "july", "supplies", "deeper", "typical", "kicking", "obey", "dancer", "remote", "daughters", "moron", "latin", "teachers", "toby", "sandy", "dragged", "strategy", "parent", "jin", "album", "compared", "rubbish", "helpful", "powder", "sync", "bum", "passes", "joan", "fort", "choices", "alley", "supper", "penis", "alibi", "sammy", "pole", "coke", "scientist", "fighter", "highway", "blade", "alpha", "diet", "liquor", "jet", "widow", "liberty", "philip", "moral", "carrie", "award", "grief", "thirsty", "ashley", "random", "suspects", "intention", "julian", "active", "tools", "driven", "trauma", "headache", "safely", "alexander", "knee", "lads", "novel", "conversations", "waters", "lookin", "invisible", "internal", "peaceful", "humming", "washed", "drives", "talented", "li", "aid", "elephant", "troubles", "core", "serial", "'s-", "painted", "'the", "divine", "jam", "goat", "opera", "thieves", "guessing", "objection", "whiskey", "florida", "resistance", "dressing", "attached", "aaron", "brief", "punish", "eternal", "lois", "'and", "required", "victoria", "fabulous", "twins", "characters", "cooked", "ln", "ruth", "dreamed", "arts", "naughty", "stabbed", "tend", "diane", "tap", "soap", "locker", "development", "images", "prick", "global", "string", "bitter", "sharing", "corn", "craig", "fits", "tent", "forms", "votes", "harold", "propose", "monica", "constantly", "granny", "nicely", "nerves", "arguing", "abuse", "relatives", "survival", "gloves", "tracking", "zoe", "u", "bend", "review", "connect", "separated", "elder", "beard", "admiral", "diana", "salary", "areas", "disturb", "pro", "maintain", "solved", "wealth", "bitches", "possession", "sang", "gimme", "plates", "shoulders", "burnt", "recorded", "upper", "counts", "tale", "profit", "colleague", "warehouse", "hostage", "shore", "porn", "miami", "fifteen", "visitors", "bo", "net", "insult", "owen", "cities", "causing", "lemon", "heal", "banging", "honeymoon", "appeal", "marshall", "critical", "creating", "scotland", "crane", "enormous", "testimony", "praise", "fights", "indians", "commission", "growls", "nicole", "sins", "fraud", "branch", "happily", "bout", "covering", "occurred", "beans", "raw", "muscle", "pages", "tense", "relationships", "management", "assignment", "blonde", "catching", "exposed", "canada", "dont", "han", "von", "comedy", "marco", "stroke", "whistling", "buildings", "shaking", "p.m.", "facility", "appropriate", "remarkable", "transferred", "drawn", "tits", "clicking", "symbol", "motor", "employees", "ambassador", "mothers", "pile", "feeding", "soda", "checks", "bears", "cookies", "slut", "awfully", "stepped", "toys", "levels", "differently", "magnificent", "steak", "tube", "leaders", "superior", "herr", "pan", "expression", "currently", "throne", "deadly", "bee", "tooth", "depressed", "potatoes", "wicked", "resources", "native", "centuries", "karl", "poetry", "multiple", "cable", "shortly", "buzz", "socks", "fingerprints", "goddess", "chin", "anxious", "september", "colors", "basketball", "promises", "explained", "appearance", "musical", "sends", "slide", "aii", "shawn", "ultimate", "pork", "communication", "payment", "structure", "paperwork", "obsessed", "lazy", "russians", "actors", "squeeze", "magical", "colleagues", "admire", "madness", "roads", "entry", "injury", "burden", "racing", "manner", "freezing", "bits", "norman", "mount", "battery", "dessert", "pound", "visited", "motel", "rumbling", "cinema", "fond", "halfway", "rifle", "reception", "statue", "fridge", "brick", "abandon", "lap", "natalie", "wars", "recommend", "brush", "nelson", "pill", "concept", "w", "delay", "quarters", "korea", "janet", "rub", "mall", "soil", "complaint", "sail", "baker", "coughs", "bucket", "description", "badge", "measure", "hip", "function", "indistinctly", "harris", "foundation", "labor", "willie", "waiter", "homeless", "proved", "unfortunate", "log", "meetings", "giggles", "combat", "poem", "polish", "handed", "mia", "weed", "raymond", "tons", "satellite", "jersey", "eagle", "privacy", "chapter", "treating", "wisdom", "flip", "entering", "barn", "farmer", "clan", "budget", "pub", "temporary", "effective", "sonny", "wendy", "juan", "lamb", "plot", "riley", "proposal", "sticks", "searched", "blessing", "rage", "bothered", "sydney", "basis", "manners", "recover", "twist", "neil", "leak", "item", "catholic", "sighing", "retired", "kings", "inner", "cents", "affect", "forbidden", "patch", "drops", "necessarily", "provided", "meters", "booked", "returns", "gloria", "fires", "humor", "torn", "e-mail", "rocky", "introduced", "creative", "betray", "soviet", "various", "added", "discovery", "cowboy", "suspected", "suggested", "delighted", "sticking", "dive", "shane", "radar", "prosecutor", "amber", "vast", "quinn", "owned", "cookie", "finest", "felix", "pump", "valentine", "counter", "sorts", "coin", "warren", "slaves", "marine", "illness", "sack", "bid", "require", "moscow", "largest", "washing", "achieve", "causes", "k", "mo", "dope", "nest", "palm", "logan", "constant", "b.", "boo", "medication", "gravity", "booze", "noah", "evan", "abroad", "christine", "rising", "analysis", "cuts", "eats", "employee", "vodka", "damaged", "solar", "height", "pops", "yards", "terrified", "suitcase", "chemical", "preparing", "advanced", "fund", "wears", "chirping", "web", "phase", "prom", "suggesting", "fleet", "lame", "irish", "editor", "october", "assumed", "whip", "mel", "region", "amongst", "temper", "discussion", "engines", "operate", "sunshine", "acted", "undercover", "horror", "tested", "smash", "contrary", "roses", "poker", "wrapped", "korean", "graham", "mi", "fu", "ivan", "focused", "liam", "tragic", "carla", "demons", "rounds", "entertainment", "gathered", "uhh", "yells", "lincoln", "crossing", "blanket", "nut", "travis", "pockets", "limited", "paintings", "sober", "caesar", "sis", "intended", "niece", "computers", "tennis", "needle", "chicks", "traditional", "delicate", "independent", "leslie", "lauren", "grandson", "repair", "a.", "brandon", "executive", "colin", "recognized", "holmes", "regarding", "weakness", "aliens", "gunshots", "european", "method", "tool", "demands", "permit", "towel", "daisy", "nowadays", "spider", "northern", "rangers", "zoo", "praying", "antonio", "passengers", "con", "australia", "technique", "cellphone", "gently", "operations", "planes", "bunny", "gunfire", "shining", "backwards", "skill", "uh-", "baron", "kidnapping", "iike", "marshal", "petty", "sealed", "massage", "raising", "menu", "diary", "fucker", "wagon", "audition", "mitch", "mexican", "casino", "bacon", "diego", "dutch", "promotion", "click", "forgiveness", "burst", "permanent", "interfere", "chanting", "dammit", "spencer", "recovered", "registered", "sunny", "packing", "scenes", "superman", "questioning", "unfair", "admitted", "ancestors", "polite", "completed", "swallow", "conduct", "prayers", "sheet", "fried", "avenue", "poisoned", "reverse", "newspapers", "ford", "complaining", "senses", "investment", "absurd", "potato", "understands", "grows", "inspired", "ruby", "celebrating", "tag", "ram", "requires", "bonnie", "bugs", "leonard", "elliot", "hooked", "jill", "ranch", "safer", "worn", "crashing", "lands", "heather", "ash", "leather", "grounds", "assuming", "nails", "dana", "conspiracy", "thanksgiving", "pierre", "guardian", "rumors", "yen", "megan", "ashes", "terror", "misunderstanding", "tire", "boats", "parade", "halt", "immunity", "adults", "steam", "kang", "closely", "pearl", "soccer", "adrian", "priority", "shouts", "donald", "happier", "khan", "struggling", "root", "larger", "november", "boot", "conflict", "laughed", "debbie", "cherry", "honking", "concerns", "celebration", "sore", "unconscious", "cattle", "breasts", "fairly", "fee", "recognise", "wade", "radiation", "holidays", "raining", "forgetting", "lungs", "register", "shadows", "specifically", "sarge", "ideal", "turtle", "spoil", "deserved", "ronnie", "gina", "candidate", "lance", "types", "bloke", "explode", "immediate", "belonged", "identified", "di", "hunger", "closest", "combination", "nanny", "seth", "gabriel", "develop", "detectives", "severe", "en", "organized", "franklin", "gut", "splendid", "dismissed", "pm", "yang", "halloween", "ellie", "vulnerable", "continued", "vital", "comrades", "bureau", "drawer", "harper", "retreat", "carson", "benny", "pillow", "troy", "ace", "cart", "nap", "chan", "ham", "announce", "borrowed", "parked", "galaxy", "voted", "muffled", "sebastian", "mmm-hmm", "jewelry", "kisses", "luggage", "groom", "oops", "lighter", "masters", "alliance", "buddies", "clothing", "denied", "drown", "alike", "excellency", "relative", "photographs", "burger", "dough", "alicia", "wreck", "approve", "produced", "christina", "physically", "stations", "eli", "samantha", "spiritual", "sire", "roaring", "stab", "inch", "servants", "limits", "unexpected", "arrival", "whimpering", "basket", "sheets", "scandal", "stink", "homer", "tara", "christopher", "toes", "'t-", "shield", "shooter", "instant", "objects", "rehearsal", "disturbing", "directed", "scan", "electronic", "republic", "overnight", "counsel", "sirens", "dorothy", "bait", "dignity", "explains", "lean", "heroin", "tracy", "rex", "barney", "gossip", "humble", "economy", "worlds", "impress", "clara", "tissue", "threaten", "et", "bump", "supreme", "bingo", "mitchell", "excitement", "mankind", "document", "broad", "vietnam", "vessel", "lit", "dale", "killers", "connor", "mario", "foul", "stare", "deaths", "hut", "elements", "coma", "laying", "coffin", "paula", "cocaine", "puppy", "louder", "handled", "announcement", "oath", "mob", "cotton", "deposit", "taxes", "injuries", "jen", "autopsy", "advise", "gig", "lecture", "posted", "skinny", "lo", "include", "revealed", "infected", "relieved", "assistance", "solo", "determine", "terrorists", "elsewhere", "lamp", "practical", "marked", "adorable", "rubber", "purple", "operating", "suite", "apologies", "personnel", "beam", "poet", "samples", "arrow", "counselor", "carpet", "allen", "audrey", "spotted", "floating", "corrected", "located", "journalist", "insisted", "operator", "rely", "singh", "fooled", "arrives", "i.d.", "leon", "walt", "eastern", "ay", "shave", "remaining", "toss", "anderson", "lip", "acid", "nora", "si", "december", "anonymous", "inn", "planted", "oldest", "breast", "sixth", "error", "reporting", "egypt", "islands", "brother-in-law", "jules", "roommate", "sings", "scum", "visitor", "giggling", "described", "geez", "inches", "commitment", "hercules", "react", "cows", "protest", "misery", "theft", "embrace", "darn", "harsh", "andrea", "communicate", "fathers", "faithful", "hector", "uh-uh", "flame", "medal", "silk", "photographer", "trevor", "cemetery", "rear", "freddy", "banana", "allison", "emotion", "chap", "dated", "excuses", "shitty", "bin", "jew", "gum", "crushed", "efforts", "content", "corporal", "realised", "del", "rap", "hopeless", "debate", "era", "luckily", "ton", "liquid", "swell", "peggy", "feast", "murphy", "attracted", "application", "profession", "bench", "vanessa", "ahem", "symptoms", "scout", "crashed", "keen", "aircraft", "formed", "hon", "aggressive", "pale", "significant", "duncan", "clubs", "visual", "embassy", "defence", "cabinet", "display", "fame", "gibbs", "drowned", "wolves", "filming", "dunno", "cursed", "twin", "sorrow", "vault", "defeated", "watson", "quote", "penalty", "bargain", "pepper", "speaker", "compare", "satan", "helmet", "scar", "copies", "fuss", "envelope", "perry", "stinks", "african", "arrangements", "wished", "honored", "believing", "discussed", "assigned", "rosa", "oven", "jenna", "attacking", "tin", "sonic", "collar", "mere", "romeo", "belief", "storage", "rusty", "psycho", "climbing", "melissa", "fears", "sum", "dedicated", "ladder", "alternative", "raid", "dining", "ms", "corporate", "folk", "jon", "replaced", "bailey", "un", "heels", "duties", "smarter", "existed", "surprising", "chess", "requested", "cruise", "primary", "rhythm", "drum", "models", "motorcycle", "adopted", "barrel", "cargo", "planets", "shove", "wha", "surprises", "rosie", "dings", "trailer", "cannon", "tables", "arse", "ally", "lawrence", "wee", "tapes", "dull", "sandra", "teenage", "kent", "cooperate", "risks", "dug", "worthless", "arriving", "kindness", "ties", "items", "and-", "grip", "relations", "rumor", "skirt", "frog", "paige", "lloyd", "claimed", "perfume", "instrumental", "flames", "association", "loses", "january", "spike", "israel", "eleven", "gallery", "ginger", "activities", "iraq", "boarding", "fist", "stuffed", "improve", "creation", "connie", "infection", "strikes", "wiped", "tension", "whistles", "kindly", "certificate", "curtis", "bold", "threats", "claudia", "sid", "twisted", "suspended", "affected", "envy", "whale", "dial", "cameron", "martial", "controlled", "lung", "nigga", "coal", "upside", "imperial", "pam", "paranoid", "signing", "congress", "villa", "candles", "filling", "becky", "comic", "faint", "recovery", "volunteer", "tech", "bleed", "positions", "cindy", "narrow", "forbid", "stuart", "perspective", "faced", "neat", "pierce", "observe", "cycle", "psychic", "handling", "goose", "accidentally", "conclusion", "designer", "sits", "importance", "spots", "francs", "sweep", "destroying", "communist", "blackmail", "pacific", "risky", "glorious", "filed", "hatred", "cam", "deals", "pos", "fooling", "persons", "scotch", "executed", "brakes", "blank", "tender", "kurt", "turner", "tub", "sucker", "slight", "addition", "campus", "ritual", "prey", "so-called", "graduate", "anyways", "ew", "fry", "genuine", "ned", "judging", "doubts", "warden", "ceiling", "practicing", "somewhat", "established", "attempted", "zombie", "generations", "yöu", "gathering", "warriors", "mick", "electrical", "collins", "sobs", "couples", "depend", "institute", "miranda", "principle", "fixing", "therapist", "compete", "compliment", "worship", "residence", "democracy", "joel", "published", "myth", "helpless", "screwing", "kennedy", "execution", "appetite", "formal", "strictly", "sucked", "tanks", "chickens", "gwen", "technical", "stella", "rod", "meets", "shepherd", "brazil", "brutal", "alison", "vain", "switched", "chi", "deer", "brooklyn", "dresses", "retire", "overcome", "inspiration", "cunt", "benjamin", "nicky", "thrilled", "tae", "suggestion", "dummy", "sailor", "destination", "bass", "picnic", "assholes", "idol", "trucks", "rank", "denise", "yu", "veronica", "blocked", "strict", "hiya", "formula", "clerk", "samurai", "disturbed", "vera", "cafe", "wandering", "consciousness", "val", "nikki", "min", "bare", "hans", "caleb", "butcher", "arrangement", "chased", "ministry", "brandy", "sweater", "boobs", "locate", "apologise", "nazi", "parole", "examine", "trains", "candle", "prior", "stream", "that-", "passage", "reaching", "organ", "directions", "asses", "outer", "proves", "morris", "luxury", "pistol", "v", "losers", "funds", "sunset", "strings", "fortunately", "gotcha", "tomb", "freddie", "but-", "engineering", "element", "balloon", "ty", "broadcast", "spray", "ninja", "eternity", "handy", "to-", "crawl", "slice", "nations", "behaviour", "pace", "stiff", "lick", "concrete", "allah", "vegetables", "euros", "sausage", "constable", "spinning", "rolls", "genetic", "loudly", "old-fashioned", "marvelous", "subway", "creep", "scheme", "performed", "ex-wife", "plug", "rejected", "brenda", "respected", "backs", "protocol", "muscles", "kidney", "finishing", "products", "im", "wu", "invasion", "affection", "woody", "endless", "discipline", "horns", "absence", "waking", "dudes", "philosophy", "cracked", "nicholas", "reed", "verdict", "drake", "connections", "privilege", "anyhow", "scent", "naive", "daylight", "controls", "airplane", "values", "jolly", "swore", "blaring", "consent", "puzzle", "disagree", "argh", "winds", "vanished", "wizard", "ranger", "celebrity", "sniffles", "stores", "aha", "intentions", "plague", "farmers", "breeze", "rascal", "convenient", "bonus", "dong", "hush", "instinct", "entitled", "porter", "maurice", "wrist", "originally", "coins", "drain", "physics", "phoebe", "furious", "sniffs", "vampires", "defending", "sector", "income", "finn", "offended", "decides", "laser", "fled", "beers", "boxing", "accurate", "kung", "snakes", "thumb", "bald", "sharon", "suspicion", "convicted", "roots", "shares", "bernard", "jessie", "wang", "harrison", "blues", "confusing", "lobby", "recipe", "las", "winston", "generally", "seeking", "secretly", "declare", "freaked", "missile", "ensure", "tricky", "pointed", "hockey", "bubble", "contacts", "maximum", "reminded", "carriage", "curtain", "clues", "hostages", "circles", "author", "wallace", "receiving", "debts", "cellar", "tortured", "tips", "mates", "mortal", "reporters", "associate", "honesty", "laptop", "jung", "katherine", "rainbow", "seed", "mature", "deed", "kay", "expenses", "discussing", "pirate", "meals", "performing", "remained", "prostitute", "adams", "retirement", "platform", "claus", "erica", "beds", "writes", "illusion", "mill", "dealt", "hears", "tryin", "manhattan", "mole", "rang", "prosecution", "fatal", "copper", "troubled", "heir", "traces", "owners", "length", "dentist", "zach", "lesbian", "enterprise", "tournament", "travelling", "confessed", "roast", "website", "ja", "mikey", "flood", "harbor", "lola", "rory", "richie", "mansion", "mademoiselle", "auction", "desires", "bachelor", "haunted", "distracted", "smashed", "rodney", "scheduled", "negotiate", "champ", "allows", "shotgun", "nigger", "cocktail", "donkey", "pointing", "butler", "dizzy", "methods", "reference", "georgia", "bully", "lydia", "collapse", "alfred", "ana", "minimum", "chairs", "hee", "patty", "owes", "included", "carmen", "civilization", "prices", "wealthy", "bart", "depression", "tide", "rented", "bra", "lin", "fellows", "rot", "password", "th", "kirk", "pedro", "spill", "cured", "naomi", "hardest", "deceased", "sleepy", "static", "hawaii", "almighty", "murray", "offers", "bruno", "phrase", "disgrace", "sources", "approval", "turtles", "screech", "snack", "collected", "ding", "fur", "jewels", "jan", "cheek", "legally", "ditch", "benefits", "roars", "arnold", "dime", "domestic", "chuckle", "hack", "ransom", "chang", "bore", "muslim", "loads", "waitress", "nurses", "glenn", "spite", "rebel", "clearing", "andre", "fortunate", "survivors", "reply", "disappoint", "orbit", "expose", "gin", "austin", "toe", "sympathy", "intel", "growth", "psychiatrist", "m.", "slams", "encounter", "daphne", "passenger", "monkeys", "accompany", "hats", "column", "sigh", "pounding", "economic", "tales", "theirs", "brat", "follows", "spreading", "sister-in-law", "burt", "hilarious", "hallway", "hamilton", "the-", "exclusive", "chimes", "greet", "decades", "bowling", "buttons", "confusion", "thud", "hooker", "ruining", "dreadful", "collecting", "lions", "sheila", "douglas", "february", "elvis", "forty", "sleeps", "sung", "brass", "shrink", "zack", "whimpers", "sworn", "email", "proven", "tasty", "covers", "sandwiches", "rarely", "wyatt", "programme", "irene", "dee", "contacted", "chemistry", "assured", "applied", "elected", "subjects", "lust", "label", "shakespeare", "tan", "ego", "forgiven", "phoenix", "companion", "lottery", "worm", "publicity", "butterfly", "dialogue", "cal", "2nd", "tremendous", "pervert", "establish", "dearest", "intimate", "eager", "se", "cathy", "atlantic", "contains", "thompson", "shirley", "bets", "inhales", "presentation", "allergic", "den", "wells", "spoiled", "chen", "accomplished", "repay", "politicians", "logic", "gratitude", "afghanistan", "exception", "ultimately", "pablo", "compromise", "majority", "journal", "signals", "bent", "dock", "meg", "essential", "campbell", "climate", "experiments", "ink", "magazines", "rivers", "teresa", "administration", "passionate", "precise", "lawn", "via", "jeans", "murmuring", "resort", "announced", "buddha", "fries", "capacity", "lena", "opponent", "chains", "minus", "caitlyn", "apples", "angie", "seattle", "aww", "instrument", "healing", "convention", "messenger", "explore", "sonia", "versus", "survivor", "ruled", "boyd", "clarence", "madison", "cough", "experts", "disguise", "archer", "bicycle", "noises", "inviting", "pregnancy", "declared", "yi", "vicky", "drums", "wooden", "innocence", "mouths", "bees", "creaking", "cloth", "sasha", "unh", "skies", "painter", "allies", "miguel", "pond", "runway", "robbie", "assist", "lana", "presented", "mona", "sickness", "civilian", "fighters", "facebook", "customs", "florence", "remembers", "sharks", "juliet", "shrimp", "tore", "seventh", "ou", "avoiding", "dawson", "isaac", "rolled", "championship", "household", "float", "chad", "ballet", "cracking", "raj", "possessed", "harmless", "curiosity", "vicious", "officials", "glove", "nearest", "manny", "begged", "que", "withdraw", "shocking", "guessed", "nightmares", "greedy", "forehead", "corps", "pirates", "rudy", "reservation", "hunters", "fog", "flu", "good-looking", "hint", "peanut", "stark", "gamble", "erin", "autumn", "bracelet", "contain", "arrogant", "simpson", "piper", "knocks", "sperm", "gesture", "materials", "lindsay", "alexis", "ticking", "standards", "ribs", "receipt", "regards", "whatsoever", "homeland", "leap", "targets", "snoring", "damon", "leaf", "jar", "brooke", "proposed", "savage", "caring", "ivy", "approximately", "d.", "kidnap", "carries", "bounce", "creek", "pony", "cleaner", "businessman", "ha-ha", "lunatic", "unlikely", "gal", "situations", "colony", "sells", "choi", "chambers", "volume", "sweets", "panties", "respects", "reads", "seeds", "engage", "explosives", "stewart", "violet", "mutual", "lighting", "scores", "lenny", "savings", "beware", "stephanie", "educated", "complaints", "cassie", "doomed", "offensive", "harvest", "qualified", "relaxed", "cape", "buffalo", "triple", "fireworks", "palmer", "armor", "poverty", "leadership", "rode", "ambition", "cakes", "trousers", "bean", "melt", "racist", "bam", "ankle", "occupied", "nicer", "correctly", "terrifying", "hugh", "gasp", "villain", "willy", "marc", "draft", "factor", "whew", "countess", "portrait", "suggests", "font", "blair", "learnt", "pencil", "coordinates", "collapsed", "reserve", "jeffrey", "shirts", "umbrella", "stevie", "ta", "traveled", "auto", "logical", "chew", "eliminate", "beverly", "carbon", "cancelled", "crawling", "stepping", "independence", "medium", "canceled", "tess", "fanny", "seated", "upbeat", "asian", "drowning", "messy", "quest", "represents", "fletcher", "memorial", "doyle", "stressed", "bearing", "watches", "spoon", "cooperation", "tucker", "earthquake", "sailing", "involve", "houston", "asia", "spectacular", "reliable", "it-", "breach", "sophisticated", "echo", "indicate", "swamp", "vehicles", "manual", "elegant", "compound", "serves", "scares", "rattling", "pursue", "dreamt", "stefan", "revolutionary", "wa", "rig", "convincing", "fiona", "tribal", "cleveland", "lex", "depth", "blaming", "aids", "elaine", "wakes", "occur", "1st", "camping", "fart", "stamp", "kathy", "assassin", "approved", "crucial", "annual", "torch", "dallas", "fulfill", "bon", "resting", "reunion", "witnessed", "graduated", "sub", "howling", "clyde", "hospitals", "stall", "legacy", "otto", "riot", "shops", "whereabouts", "teenager", "samuel", "squealing", "mines", "danced", "crowded", "orleans", "literature", "3rd", "morgue", "strongest", "agnes", "transmission", "20th", "panel", "sole", "sequence", "sexually", "o.k.", "georgie", "hugo", "denny", "smack", "congratulate", "anxiety", "choking", "tolerate", "mode", "communications", "welfare", "dice", "orphan", "locks", "settlement", "advertising", "uniforms", "mcgee", "devoted", "shoots", "principles", "circuit", "nickname", "dot", "elderman", "scenario", "choir", "stunt", "smoked", "isolated", "equally", "statements", "gil", "shaw", "lipstick", "courtesy", "hobby", "hesitate", "hatch", "luis", "sylvia", "phoned", "experiences", "popped", "quid", "fragile", "husbands", "fiction", "persuade", "pastor", "dolls", "pose", "ji", "ming", "rupees", "tricked", "ruins", "sadly", "owed", "importantly", "louie", "industrial", "musician", "labour", "evolution", "salute", "ba", "cent", "bartender", "calendar", "hal", "miracles", "balcony", "horny", "regard", "valerie", "fold", "organs", "nigel", "theo", "einstein", "boris", "suitable", "inaudible", "son-in-law", "melody", "phillip", "movements", "differences", "barbecue", "trading", "strongly", "fluid", "scholarship", "translation", "cricket", "shuttle", "moans", "quicker", "picks", "murderers", "videos", "initial", "perimeter", "questioned", "yea", "cousins", "divided", "linked", "laboratory", "'but", "crab", "pulls", "landlord", "reggie", "hostile", "classified", "cultural", "measures", "update", "cottage", "backyard", "amateur", "chopper", "rash", "despair", "honorable", "shiny", "hawk", "shorts", "ni", "representative", "wong", "pouring", "distress", "tanner", "telegram", "pimp", "dip", "trophy", "marilyn", "hallelujah", "neal", "es", "howdy", "misses", "flush", "magician", "dynamite", "cuba", "conquer", "unpleasant", "jealousy", "regrets", "lifted", "increased", "toxic", "broadway", "sakes", "pudding", "rally", "needing", "bloom", "corporation", "buys", "disorder", "interrupting", "sadness", "needn", "cease", "barnes", "scoundrel", "sensible", "evans", "specialist", "dragging", "bribe", "burke", "bothers", "interrogation", "prescription", "referring", "knives", "graduation", "t-shirt", "liking", "bubbles", "grid", "haircut", "regardless", "lodge", "poisoning", "feathers", "edgar", "software", "marina", "sophia", "queens", "oak", "trips", "scaring", "avery", "awhile", "sofa", "conscious", "swords", "instincts", "deliberately", "starve", "j.", "venus", "olive", "maniac", "psychological", "robinson", "soo", "belle", "landscape", "straw", "dam", "mandy", "sayin", "accuse", "is-", "rehab", "switzerland", "agenda", "glue", "salesman", "diner", "projects", "floors", "mainly", "biological", "sincere", "weigh", "pad", "swiss", "cue", "witches", "opposed", "brand-new", "tourists", "sneaking", "harvard", "spying", "sketch", "parliament", "behold", "blamed", "topic", "offices", "sacrificed", "loop", "drivers", "battles", "blond", "plead", "races", "tanya", "salmon", "bizarre", "rico", "isabel", "wig", "reaches", "heights", "i-i-i", "possibilities", "wax", "travels", "confidential", "pursuit", "herd", "scissors", "cd", "spies", "exams", "invention", "explaining", "replacement", "bombing", "erik", "springs", "chelsea", "sabrina", "kicks", "integrity", "dash", "jae", "senate", "mentally", "flee", "gangster", "beautifully", "roberts", "slim", "choosing", "promising", "objective", "joyce", "altogether", "attract", "ernie", "melanie", "prep", "neighbours", "nailed", "briefcase", "buzzer", "quitting", "puppet", "restore", "dozens", "betting", "pancakes", "corridor", "embarrass", "visits", "database", "cheryl", "achieved", "sucking", "encourage", "grades", "gps", "barks", "patterns", "relevant", "mafia", "hudson", "expense", "intact", "occasionally", "kiddo", "heartbeat", "identical", "cigar", "billions", "alec", "gained", "venice", "classical", "noodles", "consistent", "clip", "resign", "insects", "failing", "organic", "seize", "charging", "mug", "iris", "crow", "ella", "fountain", "observation", "abortion", "railroad", "straighten", "legitimate", "sting", "youngest", "fork", "du", "flynn", "ciao", "coroner", "jonas", "marching", "touches", "jade", "feared", "griffin", "expedition", "forcing", "neighbour", "digital", "deeds", "milan", "bernie", "a-", "attic", "jr", "whores", "sentimental", "cooler", "eun", "bert", "feds", "reese", "plea", "polly", "metres", "harmony", "difficulty", "bands", "dried", "aunty", "maker", "randall", "supporting", "brake", "girlfriends", "features", "photography", "vengeance", "inappropriate", "vacuum", "throws", "kane", "residents", "endure", "substance", "corrupt", "potter", "investigator", "thread", "'it", "priests", "gap", "whining", "scarf", "institution", "immortal", "marsh", "chapel", "desperately", "accidents", "alcoholic", "fabric", "nazis", "railway", "sal", "dame", "rebels", "custom", "pension", "cans", "possess", "kira", "poster", "developing", "addict", "feature", "cope", "lords", "delightful", "wrestling", "c.", "rio", "reduce", "rescued", "peg", "mercedes", "guaranteed", "emotionally", "poland", "accountant", "theories", "me-", "tumor", "automatic", "amusing", "unnecessary", "higgins", "voting", "buster", "stadium", "visible", "easter", "jeep", "dj", "les", "garcia", "tracked", "ignorant", "pledge", "deserted", "esther", "rum", "fisher", "wheelchair", "salvation", "lester", "wonders", "clattering", "don`t", "maintenance", "tobacco", "underwater", "divide", "slightest", "discount", "yoga", "vagina", "rushing", "modest", "make-up", "wes", "reduced", "t.", "whisper", "pressing", "tops", "variety", "ignored", "helena", "writers", "grain", "essentially", "archie", "ofthe", "individuals", "meredith", "gavin", "subtle", "interviews", "pinky", "cord", "sites", "brennan", "maddie", "vienna", "issued", "lasted", "explosive", "origin", "unto", "rogue", "x-ray", "superintendent", "cody", "jacques", "ol", "challenges", "corruption", "sullivan", "shutter", "erase", "ski", "forensics", "flavor", "fastest", "joon", "vet", "civilians", "lobster", "housing", "canal", "robots", "shade", "ambitious", "orchestra", "succeeded", "guidance", "hence", "bella", "seoul", "jose", "inevitable", "tick", "rival", "refuses", "fiancé", "purchase", "wander", "ireland", "hanna", "hanged", "napoleon", "elite", "craft", "cult", "whisky", "profits", "shelf", "kai", "allowing", "chart", "accusing", "buzzes", "weekends", "humiliated", "fiancée", "hissing", "treats", "granddaughter", "serena", "submit", "supervisor", "sniffing", "resident", "tearing", "obliged", "opportunities", "knights", "hangs", "jerusalem", "stew", "counted", "instruments", "triumph", "nun", "frequency", "resume", "marines", "distract", "satisfaction", "historical", "creates", "costumes", "swedish", "lizzie", "depending", "sour", "spark", "freely", "scotty", "freaks", "d.a.", "shan", "globe", "peak", "sentenced", "fierce", "scam", "hollow", "anton", "hoo", "concentration", "presume", "invest", "eleanor", "radical", "protective", "smiles", "stunning", "frustrated", "suspenseful", "breed", "adore", "controlling", "reagan", "pasta", "precinct", "swallowed", "execute", "4th", "towels", "architect", "delta", "honks", "whoo-hoo", "preserve", "dose", "stove", "codes", "instantly", "bugger", "vivian", "yoon", "doo", "haul", "orphanage", "bolt", "autograph", "sharply", "habits", "villagers", "cracks", "dwight", "omar", "assembly", "meds", "marge", "magnetic", "romans", "joshua", "sorted", "assets", "insulted", "outstanding", "essence", "wardrobe", "ling", "nam", "benson", "restaurants", "disco", "flirting", "abilities", "dolly", "handful", "mice", "pumpkin", "bennett", "sweating", "anchor", "thankful", "interior", "moore", "urge", "surrounding", "strain", "curtains", "gypsy", "tomato", "blanche", "bonds", "compassion", "greece", "ceo", "arabic", "examination", "participate", "veins", "cups", "additional", "sofia", "obsession", "responsibilities", "ridge", "intent", "axe", "reckless", "missiles", "razor", "corners", "frightening", "rains", "mutant", "wally", "whereas", "heavenly", "promoted", "dang", "maiden", "comments", "batteries", "bark", "seas", "congressman", "canyon", "casual", "rack", "expectations", "flowing", "adjust", "decade", "pine", "tails", "baxter", "wires", "pigeon", "finance", "respectable", "demonstration", "prank", "appointed", "treason", "views", "violin", "stir", "lifestyle", "realm", "monty", "roosevelt", "missy", "fitting", "señor", "tuna", "tuck", "inspection", "nursing", "jared", "poop", "cardinal", "altar", "herman", "carlo", "tourist", "conviction", "jelly", "thrill", "lounge", "cha", "zip", "hogan", "dimension", "choke", "backing", "pains", "bodyguard", "rug", "jaw", "ants", "popcorn", "courtroom", "reynolds", "pointless", "documentary", "donor", "mortgage", "tunnels", "enforcement", "demanding", "cocks", "eliminated", "agh", "rapidly", "refer", "shipment", "tasted", "fails", "michel", "rushed", "ordering", "efficient", "outrageous", "gracious", "slaughter", "marijuana", "monroe", "pipes", "backed", "vest", "approached", "mechanic", "mumbai", "arizona", "legendary", "delayed", "resolve", "relation", "amelia", "mechanical", "fare", "karma", "jefferson", "chorus", "nana", "extend", "info", "saddle", "pretended", "equals", "motherfuckers", "artificial", "accomplish", "burial", "lynn", "detention", "vow", "bake", "breakdown", "dvd", "delhi", "selected", "lightly", "'em", "dealers", "e.", "layer", "gown", "courtney", "incoming", "reid", "countryside", "cheaper", "smelled", "devon", "ducks", "lethal", "swan", "attending", "moonlight", "ropes", "dispatch", "notebook", "punched", "identification", "contracts", "scattered", "trusting", "susie", "prayed", "volunteers", "remembering", "adopt", "calvin", "worms", "consideration", "bandits", "moses", "zombies", "lionel", "non", "transplant", "crackling", "loneliness", "frasier", "epic", "gladly", "marcel", "mon", "frost", "registration", "prophet", "launched", "constitution", "roland", "claude", "sock", "dragons", "buyer", "regulations", "mimi", "volcano", "accomplice", "bounty", "hotels", "favors", "opinions", "pressed", "asylum", "blunt", "duel", "niles", "consult", "nevertheless", "carnival", "au", "baba", "hah", "paths", "rides", "tray", "cynthia", "te", "handcuffs", "shannon", "barrier", "supposedly", "faggot", "hunch", "disposal", "yacht", "stain", "thoughtful", "healed", "thinkin", "syndrome", "hairy", "kansas", "happiest", "entertain", "y-you", "ambush", "recommended", "childish", "meter", "gilbert", "lease", "climbed", "nadia", "unstable", "exploded", "apollo", "rogers", "politician", "rs", "awaits", "abraham", "evelyn", "particles", "violation", "lined", "amazed", "lure", "lyrics", "pod", "fran", "universal", "d.c.", "hulk", "drunken", "hyah", "continuing", "goals", "warming", "dc", "chemicals", "owl", "xena", "compromised", "grounded", "cane", "avenge", "dexter", "phantom", "notion", "directors", "tease", "forensic", "doe", "outcome", "slam", "shattered", "cheque", "baked", "sought", "racket", "hammond", "rider", "exotic", "cory", "extent", "eighth", "stack", "wheat", "shipping", "satisfy", "kara", "departure", "finch", "blocking", "regiment", "kin", "klaus", "surf", "kilometers", "rises", "frighten", "abused", "gerald", "colours", "hath", "marvin", "texts", "spaghetti", "chester", "bosses", "elephants", "snarling", "contained", "laurie", "arab", "bumped", "chili", "yah", "sustained", "abducted", "panicked", "shallow", "diving", "artie", "harriet", "generator", "federation", "mulder", "arresting", "techniques", "feather", "printed", "untie", "jupiter", "hay", "stalking", "conrad", "phony", "brett", "whack", "scored", "continent", "articles", "oxford", "z", "organize", "sensors", "shanghai", "wh", "sniper", "noisy", "framed", "horizon", "twilight", "reflection", "masks", "godfather", "merchant", "wages", "robe", "waist", "stinking", "disappointment", "venture", "voyage", "curry", "ominous", "sunlight", "oui", "overseas", "casualties", "aaah", "mattress", "grill", "marketing", "accepting", "occupation", "deadline", "freed", "exhibit", "poems", "echoing", "shin", "compliments", "til", "define", "urine", "foreman", "facial", "p.a.", "combined", "brody", "probation", "reject", "catches", "dances", "gemma", "pinch", "ingredients", "ra", "hurricane", "chatting", "mini", "heel", "adding", "bandit", "destined", "limo", "spa", "graves", "turkish", "listed", "corpses", "matty", "evacuate", "publish", "judith", "banned", "snaps", "cheeks", "predict", "ohio", "holland", "confront", "utterly", "pals", "pilots", "umm", "jonah", "ironic", "improved", "popping", "mills", "farther", "delivering", "skipper", "flattered", "coconut", "acknowledge", "shuts", "sweden", "hooray", "sip", "blessings", "grocery", "terminal", "parks", "meaningless", "awards", "fade", "hiring", "burton", "fees", "wretched", "krishna", "thoroughly", "exhibition", "spends", "denver", "80s", "winners", "doris", "luther", "disappearance", "madrid", "supported", "advised", "regina", "supermarket", "hereby", "pier", "shorter", "betrayal", "philadelphia", "christians", "psychology", "danielle", "trent", "keeper", "detroit", "canadian", "su", "associates", "gerry", "restless", "collector", "marvellous", "physician", "exposure", "grudge", "lid", "followers", "glow", "submarine", "towns", "pawn", "edith", "includes", "lu", "proposition", "joker", "spilled", "opposition", "jang", "haley", "hose", "partnership", "usa", "timmy", "breathes", "whoops", "astronaut", "porch", "leonardo", "responding", "wishing", "boil", "kneel", "tammy", "clumsy", "rapid", "xiao", "stevens", "invested", "janice", "roller", "thai", "justify", "garlic", "yelled", "simone", "ammunition", "sushi", "shaft", "definition", "gardens", "chandler", "ne", "notify", "brady", "beasts", "setup", "greed", "dared", "unlucky", "classroom", "treaty", "hike", "dagger", "spine", "detect", "chow", "des", "teenagers", "handwriting", "mock", "challenging", "salon", "virtue", "lawsuit", "shelly", "clap", "mustache", "offence", "med", "sultan", "attraction", "franco", "courts", "fortress", "café", "peel", "petrol", "disappears", "asset", "warp", "workshop", "traps", "jeannie", "appreciated", "condemned", "garrett", "muttering", "shook", "naval", "egyptian", "expand", "sunrise", "swine", "jingle", "lordship", "peach", "filmed", "pakistan", "oughta", "selection", "squeaking", "condom", "sadie", "barbie", "alongside", "risking", "democratic", "nerd", "dancers", "crook", "mack", "grasp", "translate", "behaving", "humiliating", "quarrel", "lively", "fury", "policemen", "sensei", "elders", "battlefield", "sticky", "glen", "liu", "primitive", "reign", "eugene", "stash", "evolved", "shifts", "unlock", "devices", "peculiar", "talents", "anita", "foreigners", "snacks", "mint", "pissing", "fuse", "manuel", "towers", "freezer", "inheritance", "villages", "beckett", "jewel", "bollocks", "shells", "swept", "recognition", "shovel", "artistic", "qualities", "ferry", "darren", "misunderstood", "portal", "atomic", "javier", "ava", "claiming", "examined", "defensive", "kenneth", "kat", "sensation", "ahhh", "5th", "increasing", "fugitive", "urban", "visions", "bathing", "gregory", "delight", "iot", "genes", "boundaries", "caution", "ellis", "strangled", "thorough", "ike", "bites", "nude", "tidy", "patricia", "tate", "obligation", "ari", "clearance", "reserved", "nasa", "spock", "marion", "this-", "reflect", "jammed", "sleeve", "classy", "fag", "angelo", "bradley", "bananas", "ex-husband", "saints", "longest", "confirmation", "mushrooms", "cyrus", "toni", "p.", "finals", "millionaire", "adoption", "wired", "comet", "handing", "cheerful", "deb", "acceptable", "realistic", "waits", "sufficient", "cosmic", "nolan", "gabe", "intellectual", "'we", "vomit", "warmth", "magnum", "associated", "alas", "engineers", "offend", "overwhelming", "sherry", "inherited", "antoine", "whooping", "scars", "sheldon", "purposes", "robbing", "refrigerator", "instructor", "darrin", "moms", "overtime", "percy", "laurel", "females", "sacrifices", "representing", "drift", "ruthless", "'a", "po", "arguments", "crappy", "musicians", "sidney", "depressing", "lasts", "doom", "milo", "cant", "backpack", "aisle", "insulting", "edition", "losses", "sh", "preacher", "schmidt", "swinging", "managing", "sinking", "lacey", "casting", "trials", "demonstrate", "diseases", "beggar", "amounts", "traced", "raven", "activate", "slapped", "heroic", "roar", "queer", "uk", "matching", "trump", "resignation", "newton", "sincerely", "stacy", "saul", "madman", "jenkins", "poke", "spicy", "swap", "programs", "sheer", "spaceship", "schultz", "blink", "steer", "males", "injection", "know-", "ant", "reform", "mother-in-law", "properties", "virtually", "camps", "tapping", "tequila", "inquiry", "fainted", "formation", "shields", "escaping", "unemployed", "murdering", "interviewed", "striking", "vows", "donovan", "antique", "il", "sherlock", "puke", "hysterical", "taller", "employment", "thats", "agrees", "dodge", "unite", "mumbling", "rabbits", "repeating", "mule", "locals", "v.", "neighbourhood", "hayes", "bats", "beliefs", "spared", "vegetable", "ch00ffff", "liv", "bunker", "channels", "phenomenon", "hips", "grayson", "expelled", "camille", "languages", "iv", "premises", "pronounce", "ng", "bridges", "ape", "julius", "bruises", "convict", "prettier", "elections", "18th", "annoyed", "hometown", "earrings", "discreet", "poured", "morphine", "henderson", "jun", "narrating", "rookie", "peanuts", "camel", "abe", "chewing", "imagining", "runner", "hyun", "tomatoes", "sponsor", "fulfilled", "probe", "karate", "grease", "dinosaurs", "rebellion", "marta", "lone", "nan", "underestimate", "acres", "carlton", "hacked", "barber", "mining", "aged", "designs", "preferred", "19th", "onions", "stray", "void", "sixteen", "slower", "hannibal", "sabotage", "rabbi", "concerning", "dixon", "holt", "mannix", "noted", "peterson", "dental", "obama", "squirrel", "committing", "werewolf", "slipping", "mm-mm", "matthews", "explosions", "seo", "russ", "whitney", "ignoring", "infinite", "cavalry", "lam", "suzanne", "bomber", "ruling", "boiling", "needles", "semester", "irrelevant", "savior", "veil", "tramp", "roberto", "deepest", "perfection", "shutting", "iii", "tiffany", "mentor", "branches", "enthusiasm", "arena", "listens", "hardware", "greatly", "battalion", "moustache", "irresponsible", "audio", "ga", "initiative", "sweaty", "noel", "requests", "distraction", "parrot", "steed", "entertaining", "whipped", "proving", "assaulted", "piggy", "pause", "surviving", "funding", "dinosaur", "acquaintance", "bedtime", "rail", "rooster", "cowards", "hastings", "container", "lori", "secured", "tossed", "stripper", "s.", "steele", "waving", "clamoring", "banker", "bacteria", "indicates", "assassination", "yeah.", "starring", "drawings", "cupboard", "sanctuary", "surgical", "pairs", "purely", "temptation", "elderly", "geoffrey", "vibe", "profound", "gong", "transformed", "crop", "21st", "detailed", "scrap", "abigail", "careless", "dove", "sloppy", "atlanta", "hideous", "10th", "lizard", "separation", "intern", "tab", "psych", "ranks", "parish", "booty", "peasant", "squeal", "oooh", "comb", "bash", "restored", "platoon", "junkie", "involves", "rupert", "norm", "carrier", "fatty", "difficulties", "producers", "superb", "tha", "candidates", "summoned", "15th", "refuge", "righteous", "carolina", "onion", "natasha", "pickup", "spells", "wesley", "carrington", "armies", "seasons", "senor", "billie", "specialty", "thirst", "select", "rendezvous", "smiled", "colorado", "visa", "spice", "caller", "foods", "rational", "scottish", "cunning", "grunt", "knot", "hairs", "payments", "granddad", "massacre", "competitive", "herb", "mae", "immune", "grenade", "regularly", "stakes", "kilos", "monks", "70s", "gail", "guinea", "invent", "nursery", "protein", "elbow", "keller", "clowns", "thirteen", "tattoos", "flown", "mustard", "7th", "terrace", "alter", "franz", "transportation", "what-", "lens", "alaska", "ha-ha-ha", "interference", "freakin", "wont", "weep", "clive", "mourning", "crooked", "trainer", "janitor", "gradually", "immigration", "filth", "momma", "father-in-law", "jackass", "cho", "reminder", "culprit", "gabrielle", "innit", "magistrate", "jasmine", "'m-", "womb", "texting", "injustice", "figuring", "fracture", "insanity", "peasants", "blossom", "etc", "agony", "sounding", "oz", "elementary", "seized", "teaches", "lovejoy", "phillips", "eighteen", "shack", "teen", "definite", "scrub", "ruler", "mold", "contents", "bitten", "antidote", "was-", "saves", "bunk", "thor", "republican", "graveyard", "attempts", "poirot", "aspect", "relate", "lemonade", "flour", "nypd", "biology", "dusty", "felony", "jax", "fundamental", "jai", "successfully", "potentially", "donnie", "strangely", "condoms", "quantum", "utter", "activated", "installed", "interrupted", "'er", "discharge", "devastated", "substitute", "splash", "julio", "exile", "aspirin", "authentic", "12th", "summit", "beck", "addiction", "lent", "drone", "involving", "boyfriends", "tango", "permanently", "province", "attempting", "deceived", "'know", "triangle", "skipped", "strawberry", "mirrors", "self-defense", "preston", "overwhelmed", "swift", "creeps", "token", "temporarily", "poisonous", "heidi", "diagnosis", "ninth", "locations", "retrieve", "robbers", "conclusions", "joanna", "disabled", "ira", "extension", "lining", "yuri", "hip-hop", "freeman", "scoop", "merlin", "bridget", "revving", "transform", "shelby", "hospitality", "brooks", "survey", "hunted", "cozy", "g.", "recommendation", "providing", "microphone", "skeleton", "muslims", "toll", "reconsider", "creaks", "extended", "spear", "overboard", "ai", "clinton", "petition", "baggage", "scumbag", "tribute", "weddings", "facilities", "bangs", "claw", "donation", "isabelle", "traitors", "mei", "jasper", "borders", "australian", "colby", "boxer", "whilst", "misfortune", "elaborate", "sights", "maestro", "mysteries", "loosen", "gifted", "i--i", "involvement", "affects", "summon", "sherman", "churchill", "theresa", "solitary", "wilderness", "baltimore", "olympic", "undo", "mechanism", "vietnamese", "vanish", "dome", "biting", "ronald", "texted", "sage", "yummy", "tactics", "slack", "snapped", "weekly", "bushes", "grandparents", "like-", "henri", "obtain", "hart", "flights", "adventures", "hottest", "grown-up", "eden", "mild", "dom", "fourteen", "smuggling", "blend", "chancellor", "biscuits", "gorilla", "dynasty", "acquired", "businesses", "countless", "fritz", "brent", "gardener", "barracks", "flirt", "cooks", "distorted", "carved", "jumps", "superhero", "forests", "clapping", "psychiatric", "snuck", "roughly", "screamed", "raja", "disappearing", "establishment", "whales", "lump", "dwarf", "environmental", "mam", "pint", "loading", "diplomatic", "exclaims", "context", "volunteered", "risked", "gangs", "boost", "fax", "dante", "partial", "refusing", "gaze", "rene", "nuisance", "terrorism", "jerome", "ungrateful", "donate", "relieve", "13th", "grandchildren", "felicity", "maureen", "represented", "co", "neutral", "philippe", "workin", "steering", "rm", "presidential", "rental", "challenged", "julien", "feeds", "je", "vegetarian", "teasing", "surprisingly", "iran", "shrine", "automatically", "timer", "gasoline", "juliette", "scouts", "millie", "google", "dorm", "athlete", "shiva", "robber", "convent", "balloons", "crawford", "barb", "enters", "maps", "meth", "ifyou", "fruits", "colored", "poppy", "metro", "clarke", "fernando", "scully", "resolved", "sessions", "conservative", "rates", "forged", "legends", "arrows", "charley", "dismiss", "authorized", "slavery", "attended", "flows", "employed", "decorated", "parallel", "detected", "grove", "coverage", "hen", "pyramid", "overall", "hum", "specially", "rebuild", "exclaiming", "producing", "sewing", "occasions", "boards", "trumpet", "yes.", "shaped", "matched", "daughter-in-law", "ammo", "typing", "macgyver", "blades", "thailand", "becca", "wo", "debris", "luca", "cement", "hamlet", "nat", "communists", "showers", "tougher", "sailors", "kitt", "comedian", "harassment", "missus", "monitoring", "smashing", "shaved", "inventory", "housekeeper", "tribes", "long-term", "vile", "gotham", "imaginary", "artillery", "ping", "cereal", "zoom", "portion", "irony", "14th", "exceptional", "slit", "ss", "despise", "waltz", "humour", "crashes", "gu", "stammering", "coaches", "joo", "await", "bryan", "celebrated", "encouraged", "devils", "gag", "telescope", "verse", "stalin", "e-mails", "iet", "babysitter", "pr", "distinguished", "licence", "addicted", "bauer", "speeches", "wit", "programmed", "bliss", "donny", "elsa", "com", "recorder", "hides", "shameless", "apartments", "tipped", "turf", "tang", "tu", "discharged", "psychologist", "duh", "delete", "jock", "wrath", "estimate", "tutor", "jurisdiction", "impulse", "penguin", "tubes", "playground", "sew", "nickel", "claws", "giants", "daring", "posters", "peacefully", "rag", "caves", "nikita", "stern", "condolences", "ohhh", "dearly", "humiliation", "worldwide", "cartoon", "disrespect", "so-", "shhh", "underworld", "marble", "lilly", "chun", "curly", "judged", "bidding", "erased", "confuse", "masterpiece", "pentagon", "oppa", "tow", "seduce", "bathtub", "pets", "bricks", "goa", "hotter", "regime", "contempt", "batch", "'m-i", "ramsay", "speeding", "compartment", "tackle", "wage", "shines", "lifting", "hustle", "inmates", "km", "psst", "scooter", "relatively", "stoned", "supernatural", "darwin", "viewers", "lorenzo", "treasures", "yankee", "lang", "taco", "charts", "brigade", "bankrupt", "marianne", "bikes", "lookout", "merchandise", "slippery", "duchess", "gulf", "foam", "steals", "numerous", "ripping", "trusts", "flock", "potion", "fiance", "glimpse", "invincible", "compensation", "kettle", "stroll", "trish", "brendan", "cafeteria", "sane", "currency", "amsterdam", "radius", "verify", "founded", "medic", "peek", "sewer", "vernon", "callie", "bbc", "hull", "solomon", "madonna", "toad", "powell", "maxwell", "moose", "souvenir", "stitch", "compass", "mercury", "locking", "edwards", "frederick", "dislike", "stu", "rib", "pamela", "brace", "ban", "gracias", "stitches", "thrust", "referred", "achievement", "links", "denying", "monastery", "newly", "impatient", "recruit", "sunk", "ignorance", "drugged", "predicted", "floyd", "creator", "mississippi", "civilized", "artery", "dynamic", "competing", "buffy", "distribution", "turk", "voiceover", "stereo", "ethel", "ark", "carpenter", "it.", "warner", "industries", "melted", "upsetting", "cruz", "labs", "bluff", "bender", "unbearable", "narcotics", "juicy", "eerie", "ingrid", "mwah", "slippers", "freaky", "vip", "troop", "footprints", "dani", "pact", "apparent", "repeated", "foreigner", "feelin", "journalists", "employer", "penelope", "grim", "medieval", "damien", "frustrating", "rehearse", "travelled", "preparation", "microwave", "denial", "flute", "juvenile", "paddy", "retarded", "memo", "canvas", "fa", "and-and", "symbols", "mccoy", "daly", "driveway", "funky", "kitten", "nicest", "deceive", "negro", "chopped", "consultant", "rifles", "heating", "rays", "architecture", "gideon", "butch", "warmer", "contribution", "advisor", "peoples", "groceries", "behaved", "experiencing", "yοu", "settling", "tractor", "unacceptable", "imitating", "squadron", "briggs", "smallest", "ethics", "gibson", "devotion", "plumber", "burgers", "knots", "broom", "briefing", "curve", "informant", "applauding", "whites", "app", "andrews", "blog", "ox", "vase", "glance", "collective", "poles", "sixty", "fantasies", "heritage", "motherfucking", "fisherman", "armstrong", "nder", "complained", "nightclub", "willow", "preliminary", "server", "provides", "mat", "appreciation", "a-a", "historic", "jorge", "promote", "processing", "naples", "high-pitched", "pumping", "stalker", "goats", "francine", "smokes", "introduction", "valid", "portuguese", "negotiations", "o.r.", "wheeler", "overheard", "iove", "breeding", "part-time", "barge", "refugees", "wah", "observed", "tigers", "brothel", "missions", "ashore", "panda", "discretion", "yale", "disappointing", "insect", "prophecy", "wanda", "absent", "machinery", "generals", "carrot", "ferrari", "wrecked", "gestapo", "greene", "suggestions", "puff", "supportive", "punching", "lulu", "intervention", "layers", "hughes", "scholar", "libby", "predators", "accusations", "8th", "olympics", "accounting", "jj", "expertise", "strap", "fitz", "darryl", "butts", "approaches", "flags", "embarrassment", "faking", "jamal", "vanilla", "grapes", "dominic", "beacon", "handkerchief", "rubbing", "mallory", "rustling", "lighten", "flora", "cuban", "polar", "translator", "congrats", "passports", "grabbing", "alf", "brotherhood", "ernest", "professionals", "yuan", "understandable", "banner", "academic", "thuds", "sa", "publicly", "orphans", "pearls", "predator", "'brien", "frances", "addison", "syrup", "cartel", "nash", "walsh", "norma", "bluffing", "permitted", "unpredictable", "wagner", "suspension", "addresses", "stamps", "category", "transition", "peas", "cautious", "k.", "isabella", "comparison", "coats", "islam", "thugs", "grams", "freshman", "toilets", "banquet", "coup", "shaken", "investigations", "toothbrush", "expressed", "vulgar", "haunt", "improvement", "zeus", "murdoch", "smelling", "kirby", "repairs", "jeong", "conducted", "ollie", "bakery", "busting", "investigated", "60s", "admission", "essay", "twitter", "depths", "fewer", "guarding", "altered", "filing", "ecstasy", "snatch", "stored", "tropical", "pharmacy", "dalton", "altitude", "admired", "dickhead", "priya", "mamma", "moe", "grind", "bombay", "'he", "lowest", "makin", "sentences", "mute", "full-time", "scratching", "imprisoned", "danish", "glowing", "zhang", "martini", "leah", "empress", "equipped", "finale", "tarzan", "storms", "sniff", "oh.", "me.", "slick", "unarmed", "16th", "violated", "vent", "dd", "breakthrough", "stud", "addressed", "tactical", "vessels", "procedures", "ching", "dine", "draws", "crowds", "limb", "wool", "montana", "giovanni", "jerks", "numb", "oceans", "priceless", "rocking", "commanding", "relaxing", "clatters", "merci", "gerard", "packs", "parlor", "cabbage", "josé", "intruder", "considerable", "argued", "paladin", "tellin", "pupils", "inspire", "positively", "igor", "traded", "shipped", "feminine", "vague", "partly", "6th", "insight", "lucia", "stages", "um-", "screenplay", "marquis", "rahul", "ripe", "awaiting", "pigeons", "clayton", "tempted", "inherit", "decline", "pennsylvania", "fang", "shitting", "tens", "gigantic", "guv", "readings", "headmaster", "tenth", "seals", "peyton", "avoided", "blankets", "overlapping", "flipped", "yield", "ads", "backstage", "quiz", "mosque", "weaver", "puppies", "stated", "vicki", "weirdo", "belongings", "functions", "reservations", "chilly", "betsy", "eldest", "traditions", "factories", "feedback", "repeatedly", "exquisite", "pickle", "masses", "pauline", "frogs", "crosses", "headaches", "arctic", "reinforcements", "secondary", "pajamas", "roles", "asteroid", "unsub", "mixing", "courier", "jeanne", "carrots", "fuckers", "translated", "longing", "cigars", "manipulate", "liberal", "investors", "bun", "sly", "pickles", "temperatures", "sweetest", "motto", "moss", "yum", "melting", "yan", "requesting", "lava", "you.", "kris", "monthly", "noses", "tickle", "ufo", "timothy", "stacey", "j.r.", "midst", "herbert", "purchased", "tis", "convenience", "flashlight", "dewey", "tripped", "easiest", "shouted", "splitting", "bryce", "commands", "demanded", "cuff", "cosmos", "curfew", "instructed", "notorious", "prague", "q", "streak", "equivalent", "pitiful", "fin", "greeting", "propaganda", "doorstep", "hilda", "butterflies", "fascinated", "jude", "beatrice", "miriam", "dumping", "karan", "condo", "fearless", "cripple", "errand", "'in", "halls", "imitates", "harley", "ravi", "gretchen", "sailed", "nico", "baking", "connecting", "bourbon", "cathedral", "malone", "bong", "tying", "lists", "strangle", "stripped", "loans", "manchester", "briefly", "tessa", "unfinished", "experimental", "greeks", "lil", "mainland", "w-what", "judgement", "stammers", "pike", "liars", "slot", "17th", "amazon", "flooded", "torment", "mermaid", "rapist", "sanders", "triggered", "expects", "lisbon", "reader", "keyboard", "roam", "seventeen", "openly", "deacon", "olga", "jackpot", "soaked", "printing", "yuck", "shorty", "extract", "nköö", "you-you", "prostitutes", "cherish", "logs", "takin", "sponge", "bates", "cuffs", "virginity", "torturing", "unity", "coop", "forge", "morse", "guru", "tai", "skilled", "dev", "insists", "calf", "oof", "allowance", "homosexual", "vijay", "shapes", "rosemary", "idle", "slaughtered", "resent", "cassandra", "leaking", "likewise", "riddle", "ghetto", "sunglasses", "vega", "newest", "valve", "geek", "fucks", "gangsters", "pies", "publisher", "troubling", "trembling", "marathon", "douche", "conducting", "sundays", "shrieks", "fiancee", "frankenstein", "summers", "wei", "liang", "burglar", "spiders", "norway", "crops", "infant", "falcon", "pursuing", "humiliate", "hydrogen", "karaoke", "encountered", "alberto", "corey", "scope", "cultures", "speakers", "superstar", "orgasm", "byron", "gravy", "calculations", "vocal", "severely", "hating", "novels", "mindy", "boiled", "metaphor", "kindergarten", "fades", "anders", "fi", "brazilian", "devastating", "bea", "interfering", "dripping", "ops", "cuz", "holden", "suited", "merciful", "hayley", "affirmative", "runaway", "shoo", "italians", "wales", "santiago", "adapt", "renee", "mal", "smartest", "blacks", "struggled", "prostitution", "payback", "buenos", "vintage", "diapers", "killings", "courthouse", "tong", "cubs", "surfing", "indiana", "spotlight", "frontier", "monte", "stocks", "patterson", "holiness", "denmark", "isolation", "starters", "resigned", "acquainted", "meow", "appearances", "loft", "snitch", "ribbon", "dares", "greatness", "fallon", "coolest", "decency", "mayday", "michigan", "reactor", "buckle", "vanity", "simmons", "earning", "marriages", "docks", "lopez", "alleged", "asap", "preparations", "bugging", "conquered", "cuckoo", "crib", "yogurt", "secondly", "nixon", "portland", "fishy", "flick", "scratched", "muffin", "hale", "tailor", "chimney", "nuns", "ezra", "packet", "homemade", "farming", "genuinely", "rumours", "daniels", "blouse", "kite", "buses", "hassan", "rhyme", "invaded", "quentin", "equation", "transmitter", "morons", "lime", "rotting", "20s", "remorse", "otis", "marker", "aiming", "adds", "chores", "gem", "blasted", "grabs", "courageous", "determination", "beaver", "publishing", "crickets", "well-known", "11th", "exercises", "testament", "apocalypse", "phew", "dicks", "paralyzed", "headlines", "stripes", "santos", "breaths", "abort", "heap", "ketchup", "responded", "edmund", "gracie", "protects", "tummy", "hog", "yakuza", "weeping", "fragments", "catastrophe", "bp", "churches", "pins", "shaving", "not-", "legit", "yoo", "targeted", "simpler", "noticing", "rover", "lars", "moreover", "releasing", "fascist", "greta", "spitting", "colt", "tristan", "hardy", "truce", "plaza", "bronze", "guarded", "airline", "ramon", "incapable", "punches", "sanchez", "hq", "privately", "vatican", "surround", "barrett", "edna", "alvin", "consolation", "gutter", "lan", "astonishing", "broker", "seizure", "fright", "runnin", "leaning", "mic", "scarlett", "berry", "paulie", "lacking", "verge", "lucifer", "contribute", "jewellery", "richards", "erotic", "feng", "siblings", "est", "dre", "cass", "disk", "op", "comics", "obstacle", "ale", "coral", "hamburger", "biscuit", "redemption", "thug", "concussion", "martinez", "disgust", "wright", "nsa", "arise", "celebrities", "kev", "dolphins", "kidneys", "leaked", "solving", "plasma", "singapore", "scram", "regain", "conductor", "ministers", "gender", "removing", "cocky", "know.", "richest", "deciding", "poo", "dispute", "brute", "incidents", "telly", "capsule", "chefs", "psychopath", "dumpster", "lire", "jarod", "bind", "chops", "crust", "poorly", "weighs", "bundle", "vibrating", "ricardo", "encouraging", "dwayne", "polo", "singers", "ada", "meteor", "firmly", "prettiest", "hormones", "starboard", "chauffeur", "download", "'neill", "garrison", "recovering", "heated", "hillary", "cctv", "postcard", "darlin", "convert", "celia", "abi", "sissy", "reef", "'tis", "treasury", "calmly", "mathematics", "ar", "ups", "shameful", "abbey", "strategic", "wrists", "payroll", "beethoven", "immense", "heartless", "magnus", "banged", "montgomery", "protector", "michelangelo", "teller", "raging", "applying", "mop", "sol", "atom", "paolo", "'this", "unload", "detector", "switching", "handles", "favorites", "stinky", "lina", "norton", "regional", "heil", "richer", "secrecy", "thighs", "rigged", "thesis", "zeke", "consumed", "ahold", "tuned", "atlantis", "repaired", "leverage", "winnie", "weary", "costa", "rue", "cowboys", "employ", "provoke", "stool", "postpone", "extensive", "beau", "urgently", "optimistic", "lotus", "apologizing", "spooky", "skate", "maze", "arrests", "dialing", "fireplace", "gt", "vicar", "beetle", "horace", "suspicions", "stupidity", "restricted", "skating", "pupil", "homo", "thumbs", "hostess", "cheng", "sneaky", "swollen", "por", "unlocked", "eliza", "gladys", "mixture", "porsche", "diagnosed", "vaughn", "ri", "liberation", "nay", "crows", "rockets", "starfleet", "reindeer", "'that", "shampoo", "milton", "mai", "skiing", "overhead", "disturbance", "cohen", "spits", "crank", "crocodile", "bulls", "medals", "sierra", "motivation", "dangers", "exploring", "mist", "galaxies", "ju", "sculpture", "marjorie", "adrenaline", "malik", "lt.", "allied", "manor", "convoy", "carly", "elliott", "merit", "cutter", "stressful", "forming", "bikini", "sway", "virgil", "soy", "nell", "salty", "elf", "belts", "yvonne", "disney", "contractor", "rodeo", "crackers", "playboy", "arch", "operated", "crews", "scanner", "dads", "limbs", "bathe", "cardiac", "persuaded", "argentina", "velvet", "hyde", "stem", "rewarded", "taiwan", "warfare", "lakhs", "filter", "pumped", "sterling", "gran", "right.", "fills", "chet", "disc", "percentage", "bravery", "edges", "diaper", "lyle", "ida", "preserved", "sutton", "katrina", "champions", "partying", "sergei", "pd", "morality", "crate", "mina", "complications", "sausages", "smoothly", "rafael", "cradle", "leopard", "chu", "gardner", "athens", "wh-what", "abu", "kramer", "magnet", "psychotic", "vaccine", "motivated", "aggression", "courses", "it`s", "willis", "expanding", "vance", "bases", "burglary", "stumbled", "buns", "confronted", "geneva", "increasingly", "sidewalk", "shady", "defended", "resolution", "chooses", "tapped", "exploding", "punks", "scenery", "hitch", "severed", "wink", "initially", "assessment", "shredder", "villains", "miners", "introducing", "focusing", "rainy", "amendment", "getaway", "recognised", "blackout", "leash", "muhammad", "eyebrows", "livin", "bouncing", "nipples", "'oh", "raft", "pharaoh", "pots", "refreshing", "wandered", "roz", "abel", "beatles", "confined", "contagious", "madeline", "beijing", "frequently", "operational", "shakes", "thanking", "suffers", "basil", "babylon", "'to", "drilling", "agencies", "buffet", "farms", "motives", "cocoa", "perception", "targeting", "thudding", "blares", "dense", "pinned", "pending", "nod", "crunch", "stains", "nervously", "caribbean", "bouquet", "stabbing", "screws", "boone", "philosopher", "bulb", "sinner", "ongoing", "editing", "veteran", "drip", "r.", "mara", "inspiring", "gale", "flint", "nova", "nevada", "manning", "membership", "puerto", "raphael", "chalk", "liable", "manuscript", "h.", "organised", "clanging", "markets", "rama", "austria", "chocolates", "l.", "trafficking", "philly", "unaware", "loot", "perish", "processed", "clone", "whooshing", "hangover", "flatter", "wretch", "weasel", "columbia", "israeli", "shatters", "lace", "indication", "allan", "cora", "drifting", "grady", "undress", "dolphin", "faked", "depart", "monument", "tyres", "marissa", "lorraine", "pow", "invade", "scooby", "hazel", "rep", "'est", "heavier", "tart", "mocking", "forgets", "sinister", "christy", "dex", "judas", "assemble", "shortcut", "transformation", "posts", "generosity", "amusement", "beta", "counseling", "bobo", "honors", "snatched", "phyllis", "measured", "gamma", "squeals", "evidently", "mildred", "caitlin", "dubai", "lantern", "combine", "nero", "trey", "toughest", "limp", "implying", "matrix", "dots", "kilometres", "evacuation", "earliest", "incompetent", "closure", "descent", "parachute", "analyze", "crushing", "classmates", "excessive", "tighter", "hump", "fuzzy", "tad", "punishing", "pageant", "wan", "reveals", "wildlife", "clare", "poking", "rehearsing", "homecoming", "swelling", "shrieking", "squawking", "tardis", "caine", "statues", "practiced", "christianity", "hazard", "stretched", "dea", "trudy", "slug", "frustration", "edie", "deception", "lillian", "trespassing", "elimination", "comforting", "len", "preach", "practise", "damages", "ex-boyfriend", "exits", "yer", "appointments", "significance", "drummer", "specimen", "voodoo", "cleo", "misunderstand", "asthma", "errands", "hypocrite", "snorts", "advocate", "cutie", "obtained", "cristina", "radioactive", "richmond", "ideals", "apprentice", "unreasonable", "inmate", "siege", "cobra", "increases", "harbour", "90s", "illegally", "rattle", "trim", "noodle", "antibiotics", "mattered", "declaration", "virtual", "intuition", "revs", "darcy", "scales", "testified", "gigi", "twenty-five", "bypass", "pneumonia", "manly", "medicines", "slowing", "groan", "dungeon", "chaps", "ncis", "consequence", "intercept", "badass", "examples", "fists", "klink", "substantial", "brag", "pitcher", "onboard", "amigo", "courtyard", "royalty", "spontaneous", "ca", "restroom", "peep", "negotiating", "ache", "swat", "emerge", "gambler", "references", "bonjour", "darkest", "insecure", "attendant", "sympathetic", "lila", "heroine", "choked", "unidentified", "plumbing", "darker", "ariel", "crude", "dictionary", "sparks", "auditions", "demo", "ta-da", "oppose", "fingernails", "mineral", "collateral", "istanbul", "venom", "tempting", "relay", "bamboo", "particle", "ying", "torres", "broadcasting", "banking", "reminding", "cassidy", "axl", "ferguson", "estimated", "hebrew", "electronics", "octopus", "meaningful", "stranded", "daytime", "dowry", "starved", "ex-girlfriend", "collision", "admitting", "comeback", "hungarian", "faculty", "operative", "liza", "tenants", "revealing", "ko", "ounce", "mediterranean", "gadget", "paramedics", "console", "cyril", "drawers", "caravan", "spinal", "bummer", "crippled", "bled", "defy", "luna", "herbs", "hwang", "queue", "blinded", "studios", "9th", "goddammit", "recess", "countdown", "maddy", "dracula", "alarms", "gaining", "quarterback", "maxine", "eminence", "willingly", "investigators", "speculation", "tο", "clearer", "gino", "cheeky", "powerless", "lapd", "cruelty", "external", "arjun", "quarantine", "shush", "allegations", "tito", "sands", "spelling", "che", "headline", "taliban", "tablet", "founder", "gandhi", "squash", "josie", "jets", "saloon", "tuition", "tame", "occasional", "apologized", "clinical", "serpent", "criticism", "sawyer", "fading", "viktor", "prop", "shoved", "mend", "lonesome", "separately", "reg", "evie", "waitin", "'n", "legion", "tsk", "arabs", "accompanied", "tread", "findings", "toronto", "exploit", "proposing", "shi", "scorpion", "of-", "zoey", "curb", "opium", "athletic", "bombed", "jumper", "weaker", "suing", "bianca", "seminar", "confirms", "commence", "plains", "debra", "readers", "neglected", "tavern", "worthwhile", "morale", "cleaners", "caviar", "welcoming", "kimberly", "evaluation", "f.", "occurs", "rituals", "morton", "disguised", "precision", "cube", "revelation", "titanic", "realizing", "doggy", "babbling", "cheung", "dora", "tenant", "riches", "diabetes", "alternate", "diversion", "effectively", "dedication", "wager", "companions", "sinclair", "bailed", "smelly", "ratings", "trench", "cameraman", "dillon", "hawkins", "stanton", "ajay", "edison", "batter", "dye", "abduction", "prospect", "morrison", "brighter", "wider", "alma", "manslaughter", "remedy", "damp", "thigh", "cologne", "accusation", "outsider", "serum", "whats", "spaces", "oral", "shades", "woe", "elise", "receipts", "alias", "notified", "apron", "kentucky", "vein", "tonic", "squeaks", "dim", "steep", "sod", "presenting", "cinderella", "cub", "chung", "eyewitness", "flattering", "overdose", "kathleen", "doubled", "della", "suckers", "automobile", "cain", "loo", "brittany", "bullied", "spider-man", "humphrey", "tyson", "kidnapper", "dispose", "margarita", "hash", "grieving", "initials", "hound", "boogie", "dawg", "perp", "cloak", "crabs", "pastry", "successor", "hola", "michele", "cheerleader", "slips", "critics", "recruited", "macho", "stunned", "fuller", "mornings", "accidental", "lara", "convey", "prototype", "superiors", "barcelona", "fling", "froze", "atoms", "kidnappers", "cupcake", "athletes", "warsaw", "pleasures", "ax", "kumar", "uptight", "inclined", "stockings", "scrooge", "fingerprint", "harmed", "sensational", "jockey", "mourn", "intercom", "tory", "penthouse", "forthe", "eileen", "ginny", "quack", "peck", "gospel", "'what", "presumably", "signatures", "hyung", "aspects", "assumption", "rumbles", "hugging", "sideways", "theodore", "organisation", "lowered", "youtube", "ct", "jaws", "troll", "squid", "designers", "mushroom", "freeway", "believer", "possessions", "tunes", "tornado", "cowardly", "notch", "routes", "winters", "elijah", "annoy", "loaf", "commercials", "idiotic", "inconvenience", "plum", "solicitor", "amnesia", "deborah", "distinct", "sweeping", "arson", "doubted", "furthermore", "quarry", "50s", "puss", "farts", "guo", "depot", "evenings", "ole", "circulation", "socialist", "melinda", "dryer", "mutters", "vomiting", "brock", "fei", "candis", "moody", "donated", "reich", "receiver", "semen", "converted", "rags", "harness", "slate", "padre", "sonya", "necessity", "emails", "rumpole", "orderly", "dinners", "assassins", "scold", "certainty", "marian", "knox", "upright", "trek", "patron", "reborn", "reel", "typewriter", "babes", "sorrows", "utmost", "havin", "patsy", "governments", "bhai", "privileges", "throats", "remotely", "glee", "revolver", "lockdown", "woof", "brunch", "dwell", "coyote", "squat", "manic", "groove", "bangkok", "uncovered", "mailbox", "objections", "lynch", "scrape", "commandant", "swings", "conventional", "stockholm", "raises", "transaction", "iced", "oy", "paulo", "ignition", "beaches", "interpol", "epidemic", "honoured", "shaggy", "friggin", "policies", "statistics", "shattering", "bah", "intercourse", "charms", "flashing", "destructive", "grilled", "oregon", "copied", "hookers", "paycheck", "solitude", "panther", "performances", "maids", "exhausting", "lambert", "omega", "belgium", "stationed", "yankees", "liability", "x-rays", "whichever", "hunk", "trout", "crystals", "learns", "repent", "prosperity", "literary", "assembled", "ounces", "martyr", "northwest", "connecticut", "privileged", "webster", "excess", "unemployment", "viking", "blackmailing", "munich", "install", "arrogance", "jeopardy", "hacker", "tongues", "pleases", "reset", "risen", "dependent", "sued", "perkins", "goons", "macleod", "milady", "wolfe", "abnormal", "bandage", "heed", "mabel", "pronounced", "bullying", "charter", "shelley", "turks", "litter", "standby", "izzy", "ltd", "peaches", "angles", "kerry", "here-", "baths", "generate", "cobb", "residue", "composed", "paco", "kilo", "immigrants", "probable", "x.", "enjoys", "seeks", "newman", "vicinity", "flank", "der", "clint", "functioning", "horatio", "predictable", "jedi", "scrambled", "expansion", "pittsburgh", "angus", "natives", "bing", "scarlet", "itchy", "stirring", "bedrooms", "structures", "penn", "ensign", "barrels", "voters", "madeleine", "geoff", "haste", "existing", "mcdonald", "commotion", "belonging", "extinct", "joints", "bumper", "you`re", "mao", "mare", "coleman", "influenced", "heist", "cynical", "input", "recite", "cary", "eagles", "expired", "palms", "slash", "bottoms", "o.", "columbus", "georges", "vous", "exaggerate", "l-", "guided", "pineapple", "spence", "ankles", "morals", "builds", "colleen", "posing", "fireman", "thorn", "communities", "lawson", "workout", "extraterrestrial", "raylan", "conceived", "tightly", "orlando", "tennessee", "yeon", "diaz", "fraser", "sleeves", "vacant", "infantry", "gallagher", "booking", "oranges", "rhodes", "breakup", "layla", "purity", "honourable", "militia", "j.d.", "mechanics", "mackenzie", "bronx", "realizes", "hasty", "colorful", "ramp", "boulevard", "xavier", "intriguing", "rook", "papi", "callen", "atm", "acquire", "necks", "sinners", "gents", "episodes", "oswald", "dedicate", "rests", "pi", "okay.", "milord", "debut", "interviewing", "occupy", "aimed", "emerged", "sloan", "restraining", "cod", "clarity", "daft", "islamic", "calculated", "lakes", "grumpy", "ki", "picasso", "eddy", "consulting", "obstacles", "pesos", "nicolas", "plotting", "infirmary", "sermon", "manipulated", "scratches", "aidan", "deeks", "critic", "greasy", "seung", "zealand", "supports", "anatomy", "agreeing", "straightforward", "prejudice", "placing", "flare", "milky", "masterchef", "vladimir", "premiere", "glamorous", "cinnamon", "syd", "referee", "threshold", "civilisation", "sensor", "tends", "louisa", "savages", "emil", "torpedo", "ere", "housewife", "tours", "fossil", "replied", "abdomen", "soak", "contestants", "stretching", "princes", "hoffman", "truman", "bumps", "educational", "outfits", "resurrection", "latte", "huang", "politically", "pratt", "whoosh", "françois", "ds", "wiser", "rejection", "clutch", "fusion", "j.j.", "gloomy", "madly", "cambridge", "cocktails", "lighthouse", "treatments", "chronic", "fluids", "deleted", "sustain", "stanford", "ahmed", "couid", "buyers", "valet", "darius", "nobel", "sank", "southeast", "condemn", "resemblance", "suicidal", "wed", "packages", "taped", "avatar", "wireless", "paddle", "lice", "tablets", "spreads", "itch", "gibberish", "ingredient", "emilio", "prevented", "withdrawal", "porno", "pry", "sexuality", "br", "vinnie", "oh-oh", "considerate", "sovereign", "pas", "voicemail", "é", "cadet", "clarify", "immature", "t-shirts", "marguerite", "banished", "chemo", "nicki", "dairy", "attach", "murdock", "sliding", "spectacle", "pushes", "yin", "delusional", "allegiance", "slope", "pooja", "awareness", "jed", "decker", "dino", "roaming", "shores", "l`m", "competitors", "tomas", "overreacting", "observing", "paste", "wits", "fiery", "typically", "eclipse", "produces", "oysters", "scraping", "pros", "impose", "revenue", "alabama", "departed", "user", "cracker", "hu", "undoubtedly", "arnie", "mozart", "dent", "charmed", "spiral", "scans", "hmmm", "ka", "louisiana", "rumour", "kirsten", "touchdown", "nadine", "posh", "correction", "mornin", "chubby", "manifest", "safest", "steroids", "fleeing", "genie", "dakota", "witchcraft", "sí", "archives", "trance", "symphony", "traumatic", "rocco", "skipping", "frequent", "modeling", "sporting", "affecting", "spacecraft", "negotiation", "talbot", "reno", "benton", "calculate", "fiddle", "sails", "stein", "persistent", "despicable", "bruise", "salem", "escapes", "mischief", "mckay", "cupcakes", "brussels", "arc", "ripper", "ritchie", "'hara", "vitamins", "cognac", "careers", "sim", "caps", "imbecile", "steaks", "cove", "lair", "directing", "stepfather", "slammed", "viral", "congregation", "illinois", "helicopters", "coco", "crisp", "outrage", "flexible", "goo", "licking", "funk", "ice-cream", "prefers", "tao", "captive", "montreal", "zen", "cee", "knuckles", "canteen", "credibility", "disconnected", "flats", "controversial", "enthusiastic", "janey", "cork", "priorities", "acute", "icy", "wormhole", "flyer", "bladder", "caretaker", "pep", "roommates", "programming", "grape", "astronauts", "drained", "metallic", "sergio", "seldom", "destroys", "riders", "poetic", "hacking", "transported", "contaminated", "duct", "dimensions", "insensitive", "echoes", "initiate", "nonetheless", "emmett", "grinding", "composition", "adjourned", "indulge", "wrench", "flaw", "messiah", "concluded", "accustomed", "napkin", "30s", "movin", "i-it", "doorway", "muddy", "steph", "saturn", "intentionally", "chiming", "canned", "appearing", "ballistics", "nicked", "suction", "hideout", "startled", "replacing", "solemn", "pillows", "submitted", "francesca", "override", "carver", "lea", "mateo", "mosquito", "fragrance", "pennies", "detained", "meadow", "chopping", "satellites", "cables", "youngsters", "needy", "refugee", "luc", "whitey", "inhabitants", "yun", "break-in", "harassing", "ro", "interpretation", "'il", "burying", "bree", "incomplete", "blimey", "titan", "retard", "agatha", "dilemma", "mutt", "prominent", "temples", "hoover", "lindsey", "cesar", "temp", "consul", "hairdresser", "planting", "drones", "justified", "jensen", "stuffing", "norwegian", "dork", "stalling", "birthdays", "intimacy", "tucked", "examiner", "qualify", "imminent", "masked", "diesel", "meditation", "bulk", "allie", "prosecute", "mumbles", "defined", "oklahoma", "paw", "default", "crawled", "doughnuts", "margot", "haunting", "staircase", "advances", "solutions", "plaster", "proceedings", "amends", "fraternity", "freud", "cannons", "kendall", "armored", "colonies", "perez", "birdie", "volcanic", "samson", "cleopatra", "carve", "fishermen", "brink", "playin", "martian", "hybrid", "knockout", "chunk", "constructed", "confiscated", "interrogate", "voyager", "oprah", "commerce", "t.j.", "tasks", "precaution", "printer", "finishes", "rossi", "boob", "nagging", "stephens", "hag", "skinner", "lunchtime", "imported", "transcript", "iife", "conceal", "holler", "chug", "silas", "paranoia", "compelled", "styles", "airborne", "sentiment", "syria", "pea", "babysitting", "improving", "hare", "connects", "withdrawn", "staged", "englishman", "hopkins", "pumps", "admirable", "vouch", "indicated", "reviews", "kristen", "yuki", "vey", "trivial", "parcel", "scroll", "desired", "appealing", "weighed", "'l", "designated", "bubba", "imprisonment", "ferris", "fleming", "cooling", "containing", "giles", "impressions", "advantages", "cartwright", "uncertain", "deliberate", "anticipated", "isolate", "tighten", "corporations", "petra", "venue", "irritating", "revolt", "whatcha", "lunar", "rightful", "bombers", "southwest", "maine", "marvel", "chained", "colder", "tit", "snooping", "trunks", "sully", "excused", "seduced", "communicating", "beams", "bloodshed", "offender", "offspring", "monstrous", "bruising", "we-", "doorman", "prohibited", "props", "penetrate", "intervene", "tobias", "osaka", "aiden", "niggers", "cairo", "jonny", "patriot", "bowls", "rufus", "barton", "surgeons", "pits", "infamous", "crooks", "shag", "lettuce", "exaggerating", "inferior", "zac", "foryou", "boredom", "amos", "tolerance", "cashier", "polls", "caliber", "underpants", "katy", "seller", "sensed", "vertical", "dart", "sections", "zipper", "gabby", "shankar", "acceptance", "traveler", "timeline", "emerald", "gays", "pc", "hassle", "thrilling", "hopeful", "stokes", "sneakers", "conditioning", "supporters", "rodriguez", "teal", "insults", "instruction", "flipping", "25th", "clatter", "flaming", "freight", "representatives", "invitations", "undressed", "lucille", "boiler", "edo", "uneasy", "oneself", "alfredo", "benedict", "davey", "davies", "efficiency", "that`s", "gomez", "yelps", "counterfeit", "l-i", "afterlife", "one-way", "smiley", "twat", "eccentric", "wand", "vi", "memphis", "consume", "praised", "formidable", "luthor", "lesser", "gel", "surrendered", "chffff00", "welcomed", "wendell", "tee", "launching", "cocksucker", "crores", "downs", "retiring", "spears", "vikram", "authorization", "outsiders", "pancake", "probability", "accessory", "peters", "deported", "contrast", "hooks", "remarks", "liaison", "blokes", "crater", "distribute", "vocalizing", "adele", "chiefs", "photographed", "rehearsals", "salvatore", "whoop", "credits", "shalt", "hup", "stability", "woken", "stench", "taps", "flea", "'s-it", "compelling", "dolores", "strawberries", "allright", "convictions", "hubby", "self-esteem", "threatens", "suburbs", "clocks", "peacock", "bragging", "gabi", "hurrah", "moo", "silently", "subconscious", "fatso", "pluck", "reactions", "lacks", "adolf", "mira", "refined", "lays", "bungalow", "surge", "23rd", "practices", "precautions", "thanked", "jody", "uranium", "carolyn", "menace", "ernesto", "fractured", "christie", "aka", "cone", "sauna", "extinction", "randolph", "bonding", "equality", "bourgeois", "insert", "csi", "kiki", "teens", "downhill", "pedal", "levi", "peru", "stables", "irving", "buddhist", "ambitions", "terrain", "turbo", "hae", "screening", "mu", "riots", "coaching", "explodes", "premature", "lsn", "undone", "qi", "communism", "fitted", "treacherous", "inspect", "hurray", "irresistible", "joanne", "elias", "northeast", "sparrow", "gypsies", "performer", "brew", "well.", "titles", "ingenious", "snapping", "turd", "challenger", "baghdad", "bulletin", "preview", "jinx", "immortality", "recruits", "andré", "ditched", "tempt", "procession", "eduardo", "melon", "weaknesses", "aires", "knob", "domain", "conclude", "dresser", "bao", "berries", "straining", "beads", "windy", "patent", "merchants", "profitable", "ryder", "prisons", "salvage", "mentioning", "lass", "tox", "sonja", "poof", "productive", "hosting", "doth", "ewing", "derby", "goldfish", "capitol", "leisure", "buff", "illusions", "notices", "odin", "springfield", "tracker", "kyoto", "peed", "vitamin", "heave", "bryant", "dickie", "goodwill", "euro", "strapped", "boar", "slater", "bogus", "rhymes", "brunette", "jab", "hippie", "ting", "incidentally", "face-to-face", "gi", "webb", "compensate", "tasting", "outbreak", "sow", "hallucinations", "golly", "factors", "pyramids", "copenhagen", "hiv", "dandy", "detour", "desperation", "wrestle", "entrusted", "parting", "resisting", "err", "bursting", "warrants", "savannah", "concealed", "dreamer", "mandatory", "gagging", "finances", "nightingale", "lamps", "grenades", "premier", "squire", "periods", "uhm", "kgb", "parasite", "borrowing", "rodrigo", "influential", "mammy", "absorb", "investments", "cece", "concentrated", "tyrant", "laps", "underestimated", "measuring", "origins", "applies", "britney", "exchanged", "portugal", "niggas", "maths", "decorations", "orion", "pepe", "kyung", "ownership", "tweet", "raspberry", "racial", "firstly", "suv", "intimidated", "skunk", "parsons", "nearer", "yong", "audible", "bmw", "communion", "whinnies", "hindu", "leroy", "sphere", "renaissance", "anomaly", "pursued", "klein", "chant", "outlaw", "he-", "surname", "penguins", "awarded", "mid", "classmate", "applications", "emmy", "subtitle", "laden", "economics", "well-", "ballroom", "sinned", "shortage", "mort", "phenomenal", "czech", "maneuver", "tremble", "hooking", "screeches", "moons", "ae", "sweetness", "disrespectful", "dane", "consulate", "bounced", "parenting", "robberies", "remark", "hilary", "logo", "describing", "scalpel", "cecilia", "strangest", "jaime", "seymour", "big-time", "competent", "bein", "bi", "lectures", "basics", "texture", "leftovers", "wimp", "conquest", "norris", "mounted", "pens", "contestant", "algorithm", "columns", "chile", "wails", "decree", "jeremiah", "rewrite", "'so", "momentum", "cadillac", "attorneys", "apes", "captioning", "desmond", "lesbians", "fairies", "monitors", "hua", "weighing", "roasted", "discovering", "alzheimer", "subpoena", "foe", "hicks", "cm", "circuits", "nag", "hiking", "stepmother", "personalities", "formally", "revive", "unnatural", "pip", "betraying", "renting", "prizes", "onstage", "comfy", "heath", "marrow", "blaine", "minority", "marcos", "portable", "popularity", "telegraph", "hayden", "hesitation", "sylvester", "alistair", "cluster", "grandad", "jog", "slay", "sparkling", "shithead", "tiring", "ooo", "germs", "fuhrer", "handbag", "unlimited", "thumping", "vinegar", "splinter", "supposing", "faults", "remarkably", "sketches", "nineteen", "enchanted", "hari", "respectful", "bien", "honk", "doughnut", "tags", "wrapping", "tar", "om", "dinozzo", "ducky", "unfaithful", "delia", "rae", "jojo", "stance", "barker", "financially", "clam", "clanking", "sarcastic", "blur", "organizing", "nosy", "boyle", "pasha", "my-", "attacker", "horribly", "inject", "descend", "wi", "'re-", "liberated", "burner", "fluffy", "melancholy", "puppets", "anal", "grieve", "awe", "gallons", "earring", "unprecedented", "yank", "jamaica", "brutally", "extortion", "guardians", "disciples", "simultaneously", "elves", "malibu", "lupin", "postman", "neville", "senseless", "chapman", "sittin", "hostel", "marcia", "melvin", "cockroach", "clamp", "poets", "chemist", "professionally", "faded", "vargas", "gunpowder", "inc", "gala", "surroundings", "wisconsin", "rivals", "cackling", "withstand", "contemporary", "harlem", "half-hour", "marlon", "endured", "arsenal", "underway", "donuts", "daryl", "frickin", "injected", "digs", "siegfried", "elisabeth", "billionaire", "cardboard", "hugs", "'an", "bandages", "everlasting", "liverpool", "cooperative", "diploma", "neural", "fortunes", "rural", "abbott", "receptionist", "antiques", "labels", "sizes", "millennium", "layout", "immoral", "manages", "hisses", "usher", "impulsive", "pollution", "admirer", "'r", "rejoice", "iowa", "marlene", "hindi", "holder", "squeezed", "merge", "journalism", "nominated", "sundown", "assistants", "miraculous", "stared", "prescribed", "lotta", "swearing", "guarantees", "massachusetts", "junction", "consumption", "astrid", "metropolis", "iceland", "bridal", "virgins", "victorious", "squirt", "pads", "modified", "hanson", "casket", "blaze", "kimble", "cliffs", "destroyer", "offshore", "tendency", "nip", "scanning", "first-class", "viva", "intensive", "gustav", "endangered", "va", "circling", "ave", "stashed", "das", "backward", "hai", "chamberlain", "sari", "thermal", "opponents", "fiber", "last-minute", "toto", "circumstance", "geography", "stargate", "interpret", "sicily", "pisses", "preaching", "transporter", "bosom", "salsa", "eighty", "shred", "dread", "duration", "beggars", "mein", "josephine", "networks", "formality", "heater", "par", "smug", "ordeal", "rhonda", "agriculture", "aigoo", "katya", "fowler", "descended", "lasting", "abyss", "marries", "aurora", "sleigh", "frenchman", "rouge", "survives", "margo", "redhead", "terrence", "creativity", "dominant", "isis", "kip", "corny", "aubrey", "graphic", "irrational", "mathematical", "sacked", "paws", "chariot", "havoc", "andreas", "midget", "celestial", "cetera", "nino", "upgrade", "blasting", "skulls", "it-it", "mean-", "videotape", "wedded", "babysit", "ancestor", "transit", "rained", "thingy", "wellington", "abide", "reserves", "'they", "rim", "chico", "settles", "decisive", "motors", "cheesy", "symbolic", "roxy", "clink", "handicapped", "mating", "cranky", "brightest", "molecules", "meyer", "sheridan", "sorry.", "animation", "grail", "voluntarily", "creeping", "furnace", "thine", "titus", "pierced", "bu", "chinatown", "slade", "sai", "toothpaste", "cuddle", "langley", "egyptians", "bankruptcy", "lever", "shaman", "nipple", "weeds", "becker", "reacted", "mashed", "sloane", "regent", "bentley", "tiles", "decoy", "crusade", "vivid", "slides", "jennings", "catering", "dishonest", "subs", "lurking", "airplanes", "shaky", "barren", "alligator", "moth", "uncover", "lorna", "axel", "expressing", "clacking", "doggie", "airlines", "dum", "unicorn", "jackets", "goofy", "marcy", "businessmen", "bums", "folded", "defender", "alarmed", "goody", "noose", "chic", "forgiving", "thatcher", "index", "blush", "fertile", "amateurs", "deliveries", "armour", "werner", "shits", "twinkle", "parted", "syndicate", "alexandra", "righty", "regions", "technician", "waffles", "skirts", "baroness", "castro", "malfunction", "memorable", "middle-aged", "thea", "calories", "cuisine", "motorbike", "snoop", "acknowledged", "spelled", "evolve", "cox", "sedative", "array", "tenderness", "klingon", "garland", "smuggled", "nicola", "raju", "reversed", "royce", "beforehand", "continuous", "yoko", "cecil", "seniors", "mri", "synthetic", "forgave", "discoveries", "kimmy", "agitated", "attendance", "maple", "pools", "wanker", "casa", "firearms", "offenders", "obligations", "moan", "signor", "graffiti", "supplied", "linen", "defect", "patriotic", "ethical", "pest", "lengths", "vin", "minnie", "spectrum", "distinction", "decorate", "bounds", "hums", "mandarin", "reluctant", "rand", "retain", "justine", "educate", "minnesota", "mp", "cruiser", "permits", "screwdriver", "exploration", "mace", "newborn", "shivering", "slime", "oddly", "badger", "bruised", "luigi", "attaboy", "eyeballs", "institutions", "panama", "boundary", "hypothesis", "ffff00", "drought", "rembrandt", "absorbed", "clinking", "executioner", "darts", "catalina", "lured", "lingerie", "gon", "flaws", "thinner", "lucien", "tug", "cornered", "bertie", "uptown", "clash", "aerial", "hansen", "relentless", "viable", "raul", "wen", "scholars", "marley", "limitations", "shelves", "funerals", "criticize", "jacqueline", "forrest", "shaun", "continental", "bookstore", "balanced", "workplace", "theta", "ramsey", "dixie", "bankers", "dumbass", "superstitious", "clause", "fudge", "bennet", "assignments", "councilman", "slogan", "trinity", "quadrant", "boarded", "ivory", "velocity", "composer", "mccarthy", "initiated", "covert", "builder", "insignificant", "dire", "gears", "comply", "credentials", "organizations", "applaud", "trend", "providence", "sparkle", "chump", "derrick", "donations", "flooding", "maintained", "snowing", "shaolin", "ladyship", "artifacts", "allegedly", "howl", "deploy", "showtime", "thornton", "deposition", "fractures", "handshake", "neglect", "adapted", "patrols", "bess", "cyber", "hetty", "protocols", "overdue", "slayer", "headphones", "identities", "appoint", "rotation", "solely", "tasha", "aging", "pitching", "examining", "viewing", "memorize", "freshen", "mango", "valued", "sonar", "crichton", "decay", "eu", "nightfall", "olives", "miniature", "omen", "kristin", "bai", "what-what", "chum", "posse", "mutiny", "toaster", "span", "jumbo", "blames", "mystical", "researchers", "exposing", "dung", "welsh", "frat", "waterfall", "lifts", "disgusted", "yikes", "windshield", "akira", "maintaining", "receives", "plantation", "antenna", "bodyguards", "havana", "anya", "edit", "superficial", "allergies", "invites", "comparing", "dirk", "cartoons", "mexicans", "timber", "supervision", "siberia", "winding", "rust", "intensity", "hiccup", "francois", "johan", "jogging", "confrontation", "flyers", "trustworthy", "jarvis", "coaster", "paragraph", "mosquitoes", "adios", "lovin", "unexpectedly", "russo", "amuse", "splashing", "soviets", "lorry", "dominate", "bundy", "howie", "jp", "unreal", "screens", "mouthing", "ziggy", "failures", "commanded", "recon", "representation", "bending", "gallant", "satisfying", "cheater", "pornography", "urn", "assign", "uncles", "vine", "auspicious", "tripping", "seafood", "mellow", "announcing", "resumes", "hawaiian", "ac", "centers", "adultery", "scatter", "lotion", "opposing", "dominated", "unpack", "violate", "transmit", "testicles", "zhao", "ames", "t.c.", "kayla", "hungary", "albums", "well-being", "porridge", "gavel", "prem", "rattles", "eliot", "titties", "strengthen", "sensitivity", "fitzgerald", "tamara", "removal", "sacks", "downloaded", "morocco", "sniffling", "crowns", "saddam", "nerds", "accepts", "hive", "radha", "outdoor", "raquel", "dew", "ing", "mt", "currents", "explanations", "soaking", "tanaka", "vitals", "navigation", "joins", "intrigued", "harp", "führer", "margin", "everett", "anthem", "aa", "kylie", "'c", "distracting", "fertility", "amazingly", "horrific", "indictment", "superstition", "ultrasound", "shifted", "sincerity", "hamburg", "davy", "trashed", "casper", "dumplings", "digest", "whacked", "jacks", "kiddin", "casualty", "bethany", "thump", "proportion", "quantity", "janine", "deceiving", "weave", "hikaru", "sdh", "corrupted", "gallows", "budge", "fraction", "afar", "hiroshi", "leela", "measurements", "landlady", "certified", "dusk", "luisa", "insisting", "hilton", "indoors", "hawkeye", "saliva", "homey", "whispered", "maura", "cyanide", "marched", "accounted", "diver", "eligible", "robbins", "ch00ff00", "messes", "abandoning", "blossoms", "wiggle", "awaken", "cid", "stained", "ballard", "elevated", "ryo", "transparent", "unclear", "strokes", "aria", "hwa", "solidarity", "sidekick", "starter", "regarded", "corinne", "vulcan", "bradford", "godzilla", "belgian", "seemingly", "cling", "components", "vibrates", "missouri", "constance", "batting", "chanel", "sap", "marbles", "shifting", "wiping", "refill", "famine", "sneeze", "puzzles", "provisions", "shite", "walkin", "syringe", "platinum", "preferably", "oyster", "exhaust", "electromagnetic", "consumer", "lasagna", "barnaby", "catastrophic", "winchester", "woah", "be-", "evacuated", "serge", "relic", "describes", "merger", "muck", "buds", "socially", "enlisted", "deposits", "philippines", "archbishop", "smuggle", "climax", "progressive", "wheezing", "singles", "pillar", "fearful", "spade", "saucer", "ratio", "craving", "addicts", "clifford", "orson", "nashville", "beauties", "obscure", "signora", "troublesome", "rubble", "largely", "fong", "irina", "ahn", "admiration", "lizzy", "flap", "brutality", "mariana", "prevail", "tattooed", "brats", "anguish", "whim", "nada", "leaks", "cum", "cupid", "hana", "colonial", "frau", "speeds", "'uld", "perpetrator", "watermelon", "emptied", "sponsored", "rooftop", "athena", "managers", "extraction", "stat", "rhino", "diarrhea", "disregard", "warmed", "goggles", "colombia", "struggles", "fitness", "scalp", "veterans", "suitcases", "kensi", "watchman", "caress", "devlin", "exclusively", "disciple", "misty", "aura", "helm", "crockett", "inhale", "buckets", "adored", "shillings", "kari", "tents", "revoir", "hedge", "e.r.", "snorting", "viper", "digger", "breaker", "meatballs", "suppress", "witty", "wonderfully", "shogun", "encouragement", "intercepted", "goddamned", "posting", "cleanse", "f.b.i.", "no-", "competitor", "abbot", "trenches", "sizzling", "lyon", "mustang", "stewie", "kg", "rested", "reflected", "stand-up", "habitat", "molecular", "obnoxious", "24-hour", "wraith", "sarcasm", "tung", "renowned", "tofu", "wildly", "blondie", "refund", "goon", "pulp", "exaggerated", "shad0", "embedded", "chateau", "harlan", "provoked", "antony", "guido", "nile", "alfie", "cages", "skates", "resemble", "sticker", "lennox", "unstoppable", "veal", "fe", "isle", "characteristics", "earthquakes", "cold-blooded", "ambushed", "zap", "reaper", "deployed", "biblical", "puck", "mystic", "aya", "gaby", "intends", "muffins", "speedy", "'course", "republicans", "bolts", "enrique", "hoax", "raided", "intersection", "presently", "supplier", "shuffle", "edited", "rubbed", "vegan", "outdoors", "distinctive", "upcoming", "brighton", "wagons", "granger", "peeing", "oracle", "glitter", "amulet", "suspend", "guild", "convertible", "squared", "battling", "steward", "weston", "gateway", "rites", "distributed", "pavement", "projector", "rugby", "jt", "fragment", "baldwin", "obscene", "zebra", "raping", "analyst", "eta", "elbows", "detonator", "disneyland", "rails", "earthly", "modesty", "assess", "vinci", "librarian", "do-", "moran", "suffice", "gravitational", "crowley", "slumber", "homie", "bribes", "aces", "sodium", "hubert", "trajectory", "credible", "declined", "canary", "eyesight", "jug", "duplicate", "developments", "capitalism", "polished", "defenses", "xi", "crates", "fences", "differ", "hodgins", "enzo", "chaotic", "gardening", "gram", "tinker", "forecast", "ti", "pinched", "tangled", "macy", "plunge", "bulletproof", "module", "firewood", "pizzas", "overly", "retail", "novak", "grover", "arturo", "appalling", "rows", "felicia", "concentrating", "transferring", "mash", "growl", "sliced", "rewards", "braces", "livestock", "users", "recruiting", "gunman", "dictate", "bathrooms", "nobles", "picky", "linus", "platter", "vultures", "organism", "sweeter", "scarecrow", "manufacturing", "pup", "mitzvah", "crackles", "proudly", "interpreter", "leigh", "genetically", "frying", "redeem", "cara", "ledge", "qing", "tyranny", "charleston", "cutest", "skins", "rosy", "nomination", "textbook", "descendants", "sabine", "saunders", "hast", "dubois", "finland", "loretta", "unsolved", "pioneer", "or-", "ramirez", "suzie", "hugged", "angelica", "cesare", "throttle", "powered", "carving", "thrive", "d.j.", "allergy", "icu", "suzy", "pong", "squares", "alphabet", "threesome", "accordingly", "sect", "maternity", "scarce", "internship", "morty", "tones", "sirs", "unwell", "nellie", "import", "temporal", "mohammed", "anticipate", "democrats", "pfft", "terminated", "spree", "ami", "interviewer", "respectfully", "futile", "dictator", "stuffy", "wai", "mammals", "fasten", "neptune", "giggle", "grandchild", "pharmaceutical", "persian", "tactic", "itching", "observer", "tesla", "wallpaper", "thorne", "jiang", "austrian", "output", "'malley", "goliath", "trophies", "joyful", "spouse", "giorgio", "rightly", "hobbies", "'there", "vito", "naming", "yates", "stale", "teamwork", "obedient", "switches", "rating", "regulation", "raving", "dioxide", "boner", "bc", "implant", "mari", "satisfactory", "espresso", "bach", "sleeper", "construct", "rations", "munch", "anjali", "coordinate", "stag", "dominique", "backseat", "chrissy", "analyzed", "reschedule", "uphold", "sorority", "bono", "princeton", "inconvenient", "crumbs", "reconstruction", "pipeline", "reunited", "confidentiality", "embraced", "overruled", "enlightenment", "puddle", "mortals", "comfortably", "vlad", "misha", "ukraine", "swam", "annette", "demonic", "sora", "demise", "donatello", "fungus", "barefoot", "tacos", "skeletons", "beak", "fanfare", "maryland", "felipe", "picard", "mascot", "lemonis", "drastic", "proceeding", "presidents", "intrude", "stiles", "sums", "deprived", "advertisement", "farting", "straightened", "foremost", "adjustment", "charade", "blanks", "stig", "puncture", "spank", "utah", "booing", "abs", "minimal", "gals", "flashes", "andrei", "requirements", "greenhouse", "marx", "'ma", "vermont", "comprehend", "canoe", "baton", "arsehole", "graduating", "partially", "sensing", "kinky", "titans", "microscope", "intimidating", "ren", "babu", "territories", "vaguely", "geese", "hardship", "karin", "exceptions", "jing", "gramps", "florrick", "doubles", "knitting", "slowed", "administrator", "blacksmith", "ctu", "tolling", "correspondence", "fashionable", "overlooked", "siobhan", "matron", "arcade", "gestures", "lonnie", "bord0", "quits", "outnumbered", "lockhart", "verbal", "mc", "terminate", "hosts", "rye", "chirps", "presidency", "roberta", "devote", "30th", "dumps", "hallo", "improvise", "monique", "pooh", "starship", "spades", "fumes", "cawing", "aluminum", "squeak", "drafted", "ssh", "everest", "michaels", "commonwealth", "candace", "cappuccino", "cucumber", "inventor", "folder", "slamming", "favours", "peppers", "appeals", "walton", "reasoning", "adequate", "snickers", "glued", "ifs", "nets", "hangar", "godmother", "empty-handed", "sátur", "forum", "joys", "foolishness", "sybil", "crest", "playful", "peers", "horrors", "grown-ups", "bleach", "disastrous", "lineup", "glamour", "coronation", "halo", "sookie", "highlight", "ziva", "ponies", "errors", "viv", "alvarez", "pluto", "weights", "arabia", "imperative", "trader", "galileo", "tainted", "drugstore", "lenses", "obstruction", "segment", "envious", "gertrude", "twisting", "nikolai", "insured", "overlook", "icon", "rollin", "commentator", "pitt", "camilla", "cerebral", "qin", "zelda", "spoiling", "tsar", "frames", "cushion", "divers", "hallowed", "chute", "cavity", "reds", "volcanoes", "on.", "angelina", "sahib", "strung", "watts", "40s", "monopoly", "bros", "immigrant", "back-up", "apache", "caffeine", "squeezing", "postponed", "encounters", "stuttering", "rut", "calmed", "opener", "baek", "impotent", "tabs", "franchise", "entity", "slimy", "hygiene", "andi", "containment", "knickers", "jumpy", "pistols", "irregular", "lowly", "controller", "rung", "hades", "anarchy", "wisely", "blackmailed", "dudley", "dramatically", "researching", "borg", "touchy", "fay", "seventy", "m.o.", "bullies", "stealth", "divya", "divisions", "yearbook", "abdul", "poll", "blinds", "sneezes", "bigfoot", "ninety", "dharma", "cramp", "cockpit", "truthful", "lilith", "ghastly", "hangin", "edwin", "c.j.", "whines", "corrections", "missionary", "infinity", "cola", "penance", "moist", "sham", "investor", "founding", "krystle", "caldwell", "orientation", "captains", "flop", "columbo", "jamming", "yoo-hoo", "crossroads", "p.d.", "infrared", "pleading", "sven", "carroll", "flushed", "magda", "gaming", "gurgling", "vinny", "prairie", "component", "saudi", "slapping", "gases", "aching", "lau", "abusive", "vermin", "bracelets", "tyre", "rift", "wiring", "gauge", "robby", "lifelong", "abstract", "pilgrimage", "theoretically", "mythology", "johnnie", "photographers", "wilma", "render", "rocked", "iq", "licked", "android", "rhythmic", "pianist", "clover", "unwanted", "salvador", "troupe", "feat", "primarily", "preposterous", "drying", "unseen", "raoul", "vulture", "constantine", "outlet", "git", "pictured", "functional", "24th", "nitrogen", "cc", "lest", "right-hand", "speechless", "delusions", "peeping", "follow-up", "refrain", "jerking", "engaging", "accountable", "piles", "ch", "intro", "rescuing", "orgy", "zane", "jaguar", "prue", "'she", "concerts", "schemes", "abusing", "fatigue", "taj", "charitable", "lili", "attracts", "stirred", "invaders", "wench", "kittens", "riggs", "gras", "heartbroken", "suffocating", "youse", "underage", "amar", "bugged", "dimitri", "'m--i", "klinger", "metropolitan", "unions", "worf", "cds", "hamster", "omelet", "humility", "grad", "obedience", "grub", "victorian", "lassie", "posed", "conway", "resentment", "didi", "locke", "dat", "booming", "aunts", "shay", "brigadier", "intrusion", "hedgehog", "recipes", "tacky", "'or", "here.", "hk", "saviour", "physicist", "yonder", "admiring", "anyplace", "forfeit", "lullaby", "oasis", "unleash", "avengers", "indifferent", "boxers", "truthfully", "organise", "actresses", "grin", "arranging", "voila", "hydra", "shutters", "pearson", "genesis", "daria", "energetic", "postal", "henrik", "aloud", "hmph", "archive", "nauseous", "funniest", "muse", "ernst", "constitutional", "recital", "covenant", "cloudy", "prestige", "olivier", "pencils", "gunnar", "helper", "decks", "astray", "leland", "that-that", "ip", "casing", "cooing", "ozzy", "sterile", "bagel", "releases", "recognizes", "lorelai", "intimidate", "forgery", "kenya", "bred", "dunn", "vector", "huck", "nausea", "sakura", "detonate", "lenin", "inhuman", "horsepower", "violating", "pascal", "informer", "hooting", "plugged", "oriental", "about-", "pretends", "tram", "reyes", "spoils", "chaplain", "farce", "parasites", "whipping", "cruising", "violently", "tile", "ashtray", "und", "neighing", "zones", "donut", "spoilt", "nobility", "decoration", "sharpe", "scoot", "kelso", "abdominal", "updated", "blueprints", "dealings", "pitched", "resource", "coalition", "hoss", "professors", "espionage", "dishwasher", "minded", "cheyenne", "resulted", "brewster", "wrestler", "cons", "protesting", "barbarians", "loony", "kangaroo", "rite", "dialect", "counsellor", "tsunami", "locket", "sorcerer", "pilgrims", "incorrect", "parameters", "risotto", "unreliable", "geniuses", "agricultural", "willard", "marital", "wilkes", "scramble", "hera", "swears", "starvation", "'my", "summons", "aquarium", "flavors", "sanity", "roxanne", "caste", "wedge", "bedside", "experimenting", "truths", "tribunal", "emerson", "darlene", "automated", "treachery", "explorer", "greens", "dunk", "amused", "fishes", "kappa", "oleg", "goblin", "appreciates", "lark", "commissioned", "reassuring", "disclose", "seaside", "politely", "preoccupied", "incense", "folly", "pear", "vikings", "irs", "lavender", "graceful", "stretcher", "grande", "simulation", "lasers", "groovy", "discussions", "basin", "sacrificing", "luncheon", "disobey", "snot", "mil", "sinful", "yearning", "gruesome", "aide", "i`m", "shen", "haha", "masculine", "mortimer", "extras", "hopper", "guides", "banjo", "dina", "camelot", "blazing", "dos", "crowned", "gonzalo", "painkillers", "rave", "foley", "silvia", "sylvie", "cover-up", "cassette", "sorting", "misplaced", "sprung", "vs.", "practising", "prehistoric", "howls", "enterprises", "designing", "suspense", "patti", "japs", "renounce", "paints", "relying", "w.", "n-no", "rendered", "herald", "randomly", "stylish", "spleen", "mugged", "investing", "protestant", "circumstantial", "smear", "pantry", "guiding", "flavour", "hollis", "cursing", "erection", "gravel", "artifact", "raccoon", "0h", "classics", "enlighten", "enhance", "delivers", "spinach", "binding", "goldman", "invalid", "touring", "johns", "fashioned", "gilmore", "spilling", "ledger", "quieter", "meadows", "majestic", "frequencies", "zhou", "historian", "containers", "marisa", "diplomat", "wrinkles", "aryan", "subtitling", "para", "nationals", "natalia", "rudolph", "palestine", "insulin", "torpedoes", "pagan", "swimmer", "disgraced", "bygones", "intellect", "accommodate", "posture", "adjusting", "giraffe", "peer", "petersburg", "religions", "hammering", "audiences", "ruben", "gigs", "damaging", "colossal", "renew", "iceberg", "vigilante", "emile", "dougie", "biggie", "pietro", "chewed", "cellular", "indecent", "dangerously", "duane", "bribed", "rascals", "chai", "ramona", "grammar", "thrash", "hutch", "runners", "pager", "stumble", "dispatcher", "thankyou", "iast", "stump", "wraps", "gator", "teammates", "skye", "weakest", "disconnect", "melts", "morally", "feud", "apiece", "theatrical", "distinguish", "cooperating", "passions", "strive", "flourish", "reeves", "unnecessarily", "janie", "perceive", "upstate", "accuracy", "cosmo", "bitterness", "fundraiser", "reflects", "insolent", "strauss", "circular", "generated", "rumble", "pilgrim", "squirrels", "purge", "xander", "mingle", "manufacture", "firemen", "casually", "handler", "hobbs", "slain", "phd", "multiply", "confinement", "patches", "divert", "alfonso", "protests", "versions", "ambrose", "adriana", "ia", "mit", "youthful", "numbered", "mustafa", "herbal", "kathryn", "gunther", "lawful", "stacked", "damian", "reasonably", "suzuki", "myra", "logged", "prospects", "mainstream", "sykes", "alimony", "stating", "budapest", "nelly", "awakened", "curses", "ore", "slices", "curl", "uprising", "cabaret", "manufacturer", "ration", "boulder", "manpower", "badges", "mush", "recycling", "disarm", "elusive", "snarls", "chiu", "flawless", "considers", "youre", "harmful", "horseback", "m.e.", "owens", "admits", "morales", "helene", "thankfully", "recreate", "travelers", "navigate", "pun", "ethnic", "voice-over", "kono", "esteemed", "exterior", "duffy", "triad", "licensed", "gems", "moira", "mutants", "testifying", "dissolve", "iraqi", "robes", "wildest", "portfolio", "tossing", "pussycat", "booby", "nbc", "simms", "knack", "lodged", "cpr", "lei", "racism", "nato", "mayo", "gillian", "stingy", "kaiser", "shooters", "napkins", "continents", "registry", "fags", "shah", "blinking", "capt.", "duo", "gymnastics", "jag", "bernadette", "valiant", "exploited", "attachment", "'for", "trans", "intruders", "owning", "mega", "crispy", "administrative", "hawks", "crave", "qu", "reviewed", "persuasive", "turmoil", "promoting", "shoving", "bette", "unworthy", "elevators", "fulfilling", "ronny", "rooting", "irma", "mcqueen", "s.h.i.e.l.d.", "stoop", "ee", "a.j.", "greer", "panicking", "panels", "demonstrated", "myths", "mattie", "volleyball", "cheats", "chord", "berkeley", "oblige", "radiant", "anticipation", "fibers", "daleks", "aroused", "paralysis", "ferocious", "heinous", "roulette", "emergencies", "olaf", "enjoyable", "torso", "compassionate", "softer", "delegation", "can`t", "fangs", "plaque", "alonso", "moi", "o.j.", "bowman", "uterus", "buggy", "kristina", "denies", "tally", "neighs", "unusually", "tibet", "fez", "charcoal", "healer", "weirdest", "eel", "recordings", "tamil", "naw", "camouflage", "seagulls", "hub", "shoulda", "mailman", "buckley", "furry", "pronto", "sedan", "kermit", "amir", "edible", "trifle", "delusion", "foundations", "calcutta", "cubes", "colon", "crotch", "tariq", "costing", "resisted", "leila", "snail", "ursula", "strippers", "there-", "vista", "sorta", "fiend", "ultra", "restrain", "pinkie", "voluntary", "widely", "uncommon", "blackie", "farrell", "infiltrate", "erika", "sophomore", "radios", "ringo", "medallion", "eiffel", "yamato", "wilder", "dyke", "bailiff", "peril", "plaintiff", "emilia", "transmitted", "bonnet", "assassinated", "emptiness", "helmets", "normandy", "cheetah", "clips", "thicker", "whiz", "saga", "bullock", "binoculars", "duckman", "accord", "diva", "jeanette", "birmingham", "pick-up", "bawk", "sita", "concierge", "clams", "questionable", "volunteering", "lunches", "spooked", "pinpoint", "hereafter", "brook", "weakened", "verses", "think-", "marshals", "deposited", "cleans", "ironically", "bodily", "distances", "hypnosis", "secretive", "dominion", "civic", "tori", "bursts", "uncertainty", "streams", "vortex", "tights", "sponsors", "tickles", "cello", "herring", "ab", "disability", "griffith", "orchid", "hostility", "conflicts", "pans", "housekeeping", "panthers", "wonderland", "ruiz", "interrogated", "andromeda", "premium", "broccoli", "garfield", "mussolini", "pottery", "shrapnel", "planner", "jacked", "robyn", "rounded", "giuseppe", "cactus", "motherland", "defendants", "wilt", "jia", "executives", "spoons", "mnh-mnh", "belinda", "unbelievably", "fairness", "continuously", "spices", "organisms", "regretted", "monarch", "narrative", "roth", "catcher", "dictatorship", "controversy", "manu", "alejandro", "josef", "dignified", "bonded", "tilt", "beginnings", "peaks", "tissues", "pretentious", "dell", "jeopardize", "osborne", "diversity", "shabby", "brownies", "overdo", "sharma", "crunching", "tel", "marnie", "separating", "horrid", "overrated", "harmon", "rethink", "mastered", "eww", "reopen", "camels", "tux", "denis", "depended", "tak", "whine", "axis", "orchard", "cherries", "pleasing", "unforgivable", "craziest", "rods", "distressed", "bubbling", "'on", "interact", "manipulating", "rewind", "burgundy", "blacked", "trillion", "onwards", "reservoir", "participation", "caucasian", "flushing", "serbian", "manhood", "lao", "matilda", "exhale", "dinah", "in-laws", "caramel", "slander", "identifying", "drunkard", "blooming", "stocking", "one-on-one", "rinse", "artwork", "catholics", "stormy", "refresh", "elisa", "cor", "floats", "expanded", "chilling", "congo", "afghan", "backside", "antarctica", "sandals", "investigative", "wills", "searches", "yawns", "collaboration", "untouched", "psyched", "hussein", "departments", "tuxedo", "mak", "bummed", "heinrich", "finer", "manure", "him-", "compatible", "moor", "keg", "monsignor", "peeled", "dona", "stings", "seeker", "watering", "ids", "malaria", "aj", "walters", "sinatra", "lending", "dodgers", "fortnight", "reassure", "braun", "meddling", "overthrow", "postmortem", "achievements", "excellence", "'ight", "latch", "coppers", "raids", "dickens", "thing-", "drifted", "leeds", "obsessive", "upwards", "lynette", "oatmeal", "midday", "implants", "unmarried", "murat", "sewers", "bowie", "mercenary", "perks", "outrun", "copying", "upload", "freya", "helga", "shu", "bumping", "inland", "yorkshire", "humbly", "injections", "participating", "python", "laurent", "prof.", "cockroaches", "puberty", "technologies", "crumble", "toots", "miki", "roscoe", "high-school", "clot", "exterminate", "rake", "cholesterol", "deli", "augustus", "sublime", "bottled", "fung", "charlene", "the-the", "demolition", "methane", "appendix", "aches", "ahoy", "distractions", "dashing", "plank", "medications", "chevy", "zurich", "makers", "invading", "loner", "comm", "grissom", "miner", "senile", "commando", "mantle", "manufactured", "broth", "interaction", "lsd", "sesame", "auschwitz", "restraint", "devour", "zachary", "sardines", "orb", "govern", "respiratory", "elope", "webber", "wreckage", "lumber", "consists", "operates", "needless", "faulty", "alps", "assassinate", "santo", "edinburgh", "staggering", "jillian", "murmurs", "bologna", "unleashed", "brushing", "surgeries", "alphah3d", "coffees", "advancing", "celeste", "trixie", "commonly", "mentality", "cordelia", "hammered", "meltdown", "rayna", "mastermind", "luciano", "olsen", "brow", "galactic", "16-year-old", "muriel", "strand", "tedious", "burrito", "builders", "encrypted", "threads", "now-", "22nd", "wronged", "judd", "gill", "cremated", "collectors", "prosper", "sheppard", "terri", "ferdinand", "handicap", "disciplinary", "hardcore", "hens", "inventions", "export", "alain", "vowed", "snappy", "kingdoms", "vocabulary", "cromwell", "tj", "reacting", "conceive", "bart.", "sling", "transporting", "murderous", "marius", "col.", "checkmate", "patio", "rebound", "baptized", "hooves", "payday", "jodie", "pranks", "seizures", "enable", "seaweed", "delirious", "cyborg", "telephoned", "bravely", "huey", "markings", "widows", "gianni", "hologram", "fielding", "dibs", "triumphant", "washes", "wilbur", "lexi", "hauling", "buckingham", "steadily", "processes", "for-", "bey", "projection", "creed", "acquitted", "mink", "meddle", "buts", "kwon", "scoundrels", "'til", "spectators", "blushing", "close-up", "faye", "frigging", "torches", "kato", "barlow", "mix-up", "horseman", "prescott", "vacations", "avalanche", "marking", "fret", "pacey", "glasgow", "editorial", "fleas", "eyeball", "trails", "insides", "bonfire", "micah", "anu", "urgency", "bearer", "provincial", "clueless", "chaplin", "mercer", "tempo", "conner", "capitalist", "bumpy", "maternal", "harass", "stomp", "cheeseburger", "didnt", "chime", "oppression", "resembles", "festive", "mayhem", "fleeting", "zodiac", "geezer", "thorns", "gags", "freelance", "whatnot", "scots", "brutus", "cylinder", "teri", "pouch", "sato", "are-", "fossils", "twenty-four", "marko", "b.a.", "crosby", "plausible", "disgraceful", "dax", "brushed", "dai", "holed", "encore", "ludwig", "impulses", "heads-up", "takeoff", "ceremonies", "resulting", "refers", "shatter", "fascists", "entertained", "mckenzie", "rin", "lama", "specialists", "a-and", "phenomena", "preventing", "affectionate", "precedent", "contributed", "blindfold", "schmuck", "raf", "hatchet", "bambi", "'connor", "statute", "offscreen", "gao", "carefree", "pollen", "endurance", "dialed", "virtues", "coping", "penitentiary", "hallucinating", "combo", "bowel", "hypothetically", "jana", "mayonnaise", "vineyard", "tam", "digits", "myers", "evolutionary", "ribbons", "kabir", "francesco", "advertise", "saline", "edgy", "girlie", "rao", "regained", "parental", "barbarian", "brewing", "tat", "disrupt", "unanimous", "implications", "high-end", "candice", "scallops", "vibrations", "homesick", "stung", "casanova", "tormented", "wi-fi", "steamed", "baptism", "leagues", "kwan", "thunderclap", "harassed", "velma", "chimp", "consulted", "'no", "scripts", "restoration", "retribution", "bows", "unforgettable", "afterward", "adventurous", "swab", "in-", "inevitably", "'if", "ooh-ooh", "expectation", "xu", "carcass", "notary", "lukas", "armand", "alphahff", "perverted", "surrogate", "spat", "dazzling", "snipers", "lai", "cartman", "capabilities", "midwife", "gains", "grumbling", "retainer", "bleak", "houdini", "inquiries", "expel", "berger", "markers", "reap", "specs", "morn", "deceit", "carole", "coloured", "degenerate", "adi", "petals", "dues", "tensed", "battered", "withdrew", "darlings", "starbuck", "patton", "mound", "accurately", "frenzy", "senators", "saturdays", "12-year-old", "nemesis", "rocker", "whiff", "tagged", "fearing", "fringe", "peninsula", "carey", "radiator", "tolerated", "tor", "clucking", "stun", "specimens", "reuben", "accomplices", "somber", "assailant", "mutation", "ke", "straightaway", "one-", "spun", "reclaim", "paramedic", "capturing", "gaston", "biopsy", "proportions", "colleges", "doubting", "theoretical", "funnier", "whee", "indefinitely", "disasters", "sen", "forwards", "quo", "addressing", "iolaus", "pakistani", "neon", "slurping", "felon", "inflation", "zordon", "stallion", "blackjack", "passive", "milligrams", "irritated", "worldly", "manipulation", "strips", "hijacked", "jingling", "pushy", "macaroni", "bulldog", "rigid", "maxim", "checkpoint", "soothing", "hateful", "folding", "reduction", "loaned", "undermine", "frontal", "victories", "empathy", "achilles", "overload", "topanga", "piercing", "cliché", "stamped", "potent", "bristol", "snob", "hypothetical", "detection", "unharmed", "subjected", "boils", "crocodiles", "coupons", "culinary", "mahjong", "rené", "fleur", "niko", "lira", "nonstop", "giddy", "teachings", "seong", "clinging", "n.", "silenced", "ramen", "goodman", "disposition", "enforce", "gunner", "ragnar", "ploy", "suburban", "sleepover", "slutty", "imply", "cheerleaders", "conception", "werewolves", "catalog", "paranormal", "shun", "aaaah", "biker", "jellyfish", "municipal", "ruckus", "adviser", "alerted", "commune", "granite", "fr", "formalities", "proximity", "unavailable", "fargo", "defenseless", "innovation", "paradox", "koreans", "valleys", "walden", "trooper", "infrastructure", "barrow", "interns", "taro", "bertha", "proctor", "hovering", "feminist", "declan", "observations", "prone", "spins", "conversion", "emerging", "sheffield", "dustin", "ares", "crazier", "od", "goldie", "bulbs", "blindly", "rabies", "smurf", "brownie", "formerly", "chastity", "desirable", "barriers", "hoops", "grains", "maría", "u.", "considerably", "anand", "baptist", "decorating", "proposals", "lahey", "staging", "diabetic", "baskets", "macbeth", "rehabilitation", "muscular", "revolting", "glacier", "expressions", "hiroshima", "imitation", "footprint", "beaumont", "stupidest", "unborn", "jacobs", "displayed", "commanders", "confirming", "garment", "latter", "indonesia", "enlightened", "plight", "hel", "dorian", "ogre", "warnings", "incision", "inquire", "tampered", "prophets", "listener", "substances", "rapping", "kisser", "hind", "apb", "ulysses", "butters", "dci", "tripp", "dublin", "meows", "preference", "minding", "mirage", "prediction", "dodgy", "drenched", "backbone", "sightings", "goku", "bessie", "virtuous", "earns", "grizzly", "slob", "floods", "enquiry", "begs", "juror", "strained", "monitored", "brethren", "oblivion", "contracted", "bookie", "painters", "amnesty", "cot", "cosmetics", "mortar", "wilfred", "friction", "drunks", "correspondent", "marlowe", "outskirts", "veer", "gaga", "wacky", "mann", "sparky", "adieu", "informing", "swung", "trina", "hamburgers", "interruption", "mediocre", "fulfil", "schedules", "sinks", "pathologist", "disposed", "knit", "excluded", "marcie", "scraps", "hey.", "sob", "unhealthy", "borgia", "prestigious", "rotate", "tracey", "concubine", "sanjay", "ridden", "ballot", "fischer", "complexion", "bugle", "humanitarian", "gurney", "whit", "hoot", "sumo", "holocaust", "io", "yao", "servers", "hartley", "'day", "fabio", "salim", "sleepless", "fern", "forbes", "calcium", "frown", "deranged", "exhaustion", "one-night", "rebuilt", "legislation", "sighting", "discomfort", "tru", "technological", "saigon", "lacked", "bermuda", "hit-and-run", "wept", "disperse", "kosher", "entrepreneur", "tyra", "worshipped", "wasrt", "siu", "unauthorized", "long-distance", "romanian", "melbourne", "flanders", "connors", "drinker", "hedley", "wyoming", "hotshot", "joaquin", "myrtle", "europeans", "deputies", "ther", "highlights", "musashi", "cate", "plateau", "remy", "set-up", "sordid", "placement", "we-we", "quota", "he`s", "adjusted", "tuning", "rockefeller", "bartlett", "hormone", "apparatus", "gringo", "vancouver", "samaritan", "curves", "perceived", "catalogue", "gall", "luckiest", "escobar", "vending", "thelma", "greeted", "scoring", "housewives", "beverage", "fellowship", "thieving", "have-", "tidal", "genre", "unfit", "fetus", "lanes", "socialism", "outlaws", "entrust", "rosalie", "oversight", "reflex", "vacate", "goldberg", "mercenaries", "exercising", "bev", "prosperous", "symptom", "certificates", "larsen", "suffocate", "roadblock", "detain", "inquisition", "qualifications", "paparazzi", "eater", "prefect", "flapping", "discrimination", "incorporated", "callahan", "strengths", "rowdy", "productions", "publication", "collects", "winslow", "hodges", "astronomers", "prevents", "museums", "windsor", "nebraska", "lobe", "poses", "inscription", "left-handed", "outpost", "snuff", "luxurious", "contributions", "purgatory", "documented", "showcase", "delilah", "jurors", "unimportant", "moisture", "lefty", "hendrix", "replica", "wondrous", "horoscope", "hampshire", "esteban", "departing", "instruct", "morbid", "disagreement", "misguided", "optimism", "traders", "humane", "commodore", "rink", "initiation", "calamity", "nectar", "operatives", "judicial", "callin", "swarm", "drumming", "80ffff", "shithole", "annabelle", "spartacus", "trolley", "theorists", "rowan", "bowels", "density", "iong", "researcher", "timid", "meself", "garth", "denton", "romania", "earnings", "stalk", "righteousness", "fours", "kel", "slaps", "confide", "bravest", "fencing", "laurence", "masturbate", "vale", "triggers", "wiener", "painless", "believers", "eruption", "obligated", "mojo", "essex", "eternally", "dispatched", "repulsive", "ness", "devised", "headlights", "exiled", "impeccable", "oome", "donors", "crucified", "customary", "billboard", "costly", "imitate", "definitive", "simplicity", "waved", "pavel", "scolded", "separates", "carr", "nichols", "kommandant", "setback", "lakh", "liters", "relics", "clockwork", "cdc", "ventilation", "civilizations", "brawl", "bog", "pressures", "chills", "tex", "pussies", "phrases", "gob", "pricks", "jars", "rivera", "disable", "lancaster", "godfrey", "pickled", "novelty", "equations", "doubtful", "sexist", "capone", "buffer", "castles", "reproduce", "goodwin", "blueberry", "ryu", "mm-mmm", "oskar", "flo", "potty", "algeria", "geometry", "dumbest", "bahamas", "bleating", "horizontal", "assisted", "indebted", "spook", "fertilizer", "techno", "hinges", "zhu", "helium", "imposed", "financing", "restrictions"];

  // src/generated/known-zh_cn.json
  var known_zh_cn_default = ["的", "我", "你", "了", "是", "在", "他", "我们", "不", "吗", "好", "什么", "有", "就", "吧", "她", "这", "知道", "说", "都", "去", "很", "啊", "要", "也", "他们", "和", "那", "想", "人", "会", "一个", "来", "把", "对", "没有", "做", "不是", "让", "给", "you", "可以", "i", "你们", "呢", "但", "l", "到", "还", "现在", "the", "这个", "能", "怎么", "就是", "跟", "如果", "没", "它", "走", "上", "得", "被", "这里", "这样", "个", "看", "事", "to", "自己", "着", "谁", "过", "不会", "a", "告诉", "s", "为什么", "不能", "真的", "m", "先生", "只是", "不要", "这是", "已经", "再", "哦", "需要", "it", "因为", "谢谢", "像", "这么", "可能", "但是", "那个", "所以", "喜欢", "又", "叫", "快", "我要", "觉得", "别", "听", "找", "里", "还有", "时候", "东西", "等", "死", "多", "从", "我会", "一起", "and", "应该", "我們", "这些", "that", "t", "请", "孩子", "看到", "一下", "那么", "为", "嗎", "而", "of", "您", "才", "用", "还是", "嗯", "问题", "工作", "一样", "呀", "开始", "吃", "嘿", "当", "真", "中", "然后", "看看", "說", "地方", "一定", "将", "希望", "朋友", "今天", "拿", "一", "啦", "in", "事情", "一直", "所有", "we", "找到", "什麼", "哪", "当然", "们", "回来", "不想", "更", "最", "帮", "is", "没事", "只", "那些", "可", "明白", "的话", "爸爸", "what", "下", "太", "离开", "一切", "时间", "相信", "chffffff", "妈妈", "想要", "爱", "发生", "打", "点", "來", "钱", "大", "起来", "me", "真是", "你好", "抱歉", "必须", "认为", "一点", "非常", "那里", "对不起", "天", "也许", "大家", "哪里", "有人", "该", "意思", "杀", "准备", "并", "出来", "this", "与", "时", "不过", "一些", "为了", "带", "女人", "he", "pos", "这儿", "后", "只有", "过来", "比", "一次", "得到", "и", "很多", "on", "任何", "这种", "for", "小", "怎么样", "對", "感觉", "年", "是不是", "以为", "fn", "而且", "my", "your", "前", "生活", "男人", "之前", "喂", "问", "发现", "噢", "可是", "快点", "嗨", "妈", "两个", "不用", "re", "地", "向", "名字", "have", "没错", "was", "no", "见", "do", "世界", "沒", "记得", "住", "新", "be", "不错", "肯定", "最好", "not", "不行", "等等", "嘛", "出去", "么", "先", "為", "亲爱", "或", "can", "are", "don", "他們", "担心", "如何", "到底", "有点", "最后", "小姐", "上帝", "认识", "know", "會", "正在", "那样", "父亲", "高兴", "明天", "重要", "跑", "警察", "只要", "干什么", "好像", "再见", "月", "我能", "继续", "出", "今晚", "all", "他妈的", "with", "回家", "它们", "多少", "电话", "听到", "干嘛", "just", "干", "but", "医生", "要是", "女孩", "so", "這", "所", "讓", "马上", "过去", "以前", "they", "儿子", "哪儿", "说话", "买", "看起来", "fnmicrosoft", "一個", "yahei", "完全", "该死", "there", "美国", "怎样", "回去", "以", "却", "其他", "永远", "家伙", "之后", "怎麼", "看见", "或者", "b", "小心", "fnsimhei", "行", "别人", "成为", "写", "不到", "here", "情况", "get", "送", "伙计", "一天", "玩", "见到", "放", "晚上", "喝", "总是", "好好", "琌", "号", "如此", "家", "坐", "了解", "like", "有没有", "兄弟", "没什么", "我来", "结束", "机会", "已", "安全", "拜托", "决定", "穿", "确定", "里面", "呃", "怎么办", "还好", "无法", "小时", "站", "清楚", "有些", "错", "這個", "帮助", "长官", "out", "ll", "公司", "up", "打电话", "房子", "根本", "懂", "办法", "go", "不管", "混蛋", "关于", "right", "she", "搞", "计划", "唯一", "来说", "女儿", "one", "看着", "宝贝", "每个", "about", "怎么回事", "個", "其实", "漂亮", "黑体", "這樣", "车", "if", "人们", "真正", "甚至", "那边", "弄", "开", "不好", "him", "喔", "回", "进来", "裏", "夫人", "之", "at", "ぃ", "愿意", "麻烦", "now", "睡", "哇", "就要", "打算", "完", "故事", "一种", "害怕", "救", "手", "房间", "由", "後", "那儿", "衣服", "枪", "母亲", "got", "另", "下来", "听说", "不了", "注意", "改变", "how", "这次", "這是", "没关系", "接受", "妻子", "老", "失去", "回到", "們", "以后", "话", "是否", "her", "疯", "生命", "她们", "忙", "进去", "抓", "女士", "yeah", "原因", "刚才", "保护", "是因为", "选择", "妳", "几个", "笑", "关系", "从来", "will", "他会", "当时", "出现", "结婚", "些", "至少", "还要", "oh", "挺", "成功", "come", "奇怪", "虽然", "忘", "太好了", "身上", "或许", "讲", "你們", "岁", "有个", "保证", "外面", "ve", "丈夫", "连", "want", "国家", "整个", "特别", "那种", "不同", "著", "很快", "变成", "够", "难道", "学校", "一件", "样子", "倒", "电影", "谈谈", "think", "危险", "开心", "别的", "这件", "才能", "闭嘴", "正", "进行", "照片", "話", "刚刚", "而已", "完成", "誰", "ﺎ", "方式", "from", "做到", "爸", "who", "因為", "声音", "第一次", "看来", "只能", "現在", "太太", "下去", "绝对", "处理", "欢迎", "眼睛", "通过", "行动", "啥", "感到", "最近", "聽", "as", "d", "各位", "这边", "待", "掉", "did", "不好意思", "猜", "使", "作为", "于", "see", "good", "狗", "容易", "沒有", "直到", "求", "比赛", "像是", "his", "麽", "let", "從", "拉", "拍", "更好", "曾", "why", "有趣", "就算", "活着", "不會", "ﻟ", "努力", "帮忙", "留下", "同意", "参加", "well", "赢", "死亡", "每", "上面", "结果", "消息", "要求", "理解", "曾经", "打开", "收到", "照顾", "人类", "主意", "保持", "okay", "成", "杰克", "存在", "进", "高", "晚安", "确实", "全部", "靠", "呆", "起", "謝謝", "讨厌", "gonna", "俩", "an", "硂", "突然", "多久", "老婆", "不再", "when", "back", "任何人", "开玩笑", "放在", "τ", "那個", "进入", "父母", "总统", "伤害", "時候", "回答", "一位", "三个", "所有人", "老师", "早", "除了", "black", "派", "咱们", "自由", "可爱", "us", "日", "抓住", "路", "谈", "简单", "time", "身体", "想法", "早上", "這麼", "ﺍ", "能够", "昨晚", "哥哥", "我爱你", "跳", "them", "秘密", "休息", "战争", "其中", "内", "医院", "每天", "之间", "大概", "控制", "刚", "小孩", "带来", "停止", "因此", "花", "证明", "约翰", "飞机", "替", "解释", "律师", "终于", "耶", "翻译", "调查", "告訴", "为何", "留在", "糟糕", "任务", "武器", "家里", "头", "来自", "后面", "小子", "going", "来到", "解决", "would", "其他人", "家人", "坐下", "where", "怕", "直接", "办公室", "停", "放弃", "鬼", "別", "加油", "方法", "游戏", "即使", "fnarial", "take", "were", "本", "our", "年轻", "大人", "使用", "or", "卖", "老板", "水", "想想", "坐在", "目标", "need", "变得", "可怕", "拿到", "考虑", "个人", "开枪", "哭", "been", "睡觉", "請", "分钟", "想到", "等待", "音乐", "再说", "聪明", "yes", "姑娘", "地球", "感谢", "命令", "阻止", "一只", "消失", "喜歡", "心", "第", "冷静", "似乎", "联系", "家庭", "痛苦", "城市", "力量", "对于", "未来", "男孩", "三", "博士", "姐姐", "疯狂", "报告", "放下", "昨天", "那天", "還有", "完美", "答应", "证据", "本来", "负责", "检查", "could", "見", "已經", "一条", "man", "look", "厉害", "拥有", "正常", "并且", "否则", "該", "then", "以及", "重新", "忘记", "had", "这位", "研究", "附近", "不然", "太棒了", "很棒", "方正", "字幕", "脸", "者", "加入", "於", "唱", "反正", "不该", "政府", "快乐", "身边", "down", "遇到", "some", "這裡", "伟大", "咖啡", "tell", "say", "接", "仍然", "门", "开车", "代表", "陪", "若", "尸体", "比较", "一年", "紧张", "监狱", "way", "位置", "随便", "偷", "安排", "錢", "表演", "从没", "除非", "屁股", "這些", "by", "酒", "恩", "老兄", "支持", "必要", "人生", "正确", "跟着", "杀死", "more", "交给", "叔叔", "還是", "食物", "事实", "简直", "安静", "离", "一场", "妹妹", "something", "斯", "美丽", "再次", "案子", "下面", "hey", "make", "不够", "哈", "可怜", "教", "殺", "首先", "另外", "提供", "记住", "听见", "信", "国王", "didn", "面前", "几乎", "日子", "那麼", "舒服", "原来", "再也", "操", "纽约", "早就", "逼", "really", "有关", "放开", "信息", "r", "星期", "never", "不得不", "发誓", "钥匙", "错误", "放松", "约会", "船", "打扰", "女", "手机", "二", "很大", "到处", "攻击", "一份", "第一", "建议", "日本", "理由", "事实上", "一樣", "阿", "跳舞", "生气", "久", "试试", "信任", "此", "看过", "差不多", "原谅", "has", "神", "经常", "的确", "ㄓ", "之一", "幸福", "哎", "便", "马", "算", "吃饭", "璶", "正是", "不必", "最大", "people", "幸运", "丢", "我家", "問題", "长", "東西", "而是", "住手", "动物", "弟弟", "道歉", "严重", "人家", "坚持", "想象", "按", "礼物", "每次", "将军", "ok", "剩下", "有事", "老爸", "幫", "系统", "全都", "组织", "我會", "敌人", "看上去", "應該", "老天", "ê", "认真", "分", "书", "往", "关心", "坏", "骗", "中国", "生意", "上去", "值得", "搞定", "寻找", "派对", "pro", "许多", "学生", "查理", "下次", "通知", "救命", "表现", "利用", "受伤", "后来", "早上好", "精神", "居然", "受到", "am", "大学", "那时", "既然", "几天", "有时", "米", "总", "一张", "too", "第一个", "真相", "恨", "卡", "不知", "远", "警官", "love", "属于", "fncronos", "over", "什", "い", "可不是", "怪", "一名", "怀疑", "笨蛋", "战斗", "承认", "馬", "法律", "别说", "简体", "记录", "见面", "能力", "足够", "帶", "瞧", "同样", "白痴", "拒绝", "影响", "画", "其", "德", "交易", "回來", "别动", "管", "开门", "意味着", "或是", "美", "教授", "享受", "時間", "喝酒", "好多", "接下来", "開始", "腿", "only", "走开", "合作", "女朋友", "好吃", "事件", "出发", "酒吧", "多么", "不如", "指", "客人", "换", "梦想", "英雄", "傻", "血", "扔", "藏", "little", "杀人", "一会儿", "沒事", "变", "约", "行为", "头发", "适合", "穦", "恭喜", "上次", "地狱", "不在乎", "生", "哪个", "实在", "路上", "接近", "不准", "银行", "碰", "介绍", "一旦", "味道", "实际上", "感受", "身份", "off", "意外", "一般", "吓", "停下", "意义", "拜", "来看", "婊子", "梦", "学习", "同时", "不起", "呼吸", "是从", "经历", "凶手", "目前", "威胁", "没法", "有时候", "should", "英国", "男", "什么样", "老大", "受", "愚蠢", "算了", "真实", "sorry", "婚礼", "在家", "允许", "because", "军队", "said", "电视", "please", "一家", "灵魂", "谢", "如", "道", "究竟", "戴", "无论", "谋杀", "立刻", "特", "躺", "试图", "客气", "文件", "give", "敢", "慢慢", "ﻴ", "前面", "奶奶", "黑", "sir", "答案", "棒", "新闻", "多谢", "可不", "ぐ", "very", "長", "any", "欠", "一遍", "达", "权利", "做出", "历史", "挂", "two", "好了吗", "意识", "追", "下午", "尝试", "乔治", "经过", "获得", "仍", "饿", "ﺃ", "部分", "活", "當然", "队", "带走", "竟然", "ﺮ", "失败", "一生", "黑暗", "中心", "麦克", "警告", "大哥", "显然", "碞", "根据", "动", "不過", "自杀", "subhead", "这事", "训练", "万", "thing", "令人", "ﻣ", "难", "街", "越", "搬", "好人", "少", "迟到", "mean", "恐怕", "一杯", "病", "没用", "thank", "讨论", "爆炸", "因", "美好", "放心", "长大", "微软", "令", "没人", "辛苦", "尽管", "美元", "their", "吻", "help", "收拾", "包括", "弗兰克", "面对", "跟我来", "公寓", "雅黑", "邀请", "求求", "生日", "留", "法官", "方向", "一块", "法国", "一半", "借", "find", "确认", "玩笑", "doing", "躲", "金", "病人", "目的", "公主", "mr", "even", "一会", "我刚", "sure", "these", "最终", "士兵", "怎", "其它", "反对", "傻瓜", "into", "晚", "拿走", "那家伙", "对方", "警方", "假", "次", "不介意", "赶快", "失望", "无", "出生", "酒店", "德国", "上班", "uh", "覺得", "要说", "造成", "破坏", "到达", "间", "巴黎", "药", "不见", "冷", "男朋友", "想起", "老公", "教堂", "起來", "做好", "盾", "就行了", "拯救", "still", "祝", "字", "媽媽", "一句", "幹", "子弹", "节目", "飞", "玛丽", "方面", "life", "不敢相信", "安娜", "晚餐", "不让", "越来越", "巨大", "很漂亮", "伦敦", "啤酒", "好看", "感情", "自然", "汤姆", "day", "一把", "一步", "逮捕", "超过", "時", "赶紧", "much", "炸弹", "全", "将会", "god", "主人", "可惜", "算是", "上校", "家族", "猫", "哥们", "恶心", "陛下", "从未", "球", "彼得", "通常", "名", "只会", "撒谎", "兴趣", "旅行", "吹", "雷", "没想到", "比如", "人民", "穿着", "干净", "不少", "回事", "提", "滚", "克", "用来", "队长", "公平", "愉快", "不幸", "ﻳ", "选", "好不好", "new", "电脑", "火车", "有意思", "乔", "抱", "干得", "o", "说得对", "ﻧ", "ﺪ", "爱情", "还给", "加", "校对", "一边", "宇宙", "请问", "一點", "死去", "心情", "撞", "明显", "h", "不敢", "找个", "现场", "一部分", "ﻨ", "失踪", "未", "毁", "垃圾", "十分", "愛", "相当", "の", "這兒", "before", "regular", "than", "鱼", "接着", "不可", "同", "健康", "提醒", "包", "测试", "maybe", "随时", "事儿", "遗憾", "犯罪", "治疗", "狗屎", "這種", "命", "c", "太阳", "你别", "习惯", "night", "大卫", "last", "怪物", "靠近", "反应", "某个", "意见", "蛋糕", "时刻", "于是", "床上", "责任", "充满", "热", "多年", "楷体", "亨利", "心里", "说谎", "自", "work", "见鬼", "份", "干吗", "脚", "祈祷", "疯子", "差点", "fndidactic", "我该", "好极了", "说真的", "ﻮ", "活动", "stop", "块", "对付", "命运", "醫生", "查", "罗马", "發生", "同志", "臭", "必須", "照", "服务", "call", "糟", "anything", "尊重", "关闭", "準備", "first", "期待", "号码", "again", "资料", "て", "机器", "读", "盯", "关", "办", "天使", "去过", "难过", "快點", "记忆", "女士们", "過來", "线索", "nothing", "正好", "秒", "表示", "脑袋", "爷爷", "探员", "移动", "错过", "旁边", "留下来", "彼此", "社会", "好事", "跟踪", "唔", "keep", "尼克", "疼", "弧", "及", "不断", "た", "away", "私人", "嘴", "上床", "好玩", "神父", "周围", "就让", "put", "自从", "叫做", "主要", "这场", "创造", "无聊", "作品", "制作", "干杯", "保罗", "装", "第二", "四个", "法庭", "设计", "干掉", "稱", "这点", "压力", "轻松", "those", "other", "哥", "上车", "说明", "谈论", "與", "超级", "停下来", "抢", "区", "要么", "两", "速度", "有钱", "确保", "詹姆斯", "手上", "周末", "long", "没见", "警长", "袭击", "感覺", "主", "won", "刀", "咬", "上来", "尤其", "你家", "船长", "浪费", "怎麼樣", "怀孕", "婚姻", "talk", "die", "副", "信号", "天堂", "恐怖", "角色", "心脏", "恐惧", "赚", "n", "很难", "去世", "性感", "记者", "笵", "離開", "嘘", "客户", "由于", "thought", "庆祝", "嫁给", "总之", "惊喜", "土地", "更加", "四", "出來", "安", "处", "会议", "女性", "技术", "送到", "年轻人", "官", "地址", "困难", "惹", "件", "在乎", "和平", "制造", "离婚", "認為", "那好", "似的", "sam", "非常感谢", "同学", "请求", "看不到", "常", "动作", "不停", "今年", "must", "歌", "演出", "参与", "艾", "逃跑", "一点点", "香港", "汽车", "杀手", "ever", "after", "提到", "兴奋", "丹尼", "剩", "毒品", "史", "踢", "home", "分手", "问问", "做爱", "马克", "一群", "好处", "宝宝", "森林", "赢得", "生存", "厕所", "things", "な", "荣幸", "报警", "地上", "wait", "送给", "e", "喝一杯", "世上", "想念", "这会", "大约", "可恶", "合适", "普通", "天才", "生物", "之中", "肉", "妓女", "尽快", "报纸", "俱乐部", "提出", "正式", "洗", "政治", "从不", "一辈子", "取消", "两年", "world", "监视", "产生", "犹太人", "玩意", "班", "搞砸", "只不过", "显示", "价值", "带到", "吉姆", "恶魔", "一周", "told", "状况", "那位", "辦", "name", "作", "guy", "建立", "山姆", "高中", "娶", "ﻲ", "说实话", "去年", "厨房", "特殊", "黑人", "邪恶", "勇敢", "j", "不算", "石头", "等到", "does", "假装", "better", "运动", "介意", "转", "兩個", "手下", "两天", "摆", "印度", "耶稣", "手指", "思考", "累", "沒錯", "机场", "茶", "地点", "恢复", "夜晚", "帽子", "执行", "比尔", "输", "时代", "状态", "years", "餐厅", "人会", "ﻠ", "呵呵", "ﺘ", "意大利", "犯", "背叛", "everything", "魔鬼", "情报", "great", "人员", "专家", "那樣", "了不起", "店", "不怕", "骄傲", "哎呀", "差", "唱歌", "学", "站住", "眔", "之类", "满足", "所说", "吉米", "も", "停车", "现实", "牺牲", "胜利", "好消息", "见过", "条", "引起", "醒来", "猪", "一辆", "下车", "不许", "颜色", "有用", "暂时", "sans", "投票", "证人", "想像", "鸟", "全世界", "around", "買", "迈克", "拍摄", "冒险", "place", "部队", "王子", "ﻫ", "发展", "顺利", "甜心", "谈话", "開", "不去", "吸血鬼", "筁", "张", "ﻤ", "吸引", "还会", "字幕组", "动手", "老实", "比利", "它会", "一段", "激动", "条件", "白", "doesn", "特工", "爬", "always", "光", "五", "早餐", "追踪", "發現", "废话", "演员", "哼", "亲自", "一个月", "所谓", "听听", "复杂", "é", "学会", "距离", "同性恋", "係", "外", "发", "这份", "好笑", "碰到", "受不了", "醒醒", "做些", "成员", "想着", "绑架", "即将", "发射", "抽", "威尔", "真是太", "痛", "魔法", "through", "every", "这才", "莎拉", "把手", "分享", "ㄆ", "我覺", "年前", "ü", "冲", "然而", "感激", "同事", "收", "神秘", "made", "上尉", "面", "搭", "feel", "fnfzhei", "难以置信", "迈克尔", "哈利", "车里", "傢", "桌子", "someone", "禁止", "一段时间", "交流", "带上", "放手", "临", "英里", "几年", "old", "安妮", "公园", "fuck", "边", "别管", "克里斯", "非", "done", "早安", "中间", "癸", "整天", "我想", "shit", "巧克力", "找出", "强大", "受害者", "某些", "后悔", "您好", "一分钟", "精彩", "有點", "卡尔", "睡着", "果然", "人人", "基地", "两位", "一片", "时间轴", "guys", "单独", "名单", "病毒", "may", "过程", "急", "左右", "生病", "种", "人物", "尿", "戒指", "自我", "立即", "女生", "星球", "变化", "卡车", "怎樣", "空间", "穿过", "象", "旅馆", "打死", "观众", "依然", "kill", "做事", "三年", "ﺑ", "他来", "火", "乐队", "飞行", "接到", "る", "两次", "导演", "满意", "認識", "导致", "要死", "which", "接触", "折磨", "骗子", "明星", "经验", "小伙子", "ﺗ", "前进", "西", "美女", "一部", "性", "至", "好运", "尽力", "ich", "密码", "赌", "刺激", "以来", "承诺", "艺术", "子", "耍", "让开", "烧", "明明", "惊讶", "免费", "案件", "女孩子", "天呐", "惩罚", "释放", "吵", "位", "顺便", "无辜", "老鼠", "采取", "believe", "联络", "展示", "无关", "卻", "箱子", "挑战", "讲话", "练习", "点儿", "从来不", "楼上", "擔心", "实现", "脖子", "理论", "关键", "電話", "聚会", "推", "洛杉矶", "方便", "耳朵", "数字", "世纪", "奇迹", "各种", "窗户", "罪犯", "破", "呼叫", "气", "仅仅", "frank", "手术", "leave", "说服", "john", "死定了", "清理", "big", "宣布", "启动", "能量", "分开", "车子", "室", "ネ", "加上", "车上", "fnfangsong", "印象", "天空", "天气", "小时候", "游泳", "拜拜", "滚开", "大部分", "stay", "教练", "に", "哟", "我用", "集", "阿姨", "估计", "科学", "而言", "乐意", "鼻子", "three", "不錯", "地区", "塔", "杀害", "孤独", "声", "拿来", "寫", "喝点", "夏天", "十年", "might", "如今", "某人", "元", "不像", "欧洲", "船上", "ﻋ", "肚子", "大声", "手里", "红色", "婴儿", "旧", "环境", "团队", "神奇", "年纪", "唉", "瞧瞧", "熊", "kind", "年代", "上学", "大量", "快去", "伤心", "何时", "别忘了", "紧急", "布", "暴力", "付出", "尽量", "太多", "伤", "互相", "繼續", "无论如何", "空气", "邻居", "dead", "某种", "想过", "他人", "规则", "我妈", "being", "司机", "好奇", "城", "打破", "coming", "信仰", "ﻌ", "不可思议", "ﺔ", "付", "baby", "持续", "逃", "朝", "无所谓", "协议", "父親", "假如", "阁下", "愿", "打赌", "城堡", "退后", "说不定", "菜", "彻底", "地图", "牧师", "墨西哥", "词", "重复", "犯人", "我爸", "妓", "运气", "不太", "华文", "早晨", "girl", "幹什麼", "house", "fntahoma", "一对", "hell", "小孩子", "money", "相同", "isn", "裤子", "聊", "规矩", "到来", "真棒", "逃走", "近", "程序", "发出", "趴下", "白人", "本书", "中尉", "不肯", "街上", "託", "揍", "度", "給我", "own", "伙", "打架", "这太", "ﻭ", "lot", "女王", "錯", "救救", "三天", "尽", "午餐", "则", "看法", "喝醉", "一支", "enough", "权力", "也好", "留言", "床", "脸上", "摧毁", "全是", "故意", "山", "罗", "打败", "哪裡", "hello", "背后", "人来", "远离", "狼", "毕竟", "警探", "洗澡", "bad", "黑色", "痷", "便宜", "大多数", "伪", "行李", "别碰", "毫无", "线", "一人", "蓝色", "浪漫", "亲", "起床", "很少", "大脑", "师父", "殿下", "指控", "道理", "擦", "尖叫", "爵士", "冠军", "场", "按照", "hear", "重点", "教育", "知不知道", "一堆", "前往", "对待", "another", "空", "进展", "醒", "有所", "ﻦ", "大叔", "仔细", "半", "票", "娜", "祝你好运", "护士", "一颗", "既", "罗斯", "摸", "战士", "太空", "申请", "happened", "太久", "勇气", "万岁", "组", "重", "left", "委员会", "强", "付钱", "面包", "不仅", "ﻘ", "关注", "不久", "看不见", "万一", "熟悉", "正如", "笑话", "法", "k", "咯", "经典", "一间", "fucking", "凭", "fine", "remember", "wrong", "抛弃", "时光", "实验室", "掌握", "英语", "在意", "管理", "干活", "洞", "范围", "李", "低", "集中", "遇见", "懂吗", "做点", "右", "说出", "艾伦", "报道", "最高", "之外", "哪兒", "表情", "警局", "用力", "ﻥ", "found", "谎言", "回忆", "传统", "放到", "move", "都行", "海洋", "椅子", "欣赏", "五分钟", "舞会", "搜查", "wanted", "快要", "小女孩", "退出", "看吧", "事业", "头上", "机器人", "绝不", "max", "talking", "专业", "作用", "完毕", "王", "增加", "不太好", "隐藏", "诅咒", "随", "一面", "思想", "项目", "cause", "杂志", "再見", "达到", "关掉", "罢了", "father", "不吃", "部门", "联邦", "坏人", "职业", "剑", "观察", "格", "毕业", "扂", "阳光", "白色", "岛", "吐", "想见", "有效", "做过", "实验", "course", "same", "親愛的", "心中", "忍受", "对此", "圣诞节", "nice", "罗伯特", "试着", "作家", "罪", "出口", "感兴趣", "f", "区域", "主演", "else", "愤怒", "抽烟", "凯特", "著名", "渴望", "乱", "内心", "小组", "挖", "understand", "将来", "信心", "を", "michael", "事故", "next", "fbi", "玩具", "对手", "带你去", "抢劫", "华盛顿", "现金", "摆脱", "海", "变态", "在场", "锁", "这座", "细节", "抱怨", "部", "陌生人", "秨", "为此", "many", "毛", "独自", "红", "档案", "一套", "优秀", "喊", "美妙", "血液", "数据", "内容", "大师", "这张", "随着", "混乱", "聊天", "乖乖", "走路", "马丁", "需", "早点", "伙伴", "し", "有空", "came", "指挥", "态度", "hi", "左", "几次", "show", "牛", "getting", "审判", "媒体", "这有", "保安", "教会", "即", "記得", "并非", "工厂", "收集", "背", "每年", "赶", "ask", "射击", "ぱ", "ﻞ", "一根", "过得", "损失", "帮帮我", "王八蛋", "法官大人", "埋", "杀掉", "这条", "wasn", "鞋子", "事物", "死者", "不止", "拖", "能否", "奴隶", "兒子", "我現", "real", "trying", "被捕", "瞷", "分析", "微笑", "翴", "looking", "jack", "俄罗斯", "情人", "か", "胡说", "市场", "降落", "投降", "定", "交往", "骑", "幻想", "首歌", "盒子", "开火", "那条", "算了吧", "出事", "悲伤", "进攻", "超", "威廉", "谈过", "经济", "聊聊", "宁愿", "try", "鸡", "局", "两人", "那晚", "葬礼", "嫉妒", "芝加哥", "boy", "想干什么", "乖", "绝不会", "英尺", "演", "蟿", "男子", "误会", "这话", "ﺭ", "清醒", "外套", "打个", "不信", "出色", "当心", "失陪", "稍微", "走进", "進來", "毁灭", "回头", "thanks", "五个", "工人", "举行", "度过", "类似", "懂得", "科学家", "支付", "牛奶", "正要", "反", "best", "说好", "mike", "ら", "p", "长得", "搭档", "露西", "坚强", "鞋", "mind", "语言", "感染", "歲", "规定", "农场", "钻石", "六", "ﻓ", "常常", "蛋", "生日快乐", "直升机", "广告", "其實", "州", "表达", "砍", "那裡", "镇", "說過", "總", "沙漠", "car", "ﺒ", "完蛋", "引擎", "口袋", "愿望", "道路", "带我去", "海滩", "文化", "总部", "脑子", "城里", "慰", "风", "黄金", "暗", "说法", "today", "ﺳ", "奥", "み", "耐心", "去死吧", "课", "放过", "解雇", "期间", "ﻛ", "伤口", "hold", "脱", "投资", "此事", "树", "描述", "ﺬ", "退休", "长时间", "地下", "克斯", "稍", "く", "情況", "代价", "欺骗", "队伍", "咦", "到时候", "指望", "烂", "视频", "也許", "不来", "踩", "爹", "一座", "选手", "挑", "国际", "留给", "希特勒", "间谍", "真想", "程度", "用于", "尊敬", "保重", "一声", "革命", "搜索", "羅", "教训", "支援", "莫", "盖", "珍妮", "心理", "care", "真不错", "返回", "设备", "制服", "同一个", "っ", "左边", "西班牙", "拿出", "贱人", "糖", "most", "承受", "少校", "決定", "擅长", "復", "千万", "裙子", "listen", "非洲", "基本", "煮", "我來", "女友", "y", "见见", "と", "说完", "传说", "冒", "也就是说", "la", "du", "哈哈", "斯特", "son", "一路", "迷人", "很酷", "だ", "dad", "亚", "非法", "ä", "屋子", "女兒", "搞错", "作战", "他媽", "情绪", "那会", "然", "工具", "手臂", "結束", "皮肤", "真心", "害死", "起诉", "做个", "骂", "五年", "建筑", "together", "head", "多次", "全国", "流血", "混", "指挥官", "合法", "驾驶", "没想", "史蒂夫", "麦", "接电话", "我见", "检察官", "转移", "不管怎样", "相处", "friend", "一切都是", "原本", "um", "共同", "ﻚ", "不要紧", "威士忌", "烟", "妈咪", "ﻜ", "live", "點", "网络", "儿童", "之内", "修", "蛇", "后期", "太晚", "年龄", "楼下", "员工", "科", "尼", "避免", "肯", "吵架", "效果", "歌手", "一刻", "活下去", "砸", "美味", "滚出去", "huh", "saw", "神圣", "运行", "das", "双手", "交", "有着", "那邊", "mother", "還好", "family", "刚好", "撤退", "miss", "托尼", "赚钱", "聽著", "地面", "男生", "七", "處", "whole", "最佳", "出门", "想来", "尴尬", "当成", "手中", "等一等", "假设", "鲍勃", "莎", "男友", "seen", "艰难", "公开", "我怕", "布朗", "大事", "全球", "这么久", "蔚", "那次", "men", "装置", "签名", "外星人", "商店", "沒什麼", "部落", "dna", "反抗", "第二次", "克莱尔", "琵", "联盟", "р", "硬", "蠢", "乐趣", "稳定", "姐妹", "恋爱", "屎", "经理", "掩护", "取得", "女子", "玻璃", "眼前", "身", "惊人", "师傅", "ﺴ", "機會", "猴子", "害", "went", "陷入", "高興", "yourself", "良好", "打击", "药物", "内部", "指示", "亚当", "打扮", "大街", "過去", "よ", "杯", "尔", "礼貌", "第三", "德国人", "は", "run", "诶", "peter", "dean", "保险", "走出", "wouldn", "地下室", "各", "小镇", "佬", "最新", "伊", "加州", "大麻", "手段", "更糟", "泰勒", "苏联", "killed", "你们好", "everyone", "knew", "警察局", "偷走", "风险", "取", "星星", "主席", "jane", "酷", "david", "一趟", "趁", "wanna", "without", "妮", "没人会", "关门", "话题", "改", "片名", "型", "morning", "下班", "区别", "议员", "丢下", "整理", "时期", "老人", "楼", "眼神", "电梯", "小说", "ready", "签", "新娘", "仪式", "魅力", "领导", "处于", "公里", "大楼", "g", "爱人", "形成", "右边", "称为", "礼拜", "sheldon", "为止", "圣", "称", "发明", "辦法", "老妈", "ﺣ", "儿", "几分钟", "already", "小家伙", "独立", "確定", "确信", "指纹", "坐牢", "job", "打来", "兔子", "至于", "地板", "额", "卡特", "期望", "好孩子", "海军", "对象", "凯文", "追求", "东京", "镜头", "平常", "交换", "一整天", "hard", "肮脏", "end", "监控", "で", "这辈子", "甩", "救护车", "一口", "采访", "角度", "部长", "做梦", "woman", "咱", "商量", "gone", "happy", "快速", "x", "回家吧", "open", "财产", "很长", "森", "只好", "饼干", "無法", "舞台", "名叫", "几点", "pretty", "房", "舞", "有罪", "浪费时间", "丹", "灯", "瑞克", "同一", "保佑", "对抗", "性命", "used", "强奸", "试试看", "饮料", "癬", "成熟", "人质", "浴室", "idea", "陷阱", "took", "荣誉", "当中", "once", "一本", "敬", "笨", "具有", "射", "类型", "顿", "在于", "本人", "room", "空中", "咋", "小偷", "牌", "隻", "归", "白天", "下雨", "姓", "正义", "可笑", "式", "還", "当地", "今日", "艺术家", "joe", "情", "托", "heard", "called", "货", "中央", "观点", "贾", "ま", "侦探", "卧室", "袋子", "风格", "修好", "资格", "宗教", "今早", "老朋友", "某", "之下", "起飞", "判断", "guess", "荒谬", "尼斯", "俄国", "圣经", "保留", "汤米", "gotta", "е", "祝福", "毛病", "知", "受够了", "就行", "大不了", "绳子", "借口", "维持", "寂寞", "女巫", "bring", "泡", "use", "超人", "后果", "我试", "总会", "绑", "饭", "罗杰", "槍", "开口", "慢点", "说些", "軍", "帝国", "竞选", "表明", "市长", "提起", "门口", "屋里", "将要", "美國", "一项", "古老", "ﾇ", "功夫", "温柔", "想不到", "战场", "回报", "结局", "抓到", "gbk", "支票", "座位", "不仅仅", "投", "face", "actually", "情感", "有种", "start", "雖然", "卫星", "提前", "下降", "建造", "大海", "柏林", "搞笑", "协助", "ist", "吃掉", "中士", "れ", "短", "下周", "我本", "一架", "哪来", "修女", "这部", "夫妇", "吸", "证实", "致命", "新鲜", "疾病", "温暖", "苹果", "连接", "当初", "月亮", "保密", "平静", "可能性", "骑士", "fnfzzongyi", "基本上", "ain", "整晚", "演奏", "days", "anyone", "四处", "while", "歡迎", "一瓶", "玩意儿", "出卖", "针对", "lost", "both", "成长", "蠢货", "老头", "本身", "king", "james", "每個", "不愿", "就是说", "理想", "yet", "适应", "噩梦", "棒极了", "瞎", "牙齿", "宋体", "烤", "自豪", "天天", "繫", "第二天", "提议", "念", "重大", "托马斯", "走运", "三明治", "進去", "消灭", "卡拉", "忠诚", "应付", "屋顶", "试", "當時", "基", "ah", "敲", "第二个", "钱包", "这样的话", "查尔斯", "few", "de", "文章", "mom", "理查德", "养", "飞船", "saying", "尼尔", "迷路", "这片", "注意力", "那種", "上课", "有什麼", "圣诞", "不安", "偶尔", "关上", "相反", "hand", "塞", "自信", "臭小子", "丁", "这下", "挡", "乘客", "请原谅", "费", "炒", "大臣", "植物", "這次", "飞行员", "我敢", "皇后", "春天", "香槟", "撒", "录像", "智慧", "heart", "克拉克", "祝贺", "夢", "诚实", "强烈", "皮", "tom", "坦白", "杰西", "歌曲", "深", "小鬼", "看好", "成為", "ㄛ", "我俩", "全身", "解开", "崩溃", "爱丽丝", "und", "向前", "有权", "午饭", "毁掉", "出租车", "丹尼尔", "善良", "莉", "冬天", "散步", "欧", "屁", "网站", "う", "标准", "报", "这句", "闻到", "turn", "别闹", "敏感", "脱掉", "ㄇ", "辞职", "投入", "交谈", "leonard", "安慰", "欺负", "绿色", "坏事", "還在", "そ", "還要", "飯", "until", "走走", "走廊", "小小的", "沙发", "龙", "拥抱", "慢", "結婚", "同情", "楼梯", "争取", "机构", "提高", "奇", "中情局", "brother", "产品", "完整", "周", "当作", "男性", "杂种", "淘汰", "拍照", "花园", "热情", "雇", "ﻢ", "企业", "ǐ", "斕", "壞", "打断", "谢谢你们", "跟上", "事要", "菲尔", "玫瑰", "寄", "从前", "叛徒", "ノ", "隐瞒", "舞蹈", "段", "磅", "明早", "皮特", "布莱恩", "雪", "一顿", "很久以前", "晓得", "烦", "倆", "以上", "杰瑞", "が", "尝尝", "自私", "天赋", "批准", "炸", "局长", "八", "校长", "莫斯科", "姆", "感謝", "嘲笑", "波", "囚犯", "被告", "配合", "认得", "开除", "watch", "打仗", "少女", "翻", "三次", "阿门", "ﻬ", "岛上", "仅", "倒霉", "发表", "眼镜", "き", "甚么", "封信", "ﺤ", "坦克", "high", "激情", "餐馆", "tonight", "骗人", "复仇", "洗手间", "海伦", "神经", "如同", "统治", "第一天", "影片", "职责", "ago", "商业", "何不", "衬衫", "午夜", "一眼", "迪", "胳膊", "癌症", "学到", "year", "考试", "保存", "邮件", "它們", "matter", "老子", "遵守", "ó", "切", "文明", "那兒", "军人", "同伴", "带给", "要不然", "打倒", "集团", "舰长", "合同", "片", "玛", "绝望", "墙", "鸡蛋", "法语", "礛", "paul", "couldn", "遭到", "改變", "艾米", "孤单", "很久", "also", "护照", "隔壁", "逃避", "安迪", "十分钟", "镇上", "树林", "相关", "发动", "迪克", "入侵", "记", "door", "极了", "暴露", "び", "内裤", "纳粹", "haven", "利益", "单身", "自动", "人能", "甜蜜", "报复", "case", "成就", "charlie", "猜猜", "画面", "不得", "卷", "巨人", "since", "扮演", "断", "麻煩", "头脑", "meet", "麼", "报仇", "保姆", "吓坏", "true", "人才", "大门", "巴", "拜访", "好点", "分子", "冒犯", "遭遇", "有过", "幫助", "一向", "瘋", "时机", "such", "陪审团", "会长", "注射", "啰", "ted", "利", "母親", "汤", "作出", "alone", "這邊", "der", "喝杯", "危机", "心灵", "下手", "腔", "five", "ytet", "給", "段时间", "总有一天", "friends", "市", "洛克", "迅速", "史密斯", "雨", "hope", "两周", "death", "古怪", "老是", "一头", "退", "戏", "系", "营地", "冰", "否认", "诗", "有件事", "哪怕", "alex", "冷静下来", "联合", "这家", "扯", "玩得", "唱片", "再来", "part", "遵命", "材料", "旅程", "千万别", "安东尼", "平时", "瞒", "出于", "捉", "六个", "代替", "sie", "ﺟ", "蟽", "占", "薇", "助理", "開心", "度假", "小狗", "店里", "手枪", "problem", "满", "对话", "那件事", "曼", "米奇", "ﻗ", "chinese", "电话号码", "無", "別人", "em", "无线电", "一号", "会见", "镜子", "那就好", "跟我走", "拉斯", "looks", "罪行", "报导", "高度", "街道", "公民", "妇女", "myself", "汉堡", "抵达", "damn", "fight", "ا", "应", "working", "蛤", "日期", "队员", "冰箱", "回应", "狗屁", "顾客", "要不是", "nicht", "丹尼斯", "侮辱", "約", "wants", "演讲", "圈", "野兽", "henry", "很小", "这一", "恐怖分子", "bit", "航班", "上周", "結果", "生产", "凌晨", "装备", "人們", "難道", "弗", "底下", "翅膀", "痕迹", "灾难", "一首", "参议员", "发疯", "剧本", "市民", "具体", "地盘", "天生", "道德", "僵尸", "好久", "钩", "棒球", "上帝保佑", "远点", "一家人", "海盗", "实话", "有何", "快到", "さ", "那有", "符合", "开会", "稍后", "爸妈", "丝", "体内", "违反", "网上", "骨头", "合理", "饭店", "不是故意", "eyes", "菲利普", "幸会", "烦恼", "当年", "广场", "害羞", "但愿", "伯爵", "醉", "据说", "phone", "墙上", "他杀", "前辈", "以外", "有個", "铁路", "種", "地位", "求婚", "般的", "对面", "路易斯", "ben", "高级", "牛仔", "才行", "瞭解", "用不着", "比如说", "says", "w", "不住", "谢天谢地", "不怎么", "法院", "u", "六个月", "肌肉", "惨", "却是", "哈罗", "台", "公众", "敢肯定", "轮到", "插", "刺", "洛", "看來", "舌头", "村子", "背景", "警卫", "秘书", "送来", "车站", "唐", "不对劲", "为啥", "夫", "林", "别想", "呦", "闻", "鬼魂", "本事", "知识", "奶酪", "员", "模特", "肖恩", "形式", "公路", "后退", "心跳", "水平", "包围", "瞄准", "流行", "零", "夺走", "修理", "韩国", "change", "肩膀", "强壮", "半个", "全新", "ゴ", "表面", "一致", "新来", "居民", "联邦调查局", "主任", "布鲁斯", "中午", "皇帝", "得了吧", "選擇", "war", "谓", "残忍", "kid", "厌倦", "可不可以", "爆", "哭泣", "传", "九", "屋", "难以", "賣", "相机", "剛才", "来源", "我給", "play", "波特", "熟", "沒關", "机", "卖掉", "特別", "不论", "手套", "操作", "蒂", "幾個", "神经病", "通话", "悲剧", "嫌犯", "超越", "忘掉", "达成", "傻子", "胖子", "艾迪", "隧道", "绅士", "强迫", "祇", "adam", "访问", "房間", "只想", "面具", "口", "西蒙", "斯科特", "医疗", "困扰", "角落", "each", "蛮", "做生意", "胸部", "单位", "人群", "注定", "学院", "莉莉", "hmm", "形象", "最棒", "penny", "南方", "ﺖ", "point", "這件", "金钱", "法兰克", "专门", "好莱坞", "under", "失控", "艘", "變成", "所知", "技巧", "性交", "深刻", "把门", "转身", "集合", "小丑", "上升", "寻求", "tomorrow", "解除", "一道", "knows", "称呼", "加拿大", "爱上", "爆发", "丽莎", "没人能", "晚饭", "成立", "中圆简", "准确", "逃脱", "掌控", "四年", "落", "被困", "比起", "its", "风暴", "燃烧", "卑鄙", "太大", "一员", "thinking", "参观", "一副", "限制", "り", "穿越", "闭上", "主管", "认出", "內", "萬", "梅", "da", "製", "短信", "sarah", "难受", "星", "模式", "击中", "永不", "欲望", "lady", "check", "给予", "紧", "实际", "喽", "髮", "far", "wife", "胖", "老爷", "问过", "没来", "出現", "桥", "抵抗", "whatever", "一笔", "exactly", "且", "面临", "放进", "码头", "ﻪ", "舰队", "夫妻", "阶段", "明确", "太快", "价格", "信用卡", "理智", "犹太", "一種", "杰夫", "别无选择", "导弹", "球员", "维尔", "保護", "干脆", "喉咙", "赶到", "小朋友", "维", "有意", "凯蒂", "臉", "英文", "军官", "幸好", "资金", "everybody", "你現", "我操", "谈判", "舔", "上午", "捡", "反而", "塔克", "这辆", "哈里", "火箭", "海岸", "可靠", "英国人", "即便", "帅哥", "一台", "好样", "谋杀案", "討厭", "碎片", "至今", "打中", "ㄠ", "黑鬼", "赛", "打電話", "young", "经营", "使命", "架", "另一边", "裡", "一枪", "孙子", "鲨鱼", "police", "通讯", "inside", "一夜", "fnvrinda", "富有", "调整", "进步", "可悲", "看出", "т", "尺", "偷偷", "宝贝儿", "下來", "警报", "废物", "寶貝", "吃惊", "眼", "封锁", "business", "amy", "例如", "稲", "路线", "诺", "案", "领袖", "four", "足以", "行不行", "尽可能", "薄", "老師", "社区", "進行", "砰", "嘴里", "抓紧", "close", "嘴巴", "谢谢您", "扔掉", "轨道", "輕", "影子", "动机", "这人", "埃", "器", "弹", "前来", "爽", "身后", "死刑", "鬆", "醫院", "糖果", "second", "赶上", "呐", "山上", "打扫", "萨姆", "睡不着", "person", "格斯", "助手", "单", "克拉", "选举", "所在", "感动", "萨拉", "comment", "等不及", "拿下", "哪位", "mark", "幫忙", "摄像机", "主题", "来过", "标志", "天上", "我求", "危險", "据", "平安", "懦夫", "玩玩", "ﻔ", "狦", "巴士", "暗示", "比賽", "再有", "探长", "昨天晚上", "油", "不妙", "こ", "走向", "图书馆", "公爵", "ö", "成绩", "两分钟", "reference", "word", "一共", "做得好", "这帮", "行事", "最初", "不成", "好痛", "下令", "造", "薪水", "gun", "查看", "读书", "hit", "可疑", "清除", "soon", "慢慢来", "要来", "转过", "快来", "季", "霍华德", "幽灵", "party", "基因", "岆", "皇上", "大厅", "福", "仓库", "贴", "大小", "makes", "升", "body", "荣耀", "胡扯", "今", "按摩", "气味", "君", "sit", "夜", "小男孩", "給你", "足球", "深呼吸", "守", "行星", "怪兽", "始终", "stand", "deal", "身为", "story", "透露", "杯子", "罪名", "州长", "難", "阿曼", "收回", "膝盖", "danny", "党", "猎人", "受欢迎", "简", "excuse", "姓名", "样", "probably", "异常", "談談", "埃及", "官员", "军事", "hands", "工资", "魔", "新人", "科尔", "从小", "没能", "河", "贝克", "切断", "跪下", "蹤", "轻易", "万美元", "扶", "这项", "伊甸园", "一阵子", "友好", "兒", "明年", "帝", "means", "展开", "北方", "談", "娘", "十", "突破", "狮子", "以下", "震惊", "小姑娘", "宽恕", "摄像头", "serif", "出席", "電影", "严肃", "友谊", "这块", "贼", "表", "搜", "味", "妞", "格雷", "整個", "继承", "推荐", "几周", "社长", "琼斯", "晚点", "奇妙", "车祸", "計劃", "苏珊", "顾问", "别哭", "猭", "承担", "est", "chance", "game", "ma", "预备", "剛剛", "总监", "明", "一小", "吉", "我错", "杀人犯", "看著", "相爱", "丛林", "假期", "播放", "撑", "接吻", "讽", "数", "仅供", "月球", "厨师", "半小时", "v", "沿着", "收入", "得知", "冰淇淋", "事實", "照看", "脆弱", "数量", "沮丧", "总算", "樣子", "意志", "亦", "一团糟", "gave", "每周", "贝尔", "making", "铁", "fnms", "基金", "工程", "fire", "自行车", "咱俩", "仔", "周六", "逃离", "任", "固定", "摇滚", "書", "ǎ", "勒", "食品", "參加", "產", "约定", "坏蛋", "different", "伊拉克", "体验", "业务", "吃晚饭", "岩石", "bill", "武士", "征服", "身材", "查出", "chris", "啊哈", "上司", "考虑一下", "复活", "感冒", "之所以", "相互", "娃娃", "怎能", "小屋", "入口", "精灵", "般", "程", "做法", "冲动", "jake", "聚集", "遭受", "ﻻ", "george", "老虎", "开个", "声明", "人去", "side", "赌场", "图", "荒唐", "cut", "奶油", "政策", "林肯", "值", "残酷", "职位", "注", "包裹", "科技", "坟墓", "基督", "處理", "气氛", "夸张", "搞清楚", "这笔", "出手", "计算", "好久不见", "迷失", "老二", "吓人", "开放", "有名", "患者", "被迫", "free", "性格", "更大", "秀", "民主", "happen", "lord", "mm", "crazy", "崇拜", "全体", "毫无疑问", "或許", "说起", "呗", "一百", "巧合", "闹", "会儿", "使得", "小小", "white", "阿里", "圣诞老人", "taking", "西方", "草", "遇上", "亲吻", "一晚", "ray", "除掉", "平民", "蟺", "一艘", "日记", "纹身", "加速", "西装", "这来", "直", "ms", "玡", "minutes", "school", "沉默", "会面", "小队", "告知", "大道", "け", "原來", "此刻", "祷告", "太迟", "supposed", "身體", "亲密", "白宫", "迹象", "永遠", "会来", "摔", "获取", "位子", "真理", "赶走", "整整", "竒", "首相", "辩护", "标记", "街头", "stuff", "写信", "等候", "ρ", "blood", "祖母", "导师", "美的", "water", "国会", "against", "easy", "桌上", "才刚", "沃尔特", "蓝", "小事", "亲手", "原则", "safe", "beautiful", "位于", "听过", "南", "少年", "博物馆", "學校", "发挥", "策略", "玛利亚", "不爽", "第五", "哪些", "不明", "祖父", "times", "somebody", "燃料", "价钱", "口气", "迟", "bye", "珠宝", "无论是", "mary", "set", "having", "解放", "好听", "今天下午", "尽头", "皇家", "场景", "来不及", "金子", "米勒", "纸", "感谢上帝", "鲍比", "现代", "兵", "家乡", "乔伊", "移民", "light", "好几个", "起码", "小時", "狗娘养", "数学", "猎物", "全力", "贵", "来得", "出名", "shut", "锁定", "火星", "作证", "本该", "依靠", "shot", "team", "仆人", "这么晚", "望", "我先", "机密", "总有", "亲戚", "疼痛", "非得", "大伙", "带回", "丢脸", "medium", "缺乏", "moment", "牛排", "级", "苏格兰", "女神", "國家", "法案", "喝茶", "亚瑟", "蕾", "howard", "ぇ", "咱們", "载", "物质", "优势", "吉他", "trust", "服装", "难怪", "从此", "question", "星期五", "聲音", "哪有", "留着", "打过", "遥远", "jimmy", "听不懂", "fnstkaiti", "好象", "力", "吓死", "jim", "石油", "坏消息", "诞生", "再也不会", "ﺇ", "那小子", "黄", "剪", "粉丝", "蜘蛛", "沒人", "海边", "纪念", "真有", "广播", "default", "英格兰", "平衡", "仿佛", "波士顿", "圣诞快乐", "头儿", "hurt", "详细", "mine", "戴夫", "无意", "查克", "手術", "安德鲁", "本地", "做饭", "费用", "ウ", "half", "不许动", "酱", "凯尔", "上场", "心意", "情形", "姐", "胡说八道", "纳", "手表", "赞成", "光明", "组成", "倒下", "walk", "lily", "欢迎光临", "谋", "es", "fnnoto", "设置", "周五", "芙", "下场", "形容", "等于", "停车场", "kids", "钓鱼", "过夜", "ね", "抬起", "较", "模仿", "他會", "保證", "室友", "地震", "信念", "aren", "竟", "带领", "保守", "ﻰ", "股票", "上路", "阴谋", "立场", "王国", "顶", "嘿嘿", "仁慈", "待会儿", "number", "换个", "贝丝", "没事儿", "探索", "毛巾", "afraid", "处女", "吸毒", "直觉", "相似", "回复", "看見", "及时", "现象", "通道", "解決", "宰", "嫌疑人", "鼓励", "杠", "舒适", "很久没", "激烈", "星期六", "砆", "师", "贷款", "建", "robin", "least", "船员", "炸药", "能行", "企图", "rest", "查查", "竞争", "ja", "簡單", "相", "nick", "香烟", "香", "钢琴", "守卫", "一大", "我花", "tony", "clear", "成交", "高手", "糟透了", "蒂娜", "多亏", "達", "西亚", "幻觉", "原来如此", "破产", "戴维", "通過", "pay", "指令", "脾气", "胡子", "不关", "劝", "两种", "相遇", "吵醒", "red", "追捕", "救援", "搬家", "轻", "朱", "妨碍", "码", "检查一下", "账户", "普通人", "大夫", "wish", "小妞", "考慮", "永恒", "练", "以色列", "订婚", "多人", "闆", "幸存者", "嫁", "拼命", "comes", "预约", "蟻", "每晚", "凯西", "minister", "举", "我点", "接手", "爱德华", "临时", "合伙人", "物品", "澡", "大陆", "讽刺", "饿死", "搬走", "方案", "王后", "麦克斯", "老天爷", "摩根", "亿", "上楼", "lee", "between", "调", "主动", "quite", "主教", "不得了", "英俊", "怪异", "国", "美金", "皆", "球队", "守护", "ち", "西部", "閉嘴", "演唱", "杰森", "truth", "真不知道", "显得", "公正", "獺", "人性", "伊丽莎白", "戴上", "很糟", "点子", "逐渐", "买卖", "呼", "爱尔兰", "格林", "干扰", "找回", "late", "钉", "不说", "alive", "此外", "路易", "得不到", "一番", "speak", "陷害", "别跟我", "差劲", "line", "运作", "贝", "内衣", "听懂", "兹", "自愿", "喝咖啡", "笔", "领域", "瞬间", "过分", "つ", "大型", "笑容", "fun", "偶然", "老爹", "好些", "未知", "咒语", "steve", "保住", "考验", "希尔", "拆", "根", "证词", "座", "à", "吩咐", "越南", "性爱", "发送", "随意", "招呼", "怀念", "登记", "开着", "nobody", "brian", "称之为", "水果", "丰富", "卧底", "边缘", "奥斯卡", "照顧", "史蒂芬", "解釋", "ん", "上海", "开发", "设法", "做不了", "though", "巴西", "签字", "明智", "海上", "哎哟", "早已", "质疑", "官方", "评论", "感", "症状", "减少", "直播", "军", "杯酒", "behind", "响", "沟通", "ass", "city", "昏迷", "dr", "你老", "受害人", "电台", "韦恩", "动力", "购买", "付出代价", "那一刻", "防止", "elena", "嘴唇", "双胞胎", "课程", "狗狗", "later", "种族", "解释一下", "连续", "清白", "招待", "列车", "全面", "瘦", "淹死", "捅", "条子", "占领", "大使", "抹", "戰爭", "started", "帮个", "蜡烛", "精神病", "帐篷", "首席", "郡", "兰", "宠物", "按钮", "财富", "多长时间", "扎", "无人", "高潮", "棺材", "留意", "出路", "租", "玉米", "发布", "上天", "安心", "工程师", "alicia", "西班牙语", "作业", "黄色", "经纪人", "罪恶", "人口", "野蛮", "灯光", "地说", "专心", "waiting", "过世", "保险箱", "目前为止", "ß", "先进", "见证", "组合", "当做", "能夠", "弄清楚", "蟼", "佛", "人手", "dan", "合约", "严格", "賸", "杜", "甚麼", "金属", "過", "总得", "障碍", "え", "worry", "打工", "眼泪", "人士", "大胆", "销售", "脱离", "羊", "一模一样", "他家", "温度", "天下", "出售", "走过", "外婆", "帮帮", "强尼", "星期天", "卡住", "office", "break", "独特", "涉及", "心脏病", "一行", "工作室", "别吵", "影像", "剧院", "补偿", "金发", "字母", "着火", "开启", "基础", "我查", "试验", "亲人", "来电", "挣扎", "一无所知", "细胞", "二十", "服从", "维多利亚", "进一步", "来临", "边境", "检测", "ﺫ", "minute", "太小", "排", "德州", "抗议", "运动员", "漫长", "双方", "進", "ﺩ", "名义", "娱乐", "乡村", "厲害", "面试", "看电视", "到此为止", "需求", "居住", "不見", "摩托车", "分别", "预测", "便是", "沙滩", "商人", "图片", "典型", "那辆", "确切", "小岛", "wow", "拼", "瓶子", "得出", "gets", "欢乐", "别看", "那才", "宣传", "drink", "等会儿", "眖", "凯瑟琳", "richard", "两名", "亮", "封", "感谢您", "频道", "前途", "逮到", "结合", "偶像", "暂停", "尽情", "请别", "这时候", "苏", "呵", "羞辱", "瓦", "吃点", "亚历克斯", "准时", "旁", "一大堆", "火焰", "谈到", "代理", "姿势", "这群", "屠杀", "千", "流氓", "人類", "雷蒙德", "絕對", "怪胎", "引爆", "农民", "asked", "困惑", "其余", "买下", "外表", "嗑", "花钱", "丢掉", "θ", "首次", "不远", "躲起来", "安全带", "处境", "caption", "故障", "烫", "收下", "舅舅", "星期一", "你會", "混球", "停手", "瑞斯", "met", "传奇", "登", "news", "骚扰", "伸出", "做成", "见识", "通往", "贝拉", "严禁", "每人", "犯下", "在我看来", "黃", "发作", "饶", "見過", "迎接", "小鸟", "代码", "sleep", "目的地", "资源", "召唤", "样本", "判决", "沙拉", "功能", "诱惑", "忍不住", "脑子里", "í", "商业用途", "怪人", "流", "瓶", "几句", "玩吧", "无能为力", "清", "斗争", "事先", "着想", "乱来", "hours", "久等", "办不到", "弥补", "調查", "eat", "之上", "萨", "這位", "乃", "隔", "鲸鱼", "这方面", "没收", "饼", "指导", "power", "苦", "blake", "那样的话", "那人", "脏", "read", "听话", "街区", "媽", "大象", "停留", "利亚", "罚款", "家长", "双", "號", "還沒", "追查", "观看", "出局", "撤离", "蠅", "摄影机", "試試", "蠀", "口音", "cool", "第一季", "住口", "這里", "全家", "半夜", "难得", "献给", "取决于", "一命", "理查", "击败", "可卡因", "海里", "领先", "叫醒", "邦德", "之間", "何必", "save", "哈啰", "ryan", "办事", "傷害", "寻常", "机械", "夏威夷", "敲门", "接收", "fnsegoe", "省", "别提", "电池", "录音", "帕", "夥計", "就够", "恶梦", "住在一起", "大地", "宴会", "bobby", "大多", "仿宋", "货车", "别怕", "引发", "修复", "fnkaiti", "almost", "作者", "虫", "提要", "十字架", "难看", "福尔摩斯", "头部", "劳拉", "眼里", "象征", "牠", "俄国人", "谨慎", "珍惜", "勇士", "睡覺", "girls", "蜂蜜", "删除", "抛", "发型", "周日", "tried", "辆", "婆婆", "氧气", "南部", "吃药", "轮", "项链", "聯", "弄错", "初", "forget", "消除", "放屁", "概念", "交通", "瑞士", "三個", "汽油", "诊所", "goes", "土豆", "full", "祖先", "童年", "无数", "双眼", "下载", "歌唱", "確實", "东", "一点儿", "越过", "力气", "声称", "隨便", "马车", "瑞德", "这回", "搞不懂", "房租", "有点像", "通", "这套", "波兰", "仅此而已", "ω", "died", "robert", "reason", "家园", "yours", "作為", "暗杀", "纪录", "试过", "降临", "人渣", "主持", "ˋ", "人数", "ﺠ", "阴影", "防御", "タ", "滚蛋", "巴克", "一下子", "死人", "贵族", "接下", "plan", "枪杀", "仇恨", "评估", "離", "迪恩", "沙", "掌声", "英寸", "索", "共", "six", "繷", "今后", "绕", "深入", "抬", "咧", "得分", "之地", "没说", "身份证", "布拉德", "快樂", "騙", "签署", "珍", "登上", "無論", "睡眠", "ﺓ", "服用", "還能", "很多年", "听不见", "法国人", "甜", "这算", "例子", "吼", "往前", "清洁", "胆小鬼", "亚洲", "夏", "que", "许可", "警员", "继续前进", "周一", "告别", "长期", "盡", "福特", "秩序", "奖励", "香肠", "屋子里", "插手", "我读", "诗人", "死神", "两只", "原创", "answer", "效劳", "小人", "滋味", "important", "恐慌", "fnconsolas", "北京", "创作", "披萨", "め", "那场", "畜生", "禗", "结论", "打招呼", "std", "说来", "可否", "earth", "bitch", "珍贵", "第四", "防守", "阅读", "anyway", "摄影师", "瓣", "陌生", "whoa", "会想", "量", "车辆", "就位", "變得", "稰", "翻譯", "伊莎贝尔", "带子", "分离", "交代", "院子", "約翰", "進入", "远远", "埋葬", "民众", "虐待", "腳", "week", "岿", "ui", "帮不了", "迈阿密", "舧", "赶来", "勉强", "预言", "举办", "复制", "原始", "评价", "吸烟", "奖金", "地毯", "私下", "trouble", "墓地", "哈特", "热爱", "一百万", "苏菲", "巡逻", "收获", "毫米", "协会", "法兰", "过度", "超市", "朝鲜", "问好", "行動", "负担", "村", "fnhobo", "玛丽亚", "指出", "战胜", "当事人", "模型", "套", "无比", "琳娜", "义务", "普", "定位", "湿", "汀", "卢", "chfafafa", "不足", "授权", "登陆", "主角", "节", "接管", "应得", "自已", "证件", "八个", "武装", "保管", "太过分", "掉下来", "各自", "brought", "回头见", "重建", "疭", "版本", "打包", "二号", "奔", "幽默", "旅游", "休假", "候选人", "换衣服", "拉里", "中有", "不通", "香蕉", "埃里克", "矛盾", "血腥", "约瑟夫", "东尼", "看待", "威利", "相比", "伴侣", "治愈", "杰米", "welcome", "举起", "蹲", "蝙蝠", "闯入", "jesus", "清晰", "少来", "刮", "眼中", "阿富汗", "村庄", "原諒", "跟随", "瑞秋", "誓言", "违法", "快死了", "shall", "操纵", "兩", "country", "礚", "搜寻", "大厦", "旋转", "赌博", "覆盖", "front", "只管", "硬币", "潜艇", "弱点", "香水", "本能", "telling", "教皇", "晕", "盘子", "最快", "百万", "青春", "恐龙", "send", "购物", "口味", "不赖", "anymore", "询问", "那要", "面子", "别急", "幹嘛", "身邊", "鲜血", "娩", "漫画", "受过", "呜", "那份", "fnstzhongsong", "自身", "之夜", "策划", "诉讼", "冲突", "渐渐", "巫师", "个性", "房里", "outside", "貌似", "穿衣服", "免得", "要命", "一千", "里克", "飛機", "酒精", "审讯", "凯撒", "seems", "闪", "莱", "侄子", "猜测", "尊严", "袜子", "隔离", "下流", "基督教", "修改", "基于", "每当", "印第安人", "目击", "able", "未婚夫", "eye", "一同", "指引", "六年", "入", "恒星", "取代", "狂", "专注", "取出", "怎么着", "电子", "伊恩", "回归", "供", "右手", "透过", "吾", "说错", "牙", "檢查", "汇报", "台词", "水手", "牛肉", "亂", "克服", "了结", "帮帮忙", "慷慨", "一辆车", "良心", "灵感", "打開", "needs", "一分", "元首", "买点", "娅", "原", "夹", "胃", "马克斯", "从事", "agent", "排除", "召集", "模样", "外国", "阴茎", "酒鬼", "操心", "指着", "寒冷", "汉克", "慢着", "一身", "马特", "旧金山", "couple", "北部", "希腊", "扫描", "一圈", "看起", "戴尔", "好友", "终结", "grace", "老弟", "有点儿", "犹豫", "场面", "伪装", "心理医生", "不理", "目標", "牢房", "丑", "实力", "把戏", "纯粹", "報告", "朱莉", "侵犯", "丸", "乡下", "例外", "湖", "罗伊", "传播", "块钱", "hot", "赣", "餓", "戳", "指责", "各地", "boys", "芭芭拉", "收音机", "领带", "核心", "途径", "命名", "滾", "人要", "类", "弹药", "团结", "黑帮", "忏悔", "晚会", "眼光", "前线", "扁", "上船", "别去", "有利", "可乐", "改天", "惹麻烦", "正直", "靴子", "龟", "电视台", "看不出", "维护", "边界", "四周", "视线", "一阵", "路过", "污染", "明晚", "town", "写作", "mrs", "bob", "中学", "国内", "渡", "电报", "哈哈哈", "daughter", "不利", "未來", "er", "论文", "风景", "额外", "传送", "两者", "幼稚", "电", "ª", "lose", "基督徒", "解散", "あ", "山谷", "出版", "依", "帕特", "友善", "艾比", "而战", "months", "闭上眼睛", "埃迪", "吓唬", "蝴蝶", "德语", "一组", "男女", "争论", "七个", "拉斯维加斯", "得以", "我心", "泄露", "caroline", "乘", "遗嘱", "你給", "媽的", "captain", "钟", "获胜", "谣言", "忽略", "单纯", "跑掉", "children", "荷兰", "賺", "黛", "分散", "狠狠", "团", "爲", "尾巴", "非要", "里头", "wir", "展现", "惠", "诡异", "doctor", "讯息", "哩", "曲子", "某处", "充分", "多钱", "担任", "怎会", "安息", "端", "问候", "订", "后门", "提过", "那段", "ゑ", "奖", "喂喂", "内疚", "帅", "拿给", "避开", "裸体", "一时", "倍", "人有", "寄给", "少爷", "未婚妻", "凯莉", "露出", "恕", "青年", "观赏", "悲惨", "挤", "反击", "新生", "負責", "别跑", "dave", "与众不同", "传给", "尚未", "排队", "画画", "不感兴趣", "把握", "笆", "johnny", "臺", "适当", "七年", "boss", "air", "洞穴", "振作", "生长", "马修", "制度", "真他妈", "lt", "摄影", "蔬菜", "客厅", "疑犯", "色情", "麵", "不管怎么", "枪击", "途中", "前妻", "ha", "此地", "公斤", "孤儿", "维克多", "着急", "打猎", "费城", "巴里", "赞美", "人选", "节奏", "住嘴", "秈", "得来", "狂欢", "sister", "玛格丽特", "耻辱", "方", "喜", "黎明", "存活", "滑", "疑问", "花费", "分鐘", "睡衣", "外公", "毒", "想得到", "决心", "奉献", "魔力", "实施", "前方", "古巴", "没到", "總是", "倾向", "保镖", "大会", "荡妇", "米歇尔", "living", "我還", "料到", "表哥", "husband", "多大", "甩掉", "真好", "降低", "别傻了", "提示", "怀特", "癡", "快快", "jeremy", "没空", "亲近", "成人", "human", "音樂", "以此", "married", "轮胎", "lives", "出院", "top", "两杯", "被判", "挑选", "名人", "碰巧", "讯号", "教师", "看清楚", "排练", "指甲", "成年人", "隐私", "枪声", "music", "苍蝇", "放棄", "这能", "打个招呼", "二十年", "蠢蛋", "毒药", "roman", "不用说", "真话", "早期", "握手", "就此", "考", "犯错", "过于", "里奇", "维克", "舱", "浴缸", "child", "种子", "瓳", "北", "戏剧", "粄", "好心", "沾", "看過", "这间", "贡献", "damon", "看得出来", "either", "祈求", "过后", "读过", "炳", "烧掉", "emily", "shoot", "吉尔", "碗", "优雅", "狡猾", "瀑布", "一封", "融化", "不快", "行程", "改造", "ﺷ", "计程车", "鸽子", "羡慕", "伏特加", "深深", "狥", "游", "头痛", "咪", "齐", "z", "病房", "告", "複", "sound", "光芒", "地铁", "康复", "没听说过", "骑马", "大王", "雕像", "发言", "期", "之旅", "好喝", "民族", "负责人", "汉娜", "能源", "touch", "血迹", "提升", "lucky", "找点", "抓走", "木头", "院长", "一具", "乐观", "游泳池", "我剛", "pete", "再谈", "交出", "control", "两点", "所作所为", "撤", "一幅", "甲板", "烧死", "宿舍", "台上", "窗口", "短暂", "promise", "化学", "哥们儿", "破解", "线路", "急事", "遠", "葡萄酒", "混合", "治安", "积极", "陈", "给钱", "很想", "配", "外出", "女郎", "亚历山大", "或者说", "镑", "怪怪的", "ﺧ", "服务员", "打球", "拉屎", "教室", "做人", "墨菲", "布鲁克林", "海豚", "較", "間", "崔", "目击者", "礼服", "一篇", "因素", "计算机", "压制", "编辑", "當", "结构", "蒙", "哈维", "挽救", "措施", "堕落", "遗产", "演戏", "控告", "women", "小费", "弗雷迪", "腊", "脚下", "画家", "以往", "预感", "堡", "杰", "小便", "滑稽", "胸", "别墅", "卡洛斯", "司令", "feeling", "迟早", "医学", "tlf", "收养", "下士", "手腕", "圣母", "影视", "一口气", "维斯", "天呀", "输入", "没带", "ン", "进化", "pick", "地步", "一系列", "贝蒂", "追逐", "甜点", "卡片", "治", "ten", "办到", "anna", "督察", "一到", "争吵", "行业", "碎", "噪音", "整件事", "游客", "ein", "事务所", "呻吟", "小弟", "琳", "那年", "一匹", "上台", "季节", "车库", "环", "机长", "艾德", "偷看", "斯巴达克斯", "夏洛特", "找人", "光荣", "塊", "文字", "姨妈", "管用", "时尚", "裡面", "待命", "违背", "第三个", "钮", "stefan", "願意", "处置", "老家伙", "决赛", "到哪去", "鸡肉", "企鹅", "疏散", "搶", "沃特", "大便", "委托人", "一无所有", "说了算", "遊戲", "真够", "纯洁", "五十", "格里", "果汁", "他妈", "回合", "出场", "天亮", "eddie", "想想看", "任務", "经", "艾莉", "je", "几岁", "sent", "图像", "监禁", "sometimes", "伪造", "往常", "收藏", "手铐", "撒尿", "港口", "斯汀", "押", "伯格", "正面", "几时", "fly", "家具", "极", "罗比", "戴维斯", "蛋蛋", "玩游戏", "walter", "祖国", "要点", "射杀", "贺", "文", "行不通", "笑声", "死后", "在外", "审问", "以防", "魏", "投诉", "le", "肯尼迪", "驾照", "唷", "医师", "早晚", "安保", "扣", "指定", "形状", "抽屉", "名片", "着陆", "一封信", "好戏", "毫无意义", "julie", "挡住", "招", "嫌疑犯", "small", "屌", "艾玛", "歌声", "模糊", "物", "太过", "受苦", "大自然", "军团", "ﻱ", "taken", "有事吗", "running", "president", "past", "理", "food", "动物园", "book", "里奥", "扎克", "赌注", "安装", "一手", "一流", "布拉", "会为", "兰斯", "hate", "生死", "乱七八糟", "掩盖", "议会", "品味", "否則", "安德烈", "狩猎", "帐", "家中", "亚伦", "丑陋", "服", "德斯", "遗忘", "发动机", "我哥", "首都", "多好", "筿", "航行", "那事", "手法", "报酬", "盐", "不小", "无情", "現場", "无限", "簡直", "破烂", "follow", "张开", "旅途", "銀行", "饥饿", "以便", "化妆", "版", "開車", "不多", "失业", "陪伴", "我得", "脑海", "打交道", "开关", "火山", "酗酒", "sounds", "下个", "有關", "游行", "刀子", "局面", "赐予", "不满", "多数", "這事", "空军", "drive", "stupid", "名声", "当局", "dog", "瑞", "过头", "创意", "快给我", "dark", "古", "没完", "暑假", "欢呼", "此时", "打得", "来接", "公共", "逗", "狟", "克里", "别过来", "辐射", "blue", "勋章", "背上", "清单", "遭", "million", "美人", "van", "honey", "言", "慈善", "棘手", "缠", "玛莎", "团体", "till", "弗雷德", "布里", "几小时", "希", "依旧", "极端", "片子", "扇门", "来得及", "好日子", "接通", "河流", "余生", "帮派", "大人物", "證明", "无礼", "传达", "susan", "债务", "ﺐ", "胃口", "犯罪现场", "堵", "心想", "欧文", "动静", "大规模", "杀戮", "一程", "hour", "拘留", "下注", "看不出来", "代", "合", "艾尔", "蜜蜂", "肯尼", "十个", "干过", "诀", "tommy", "卢卡斯", "混帐", "这时", "头盔", "扭曲", "过敏", "along", "asking", "tu", "红酒", "自首", "当天", "喜爱", "清洗", "橄榄球", "点心", "跪", "休想", "装饰", "government", "憎恨", "集中营", "稦", "症", "来个", "失败者", "闪电", "乐子", "狐狸", "sweet", "星系", "紧急情况", "国民", "离去", "世人", "借给", "器官", "半年", "毙", "妹", "fall", "毫不", "重生", "看一看", "重量", "下巴", "十二", "航空", "好久没", "散", "葛", "order", "fast", "举动", "之王", "喝水", "可憐", "太远", "光线", "一切顺利", "宝藏", "dream", "直说", "战役", "潜水", "元素", "perfect", "三点", "挣", "醒过来", "这要", "点燃", "那座", "屍體", "perhaps", "保释", "ú", "要钱", "本來", "火力", "clay", "晚宴", "竟敢", "火灾", "城镇", "陆地", "处决", "夜总会", "物种", "大赛", "触摸", "克莱", "想一想", "制定", "詹姆士", "一伙", "落下", "柑", "住院", "妮可", "落后", "第一件", "首领", "q", "要紧", "信件", "杰克逊", "下落", "走上", "martin", "他俩", "特里", "董事会", "体重", "引导", "宣誓", "平等", "草莓", "一股", "处在", "鸡巴", "那件", "暖和", "琳达", "陆军", "記住", "凯利", "cannot", "ㄢ", "勒索", "rick", "透", "這么", "好大", "一場", "less", "鸭子", "á", "bed", "世界末日", "謝", "身子", "還記", "company", "取笑", "天黑", "追杀", "凯", "魔术", "ya", "放学", "马戏团", "工业", "我教", "帮手", "乐团", "德拉", "jason", "馅饼", "吸引力", "幕后", "虫子", "building", "打擾", "雅典娜", "约翰尼", "独自一人", "侵入", "边上", "毯子", "该是", "狙击手", "相片", "ship", "左手", "传言", "提名", "开头", "rock", "那辆车", "菲尔德", "设施", "背着", "何处", "開槍", "thomas", "乳房", "leaving", "第七", "happens", "出血", "小学", "queen", "这栋", "大叫", "要花", "床单", "世界各地", "邦", "多一点", "わ", "信封", "伯", "andy", "mit", "system", "上级", "不出", "harry", "解决问题", "還沒有", "逃出", "妹子", "冷靜", "一看", "纯", "认罪", "大姐", "公室", "一條", "继续下去", "轰炸", "太美", "男孩子", "恐吓", "赞", "一所", "勾引", "日落", "搬进", "un", "斯蒂芬", "身处", "billy", "有力", "望远镜", "笼子", "玛雅", "送回", "那张", "整", "活力", "页", "小弟弟", "佈", "超出", "英镑", "水里", "树上", "一双", "太平洋", "才华", "布兰", "叹气", "板", "解脱", "布莱克", "sort", "跑步", "朕", "有史以来", "忘記", "马蒂", "第六", "恶作剧", "钻", "蹲下", "珊", "情侣", "紧紧", "泳池", "终止", "持有", "scared", "丢失", "第三次", "为难", "体会", "斗", "我累", "伊朗", "挨", "勒斯", "security", "升起", "傲慢", "shouldn", "干涉", "包含", "fact", "狠", "放開", "缺少", "非凡", "每件事", "alright", "ahead", "闪开", "hat", "win", "信不信", "不曾", "关联", "一一", "四点", "威力", "肉体", "known", "讲讲", "ed", "緊", "我快", "功课", "宝贵", "难堪", "快滚", "咳嗽", "florrick", "万圣节", "kevin", "东部", "一批", "ﺼ", "布雷", "意图", "好不容易", "大使馆", "marshall", "不配", "三号", "着迷", "吸收", "組", "马里", "瞶", "迷", "生氣", "尺寸", "出自", "ﾃ", "雇佣", "预算", "电力", "歌词", "迷惑", "总理", "战术", "很累", "possible", "精力", "睡得", "国外", "成千上万", "曼哈顿", "惊奇", "市中心", "傻事", "表弟", "穷人", "一會兒", "再度", "十点", "一拳", "真让人", "弟兄", "极限", "回见", "law", "朱利安", "化", "奥利弗", "开战", "俺", "哈尔", "专辑", "等着瞧", "funny", "乱动", "松", "公布", "出动", "海底", "buy", "改善", "ず", "何", "枕头", "背包", "笔记", "向上", "粗鲁", "有位", "光临", "责怪", "灰色", "觉", "转向", "become", "牙医", "索尔", "割", "ﺄ", "据我所知", "活在", "尽全力", "ч", "贱", "转变", "緊張", "波比", "身旁", "牌子", "碰上", "不合", "云", "很会", "机票", "daniel", "马歇尔", "一队", "機器", "學習", "anybody", "随后", "playing", "ﻝ", "夜里", "八年", "社交", "热狗", "缺", "逻辑", "暖", "抱抱", "两张", "穆斯林", "小东西", "祝你们", "miles", "万美金", "联合国", "cia", "再來", "看清", "夠了", "動", "从现在起", "罗宾", "真名", "看守", "雪茄", "窗外", "摔倒", "糊涂", "海水", "somewhere", "有限", "最坏", "可别", "警戒", "喇叭", "真的假", "尔斯", "小马", "碰面", "工会", "秋天", "无罪", "甜甜", "交給", "滑雪", "嫌", "拳击", "murder", "ō", "慌", "稍等一下", "發誓", "标签", "state", "柯", "美军", "sex", "彩虹", "哈里斯", "没命", "最多", "说句话", "同行", "fncomic", "t恤", "好棒", "定义", "μ", "special", "見面", "极其", "火鸡", "future", "拒絕", "心思", "渭", "一处", "乌鸦", "当真", "族人", "ﻄ", "盖尔", "卡斯", "会合", "巴斯", "青少年", "早该", "推进", "雅各布", "老哥", "聽到", "开动", "梦见", "建设", "文森特", "抓狂", "驱逐", "潘", "往前走", "出狱", "很晚", "预期", "鼓掌", "运送", "忽然", "land", "围绕", "妥协", "抚养", "编", "himself", "sense", "耽误", "贸易", "宝石", "當我", "黑夜", "谅谅", "一枚", "成年", "心爱", "巴比", "软件", "加强", "活该", "步枪", "辩论", "总共", "扫", "暴风雨", "她家", "这本", "洗个", "堅持", "瑞奇", "特定", "极度", "介入", "青蛙", "独处", "凡", "意愿", "不好玩", "颗", "英勇", "ど", "street", "成果", "seem", "就别", "工", "住处", "羞愧", "掉下去", "雷达", "為何", "能干", "開門", "mal", "应对", "carl", "有毒", "歌剧", "这行", "作弊", "barney", "外星", "一回", "雪莉", "涴", "贝利", "有的是", "起立", "烦人", "戈登", "打听", "耶稣基督", "别处", "wall", "叫声", "常见", "多点", "总能", "不但", "大腿", "夹克", "芬奇", "增长", "最美", "矮", "软弱", "忍耐", "水中", "祥", "剪刀", "给你个", "フ", "曾經", "pas", "受傷", "星期四", "局里", "hair", "多余", "军方", "色", "石", "不夠", "dance", "误解", "盿", "每天晚上", "无视", "嗷", "之名", "ﺸ", "patrick", "weeks", "烹饪", "水面", "唐娜", "外国人", "清晨", "套房", "只用", "老太太", "朗", "usher", "嚴重", "快进来", "摩西", "strong", "咩", "撒旦", "擁有", "邀", "喷", "囉", "救人", "能带", "脸色", "闯进", "流浪汉", "隐形", "人间", "海外", "系列", "目光", "一切正常", "悬崖", "盽", "沉重", "浑身", "羞耻", "宁可", "第一位", "求救", "電視", "已有", "精子", "土耳其", "很帅", "范", "入睡", "侄女", "比特", "悲哀", "握", "已婚", "打人", "佩服", "以防万一", "设定", "carter", "很重", "匿名", "人体", "挖掘", "爸爸妈妈", "几", "先知", "同伙", "发觉", "大众", "贪婪", "水晶", "marie", "花花公子", "七点", "鲍尔", "抢走", "道别", "笔记本", "裁判", "蝙蝠侠", "和尚", "携带", "逃出来", "别以为", "沃克", "填", "男爵", "佢", "补充", "技能", "喝完", "雞", "为什", "妖怪", "daddy", "史上", "别太", "绿", "汽水", "す", "鸟儿", "救出", "无知", "菜单", "溜", "斯坦", "中断", "有钱人", "匹配", "figure", "星际", "セ", "赔", "hang", "發", "到手", "新年", "录像带", "我带", "创伤", "一分钱", "抗拒", "通电话", "tara", "卢克", "高速公路", "一站", "听从", "忍", "援助", "维亚", "ﾊ", "劳伦斯", "预计", "泰国", "幸存", "毕", "趟", "唤醒", "请客", "腐败", "气体", "恶劣", "腐烂", "ç", "失", "喘气", "委", "砛", "主厨", "secret", "社會", "物理", "serious", "鸡尾酒", "扮", "鳄鱼", "战略", "跳下去", "失礼", "乐", "管道", "催", "音乐会", "紈", "收看", "待会", "永久", "困住", "墙壁", "妮娜", "梦里", "己", "货物", "工作人员", "通缉", "跑道", "轻轻", "遗传", "借用", "哪個", "扔下", "帕特里克", "不难", "艾琳", "婚", "丢人", "sun", "用心", "分配", "坚信", "五点", "诱饵", "车厢", "真对不起", "传闻", "風", "从未见过", "玩弄", "设计师", "这段", "里斯", "势力", "takes", "天真", "摩尔", "高贵", "雇用", "sara", "乔纳森", "思维", "除", "cold", "多多", "真该", "tyler", "先来", "视为", "连环", "一幕", "咁", "刹车", "很痛", "发烧", "进屋", "派出", "往后", "治療", "阴道", "修道院", "琼", "热闹", "老人家", "教导", "传来", "jeff", "屁眼", "应当", "宾馆", "hurry", "救世主", "dear", "密室", "选中", "权", "一首歌", "蠈", "赞同", "choice", "一票", "编剧", "信徒", "放假", "质量", "水管", "监督", "无效", "得救", "大爷", "奋斗", "别来", "en", "点钟", "粘", "拳", "你別", "发火", "布置", "走私", "玩家", "五千", "pull", "前任", "着手", "beat", "金色", "爾", "辣", "柠檬", "海豹", "口香糖", "活著", "物体", "羽毛", "诊断", "丧失", "死因", "meeting", "刺杀", "jerry", "喘", "好几年", "威尼斯", "珍珠", "制止", "加油站", "固执", "资产", "最强", "拘捕", "同時", "星矢", "凉", "words", "一层", "本性", "fantasy", "罢工", "任命", "我付", "庞大", "證據", "箭", "现身", "完事", "分裂", "重力", "除此之外", "服役", "体育", "ooh", "掩饰", "场合", "zu", "账单", "爱过", "蒂姆", "痛快", "九点", "躲避", "本质", "一秒钟", "luck", "没准", "融入", "坦", "走開", "calling", "谎", "电源", "坚定", "锻炼", "芝士", "拦住", "worked", "可行", "maggie", "独一无二", "事是", "並且", "大衣", "神盾", "低调", "贿赂", "操控", "深处", "过份", "说得好", "俄语", "镇子", "德军", "疫苗", "节日", "罢", "凯伦", "玩完", "事后", "活儿", "古代", "胸口", "聰明", "脱身", "菲", "一是", "华丽", "值钱", "è", "罪人", "镇定", "运转", "周二", "话说回来", "禮物", "好转", "巴特", "出价", "听证会", "哄", "泰迪", "目睹", "lucy", "层", "太高兴", "杰西卡", "相对", "morgan", "催眠", "moving", "弱", "巴基斯坦", "安吉拉", "drop", "心碎", "转告", "step", "全美", "自殺", "蠢事", "界", "识别", "克雷格", "你行", "享用", "ﺕ", "關於", "东方", "腰", "装满", "袋", "我知", "演唱会", "保卫", "三分钟", "脚步", "均", "八点", "逃犯", "营", "记着", "den", "questions", "肺", "三人", "录", "休", "重视", "嫂子", "发给", "三十", "fntimes", "圣人", "早饭", "精确", "海洛因", "运输", "中校", "打劫", "微軟雅", "catch", "澳洲", "自称", "两条", "髒", "works", "平凡", "棕色", "小鸡", "沉", "出身", "趕緊", "road", "庄园", "商品", "rachel", "厩", "采取行动", "正想", "博", "预定", "嫌疑", "钞票", "后天", "沒用", "拳头", "别烦", "幾乎", "传递", "泰德", "口交", "不接", "明日", "装作", "粉碎", "敌军", "外遇", "细菌", "虽", "当着", "人情", "盛大", "容忍", "我什麼", "鉴于", "gold", "攻擊", "发现自己", "誒", "客房", "畏", "效忠", "批评", "形势", "不动", "永生", "forever", "看书", "推测", "继承人", "注册", "上演", "来讲", "ground", "乐园", "群", "超能力", "亨特", "記錄", "可真", "哥伦比亚", "卷入", "致敬", "lie", "核弹", "依赖", "worth", "甜美", "珨", "穝", "往往", "毒贩", "蘑菇", "組織", "呼唤", "客氣", "放大", "保障", "seven", "保", "路边", "還給", "爱好", "上空", "答應", "新郎", "撞击", "dinner", "打造", "ﺀ", "会带", "赢家", "各个", "昆虫", "六点", "厚", "感恩节", "raymond", "德里", "垃圾桶", "行走", "出租", "第一步", "扯淡", "宽", "开走", "班机", "變", "nate", "gps", "不干", "深度", "真诚", "莱恩", "女孩儿", "铃声", "精神病院", "念头", "维拉", "卫", "這就", "胜过", "一方", "直至", "焦虑", "没门", "阻碍", "流浪", "被害人", "生涯", "胆子", "那本书", "拖车", "葡萄", "神话", "意大利人", "先是", "挺不错", "左转", "培养", "肈", "帐户", "正当", "怜悯", "困境", "摩托", "提问", "阿宝", "大战", "赋予", "租金", "最有", "娜娜", "终身", "哈佛", "老家", "思念", "头疼", "杰出", "起初", "派克", "多謝", "others", "两样", "米兰", "weren", "守住", "刘", "磁带", "happening", "º", "eric", "儘", "一會", "艾米丽", "寡妇", "遍", "莫莉", "盒", "迪伦", "三周", "互联网", "安定", "男子汉", "发财", "上个月", "一早", "强盗", "通信", "开工", "托比", "seeing", "创建", "门外", "洱", "共度", "没得", "真主", "赔偿", "爱上你", "虚弱", "一代", "michelle", "共事", "脂肪", "别问", "提及", "换成", "手機", "这招", "决斗", "请来", "加班", "不覺", "犯法", "克洛伊", "lead", "ぶ", "扩大", "ﻊ", "搞不好", "带回家", "賭", "景色", "俘虏", "戴着", "压", "里昂", "張", "担保", "上将", "今夜", "下水", "弄出来", "return", "娜塔莉", "灰", "不问", "利润", "玂", "窒息", "秆", "政客", "驾", "厄尔", "枪支", "longer", "turned", "盯上", "影響", "加斯", "ル", "經過", "芯片", "朮", "护送", "无需", "監獄", "那群", "新魏", "炸掉", "適合", "终点", "表現", "還會", "小宝贝", "校對", "后院", "吉娜", "lisbon", "蔼", "中國", "血统", "charles", "威", "无人机", "生命危险", "吞", "迈尔斯", "极大", "忠实", "凶", "衣柜", "使劲", "奖学金", "al", "损坏", "效力", "福利", "狂热", "敞开", "伊莱", "河边", "uncle", "缘故", "坑", "出差", "加点", "alphaff", "还行", "母狗", "松鼠", "校园", "封闭", "试一下", "当晚", "simon", "走到", "更新", "汗", "制片", "屏幕", "厌恶", "辆车", "星期二", "安宁", "机关", "高速", "乘坐", "姑姑", "这幅", "肯特", "阻挡", "世间", "kelly", "肥", "色彩", "最小", "康纳", "写下", "朝着", "下山", "周四", "管家", "蚂蚁", "稳住", "昂贵", "carrie", "认同", "编号", "无关紧要", "一邊", "澳大利亚", "师兄", "摇", "伊森", "锁上", "拽", "快点儿", "气息", "引", "一级", "亲生", "ﺨ", "喵", "黛比", "旨意", "景象", "摔跤", "alphahaf", "梅森", "看得出", "scott", "姑妈", "沼泽", "樓", "失误", "名称", "杰作", "驴", "同樣", "瑞典", "并不知道", "别理", "找些", "赛车", "火车站", "烂摊子", "之声", "业余", "装修", "商场", "履行", "出去玩", "过会", "野心", "piece", "遗体", "赫", "窗帘", "爱因斯坦", "下楼", "打搅", "奈特", "吊死", "堡垒", "他用", "付给", "josh", "力克", "潜入", "咆哮", "given", "斯大林", "见过面", "英", "buddy", "同胞", "从中", "女仆", "一班", "sophie", "战", "選", "德里克", "罕见", "老板娘", "情报局", "迫不及待", "兼", "von", "请便", "步行", "那時", "规模", "快逃", "rather", "薯条", "爱我吗", "怎么弄", "引诱", "怪不得", "战舰", "备用", "豪华", "行為", "喲", "角", "誓", "更是", "auf", "气球", "就象", "司令官", "病情", "阳台", "共享", "语", "汽车旅馆", "黑洞", "采用", "妖", "低估", "集会", "涂", "时会", "將會", "部位", "保持沉默", "小型", "佛罗里达", "炫耀", "懷疑", "统一", "太漂亮", "娘娘腔", "枪手", "我国", "帕克", "分成", "across", "妄想", "我以", "闽", "克劳", "protect", "冰冷", "lisa", "底特律", "改革", "刷", "那家", "雅", "rebecca", "太高", "搬出去", "阿拉", "罗素", "库珀", "冰块", "失敗", "我救", "learn", "wonder", "决不", "频率", "打給", "kate", "差别", "宪法", "强调", "finally", "ride", "北极", "模拟", "picture", "胆量", "两倍", "嘅", "急救", "共和国", "前夫", "洋葱", "敵人", "这倒", "组长", "ﺻ", "worse", "归来", "song", "运用", "陈述", "接待", "宫", "沙子", "felt", "米拉", "sick", "ㄤ", "恶意", "桶", "吃醋", "两句", "库", "叶", "愛情", "这真", "料", "真要", "乔丹", "处死", "自以为是", "圣斗士", "举起手来", "庆幸", "關心", "出错", "瘋狂", "血管", "和解", "解救", "特意", "震撼", "總統", "樣", "向下", "扔进", "莎莉", "needed", "伍德", "服务生", "符号", "发起", "神像", "之子", "meant", "飛", "一秒", "逃亡", "上诉", "平均", "車", "职员", "骗局", "ェ", "missing", "偏偏", "正常人", "kiss", "岛屿", "网", "錯誤", "这么回事", "会上", "加里", "船只", "太糟", "担忧", "迟早会", "顺序", "有话", "精英", "瘟疫", "我出", "不带", "数到", "封面", "message", "料理", "激怒", "个头", "长相", "歷史", "哪边", "差一点", "ones", "谈恋爱", "じ", "卫生间", "阁楼", "十足", "喜剧", "癘", "点火", "星期三", "房屋", "giving", "司令部", "趕", "协调", "舞者", "束缚", "機", "讲述", "straight", "乾", "洗手", "零钱", "阿拉伯", "缺陷", "以免", "clean", "一块儿", "拿掉", "曝光", "捣乱", "imagine", "hospital", "集体", "特征", "戈", "缺点", "徽章", "电线", "糑", "欧元", "德尔", "操蛋", "並", "回避", "扳机", "供应", "穿著", "天主教", "况且", "戰鬥", "能耐", "艾瑞克", "汉斯", "別說", "表妹", "哈罗德", "圆", "finch", "包装", "法郎", "辉煌", "dvd", "印", "使者", "反應", "沒法", "箱", "一大笔钱", "牢", "arthur", "可要", "私事", "粉", "偷来", "五百", "没理由", "蜜月", "資料", "kim", "chuck", "牧场", "很难说", "找死", "右转", "et", "推出", "外人", "必定", "近来", "一切都在", "墓", "汉弗莱", "写信给", "树木", "丫头", "口供", "不用谢", "jay", "拨", "美麗", "险", "哪种", "妓院", "杆", "偷东西", "實際", "脚趾", "队友", "台湾", "別動", "遺憾", "名誉", "会派", "资助", "分心", "气候", "事务", "history", "首尔", "废", "软", "rose", "罩", "赦免", "report", "兇手", "原地", "恶化", "帕蒂", "理性", "九个", "仙子", "战斗机", "宁静", "山羊", "送走", "美食", "冲击", "领", "丑闻", "品牌", "watching", "上衣", "老友", "潜在", "圈套", "老头子", "官司", "生于", "越來", "占据", "doch", "巨星", "angel", "拖延", "好意", "别生气", "拉姆", "黄油", "dick", "破碎", "ヴ", "天花板", "金字塔", "服务器", "邓肯", "施", "none", "坠落", "罗莎", "跌", "紐約", "fear", "住所", "weird", "ﻷ", "查到", "性别", "提交", "报答", "我开", "一个男孩", "na", "二位", "烧毁", "脱衣服", "科林", "高尚", "tmd", "蟑螂", "glad", "黑社会", "两边", "劲", "再见面", "焊", "屈服", "转过身", "会到", "大伙儿", "一招", "回想", "黑客", "领导人", "maria", "毛衣", "大忙", "王牌", "泰", "上头", "ﾑ", "eli", "夜间", "正確", "先去", "说点", "咨询", "凯勒", "坐标", "递给", "管好", "il", "格拉", "乾杯", "phil", "这艘", "吊", "架飞机", "尝", "本片", "埋伏", "蒙特", "loved", "谎话", "市区", "杨", "销毁", "kitt", "不光", "我媽", "反映", "茉莉", "給他", "larry", "过时", "第二季", "总裁", "炮", "执照", "逃出去", "收买", "数目", "堆", "恶棍", "终", "高地", "土", "四天", "买家", "detective", "那太", "地带", "wedding", "前门", "再试一次", "太酷", "殖民地", "温", "绝不能", "琴", "せ", "夸奖", "察觉", "matt", "部份", "胡闹", "贫穷", "离谱", "information", "猪肉", "oliver", "另一半", "chief", "顶级", "月光", "推翻", "米尔", "綁", "做错", "大學", "安德森", "欸", "三位", "前提", "意味著", "在内", "宫殿", "两份", "眼看", "河里", "一击", "throw", "露面", "鱼雷", "条款", "待遇", "stark", "负", "检验", "先回去", "录影带", "世代", "凶器", "一張", "升级", "雅各", "引用", "这颗", "捏", "泄漏", "豆子", "尼基塔", "时速", "不在意", "事态", "万物", "方位", "jetzt", "探員", "根據", "未必", "冲浪", "出示", "末日", "柜子", "海报", "小声点", "天地", "摘", "最早", "date", "西德", "打开门", "尋找", "soul", "建筑物", "萨尔", "趴在", "推迟", "應", "diane", "deep", "claire", "還活", "另一方面", "超級", "再也不能", "阿尔伯特", "feet", "尼亚", "介紹", "放进去", "掌管", "诺曼", "遵循", "茱莉亚", "颤抖", "ﾈ", "买个", "ian", "那间", "乱跑", "手脚", "肖", "撤销", "谈一谈", "amanda", "白兰地", "草原", "进城", "罪过", "悲痛", "幽默感", "prison", "ran", "结尾", "充足", "贩毒", "喜悦", "妈呀", "一刀", "桑", "帅气", "artie", "南希", "此次", "選手", "审查", "廉价", "几句话", "山顶", "制片人", "这车", "再会", "爱河", "婓", "wake", "ghost", "green", "菜鸟", "奇特", "意", "及其", "金融", "振作起来", "多莉", "总督", "西雅图", "unless", "伯特", "帶來", "之用", "危害", "金币", "盟友", "明亮", "猩猩", "务必", "taylor", "年度", "探望", "立正", "roy", "上下", "真實", "推动", "记下", "你媽", "ring", "list", "靈魂", "罗密欧", "气色", "牵扯", "parents", "射中", "莉娅", "正事", "球场", "苦难", "酋长", "拍卖", "冤枉", "潜力", "功劳", "盢", "回收", "马路", "支撑", "抄", "born", "這也", "脏话", "零件", "优先", "灭绝", "casey", "筹码", "evidence", "性生活", "凡人", "研究所", "壓力", "一塊", "终极", "句", "交叉", "poor", "传染", "包里", "還以", "订单", "晒", "courtney", "star", "防卫", "野餐", "关在", "健身", "特效", "流言", "空虚", "梯子", "条路", "fnyouyuan", "鑰匙", "孤儿院", "忠告", "皑", "语气", "半天", "下个月", "天吶", "前行", "闯", "倒数", "有天", "麻醉", "act", "知名", "里边", "探险", "撑住", "调情", "松开", "指向", "管理员", "结", "追随", "打碎", "布什", "找個", "有太多", "大学生", "辨", "一帮", "大西洋", "肥皂", "刺客", "谷", "纸条", "changed", "罗恩", "缓慢", "念书", "公子", "盲目", "pain", "ﺰ", "不愧", "忽视", "鲜花", "支配", "方舟", "夏洛克", "露营", "伤亡", "vanessa", "虔诚", "旅客", "looked", "哲学", "职业生涯", "ア", "一栋", "ﻡ", "并非如此", "分辨", "特地", "书上", "利息", "sean", "小提琴", "坠入", "現", "自行", "特权", "格雷格", "雄", "飞翔", "情节", "面条", "领主", "那套", "精", "偷窃", "桑德斯", "纠缠", "注视", "抚摸", "吴", "活命", "大屠杀", "sign", "的士", "武力", "几位", "列", "灭亡", "要用", "衄", "人住", "仗", "减肥", "少数", "伊娃", "囚禁", "把头", "bet", "发抖", "响起", "容", "service", "通向", "针", "养活", "看得见", "仔细听", "材", "記憶", "难民", "无处不在", "十五", "霍", "赶时间", "bonnie", "到家", "骨折", "登机", "璸", "wie", "闪耀", "烤肉", "穷", "系統", "最低", "一带", "中枪", "基佬", "示范", "捡起来", "建議", "pass", "caught", "扭", "野", "擅自", "血压", "影响力", "伴随", "托德", "克莉丝", "八卦", "道具", "實話", "一有", "低头", "必然", "日常", "mouth", "恋人", "cd", "写给", "イ", "尾", "呕吐", "插入", "手榴弹", "躲开", "最少", "领养", "鬼混", "說話", "cooper", "quick", "剥夺", "莱特", "不定", "婚禮", "多远", "aaron", "咖啡馆", "活人", "这比", "經歷", "聋", "定罪", "体面", "小猫", "キ", "非常高兴", "挖出来", "冯", "大炮", "毒气", "那本", "警车", "一瞬间", "琩", "完全正确", "不能不", "安靜", "特洛伊", "艺术品", "华生", "走着瞧", "兰德尔", "吉利", "加密", "罐子", "很强", "钡", "倾听", "刚刚开始", "紫色", "印度人", "共产党", "陳", "替代", "plane", "同居", "三十年", "calm", "鐘", "讀", "离家出走", "赶出去", "得罪", "怎样才能", "泥", "摸摸", "甡", "地雷", "獶", "owen", "给出", "邪", "光是", "别用", "虾", "fault", "喝啤酒", "伴", "佩吉", "乞丐", "认定", "真会", "猛", "晋级", "踏上", "大火", "动摇", "多麼", "消防员", "人死", "布丁", "大老远", "不爱", "马克思", "拍电影", "國王", "看样子", "爺爺", "输给", "坠毁", "认可", "扇", "管子", "女演员", "此人", "rich", "前科", "划", "在线", "那头", "老太婆", "用到", "我什至", "沖", "莎士比亚", "太重", "上网", "钟头", "秒钟", "五天", "â", "吞噬", "雨果", "帮会", "周三", "army", "阿尔", "严厉", "klaus", "一万", "杀光", "唯有", "门锁", "north", "逗我", "voice", "五分", "救赎", "升职", "single", "好多年", "伯爵夫人", "explain", "middle", "盖瑞", "有件", "试镜", "不算什么", "币", "窥", "early", "偏见", "弗朗西斯", "broke", "一轮", "名为", "底部", "打起精神", "厌烦", "深夜", "循环", "人心", "nikita", "十天", "ladies", "下水道", "好比", "布斯", "el", "德鲁", "亲眼", "野人", "级别", "獲得", "dangerous", "贱货", "游艇", "serena", "和谐", "用餐", "布尔", "做手术", "玛莉", "否定", "莱斯特", "dude", "西斯", "步骤", "意大利语", "唐尼", "来回", "皇室", "很傻", "尤", "南瓜", "smart", "經常", "american", "真爱", "贴心", "kidding", "帮到", "破裂", "局势", "表格", "尖叫声", "重回", "入狱", "恢", "请稍等", "public", "愛的", "管它", "布鲁克", "百姓", "追上", "头绪", "通行证", "吹牛", "性关系", "威脅", "罪孽", "奎恩", "缩小", "andrew", "killing", "选票", "男士", "北边", "呆子", "摆平", "调查员", "write", "纪念日", "ひ", "村民", "只會", "场所", "火腿", "感恩", "揭露", "诺拉", "attack", "马桶", "mich", "侏儒", "為止", "噁", "我下", "众多", "amazing", "脱衣舞", "我过", "跳跃", "合格", "发泄", "宝", "安置", "村里", "淑女", "情景", "爹地", "学长", "william", "原理", "存", "报社", "棉花", "身高", "日出", "厂", "ﾟ", "吃饱", "电影院", "难题", "赏金", "巫婆", "心底", "master", "火車", "玩耍", "lying", "牡", "三千", "马库斯", "这样一来", "火柴", "史考特", "铺", "路程", "平", "遲到", "捕捉", "监听", "迷信", "音", "岂", "本案", "ì", "尔顿", "不怪", "cover", "stephen", "sky", "教父", "文学", "哀悼", "有病", "瘾君子", "古董", "屠夫", "感人", "第一名", "瞎子", "诗歌", "饮食", "很惨", "hannah", "有份", "砍掉", "丧命", "伯母", "将近", "韦德", "坻", "艾伯特", "届", "损害", "乱搞", "监视器", "自尊", "咪咪", "jessica", "比喻", "絋", "安东", "外交", "join", "判", "期限", "梅根", "群众", "脉搏", "捕猎", "根本就是", "遇害", "abby", "庇护", "park", "巨型", "麦克风", "峡谷", "時間軸", "补给", "富人", "不惜一切", "后代", "aber", "每日", "代号", "守护者", "狂野", "棍子", "幾", "頭", "发了", "創造", "雷诺", "柯南", "space", "时空", "sd", "充电", "sea", "kept", "粮食", "跌倒", "魔术师", "传到", "转动", "box", "政权", "命中注定", "累死", "音乐家", "甚", "值班", "老娘", "窝", "雷蒙", "我犯", "缝", "塞进", "十字", "煎", "安全感", "里德", "mmm", "可好", "各就各位", "弯", "nbsp", "一出", "运", "出海", "新聞", "骆驼", "外界", "接著", "歇", "副作用", "会员", "不顾", "惡", "外边", "塑料", "突袭", "立马", "冷血", "长久", "確認", "准", "saved", "播出", "哒", "构成", "玛姬", "访客", "懦弱", "维奇", "轻点", "啥事", "众人", "ﺲ", "學生", "china", "粉红色", "言语", "转换", "迷恋", "suppose", "ﻩ", "股份", "权威", "猜想", "领土", "忍者", "步", "学费", "国度", "成本", "兄弟姐妹", "亲亲", "无权", "银河系", "paper", "身分", "趕快", "很差", "领地", "不妥", "必", "coffee", "患", "absolutely", "hier", "烟雾", "差點", "烧伤", "丝毫", "弄死", "乌龟", "願", "所能", "撕裂", "gary", "玩儿", "柔软", "假释", "伤人", "未经", "食", "呈", "滴", "轮椅", "无敌", "准备就绪", "视野", "赫克托", "特纳", "鲸", "弗斯", "忘不了", "活動", "抵押", "行踪", "无家可归", "嚼", "同性", "humphrey", "迷你", "烧烤", "alan", "指南", "骨灰", "出击", "洗衣服", "每月", "离家", "真糟糕", "忧郁", "有枪", "ゲ", "還想", "ken", "課", "时髦", "號碼", "生日礼物", "二人", "austin", "te", "杀了人", "矪", "丫", "共同点", "王位", "照相", "难忘", "一大早", "人想", "奧", "難過", "宇航员", "充滿", "墨西哥人", "窗", "人造", "参赛", "谜", "恩怨", "果", "煎饼", "不知情", "与此同时", "基德", "团聚", "二楼", "霍尔", "越是", "美国政府", "hide", "桑德拉", "感想", "一日", "auch", "hank", "搂", "人命", "围着", "活生生", "簀", "熬", "备份", "警署", "痛恨", "梦境", "房地产", "戴安娜", "洛斯", "killer", "海湾", "摩", "班上", "悄悄", "柜台", "莱拉", "太早", "转到", "訓練", "carlos", "莱纳", "请等一下", "俱", "真遗憾", "shakira", "滚出", "quiet", "推销", "药丸", "普拉", "强制", "莱克", "匆忙", "所长", "巧", "mad", "子女", "ﾚ", "鲁", "情愿", "跳动", "弄出去", "隊長", "先前", "失落", "可可", "殴打", "猎杀", "优点", "设", "打发", "女婿", "顯然", "从而", "stan", "解", "照料", "bag", "虚构", "有鬼", "德國", "再聊", "好球", "month", "书店", "诸位", "勁", "款", "产业", "那首歌", "能活", "下雪", "臀部", "討論", "jenny", "草坪", "林先生", "出庭", "没变", "ice", "某种程度", "约翰逊", "斯塔", "住址", "溜走", "迫使", "命中", "用途", "签约", "年来", "什麼樣", "本次", "唠叨", "破案", "冻结", "弗雷", "亲热", "呼吁", "体力", "最糟", "戒", "honor", "顺着", "何方", "blow", "simple", "快上车", "brown", "摇摆", "自大", "双倍", "mama", "裹", "不变", "zach", "瞄", "踪迹", "罗拉", "灭", "ﻙ", "告辞", "亲切", "炮弹", "mistake", "送死", "探测", "前所未有", "飞往", "先到", "门铃", "徒弟", "客", "置", "觀眾", "四十", "十三", "招募", "好受", "门前", "赎金", "呈现", "支", "near", "穿成", "吨", "五月", "打斗", "结了婚", "山洞", "冰蓝", "逃生", "部署", "安全局", "罚", "核", "拦截", "想象力", "兔崽子", "特种部队", "引力", "ﻀ", "wenn", "禽兽", "最先", "叔", "dj", "行政", "恰当", "记载", "送給", "難以", "无能", "演員", "掉头", "闪亮", "仇", "圣地亚哥", "芭", "幾天", "卡罗尔", "出国", "输掉", "答复", "进出", "让你在", "收购", "收费", "ń", "伯伯", "兄弟会", "孙女", "蠂", "copy", "夺回", "谷仓", "家属", "无趣", "officer", "美分", "算不上", "leslie", "仪器", "大侠", "瑜伽", "莫里斯", "floor", "bishop", "好想你", "耳环", "eight", "雇员", "几张", "火花", "解药", "与否", "dass", "谴责", "不看", "哔", "收留", "落入", "泰瑞", "晃", "les", "勃起", "乳头", "乱说", "故乡", "busy", "学者", "一包", "拿些", "回顾", "善", "平台", "據", "terrible", "不放", "except", "立", "主持人", "真美", "成天", "初次", "活得", "手册", "假发", "维修", "打理", "测验", "奥巴马", "海军陆战队", "露丝", "打动", "无疑", "得逞", "志愿者", "比不上", "米克", "带有", "莫名其妙", "冠", "允許", "阿瑟", "chloe", "单单", "跨越", "holy", "航线", "careful", "达拉斯", "太近", "无力", "浪費", "壮观", "会计", "演习", "巫术", "厨艺", "信赖", "神明", "木偶", "篮球", "洒", "迷宫", "蔓延", "国土", "抗争", "dann", "口径", "gentlemen", "植入", "宣称", "律師", "树枝", "合并", "追寻", "借钱", "中弹", "这周", "车牌", "合唱团", "人为", "坏掉", "弟兄们", "cary", "伊凡", "香味", "饒", "花朵", "將", "西尔", "幼儿园", "片段", "拉尔夫", "隊", "court", "握住", "这首", "诺亚", "parker", "坦诚", "那颗", "岁月", "理会", "展览", "坐坐", "窃听", "可耻", "背部", "品尝", "幸運", "按住", "报案", "恕我直言", "hunt", "菊花", "作对", "想必", "外头", "一脚", "大家伙", "mir", "责备", "艾略特", "虽说", "還不", "其次", "吵死", "与其", "粒子", "看穿", "纽约市", "压抑", "整体", "瓦斯", "anywhere", "露", "小伙", "争议", "游荡", "灰尘", "废弃", "第三季", "去取", "大桥", "新手", "烦死", "停电", "挣钱", "报应", "高层", "癒", "实情", "当个", "抉择", "动身", "生来", "birthday", "堵住", "高大", "士", "无尽", "公事", "爱着", "round", "真为", "新泽西", "帮上", "哗", "奉", "group", "头号", "熟人", "派遣", "估", "耶路撒冷", "港", "当场", "正经", "一丝", "塔斯", "枪毙", "转转", "摆在", "在世界上", "四月", "减轻", "york", "核武器", "面孔", "但别", "走近", "戒酒", "关进", "修正", "过日子", "签个", "blair", "那幅", "所见", "友情", "洛伊", "学期", "好家伙", "娘养", "大笑", "amber", "入住", "elizabeth", "后座", "孔", "喬", "活跃", "我放", "脑", "可比", "伊万", "等级", "沉睡", "那块", "健身房", "头顶", "诺言", "叶子", "每隔", "電話給", "小混蛋", "三百", "被关", "我馬上", "顶尖", "整夜", "打牌", "ν", "鹿", "法医", "体贴", "对决", "shaw", "口信", "瑞格", "片刻", "jax", "电子邮件", "黑手党", "bar", "突击", "私奔", "造型", "謊", "阿拉斯加", "飓风", "驾驶员", "伤痕", "绰号", "损伤", "威尔逊", "下定决心", "处罚", "公牛", "伺候", "裁决", "酸", "徘徊", "章", "猪头", "意識", "女佣", "梦幻", "记号", "以至于", "捧", "上士", "打赢", "移植", "不怎么样", "县", "韩", "不下", "捉住", "波斯", "说来话长", "号房", "诸神", "worried", "很感兴趣", "博拉", "营救", "往事", "牢里", "press", "圣灵", "peace", "面对现实", "sell", "拨打", "旋律", "博客", "share", "无法忍受", "怀抱", "出入", "做過", "时常", "剧", "任性", "桑尼", "他长", "抖", "叉", "厄", "规律", "証", "人格", "抬头", "expect", "找寻", "瘫痪", "转弯", "几十年", "人头", "yo", "康", "艾拉", "節目", "碰头", "你還", "請問", "entire", "答", "很近", "敬礼", "不該", "买单", "父王", "寄来", "天知道", "設計", "教书", "記者", "我活", "没干", "此处", "碭", "十万", "奔跑", "面对面", "using", "莱斯", "交流学习", "猫咪", "螟", "发光", "卡罗", "收据", "在此之前", "氣", "上床睡觉", "试一试", "罵", "熊猫", "刘易斯", "族", "cop", "盈利", "拿破仑", "不至于", "巴德", "旁邊", "另一只", "vincent", "上岸", "能比", "房东", "輕人", "冇", "如果说", "情妇", "莉娜", "恳求", "上方", "x光", "达斯", "brody", "水下", "奏效", "好美", "忙碌", "多个", "太郎", "退学", "手续", "走动", "全靠", "尽我所能", "并未", "撕", "樱桃", "自我介绍", "嘞", "权限", "朱迪", "狀態", "花生", "之战", "逛", "镇静", "梅尔", "charge", "粗", "痊愈", "吻合", "sing", "请教", "防线", "地窖", "复活节", "保险公司", "不当", "打到", "不上", "歹徒", "挚爱", "冒出来", "亚特兰大", "荣誉出品", "科特", "惊慌", "狀況", "private", "激活", "皊", "動物", "江湖", "jesse", "新年快乐", "省省", "test", "竞赛", "惊吓", "現實", "远处", "迪伊", "强暴", "要給", "自卫", "强硬", "后果自负", "新鲜空气", "听得见", "垫", "含义", "车票", "豆腐", "record", "绑起来", "内特", "瞪", "深爱", "頗", "战机", "布兰登", "怀里", "刻薄", "问起", "st", "无耻", "淹没", "坏话", "折腾", "电击", "不及", "嘉宾", "艺人", "stick", "草地", "katherine", "妳是", "walking", "隐蔽", "华特", "中东", "华尔街", "激励", "隨時", "愧疚", "缉毒", "胜任", "中毒", "童话", "三角", "某個", "趴", "皮埃尔", "蜥蜴", "一发", "怀", "罗尼", "加把劲", "人工", "付款", "村长", "测量", "太慢", "nzt", "田", "超时空", "赞助", "那栋", "这台", "舞伴", "我生", "聲", "漏洞", "人來", "哪天", "快感", "通通", "鳥", "暴徒", "小妹妹", "出發", "崭新", "失效", "回电", "设想", "汉", "起身", "america", "有话要说", "sind", "打出", "凤凰", "上瘾", "脚印", "唱得", "模特儿", "non", "夏季", "旅館", "russell", "退缩", "yesterday", "一滴", "咒", "popsub", "内森", "湾", "漏", "真可怜", "thinks", "此案", "致死", "booth", "saul", "份子", "小看", "珊瑚", "wilson", "christian", "心臟", "situation", "藏身", "马可", "胡", "helen", "发脾气", "来杯", "可用", "许", "大餐", "母", "岗位", "finish", "下星期", "low", "qu", "这支", "受够", "困在", "混账", "太空船", "规划", "撒謊", "纪念品", "裂缝", "过错", "超自然", "noch", "哈克", "fighting", "电视机", "震动", "打火机", "热水", "raj", "图案", "索菲", "琪", "奶牛", "這點", "点击", "上車", "睇", "泡沫", "空调", "欲", "腹", "残骸", "削减", "斯塔克", "瑞恩", "带回去", "情人节", "大军", "虎", "配不上", "口水", "酒保", "高中生", "药品", "破壞", "鹦鹉", "轰炸机", "伯恩", "宋", "eva", "兰德", "发音", "庆典", "linda", "拉开", "随机", "底", "公", "七月", "肚子饿", "凡事", "奶", "哪去", "匕首", "这起", "不斷", "brain", "浩", "中止", "变形", "ball", "swear", "一类", "畏惧", "达尔", "當你", "生前", "眼下", "废墟", "千年", "最終", "有幸", "疲惫", "纠结", "挑剔", "加快", "背面", "真没想到", "問問", "卡门", "硄", "银", "渣", "孽", "警惕", "桃子", "人马", "handle", "這場", "一两个", "提取", "paid", "液体", "greg", "冰激凌", "新奥尔良", "举止", "腹部", "召开", "spent", "龙虾", "暴躁", "庭上", "问题所在", "政治家", "伤疤", "侦察", "切除", "踢球", "添麻烦", "油漆", "ー", "国防部", "我成", "体系", "卡利", "尼娜", "聪明人", "心事", "這一點", "认错", "拔", "内尔", "赐", "价", "心烦", "授予", "force", "即刻", "记下来", "bruce", "南非", "evening", "黛西", "知晓", "挖出", "捐", "藉口", "我选", "无赖", "karen", "来来来", "泡妞", "增强", "培根", "格斗", "调用", "碰撞", "纠正", "数据库", "feels", "聚在一起", "ﺋ", "看似", "keith", "真能", "法西斯", "boat", "小猪", "回国", "阿杰", "ﻒ", "亿美元", "农夫", "相当于", "fair", "得意", "爱好者", "脫", "繁殖", "渡过", "乡巴佬", "决不会", "cross", "tv", "带路", "crime", "鲁莽", "怨恨", "搜集", "ユ", "地獄", "斯坦利", "赛斯", "station", "竞技场", "抑制", "钢铁", "布洛克", "祭", "落到", "已知", "辣妹", "对准", "天主", "挺住", "疑惑", "酒馆", "slow", "冒昧", "key", "club", "台阶", "偿还", "ﻼ", "認", "我数", "拉克", "作案", "sich", "看不起", "扩散", "午安", "犬", "missed", "class", "身亡", "seriously", "劈", "annie", "雪梨", "随心所欲", "布鲁诺", "暗号", "战友", "自责", "令人兴奋", "包包", "burn", "点半", "再生", "坐飞机", "蚊子", "改编", "妒忌", "公尺", "诺夫", "想不起来", "启发", "大都会", "price", "补", "julia", "收钱", "harold", "清空", "适用", "来信", "personal", "观念", "我愿", "尼古拉斯", "杰弗里", "知情", "超過", "忠心", "弗林特", "走来", "table", "奈", "发电机", "演示", "大块头", "社团", "holding", "count", "无助", "emma", "中途", "hasn", "神灵", "詞", "那笔", "进度", "提早", "英國", "軍隊", "cat", "辛格", "案例", "焦点", "太阳系", "围巾", "斯托", "后台", "面部", "契约", "kira", "talked", "关灯", "剧终", "寄生虫", "standing", "叛军", "开花", "关照", "当选", "杰里", "杰斯", "娜塔莎", "兽", "言论", "沒見過", "愚弄", "营业", "姜", "两件事", "流放", "ﺏ", "有家", "先别", "里尔", "ﺛ", "群体", "爪子", "债", "reed", "程式", "私生子", "歪", "罐头", "叹息", "塞斯", "仍旧", "致", "球迷", "求助", "子民", "绷带", "majesty", "轻微", "团伙", "便会", "自找", "有助于", "湖边", "阿德", "漫步", "他現", "明信片", "驚", "olivia", "传球", "应用", "爱尔兰人", "beth", "条约", "教士", "军火", "用作", "斯隆", "内心深处", "艰苦", "partner", "流动", "后备箱", "计时", "告发", "用枪", "畢業", "前台", "相當", "报名", "班长", "哈妮", "從來", "别介意", "莫妮卡", "更改", "小兰", "成分", "enjoy", "fell", "马尔科", "法國", "stopped", "猛烈", "改成", "west", "马赛", "发狂", "注入", "更衣室", "监护人", "道格拉斯", "forgive", "during", "放出", "解剖", "董事", "真面目", "一度", "银河", "真令人", "沃德", "听众", "碰过", "患有", "木", "小路", "澄清", "拉拉", "单词", "抢走了", "犯规", "当上", "不久前", "同學", "预知", "全力以赴", "ho", "属", "totally", "坦白说", "暮", "靠着", "wearing", "内阁", "肿瘤", "快递", "四分", "stars", "营养", "胡說", "age", "や", "汽車", "扯平", "察觉到", "盔甲", "yang", "乖孩子", "summer", "公鸡", "天主教徒", "很烂", "fix", "丽", "回信", "铅笔", "小声", "善于", "乔希", "顽固", "彩排", "恰好", "屁事", "短裤", "中文", "没钱", "冷酷", "責任", "警", "选出", "凉爽", "联调", "招牌", "勋爵", "送命", "受损", "within", "电视节目", "兜风", "偷听", "螃蟹", "啰嗦", "snow", "再用", "冬季", "上钩", "揪", "登场", "酸奶", "榜样", "场地", "布莱斯", "general", "共和党", "簆", "融合", "降", "乐器", "肋骨", "心愿", "support", "理念", "行李箱", "胸罩", "鸡鸡", "样品", "管制", "屁话", "judge", "精细", "祝您", "佐", "東尼", "去向", "隆", "邮局", "巨", "视觉", "不應", "辣椒", "金刚", "准许", "南边", "感应", "培训", "哑巴", "伊尔", "鲍伯", "那帮", "bell", "蕩", "谱", "炸毁", "氨", "头晕", "alice", "未能", "没戏", "強", "郁闷", "尤金", "下方", "都还没", "相识", "attention", "兰迪", "洪水", "理所当然", "刻", "格伦", "野外", "部下", "胜", "虚伪", "奥斯汀", "说说看", "夺取", "至关重要", "這對", "尸", "透明", "赛门", "risk", "倾诉", "離婚", "本周", "真人", "cell", "sitting", "象是", "我方", "性行为", "聆听", "指挥部", "财务", "train", "很爽", "弄伤", "edie", "有车", "美极了", "前男友", "监管", "卢比", "冰河", "利兹", "证物", "真得", "grand", "读者", "去一趟", "打住", "教官", "出轨", "荒野", "plus", "周年", "办好", "认不出", "别怪", "白白", "郊区", "捍卫", "bear", "煎熬", "统统", "刑事", "泥土", "apartment", "我問", "当面", "搅", "就绪", "承認", "小熊", "僊", "葬", "reach", "指使", "奥利", "吐出来", "失手", "宙斯", "足夠", "扒", "茱莉", "不足以", "意味", "结实", "放走", "书籍", "犯傻", "争执", "画廊", "安东尼奥", "耽搁", "haben", "旅", "脱下来", "快回去", "别着急", "无用", "christ", "种类", "弗兰基", "san", "對方", "诡计", "hab", "seconds", "体型", "犧牲", "新世界", "interesting", "那片", "父", "習慣", "合作伙伴", "trip", "跺", "拿回去", "之神", "river", "各种各样", "灵", "六月", "大城市", "相见", "anthony", "拍档", "体", "扫兴", "瑟夫", "同情心", "女主角", "神龙", "与你同在", "盗窃", "维特", "蕾丝", "钟声", "我應", "原子", "completely", "并不需要", "布拉格", "卡莉", "主宰", "扔出去", "科斯", "art", "jon", "精致", "cops", "说说话", "抱住", "特色", "照亮", "card", "百老汇", "绞死", "显而易见", "雾", "冲着", "粉色", "兑现", "龙卷风", "城墙", "寿司", "这不关", "逛逛", "垛", "委托", "护理", "前去", "娃", "short", "疗法", "西瓜", "想不出", "矿工", "矗", "分数", "皇冠", "具", "阿布", "米兰达", "seat", "探", "虚假", "激光", "roger", "告密", "寺", "caleb", "太紧", "妳在", "标题", "瞎说", "多管闲事", "慢走", "前一天", "干预", "快些", "涉嫌", "举手", "gift", "礼", "持枪", "幸亏", "芭蕾", "福克斯", "ntp", "进水", "快來", "房客", "里根", "hill", "一事", "空白", "黑道", "光辉", "诈骗", "找麻烦", "forward", "配方", "占有", "提姆", "沃", "暫時", "门票", "温和", "丽贝卡", "接替", "stone", "向着", "兜", "報", "具备", "交配", "兽医", "伯父", "门上", "certain", "书房", "突出", "時刻", "要生", "教徒", "祂", "伴娘", "斩", "深感", "快活", "反复", "路德", "副本", "窗子", "天性", "level", "一開始", "雨水", "扰乱", "多重", "胆小", "纽", "上星期", "底线", "橡胶", "晕倒", "鸭", "智商", "打爆", "哋", "grab", "丹麦", "投手", "长城", "正点", "ne", "像样", "手头", "后方", "goodbye", "gay", "vous", "伞", "信用", "海面", "ﺜ", "头骨", "spend", "高尔夫", "之手", "心理学", "fish", "盟军", "伸手", "看望", "侠", "争夺", "锤子", "辜负", "一輩子", "录音带", "篇", "connor", "万能", "尼古拉", "刑警", "靡", "出钱", "许可证", "wear", "槽", "デ", "延长", "提案", "发短信", "fnzhunyuan", "fncalibri", "过不去", "偏", "拉丁", "进晚餐", "姊妹", "法子", "视力", "不來", "wonderful", "刷牙", "導演", "同类", "伊斯", "避难所", "艾米莉", "直线", "眨眼", "放置", "眼睁睁", "在座", "从头开始", "des", "十岁", "剂", "科夫", "顶部", "agree", "室内", "染上", "公公", "吧台", "懒得", "为荣", "全能", "发来", "cole", "時代", "淋浴", "upon", "權利", "实行", "moon", "法则", "window", "认", "雕塑", "冰川", "輸", "percy", "穆罕默德", "领导者", "占用", "多米尼克", "服侍", "安眠药", "然後我", "繁荣", "升高", "luke", "offer", "共产主义", "群岛", "艾莉森", "eh", "起源", "planet", "怎办", "尚", "纪律", "向来", "jamie", "换掉", "大力", "加倍", "danielle", "匈牙利", "三分", "不妨", "都市", "朴", "真快", "五岁", "伊莎贝拉", "gardner", "查明", "手电筒", "地去", "美貌", "东边", "五号", "marry", "增援", "塚", "越狱", "格兰特", "炸彈", "小妹", "anne", "认输", "硬盘", "当下", "四号", "羆", "goddamn", "皮带", "麦特", "捞", "劳动", "犹大", "有時", "何况", "挑起", "更为", "扩张", "一个个", "来往", "area", "有次", "重返", "偉大", "cry", "留住", "舊", "司法", "坚果", "員", "毛骨悚然", "流星", "bernard", "无法控制", "罗伯", "兼职", "女主人", "作风", "留个", "睡一觉", "琴子", "太难", "嗓音", "不好受", "去掉", "阿拉伯人", "身手", "bank", "self", "三倍", "距", "weapon", "巴克斯", "broken", "深渊", "流泪", "好感", "漂浮", "路口", "重伤", "亲眼看到", "一团", "姐夫", "邓", "大个子", "挂断", "余地", "伯纳", "豆", "吉恩", "好歹", "扑克", "附身", "運", "痒", "交朋友", "这部分", "力克斯", "尿布", "code", "facebook", "我常", "阿姆斯特丹", "韦", "回话", "猫王", "赛马", "鬼话", "散开", "以為", "詹", "护卫", "eine", "倒计时", "造就", "消耗", "敲诈", "tea", "跳过", "绝", "延续", "闹着玩", "艾莉丝", "玩偶", "战俘", "這才", "照着", "visit", "车门", "夥計們", "smile", "claudia", "contact", "井", "停火", "麦斯", "devil", "绳索", "出品", "冷漠", "赎罪", "凶杀案", "西边", "克莱儿", "平息", "上楼去", "早起", "搭配", "捐赠", "维也纳", "decided", "第八", "樹", "francis", "矹", "住宅", "臀", "position", "绘画", "dress", "tm", "强行", "狝", "枪战", "交到", "公务员", "日志", "终生", "来时", "猁", "此时此刻", "darling", "技術", "旗帜", "不大", "帽", "为所欲为", "測試", "机动", "以來", "傍晚", "甘", "旅行者", "justin", "他会来", "一页", "锁门", "驹", "罗斯福", "不堪", "野生", "首要", "按时", "旅店", "不必要", "百分之百", "毒蛇", "腦袋", "辛普森", "示威", "弄坏了", "基金会", "埃德", "毁坏", "讲故事", "liz", "斯特拉", "人員", "问得", "singing", "点事", "主张", "小船", "战后", "bree", "逮", "胡萝卜", "娘们", "太陽", "奈德", "泪水", "露意丝", "开场", "流逝", "坚持下去", "錯過", "战利品", "ii", "harvey", "彼特", "barry", "差事", "含", "大妈", "生下", "玛丽安", "阿伦", "比方说", "剧场", "两件", "暴动", "瓦尔", "建筑师", "有益", "大大", "架子", "少尉", "太累", "华莱士", "开来", "walt", "开拍", "格利", "高興見", "外部", "昏倒", "真像", "马子", "口中", "scene", "击倒", "field", "許是", "fred", "剃", "内战", "教过", "洗洗", "签证", "果酱", "han", "凶案", "探测器", "高跟鞋", "收手", "鞠躬", "职务", "张嘴", "服務", "牵", "心痛", "申請", "多事", "不然的话", "路克", "手提箱", "熄灭", "拇指", "到场", "火辣", "集中精力", "嫁給", "飞去", "去查", "品质", "這條", "带个", "社会主义", "出演", "大方", "飞过", "诺斯", "最为", "好極", "鬧", "坚决", "卖命", "当前", "大惊小怪", "支持者", "希拉", "之心", "strange", "大嫂", "一如既往", "春", "instead", "還說", "用处", "roll", "款待", "这头", "复原", "ihr", "水上", "starting", "說明", "尼基", "乞求", "让步", "钉子", "姊姊", "暗中", "无名", "用户", "窃听器", "压根", "随你便", "可言", "那句话", "尖", "罐", "十五分钟", "冻死", "难听", "爆米花", "大衛", "曹", "疤痕", "級", "south", "驾车", "加利福尼亚", "这身", "薇薇安", "微不足道", "谈起", "依据", "北极熊", "热烈", "愈", "执法", "大佬", "关押", "los", "龙舌兰", "jump", "懷孕", "hotel", "上山", "预订", "曼尼", "芭比", "的确如此", "实习", "机车", "臭味", "反射", "moved", "觉醒", "certainly", "资本主义", "免", "回不来", "子宫", "分局", "内脏", "巢穴", "nancy", "消化", "录取", "微小", "舞步", "ـ", "起火", "快进去", "gundam", "淡定", "羘", "normal", "joey", "添", "木材", "通宵", "脑部", "温泉", "實在", "头衔", "г", "tim", "nine", "会议室", "吓跑", "鸟类", "用过", "山里", "named", "控制室", "巴顿", "把柄", "地表", "手工", "艾丽西娅", "安吉", "奖章", "百分百", "尼克斯", "ﾓ", "初步", "镇静剂", "咖啡店", "思", "骑兵", "拿手", "一百年", "湿透", "仙女", "这名", "节省", "双腿", "definitely", "地道", "一路上", "襲擊", "朱丽叶", "取回", "风趣", "特拉", "ways", "吗啡", "体温", "present", "keeping", "西西里", "炸死", "准圆", "项", "应有", "机师", "逍遥法外", "骨", "永别", "换句话说", "alexander", "一碗", "讨好", "家门", "衡", "彩票", "会谈", "movie", "同盟", "尤里", "不留", "弗罗", "這不", "陪审员", "額", "生效", "渴", "置信", "holly", "巴克利", "屁屁", "足迹", "一心", "那得", "ぺ", "刻意", "产", "肃静", "饱", "報警", "比例", "sasha", "亚当斯", "说道", "下毒", "刺青", "格蕾丝", "有心", "保持联系", "有用吗", "解密", "带点", "界限", "按计划", "减速", "发行", "truck", "某事", "第四季", "勒死", "奖杯", "皇宫", "clark", "烤箱", "恐懼", "沃伦", "有机", "ﻑ", "激发", "天然", "性欲", "大猩猩", "传输", "源", "德克", "苇", "線", "疑", "延迟", "佛罗伦萨", "christmas", "本地人", "粗暴", "日语", "阿波罗", "一點點", "阻止不了", "不太可能", "之树", "heaven", "不惜", "佩", "纪录片", "必需", "美国佬", "打印", "开灯", "莫非", "童子军", "统计", "总比", "好话", "诚意", "三名", "吉普", "夸", "是非", "上见", "排名", "艾丽", "圣地", "迫害", "药片", "避孕套", "這都", "逮住", "想都别想", "外科", "演技", "双重", "不管是谁", "来点", "自慰", "不坏", "牛仔裤", "消防", "上当", "盡力", "哥們", "這張", "興趣", "一局", "早點", "孟买", "一艘船", "鹅", "super", "威斯", "两千", "地产", "八月", "奇怪的是", "電腦", "扑", "停車", "常规", "夏日", "休斯", "前女友", "急需", "篮子", "京都", "勾搭", "买来", "祈禱", "角落里", "好过", "si", "內心", "两百", "小行星", "脚踝", "挪威", "睲", "密切", "没意思", "誠", "叭", "当地人", "一世", "吃光", "车队", "滿", "sue", "用手", "撞死", "武功", "鉴定", "青", "monica", "彗星", "死活", "早些时候", "proud", "野生动物", "順利", "太紧张", "build", "别杀", "还清", "神殿", "苏西", "华", "jackie", "伊甸", "捨", "卡西", "realize", "过量", "毒死", "永远都是", "豪", "畜牲", "阿迪", "捷克", "奖赏", "我行", "浑蛋", "银行家", "取悦", "眉毛", "恶", "條件", "胸围", "存款", "ﻐ", "松饼", "耻", "連", "航向", "赶出", "尹", "請求", "瓁", "奶子", "教教", "memory", "猫头鹰", "file", "对讲机", "野马", "时不时", "收工", "忠", "找份", "入侵者", "ce", "appreciate", "一桩", "教给", "arms", "卫兵", "化石", "弱智", "关机", "calls", "smell", "换上", "散发", "这会儿", "園", "贝壳", "琍", "事关", "贝卡", "挽回", "假扮", "流子", "预料", "谦虚", "一宗", "敌", "department", "target", "延伸", "笷", "靠边", "养育", "guns", "路障", "夏娃", "元帅", "休斯顿", "语音", "难道说", "这裡", "新加坡", "霉", "重案", "薄荷", "家里人", "干完", "计", "四次", "噓", "胡言乱语", "各種", "老布", "院", "莱利", "albert", "你会", "經驗", "伤痛", "网球", "rules", "希德", "剪掉", "魔王", "葡萄牙", "respect", "发过", "闯进来", "thousand", "瘋子", "卡洛", "袖手旁观", "出面", "stuart", "办案", "敬意", "赛尔", "歸", "阿公", "行驶", "亨", "山脉", "专栏", "沉浸", "万人", "老百姓", "好了吧", "奥地利", "继父", "验尸", "帐单", "发布会", "剂量", "完工", "调查局", "高山", "车道", "自负", "出过", "obviously", "这门", "揭开", "会变", "弗莱", "一死", "消遣", "カ", "佐伊", "本尼", "dem", "本杰明", "原子弹", "兩位", "兰亭", "上传", "關", "克特", "而来", "女皇", "康妮", "太忙", "驕傲", "愛我", "卡里", "过瘾", "我為", "口渴", "吃屎", "拿枪", "开到", "高尔夫球", "angela", "聊过", "房产", "动用", "中队", "诱人", "學", "jo", "法师", "温馨", "kalinda", "栋", "重罪", "natalie", "粉红", "盲人", "手淫", "国旗", "谅", "下集", "戒烟", "勾当", "消费", "商業", "章鱼", "至极", "锁住", "中风", "jj", "rain", "church", "芬妮", "逃命", "遗弃", "bought", "derek", "万分", "差异", "闭上嘴", "巴迪", "带枪", "欺诈", "圈圈", "缇", "救活", "不受", "巡警", "十八", "米娅", "拿点", "大喊", "雪橇", "查过", "madam", "桌", "马文", "让给", "精明", "耀眼", "里子", "pop", "一个半", "主义者", "glass", "庭审", "揭发", "开庭", "accident", "打成", "小宝宝", "katie", "打個", "chase", "退役", "莱尼", "香草", "偷袭", "上前", "謀", "我信", "大婶", "距離", "怪事", "综合", "明知", "反常", "栅栏", "丹佛", "萨伊德", "贵宾", "记起", "比萨", "洛根", "水流", "youtube", "空手道", "speaking", "ガ", "腰带", "許多", "失明", "盼", "分開", "布莱德", "气温", "surprise", "斧头", "smith", "说服力", "珍妮特", "guard", "wayne", "built", "皮尔斯", "你够", "挨饿", "学位", "prime", "混混", "衣物", "不許", "自制", "远方", "病例", "常有", "收起", "填补", "寄宿", "聽過", "火烧", "快好了", "笑一笑", "万元", "键", "艇", "翅", "法学院", "碧", "鲁迪", "布利", "为生", "从那以后", "服刑", "辛迪", "命案", "敌方", "命運", "律", "未曾", "光速", "黨", "大错特错", "接过", "mess", "含有", "柯蒂斯", "关上门", "六岁", "最差", "foster", "搞不清楚", "沃恩", "池塘", "厅", "没多久", "共有", "跟你走", "参军", "印第安", "逗留", "过节", "切开", "third", "滥用", "保羅", "粗糙", "依照", "交待", "小混混", "將來", "塔拉", "摇滚乐", "瑪麗", "风声", "威克", "lovely", "税", "丽萨", "没道理", "不可避免", "一旁", "睡个", "毒素", "stuck", "生理", "塔尔", "到位", "连线", "亚伯拉罕", "声誉", "運動", "驳回", "多嘴", "無關", "夜班", "睾丸", "飞弹", "闪光", "连累", "鼓", "密", "是否是", "澳门", "leo", "应急", "不好过", "妥当", "福斯特", "斯图尔特", "美洲", "医学院", "时钟", "研发", "弗吉尼亚", "球赛", "傀儡", "更换", "追赶", "dreams", "松手", "种植", "廣告", "路西", "联手", "归还", "ﻂ", "侦查", "九年", "塑造", "就會", "之類", "双语", "一二三", "遍布", "自有", "专长", "driving", "开过", "im", "没完没了", "miller", "nina", "糖尿病", "這有", "恐怖份子", "胜负", "协商", "molly", "無所謂", "mission", "大喊大叫", "grey", "盘问", "许愿", "陶德", "举报", "奇异", "智力", "锁起来", "不玩", "独家", "我並", "苏丹", "拆除", "第一条", "两块", "制裁", "脱下", "whether", "任意", "伤感", "shh", "喬治", "一线", "失灵", "请勿", "来访", "助", "性质", "evil", "看着办", "ゃ", "一輛", "重要性", "不朽", "日报", "几率", "行刑", "好奇心", "怀着", "呼喊", "flight", "字条", "一无所获", "储藏室", "掰", "維", "卡爾", "不已", "pleasure", "耳", "brothers", "股", "jess", "控制中心", "评判", "mickey", "吉斯", "分歧", "现", "有够", "tired", "叛国", "乳酪", "慈悲", "佳", "照相机", "lawyer", "难熬", "哪条", "指派", "丢弃", "人行道", "期盼", "延期", "招供", "wine", "陨石", "喜不喜欢", "裔", "walker", "记错", "剩余", "共和", "拍到", "埃米", "感到高兴", "水泥", "girlfriend", "别装", "克利", "异教徒", "汤普森", "光彩", "福音", "买不起", "原先", "婶婶", "惭愧", "杰伊", "莱赣", "一棵", "触发", "十四", "司法部", "芭蕾舞", "拍下来", "拦", "尽管如此", "莲娜", "а", "一英里", "街角", "quickly", "路径", "警徽", "多种", "不适", "double", "好开心", "当兵", "散布", "小鱼", "下跌", "一通", "九月", "过床", "嚷嚷", "曲棍球", "戈尔", "档", "relationship", "honest", "lynette", "全部都是", "王室", "whose", "bigger", "神仙", "仔細", "names", "乌", "缺席", "捕获", "letter", "光顾", "弄坏", "很早", "search", "史都华", "轮子", "饥渴", "滑板", "启示", "方向盘", "fiona", "军士", "computer", "比利时", "不死", "制", "接纳", "ﻈ", "克莱德", "野猪", "愛上", "那部", "癳", "跨", "年级", "挪", "足", "ッ", "胡思乱想", "要学", "brad", "迟些", "magic", "顿饭", "天分", "報紙", "差错", "ﻏ", "衣", "憑", "电视剧", "雷克斯", "用尽", "意見", "按下", "丧生", "那台", "对比", "单子", "共识", "總有", "實驗", "照耀", "整齐", "民主党", "嗬", "结案", "正中", "天大", "手帕", "唬", "一盒", "看点", "顾虑", "胆敢", "新车", "揉", "辩方", "初中", "终究", "酚", "昨日", "beyond", "名下", "多难", "空袭", "蟹", "威廉姆斯", "定期", "落地", "幻象", "玉", "头条", "保全", "十一", "那根", "bailey", "kyle", "秘诀", "ﾏ", "困", "蠉", "顯示", "試著", "lucas", "画像", "接住", "可惡", "设立", "傳", "变种", "成名", "orders", "daisy", "frankie", "热带", "毀滅", "泰山", "这些年来", "坠机", "醚", "送往", "消逝", "牙刷", "参考", "泡菜", "人用", "货币", "一路顺风", "火药", "条例", "恢复正常", "今天上午", "很難", "被害", "第九", "放入", "迷住", "寺庙", "步兵", "舱门", "饶恕", "个个", "對付", "大家庭", "挑衅", "敏宇", "绑匪", "allen", "阿根廷", "呸", "凯恩", "天后", "分居", "心血", "clothes", "痴", "公车", "痴迷", "表姐", "机枪", "一天到晚", "黛安", "要塞", "反省", "咋样", "几条", "百万富翁", "yep", "crap", "盖茨", "祸", "戏剧性", "番茄", "塞巴斯蒂安", "特区", "kenny", "化身", "弯曲", "二十分钟", "tree", "劫", "可信", "碍事", "above", "富裕", "笲", "一言为定", "啃", "看管", "常说", "places", "心扉", "radio", "兩次", "bastard", "shame", "看作", "ㄏ", "johnson", "奖品", "重逢", "胶带", "有何贵干", "新兵", "诸如此类", "包子", "尊贵", "hole", "雇主", "替身", "金牌", "吸气", "高点", "精心", "夜店", "收容所", "宣战", "飞到", "很怪", "花园里", "大气层", "不知不觉", "近距离", "到头", "幅", "搭讪", "drunk", "difference", "移", "里拉", "se", "參", "歇斯底里", "欣慰", "winter", "小雪", "洗礼", "花瓶", "gordon", "十月", "八岁", "行家", "娘娘", "吃个", "马力", "唐纳德", "victoria", "嚟", "精液", "wind", "頂", "真行", "灵活", "入江", "悬赏", "dana", "突击队", "克里夫", "一千万", "awesome", "中世纪", "统治者", "五万", "死不了", "消毒", "膨胀", "好时机", "瓜", "灯塔", "老鹰", "過得", "宽容", "困難", "跟进", "报上", "别出", "称赞", "twice", "罗德", "控制不了", "那句", "面罩", "橘子", "在读", "上市", "微妙", "赶不上", "塞尔", "驯鹿", "海关", "莱昂", "纽约时报", "孕妇", "回事儿", "烟草", "不禁", "浪", "说定了", "厄尼", "树叶", "鹰", "jean", "下达", "choose", "看不清", "大气", "想過", "老實", "forgot", "吞下", "宣判", "咖", "迟钝", "胎儿", "善意", "署", "逼近", "人偶", "carry", "丟了", "头目", "三月", "justice", "两颗", "隨", "书里", "亵渎", "恩赐", "不谈", "上报", "身影", "术", "分头", "休息室", "被子", "那艘", "公关", "交战", "额头", "咖喱", "特斯", "初恋", "中部", "反过来", "堕胎", "奴役", "紅色", "演说", "第一场", "瓦解", "凯茜", "粥", "lived", "分给", "利奥", "感激不尽", "启程", "报价", "刺伤", "凯旋", "gabriel", "阿尔法", "特勤", "碰见", "库克", "lester", "十六", "邮箱", "婆娘", "潮湿", "小兄弟", "grow", "北美", "委员", "再給", "那就是说", "sad", "生日派对", "打不开", "畍", "盗贼", "三八", "崇高", "前天", "欢笑", "巴布", "修正案", "先给", "生火", "层面", "提起过", "自從", "找找看", "線索", "大吃一惊", "韦伯", "putting", "陆战队", "海域", "实话实说", "富", "泡泡", "洛基", "化验", "impossible", "職業", "恶人", "影", "境地", "board", "资讯", "衣橱", "幢", "圈子", "玷污", "讚", "频繁", "海浪", "活活", "潜水艇", "那首", "后援", "竭尽全力", "钓", "倒闭", "vega", "控方", "四分之一", "切尔", "闲逛", "纤维", "藝術", "老式", "咳", "的頭", "ﾝ", "舍不得", "喷泉", "木星", "worst", "眼球", "征兆", "描绘", "失眠", "廁所", "亞", "埃伦", "洗脑", "一次性", "擂台", "hundred", "骷髅", "首", "老套", "dennis", "發展", "想些", "access", "做個", "痙", "sally", "缓解", "瞴", "锋利", "巡演", "几秒钟", "芬", "治好", "争", "为时已晚", "手艺", "侵略", "fit", "大名", "如下", "专用", "萬歲", "fool", "媳妇", "科拉", "大雨", "ﻃ", "点头", "狄", "owe", "london", "路亚", "周到", "鼠", "智能", "稳", "我該", "竞争对手", "处方", "finished", "战车", "boyfriend", "告白", "传单", "别挡", "萎", "折", "击落", "一袋", "窾", "dir", "乏味", "躲藏", "数百万", "不要脸", "island", "weapons", "冷冻", "文斯", "狼人", "一排", "每一件", "病态", "岳父", "我住", "体育馆", "ダ", "earl", "ば", "学学", "灿烂", "我关", "使出", "呼气", "预见", "拖住", "幹得", "marty", "joseph", "前進", "定居", "抽出", "航空公司", "金库", "gibbs", "孤立", "小意思", "圣诞礼物", "µ", "重演", "猜猜看", "肝脏", "慕尼黑", "尼科", "环球", "锦标赛", "皐", "干酪", "查出来", "糟蹋", "crew", "用钱", "卫生", "大大的", "杰里米", "themselves", "摩洛哥", "想像中", "dexter", "后备", "別管", "全城", "品", "弟子", "有点累", "新型", "最爱", "走狗", "卡通", "背心", "asshole", "切斯特", "混在", "名牌", "封印", "rex", "婚纱", "外卖", "quinn", "登山", "杂货店", "顏色", "小可爱", "向前走", "我無法", "这根", "foot", "特利", "骚乱", "hunter", "翘", "闪烁", "克兰", "咗", "劫匪", "relax", "为您服务", "decision", "验证", "比較", "cash", "真傻", "外科医生", "死尸", "bunch", "指数", "二战", "这趟", "全心全意", "不听话", "党卫军", "七天", "餐廳", "种种", "聽起", "teddy", "不良", "出声", "除去", "matthew", "cass", "这类", "闷", "弄脏", "几百万", "骗过", "involved", "外号", "骑车", "雷德", "保龄球", "似", "被控", "dollars", "囧", "潜意识", "三分之一", "默", "境界", "瑞安", "克制", "争斗", "下台", "出汗", "血清", "雲", "憋", "财政", "某種", "prove", "出版社", "nathan", "靠你了", "太冷", "伯纳德", "動作", "dying", "不负责任", "传真", "羔羊", "彭", "啥意思", "南极", "汁", "甘心", "ゅ", "误导", "lincoln", "爱心", "这天", "未成年", "只顾", "湯姆", "粪", "jackson", "fucked", "眼熟", "岸边", "耗尽", "college", "平原", "约束", "空间站", "相亲", "看成", "分明", "合成", "略", "伊莉莎白", "瑟", "移开", "三条", "办公桌", "恨死", "地想", "ann", "喝多", "镜", "宣告", "意義", "黑市", "驚喜", "碉堡", "debra", "玛吉", "兔", "情報", "认出来", "摔下来", "缅甸", "艾连", "apart", "西卡", "父子", "打烂", "反感", "恩典", "哈瑞", "动画", "泳衣", "克劳迪", "打伤", "蘋果", "真心话", "集结", "公交车", "主公", "金额", "贝斯", "要开", "克劳德", "同步", "之力", "电邮", "关乎", "肤色", "阿米", "过奖", "east", "假日", "刚来", "看得", "疲倦", "改进", "王冠", "部隊", "投资者", "时间表", "性骚扰", "莱德", "选民", "列表", "遮住", "传唤", "ourselves", "纯属", "解决办法", "想通", "跳得", "手镯", "lunch", "figured", "这所", "六十", "脑中", "解决方案", "厘米", "推理", "一打", "鄰居", "用品", "小屁孩", "最高法院", "遗言", "教区", "有害", "哪家", "紧密", "纸巾", "詹森", "话语", "西伯利亚", "牆", "妦", "天线", "账", "打烊", "要麼", "深深地", "戀", "完善", "掃", "重现", "新家", "愈合", "去過", "四個", "爱是", "流传", "治疗师", "持", "手势", "公道", "建成", "需要的话", "味儿", "维多", "佐藤", "伤员", "拉丁语", "教养", "辅助", "凯斯", "代理人", "address", "琢磨", "重新考虑", "克劳斯", "suspect", "结过婚", "闲聊", "哈桑", "大错", "我告", "做什麼", "水牛", "下棋", "竊", "没电", "不择手段", "到头来", "限度", "逃不掉", "运到", "动人", "loves", "弦", "活不下去", "掏出", "lock", "造反", "特瑞", "最难", "cute", "小精灵", "美景", "唐纳", "沙龙", "烟囱", "付清", "奉命", "arrest", "interested", "总要", "帮人", "淘气", "我别", "降落伞", "becky", "不杀", "错乱", "身心", "活过来", "密封", "如你所愿", "跳伞", "拧", "觉悟", "低级", "何時", "懲罰", "搭车", "救助", "强力", "朵", "嗅", "恶灵", "心头", "斗士", "你明", "耳光", "一方面", "烟花", "十五年", "漆黑", "派来", "脸颊", "raise", "lo", "讲完", "horse", "字眼", "指证", "凶杀", "不值", "请假", "癖", "雅克", "法拉利", "一盘", "christina", "汉森", "april", "左侧", "糗", "趁现在", "訴過", "行得通", "发掘", "牛津", "阿特", "芥末", "action", "清洁工", "水准", "开张", "跳进", "没睡", "实践", "環境", "弄掉", "感興趣", "充斥", "起始", "罗西", "聯邦", "忘却", "事上", "原告", "克罗", "超棒", "無聊", "catherine", "冷淡", "脱光", "起点", "camera", "tough", "stole", "留心", "鱿鱼", "迷茫", "糶", "进食", "半死", "抬高", "储存", "beer", "撿", "捕鱼", "likes", "很烦", "jones", "兵力", "greatest", "珂", "受得了", "血型", "之星", "放马过来", "拭目以待", "喝點", "那時候", "富兰克林", "苍白", "upset", "擺", "供给", "前后", "金枪鱼", "books", "problems", "棍", "萝丝", "豁免", "泊", "挂掉", "拥挤", "我照", "aah", "过活", "茨", "hero", "拖鞋", "哆", "這份", "掷", "講話", "霍布斯", "二氧化碳", "编造", "地點", "雄性", "怒火", "我留", "這樣子", "开幕", "凑", "防护", "极为", "想开", "璣", "不见得", "乐乐", "殺手", "有過", "吉野", "班克斯", "變態", "乾淨", "但現", "事发", "简报", "德行", "平静下来", "吉普赛人", "无法解释", "进门", "学过", "沐浴", "主义", "聘请", "想当", "保險", "西蒙斯", "通报", "做主", "doubt", "罗杰斯", "阿斯", "餐", "逝去", "普遍", "變化", "学园", "劳驾", "心目", "教学", "很深", "次郎", "看透", "家门口", "国防", "止血", "上學", "人世", "区分", "everywhere", "参议院", "規矩", "爱意", "搭乘", "暴君", "猎犬", "へ", "lewis", "監視", "美梦", "伤到", "玛拉", "拼图", "信箱", "嘗試", "gas", "豪宅", "鍾", "克尔", "点到", "利尔", "周边", "百年", "偷偷摸摸", "牵连", "几件", "神經", "问话", "大洋", "旅途愉快", "運氣", "可见", "高明", "睁", "播报", "並沒有", "剧情", "平安无事", "严密", "镇压", "加以", "九岁", "意想不到", "逛街", "抓紧时间", "花样", "胜出", "練習", "english", "緊急", "donna", "衬衣", "turns", "慢下来", "national", "褲子", "穌", "撐", "任由", "亲属", "魔女", "胶片", "勺子", "画作", "你哥", "坚守", "罗丝", "パ", "污点", "微弱", "ъ", "初次见面", "慾", "仁", "時光", "电车", "搞不定", "玩牌", "kick", "动手术", "寂静", "secretary", "レ", "叛乱", "里斯本", "饰演", "源自", "赵", "萬一", "通告", "不全是", "抓捕", "组建", "duty", "那可真", "價值", "外加", "净化", "歧视", "敏捷", "losing", "gives", "cutter", "hungry", "helped", "弱者", "灰姑娘", "排斥", "三岁", "压迫", "特雷", "卢卡", "叙利亚", "這會", "致力于", "长老", "bin", "啲", "盉", "阿什", "格罗", "日后", "日内瓦", "权益", "zoe", "一文不值", "橙色", "回憶", "逊", "掐死", "斯诺", "通行", "碍", "danger", "只能靠", "电流", "區", "meredith", "赖", "烧焦", "这歌", "水源", "茄子", "救过", "弄清", "赫尔曼", "工地", "人权", "尽力而为", "可愛的", "被盗", "土壤", "光头", "姿态", "暴行", "garcia", "马上会", "印记", "science", "很忙", "思議", "船長", "毕生", "一曲", "特警", "能用", "跳蚤", "bb", "一战", "這段", "率", "迁徙", "混淆", "mail", "不便", "达克", "止痛药", "搏斗", "whoever", "狙击", "denn", "過程", "肝", "皮条客", "课堂", "自便", "对外", "海瑟", "sake", "表白", "手稿", "太热", "拆掉", "温斯顿", "美偶", "兩年", "vote", "柯林斯", "spot", "ヘ", "厨", "家裡", "假裝", "俄亥俄州", "faith", "哲学家", "睁开眼睛", "听错", "貼", "锅", "学姐", "關鍵", "高科技", "杜威", "locked", "星座", "读完", "花生酱", "一粒", "度蜜月", "潜伏", "蜗牛", "铐", "篇文章", "那去", "鄉", "停职", "手拿开", "稀有", "来此", "搬到", "一脸", "帶著", "拔掉", "简历", "窃取", "再犯", "降到", "取胜", "我管", "吸入", "导航", "卡罗琳", "id", "周圍", "出世", "几杯", "所謂", "談話", "百合", "躯体", "年紀", "一腿", "所作", "eve", "地形", "赐给", "第一批", "激動", "维斯特", "肾", "曼谷", "姓氏", "果冻", "多加", "上膛", "广阔", "讨厌鬼", "天皇", "热量", "徐", "商量一下", "西班牙人", "cristina", "五角大楼", "favorite", "重获", "laura", "只得", "victor", "胜利者", "store", "偷窥", "major", "傑克", "木板", "出城", "favor", "弗兰西斯", "餐桌", "冻", "accept", "棵", "无缘无故", "格温", "修车", "恐怖主义", "瞅", "下沉", "耳边", "拷问", "别误会", "大嬸", "滿足", "孤身一人", "折断", "得手", "真巧", "很远", "这杯", "黑手", "游乐场", "雕刻", "物资", "客戶", "bones", "idiot", "match", "开往", "太贵", "懂不懂", "劫持", "耳机", "入境", "惯例", "我些", "跳出", "很多很多", "pictures", "舞厅", "美人鱼", "救回", "忠于", "我输", "溺水", "阿姆斯特朗", "恐怖袭击", "大厨", "洞里", "下車", "内在", "相伴", "煙", "拉比", "尿裤子", "士气", "满是", "黑白", "victim", "正向", "天杀", "苛刻", "来宾", "video", "薯片", "发达", "现有", "卡森", "安抚", "保利", "神庙", "萝拉", "流产", "那会儿", "鞭子", "jennifer", "wrote", "mate", "teach", "小命", "麥克", "奥运会", "百", "肾上腺素", "專業", "dust", "doug", "丽亚", "送货", "邮票", "体现", "抗生素", "米特", "赞赏", "讨论一下", "太长", "麻", "罚单", "古拉", "现状", "麦片", "知觉", "neither", "合身", "一月", "洪", "嗒", "果实", "车库里", "不合理", "arm", "doc", "实习生", "替换", "轻而易举", "united", "开端", "加热", "特质", "跑出去", "经费", "alison", "骰子", "宣言", "一来", "還得", "避难", "生育", "寿命", "从未有过", "爬上去", "扮成", "德克萨斯", "叉子", "卖出", "奴隸", "绕过", "紫龙", "抢银行", "累坏", "一说", "根本无法", "君主", "油炸", "科學", "会试", "大奖", "恩斯", "作主", "倾情", "hast", "天父", "持久", "蠢材", "掌", "mountain", "嚣张", "异议", "两半", "观光", "恰恰", "became", "对天发誓", "渔夫", "散散步", "徹底", "信使", "阵亡", "拐", "行尸", "巴格达", "很久很久", "面粉", "我永遠", "满脑子", "kann", "袖子", "威尔斯", "心理准备", "begin", "维吉尔", "檔", "演得", "越快越好", "data", "todd", "赛昂", "大房子", "向日葵", "说不出", "疏忽", "工钱", "joke", "日夜", "最长", "叮", "创始人", "盛宴", "穿梭", "想不通", "禲", "看不懂", "纹", "核对", "犹如", "抗", "面包车", "特德", "句子", "选美", "丽塔", "更深", "numbers", "诺克斯", "打手", "carol", "盞", "撤回", "那真", "愿不愿意", "爆破", "半辈子", "麻木", "牛顿", "試圖", "huge", "mason", "五次", "王朝", "铲除", "小麦", "写字", "解答", "酒瓶", "indeed", "卡斯蒂利亚", "黄昏", "宅", "wild", "恩彩", "ﻖ", "较量", "之情", "冷却", "lay", "盖伊", "啦啦队", "一走了之", "卡斯特", "胊", "腦子", "罪案", "serve", "敏锐", "枪械", "往回", "回頭", "棋子", "难吃", "投球", "热心", "后边", "玛格", "肩上", "找过", "看病", "輪", "摇晃", "sandy", "环保", "waste", "散播", "angry", "绝地", "波利", "睡过", "dogs", "合唱", "毛利", "館", "通缉犯", "learned", "巧妙", "剥", "本土", "我长", "巴尔", "聯絡", "哪能", "同一时间", "火美子", "母牛", "pulled", "妖精", "猎枪", "安琪", "滿意", "订购", "八成", "癌", "赫尔", "书呆子", "γ", "离不开", "进口", "挫折", "staying", "平行", "difficult", "告诉您", "糕", "dich", "佽", "阵营", "小菜一碟", "con", "冒充", "本意", "沙皇", "注意安全", "菲利", "啪", "电影明星", "挡路", "千真万确", "红灯", "skin", "放纵", "一塌糊涂", "反驳", "machine", "二十四", "无处", "海蒂", "房主", "灰烬", "绝佳", "樂", "成真", "急诊室", "跑车", "枪伤", "赶过来", "噗", "拋棄", "嗜好", "强奸犯", "鼓舞", "dirty", "fat", "对策", "手术室", "bottom", "昂", "louis", "小女儿", "興奮", "公告", "难度", "众所周知", "一清二楚", "robbie", "巴赫", "谋杀罪", "贝茨", "婚前", "挑戰", "车手", "敌机", "病患", "絬", "α", "蛋白质", "采集", "提夫", "渗透", "绝妙", "简短", "西德尼", "closed", "便当", "schon", "點兒", "dare", "威廉斯", "枪法", "监制", "波尔", "特点", "我將", "military", "园丁", "惧怕", "誤會", "eating", "岂有此理", "联邦政府", "舰", "自家", "加大", "品种", "肖像", "辩护律师", "飘", "绽放", "顶端", "迪安", "烟火", "贩卖", "直到现在", "bernadette", "退回去", "often", "拐杖", "面积", "真酷", "海绵", "我全", "股东", "夜空", "五块", "注释", "dash", "生意人", "没救", "天神", "灯泡", "伯尼", "南美", "驱动", "恶毒", "资本", "孤獨", "接听", "那点", "颇", "捐款", "装扮", "苏珊娜", "席", "ai", "过期", "用光", "奢侈", "wendy", "傷心", "阿尔弗雷", "冒險", "哥伦布", "ミ", "定下", "神通", "奔驰", "悄悄地", "站台", "晚飯", "献上", "个子", "劳埃德", "ceo", "医治", "煩", "次数", "过生日", "引领", "更强", "移動", "鲍里斯", "执着", "穹顶", "常识", "无数次", "打针", "布雷克", "却说", "往右", "揭穿", "分类", "苦恼", "情緒", "无害", "珀西", "不給", "你害", "neck", "日元", "遥控器", "广泛", "優秀", "一无是处", "教練", "breaking", "轻举妄动", "整座", "费心", "une", "敌意", "修补", "放着", "付费", "创新", "pat", "佣人", "塔米", "勝利", "杰基", "物理学家", "感知", "社", "豁免权", "一箱", "不道德", "别玩", "荷", "bbc", "麻雀", "希腊人", "christine", "將軍", "bringing", "盡快", "删掉", "让路", "圣诞树", "promised", "蒂尔", "放逐", "儿女", "hm", "判定", "大片", "维加斯", "口红", "紧迫", "围墙", "阿道夫", "mac", "这钱", "奥德", "三只", "一聲", "源头", "食堂", "drug", "外甥", "final", "错觉", "即將", "多半", "捉迷藏", "pour", "后背", "莱西", "天国", "炼狱", "直走", "酒杯", "约瑟", "tears", "窗戶", "摩擦", "十二点", "雪花", "埃德加", "撕开", "宝物", "叫喊", "医务室", "差距", "零食", "信號", "音乐剧", "蠋", "蒙羞", "princess", "洛夫", "朴荷", "切掉", "afternoon", "涨", "裁缝", "过会儿", "我军", "照样", "dale", "continue", "苏醒", "bullshit", "成員", "系好", "戒备", "listening", "martha", "上街", "超大", "郑", "伏击", "逃逸", "拳击手", "偷懒", "battle", "狗日", "浮现", "贫民窟", "心态", "他爸", "clock", "僵硬", "更长", "别像", "修建", "侧面", "悲傷", "伴郎", "原料", "柱子", "jail", "深海", "追究", "davis", "轿车", "醉酒", "傻话", "天氣", "嬷嬷", "ろ", "大局", "透透气", "外衣", "拆散", "目录", "杜克", "聖", "大帝", "抽筋", "beginning", "實現", "刑期", "extra", "国安局", "博格", "病得", "免于", "疗养院", "ex", "哪里找", "邋遢", "美容", "药店", "弗莱德", "兵团", "傻蛋", "热门", "混凝土", "幾年", "引开", "指认", "幻影", "小允", "摘下", "dawn", "卡伦", "羶", "露露", "连络", "睁开", "提斯", "丘吉尔", "那双", "地牢", "大兵", "免疫", "菲兹", "懒", "就会", "hector", "生个", "辽", "扛", "波波", "原型", "矣", "脑海中", "预告", "曹操", "弹钢琴", "典礼", "弟", "水池", "手动", "臣", "综艺", "ricky", "嗓子", "谢尔盖", "好怕", "冷战", "不忠", "觅食", "居", "э", "wei", "崩", "状", "我本來", "农业", "看重", "不知所措", "叛逆", "激进", "wondering", "谋生", "变老", "先走", "违抗", "单一", "helping", "变暖", "录下来", "沒見", "交火", "受了伤", "满月", "视", "再好不过", "麦当劳", "conversation", "克里斯蒂", "佐治", "picked", "愉悦", "债券", "备忘录", "渺小", "非常感激", "不容", "尼特", "伪君子", "皮包", "笑脸", "二世", "种族歧视", "衡量", "三年级", "布罗", "道格", "push", "荡", "道奇", "出門", "hiding", "護士", "便士", "土匪", "讨价还价", "mann", "地中海", "消停", "评委", "empty", "佑", "夏令营", "海贼", "亿年", "滑倒", "咖啡厅", "他來", "阑", "一块钱", "谷歌", "认知", "執行", "围栏", "好意思", "mia", "nur", "招惹", "witness", "华沙", "亚伯", "失忆", "角斗士", "騙子", "拉链", "重點", "枚", "高空", "几号", "体制", "尼莫", "鄙视", "两万", "由此", "飞来", "刺穿", "freedom", "致电", "传染病", "记不清", "铃木", "废除", "車子", "长发", "deb", "牧羊人", "出走", "祭司", "总结", "大好", "一见钟情", "nearly", "菜子", "进程", "local", "擦掉", "进球", "uns", "波动", "优美", "斷", "踹", "speed", "歐洲", "挑逗", "穩定", "罗兰", "董事长", "多斯", "壁橱", "龙哥", "国务卿", "留点", "邀請", "blame", "比基尼", "情书", "至於", "装傻", "会要", "约书亚", "捷径", "残暴", "管理局", "同谋", "beach", "橄榄", "rush", "弗利", "哈姆雷特", "戏弄", "有条", "千里", "快追", "那女", "天份", "能給", "细", "霍莉", "中間", "给我发", "纒", "引来", "fuckin", "来晚", "很長", "做點", "pack", "marriage", "比拉", "义气", "效率", "众神", "下潜", "煮饭", "雜誌", "揭晓", "脑筋", "harris", "讲个", "track", "flying", "我待会", "藉由", "射程", "新书", "褐色", "sammy", "写道", "铁轨", "辛", "普利", "趁着", "白费", "爱抚", "vince", "邂逅", "两百万", "大阪", "七号", "饭碗", "耶和华", "食谱", "乘以", "流感", "恭维", "美德", "西藏", "佣金", "乔纳斯", "远程", "迎来", "向导", "送过来", "巴拉", "掀起", "走投无路", "edward", "walked", "揭示", "查找", "水域", "感官", "鸦片", "原以为", "已故", "年里", "knife", "索菲亚", "切特", "十一点", "阿兰", "几分", "結", "包扎", "巷子", "康拉德", "做做", "阴暗", "阿什利", "刚到", "炉子", "梦想成真", "哈里森", "禬", "水槽", "不自在", "尘土", "simply", "papa", "義", "einen", "fad", "浅", "户外", "太子", "看中", "道尔", "死光", "参选", "裡的", "正是如此", "舍弃", "顺从", "停住", "西北", "驻", "enemy", "bomb", "否决", "兄妹", "更何况", "打通", "手举", "跳楼", "威尔士", "師", "城外", "bodies", "之道", "escape", "君子", "达西", "这得", "回音", "宝拉", "bird", "reese", "苏打水", "認真", "本论坛", "发育", "菜品", "指揮", "幹活", "历克斯", "管教", "客观", "忍住", "说教", "请进来", "hoping", "完好", "guilty", "惹火", "monster", "坐车", "要害", "椰子", "磨", "搭便车", "一针", "湖里", "败类", "跟不上", "沉没", "ﾉ", "荷娜", "帕拉", "interest", "嬰兒", "流淌", "保险柜", "星光", "同一天", "然後呢", "宾", "超速", "鼓手", "赤裸", "西恩", "吋", "乡", "即兴", "婚事", "randy", "克格勃", "支舞", "我親", "推进器", "罗曼", "tight", "郎", "完畢", "升空", "即可", "激起", "風格", "就給", "想像力", "床垫", "飲", "一课", "环节", "克雷", "拉德", "lied", "气质", "奥托", "一体", "你生", "神马", "弓", "ali", "起誓", "走得", "keeps", "大致", "六号", "基尔", "减", "换取", "usually", "murdered", "奇跡", "机灵", "states", "丰盛", "题目", "rule", "猎手", "科恩", "宠坏", "镇长", "一门", "英語", "醉鬼", "分解", "destroy", "法式", "猴", "冰层", "储备", "刽子手", "开球", "别挂", "吉塔", "啥时候", "脸蛋", "問", "knock", "磨坊", "口号", "bright", "绞刑", "顶多", "戴眼镜", "血脉", "登录", "不祥", "听得懂", "form", "真蠢", "石頭", "媽咪", "传教士", "溅", "孩童", "伪装成", "余", "ash", "青瓦台", "警司", "割断", "行尸走肉", "陪你去", "木乃伊", "decide", "反恐", "黑猩猩", "breathe", "世紀", "磨蹭", "唯", "彼得森", "维基", "踞", "不靠", "機場", "沿", "倒塌", "兩天", "录制", "盡量", "没人要", "談論", "目", "莫扎特", "干燥", "clip", "矮子", "个别", "bus", "base", "换来", "一试", "漏掉", "酱汁", "士官", "癥", "驱使", "mitch", "准则", "服从命令", "亚鲁曼", "跑不了", "鞭打", "法令", "团长", "peterson", "安好", "天鹅", "战神", "过往", "胶卷", "杏仁", "施舍", "伸展", "醒来时", "一棵树", "surprised", "微博", "海鲜", "全速", "重组", "偏僻", "很蠢", "圣徒", "liked", "惹事", "转达", "莉亚", "常理", "快上来", "属实", "奥黛丽", "气流", "rise", "可说", "可口", "castle", "血手", "经受", "奥克", "说唱", "aus", "瞬", "贏得", "cos", "短期", "门开", "suit", "记不起来", "委屈", "bloody", "牌照", "克里斯蒂安", "指教", "从今以后", "survive", "闹事", "俩个", "拳王", "小巷", "侦测", "頓", "赛季", "这使", "特务", "被绑", "弹头", "賤", "commander", "萨曼莎", "warm", "案情", "fax", "音符", "一二", "突发", "遵从", "定律", "禁区", "浣熊", "例行", "寸", "芬兰", "冰雪", "多些", "龍", "之物", "穿透", "外太空", "生锈", "红队", "曲", "willing", "travis", "容器", "恋情", "酷毙了", "免受", "壳", "莱姆", "下个星期", "聊聊天", "配备", "innocent", "倉庫", "的關", "选项", "阿诺德", "隆重", "mcnally", "马匹", "籔", "赛跑", "胡椒", "一年级", "turning", "三楼", "全在", "加薪", "导游", "七岁", "allowed", "人力", "熊熊", "seemed", "憤怒", "相连", "既然如此", "notice", "布满", "包袱", "识字", "allow", "高处", "打來", "dorothy", "嘉", "ned", "波兰人", "و", "步伐", "十倍", "放火", "播", "energy", "准備", "marcus", "令人震惊", "杯水", "煤气", "这道", "硬汉", "推开", "叛变", "剪辑", "肺部", "事来", "羊肉", "查德", "智利", "cindy", "复合", "舞會", "莱尔", "顶上", "迪士尼", "借此", "伙計", "李先生", "税收", "贫困", "术语", "threat", "妙", "魔法师", "苔丝", "汝", "簿", "荷尔蒙", "环绕", "别笑", "说来听听", "大批", "动脉", "互动", "朋克", "分不清", "一罐", "德罗", "大头", "自尊心", "乌克兰", "代價", "铭记", "一整夜", "ī", "里瑟", "account", "蓝图", "冷靜點", "装甲", "迈", "掐", "混血", "注重", "星期日", "没试", "捲", "帮得", "hunting", "龙神", "何种", "蓋", "受人", "买些", "摧毀", "quit", "首饰", "积蓄", "畸形", "特技", "大树", "太坏", "开饭", "爵士乐", "预想", "盖子", "商", "辅导", "盘", "農場", "登台", "steal", "上线", "廚房", "追到", "标本", "powerful", "同感", "雷恩", "十字路口", "北境", "城门", "三角洲", "gut", "待在家里", "note", "阿司匹林", "稻叶", "especially", "ford", "拎", "大意", "safety", "加德纳", "否", "顶楼", "正忙着", "达成协议", "活不了", "骚动", "银色", "喝光", "赫拉", "添加", "randall", "道菜", "眤", "化名", "东东", "拔出来", "山区", "光滑", "鲑鱼", "passed", "看护", "德文", "坚固", "匪徒", "staff", "存放", "做菜", "射手", "ron", "哈珀", "伎俩", "贏了", "风吹", "胆", "鎘", "铬", "scofield", "生化", "我念", "花招", "胜算", "ñ", "亚历", "我作", "工廠", "muss", "老年人", "僕", "reading", "試過", "ellen", "集市", "传感器", "萤火虫", "阿妈", "估計", "佛罗里达州", "operation", "經濟", "dylan", "experience", "ﾞ", "出头", "轻轻地", "各国", "一两天", "相聚", "不早了", "坎", "ﾍ", "进军", "何在", "gemma", "店主", "队里", "签了", "三种", "梅格", "填满", "驴子", "琥珀", "脊椎", "全场", "抛开", "賊", "梅斯", "會給", "反应堆", "喋喋不休", "拉夫", "keys", "下一個", "置于", "划船", "打声", "安然无恙", "shoes", "踏", "neal", "cameron", "狼群", "坨", "气死", "迷上", "山脊", "金鱼", "拉萨", "橙汁", "尘", "foreign", "太蠢", "回不去", "墓碑", "探访", "zero", "海姆", "壁炉", "几只", "薄饼", "切割", "nowhere", "杰克森", "伏", "巴尔的摩", "伊斯兰", "itunes", "邸", "右侧", "献出", "事兒", "蠁", "变为", "十二个", "趁机", "羛", "幾次", "威特", "congratulations", "形", "nicole", "承諾", "之光", "笔迹", "tells", "刮胡子", "帕斯", "珍娜", "普尔", "马里奥", "野狼", "菲奥娜", "副手", "叫作", "怀上", "印刷", "胡安", "戒毒", "heads", "妆", "从头到尾", "following", "下一代", "警队", "昏", "赽", "太后", "plans", "记性", "馆", "网路", "获", "思路", "克莱恩", "反悔", "单车", "圣洁", "恩里克", "爱死", "五十万", "光亮", "渡假", "不得已", "源于", "terry", "住宿", "收视率", "此生", "贝多芬", "轮流", "收缩", "调教", "青春期", "作曲家", "现实生活", "亲眼看见", "闹鬼", "行列", "纬", "银子", "我害", "陪陪", "笨拙", "总署", "公園", "交情", "下船", "第一眼", "盼望", "战死", "别乱", "战线", "无所事事", "放肆", "退休金", "收益", "送上", "打過", "骂人", "电缆", "我画", "lots", "玱", "警卫队", "並不", "nature", "順便", "量子", "亏", "拚命", "closer", "撕成", "难不成", "木匠", "决策", "这鬼", "stage", "下属", "凉快", "太少", "我记", "noah", "每位", "数千", "隐秘", "拷贝", "办完", "人到", "证", "进到", "概率", "私生活", "球棒", "纯净", "晋升", "規定", "亲口", "洋娃娃", "厄运", "手掌", "剁", "思绪", "粗俗", "belong", "星空", "末", "月经", "本领", "比爾", "擦伤", "廢話", "防护罩", "好手", "克拉拉", "drugs", "米娜", "五百万", "佔", "心存", "杀人狂", "無辜", "冰岛", "complete", "看个", "智障", "静", "买票", "smoke", "heshe", "medical", "冰冻", "美酒", "hadn", "入伍", "协定", "上身", "抵制", "柏", "灌", "qui", "园", "克里斯托弗", "好觉", "町", "行进", "悉尼", "长话短说", "坐火车", "面向", "乔西", "菲利克斯", "礼仪", "退伍", "我姓", "某种意义", "挨打", "艾丽克丝", "小春", "大鱼", "好得多", "梅丽莎", "根源", "animals", "最深", "藍色", "program", "遗失", "配偶", "每秒", "sleeping", "多尔", "养大", "laughing", "萨克", "处处", "电话响", "圣父", "空氣", "调到", "疑虑", "德伍德", "警長", "我媽媽", "trick", "年长", "生还者", "赶出来", "mi", "有把握", "弄断", "捏造", "梨", "moi", "敬佩", "何事", "人待", "福尔", "送花", "至死", "craig", "慌张", "阿信", "刊登", "某天", "下一场", "天前", "出不去", "小黑", "抢劫案", "藏匿", "汉堡包", "mention", "永", "影院", "万事", "躲过", "checked", "笼罩", "兵器", "无谓", "熬夜", "匡", "法老", "艾娃", "贪心", "豆豆", "三张", "调校", "斗篷", "走掉", "第一夫人", "司", "規則", "ㄐ", "十六岁", "全速前进", "享有", "チ", "charming", "wade", "豪斯", "feed", "富豪", "菇", "打入", "无妨", "与我无关", "诽谤", "抑郁", "判刑", "福瑞克", "蹭", "欢迎您", "私", "毕业生", "潮流", "泽", "堂", "新婚", "男主角", "强化", "轰", "繧", "台北", "许诺", "车轮", "أ", "神情", "taste", "先说", "放過", "臔", "密探", "小刀", "上吊", "他时", "那不勒斯", "卓", "common", "洗衣", "尼尔森", "绿灯", "planning", "匹兹堡", "胸膛", "在手", "au", "完结", "当今", "紆", "research", "别搞", "驾驶舱", "射线", "他給", "敬畏", "有何不可", "精通", "carson", "无畏", "forest", "老兵", "天然气", "麦琪", "吸血", "上任", "温蒂", "最新消息", "動手", "held", "band", "墨水", "离奇", "辨认", "勇氣", "防", "shepherd", "德利", "抱紧", "bauer", "淫荡", "王八", "冰毒", "apparently", "出庭作证", "blind", "炒鱿鱼", "逼迫", "尔特", "掠夺", "起舞", "两家", "ocr", "向往", "劳", "瓦莱丽", "國際", "视而不见", "擅長", "天意", "国会议员", "upstairs", "ﺿ", "温迪", "器材", "spirit", "蒸汽", "赚大钱", "俱樂部", "蒙蔽", "朝廷", "清扫", "地理", "爱国", "请坐下", "峈", "finn", "谅解", "chicken", "博比", "眨", "参战", "下课", "給我們", "瞧不起", "古典", "烈酒", "勾", "奎尔", "乐于", "market", "抽煙", "nasa", "引人注目", "signal", "閉上", "進展", "然後他", "房顶", "二个", "pregnant", "mehr", "近期", "西奥", "慶祝", "政变", "毒害", "办公", "當他", "簽名", "书面", "搁", "宿命", "筷子", "遛", "卑微", "退下", "上门", "往下", "net", "非称", "淩", "举杯", "shooting", "桑迪", "匆匆", "teresa", "休克", "grant", "新任", "玩过", "用得着", "一箭", "摩斯", "抑或", "teeth", "聚", "疯人院", "ow", "做件", "机上", "真好玩", "爱神", "蠢猪", "梦到", "瞧见", "獹", "钓到", "juice", "时分", "travel", "布料", "路易丝", "不顺", "地平线", "簡", "還不錯", "ы", "割掉", "谜团", "打着", "戒掉", "日程", "无可奉告", "先令", "不起作用", "一巴掌", "萝卜", "军营", "恐惧症", "粪便", "劳伦", "卡尔文", "班尼", "翡翠", "type", "大堂", "太好", "同僚", "一举一动", "事業", "证券", "提防", "trade", "四位", "冰球", "啟動", "静静", "會議", "腀", "color", "克鲁格", "洗碗", "干的事", "巴尼", "议长", "迟点", "小气", "开展", "酬劳", "番茄酱", "试探", "fake", "嗜血", "打错", "完后", "默默", "strike", "一顶", "起步", "內容", "含量", "钦佩", "忙于", "κ", "glenn", "撞车", "老外", "一楼", "响亮", "河水", "专利", "航海", "解决不了", "梅里", "jordan", "验尸官", "sword", "trial", "自言自语", "骚货", "film", "shop", "制药", "整洁", "侵蚀", "招来", "人比", "圖", "仓", "單", "远古", "悟空", "被叫", "憧憬", "构造", "闹剧", "凯拉", "猛男", "美國人", "偏离", "有多远", "一款", "贝贝", "腊肠", "排序", "丹妮", "崛起", "战时", "卓越", "预防", "證人", "赛特", "杰德", "铃", "堅強", "好似", "prey", "险境", "學會", "形态", "到此结束", "密谋", "欢呼声", "眏", "膥", "米切尔", "further", "克隆", "hr", "海龟", "煽动", "在世", "mais", "牙买加", "晾", "论", "心知肚明", "筽", "链接", "投给", "旗子", "爱国者", "corner", "拔出", "很贵", "股市", "假定", "advice", "预兆", "consider", "秃头", "十秒", "一扇门", "size", "邀请函", "斯蒂夫", "lip", "消", "斯考", "寶寶", "洛特", "五十年", "格勒", "机舱", "肾脏", "fresh", "胜者", "什麼關", "主机", "再加", "见识一下", "聋子", "毛发", "带进来", "真笨", "帆船", "答对", "燈", "四岁", "cup", "台风", "四百", "危及", "调动", "猵", "过失", "顺其自然", "穨", "后裔", "精神科", "bist", "德意志", "越共", "thousands", "穆德", "未婚", "阿比", "一扇", "呜咽", "帮不上忙", "扣子", "ward", "六天", "奶昔", "碟", "倾斜", "瑞尔", "drinking", "合伙", "肩", "阶", "德性", "山丘", "冷水", "丽斯", "大蒜", "谢尔曼", "家务", "肛门", "ashley", "joy", "风筝", "理事", "北韩", "眼镜蛇", "流程", "链", "實驗室", "巴蒂", "隨著", "一记", "breath", "毒瘾", "卖淫", "cousin", "缝合", "滾開", "放荡", "埃文斯", "奴才", "斯通", "辩解", "洗衣机", "控诉", "坏处", "通奸", "很坏", "好香", "想点", "巡回", "残废", "修剪", "拜伦", "拉丁文", "窝囊废", "并肩作战", "卫队", "参", "小不点", "信托", "链子", "放在心上", "楼顶", "上映", "触动", "须", "universe", "不放过", "菩萨", "白日梦", "一案", "灯里", "进不去", "读读", "易", "必胜", "ocean", "fitz", "罪恶感", "勸", "电动", "french", "安然", "了如指掌", "双脚", "哈德", "布赖恩", "右翼", "踢足球", "op", "打扰到", "關系", "沾满", "饭菜", "推销员", "义大利", "遗物", "施展", "说到底", "post", "糊弄", "傷口", "阴阳", "管辖", "專家", "奥利维亚", "戏院", "食材", "南茜", "pressure", "反叛", "信奉", "马德里", "盯住", "畫", "約會", "可怜虫", "牵涉", "地底", "大部份", "遥控", "郊外", "pants", "发言人", "劍", "lies", "推到", "贝特", "強烈", "失事", "那能", "超爱", "laugh", "乔尔", "店铺", "月份", "我进", "心声", "平分", "综合症", "总而言之", "一丁点", "忧虑", "直奔", "aunt", "ethan", "大本营", "啊啊啊", "海鸥", "淘汰赛", "亲王", "多米", "短时间", "犀牛", "所罗门", "steven", "matters", "扣动", "蒂斯", "受夠", "聖誕", "sat", "裴", "吃點", "罪有应得", "藝術品", "梦寐以求", "复苏", "内幕", "晚一点", "不耐烦", "姬", "国际刑警", "gate", "喇", "page", "月底", "炮火", "专员", "跨过", "内线", "机率", "常客", "年青人", "opportunity", "免費", "游击队", "会令", "子彈", "大尉", "汀娜", "切换", "tiny", "耙", "不早", "曙光", "惠特尼", "制成", "written", "惊艳", "萨达姆", "西门", "没吃过", "好帅", "活到", "化妆品", "麻痹", "wird", "本部", "不回", "疯狗", "满嘴", "坐稳", "花儿", "lonely", "残留", "受罪", "itself", "阶级", "艹", "该不该", "但丁", "伤势", "土星", "福德", "无线", "sebastian", "特性", "理发", "志愿", "理应", "calvin", "休闲", "费尔南多", "达尔文", "渴求", "格雷厄姆", "跑腿", "生小孩", "而生", "lights", "藥", "罗布", "crying", "犹太教", "熏", "爱戴", "比分", "比得上", "我学", "醋", "从今天起", "hall", "clearly", "坐船", "专业人士", "进场", "沉迷", "浓", "徒步", "波浪", "对劲", "涅", "太精彩", "细心", "一连串", "采", "胸前", "警觉", "請進", "吞下去", "herself", "性能", "cars", "梦游", "排成", "扣留", "瞎扯", "指头", "凡是", "不願意", "shake", "肺炎", "雌性", "切斯", "一朵", "immediately", "fox", "有大", "罢休", "奥利佛", "掺和", "螺旋", "梳", "虱子", "录影", "mommy", "第一部", "以内", "习俗", "希瑟", "一大群", "全员", "睼", "珊瑚礁", "纸牌", "哪样", "撕碎", "再婚", "sunday", "入室", "只见", "款式", "献身", "洛杉磯", "圣殿", "个体", "played", "挥手", "ふ", "军士长", "赶回", "mon", "安危", "擋", "heavy", "权势", "談過", "げ", "污秽", "banks", "小天使", "墨镜", "容许", "明美", "亲眼目睹", "鬍", "一如", "干些", "lab", "别忘记", "克丽丝", "自相残杀", "还用", "太阳能", "黏", "oder", "太平", "任职", "涂鸦", "这般", "计较", "头头", "安息日", "开得", "cal", "高档", "亚马逊", "whoo", "考試", "瑈", "恩惠", "judith", "洗钱", "跑过来", "小猫咪", "搜捕", "不可理喻", "的確", "paris", "驻扎", "无声", "谜题", "一好", "不卖", "稍稍", "核实", "cody", "插进", "wes", "头等舱", "斯派克", "弗洛伊德", "宿醉", "邮差", "恼火", "伦", "驚訝", "艾达", "短短", "伯恩斯", "洁", "偷情", "德曼", "繁忙", "第四个", "舞女", "began", "咸", "领队", "无与伦比", "逃掉", "nein", "tank", "耍花招", "听不清", "开出", "shadow", "机关枪", "去不去", "阵地", "强悍", "重重", "妞儿", "移交", "paige", "剑桥", "机制", "佩里", "心急", "书写", "暴风雪", "越大", "吐司", "呼呼", "gene", "driver", "难为情", "只在乎", "耶鲁", "還真", "爵", "门廊", "過了", "外地", "收听", "歌星", "摆布", "collins", "denny", "讨", "晕过去", "活捉", "心智", "二等兵", "我過", "heat", "观众们", "妮丝", "西服", "gods", "这破", "金矿", "对不住", "purpose", "歉", "变异", "访谈", "手下留情", "菜肴", "摘掉", "nose", "安稳", "跑不掉", "records", "警报器", "老伯", "没拿到", "接觸", "消极", "我姐", "大碍", "隊伍", "缩写", "另一面", "击毙", "暴乱", "拳手", "唇", "推断", "蓝队", "面對", "尔德", "远走高飞", "没劲", "奥马尔", "栗子", "交通工具", "返", "实里", "獽", "特制", "柳", "乜", "卖力", "捉弄", "cbi", "仇人", "做点事", "歉意", "告密者", "闹钟", "后会", "字典", "藤", "嘣", "wyatt", "剃刀", "多多指教", "相应", "室长", "压住", "空缺", "祭坛", "克朗", "塔特", "打字", "世", "這座", "彩色", "耶穌", "command", "faster", "全家人", "联赛", "milk", "氛围", "电路", "親", "easier", "深信", "从天而降", "余下", "柴", "只为", "难搞", "走来走去", "下回", "借助", "christopher", "监护权", "mcgee", "語", "赌城", "丝绸", "车来", "桥梁", "sheriff", "比斯", "右舷", "史丹利", "楼层", "脚踏车", "弄湿", "狗崽子", "possibly", "鼻涕", "贝勒", "裂开", "华府", "裕", "发号施令", "mikey", "波多黎各", "肥猪", "加利", "shirt", "骨髓", "劳工", "四肢", "抢救", "猔", "深爱着", "忧伤", "斯文", "布道", "莱克斯", "心肝", "品位", "sloan", "两下", "卸下", "val", "兩人", "炸鸡", "莉比", "艰辛", "一夜情", "索尼", "ラ", "alles", "体谅", "香料", "曲线", "卡蒂", "这班", "照镜子", "过火", "嫁人", "汜", "追随者", "吹箫", "模范", "班级", "nah", "微风", "骨骼", "這人", "坏主意", "携手", "翻过", "响应", "俊", "便利店", "director", "魂", "felix", "现场直播", "出乎意料", "跳下来", "插嘴", "接上", "online", "弗雷德里克", "闻闻", "佩姬", "点亮", "羊毛", "司機", "dropped", "剧烈", "出没", "仰望", "不顾一切", "船舱", "orson", "會有", "轨迹", "家庭主妇", "身在", "失恋", "账号", "贵重", "赏", "全程", "pink", "写出", "motherfucker", "雷文", "马拉松", "畢竟", "赌徒", "不复存在", "來過", "gail", "natural", "巡逻队", "ellie", "不喜歡", "spoke", "病假", "高雅", "油门", "扎营", "弗拉", "自欺欺人", "鬼子", "態度", "要查", "lieutenant", "人影", "beauty", "求生", "小溪", "暴风", "做错事", "表扬", "栏", "厨子", "满身", "愈来愈", "另有", "安顿", "成全", "绳", "老老实实", "responsible", "朝向", "somehow", "无条件", "衷心", "接头", "耐性", "铲子", "汤玛斯", "被害者", "洗掉", "外勤", "无稽之谈", "光臨", "今儿", "暖气", "王爷", "得够", "bathroom", "手指头", "taught", "逃兵", "私家侦探", "東", "這話", "有如", "我演", "烂透", "行行好", "北面", "尼克松", "熄火", "梗", "毕加索", "事事", "釜山", "一任", "oleg", "饱受", "凯里", "加冕", "低下", "marco", "祖", "人犯", "受宠若惊", "rid", "拒", "开销", "表亲", "下跪", "太差", "莉斯", "粗黑", "骑着", "時機", "世道", "塔利班", "热身", "麦迪逊", "买下来", "听取", "pride", "ck", "振动", "proof", "里克斯", "心烦意乱", "直视", "克雷斯", "外围", "被遗弃", "喜好", "yellow", "咯咯", "好坏", "巴勃罗", "aw", "baylor", "大約", "辉", "excellent", "基普", "睡醒", "洗车", "公墓", "view", "games", "硐", "巴洛", "语音信箱", "露易丝", "科迪", "我时", "侍奉", "贰", "一千年", "还击", "ゎ", "灌输", "日常生活", "希拉里", "荷兰人", "不忍心", "好酷", "之际", "willie", "十亿", "在我心中", "能救", "fancy", "弄完", "一間", "emergency", "造访", "钻进", "公共汽车", "殺害", "金星", "套装", "雨伞", "career", "撞倒", "死期", "痛楚", "清新", "声响", "宵禁", "日記", "盾牌", "双臂", "center", "岁数", "忒", "有水", "摇篮", "gus", "lauren", "席位", "各处", "印地安人", "负面", "drew", "包厢", "中年", "倘若", "oui", "恩人", "遗书", "声纳", "小伙伴", "还债", "继母", "能为", "合適", "竜", "预先", "共犯", "sons", "square", "李润成", "艾蜜莉", "组装", "铲", "關閉", "拍拖", "争辩", "漩涡", "卡姆", "詛咒", "主导", "夺去", "物理学", "plenty", "stories", "座椅", "otherwise", "停不下来", "会计师", "少废话", "蹦", "friday", "市場", "仓鼠", "采儿", "促进", "祘", "warren", "白雪公主", "贝里", "deserve", "block", "马铃薯", "会以", "下滑", "音响", "这年头", "伊利", "分队", "嫩", "结识", "他关", "brave", "擦屁股", "消防队", "业主", "門", "背负", "消沉", "底片", "拍拍", "型号", "高利", "法文", "顺风", "观测", "weekend", "纳什", "著作", "做不来", "civil", "学徒", "pierce", "可得", "simmons", "掠", "探讨", "太深", "创立", "恰恰相反", "名堂", "秋", "把酒", "人事", "活口", "撬", "dancing", "ㄈ", "发给你", "威风", "turner", "赚点", "地區", "gavin", "這東西", "事迹", "甘地", "京城", "遲", "始于", "心动", "憩", "素", "队形", "咔", "财宝", "转化", "高达", "高温", "肉桂", "皮夹", "喜剧演员", "折扣", "打点", "sight", "release", "布兰达", "酒来", "甜品", "找遍", "效应", "大腦", "削弱", "对战", "總會", "家教", "洗完", "纳闷", "knowing", "法力", "judy", "令尊", "ス", "sold", "欺騙", "象个", "老年", "钮帝", "彼此彼此", "办理", "屁滚尿流", "三百万", "两岁", "一提", "帮过", "祭品", "先放", "貨幣", "极好", "认证", "麻烦事", "億", "temple", "庞德", "nash", "回过", "精准", "主唱", "前排", "克里斯蒂娜", "翻身", "救生艇", "加仑", "肌肤", "资深", "一小部分", "王妃", "艾滋病", "接线员", "行凶", "两把", "樂隊", "咖啡吧", "陪同", "马拉", "british", "上个星期", "沒辦法", "due", "出个", "顽强", "大学毕业", "加工", "不僅", "色情片", "豹", "打探", "菲律宾", "會不會", "摄像", "派上用场", "迪奥", "拖累", "留給", "斯拉", "五個", "玛丽莲", "力士", "激动人心", "特有", "餐具", "华纳", "施工", "ls", "簈", "军情", "捣", "咖啡因", "bullet", "提拔", "上锁", "潘妮", "尽兴", "相處", "随之", "睡觉时", "调皮", "繰", "赶着", "阿方索", "掌权", "animal", "补救", "花瓣", "地被", "冲洗", "第二名", "嗅觉", "汉尼拔", "情不自禁", "施压", "看能", "藉", "showed", "beg", "优惠", "开了个", "拿个", "备受", "公元", "老房子", "鬼鬼祟祟", "阿卡", "发射器", "skye", "burt", "綼", "药房", "买不到", "apologize", "得体", "案发", "这群人", "爺", "給了", "feelings", "整年", "费劲", "正轨", "钱财", "年青", "场上", "強大", "真受不了", "pretend", "归宿", "小点", "メ", "事宜", "伸", "静止", "逐出", "穆尔", "马儿", "装在", "池", "真不该", "坦率", "缓刑", "搞混", "cost", "露娜", "起死回生", "老伙计", "becca", "半点", "裙", "黄瓜", "拖走", "终将", "坎普", "扫帚", "蓄意", "suddenly", "后卫", "风流", "獨自", "穆", "leaves", "芒果", "机体", "investigation", "伽", "爬山", "卧槽", "我兒子", "む", "放任", "jena", "消磨", "长度", "但愿如此", "索尼娅", "ر", "飞过来", "挥舞", "飽", "象棋", "打敗", "教訓", "预料到", "確保", "榮幸", "阿蒂", "运营", "好运气", "寇", "folks", "照办", "猎", "放不下", "朗尼", "ﾌ", "头颅", "files", "菲茨", "他病", "直升", "录音机", "考上", "长长的", "学着", "letting", "我够", "pray", "禦", "再来点", "再过", "开业", "當我們", "heading", "醬", "轰动", "雨林", "办妥", "祝你愉快", "加布", "bitte", "project", "填写", "扭转", "稿子", "茜", "徒劳", "汉子", "打折", "美剧", "海莉", "喘息", "垃圾箱", "悔", "磕", "finding", "凳子", "前夕", "有什", "利亚姆", "低于", "总在", "列出", "发怒", "蝎子", "面谈", "符", "通心粉", "權力", "芙琳", "三十秒", "另一端", "ゼ", "sierra", "admit", "好色", "瘆", "史坦", "iron", "伊桑", "分娩", "变回", "车窗", "雇佣兵", "布伦达", "霍克", "保释金", "贫民区", "曾祖父", "稍息", "交涉", "闺女", "世事", "印尼", "不时", "小木屋", "兴", "牡蛎", "预谋", "疤", "安静下来", "上边", "sweetheart", "小花", "aware", "這句", "谢尔顿", "雜", "敬重", "主人公", "香田", "truly", "氮", "洗衣店", "昏过去", "两瓶", "衰老", "魁", "nelson", "尸检", "府", "锯", "公安", "人太多", "调头", "理发师", "泽西", "torres", "treat", "没骗", "篊", "简称", "这篇", "神经质", "myka", "帅呆了", "karev", "cook", "出什麼", "愣", "绑住", "讲究", "初期", "垮", "崔西", "政党", "牧", "家住", "盖特", "歼灭", "不怕死", "交了", "菠萝", "卡德", "經理", "leg", "山峰", "孬种", "太帅", "监护", "现今", "留著", "牲畜", "眎", "殖民", "falling", "富翁", "间接", "終於", "冲向", "精美", "会用", "寬", "怪罪", "今次", "法兰西", "算法", "开船", "一百块", "片场", "based", "日語", "筹备", "促使", "编织", "led", "earlier", "这全", "莫利", "宣", "arrested", "pm", "哮喘", "糖浆", "不痛", "捕食", "多纳", "邦尼", "map", "机遇", "参赛者", "君临", "ruby", "狂人", "你付", "乱说话", "lawrence", "游乐园", "空闲", "决不能", "渠道", "balls", "amelia", "bei", "纯真", "过多", "扩展", "耳语", "弄点", "vip", "糒", "弗里", "junior", "白粉", "八十", "蜂", "慢跑", "肥胖", "大提琴", "坚硬", "脸红", "挂出", "生还", "pal", "圣子", "奋战", "追击", "根烟", "遭殃", "耗子", "无私", "市政厅", "酷刑", "做好事", "普罗", "外观", "流出", "受审", "ugh", "barnes", "health", "养老金", "斯巴达", "露水", "斯凯", "左翼", "守则", "hydra", "敬酒", "休庭", "联系人", "风光", "很脏", "拉维斯", "人工智能", "践踏", "發射", "我定", "先锋", "likely", "探戈", "编码", "灵媒", "受伤害", "我接", "text", "起司", "泡汤", "正派", "拉面", "玛蒂", "jonah", "护身符", "papers", "大选", "jonathan", "nicholas", "摆动", "魔杖", "ゞ", "攻打", "单挑", "普里", "记不住", "乱讲", "共舞", "口哨", "驾驭", "之剑", "宣扬", "海滨", "伊斯兰教", "最具", "bennett", "site", "从那时起", "骡子", "捎", "storm", "截然不同", "管事", "约瑟芬", "那该", "禁忌", "残", "地儿", "奈斯", "难免", "钢", "后头", "夏目", "说声", "楊", "配对", "四人", "小分队", "顶住", "golden", "好運", "demon", "他开", "串", "绊倒", "发放", "一季", "表兄", "氪", "解读", "這還", "付账", "投篮", "藥物", "壮", "卡洛琳", "focus", "當成", "版权", "生路", "大黑", "棋", "长颈鹿", "小心翼翼", "颠覆", "故", "证供", "跟班", "称号", "脑后", "秖", "samantha", "雷藏", "受训", "难闻", "印章", "击掌", "平和", "举个", "ton", "埋怨", "妄想症", "古埃及", "日军", "承担责任", "接球", "风中", "眶", "几百年", "疏远", "亡灵", "说会", "有句", "生出", "ﺯ", "飞越", "關注", "在生活中", "经纪", "火爆", "因而", "十七", "半数", "修行", "walls", "loose", "breakfast", "勤", "急速", "吸取", "挣脱", "崇拜者", "头巾", "尼玛", "上百万", "hong", "咕噜", "nervous", "疲劳", "弗洛", "外壳", "开刀", "看样", "弃", "昂山", "扣押", "旋风", "杂草", "蔑视", "陶醉", "瞳", "卖出去", "罗马尼亚", "ﺁ", "眼鏡", "撕掉", "愛你", "騎", "去除", "圣战", "fill", "哪门子", "当回事", "客栈", "够不够", "arrived", "遗迹", "无论怎样", "深受", "兰顿", "书包", "禁令", "二十五", "最起码", "发飙", "疯女人", "三下", "最酷", "kurt", "ē", "suggest", "afford", "号角", "承", "事有", "memories", "珇", "気", "斑", "meine", "逮捕令", "wallace", "一再", "這下", "总管", "候", "安全套", "应有尽有", "奻", "开支", "侯爵", "强劲", "记不起", "拍片", "班主任", "杀过", "吹口哨", "纽扣", "召回", "赶回来", "听译", "马厩", "显眼", "年齡", "fate", "左脚", "退路", "飞鸟", "滚回", "饮", "英哩", "闪闪发光", "秘方", "会出", "凶残", "headed", "基特", "色狼", "伤得", "丹妮尔", "训练有素", "征求", "抽空", "安葬", "全职", "法警", "算不算", "妳有", "silas", "活泼", "玫瑰花", "很不錯", "埃德蒙", "according", "事到如今", "ahh", "安琪拉", "腞", "名單", "photo", "di", "抵挡", "nope", "オ", "山坡", "懒惰", "genius", "瓆", "熟练", "界层", "耍花样", "无处可去", "见解", "斑马", "空地", "犯过", "correct", "秘鲁", "圣路易斯", "日光", "这瓶", "有種", "交付", "當初", "收容", "megan", "围裙", "豌豆", "闭", "王座", "dry", "眷顾", "制造商", "死法", "火把", "救济", "美术馆", "starts", "nights", "弥撒", "飞走", "到处跑", "真凶", "伤者", "higher", "之处", "螺丝", "乌斯", "责任感", "meg", "remain", "开罗", "价值观", "我算", "春虎", "颁发", "fnnyala", "被告人", "关爱", "夥伴", "空間", "猜到", "二次", "我爹", "來點", "赶路", "珍珠港", "兰花", "每时每刻", "全國", "键盘", "想得美", "说不出口", "充实", "雪糕", "人称", "蘭", "饥荒", "julian", "挟持", "倫敦", "細節", "无话可说", "蛋白", "鞭", "draw", "吉普车", "生殖器", "素材", "深陷", "进发", "非常简单", "带些", "阿弥陀佛", "精华", "中场", "地里", "没人敢", "获利", "受死", "虚拟", "传出去", "policy", "樱花", "学得", "kitty", "已成", "tape", "然後就", "擦擦", "挂念", "necessary", "转学", "issue", "追着", "奪", "泼", "酵", "術", "偷渡", "犀利", "变好", "難受", "炎热", "地主", "拍戏", "当过", "福斯", "一餐", "pardon", "贴身", "lake", "离职", "早日", "再来一个", "克利夫兰", "中间人", "六周", "barely", "团结一致", "只不過", "協議", "奥秘", "干不了", "饮酒", "爱花", "告解", "太有", "loss", "作梦", "lockhart", "among", "零下", "打了个", "shine", "团团转", "常用", "一对一", "而成", "算数", "一齐", "竭尽所能", "community", "胡须", "锁链", "皘", "怕死", "每分钟", "大路", "蹊跷", "伊夫", "何故", "数年", "成績", "持續", "bang", "委員會", "jacob", "空姐", "袭", "妻", "守口如瓶", "堂兄", "shows", "容纳", "问个", "捣蛋", "ally", "awful", "收不到", "hidden", "单元", "高音", "子孙", "乔佛里", "漆", "freak", "数数", "退回", "截住", "已死", "宾客", "融洽", "正规", "南斯拉夫", "繦", "高峰", "稍候", "此后", "布克", "有变", "搬出", "后会有期", "被称作", "並非", "你查", "研讨会", "阿婆", "赖安", "海拔", "total", "武术", "尝到", "鬼扯", "本子", "coulson", "共鸣", "多长", "试想", "海狸", "记忆力", "马科斯", "多一些", "脉冲", "上庭", "暗恋", "捆", "biggest", "步入", "ridiculous", "输赢", "白雪", "孩子气", "矿井", "外交官", "关键时刻", "乔治亚", "writing", "團隊", "两根", "南京", "莫里森", "算账", "towards", "维京", "狄克逊", "总司令", "干什", "衫", "极品", "搜救", "discuss", "泥巴", "饵", "籖", "黑进", "伍", "田地", "荒凉", "航道", "下药", "厂长", "一集", "我头", "不差", "会输", "roof", "sending", "嬸", "管不了", "东北", "rodney", "太天真", "战壕", "每件", "都柏林", "空军基地", "物件", "未成年人", "試", "之意", "讲清楚", "不懂事", "避", "雅典", "hanging", "ta", "触犯", "裤", "货色", "胡来", "钩子", "mum", "法术", "用來", "elsa", "事会", "世界杯", "省得", "赶去", "急于", "更能", "促成", "悲", "癫痫", "瘤", "染", "啄", "巴恩斯", "必将", "惊恐", "重击", "觀察", "站立", "痜", "蟋蟀", "不易", "那算", "吐口", "懂事", "agents", "silence", "服药", "迷航", "担架", "弱小", "点点", "重启", "玩个", "gotten", "超赞", "装有", "传票", "england", "起义", "他醒", "煤", "玛丽娜", "感觉得到", "剥削", "本季", "female", "甭", "腌", "硈", "janet", "微型", "心怀", "真人秀", "秸", "location", "马龙", "計畫", "珿", "敌对", "说个", "诺玛", "大功告成", "轮不到", "双面", "神經病", "车开", "比舍", "颈部", "狱警", "cake", "理事长", "一顆", "发牢骚", "不願", "长成", "墓穴", "酱油", "无可", "扼杀", "所愿", "machen", "现任", "闽玒", "全套", "影迷", "熬过", "鱼类", "防备", "送信", "内陆", "写得", "猶太人", "境内", "扎法", "小把戏", "六個", "残疾", "ends", "证书", "道谢", "哪來", "powers", "毛毯", "参谋", "查案", "部件", "军用", "前景", "jared", "二年级", "恨不得", "逃到", "path", "微", "司徒", "希曼", "菌", "猌", "敢动", "caspere", "窃贼", "琪琪", "cancer", "主流", "的車", "夔", "真不錯", "hearing", "转接", "看些", "公爵夫人", "走失", "出拳", "撤出", "开膛手", "中意", "紫", "锁好", "守夜人", "苦头", "死地", "遍地", "秘密行动", "更进一步", "瘸子", "倒地", "族群", "愛人", "名气", "别慌", "不服", "credit", "野性", "從現", "偷吃", "光环", "讨人喜欢", "excited", "佛祖", "一下下", "小組", "无须", "战火", "一贯", "海格", "弗朗索瓦", "平稳", "慢用", "玩乐", "远去", "议论", "投資", "玻", "昨夜", "会场", "chd", "痁", "详情", "丰厚", "好要", "刀片", "卡車", "死路一条", "弄脏了", "假象", "一頓", "问到", "收割", "满满", "時期", "竞技", "取名", "国务院", "逃过", "歌迷", "覺", "皇后区", "射死", "however", "明顯", "沙丘", "搞乱", "配得", "斯基", "达拉", "年间", "电话线", "滚出来", "回老家", "sein", "不清", "守护神", "不论是", "称作", "四名", "不累", "當中", "不著", "公分", "毫不犹豫", "早早", "佛利", "週末", "瑞卡", "罗根", "整件", "白马王子", "dumb", "真广", "年底", "押韵", "ò", "泰坦", "够呛", "超乎", "ours", "大福", "火炮", "盘旋", "贝琪", "维吉尼亚", "kitchen", "还敢", "毫克", "嘿咻", "欣賞", "勇往直前", "享乐", "醫師", "不应", "承包商", "格兰", "沒能", "besides", "万块", "高清", "铅", "招待会", "pieces", "三万", "爱情故事", "市政", "开炮", "大盗", "嘲弄", "顺路", "后见", "公式", "冰山", "背弃", "弹琴", "harder", "嘭", "一个多", "colonel", "假名", "词语", "击沉", "晦", "main", "潇洒", "列入", "过关", "training", "听力", "震", "底层", "舉起", "留神", "即时", "敲打", "曆", "不太会", "chose", "重聚", "稀罕", "最合适", "扳倒", "牺牲品", "束手无策", "寄养", "亚利桑那州", "這間", "转机", "特曼", "得奖", "mandy", "伊迪丝", "political", "救星", "侍者", "菲斯", "第一年", "脚步声", "社工", "脱落", "patient", "酒后", "生物学", "柔和", "僅僅", "禮拜", "那支", "theory", "潮", "工夫", "挑战者", "peggy", "题材", "眼珠", "真空", "納粹", "那會", "去往", "小美", "周期", "波西", "擺脫", "呐喊", "接见", "大坝", "意指", "文档", "ralph", "起訴", "没出息", "胡桃", "soldiers", "落得", "裁定", "皮膚", "bro", "脑震荡", "肥料", "超新星", "犯案", "debbie", "开阔", "健全", "难以相信", "若有", "缺口", "rob", "鼓起勇气", "机智", "另一头", "心甘情愿", "老奶奶", "亚斯", "斧子", "迫切", "我醒", "brandon", "到期", "meat", "魔咒", "舍得", "还手", "米斯", "逃不了", "多伦多", "好了没", "尷尬", "火化", "无奈", "图表", "angels", "臭名昭著", "复印", "拼写", "慎重", "考古学家", "绫", "看路", "祝愿", "历史性", "梵蒂冈", "獨立", "赫斯特", "化为", "歌舞", "豪华轿车", "关节", "农村", "wo", "加拿大人", "幫幫", "天王", "牙膏", "单身汉", "即便如此", "探险家", "借来", "昵称", "常人", "一醒", "收场", "放慢", "信得过", "奈杰尔", "新鮮", "女伴", "zack", "塞满", "往来", "颈", "buffy", "爪", "stolen", "房贷", "反對", "军事法庭", "仙", "越来越近", "清水", "assume", "田中", "痛死", "使人", "四十年", "分布", "多诺万", "奶妈", "肚", "沉迷于", "电话亭", "史蒂文斯", "烩", "老土", "静静地", "小人物", "財產", "笨手笨脚", "垃圾堆", "无所不能", "翱翔", "聚會", "很丑", "鲁道夫", "戴克", "时装", "卡梅隆", "欢喜", "媒體", "片源", "业", "烂醉", "三块", "唏", "消费者", "小老鼠", "受惊", "failed", "车程", "安全部", "hardly", "不尽然", "经理人", "結局", "亿万富翁", "太赞", "颠倒", "covered", "龙王", "汇合", "达伦", "冲刺", "ブ", "夸大", "放射性", "实用", "写成", "纠纷", "眼罩", "我养", "木屋", "奈尔", "身无分文", "韦斯", "破译", "西红柿", "當年", "春日", "真可笑", "她現", "全垒打", "哥特", "滇", "咚", "经由", "至此", "可知", "改名", "金山", "cream", "比武", "捕捉到", "时才", "一派胡言", "recognize", "毅力", "meaning", "水分", "property", "吉吉", "billion", "词汇", "隱藏", "后腿", "多克", "杭特", "抛出", "不值钱", "市里", "长大成人", "清清楚楚", "發出", "跟前", "看不清楚", "温室", "良知", "起碼", "africa", "体育场", "尽早", "拆开", "数月", "短路", "檔案", "案底", "喝个", "之歌", "镇里", "insane", "危急", "吃些", "丢进", "成長", "输家", "看上", "十一月", "study", "左邊", "agreed", "member", "佩顿", "引渡", "记者会", "国防部长", "天文学家", "awake", "拉塞尔", "不饿", "理子", "ボ", "门罗", "驯服", "搬回", "相符", "般配", "竖起", "二十万", "這讓", "低劣", "菲比", "不大好", "用药", "弗兰", "入学", "这药", "philip", "整条", "加冰", "皮革", "巴勒斯坦", "不巧", "赛道", "过滤", "尼奥", "变动", "忽悠", "不错呀", "碿", "油箱", "好险", "大嘴巴", "黛安娜", "洱洱", "审理", "弹奏", "饰", "字谜", "奏", "独角兽", "换换", "叶风", "lane", "fired", "中产阶级", "炖", "傻笑", "领事馆", "横跨", "伟人", "大队", "光年", "批判", "斜坡", "瑕疵", "吉儿", "殆尽", "历经", "虚无", "偷拍", "professor", "梅拉", "簘", "摘下来", "冥想", "凯琳", "孕育", "海啸", "我會給", "道森", "保险库", "替罪羊", "crane", "净", "空位", "陷", "虚张声势", "射门", "芥", "斑点", "心裡", "感性", "然後我們", "烙印", "挺身而出", "几千年", "请进", "精疲力尽", "whore", "皮鞋", "发神经", "famous", "拐角", "露天", "格雷戈", "动议", "正版", "ほ", "完全同意", "民间", "团结起来", "洛尔", "推倒", "三十分钟", "动听", "考察", "排出", "半岛", "沒時間", "onto", "劫案", "积累", "四千", "duncan", "prince", "野营", "西娅", "拉上", "分身", "爭取", "说够", "自觉", "失血", "阿拉伯语", "托尔", "已久", "内奸", "千萬", "完完全全", "敌舰", "翼", "沙丁鱼", "诡", "想尽办法", "珃", "小个子", "维生", "庄严", "人多", "fan", "西南", "不關", "沃尔", "塌", "罪魁祸首", "迄今为止", "不测", "用功", "下個", "改了", "难缠", "responsibility", "说不清", "黑盒", "人會", "拉格", "出息", "波士", "跑来跑去", "石板", "判断力", "mao", "這太", "生不如死", "柠檬水", "畉", "阿龙", "撞见", "拉斐尔", "bien", "adams", "时报", "阿奇", "巴比伦", "悲观", "靶子", "註", "萇", "jenna", "收藏家", "面熟", "boom", "顺", "无形", "改写", "养老院", "星云", "巴巴", "大笔", "小狗狗", "lf", "nuts", "强度", "珍宝", "拷", "大巴", "今生", "起草", "肠子", "橡树", "嘿嘿嘿", "行径", "捐给", "感到遗憾", "ь", "讲道理", "痣", "leader", "海象", "没人接", "收取", "题", "赛场", "游说", "江", "large", "奀", "bother", "所属", "顽皮", "fsp", "concerned", "語言", "伐", "royal", "ideas", "宗教信仰", "心不在焉", "原样", "經紀", "這兩個", "畅销", "致以", "纷纷", "ufo", "加藤", "所用", "结账", "审视", "海藻", "導致", "弹性", "引爆器", "口令", "必有", "磁场", "荷马", "一片空白", "岸上", "亚特", "損失", "幾點", "sexy", "主子", "真乖", "wolf", "赫里", "独眼", "carla", "破车", "穿過", "藍", "事实证明", "隔天", "布奇", "独裁者", "wieder", "喝下去", "爆炸案", "踏进", "诺曼底", "這輩子", "malcolm", "奥兰多", "祖父母", "本想", "paying", "gates", "小米", "尖锐", "謊言", "直面", "瓦特", "毒液", "火炉", "开胃菜", "认真对待", "perfectly", "点名", "勿", "加满", "两队", "silver", "不开", "中立", "巡视", "死于", "双份", "revolution", "日益", "马达", "掏", "不关我事", "渺茫", "庇护所", "destroyed", "灌木丛", "我订", "砑", "满脸", "波顿", "哈拉", "大韩民国", "honestly", "湮", "烈火", "浏览", "williams", "关怀", "莫顿", "沸腾", "治病", "弯腰", "贵姓", "灰灰", "理事会", "中介", "ゆ", "重拾", "发呆", "惊动", "ﻕ", "索菲娅", "素描", "哲", "计数", "bravo", "迈出", "儀式", "十二岁", "更难", "孵化", "艱難", "銀", "runs", "砍死", "航母", "bo", "藐视", "认清", "佛莱迪", "瑞典人", "更高", "恐怖组织", "ought", "abc", "野狗", "分部", "kong", "谭", "往日", "买得起", "冢", "河马", "最最", "惊", "正宗", "蜜糖", "之人", "缺钱", "selling", "没人来", "学员", "只求", "报到", "研究员", "七八", "决战", "校長", "一则", "结婚戒指", "诉说", "会先", "感应器", "死前", "打高尔夫", "還不夠", "展", "悔恨", "另一回事", "食者", "spread", "毞", "不一樣", "世俗", "多岁", "取证", "轮回", "执行官", "譬如", "倾倒", "鲍", "混沌", "双层", "在此期间", "童话故事", "經有", "資格", "internet", "顶层", "火热", "反倒", "唱诗班", "鱼子酱", "飞碟", "區域", "流浪者", "商用", "网页", "天马", "碳", "埃文", "稀奇", "节哀顺变", "secrets", "爱看", "质问", "改装", "契", "垂死", "晚些时候", "金大中", "身穿", "正往", "出丑", "开学", "仅存", "职业杀手", "吸食", "篱笆", "越战", "ss", "泵", "沒來", "乾脆", "understood", "進步", "所在地", "总经理", "羪", "艾薇", "贝基", "fairy", "吹嘘", "只手", "甧", "老先生", "enrique", "移民局", "别停", "天文", "气概", "萨利", "肤浅", "德勒", "σ", "搅拌", "秃鹰", "胶水", "鞋带", "打垮", "慢慢说", "百万美元", "吃不下", "序列", "枯萎", "军舰", "全副武装", "敢不敢", "风度", "滴答", "德怀特", "昔日", "作物", "刺痛", "油画", "brennan", "瓦拉", "特尔", "夕阳", "爱伦", "several", "swon", "击球", "狭窄", "四分钟", "farm", "禁闭", "随身携带", "崔克", "gang", "弹道", "路飞", "邪教", "悠着点", "生动", "游戏规则", "笔录", "armed", "上马", "一大笔", "毫无关系", "講", "那班", "条纹", "盯紧", "讲得", "兰利", "换人", "camp", "沦落", "时辰", "共庆", "叙述", "掌聲", "购物中心", "肢体", "三份", "殺人", "突变", "legs", "pootie", "杜松子酒", "组员", "多愁善感", "丟下", "繁衍", "风头", "睹", "薰", "吵闹", "克裡斯", "屋内", "出行", "過的", "外伤", "û", "使唤", "bite", "老爺", "法规", "絕不會", "有朝一日", "艾美", "叮当", "照明", "失火", "宏伟", "火炬", "格外", "联想", "鉴证", "偏执", "凑合", "尔巴", "罺", "followed", "一郎", "piper", "且慢", "哈蒙德", "claude", "上來", "艾克", "珍藏", "塞车", "熱情", "松树", "三杯", "阿拉贡", "做起", "第一任", "source", "太爽了", "throat", "tan", "倒退", "推广", "冲破", "納", "塑胶", "直樹", "轻视", "sch", "八千", "andre", "出点", "下落不明", "休战", "地圖", "fella", "终结者", "卡塔", "犯错误", "气势", "comfortable", "仰慕", "尊", "州立", "赫伯特", "史蒂文", "單位", "激素", "岳母", "吉奥", "諾", "米基", "採取", "凡妮", "本应", "迪斯科", "pig", "前夜", "装着", "几下", "shane", "公文包", "平板", "漏水", "紧急事件", "莫尔", "十八岁", "不买", "拉特", "灭火", "对应", "爷", "凶猛", "祝賀", "所得", "猪排", "侧", "土耳其人", "賽", "视角", "保养", "强项", "老夫", "堪萨斯", "strength", "尼可", "从头", "萨沙", "止", "用得上", "兇", "social", "学术", "堵车", "杂碎", "食欲", "我到", "saving", "财政部", "ak", "日复一日", "漫游", "张照", "商标", "官僚", "方程式", "干旱", "挖苦", "员警", "断定", "practice", "齿轮", "harrison", "我待", "schei", "皮毛", "lines", "佩德罗", "砖头", "害人", "如何是好", "伴奏", "海克", "garrett", "匹", "十二月", "混亂", "聊得", "好车", "门徒", "坤", "只差", "克拉伦斯", "外貌", "装进", "针头", "酷哥", "户口", "宫廷", "抵御", "深色", "一團", "耶维奇", "企业家", "芬尼", "抽搐", "体操", "起航", "新泽西州", "招式", "小点声", "冰上", "屏障", "自由人", "雷吉", "杀人案", "稻草人", "笑笑", "取暖", "建築", "二叔", "蓝莓", "处长", "项圈", "餵", "行使", "戰車", "星舰", "此行", "谣传", "出版商", "药水", "大维", "广", "洁西", "归队", "少林寺", "产物", "戰士", "现代化", "不佳", "和服", "領導", "吃完饭", "镇定剂", "布里斯托", "纨绔子弟", "长着", "锣", "纪念碑", "哈哈哈哈", "一倍", "住房", "多恩", "王者", "民兵", "趋势", "退房", "清真寺", "loud", "构思", "松绑", "zeke", "张脸", "隆美尔", "卷进", "攫", "grew", "村落", "副总裁", "車上", "慰藉", "jonas", "轉移", "巴兹", "霹雳", "先要", "二哥", "卡梅伦", "那條", "半年前", "獀", "燃起", "認出", "上层", "拉蒙", "双亲", "埃克", "client", "占卜", "面纱", "格力", "哪一位", "伊奈里", "bon", "没这回事", "俾", "艾文", "长岛", "复习", "第十", "说到做到", "许下", "哥斯拉", "changing", "米饭", "habe", "babe", "denise", "二月", "情绪化", "挪开", "一臂之力", "troy", "发球", "熟知", "曲奇", "齐心协力", "波特兰", "埃利奥特", "学业", "流汗", "慢點", "闻名", "区区", "违规", "药剂", "外交部", "切成", "罗宾汉", "扯进来", "ct", "打字机", "冬眠", "筹款", "担当", "调节", "我病", "迪克斯", "重申", "蹟", "sydney", "世界冠军", "多佛", "就业", "没什", "包容", "野猫", "浪子", "一马", "川", "俄", "吉尔伯特", "维他命", "damage", "房车", "眼皮底下", "天台", "像不像", "体检", "事项", "呈堂", "悼念", "傳統", "bush", "jobs", "天体", "饭桶", "吉普赛", "單獨", "科长", "披", "雙手", "承蒙", "哈瓦那", "长袍", "选错", "美眉", "阶层", "chair", "遠點", "十几年", "打乱", "三件", "软糖", "最怕", "真子", "june", "点着", "方圆", "盎司", "攻", "直升飞机", "高中毕业", "愿主", "劳尔", "一幢", "fisher", "分割", "冒烟", "願望", "会毁", "戴帽子", "迪拜", "罗先生", "焚烧", "acting", "弘", "als", "人中", "泰瑢", "一步步", "阴性", "prepare", "十二年", "律所", "惠顾", "会飞", "dig", "随身带", "叼", "弗林", "經死", "心上人", "田野", "理清", "格里芬", "仪", "皱纹", "刮目相看", "裁员", "所要", "展出", "burned", "田里", "報導", "血流", "气疯", "狂暴", "議員", "装得", "埃尔", "同名", "風險", "щ", "拿骚", "越少", "攝", "篝火", "ay", "敬爱", "好哇", "外来", "维克托", "khan", "大拇指", "吓了一跳", "小白", "骯", "遇見", "平面", "变身", "德雷克", "依我看", "威利斯", "初吻", "ctu", "asleep", "karl", "开机", "礼节", "想个办法", "restaurant", "薩", "不提", "还来", "交货", "發明", "enemies", "烈士", "巴伯", "棒棒糖", "斯图", "笑柄", "里装", "中是", "幕", "记录下来", "兰姆", "萨特", "真帅", "赔率", "我絕", "蹩脚", "legal", "doors", "托付给", "马塞尔", "强势", "内斯", "装载", "受害", "精采", "改动", "长久以来", "沒人會", "海岸线", "潜水员", "忌", "快开", "上涨", "迪斯尼", "赌钱", "运河", "盖住", "坦率地", "天赐", "邻居们", "铁链", "花光", "tip", "spencer", "美满", "我个", "柄", "圣城", "为主", "惹恼", "搞鬼", "養", "成不了", "嬉皮", "details", "他出", "娥", "毛茸茸", "關門", "強姦", "这词", "彻", "逆转", "murphy", "论坛", "万无一失", "speech", "好萊塢", "governor", "廳", "安详", "大亨", "太吵", "逼真", "妻儿", "那架", "性病", "舞池", "守规矩", "讀書", "而活", "归于", "有否", "小菜", "language", "wherever", "不能容忍", "兴致", "马利亚", "变更", "海伦娜", "理論", "受益", "很美", "場", "地名", "内华达州", "最後一個", "cnn", "业绩", "礹", "烟灰缸", "洛伦佐", "seek", "我答", "赔钱", "缠住", "changes", "被车撞", "身陷", "点前", "宝座", "驾到", "heather", "休息时间", "梅林", "太過", "纳税人", "大米", "lover", "心疼", "优", "错事", "秋季", "入场", "封住", "部門", "化疗", "平庸", "雷曼", "猧", "拘束", "阿多", "不熟", "难以想象", "都給", "小说家", "盖世太保", "偷车", "无从", "圆满", "watched", "伸进", "卡米拉", "平靜", "车是", "伦纳德", "ra", "好极", "画得", "收好", "主菜", "数不清", "舉行", "听来", "禣", "加西亚", "race", "哼哼", "嚇到", "眼线", "强者", "菲利普斯", "板球", "wide", "threw", "别扭", "少林", "每条", "智者", "美好时光", "坏孩子", "gaby", "donald", "å", "ﺢ", "criminal", "門口", "躲到", "角度看", "最能", "阴险", "迴", "贪污", "树丛", "正题", "那还用说", "岸", "慈善机构", "拉娜", "burning", "克林顿", "伯顿", "湯米", "张床", "connection", "党员", "最出色", "全人类", "mein", "布鲁", "遗漏", "remind", "有所不同", "啊呀", "猎食", "success", "结盟", "腫瘤", "必死无疑", "绊", "woods", "云层", "只怕", "卵", "触及", "產生", "colin", "喂养", "随从", "铃铛", "阳具", "一列", "高价", "阳光灿烂", "失常", "佩奇", "这堆", "割伤", "看错", "大聲", "专", "面貌", "救火", "更惨", "过河", "闲", "牢牢", "鑽石", "沙织", "不能自己", "recently", "高估", "套餐", "私自", "finger", "妳们", "牢笼", "圣杯", "手袋", "黑名单", "托斯", "抽泣", "確", "會來", "寄托", "浮", "破事", "哈斯", "giant", "noir", "节食", "别胡说", "点好", "不及格", "断裂", "没动", "粉刷", "打擊", "莉雅", "快餐", "帮不上", "basically", "中文字幕", "率领", "当众", "小哥", "马驹", "令人讨厌", "热烈欢迎", "诚挚", "认识一下", "多疑", "心理学家", "大国", "蓝调", "前輩", "姊", "senator", "parts", "七十", "一桶", "不動", "胡乱", "战队", "病倒", "照常", "霍夫曼", "攻势", "柯克", "浇", "bart", "打篮球", "竟是", "供应商", "熄灯", "母鸡", "你试", "小鹿", "坎贝尔", "赞扬", "铜", "再试", "相隔", "互相帮助", "木马", "screaming", "唸", "工匠", "尘埃", "bass", "艾斯", "crowd", "兄长", "科里", "警力", "乔尼", "无意识", "尔比", "carolyn", "教友", "雷米", "吃亏", "石膏", "着凉", "连结", "全身心", "santa", "太笨", "空洞", "僧侣", "挠", "prepared", "一路平安", "嘟", "rudy", "班杰明", "nurse", "geht", "defense", "熔岩", "手足", "关了", "保时捷", "搞垮", "ohh", "搜身", "不同寻常", "甲虫", "trees", "据点", "許會", "饲料", "manager", "律法", "艾格尼丝", "although", "默斯", "ended", "赌局", "仙人掌", "轉過", "我发", "时见", "拘留所", "不帮", "调戏", "不同于", "trap", "很配", "接生", "庭院", "阿利", "很赞", "汉普顿", "除外", "杰拉德", "sooner", "前两天", "揭", "时要", "何塞", "艾萨克", "要付", "绣", "kinda", "sa", "一般来说", "lenny", "袋鼠", "上菜", "midnight", "ruth", "孤零零", "thoughts", "坐好", "帕姆", "辞掉", "善待", "趾", "爱慕", "法拉", "出人意料", "抓获", "莫大", "行军", "堕", "ser", "馆长", "害虫", "少见", "放映", "展会", "车臣", "below", "大幅", "走人", "觉着", "美术", "满怀", "我妹", "嬉皮士", "毛主席", "煎蛋", "射擊", "计票", "贾宝玉", "庙", "存钱", "凯布", "列宁", "凯萨琳", "音量", "无可救药", "不公", "财物", "课上", "向右转", "cc", "房门", "證", "兰特", "詹妮", "阿梅", "脚本", "斯蒂文", "ross", "毒气室", "秘密武器", "泉水", "家事", "外形", "性侵犯", "黄飞鸿", "点菜", "山米", "卡车司机", "流口水", "对阵", "太短", "剛好", "出力", "teacher", "牲口", "凛", "支出", "垂直", "優", "foreman", "绵羊", "典狱长", "泉", "招数", "abel", "侍卫", "阿强", "攀登", "可夫", "搅和", "大都", "西海岸", "何等", "萨米", "开采", "剧组", "作何", "ﻵ", "锡", "汉城", "過分", "拉尔", "榮譽", "驱魔", "罗嗦", "清静", "雷诺兹", "毁灭性", "绘", "妥", "忙活", "洋子", "罗马帝国", "衝動", "跳水", "遵照", "机翼", "改过自新", "冒牌", "联谊会", "海峡", "艇长", "distance", "詹妮弗", "coat", "予以", "soldier", "安妮塔", "lift", "続", "修士", "丘", "收声", "他教", "控制权", "足球队", "棒棒", "环游世界", "破门而入", "死胡同", "列为", "旁白", "停停", "guest", "无济于事", "速战速决", "两架", "鲁本", "橙", "溜冰", "realized", "別開", "送出去", "众", "小女生", "线条", "有理", "赎回", "基斯", "关头", "来袭", "瑟斯", "撑不住", "第六感", "破灭", "條", "凑巧", "缅因州", "欺負", "fought", "rabbit", "无动于衷", "聽見", "當心", "献祭", "漂流", "跳个", "gloria", "反弹", "保持警惕", "出奇", "充气", "重覆", "地铁站", "高里", "吮吸", "shout", "gibson", "殡仪馆", "低落", "調", "確是", "簍", "一个样", "军医", "珠", "including", "造物主", "growing", "rigsby", "舰桥", "小区", "第三天", "阿文", "御", "洛城", "飞快", "嫌弃", "萧条", "冻僵", "甉", "流通", "船尾", "總部", "遜", "意念", "检察长", "栽", "人气", "招聘", "纸张", "存储", "开价", "mills", "往外", "沅", "科研", "消息来源", "罗伯茨", "南面", "密西西比", "床边", "实体", "我车", "重心", "打斷", "停战", "红军", "小兔子", "淮", "代尔", "tear", "中央公园", "呛", "魔術", "brings", "小白脸", "贝鲁特", "来世", "中等", "传出", "swing", "密碼", "candy", "淑", "process", "當地", "巨石", "ざ", "芬恩", "発", "波拉", "脱水", "自助餐", "丽兹", "罗德里克", "奢华", "两支", "大主教", "年份", "克星", "眕", "乔迪", "弹壳", "过渡", "籇", "你闻", "夺冠", "朝圣者", "內部", "我动", "羁绊", "类固醇", "和善", "betty", "飞得", "衰退", "摔角", "之死", "便利", "连同", "水龙头", "佩斯", "扳手", "米格尔", "绘制", "工藤", "停尸房", "所爱", "縫", "南下", "臭死", "躺下来", "掩体", "垫子", "mars", "liam", "小钱", "没去", "lance", "几英里", "这酒", "虚幻", "请多关照", "母女", "装蒜", "保暖", "纳西", "拖把", "肿", "你問", "亞瑟", "今天天气", "澡堂", "颜料", "栏杆", "玉子", "活埋", "迷幻药", "太强", "新星", "彷", "获奖", "兆头", "嘢", "舵", "高高的", "炫", "孫子", "哇塞", "手肘", "纷争", "非礼", "扑克牌", "媚", "接应", "船头", "日历", "科幻", "巴拿马", "甘愿", "discovered", "佩克", "掩護", "壁画", "noticed", "英军", "乒乓", "拉普", "贝格", "绝招", "奥斯维辛", "в", "感情用事", "干员", "草药", "cabinet", "小鸡鸡", "不会错", "pie", "拴", "burke", "近乎", "每星期", "入手", "桐人", "那车", "这出", "人干", "矿泉水", "thompson", "晉級", "迷幻", "案发现场", "本市", "分为", "weight", "脸部", "泰斯", "笔记本电脑", "两枪", "瑿", "中将", "狹", "乔什", "挚友", "阻挠", "初级", "全给", "脾氣", "之眼", "話題", "interview", "planned", "顺道", "機構", "文森", "雪地", "他本", "梦中", "沉闷", "horrible", "决定性", "女工", "真不容易", "绑架案", "重塑", "机能", "公交", "波林", "洗耳恭听", "pd", "一千块", "範圍", "署名", "大肆", "炊", "莫伊", "phillip", "起居室", "奖牌", "millions", "特写", "timmy", "顶嘴", "紇", "忘恩负义", "时差", "要告", "報仇", "harm", "传话", "临冬城", "忍着", "贵人", "温妮", "结冰", "别打我", "加文", "上游", "听够", "米莉", "不論", "字面上", "难说", "ugly", "隱瞞", "这关", "believed", "波普", "主编", "办事处", "landing", "好爽", "名号", "蒙哥马利", "唐人街", "我米", "下葬", "苏黎世", "维生素", "私底下", "大白天", "泄密", "curtis", "这待", "法定", "风向", "說些", "校友", "jp", "独裁", "强森", "公元前", "小敏", "儿时", "add", "收成", "豬", "蝴", "他花", "这船", "沒想", "水母", "问个问题", "遠離", "左撇子", "人形", "slowly", "埃莉诺", "不轻", "击", "鼻孔", "一亿", "下结论", "century", "水桶", "泰尔", "日本鬼子", "门卫", "不仅如此", "算上", "sugar", "方言", "署长", "全斗焕", "憔悴", "珍妮佛", "作曲", "销量", "罗纳德", "竹子", "哪间", "小胡子", "麋鹿", "冲锋", "嚷", "哀伤", "挨揍", "绝无", "变坏", "season", "蜘蛛侠", "喊叫", "貴", "紅", "赶过去", "蒸发", "学家", "站长", "crowley", "莫特", "聖誕節", "阿嬷", "football", "pocket", "丑八怪", "交換", "created", "替补", "翻转", "rate", "他活", "加糖", "风扇", "伊安", "想方设法", "zur", "事前", "驱逐舰", "萝", "无名小卒", "往上", "自然界", "整容", "从此以后", "大熊", "穆斯", "维奥", "痕跡", "海斯", "年头", "帕特森", "长达", "家父", "别往", "摔死", "辫子", "crash", "maya", "奥兹", "船队", "ab", "哑", "不明智", "高于", "异形", "streets", "调味", "qq", "attorney", "哺乳动物", "所言", "charlotte", "審判", "又名", "波旁", "这枚", "癠", "后者", "补习", "daryl", "光天化日", "连锁", "装甲车", "斯派", "领航员", "飞行器", "公開", "一束", "脸庞", "没用过", "太多人", "受罚", "纳森", "宾州", "改正", "阴蒂", "新西兰", "实战", "长出", "兒童", "許他", "鋼琴", "筋疲力尽", "不太想", "邮递员", "未遂", "初衷", "嘎", "说句", "脱口秀", "海德", "纵火", "栽赃", "装模作样", "足足", "水底", "有多深", "从何而来", "ã", "钉死", "下边", "第二条", "bottle", "使馆", "简讯", "坡", "真假", "大半夜", "這幹", "患上", "絕望", "国税局", "大有", "神力", "鏡頭", "离别", "称职", "送入", "传承", "交钱", "擠", "bbs", "议题", "旗", "冲进去", "原力", "周遭", "hundreds", "真高興", "宪兵", "橡皮", "卡琳", "枷锁", "崩塌", "宣读", "滚回去", "时段", "太妙", "短缺", "狒狒", "采购", "母子", "frau", "成像", "卢布", "期間", "获救", "马林", "消亡", "russian", "窥探", "癚", "对岸", "搞掂", "找来", "伍迪", "坟", "面上", "別想", "技术人员", "四季", "cap", "车间", "过些", "怒", "春季", "晒太阳", "戴安", "追溯到", "万英镑", "bernie", "壁", "临近", "水壶", "杜鲁门", "阿明", "開火", "闯祸", "項目", "平松", "大话", "信服", "图画", "世界大战", "競爭", "wood", "放回", "纳特", "越久", "咕咕", "钟爱", "勘", "显著", "卡斯帕", "紮", "一万块", "小睡", "vice", "工作者", "驱动器", "副官", "迷糊", "舞曲", "两分", "鸡皮疙瘩", "weak", "草率", "赤", "东区", "散落", "闷死", "ﺝ", "先例", "驼背", "攻破", "棒子", "恶臭", "挨着", "讯问", "問過", "精神分裂", "sees", "光照", "趙", "绿洲", "尤物", "丰满", "谷物", "池子", "改为", "千萬別", "粉末", "难办", "stu", "入院", "卑劣", "走散", "快接", "想出", "维娅", "阿金", "小号", "流水", "第一印象", "hobbs", "不象", "火星人", "缺失", "监测", "众议院", "接待员", "彻头彻尾", "草草", "單身", "打嗝", "釣魚", "电波", "竚", "生父", "勾结", "牵着", "病症", "council", "沉思", "回声", "空前", "生计", "腾出", "迁移", "行么", "絲", "shelli", "后续", "侥幸", "逍遥", "harper", "句号", "一百个", "edge", "别为", "相公", "精密", "keine", "miranda", "算计", "suicide", "如此而已", "泰迪熊", "小吃", "prefer", "副局长", "发牌", "万年", "科學家", "私密", "劲儿", "花掉", "彿", "做作业", "爽快", "医药", "shower", "指标", "扫荡", "missy", "幌子", "美洲狮", "气愤", "fingers", "前头", "讲过", "至上", "狂欢节", "invited", "马屁", "阿正", "战败", "ご", "接入", "无时无刻", "texas", "上交", "卖完", "能动", "帝王", "德洛", "右脚", "移走", "崋", "费尔", "发问", "瓜葛", "dies", "干草", "来头", "茱莉叶", "對面", "蒙蒂", "喏", "变革", "茱", "裘", "始", "説", "窩", "宽敞", "严峻", "拌", "狗叫", "婊", "水星", "狱中", "搬运", "凭着", "celestial", "瞬間", "平安夜", "胡佛", "凭借", "格拉斯", "issues", "嗝", "痞子", "查询", "中期", "家庭作业", "小杰", "囊", "ヰ", "翻过来", "职", "亲身", "unit", "第四次", "挤满", "riley", "在場", "protection", "重写", "兴起", "几星期", "限", "va", "年幼", "當作", "飞逝", "曼纽尔", "指紋", "史诗", "大牢", "头版", "分析师", "换班", "恐怖片", "lou", "witch", "信上", "之谜", "带入", "birds", "祭祀", "气压", "包在", "竧", "moves", "戰場", "踏入", "弗吉尼亚州", "破例", "结帐", "施加", "野牛", "彼德", "但会", "knowledge", "鐵", "联络人", "投胎", "天命", "手持", "卡辛", "痉挛", "沒想過", "這的", "最烂", "人像", "平淡", "秤", "opie", "四年级", "孔雀", "劳力", "小杂种", "纵容", "红心", "乌尔", "禁足", "圆形", "译者", "外语", "自由自在", "查清", "蒙在鼓里", "退伍军人", "正试图", "布里奇", "freeze", "跟个", "废话少说", "co", "burrows", "归功于", "叁", "贴着", "女服务员", "腐蚀", "南北", "原住民", "谢绝", "长寿", "嗜", "写过", "向东", "燕麦", "silly", "德國人", "亭", "长辈", "我变", "perry", "搓", "砰砰", "former", "变换", "阶梯", "编程", "視頻", "brilliant", "wings", "芠", "抗体", "天晓得", "死党", "奥古斯丁", "雨衣", "份量", "original", "adrian", "繺", "這怎麼", "写些", "入伙", "洗劫", "北上", "大雪", "自主", "荧幕", "奇幻", "为傲", "journey", "一族", "天賦", "穆勒", "红外线", "signed", "bridge", "复兴", "謀殺", "达利", "釋放", "刺刀", "剪头发", "抑郁症", "某件事", "与世隔绝", "分担", "怎會", "绝园", "赤裸裸", "split", "立法", "界线", "ù", "白酒", "猥亵", "指南针", "梳子", "图斯", "м", "lately", "airport", "凯丽", "卫生纸", "流向", "二百", "terms", "布莱尔", "无忧无虑", "grown", "stern", "desk", "储物柜", "到現", "加森", "決", "一想", "屋頂", "關掉", "接个", "一卷", "tout", "新一", "病菌", "forces", "底细", "已然", "起到", "弥赛亚", "sherlock", "拉玛", "sweetie", "紀念", "螤", "拉倒", "几根", "克里斯多", "异性", "纽约州", "首长", "surely", "ans", "学生会", "引进", "二级", "菲力", "共用", "米尔斯", "五郎", "ô", "动员", "累赘", "很穷", "鸣叫", "exist", "能治好", "坏小子", "变大", "太老", "生子", "毒贩子", "便条", "五人", "它會", "虎鲸", "黑板", "达米安", "歌剧院", "临床", "馒头", "人身", "音频", "我試", "好办", "别耍", "瑀", "转角", "防弹衣", "统帅", "描写", "village", "浓度", "捱", "假牙", "前锋", "抹掉", "篡改", "扔给", "吸尘器", "雪人", "花店", "脱衣舞娘", "奉承", "我气", "木筏", "dressed", "马西", "江户", "溫柔", "意下如何", "想不起", "空手", "马利", "中國人", "挑战性", "没病", "容貌", "維持", "cheese", "毒枭", "相配", "sharp", "咬住", "会痛", "烦躁", "一岁", "重型", "哈雷", "无所畏惧", "之路", "攻击性", "创", "下載", "tie", "支柱", "好重", "彼", "通风", "鼻", "丧尸", "新來", "前世", "惊醒", "老頭", "公然", "主谋", "禫", "康威", "奖项", "战维", "岈", "沈", "一角", "追上来", "灭口", "benny", "周年纪念", "山本", "太低", "一两次", "鱼儿", "開會", "笛子", "whom", "信不过", "缩短", "赴", "rome", "打下", "打拳", "familiar", "美利坚合众国", "使徒", "florida", "埃米尔", "杰姬", "塔台", "insurance", "很明顯", "微生物", "主妇", "oscar", "大師", "那回事", "原话", "之家", "赛事", "改良", "灌醉", "欧里", "surface", "转悠", "一闪", "泰森", "提米", "小孩儿", "舌", "郑重", "失血过多", "finds", "两三个", "錶", "充当", "下过", "商务", "大吼大叫", "犯了错", "成家", "焦", "李斯特", "疑似", "liv", "ケ", "尚宇", "圣衣", "遗愿", "多得多", "衣着", "卡蜜", "sergeant", "这幢", "ears", "头领", "惊慌失措", "吉特", "身体健康", "威尔森", "肆虐", "矿", "火种", "接招", "矢", "鲍威尔", "掉落", "交通事故", "拖拉机", "oil", "圆圈", "透顶", "检方", "分发", "培育", "通用", "各大", "引入", "讨人厌", "罢手", "渔民", "生命力", "eggs", "弄乱", "手无寸铁", "肇事", "票房", "好谈", "大理石", "爬起来", "一刻起", "爱护", "自助", "歌詞", "nach", "filled", "供词", "游览", "hook", "截肢", "没读", "细小", "一章", "duke", "出车祸", "致意", "蓓", "长远", "结了", "带头", "再放", "恭候", "韦斯特", "瞦", "装上", "退化", "出人命", "將要", "斯维尔", "蠕虫", "求爱", "isaac", "蓝华", "春假", "狐", "许多年", "即将来临", "淡", "裸", "真情", "地爱", "我受", "海扁", "塞拉", "不成问题", "塔尼", "郵件", "liar", "abba", "前才", "玲玲", "别弄", "太烂", "ナ", "凶恶", "好樣", "些小", "代言人", "橱柜", "乌贼", "採訪", "货船", "洋流", "毫无价值", "闭上眼", "返航", "分泌", "炸开", "面容", "快想", "凶狠", "垃圾场", "bond", "历史学家", "李奥", "史黛拉", "复印件", "sonny", "學家", "天气预报", "washington", "personally", "电器", "合照", "谨", "嚎", "新奇", "ﺌ", "狮子座", "η", "过年", "欧洲人", "六次", "罗拔", "无非", "ぎ", "大好人", "如愿", "小林", "奔波", "首府", "倒车", "紧点", "弓箭手", "公务", "看不下去", "帐号", "憎恶", "所有权", "那帮人", "饿坏", "长途跋涉", "附带", "会救", "fellow", "西区", "屠宰场", "飞龙", "avoid", "往南", "車裡", "intelligence", "水来", "每样", "梁", "巴格", "移到", "诺特", "元老院", "店员", "很准", "加利福尼亚州", "gilbert", "山下", "spring", "特伍德", "冲出", "发票", "疼爱", "morty", "好好看", "构建", "回转", "延误", "太平间", "那来", "飞鸿", "stevens", "juan", "becomes", "扭伤", "流失", "测谎", "癮", "兄", "南美洲", "市長", "我太累", "格雷斯", "diaz", "唱首歌", "内务部", "數", "哈伯", "expecting", "europe", "被动", "奇普", "服饰", "输出", "trevor", "宾夕法尼亚州", "巡逻车", "奄奄一息", "再次发生", "stayed", "小手", "野兔", "措手不及", "断掉", "create", "向左转", "失窃", "決賽", "两面", "弄些", "久留", "mentioned", "绝非", "褐", "opinion", "泰西", "小车", "听著", "ships", "咋办", "花園", "婚约", "罗利", "恋童", "严酷", "牛群", "警笛", "要來", "派出所", "屋檐下", "維克多", "布伦南", "横滨", "硑", "布达佩斯", "獵人", "常去", "hood", "陀", "飲料", "一点一点", "chosen", "watson", "ellis", "细微", "ﾐ", "龌龊", "做客", "蜻蜓", "北非", "饺子", "漢", "没有勇气", "手杖", "說服", "鑽", "morse", "指点", "推论", "气象", "信里", "一米", "魔界", "sid", "三秒", "rat", "grady", "莫里", "贾斯珀", "结晶", "gabrielle", "simpson", "raised", "脑残", "火警", "谦卑", "丑恶", "研究生", "液", "楼里", "鎮", "贾德", "臮", "校服", "晴天", "领事", "唉呀", "夜色", "车主", "confused", "擦干", "问下", "正午", "偏远", "那名", "约旦", "晚點", "不記", "bud", "以牙还牙", "圣水", "钱德勒", "按着", "大利", "你當", "讲座", "禜", "猳", "soft", "赞助商", "镍", "琐事", "标语", "舍", "教他", "奉陪", "國", "满地", "早些", "假话", "储蓄", "先得", "加重", "avery", "outta", "交际", "拉近", "個小時", "满满的", "suck", "沃斯", "驶向", "录用", "東京", "可敬", "大风", "任何理由", "布鲁塞尔", "抓好", "赶往", "聚餐", "爬上来", "发言权", "不宜", "微波炉", "珀斯", "dottie", "唇膏", "下楼去", "一夜之间", "强有力", "走火", "有辆", "算命", "全名", "多吃点", "消滅", "一天天", "pony", "扭断", "砖", "部長", "施密特", "sandra", "隐居", "謝天", "中奖", "杀虫剂", "砃", "移除", "跤", "倒楣", "她們", "服部", "侯", "謝地", "留恋", "左舷", "杂志社", "寄出", "亿元", "腕", "后要", "米罗", "stella", "complicated", "poison", "颠簸", "求饶", "這可", "會長", "发声", "照射", "记不得", "生平", "巴不得", "大到", "自毁", "侈", "越远", "stronger", "扑灭", "果子", "诀窍", "打官司", "十块钱", "四眼", "百利", "注射器", "黑发", "班车", "筒", "screw", "监察", "engine", "zum", "文书", "精神失常", "數據", "坐过", "辛蒂", "麦加", "藏有", "cheers", "不高", "长子", "口感", "女招待", "走遍", "試驗", "settle", "津贴", "难关", "belongs", "分到", "游走", "guards", "军装", "米哈", "hurts", "斗志", "subject", "符咒", "籐", "俯冲", "淫", "警察局长", "一串", "舆论", "mercy", "得花", "valerie", "彩", "雪诺", "何人", "older", "任期", "棕榈", "letters", "枪响", "帕尔默", "防火墙", "callie", "排骨", "古斯塔夫", "破旧", "张纸", "毕业典礼", "酕", "面包店", "蒙特利尔", "student", "文物", "竭", "ana", "喝了酒", "一见", "恩爱", "大脚", "星球大战", "少许", "第一集", "甫", "mostly", "claim", "牢记", "回忆起", "愛他", "身世", "换作", "球场上", "好几", "forced", "冲过去", "horses", "几秒", "婚外情", "手放", "dans", "太巧", "偶", "选拔", "曰", "黎巴嫩", "斯特林", "扫射", "進攻", "风味", "割开", "诠释", "未有", "衰", "开创", "冒牌货", "感受一下", "打電話給", "荒废", "话筒", "书本", "祭典", "霜", "塞缪尔", "恰到好处", "一侧", "华伦", "婚戒", "干点", "读取", "乌云", "置身", "壶", "点水", "读数", "就照", "introduce", "训练营", "全身而退", "拉皮条", "作戰", "沉船", "止痛", "主題", "surveillance", "bee", "安德列", "goin", "問我", "欴", "叛国罪", "装好", "诺贝尔奖", "疑点", "情势", "美美", "起因", "荐", "密歇根", "钻头", "降下", "flowers", "fail", "特长", "层次", "皇", "册", "小流氓", "色鬼", "scg", "游戏机", "清澈", "西洋", "动向", "辞", "喝彩", "chicago", "肉类", "靠不住", "第十三", "出人头地", "flat", "伊莲娜", "框", "驱逐出境", "来福枪", "寻宝", "园子", "沮", "先回", "不符", "空着", "老爷爷", "宿主", "敵", "toby", "federal", "十五岁", "妙极了", "听闻", "减弱", "实时", "神魂颠倒", "战事", "无所不知", "可救", "敢于", "鬼才", "信守", "食用", "毛毛", "枯燥", "贞操", "宝剑", "右邊", "航天飞机", "得太快", "赡养费", "打翻", "淡水", "有救", "不缺", "史东", "教會", "瘸", "伊织", "两秒钟", "租给", "那么回事", "pope", "千金", "想个", "经验丰富", "比克", "潜逃", "darkness", "spike", "伊利亚", "汪", "你永遠", "甜头", "嘉莉", "誠實", "递交", "少量", "僅供", "博士学位", "谢利", "貸款", "真谛", "之身", "雷尼", "嗅到", "买好", "灵光", "ト", "睡前", "michaela", "阿伯", "复制品", "尔菲", "乘船", "老手", "自保", "unh", "小麻烦", "好點", "马洛", "苦苦", "随时随地", "这一关", "士官长", "immer", "pr", "不单", "满分", "知識", "磁铁", "grandma", "狶", "情报员", "lionel", "崽子", "排列", "nor", "热线", "快车", "围", "两只手", "棒極", "ﺙ", "spare", "寄生", "格洛", "求情", "芬芳", "附加", "偏要", "要放", "推向", "這片", "洛奇", "小忙", "说辞", "wet", "提拉", "聘用", "拖延时间", "枪口", "卵子", "候补", "白领", "瓦西里", "姥姥", "二手", "男孩儿", "naked", "有利于", "secure", "crack", "莎伦", "公共场合", "得主", "轮廓", "矼", "教科书", "聯盟", "生成", "骨肉", "平時", "佛教", "nelly", "群山", "之處", "浸", "自作聪明", "喷雾", "深情", "新闻界", "逃不出", "example", "蒙古", "蓝天", "走不动", "mack", "两艘", "cyrus", "规范", "苦痛", "纳尔逊", "泣", "jet", "rahul", "是給", "toilet", "graham", "核武", "稻草", "防水", "身价", "签下", "網絡", "洋人", "税务", "曲目", "多于", "苗条", "elliot", "開口", "爱德", "valley", "场子", "涉足", "阿克", "proper", "临终", "自然而然", "茲", "jan", "停车位", "摆弄", "昆", "页面", "永存", "水族馆", "弃权", "对立", "四条", "惨剧", "感動", "八道", "世伯", "相像", "潮水", "brick", "加勒比海", "協助", "帕切科", "underwood", "一毛钱", "不为人知", "india", "射箭", "绕过去", "神探", "ド", "溜出去", "林子里", "运走", "lesson", "安全措施", "犹他州", "工資", "纸杯", "教派", "階段", "秘密警察", "它用", "綠色", "稱呼", "捆绑", "洋装", "索取", "付不起", "official", "转世", "安托万", "处以", "chuckles", "气喘吁吁", "這並", "阴毛", "陈先生", "宝马", "幺", "诺兰", "我梦到", "意识形态", "奋力", "芹泽", "李察", "斯博士", "半径", "斯图亚特", "marcel", "吓倒", "顶峰", "ψ", "冲绳", "阿祖", "雷切尔", "尼诺", "箭头", "法尔", "临死前", "会付", "wolowitz", "伤脑筋", "不长", "劳勃", "ニ", "一地", "残疾人", "紧急状况", "fantastic", "不二", "滑冰", "一期", "勇敢的人", "海登", "tower", "shots", "托盘", "启用", "marks", "执勤", "请接", "凝视", "dd", "permission", "粂", "铁丝网", "應付", "法典", "疯掉", "棒呆", "虏", "柯林", "trace", "捉到", "暴雨", "赤道", "cares", "兴奋剂", "offered", "用具", "付帐", "守候", "bout", "丝袜", "搖滾", "此话", "藝術家", "这活", "铁匠", "衰竭", "留学", "設備", "之事", "等等等等", "高斯", "别骗", "看够", "你活", "佩妮", "滚动", "终端", "电话铃", "屬", "不起眼", "奥运", "阉", "坐以待毙", "然後再", "ﾘ", "决定权", "通灵", "离得", "泰特", "報道", "得病", "两起", "advantage", "搞不清", "泪", "八百", "救回来", "递", "前程", "班里", "纽曼", "saturday", "推特", "想学", "心率", "刚回来", "安全性", "长矛", "日日", "白金", "五秒", "亮光", "记在", "增大", "喂食", "填充", "心理治疗", "有生之年", "六千", "闺蜜", "没要", "利马", "航空母舰", "视网膜", "辛西娅", "成群", "两场", "soll", "低语", "攀", "堵塞", "loving", "小道", "查不到", "攻下", "萨斯", "八号", "阿瓦", "嚎叫", "侖", "库斯", "我願意", "事想", "布莱顿", "奠定", "奥拉", "多尼", "hetty", "ffffff", "大峡谷", "红头发", "贬低", "player", "研制", "嘶", "击打", "对着干", "request", "对白", "代表团", "帮凶", "溺死", "想家", "缘分", "陛", "身為", "leads", "類型", "人品", "招手", "destiny", "disappeared", "摄影棚", "cbs", "修斯", "节约", "多多关照", "不比", "眼淚", "表决", "推荐信", "产卵", "青睐", "詹姆", "合得来", "專門", "德瑞", "鑒", "俄國", "一小块", "华尔兹", "褪色", "格子", "愚昧", "开拓", "不疼", "forgotten", "cassie", "日渐", "erik", "维利", "独居", "米苏", "超强", "琼恩", "撥", "周全", "纳粹党", "高高在上", "回心转意", "乡间", "条狗", "饲养", "尝过", "desire", "早前", "数以千计", "previously", "例行公事", "ﺱ", "很樂意", "incredible", "society", "伯克霍", "ace", "埃斯特", "屏蔽", "nonsense", "低点", "主修", "breathing", "天桥", "style", "蘸", "吉祥物", "异性恋", "十几岁", "自負", "發生過", "遇难", "diamond", "医护人员", "苏利文", "餐巾", "扬声器", "屈克", "yourtear", "大樓", "我人", "约克", "大伯", "谜语", "胞胎", "让我拿", "辛克莱", "疗程", "regret", "usual", "小傢伙", "斯德哥尔摩", "癶", "这像", "脏兮兮", "有效率", "铝", "轻率", "袍子", "chappie", "输光", "种马", "ﻯ", "统领", "大灾难", "出不来", "那群人", "惩", "并用", "粉絲", "霍金斯", "科比", "维达", "重量级", "全校", "梅西", "毋庸置疑", "suv", "分钱", "麦考伊", "核磁共振", "决议", "莫名", "所料", "county", "素食", "伸出手", "树立", "佩尔", "放心好了", "seal", "擁抱", "安格斯", "相会", "顾", "曼联", "好时光", "令人厌恶", "湖泊", "地堡", "奈子", "有话直说", "bat", "出马", "曬", "投靠", "累积", "陷入困境", "模", "若能", "成百上千", "艾尔文", "浴", "guests", "拍卖会", "蠢驴", "创业", "庇佑", "贩毒集团", "带进", "美月", "课长", "总想", "小兵", "禾", "搞好", "我當", "亞當", "差遣", "做会", "徒", "打网球", "诚信", "判处", "漫画书", "绳之以法", "gray", "插进去", "zone", "办个", "小店", "哭声", "疯婆子", "删", "ancient", "bedroom", "祅", "黑桃", "抓緊", "艾尔莎", "踢出去", "娼妓", "揽", "压缩", "许个", "不相干", "高一", "tongue", "su", "行头", "哪一", "決心", "太妙了", "自个儿", "免除", "elise", "下贱", "旅行社", "钢笔", "frm", "绪花", "货真价实", "鎮上", "那道", "总说", "两部", "第一份", "焦糖", "胆怯", "铀", "图纸", "批货", "卡萝尔", "不止一次", "里安", "cards", "發動", "碟子", "一事无成", "登船", "才艺", "職責", "没关", "鹤", "面目", "盛会", "抓人", "辍学", "reasons", "彩蛋", "百货公司", "web", "泡茶", "联合会", "车顶", "深沉", "多情", "î", "人种", "多着呢", "飞舞", "弗莱迪", "阿爸", "大坏蛋", "园艺", "jaclyn", "短片", "吉他手", "真香", "十字军", "里会", "言行", "丝绸之路", "水坝", "斯人", "算算", "卡西迪", "信教", "诚心", "那面", "这架", "货运", "怎知", "mystery", "枪击案", "再待", "处分", "世子", "主播", "写诗", "王宫", "思索", "阿诺", "沙克", "赛段", "砸碎", "轻声", "瞞", "鸟事", "千米", "想得", "雷电", "流入", "艾利", "認得", "红宝石", "繩子", "信条", "买主", "伯克", "舒", "螺旋桨", "埃利斯", "abbott", "少将", "弹簧", "嫁妆", "沒人能", "妇人", "解開", "回報", "归属", "喷射", "wally", "shore", "扔下去", "mile", "诺克", "knees", "跋", "高級", "keller", "搬来", "exchange", "λ", "午后", "谚语", "别拍", "整栋", "開著", "苏格兰人", "斯托克", "石块", "丽娜", "气死我了", "出气", "十点钟", "羊群", "咱倆", "media", "而定", "谢恩", "运动鞋", "庫", "急切", "马来西亚", "pablo", "弄醒", "病历", "約定", "buried", "piss", "十次", "好长", "falls", "有缘", "土著", "plays", "挥霍", "密度", "tag", "玛塔", "麦肯齐", "弗莱彻", "路途", "鼹鼠", "深信不疑", "patterson", "艾丽丝", "维系", "暴政", "cam", "数学家", "筛选", "弗雷泽", "格莱美", "假冒", "有场", "一举", "宗", "闲着", "放人", "乡下人", "矫", "赐福", "吻别", "lower", "圣上", "旗下", "别扯", "halfcd", "拍子", "硉", "火神", "phoebe", "particular", "几百个", "大骗子", "玉米饼", "コ", "情歌", "笔钱", "meal", "birkhoff", "瞳孔", "condition", "死得", "wells", "快過", "半個", "用车", "如实", "撬开", "cho", "九号", "股价", "创造者", "传奇人物", "搏击", "咬掉", "时有", "走運", "信誉", "現金", "pounds", "高超", "共产主义者", "燃油", "说不清楚", "弄到手", "两侧", "赛车手", "发生意外", "探视", "特里普", "觀點", "辖区", "公演", "喜翠庄", "弄个", "刚果", "灌木", "星巴克", "倖", "螘", "煤炭", "伯德", "巴斯克", "bucks", "exciting", "赛德", "堤", "身躯", "richie", "嚇死", "一向如此", "rough", "醫療", "山寨", "willow", "商讨", "晴朗", "晚期", "乐在其中", "cameras", "试用", "别开", "尿床", "很困", "比萨饼", "投掷", "前不久", "帕克斯", "削", "广州", "hung", "大黄蜂", "取得联系", "汗水", "美式", "夫斯基", "剪断", "雪球", "怒吼", "酒会", "吃素", "调度", "托克", "读懂", "插曲", "aj", "一段路", "圣保罗", "之母", "手机号码", "广告牌", "波罗", "格里格", "換", "绝大多数", "rescue", "氣氛", "校车", "ganz", "分支", "我载", "竡", "蔡", "这桩", "紫罗兰", "戒严", "elle", "宛如", "喝掉", "是我太", "凭空", "太监", "雪崩", "movies", "辭職", "挥", "维纳斯", "快救", "彼岸", "冲出去", "一生一世", "麥", "賣給", "创世", "指手画脚", "卢瑟", "衣裳", "呜呜", "上樓", "读到", "區別", "互相残杀", "血缘关系", "男仆", "实质", "一丝不挂", "褫", "豪哥", "悲劇", "缠身", "安检", "纱", "費", "bull", "街坊", "faces", "你常", "没上", "神经系统", "哇哇", "蹂躏", "康纳斯", "哉", "消散", "二十个", "推车", "玛妮", "另一名", "开门见山", "糕点", "members", "逐步", "安顿下来", "有染", "保护费", "东海岸", "廣場", "showing", "浑球", "超凡", "蓝眼睛", "批", "出众", "抓起", "选个", "金姆", "玩够", "纯正", "白昼", "button", "丁丁", "released", "瓦伦", "进过", "广岛", "哥本哈根", "万里", "range", "要换", "此前", "害得", "bay", "amount", "chad", "answers", "tina", "令人吃惊", "就读", "tiger", "肉眼", "downstairs", "解体", "有张", "真难", "放射", "自尽", "派瑞", "pulling", "悠", "死心", "苦衷", "重头", "我手", "四万", "fully", "山头", "德克萨斯州", "善事", "真坏", "几步", "忌妒", "保险金", "台灣", "陈年", "rights", "holiday", "待过", "拦下", "三角形", "olive", "秃鹫", "weil", "惬意", "喳", "enter", "这款", "noise", "莉莉丝", "辨识", "全完", "也罢", "vision", "eventually", "死鬼", "cases", "崩潰", "戏法", "一等", "梅兰", "考特", "看招", "海尔", "没得选", "四块", "出其不意", "游侠", "老千", "化成", "正因如此", "挤压", "expected", "最佳人选", "村上", "我勒个", "浮出", "头皮", "高原", "shannon", "能来", "转头", "猿", "inspector", "switch", "下辈子", "北约", "kingdom", "番", "低音", "ホ", "鼓勵", "财团", "熨", "蠢话", "ゝ", "spell", "winchester", "毫无用处", "锚", "十块", "听命于", "頭上", "一万元", "博物", "科克", "陆", "传送门", "咻", "水落石出", "vito", "作画", "警校", "自作自受", "我换", "站岗", "coast", "全市", "口吃", "載", "我太爱", "墨索里尼", "支枪", "醒來", "进而", "小山", "關照", "深切", "agos", "色拉", "里亚蒂", "聚聚", "精疲力竭", "分量", "professional", "发热", "史前", "魔镜", "蘇聯", "劑", "交手", "停顿", "降生", "泄气", "长途", "預備", "胸腔", "普林斯顿", "号车", "德兰", "塔利", "芳心", "招人", "easily", "罙", "越界", "md", "陪你玩", "看一遍", "一次次", "性高潮", "gallagher", "敷衍", "刀锋", "chain", "查派", "百分之", "醉醺醺", "生态", "morra", "爬行", "蛋黄酱", "heh", "醒目", "怀中", "开路", "飞镖", "確信", "neil", "demons", "真替", "璉", "领悟", "臭屁", "不笨", "胶囊", "洗衣房", "科曼", "康斯坦", "汤匙", "气泡", "溫暖", "想問", "迪斯", "甜食", "党派", "欢快", "霸王", "hired", "抛锚", "默契", "麻醉剂", "管得", "孟山都", "revenge", "challenge", "拉吉", "墳", "暂且", "回房", "年老", "越来越少", "小红帽", "消防车", "十七岁", "朗姆酒", "睦", "漢娜", "霍顿", "作伴", "快艇", "怀旧", "高傲", "丝带", "膝", "迷雾", "表達", "裝置", "崆", "绕道", "十几个", "小儿子", "快放", "有權", "竖", "撤走", "钻井", "库拉", "tracy", "grandfather", "隔离区", "穿衣", "伦理", "首位", "事端", "浓缩", "古城", "面麻", "students", "极力", "哈迪斯", "喇嘛", "康斯坦丁", "多利", "一筆", "敷", "呣", "渔船", "科罗拉多", "午睡", "穿件", "終于", "幸运儿", "珍妮弗", "内地", "數字", "无影无踪", "号机", "otto", "臂", "连个", "还用说", "张大", "对得起", "nora", "恶行", "回覆", "嚯", "斯宾塞", "一陣子", "我主", "opening", "充满活力", "幻覺", "宝贝女儿", "买房子", "牢固", "柯特", "包抄", "击溃", "大山", "顶替", "好闻", "瘀伤", "写个", "塔玛拉", "lips", "image", "账本", "肢解", "ю", "reality", "买回来", "palmer", "闷闷不乐", "适可而止", "溶解", "佰", "收尾", "安德里", "耗费", "放水", "心脏病发", "簽字", "坍塌", "真相大白", "库存", "潜能", "牵涉到", "亲友", "截获", "併", "答覆", "冲走", "technology", "定论", "撑下去", "危機", "牵制", "引人注意", "laurel", "此类", "已到", "巡查", "五名", "倒不如", "经济学", "划分", "金錢", "电锯", "走過", "射精", "汉密尔顿", "框架", "鬼呀", "低俗", "密集", "独占", "学了", "节拍", "几块", "我超", "请柬", "冲到", "没话说", "笛手", "假設", "斌", "服裝", "卧倒", "哪会", "肥肉", "卡曼", "峰会", "rocks", "ba", "庄稼", "medicine", "栖息地", "酥", "从小到大", "甜菜", "搭理", "我往", "俗气", "听觉", "赝品", "weather", "确凿", "本庭", "伊莎", "雷斯", "孟菲斯", "构想", "控制系统", "你学", "timothy", "肉身", "蔡斯", "香气", "今年夏天", "电磁", "幸會", "荒芜", "痒痒", "回旋", "错失", "全體", "婭", "嘴边", "老掉牙", "积雪", "屠宰", "ｿ", "変", "西蒙妮", "珠宝店", "涡轮", "典范", "电网", "银幕", "破晓", "打打", "串通", "军服", "ernie", "库什", "ë", "交接", "奥克兰", "飞机场", "购", "嗡嗡", "即使如此", "内华达", "州政府", "抓来", "莱斯利", "卡拉汉", "景观", "打炮", "琜", "斯蒂尔", "妹夫", "采纳", "磅重", "交友", "爱莉", "按摩师", "心靈", "老古董", "血债", "健美", "发臭", "地向", "wash", "援军", "黑匣子", "水库", "炮兵", "日程表", "武", "颗粒", "樓梯", "倒回去", "啤", "梵高", "莲花", "辅", "前要", "浪潮", "传讯", "蘇珊", "萌", "dealing", "多棒", "对头", "kay", "南极洲", "臭虫", "濒临", "追不上", "潮汐", "babies", "一瞬", "蓝领", "摆好", "令人不安", "几百", "远远不够", "用词", "索达", "沧", "农庄", "罗宾逊", "这不像", "bone", "当铺", "粮", "窮", "射穿", "签订", "傷", "迫不得已", "joffrey", "wound", "阿孝", "適應", "茱蒂", "巴掌", "勇猛", "软禁", "伸直", "打喷嚏", "rufus", "aye", "议程", "心软", "海港", "攪", "萨克斯", "桩", "ordered", "县长", "第三者", "刀疤", "served", "撞坏", "神迹", "双人", "听得", "invite", "暗影", "cookie", "顺眼", "呼救", "防范", "麦尔斯", "snake", "滚石", "不正", "亚历克", "前额", "很慢", "仅剩", "吉安", "主義", "重创", "一千元", "迎合", "化学物质", "ㄨ", "旺", "专属", "小腿", "多夫", "有助", "影星", "两头", "瑞拉", "solve", "披肩", "座标", "阿玛", "sofia", "打鼓", "全额", "苤", "隔绝", "捡回来", "睿", "miracle", "route", "千元", "大石", "派特", "衰人", "三十岁", "雜種", "節", "ticket", "opened", "大点", "待會", "本校", "capable", "朋友家", "一味", "重叠", "受雇", "用水", "星辰", "term", "送行", "お", "民", "救護車", "路易斯安那州", "hale", "遣送", "当代", "己经", "巨头", "评论家", "审核", "kara", "定制", "聞", "halt", "沦陷", "辛辛那提", "喷发", "tucker", "没长", "毛泽东", "粗心", "往里", "beating", "贝尔法斯特", "危", "芽", "帶上", "リ", "哈勃", "appear", "天涯海角", "远足", "殺案", "手提", "挫败", "練", "杰利", "理发店", "食言", "garage", "失踪人口", "发自内心", "第二集", "原位", "传授", "红衣主教", "活下", "萧", "放个", "表示感谢", "光明正大", "老媽", "lena", "蛆", "小女", "史莱克", "能查", "司法部长", "mistakes", "藏身之处", "过个", "许久", "血样", "贝塔", "鲁尔", "direct", "完好无损", "海风", "整合", "阳性", "白血病", "經營", "湿润", "法兰克福", "全然", "margaret", "来源于", "高端", "小甜甜", "摄制组", "火葬", "膀胱", "放上去", "华德", "奢望", "查斯", "血淋淋", "阿福", "靴", "nicky", "支离破碎", "drove", "着装", "寻", "出乎", "布列塔尼", "比安卡", "小王子", "空空", "最远", "佩特", "上限", "lexie", "知识分子", "兜兜风", "发电", "背影", "战区", "说件", "逸", "茶壶", "特价", "屁用", "flag", "通話", "赻", "而己", "另一侧", "普特", "deliver", "球杆", "福气", "投资人", "掀", "难以忍受", "夏曼", "铜板", "餐桌上", "葡萄干", "pelt", "avec", "若想", "特蕾莎", "一頭", "巅峰", "焕然一新", "不省人事", "荷莉", "八婆", "原著", "忧愁", "nation", "apple", "曼蒂", "吽", "煩惱", "藝恩", "扬", "劝劝", "转给", "我加", "适宜", "中西部", "warning", "卡路里", "受邀", "干干净净", "每一刻", "利比亚", "陽光", "泰克", "arrive", "想成", "骨架", "弧杠", "麦子", "吃糖", "方块", "相關", "茱丽叶", "肚子痛", "norman", "某种原因", "來給", "注明", "小学生", "永久性", "第二年", "燙", "锁匙", "阿叔", "伯里", "progress", "層", "下游", "還有別", "罗格", "咬人", "梦魇", "大酒店", "發揮", "audrey", "无名氏", "這我", "幼虫", "壓制", "拉美", "杂耍", "流鼻血", "田纳西", "不景气", "model", "各有", "硫磺", "lannister", "地来", "別哭", "残杀", "深远", "风雨", "当日", "華", "史帝夫", "因果", "看门人", "第一轮", "moore", "十九", "玻利维亚", "fi", "heck", "发邮件", "满口", "庄家", "增添", "先走一步", "没生气", "不可收拾", "内情", "重新安排", "他付", "河岸", "period", "独", "届时", "海狮", "极具", "懊悔", "润成", "attacked", "detail", "发到", "静脉", "趁早", "操场", "骑手", "我寧願", "笴", "直达", "生物学家", "毛皮", "八十年代", "victory", "公社", "卷心菜", "祖宗", "阿美", "竲", "图书", "艺妓", "贩子", "拍下", "近点", "桨", "认不出来", "头牛", "牧師", "加德", "释怀", "returned", "一整", "下楼梯", "耞", "上流社会", "腿部", "做作", "第一章", "行人", "难民营", "我弟", "多丽丝", "英明", "火光", "洞察力", "冈", "lin", "坏习惯", "shelly", "呼噜", "婷婷", "福林", "睁开眼", "說法", "巨额", "老母", "螒", "悬挂", "往上爬", "溜进", "反胃", "秀发", "以西", "家当", "安逸", "曼彻斯特", "沦为", "warrant", "竞争者", "多拉", "待续", "打车", "相通", "树干", "编写", "solid", "天涯", "市政府", "琘", "nikki", "里尼", "圣域", "建了", "老东西", "狂风", "vor", "doin", "三世", "女同性恋", "偷偷地", "蒂诺", "funeral", "吸管", "盲", "学来", "晟", "传媒", "圣餐", "视察", "苏斯", "摁", "右手边", "小薇", "借過", "深水", "酬金", "击垮", "罗里", "睡袋", "好长时间", "呕吐物", "猜中", "克拉苏", "linux", "这枪", "联系方式", "gentleman", "买通", "令人作呕", "作呕", "口头", "高压", "franklin", "惹怒", "判斷", "正朝", "首脑", "本国", "sisters", "給予", "那钱", "互换", "光碟", "整修", "絤", "加内特", "電梯", "洗清", "一等兵", "胁迫", "亲兄弟", "兮", "算啦", "抛下", "available", "一去", "结巴", "傑", "晚些", "漫漫", "清场", "hearts", "ý", "孙", "高高", "slip", "ear", "别老", "翻滚", "霍乱", "rings", "别站", "墨", "sighs", "搞清", "曼迪", "秋千", "大洞", "難怪", "早知", "sand", "无价", "害臊", "received", "beneath", "替代品", "仙境", "呕", "惊呆", "老妇人", "五千块", "犯罪行为", "正经事", "门多萨", "新墨西哥州", "選舉", "慈爱", "minds", "击退", "要些", "塔夫", "记录在案", "防火", "留有", "送达", "勾拳", "洛德", "主观", "小步", "酒量", "天内", "忍无可忍", "繁星", "毒性", "缓缓", "丸子", "male", "沃茨", "一不小心", "纏", "选上", "烛光", "komm", "黑钱", "抢先", "奶头", "接下去", "几件事", "索隆", "一垒", "筋", "找错", "丟臉", "cruz", "痛心", "第二阶段", "斩首", "柠檬汁", "真大", "central", "管理层", "劳瑞", "烟斗", "克塞尔", "舞动", "演绎", "山路", "飞车", "诸多", "肉麻", "哈姆", "皮塔", "highly", "深知", "白蚁", "笔直", "全民", "physical", "obvious", "煤矿", "晚礼服", "肯尼亚", "风俗", "化学品", "椅", "比索", "我見", "之大", "真实性", "亨德森", "名词", "前有", "u盘", "bleeding", "高登", "咀嚼", "宅邸", "頭腦", "仍会", "断电", "置身事外", "探究", "这书", "选定", "提議", "chances", "tr", "popular", "克利夫", "werden", "英亩", "添乱", "你將", "獨一無二", "无常", "普莱斯", "騎士", "沼泽地", "爸会", "委内瑞拉", "轻柔", "站上", "有失", "死讯", "胰岛素", "whenever", "加个", "败", "两片", "窄", "只花", "ava", "学问", "熏肉", "茶叶", "阴部", "橙子", "甜言蜜语", "阵线", "砩", "药效", "砍下来", "随时欢迎", "searching", "炮击", "猛虎", "炸飞", "远道而来", "彈", "nbc", "國會", "柏斯", "晚间", "celebrate", "健忘", "大冒险", "城市猎人", "单曲", "生命体", "反馈", "车牌号", "剧团", "donny", "sexual", "chest", "sub", "伤透", "西贡", "海明威", "盛", "nnen", "愤世嫉俗", "航程", "烈焰", "plant", "稍等片刻", "黑子", "這只", "許動", "西格", "很能", "嘟嘟", "快让开", "steps", "concern", "以致", "肉饼", "縒", "覆", "通融", "栓", "两千万", "一条线", "甮", "活多久", "求救信号", "哲秀", "阀", "火大", "哈洛", "撸", "一球", "乡亲", "大雄", "那為", "皇太子", "这顶", "第一句", "檢察官", "倍感", "下礼拜", "tech", "糊", "什么游戏", "wheel", "rita", "獸", "wise", "太一", "地盤", "放進", "慢著", "小册子", "肯塔基州", "por", "肯尼斯", "婚宴", "罗柏", "正门", "喷出", "两辆", "荒漠", "三颗", "奥林匹克", "引向", "用刀", "号线", "执政", "哈根", "美少女", "校正", "灰心", "与生俱来", "绝密", "要問", "结为", "烧着", "埃里", "赖瑞", "skyler", "原則", "布局", "深思熟虑", "开店", "喝太多", "杜兰特", "九头", "会帮", "第二位", "莉迪亚", "卷饼", "柔道", "千頌", "会过", "災難", "指明", "新房子", "受命", "练练", "美纪", "殘忍", "小牛", "塑料袋", "committee", "角色扮演", "借过一下", "不常", "土豆泥", "precious", "上述", "疑心", "螝", "烦心", "比比", "真要命", "芝麻", "苏维埃", "信贷", "沙特", "真怪", "哪一天", "诬陷", "兮兮", "座右铭", "苏打", "к", "亮点", "手裡", "大开杀戒", "喝牛奶", "一寸", "卷发", "rare", "珀尔", "高官", "有线电视", "泳装", "摊", "高三", "贯穿", "小儿科", "再要", "格杀勿论", "卡普亚", "挡风玻璃", "可別", "羚羊", "用意", "伊斯坦布尔", "depends", "高个子", "论点", "facts", "言辞", "社長", "梅花", "征服者", "網上", "燕尾服", "喝醉酒", "指導", "身体状况", "第五个", "百分点", "东面", "没问", "不收", "羲", "搭个", "珩", "婦", "吃过饭", "类人", "響", "出境", "聊到", "琎", "预付", "這家", "第三名", "友", "领取", "出了名", "desert", "柬埔寨", "新娘子", "阿尔及利亚", "光州", "恩湖", "集装箱", "trained", "退一步", "好好学习", "literally", "瞎编", "拨号", "腎", "tooth", "买到", "kris", "层楼", "丘比特", "开锁", "dozen", "comme", "作好", "发个", "一代人", "重症", "顔", "上千", "amen", "弗罗斯特", "颁", "走入", "阀门", "二十块", "赌上", "plate", "夷为平地", "珍爱", "prize", "风水", "附", "有待", "victims", "reached", "兰巴迪", "召", "新鲜事", "呎", "焦躁", "踪影", "依赖于", "俄亥俄", "治理", "雌", "风速", "賭場", "记忆里", "pure", "半路", "迎", "tour", "下层", "防空", "快給", "illegal", "拍个", "肆意", "尺码", "流亡", "例", "漂泊", "娘家", "卒", "咬伤", "阻拦", "亲眼所见", "肉松", "忍心", "猛兽", "新教", "带劲", "搵", "jury", "宠爱", "砍断", "要加", "多得", "darcy", "东欧", "新海", "大豆", "警部", "標準", "雪子", "郭", "爷们", "钳子", "鬼怪", "全天", "开朗", "埋藏", "brand", "強迫", "唤起", "黑奴", "三点钟", "连胜", "癵", "曼斯", "螠", "pissed", "chasing", "埃斯", "怨", "scary", "西安", "利特", "dixon", "摇动", "穆特", "兑换", "勇", "提尼", "同性恋者", "傻乎乎", "愁", "brenda", "常务", "高效", "gregory", "真命天子", "流落", "家庭成员", "莫罗", "装腔作势", "cheap", "闭路电视", "election", "泰利", "scylla", "屈辱", "一項", "卺", "第三集", "踏出", "进不了", "event", "传过来", "加快速度", "照应", "宫里", "无心", "匹萨", "亚里沙", "冲过来", "如愿以偿", "別鬧", "维罗妮", "patty", "校", "胡话", "指尖", "toi", "相提并论", "电话簿", "過什麼", "逞英雄", "琠", "kabir", "快带", "莉兹", "バ", "監控", "尸骨", "ln", "科林斯", "皗", "per", "没回", "一团乱", "li", "年内", "伊迪", "谈完", "lola", "fortune", "布雷特", "打雷", "叫停", "攻占", "乞讨", "流下", "内涵", "攒", "current", "何要", "轰掉", "筹钱", "研究室", "dom", "坴", "作弄", "一號", "美人儿", "仓促", "舦", "真多", "jeffrey", "亚克", "補", "反向", "后人", "救护", "鳗鱼", "钵", "garden", "紳士", "内有", "周刊", "西语", "想太多", "給他們", "pied", "崖", "白种", "药剂师", "不晚", "驱赶", "辞退", "不速之客", "杀伤力", "一静", "何以", "孝珠", "desperate", "别难过", "非常适合", "莅临", "職位", "爆裂", "古希腊", "豪尔", "无处可逃", "宅子", "私藏", "詹金斯", "ncis", "豈", "华氏", "有无", "写封信", "窟", "巴奇", "mitchell", "计时器", "掏钱", "拥", "局外人", "追来", "迫降", "允", "物证", "抢夺", "nolr", "laid", "展現", "爱丽", "名言", "富士山", "没辙", "心胸", "制造者", "caylee", "某位", "再過", "书桌", "搬回来", "footage", "甲", "杏奈", "弗尔", "诚恳", "防空洞", "六小时", "老乡", "windows", "私人物品", "direction", "标识", "虚荣", "胡迪", "借点", "荷西", "云雀", "十三姨", "纳迪", "无罪释放", "血肉", "克里斯塔", "勇者", "长生不老", "bound", "街口", "焦急", "參與", "freddy", "repeat", "奥斯", "鱼缸", "爬出来", "动荡", "斯拉夫", "口臭", "蛊", "禁用", "河谷", "选区", "堋", "wave", "疼死", "礼拜天", "荆棘", "阵子", "瞄準", "念叨", "无穷", "人道主义", "晃动", "贴近", "惊险", "霍利斯", "你妹", "革命性", "空降", "锅炉", "吕", "蒸", "一百万美元", "柴火", "心肠", "归咎于", "低贱", "nova", "气来", "达摩", "编队", "破坏者", "保不住", "近况", "hits", "jose", "他成", "门窗", "林奇", "警犬", "橾", "吓死人", "无头", "西欧", "玉米片", "小丫头", "堪萨斯州", "暗算", "随便说说", "ﺾ", "相差", "截止", "径直", "该来", "suffer", "barbara", "不请自来", "抹布", "非正式", "agency", "kirk", "卡萝", "冷酷无情", "vampire", "谢意", "邮寄", "不付", "吓一跳", "紧接着", "pk", "营造", "窱", "猎豹", "文本", "hoo", "几千", "弗莱明", "娘子", "盖亚", "我大", "deputy", "这阵子", "悬", "掘", "盡情", "东南亚", "落水", "辛辛苦苦", "kicked", "抓不住", "履历", "價錢", "辨别", "tall", "获胜者", "德克斯特", "拣", "计谋", "同党", "申请表", "狂奔", "师姐", "畫面", "明尼苏达州", "喷火", "負擔", "推薦", "省钱", "配音", "戴面具", "俄勒冈州", "gross", "当有", "太对", "东德", "這部", "瑞夫", "乱套", "真叫人", "凯迪拉克", "侬", "joan", "课本", "牵挂", "悠闲", "葡萄园", "mouse", "hamilton", "pills", "舒曼", "反面", "凝固", "大公", "阿玲", "洲", "博伊德", "尚恩", "挺好玩", "talent", "重温", "圈子里", "奥斯丁", "维格", "对错", "集團", "商议", "特伦特", "一點兒", "耋", "赖特", "㗎", "還剩", "alle", "砸死", "谋划", "垃圾袋", "指揮官", "荒地", "av", "好酒", "還來", "大胡子", "生母", "checking", "供奉", "断绝", "摧残", "临死", "大力士", "大钱", "curious", "柯尔", "钚", "趁热", "ipod", "电费", "campaign", "无药", "remove", "天上掉", "起伏", "诺维奇", "挺酷", "做工", "触", "损毁", "anton", "伊戈尔", "演变", "有烟", "lj", "太扯", "pilot", "浇水", "投弹", "指路", "同等", "氧", "一百元", "laughs", "drinks", "乐谱", "墓园", "helena", "flynn", "公认", "首个", "共存", "千代", "之徒", "超感", "去給", "国人", "赃物", "全天候", "共和党人", "小宝", "rent", "打瞌睡", "jessie", "囚徒", "stood", "技艺", "索恩", "这狗", "床铺", "呒", "早说", "换件", "北海道", "罖", "三级", "示威者", "谭市", "隐身", "手握", "房間裡", "心地", "关着", "何物", "一窍不通", "吉布森", "反转", "ﾅ", "throwing", "顾及", "立下", "ク", "深圳", "艾利克", "东南", "nadia", "搽", "涌入", "鲈鱼", "捕", "臥室", "monkey", "教母", "素食主义者", "往返", "穿戴", "馋", "拍打", "回想起来", "优良", "援手", "识破", "发病", "阿拉丁", "suzy", "葛雷", "布景", "丈", "violence", "没开", "把守", "两组", "为期", "冠军赛", "两步", "親戚", "冷气", "各方", "费尔德", "crown", "continues", "ka", "说不出来", "排好队", "保有", "山庄", "officers", "磁盘", "肛交", "鬼故事", "对人", "不破", "夜光", "riding", "涌", "很香", "statement", "巩固", "亨德", "巢", "撇下", "sophia", "吐露", "随随便便", "以至", "或種", "五千万", "boring", "carrying", "长眠", "看门", "自恋", "人活", "睡梦中", "原定", "尾随", "要个", "勝祖", "艾林", "woke", "疗伤", "一干二净", "abraham", "辅导员", "密歇根州", "shift", "irene", "bruno", "才华横溢", "冲个", "aside", "输定", "九十", "犹豫不决", "birth", "乔斯", "周先生", "变小", "縀", "异", "不经意", "和玛丽", "四楼", "一模", "贝弗利", "甅", "文件夹", "对峙", "首演", "或多或少", "病床", "stephanie", "低能", "张开嘴", "琿", "混血儿", "摔下去", "侍候", "蛛丝马迹", "药膏", "必需品", "趴到", "三十六", "矿山", "蜡", "教宗", "缘由", "另一家", "committed", "公共场所", "守夜", "touched", "留守", "一時", "抱负", "愛麗絲", "火堆", "throne", "乔安", "纳克", "牵手", "喉嚨", "救援队", "肯恩", "林中", "picking", "bath", "压死", "光靠", "众生", "回击", "robbins", "navy", "实", "四處", "alien", "总和", "魚", "holmes", "手提包", "背黑锅", "紧身衣", "actual", "断开", "菠菜", "押送", "续集", "lyle", "妥善", "交易所", "想用", "ｋ", "撂倒", "americans", "没锁", "虚", "designed", "有线", "峨", "香檳", "迈进", "资料库", "外孙", "站稳", "胆固醇", "睿智", "齐全", "瘾", "松懈", "切口", "拔枪", "有限公司", "笿", "卷轴", "rosie", "兰登", "有感", "沃尔夫", "措辞", "扫地", "勤奋", "绝境", "乍得", "麦当娜", "vegas", "缝隙", "grave", "四大", "蘇", "投机", "源泉", "氟", "关键在于", "敲响", "不计", "别逗", "更快", "季度", "密苏里", "改掉", "技师", "当家", "噎", "顧", "魔幻", "section", "玥", "路标", "我終", "心肺", "画出", "数十亿", "走错", "横", "比格", "钢琴家", "迷惘", "排演", "從頭", "華盛頓", "布尔什维克", "质", "奥古斯特", "del", "別亂", "堂堂正正", "ate", "骸", "bella", "漂", "没油", "那一晚", "意料", "拉拢", "相貌", "二十岁", "伟哥", "一网打尽", "天文台", "马萨诸塞州", "蛊惑", "要挟", "日文", "pizza", "刑罚", "米亚", "琳恩", "远比", "ella", "插管", "我伤", "電子", "艰巨", "拍马屁", "doctors", "brady", "至高无上", "种族主义者", "歇歇", "拉长", "裸露", "寻觅", "壮大", "卡迪拉克", "管闲事", "显现", "爸媽", "被俘", "搞破坏", "骋", "但願", "所致", "重任", "哨兵", "启示录", "我前", "两三天", "弘树", "委员长", "更久", "互助", "柜", "results", "悄然", "错路", "极速", "火球", "事能", "变装", "norris", "诋毁", "健壮", "李子", "止步", "不可或缺", "珀", "减刑", "首要任务", "尼德", "忘带", "臣民", "鸣", "goodness", "电子游戏", "够用", "papi", "妲", "没醉", "分道扬镳", "和谈", "可观", "马鞍", "韓國", "高尔夫球场", "joshua", "虐待狂", "马斯", "k党", "菊", "斯科蒂", "全息", "protecting", "试演", "library", "冰茶", "真糟", "cliff", "他生", "joel", "pool", "要选", "屏住", "布鲁克斯", "阿苏", "基督教徒", "mexico", "侵袭", "何方神圣", "阿拉巴马", "嘗嘗", "热血", "洞口", "偷钱", "急性", "實力", "箉", "穿鞋", "现已", "照旧", "少管闲事", "交由", "安德", "养狗", "關于", "末期", "花钱买", "ï", "设计图", "午飯", "一车", "gravity", "someday", "艾森豪威尔", "成份", "要活", "一家子", "猛禽", "很行", "比德", "帮主", "manage", "buying", "引出", "捐献", "稿", "scare", "錢給", "studio", "trigger", "卢泰愚", "胸针", "席卷", "索赔", "esther", "小报", "偏爱", "生机", "全神贯注", "委任", "参谋长", "热衷于", "打滚", "泡澡", "火锅", "传开", "就夠", "不切实际", "vicky", "caitlin", "下半身", "工作服", "郅", "不敬", "拉瑞", "回响", "行者", "砫", "ip地址", "potential", "mo", "结交", "恳请", "求之不得", "倾", "音调", "馊主意", "立案", "所求", "庄", "答录机", "看什麼", "草案", "营销", "经销商", "熟睡", "ﻉ", "社區", "一吻", "加布里埃尔", "神枪手", "gather", "宽松", "看戏", "列队", "胔", "扶住", "见不得人", "幸福快乐", "德华", "布魯斯", "克莱顿", "失散", "梳理", "混进", "宵夜", "禁锢", "大驾光临", "帥", "查普曼", "抨击", "更坏", "presence", "glasses", "有点痛", "西面", "轮船", "贴纸", "points", "鲍曼", "kobe", "格雷戈里", "告诫", "胎记", "想尽", "住宅区", "马丁尼", "叔父", "japanese", "第一张", "搁置", "掩埋", "解锁", "低声", "university", "adele", "托儿所", "odd", "切入", "拉尔斯", "role", "老大哥", "易如反掌", "沉入", "領域", "到访", "還挺", "yourselves", "同胞们", "sunny", "腨", "那股", "全镇", "干洗", "pa", "債務", "间隔", "以南", "较大", "赖斯", "不论如何", "換個", "贝儿", "变强", "bullets", "通訊", "ruined", "共进午餐", "花粉", "迎战", "波莉", "水吧", "配有", "白葡萄酒", "安德魯", "乔乔", "米德", "回程", "二十一", "污垢", "繞", "峰", "默德", "大宅", "crimes", "当人", "大得", "猎狗", "德川", "人猿", "冈萨雷斯", "遛狗", "阴", "耗", "起疑心", "天际", "冲锋枪", "飞艇", "花哨", "更近", "办成", "盛装", "观光客", "逝世", "劝说", "执事", "攝影", "薄弱", "title", "沒興趣", "包庇", "配件", "莉齐", "收走", "用场", "病痛", "些许", "面朝", "打拼", "辞呈", "抽到", "猪猡", "乱糟糟", "jr", "波恩", "释放出来", "campbell", "折叠", "高校", "负罪感", "絞", "多恶", "我贏", "車站", "盛开", "痴呆", "溢出", "之极", "請別", "紧闭", "转折点", "主義者", "店长", "亏欠", "战前", "魔神", "误", "取下", "卡斯特罗", "小玩意", "小事一桩", "车载", "试穿", "霍夫", "筐", "保险套", "labor", "富勒", "斗殴", "最愛的", "广大", "太棒", "鋪", "這套", "小题大做", "危险性", "帕里", "開個", "娘炮", "jungle", "歡樂", "帶給", "窥视", "workers", "chat", "對象", "轴", "一杆", "进进出出", "可有", "thief", "向北", "抚慰", "廠", "调解", "游手好闲", "所处", "格鲁吉亚", "木桩", "侵略者", "柔伊", "reynolds", "我离", "搭建", "亚利桑那", "逞强", "评分", "warn", "拿开", "委婉", "courage", "夏普", "弓箭", "坟场", "silent", "情趣", "失职", "舌頭", "pam", "溜达", "affair", "人时", "巴哈马", "咬一口", "rebekah", "奇葩", "美容院", "韩语", "礼堂", "沙發", "能别", "科目", "成龙", "和蔼", "俄羅斯", "fu", "内原", "有完没完", "妮塔", "伊利诺伊州", "诱拐", "孤單", "慢性", "膀", "不休", "断线", "抓住机会", "闖", "对接", "trapped", "正视", "无神论者", "sacrifice", "油井", "blows", "吊起来", "先用", "吝啬", "倪", "平坦", "诗意", "洛林", "小标", "以北", "岌岌可危", "言归正传", "缘份", "逍", "这么着", "千块", "存货", "巴利", "过激", "切腹", "捧场", "senior", "安雅", "意志力", "找不出", "lucifer", "戈林", "families", "柴油", "微波", "ihn", "真不愧是", "自找麻烦", "披露", "蝗", "科尔曼", "没指望", "clever", "elijah", "库尔特", "回放", "把风", "disappear", "樂團", "赠送", "誓死", "backup", "呻吟声", "确诊", "谈心", "軍事", "一對", "膜", "一桌", "骨頭", "开去", "鸡腿", "合影", "云彩", "堂堂", "弗兰肯", "颁布", "人过", "ari", "丧礼", "券", "主体", "德秀", "手语", "预见到", "胸脯", "茶水", "便宜货", "一笔勾销", "exact", "夏恩", "改编自", "干部", "childs", "大发", "谷底", "评审", "袭击者", "迈尔", "静一静", "检查站", "枑", "咖哩", "lori", "吸取教训", "民调", "狄更斯", "directly", "劇本", "強壯", "军衔", "塞西尔", "不如说", "登月", "巴塞罗那", "札", "雷射", "轮班", "老旧", "宁", "体积", "是關", "转播", "anderson", "仨", "quoi", "三文鱼", "别干", "孤寂", "stevie", "特许", "会放", "每场", "公告牌", "广东话", "敢死队", "何用", "脆", "烧光", "夺", "disease", "jen", "浆果", "org", "国籍", "口罩", "似曾相识", "面团", "啪啪", "越南人", "灵敏", "bread", "次要", "护航", "功率", "knocked", "caused", "不值一提", "wing", "cure", "冲进来", "补贴", "sehr", "搞懂", "专访", "massive", "dc", "白勝祖", "克西", "罗森", "anti", "這把", "波洛", "多出", "march", "砞", "首发", "谁家", "试音", "山地", "benjamin", "用以", "止住", "告退", "入眠", "扣下", "单人", "干活儿", "柔弱", "凹", "單純", "精光", "爱卿", "找不着", "阿图罗", "結論", "热衷", "hunahpu", "功力", "捡起", "warum", "可恨", "夫君", "走远", "完全相同", "发笑", "六分钟", "按键", "金发女郎", "坚持到底", "少爺", "mirror", "电椅", "歌颂", "bhau", "冲进", "天蝎", "nous", "louise", "手链", "换言之", "斯坦顿", "十四岁", "断气", "心灵感应", "美咲", "怪癖", "大丈夫", "managed", "受洗", "敬仰", "环顾四周", "positive", "nba", "申诉", "刺耳", "保险丝", "houston", "里加", "一节", "傳奇", "军中", "瑪莎", "死罪", "但他却", "之爱", "颂歌", "工具箱", "医药费", "雨季", "公立学校", "末端", "巴雷特", "管管", "california", "走时", "地站", "双赢", "susie", "和睦", "飞过去", "生灵", "三十万", "狼狈", "縷", "若无其事", "萊", "同归于尽", "劳烦", "无理", "死翘翘", "夹子", "盖尤斯", "板子", "figgy", "家有", "神童", "鱼群", "不算数", "pot", "远征", "新一代", "解毒剂", "登記", "阻力", "不列颠", "票数", "舰艇", "神志不清", "贝克特", "活像", "天色", "考量", "failure", "面試", "灯笼", "窗边", "movement", "斯大林格勒", "邊", "卖家", "rosa", "人里", "科姆", "掌舵", "酒窖", "硬件", "翁", "播种", "真差", "十大", "alarm", "后辈", "凝视着", "踏实", "输血", "狂犬病", "发芽", "黑衣", "咱家", "看做", "橄榄油", "葛兰", "安插", "骨子里", "偶爾", "暗处", "弯刀", "卖光", "晶片", "拍手", "拿來", "重担", "蠻", "乡亲们", "toast", "小房间", "vehicle", "murders", "铁定", "讀過", "flower", "讲解", "转账", "这好", "七百", "paint", "越发", "那招", "汉考克", "闱", "性子", "别别", "正相反", "沿岸", "偷盗", "偏差", "茧", "google", "领空", "无计可施", "走神", "维德", "过手", "有別", "独身", "circle", "不曉得", "娜拉", "闭眼", "发情", "浓烟", "僵", "染成", "恶霸", "親手", "他进", "stock", "橱窗", "星城", "wasting", "真热", "總監", "除夕", "江南", "戏剧化", "古德曼", "所剩", "绯闻", "蜜", "不远处", "住户", "remains", "犯了罪", "淏", "城区", "衛星", "烧坏", "总的来说", "斜", "traffic", "莫西", "allison", "向西", "手气", "连任", "官兵", "侍从", "recall", "几种", "立体", "鲁比", "旺达", "深奥", "半田", "白马", "传染给", "臨時", "文凭", "电玩", "之火", "涂料", "这棵树", "黎", "燃燒", "有火", "头一回", "第四集", "小聪明", "意外事故", "菲利浦", "种族主义", "宽广", "广东", "傻小子", "瓷器", "dara", "隐形眼镜", "道场", "凄惨", "pierre", "复生", "机械师", "差点儿", "转制", "鲨", "听证", "文书工作", "basement", "組成", "坐视不管", "古斯塔", "pip", "package", "检讨", "enzo", "修道士", "响声", "false", "黑猫", "否認", "传遍", "財富", "意式", "谈好", "第一阶段", "高塔", "每到", "幾歲", "耐力", "怒气", "fixed", "食肉动物", "拉紧", "比奇", "牙齒", "达芬奇", "非洲人", "jam", "两遍", "邓恩", "全裸", "首映", "念完", "裝", "搁浅", "gar", "围观", "飛行", "巴罗", "隐喻", "堵墙", "crow", "滑行", "飯店", "一成不变", "解放组织", "地底下", "有意识", "苦艾", "字符", "劝告", "punch", "ivy", "果断", "诱导", "刹那", "比亚", "吸干", "燕子", "romantic", "患病", "征用", "海灘", "第二遍", "親人", "拓展", "来谈", "assistant", "宾果", "effect", "弥", "海砂", "潘多拉", "stairs", "bunny", "expensive", "一席之地", "布兰妮", "石碑", "豁出去", "宇宙飞船", "澤", "烤焦", "纳米", "牵引", "裤裆", "考古", "erica", "罗盘", "那大", "地笑", "減少", "请举手", "脫掉", "球衣", "大将军", "人际关系", "血糖", "準確", "expert", "闪人", "砸烂", "屄", "霍格", "斯坦福", "六百", "特勒", "美英", "實習", "贾森", "這筆", "希斯", "共处", "买菜", "长椅", "内务", "残障", "跌落", "休眠", "膏", "你动", "绿巨人", "无法无天", "抽象", "systems", "搏", "流利", "辭", "æ", "provide", "解冻", "之柩", "二千", "提了", "合情合理", "架上", "淝", "这下子", "岩城", "veronica", "更具", "load", "十分之一", "癢", "老婆婆", "接客", "ni", "tickets", "金英株", "痴狂", "精神分裂症", "coppelia", "切尔西", "獲", "證實", "屈服于", "机身", "joaquin", "一槍", "問他", "开场白", "閃", "alpha", "脸孔", "出游", "赫德", "室外", "拍过", "拉克斯", "审", "begins", "导航系统", "cheng", "尼姆", "组队", "迷宮", "麦克白", "靠岸", "特蕾西", "俗话说", "课题", "维克特", "該給", "敏", "侵害", "伽利略", "财", "熔化", "iike", "slave", "宜家", "jarod", "艾登", "开开心心", "海军上将", "体能", "展现出", "夜校", "大干一场", "布伦特", "每种", "荣幸之至", "三思", "平手", "brooklyn", "發瘋", "从军", "亚哥", "帆", "epstein", "真爽", "egg", "chocolate", "赛勒", "十五分", "solution", "引到", "菜刀", "輪到", "教我如何", "vic", "gretchen", "偏向", "自卑", "老爷子", "salt", "laws", "空荡荡", "啥子", "sentence", "光子", "风软", "皮尔", "可去", "两具", "深藏", "crystal", "几何", "mandarin", "伊斯特", "往西", "成败", "侵占", "獨美", "感染者", "棺木", "alfred", "那家店", "放出去", "两码事", "说明书", "闲话", "阿良", "嘘嘘", "ren", "先別", "六年级", "大吉", "contract", "marvin", "小葵", "转圈", "本月", "卸", "fait", "不诚实", "负荷", "三日", "出生地", "金妮", "東西給", "送礼物", "习惯于", "费力", "搞糊涂", "时机成熟", "希尔顿", "有座", "博学", "充分利用", "敲定", "挑个", "emotional", "exit", "swim", "我藏", "carefully", "dwayne", "全局", "放火烧", "不中用", "不可告人", "eagle", "盡管", "怨言", "逃学", "支烟", "transport", "signs", "心满意足", "划算", "marshal", "裂痕", "空房", "譜", "古人", "军事基地", "pen", "动态", "價格", "箱里", "人好", "夠", "圣女", "万福", "阿門", "嫖客", "請給", "小游戏", "正合我意", "弗拉基米尔", "合約", "脚底", "压扁", "明尼苏达", "拜訪", "当不了", "香皂", "saint", "奥蒂斯", "朗诵", "阿南", "谈点", "非常复杂", "护", "比我强", "古拿玛", "店子", "魔戒", "排挤", "结成", "reggie", "出外", "哪有什么", "權", "左手边", "尤利", "捉拿", "熄", "大好机会", "单枪匹马", "eleanor", "不像话", "隆隆", "这该", "下午茶", "莫拉", "cast", "主力", "洛塔", "多待", "這來", "沮喪", "留宿", "一个点", "拉尼", "两眼", "直通", "value", "寺院", "肺癌", "光束", "扳", "小叮当", "迟迟", "水位", "脱衣", "流量", "rio", "真惨", "engaged", "factory", "正统", "appointment", "你照", "盗版", "寶", "写歌", "门房", "布拉特", "gibt", "charges", "絏", "climb", "科罗拉多州", "法語", "郊游", "不能不要", "书记", "酝酿", "薄荷糖", "获准", "脱罪", "没杀", "新生儿", "妈会", "电工", "几颗", "過世", "参数", "死而复生", "最強", "sergei", "彼得斯", "得利", "第一道", "加注", "鏡子", "单调", "创世纪", "每一個", "横扫", "日光浴", "高利贷", "偷人", "connie", "這塊", "無能", "trusted", "艶", "陵墓", "音乐节", "卧房", "老不死", "打气", "恺撒", "预示", "升官", "喎", "内侧", "開除", "echo", "看球赛", "領先", "迁就", "明摆着", "pair", "永新", "塞住", "万幸", "艾哈迈德", "无边", "撮合", "山田", "首字母", "寄出去", "捕食者", "真实世界", "言论自由", "威爾", "別過", "坝", "fa", "营区", "干爹", "我命", "打糕", "深层", "昏睡", "針對", "天花", "callen", "kinds", "学着点", "青梅竹马", "直率", "货柜", "neighborhood", "野火", "要素", "脏东西", "二垒", "湖水", "法西斯主义", "挤奶", "woo", "資金", "遮掩", "猎鹰", "决意", "霸占", "高昂", "暗黑", "entirely", "克林", "肯塔基", "小城", "起先", "兜帽", "melissa", "嘻", "izzie", "动心", "披头士", "naomi", "駕駛", "聊聊吧", "驚人", "mood", "早先", "sookie", "怀有", "千美元", "刁", "四十八", "fellas", "回个", "转基因", "份儿", "ﾔ", "发条", "洛克菲勒", "夹住", "切片", "行贿", "便秘", "街边", "热水澡", "沿途", "静香", "喂饱", "種族", "talks", "槚", "格林威治", "詳細", "过热", "whitney", "惊异", "独木舟", "蠢貨", "夜莺", "腻", "拉肚子", "webber", "格格不入", "shelton", "其余部分", "驻军", "启航", "恩佐", "医疗保险", "耳熟", "反覆", "union", "第三世界", "happiness", "時會", "license", "油田", "海瑞", "通缉令", "权杖", "誇張", "童子", "见个面", "專心", "依法", "特赦", "stranger", "保命", "发挥作用", "太弱", "麦迪", "belt", "孩儿", "大作", "筆", "贊成", "eugene", "瑍", "繻", "弹夹", "私立学校", "恰巧", "十二宫", "nothin", "路面", "肚皮", "四面", "摸索", "热恋", "nichts", "滚远点", "长崎", "银币", "我渴", "percent", "日日夜夜", "奥尔森", "handsome", "peck", "过问", "车胎", "桑拿", "半英里", "堕入", "app", "赫斯", "炸成", "簎", "惠勒", "癸盾", "shock", "元老", "肞", "扫把", "发炎", "剛開始", "coach", "史嘉丽", "rolling", "逼供", "对称", "穿越时空", "颁奖", "尘世", "更正", "經典", "kgb", "刷卡", "spock", "naz", "挡不住", "抄袭", "靠得住", "艾菲", "肉汁", "真不少", "evan", "配置", "矛", "谁他妈", "十三岁", "野獸", "伞兵", "正前方", "租约", "列斯", "时说", "丶", "paulie", "摆设", "挺帅", "參觀", "线报", "teller", "拉登", "sec", "细致", "精力充沛", "电压", "調查局", "胎", "阿巴", "中队长", "滋生", "溫", "抽签", "杀伤性", "重来", "靠墙", "辞去", "而后", "利率", "利害", "歹势", "诺尔", "隼", "神社", "修理工", "切尔诺贝利", "资产阶级", "本是", "普拉格", "救世军", "饶命", "炽热", "触地", "我造", "aurora", "发生爆炸", "iris", "脑浆", "其一", "大肚子", "罗纳", "铸造", "迷迭香", "霍普金斯", "创造力", "干劲", "作文", "隨意", "冷死", "轉身", "漂亮女孩", "旁观者", "查阅", "钱伯斯", "时用", "來源", "下不为例", "glory", "入选", "阿姆", "长途电话", "划伤", "用点", "割下来", "大船", "ghosts", "啾", "莫斯", "陆续", "主使", "拉诺", "考拉", "特种", "下床", "卡莱尔", "嚴肅", "带去", "尔西", "連續", "兰格", "爆头", "令人惊叹", "璚", "原版", "贺卡", "о", "果真", "云端", "泰莎", "gabby", "jai", "狄龙", "不忍", "落山", "通话记录", "游轮", "缓和", "玛丽娅", "agatha", "低沉", "扯掉", "花上", "尔登", "弗朗西斯科", "懒鬼", "本店", "彎", "轻巧", "大鼻子", "有序", "collect", "belle", "花心", "没面子", "黑魔法", "相对论", "必不可少", "好汉", "头条新闻", "维姬", "太空梭", "chambers", "我實", "埃玛", "狂妄", "alec", "存心", "解说", "珋", "苏茜", "告示", "winner", "wins", "大吵", "拉上来", "幸免", "基利", "秘书长", "资本家", "doo", "接收器", "马路上", "单干", "裝備", "character", "intel", "cruel", "passing", "stewart", "译", "中指", "水箱", "北朝鲜", "起程", "打坏", "international", "很狡猾", "濕", "津", "赢定了", "马勒", "驻守", "托托", "乔恩", "大戰", "教义", "神气", "hart", "雪穗", "ruin", "有血", "作响", "多汁", "聚光灯", "选择权", "技工", "法斯", "佩戴", "一帆风顺", "梅毒", "借过", "供出", "血壓", "反抗军", "感同身受", "capital", "范妮", "我建議", "请示", "appears", "先看", "孤注一掷", "自作主张", "俯瞰", "firm", "襯衫", "多月", "过高", "今晨", "季第", "少不了", "结界", "漫画家", "复职", "假货", "塔格", "长满", "手槍", "搬出来", "气馁", "沙沙", "解码", "ﺡ", "龙头", "明珠", "化解", "夫婦", "madison", "抵", "设在", "洗过", "大哭", "得意忘形", "廚師", "為力", "希姆", "下体", "管不着", "往东", "优质", "过要", "带队", "还原", "preston", "烤面包", "节子", "ぼ", "驾驶室", "碎石", "unusual", "副队长", "年薪", "装束", "随身", "严寒", "勞動", "学士", "打消", "仇家", "prisoner", "谁知", "数以百万计", "emperor", "herr", "下决心", "tattoo", "平日", "筑巢", "grandpa", "复古", "撰写", "船票", "穴", "一顿饭", "没水", "authority", "没教", "徒手", "virginia", "这批", "開過", "几家", "嫁祸", "置之不理", "painting", "humans", "热辣", "嘉年华", "團", "需不需要", "水兵", "摆放", "地问", "cage", "度過", "刷子", "史丹", "保守派", "洗刷", "促销", "滋润", "幾句", "鳄", "janice", "犹他", "steel", "幼崽", "麦克利", "维恩", "控制器", "爆料", "苏姗", "晕船", "新面孔", "款项", "英格蘭", "生活费", "georgie", "再往", "antonio", "崽", "没人见", "大白鲨", "沃纳", "迭戈", "嚇壞", "sheila", "努", "免疫系统", "保护者", "磨难", "闯进去", "沉醉", "林赛", "乃是", "布宜诺斯艾利斯", "学历", "利乌斯", "healthy", "伍兹", "清算", "th", "小霞", "起个", "胡克", "预演", "schedule", "钱来", "五年级", "超模", "尾声", "院長", "安琪儿", "支架", "建起", "眼皮", "玙", "sin", "本色", "水獭", "朱古力", "斯内德", "远不止", "人工呼吸", "险恶", "热点", "以示", "第三方", "装成", "师弟", "此時", "缝纫", "堂弟", "饭馆", "這群", "升天", "年少", "connected", "別緊", "披薩", "generation", "租赁", "匈牙利人", "describe", "鹽", "贞德", "玩命", "领头", "eros", "ronnie", "这小", "所指", "本名", "艾弗森", "摔跤手", "撩", "送上门", "強尼", "sail", "买车", "全班", "dea", "不僅僅", "布里格斯", "船体", "干涸", "分崩离析", "朝圣", "learning", "打鼾", "威严", "拥护", "非裔", "friendly", "boyd", "自传", "chdbdbdb", "提个", "slept", "麥特", "汗毛", "放下去", "打进", "面板", "奶茶", "分店", "frost", "会花", "查莉", "娟", "拆弹", "废人", "jin", "沃利", "死路", "包皮", "這回", "抵達", "不生", "晃悠", "過夜", "kenneth", "父女", "好用", "预警", "大块", "小爱", "貝", "專輯", "诺丁汉", "这盘", "蠢到", "章节", "得克萨斯州", "装饰品", "发大财", "每张", "劳蕾尔", "真冷", "简洁", "浴场", "主题曲", "grade", "布里克", "附上", "肉酱", "老太", "好怪", "告终", "身孕", "数千年", "封鎖", "很胖", "戈培尔", "无望", "不动产", "烘焙", "戏服", "分別", "无误", "萨尔瓦多", "发表声明", "身家", "拿药", "殭", "劳累", "从今往后", "缴", "罷了", "pleased", "多达", "三声", "吞掉", "特警队", "乎", "首选", "勾起", "samuel", "寝室", "鸡翅", "施主", "睫", "deny", "下海", "疑神疑鬼", "荒岛", "o型", "脱裤子", "哭哭啼啼", "签收", "强生", "豐富", "拒捕", "帝國", "来龙去脉", "霍金", "三层", "募捐", "吉布斯", "优胜者", "rocky", "十号", "waited", "刀刃", "木村", "尼拉", "一派", "我想問", "爱尔兰共和军", "介", "厭倦", "娜塔", "沉下去", "手边", "监牢", "互不", "起重机", "排隊", "绑紧", "迷倒", "别别别", "基恩", "过冬", "这可真", "栽培", "最蠢", "拘禁", "四方", "libby", "乔伊斯", "枪决", "规章", "somethin", "肿胀", "开水", "直径", "半途而废", "寄钱", "場所", "迪特", "格列佛", "先行", "祍", "boyle", "bless", "夢想", "没少", "stanley", "然後把", "這跟", "knight", "紧身", "翻天", "披风", "海星", "默尔", "留意到", "valentine", "一大块", "不太像", "何去何从", "老远", "一用", "喷气", "沒錢", "计画", "瞏", "同住", "先找", "淋", "安布", "列兵", "负担得起", "从早到晚", "成绩单", "爆炸性", "盖斯", "帕罗", "开溜", "d版", "一条街", "加拉", "传道", "总决赛", "这花", "好痒", "发电厂", "不尽", "傻帽", "阿民", "疱疹", "民宅", "盆栽", "林子", "result", "兜圈子", "鲍鱼", "普鲁士", "枪炮", "连续剧", "有加", "勉強", "暴民", "血流成河", "朗读", "下定", "人大", "史无前例", "哪件", "一枝", "门路", "survived", "诺瓦克", "給你們", "光泽", "上风", "rivers", "重蹈覆辙", "幽会", "我想会", "想救", "坚不可摧", "亲自动手", "奸", "圣彼得堡", "极地", "葬禮", "警示", "jody", "鬥爭", "說來", "神聖", "书名", "利西", "婦女", "布恩", "调子", "迷途", "布拉德利", "successful", "software", "priest", "定金", "门边", "错话", "提利昂", "会开", "hacker", "taxi", "粗野", "演练", "還行", "隔间", "flies", "念念不忘", "臭鼬", "马屁精", "ginger", "我毁", "会活", "荣光", "披上", "出征", "小猴子", "louie", "军阀", "力度", "查尔斯顿", "你講", "wh", "下厨", "荒謬", "干细胞", "打响", "奉献给", "刑", "法宝", "麻子", "兰尼", "thursday", "粉笔", "刚过", "shirley", "別告訴", "奥林匹亚", "游戏吧", "雷霆", "尼夫", "六点钟", "新宿", "人见", "订婚戒指", "einfach", "巴特勒", "花言巧语", "休斯敦", "养家", "核子", "小鎮", "预防措施", "升降机", "投射", "本钱", "勃", "挤出", "加固", "陑", "approach", "相撞", "自来水", "坐轮椅", "蜜雪儿", "施行", "阿爾", "競選", "登基", "床位", "莱曼", "虧", "兵营", "核能", "巴哈", "知己", "脉", "refuse", "moments", "比方", "dirt", "醒悟", "转载", "了點", "各式各样", "task", "抗議", "大狗", "佳人", "演講", "从那之后", "格拉姆", "新兴", "粉身碎骨", "poppy", "兜里", "调料", "屹立", "金发碧眼", "客官", "好下场", "歌名", "伊格", "苦短", "useful", "第二步", "加深", "运来", "凱莉", "好难", "草帽", "谴", "皆大欢喜", "艾瑞瑞", "twenty", "翩", "久远", "小萌", "麻袋", "编个", "合不来", "灾难性", "褲", "赎", "两手", "一伙人", "起落架", "大半", "海洋生物", "sharon", "這是給", "波德", "options", "警報", "会替", "破绽", "据称", "太过火", "输送", "高举", "我長", "幹掉", "禮貌", "拉皮", "杰茜", "成品", "炒蛋", "发霉", "中途岛", "亲嘴", "争取时间", "大清早", "立場", "聯系", "障礙", "垂", "bj", "急躁", "获悉", "紊乱", "前一晚", "见证人", "六尺", "锤", "無情", "藏身处", "墨尔本", "就當", "聚焦", "插头", "厚颜无耻", "食物链", "傻傻的", "阿德里安", "四只", "釘", "描", "莱蒂", "limit", "腇", "苏菲亚", "天行者", "doyle", "工头", "古斯", "不會來", "不要命", "策", "dov", "矚", "开进", "大于", "湿地", "蟒蛇", "排球", "bingo", "家产", "很早以前", "遗孀", "一言", "转让", "不够格", "cock", "之美", "bow", "指甲油", "探险队", "人儿", "会成", "小贩", "補償", "盲点", "一大步", "骚", "罗宾森", "欣", "不进", "外快", "这条线", "小巴", "泰莉", "bears", "幫個", "一磅", "既有", "脱线", "empire", "车费", "化学反应", "克里斯多佛", "弗兰妮", "珊蒂", "屋外", "两间", "麦格", "席德", "具體", "免谈", "缄默", "亿美金", "凍", "开辟", "眠", "蚁", "巡官", "罗德尼", "寄信", "维尼", "微信", "禁", "ﺺ", "大祭司", "dating", "传教", "救生员", "arkady", "遏", "温顺", "自救", "编出来", "贪", "五百年", "萸", "梦露", "快回", "盟约", "clue", "见谅", "旺角", "暗物质", "列車", "浴袍", "丟", "編劇", "萨德", "死丫头", "淋湿", "战地", "选好", "創作", "沃特斯", "harriet", "麦金", "拱门", "你剛", "汹涌", "購物", "疯疯癫癫", "富贵", "錄音", "枯竭", "黄蜂", "儿戏", "狗仔队", "作法", "告別", "melinda", "索尼亚", "竭力", "四百万", "异样", "偵探", "希特", "soup", "乐意效劳", "戴利", "功", "补助", "心里有数", "秅", "jealous", "私下里", "飛行員", "nest", "新墨西哥", "粑", "假想", "唐突", "妨礙", "砏", "莫瑞", "游骑兵", "主场", "他常", "冰封", "没种", "species", "弹射", "毫不留情", "半决赛", "樱", "presents", "迫击炮", "煮熟", "扯蛋", "好快", "告訴過", "再开", "领班", "证言", "芳香", "塔楼", "二姐", "亮相", "近在咫尺", "常在", "他還", "硼", "wright", "lilith", "氏", "筹划", "丰收", "彻底改变", "开点", "终点站", "车位", "melmotte", "握紧", "时节", "犯有", "转入", "他伤", "密友", "非同寻常", "撲", "師傅", "万年前", "不屑", "出战", "岩浆", "满洲", "脱衣舞女", "那輛", "懶", "bury", "一堂", "剑术", "社保", "不送", "水泡", "布蘭登", "politics", "停靠", "不酷", "勺", "自卫队", "菜谱", "間諜", "沿海", "阿辉", "萨莉", "jarvis", "救生衣", "grandmother", "填饱", "screwed", "安拉", "喝汤", "zobelle", "前卫", "掸", "巴伦", "爷爷奶奶", "記下", "masters", "透视", "洗头", "长毛", "理奇", "飙车", "之苦", "院里", "敖", "sb", "海王星", "螳螂", "dump", "光光", "廢", "机房", "伯明翰", "醫學", "rico", "谁给我", "来历", "上垒", "哈德森", "屈膝", "筹到", "救出去", "转校", "н", "surrender", "林恩", "吳哈妮", "合拍", "考尔", "维琪", "math", "印度教", "礼品", "四射", "我講", "幾分鐘", "murderer", "隶属", "convinced", "营房", "民谣", "避孕", "暧昧", "油脂", "成婚", "哔声", "总指挥", "roaddog", "基思", "最受", "芙蓉", "眺望", "鼓舞人心", "齊", "排放", "柏拉图", "喧闹", "脹", "女装", "赢过", "竞标", "清醒过来", "弊", "检举", "史波克", "breaks", "大摇大摆", "供电", "孝顺", "持械", "昏暗", "男爵夫人", "为的是", "winning", "photos", "快餐店", "坚韧", "orange", "恐怖活动", "弄糟", "灭掉", "妳会", "離家", "小心谨慎", "面有", "乘着", "酒水", "selina", "纱布", "巡航", "那匹马", "索罗", "侯默", "pedro", "长高", "北欧", "风情", "桑德", "整间", "腐朽", "greater", "不由", "抢劫犯", "查证", "乌拉", "公眾", "拉菲", "驱散", "惨遭", "先上", "lu", "罗宾斯", "一堵", "抽身", "stays", "骑师", "尿液", "该轮", "陡峭", "笨笨", "毖", "安室", "体育课", "表演者", "我們還", "混合物", "棋盘", "拐角处", "库尔", "火箭筒", "root", "脊柱", "摔坏", "嬉戏", "borrow", "modern", "阿达", "音乐学院", "隅", "旨在", "心里话", "警铃", "terrorist", "同化", "睁眼", "顺手", "灼热", "年鉴", "德黑兰", "pill", "砌", "愛著", "jacket", "特雷西", "录下", "严谨", "倒杯", "嘉奖", "julien", "无踪", "不骗你", "天鹅绒", "轻浮", "慎", "suffering", "冷落", "敦", "休养", "沙加", "路線", "traitor", "露琪亚", "公之于众", "大法官", "颓废", "生菜", "改头换面", "午休", "西拉", "填好", "快上去", "示意", "碼頭", "上上下下", "沃尔玛", "无故", "大儿子", "肌", "喝些", "總覺", "麦道", "地皮", "加速器", "四十岁", "正值", "steady", "急救箱", "流浪狗", "十多年", "蔚委谓", "碰触", "明智之举", "锁定目标", "smoking", "内应", "第六集", "全开", "シ", "viktor", "多想", "精神状态", "殿", "废铁", "卷起", "將在", "林德曼", "看下", "过意不去", "她俩", "洗手不干", "领到", "七分钟", "butt", "出生入死", "应酬", "赫敏", "抓牢", "跆拳道", "肚子疼", "高盛", "父母亲", "痛不欲生", "青岛", "胜诉", "造假", "一劳永逸", "托尔斯泰", "救治", "手术刀", "軍人", "想著", "拉回来", "礶", "账目", "多有", "尖牙", "這一", "咒語", "綠", "曼宁", "三辆", "造出", "高堡", "再动", "印度洋", "黄石公园", "张扬", "佩内洛普", "大发雷霆", "蒙娜", "奎因", "吹喇叭", "交出去", "千载难逢", "这说", "羊羔", "废柴", "无法挽回", "上火", "圭", "开打", "玩法", "defend", "实实在在", "predators", "山中", "牌局", "shape", "大开眼界", "使用暴力", "烧成", "训练场", "返校", "喂狗", "伊琳", "致歉", "扭动", "loretta", "零用钱", "接送", "las", "戰", "克罗夫特", "根除", "gabe", "阿列克", "局部", "改不了", "全年", "恢复过来", "飞天", "低温", "尼罗河", "车内", "船坞", "卷毛", "布兰特", "這周", "表彰", "惨痛", "伸张正义", "cabin", "frz", "卡比尔", "未免太", "戴著", "吊销", "畑", "helps", "另类", "我錯", "整场", "人真", "跋涉", "mountains", "pity", "何苦", "瑞娜", "母体", "快撤", "水是", "后脑勺", "recent", "汤尼", "产量", "fort", "这么一来", "贾克", "年复一年", "撕破", "鱼肉", "leading", "麦凯", "荣", "本分", "转为", "名流", "树皮", "日程安排", "melody", "唾液", "virus", "西岸", "达姆", "信中", "充满希望", "金丝雀", "墊", "cloud", "体格", "科威特", "彻夜", "强国", "鴨", "咚咚", "spanish", "鲶鱼", "当班", "手机号", "哥儿们", "邻里", "要价", "率先", "午餐时间", "本州", "取而代之", "勇于", "别无他法", "道义", "孤岛", "志", "更棒", "客机", "资历", "苹果派", "受理", "仰慕者", "內褲", "花点", "传记", "死里逃生", "天生一对", "小维", "stands", "quality", "全押", "冬月", "上流", "改过", "振奋", "extremely", "invisible", "nasty", "丽西", "谈妥", "妾", "事实如此", "liebe", "异想天开", "争端", "来付", "艾利斯", "红发", "沟", "娄", "而行", "specific", "雷公", "有所作为", "生化武器", "疙瘩", "第二轮", "兰妮", "没人管", "palace", "好的开始", "circumstances", "鄉村", "spa", "趕上", "不称职", "產品", "マ", "abu", "獲勝", "杰拉尔", "哪一点", "margot", "玛格丽塔", "郁金香", "一时冲动", "得通", "少有", "盖上", "樸", "埃利", "沙利文", "索達", "estate", "不试", "拉西", "満", "輕易", "安全区", "效命", "素食者", "相機", "linc", "梦幻般", "梅朵", "臟", "剛", "唯独", "kills", "萨克拉门托", "氰化物", "宣傳", "都城", "经文", "joint", "急诊", "定时", "寇克", "阿力", "菈", "有生以来", "租车", "小倩", "水沟", "considered", "嘲讽", "受折磨", "皮疹", "见死不救", "碰碰运气", "泰坦尼克号", "姿勢", "污水", "钟表", "详尽", "哪種", "餐館", "劈开", "提過", "最要", "食人魔", "戮", "五百块", "克伦威尔", "呼吸器", "改建", "weller", "brendan", "议案", "安德鲁斯", "夺得", "france", "敲门声", "第二次世界大战", "欧拉", "欺凌", "jerk", "好惨", "差得远", "大西洋城", "随之而来", "三文治", "出嫁", "诸如", "面包屑", "基礎", "张牌", "铁道", "辛勤工作", "詩人", "怂恿", "联姻", "嚴格", "逆", "梳洗", "灵异", "啵", "剧中", "puts", "擒", "阿斯特", "免遭", "闇", "緣", "奇才", "german", "没付", "美梦成真", "咖啡机", "九点半", "下場", "大礼", "耐", "别死", "阿衡", "覂", "啰唆", "远距离", "投放", "艾力", "chip", "ill", "外行", "空旷", "福勒", "轮盘", "不容许", "里约热内卢", "健谈", "嗦", "fr", "境况", "玛莉亚", "一炮", "善后", "血偿", "翻新", "七千", "tied", "option", "身着", "多处", "任何事物", "小艇", "gear", "报废", "kent", "朦胧", "lass", "darby", "muhammad", "感觉不好", "恢复原状", "ber", "先驱", "左派", "夜视", "烤鸡", "住客", "凝聚", "蜚女", "sal", "感伤", "equipment", "乱伦", "舍尔", "monday", "西摩", "军事行动", "贞洁", "普林斯", "乙", "solis", "短短的", "无政府主义", "thou", "回头路", "大英帝国", "转而", "别光", "废料", "玻璃杯", "那门", "挺快", "這叫", "马夫", "缅怀", "被劫持", "眒", "圣诞夜", "户头", "还开", "喬丹", "追上去", "减慢", "想试", "不为", "从头再来", "避孕药", "触碰", "徹", "动弹", "直覺", "溝通", "我弹", "atm", "团圆", "rip", "开着车", "深表", "遮", "楚", "ﾎ", "飞向", "优惠券", "douglas", "找上门来", "老派", "钳", "quand", "叹", "nuclear", "closing", "挥之不去", "兰茨", "親密", "律政", "混得", "阿东", "standard", "紫外线", "酒窝", "冷笑", "嘴闭", "排查", "跳到", "我連", "sometime", "twitter", "毫無", "facility", "久仰", "不太对", "欢庆", "barlow", "mtv", "上位", "老巫婆", "螖", "紀錄", "没良心", "塞进去", "各人", "堪称", "男妓", "欢心", "娛樂", "毫发无损", "handed", "青椒", "suis", "善解人意", "无懈可击", "第一班", "同父异母", "烧酒", "divorce", "摄入", "行窃", "巡", "五金店", "马先生", "取得胜利", "deeks", "提尔", "琴科", "海邊", "玩伴", "您们", "那匹", "放上", "三星期", "五十块", "梦想家", "拉拉队", "草图", "度日", "小毛", "转个", "义工", "拷打", "荒原", "火烈鸟", "粘土", "稳定下来", "你件", "染色体", "古龙水", "出柜", "欢愉", "充裕", "迦勒", "受孕", "半小時", "两台", "我收", "动粗", "街舞", "质询", "atf", "出炉", "忘怀", "殿堂", "显灵", "百货", "飞跃", "衙门", "和保罗", "卖点", "卸货", "渡轮", "鹰眼", "救命恩人", "experiment", "华人", "份额", "小矮人", "賜", "友誼", "瓦西", "napster", "恋", "肥婆", "drag", "哈德逊", "owner", "而現", "缆绳", "韦瑟山", "中来", "神衣", "而出", "traditional", "印地安", "提摩西", "厄普", "利物浦", "抗衡", "练功", "认命", "教诲", "接電話", "夫子", "简陋", "科幻小说", "凌乱", "witnesses", "領袖", "賠", "一眨眼", "天文学", "两英里", "惨死", "staring", "平局", "德纳", "排行榜", "击出", "咕", "鸡奸", "這算", "卡帕", "edgar", "金屬", "如意", "新闻记者", "装弹", "祖國", "thy", "咒骂", "申报", "parking", "cece", "flesh", "leon", "存档", "神经兮兮", "马汀", "阿珍", "正为", "陈沸", "blown", "他娘", "切斷", "昆汀", "科斯塔", "这匹马", "力场", "办得", "出赛", "二年", "点整", "显微镜", "转变成", "現象", "张卡", "熬过去", "自古", "小角色", "吸毒者", "paula", "价码", "response", "探寻", "伙食", "相近", "胃里", "不如意", "克鲁斯", "noodles", "喧嚣", "洗发水", "君王", "沉沦", "肉丸", "烟味", "苦力", "廣播", "捂住", "素质", "地质", "蝦", "coyopa", "修养", "切磋", "坦然", "乔巴", "reports", "脚跟", "知足", "空难", "吃喝", "隐约", "感到恐惧", "挑战赛", "极乐", "脚尖", "草稿", "鸟嘴", "那伙", "腰部", "那枪", "上個", "脸书", "采摘", "弗格森", "吼叫", "同年", "风云", "dot", "merry", "疯话", "官邸", "艾滋", "藏起", "希腊语", "多姆", "賠償", "调职", "cherry", "spy", "再现", "左门", "两秒", "這將", "核桃", "佩特拉", "报销", "抽根烟", "时日", "手软", "掙扎", "福尔曼", "吉祥", "维达尔", "英格", "我個", "僅翻譯", "攝影機", "公用电话", "交集", "演变成", "凯奇", "过山车", "maid", "玩火", "賈", "pet", "汲取", "两腿", "盡頭", "部族", "复仇者", "焊接", "雷先生", "attempt", "成千", "拖下水", "发生变化", "马里兰州", "網站", "外甥女", "合作愉快", "本論壇", "罪证", "要犯", "甲烷", "嗡嗡声", "胶", "還用", "darren", "动动", "牢骚", "所学", "多虧", "住进", "所欲", "扣除", "照张", "回首", "sensitive", "有股", "好心人", "帕斯卡", "卡恩", "wire", "盖文", "clouds", "碇", "impressive", "宠", "渣滓", "音乐厅", "度假村", "青木", "纞", "瓦德", "lloyd", "臭丫头", "阳光明媚", "几名", "歪歪", "并肩", "字面", "乒乓球", "guessing", "core", "重新启动", "零花钱", "高等", "太胖", "婆", "读出来", "途徑", "循规蹈矩", "侦察机", "合金", "嘍", "雀斑", "天衣无缝", "兴建", "神奈", "背负着", "窍门", "運作", "无足轻重", "能成", "上阵", "理睬", "摩纳哥", "adult", "拼了命", "汪汪", "launch", "柱", "电影吧", "我身", "眼界", "з", "丽丝", "匡拒", "里卡多", "和平共处", "別去", "devin", "原有", "地域", "見識", "row", "旧情", "墙纸", "买件", "秋山", "威洛", "翔", "市内", "衵", "情谊", "精湛", "先杀", "半价", "brains", "第十二", "玛莉安", "冷清", "sucks", "score", "凌", "stacey", "chess", "一届", "烂货", "勛", "听听看", "沒關系", "用不上", "services", "懷", "关节炎", "要强", "乔治亚州", "露台", "狸猫", "视作", "誕生", "厚厚的", "亲口说", "倔", "勤劳", "當然會", "crossed", "有劳", "准将", "tj", "细腻", "紧跟", "一斤", "性别歧视", "配给", "坚实", "战况", "崔佛", "作个", "贫血", "唄", "whale", "巫女", "别针", "脄", "犁", "告一段落", "功效", "盗用", "更衣", "經是", "现成", "开通", "枪管", "screen", "趕到", "自動", "这具", "狡辩", "饮用", "紋", "curse", "支持率", "受尽", "精髓", "stomach", "面包师", "息", "爱荷华州", "当务之急", "紧绷", "这画", "左轮手枪", "這幫", "回應", "属性", "hop", "wolves", "猜疑", "放箭", "開什麼", "cabe", "blew", "俯卧撑", "不保", "不由自主", "boyka", "投注", "蒸气", "行礼", "坠", "何止", "七次", "身不由己", "josiah", "弗蘭克", "houses", "动手动脚", "新教徒", "府上", "treatment", "佣兵", "拜拉席", "辅佐", "想給", "探子", "路易斯安那", "重庆", "涙", "段子", "永濑", "我闻", "简妮", "机密文件", "莫琳", "大河", "旷野", "stealing", "吉娃娃", "中原", "啧", "别谈", "创造性", "一千个", "自打", "布纳特", "千万美元", "深吸", "局限", "bryan", "crixus", "ㄣ", "惨不忍睹", "親吻", "開放", "上場", "泼妇", "谦逊", "棚子", "二代", "celia", "一切办法", "浸泡", "細胞", "診斷", "treated", "风车", "瓦格纳", "标示", "大呼小叫", "毙命", "终老", "越多越好", "海带", "grateful", "自如", "不得好死", "衰弱", "二者", "硕士", "雷克", "火势", "散会", "该国", "pre", "魏伪", "拉瓦", "守门员", "不败", "先发制人", "松子", "几十万", "优异", "拳赛", "紧要", "version", "会选", "documents", "羊水", "号召", "劳动力", "欣喜", "兩名", "现时", "收敛", "炉", "先來", "更少", "爆炸物", "伊特", "来烦", "德比", "进取", "坎特", "甲子", "独子", "砲", "端庄", "现行", "ssen", "arnold", "沒去", "背叛者", "oswald", "作祟", "死伤", "auntie", "monsters", "水坑", "motion", "我己", "违约", "闸门", "淤青", "毒打", "灿", "摇头丸", "永世", "掴", "arizona", "背对着", "龙崎", "一查", "三分之二", "矿场", "device", "bret", "人间蒸发", "车灯", "很受", "conference", "尖端", "渥", "ch", "unfortunately", "李小姐", "想带", "听命", "掩藏", "oz", "lucia", "声波", "著火", "coke", "gore", "琛", "不解", "路易莎", "三流", "mister", "drake", "蓝恩", "拉走", "禱告", "ﻹ", "雙眼", "小美人", "delicious", "萍", "那批", "丁哥", "真系", "摇头", "数个", "正合适", "una", "可谓", "六人", "利索", "格特", "后遗症", "名副其实", "或暗", "草泥马", "全死", "違反", "化合物", "數學", "整死", "小径", "庸俗", "遇", "不胜", "危在旦夕", "灭火器", "闲事", "kev", "渴死", "发明家", "奥康纳", "离世", "划掉", "古罗马", "八天", "奥吉", "格调", "阿罗", "自以", "扪心自问", "没看", "化作", "hal", "洞房", "ro", "debt", "顯得", "克罗斯", "洋", "停工", "迪尔", "难耐", "减缓", "淌", "橡木", "欠债", "满载", "干洗店", "消退", "刚出生", "預感", "圣约翰", "百分之十", "每一秒", "红十字会", "公会", "凸轮", "深厚", "狠心", "承载", "蠢才", "见习", "tail", "ذ", "保持平衡", "总体", "执行命令", "小海", "duck", "笑死人", "邱", "美化", "四面八方", "空壳", "赢钱", "theo", "特遣队", "內疚", "昵", "法律顾问", "企業", "图拉", "teri", "特伦斯", "吃藥", "估价", "panic", "dollar", "果园", "僵局", "爆發", "弥漫", "婚姻生活", "voices", "deck", "ihnen", "欧娜", "偷溜", "提高警惕", "逗你玩", "棒球队", "我为", "没落", "八百万", "世纪末", "bike", "唯一一", "歐", "迈向", "hodge", "东山再起", "早到", "班纳", "那具", "況", "织", "悄悄话", "惩戒", "保守党", "那狗", "一并", "先上去", "会害", "惊叹", "爬升", "一男一女", "臭男人", "阿黛尔", "用语", "ronaldo", "底朝天", "hans", "分隔", "记事", "单亲", "geh", "andrea", "调出", "伦巴", "洛佩兹", "萦绕", "活死人", "干系", "搞坏", "绝食", "拚", "落叶", "威尼", "碼", "剧作家", "傳說", "双峰", "撇开", "卜", "aii", "麻疹", "violent", "米卡", "luca", "別吵", "卖身", "百度", "真是假", "脱颖而出", "jacky", "赢回", "国歌", "缠绕", "spoken", "拉丁美洲", "养家糊口", "库特", "回路", "必定会", "臸", "史酷比", "情结", "萨莎", "历险", "杂物", "开诚布公", "撒野", "榨干", "粒", "gehen", "脊髓", "車禍", "幽闭", "玩球", "巨人队", "四十五", "zimuzu", "影业", "valuable", "mccoy", "取个", "线人", "肯斯", "火气", "痛哭", "多来", "winston", "偶遇", "odds", "rocket", "枯", "新月", "踢踏舞", "不利于", "落脚", "太惨", "custody", "問你", "徙", "ň", "總算", "混入", "hunters", "sidney", "何況", "画展", "武裝", "麦芽", "重病", "顺带", "农田", "發表", "鸳鸯", "控制台", "訪問", "音色", "烦心事", "得当", "主動", "砍头", "黏在", "愈发", "山雀", "落花流水", "深處", "溫度", "鸡汤", "蔣", "尽职", "捕鲸", "捶", "公敌", "没死", "souls", "自由主义", "胡搞", "商船", "狱友", "麻省理工", "奉命行事", "绝种", "普拉提", "说不上来", "聿", "欲火焚身", "一摸", "大牌", "录像机", "這一個", "污渍", "老挝", "莎朗", "逞", "黄鼠狼", "yup", "兰伯特", "两条腿", "蔷薇", "推掉", "洸", "念念", "逐漸", "撤消", "浴盆", "多过", "hammer", "闪光灯", "奇蒂", "我開", "交談", "阿勇", "仇敌", "陷于", "无偿", "欣喜若狂", "浮游生物", "共产党员", "海平面", "拍照片", "我同", "adventure", "大廳", "本职工作", "einer", "壮丽", "有情", "職員", "怎讲", "压倒性", "叫法", "优越", "洗脸", "評價", "夜夜", "乔登", "癖好", "bloom", "撤掉", "杂货", "這了", "青铜", "可真有", "不写", "那话儿", "磨损", "醇", "主治", "卡萨布兰卡", "整形", "漠不关心", "桥牌", "时时刻刻", "frame", "茬", "未免", "紋身", "重播", "动画片", "友人", "最让人", "丞相", "不照", "绝世", "brooke", "bhoothnath", "堆积", "二重", "主权", "奥尼尔", "显示器", "全境", "应征", "毫升", "侧翼", "弱點", "阿纳", "维塔", "bags", "垄断", "就职", "杰瑞米", "误以为", "廢物", "你定", "这就是说", "严格来说", "二等", "乡村音乐", "daphne", "毛线", "宗旨", "ga", "bd", "饶舌", "旧事", "大姑娘", "扶持", "奥利维", "共同体", "横行", "要冲", "印第安纳", "属下", "出航", "坏女孩", "加纳", "收拾残局", "玛格达", "倒影", "我頭", "板块", "五位", "憨", "追问", "pops", "罗德里格", "葫芦", "孟加拉", "thin", "阻塞", "大点声", "请容", "半步", "匪", "solar", "要员", "萍琪", "露西亚", "喃喃", "上会", "脑门", "严重性", "自願", "考克", "骨气", "朵花", "丑事", "跑得快", "搬运工", "红线", "俄國人", "来求", "古巴人", "loyal", "profile", "抗抑郁", "粿", "這時候", "屡", "展览会", "就是指", "ability", "越野车", "嘀咕", "scientist", "緊緊", "别喊", "incident", "整日", "ㄑ", "大富翁", "上过", "断言", "契机", "別看", "蒂托", "丟人", "patients", "离合器", "灵长类", "tracking", "shopping", "鱼饵", "打捞", "六百万", "运往", "多活", "这令", "头像", "征兵", "升到", "法雷尔", "恰", "馅", "寶貝兒", "禁欲", "时侯", "遗传基因", "别接", "牺牲者", "赴约", "坑里", "奸细", "scream", "洗牌", "样式", "簙", "第五集", "第十一", "厮守", "holden", "aa", "反攻", "寓所", "拍张", "找钱", "啧啧", "wer", "留到", "米尔顿", "吶", "术士", "sagen", "用不著", "觅", "tessa", "加载", "寡人", "花栗鼠", "肥沃", "mix", "赛克斯", "普斯", "ending", "皮草", "出远门", "健在", "effort", "沒得", "一元", "hug", "奇遇", "寇森", "踌", "砯", "八分", "angle", "饭后", "bates", "大个儿", "通风口", "恩情", "nat", "ew", "ttg", "雷管", "division", "逃之夭夭", "metal", "宾夕法尼亚", "困擾", "negative", "好书", "跛脚", "miguel", "暴", "chef", "九龙", "反思", "爱斯基摩", "十秒钟", "吉妮", "誓约", "开演", "那就算了", "聲明", "仔细检查", "局長", "盗", "本场", "安家", "ike", "经济学家", "布雷斯", "wipe", "辦到", "托付", "家畜", "手心", "收音", "发出声音", "fed", "链条", "shoulder", "spending", "奸诈", "unbelievable", "卡马", "外国佬", "老歌", "桃乐丝", "慈善家", "演播室", "铃兰", "有神", "九千", "麦基", "销售员", "之时", "手来", "猜谜", "全力支持", "hk", "靓女", "不假", "達成", "斯特恩", "偷运", "劳森", "這什麼", "正像", "没话", "布兰德", "大案", "卖得", "人敢", "大包", "快拉", "容量", "monroe", "牙签", "天一亮", "雨天", "某样", "心上", "嗚", "写书", "侍女", "garbage", "布莱特", "這行", "停車場", "冰水", "auto", "相逢", "猶豫", "netflix", "修整", "一員", "companies", "邦奇", "霸道", "召见", "哞", "王先生", "接种", "阿豪", "考克斯", "象牙", "暗指", "上苍", "不可开交", "mass", "橡", "donnie", "不敢肯定", "忍忍", "sides", "抵消", "酮", "蜡笔", "科莫", "巡游", "如常", "连在一起", "垀", "木棍", "bug", "听不进去", "别当", "yyets", "相好", "乘车", "监", "暴力行为", "惋惜", "再查", "吞没", "看住", "史帝", "赛马场", "becoming", "拆穿", "以求", "判官", "托利", "雅利安", "炮手", "bride", "拾", "保尔", "马场", "警备", "乃至", "小羊", "生态系统", "creatures", "阿尔巴尼亚", "strangers", "佐佐木", "friendship", "wrap", "创办", "慢吞吞", "无辜者", "文盲", "hanna", "白菜", "清净", "支笔", "暴力犯罪", "久违", "蜘蛛网", "爱丽斯", "kissed", "利兰", "海因里希", "高呼", "小雨", "道光", "remembered", "學院", "小乔", "po", "前列腺", "守護", "hire", "老得", "沉着", "退款", "understanding", "空隙", "這個給", "洁净", "银器", "再三", "演过", "不向", "想活", "哭喊", "契斯", "雷纳", "断层", "出生证明", "作怪", "化妆舞会", "蠢人", "搜过", "melanie", "东海", "fans", "推行", "餐车", "同台", "谢丽尔", "帮你忙", "找上门", "doll", "夏绿蒂", "fowler", "称得上", "节哀", "顧問", "汉姆", "好使", "伴着", "團體", "組合", "degrees", "捣毁", "反应炉", "希腊神话", "断头台", "减去", "回乡", "有性", "获得者", "突如其来", "另有其", "随处可见", "發覺", "私刑", "昨天下午", "蒙住", "斐济", "动乱", "改改", "跛", "发动战争", "過度", "片中", "軗", "替人", "太阳神", "女星", "极光", "拉住", "攀爬", "带动", "主耶稣", "树根", "晒黑", "吠", "jumbo", "马达加斯加", "理他", "earned", "ð", "遗址", "教唆", "连长", "老规矩", "abe", "顧客", "unique", "恶鬼", "站不起来", "kathy", "痛扁", "阿莉", "衍生", "找人来", "roberts", "大石头", "意料之外", "恐怖电影", "掰掰", "尔塔", "向南", "逝者", "出勤", "摩天大楼", "chin", "電", "柯尔特", "湖畔", "robot", "历桑", "农场主", "协议书", "我忍", "奇诺", "线上", "出格", "印第安纳州", "affairs", "阿桑奇", "温特", "死囚", "不胜感激", "network", "legend", "平地", "围攻", "赤手空拳", "月台", "采矿", "显", "新意", "深表遗憾", "上点", "佛州", "马尔", "三道", "点钱", "霍斯", "祸害", "我爱上", "daily", "话剧", "ye", "拉过来", "发信号", "算个", "bombs", "名额", "四分五裂", "诗句", "撤離", "岩", "贵国", "巴瑞", "吃力", "牧羊犬", "穴居人", "節奏", "hated", "裸女", "劇院", "协作", "霍恩", "pee", "译制", "有错", "神来", "人質", "才智", "太君", "偷笑", "天翻地覆", "珍视", "pitch", "大名鼎鼎", "连衣裙", "队列", "性变态", "猥琐", "apocalypse", "犯罪集团", "短发", "复出", "泰拉", "之源", "background", "高墙", "数周", "孤", "绊脚石", "情欲", "冷藏", "messages", "世界级", "殘酷", "挖个", "扇子", "scientists", "卡米", "几份", "這項", "佛像", "問候", "solo", "fusco", "犯罪分子", "rogers", "马修斯", "桥下", "雪儿", "拉图", "睪", "上班族", "档次", "订好", "笼", "多萝西", "vacation", "小蝶", "鬼龍院", "托普", "几十个", "毒虫", "遇刺", "广播公司", "赶尽杀绝", "可大", "macht", "gil", "阻断", "穷光蛋", "fletcher", "调来", "不灵", "回味", "楞", "沒別", "李小龙", "直截了当", "鲱鱼", "treasure", "修饰", "蔓", "audience", "终究会", "花花", "为国", "游戲", "生性", "样貌", "尽责", "相助", "猜错", "全权", "矫正", "先付", "卫生棉", "不平", "专程", "呼吸困难", "豆瓣", "聯合", "少佐", "真烦", "jules", "liberty", "变性", "大屏幕", "莫娜", "噪声", "特使", "醉汉", "得太多", "八万", "亲眼见到", "不分", "鳕鱼", "会爱上", "对质", "考驗", "sonia", "judgment", "不对头", "样样", "束縛", "越野", "每家", "費用", "利文", "马虎", "波本", "根基", "搜查证", "fallen", "兆", "复发", "前所未见", "划过", "體內", "jazz", "定时炸弹", "圣歌", "她給", "丟掉", "作秀", "杰罗姆", "一坨", "概括", "冷得", "泥泞", "身份证明", "蒋先生", "海地", "下马", "頭兒", "执意", "真烂", "此时此地", "几点钟", "莫德", "西裝", "太空站", "除名", "gosh", "少于", "糟糕透顶", "微微", "戒律", "莫林", "打盹", "达夫", "霸", "生產", "八分钟", "damit", "脱鞋", "沙利", "金正日", "农作物", "嚴", "海员", "不堪一击", "japan", "rainbow", "岭", "胖虎", "offering", "寒舍", "交税", "沙袋", "格拉夫", "恍惚", "浴池", "notes", "hayes", "同音", "没对", "回忆录", "曼德拉", "关禁闭", "自始至终", "人道", "唧唧", "存者", "王國", "蠱惑", "闪过", "霍特", "歇会儿", "團結", "younger", "免提", "帕梅拉", "別怕", "计划书", "换回", "shell", "伊格纳", "三岛", "旁人", "很甜", "失态", "甩开", "優勢", "侄儿", "荒诞", "蒜", "踏板", "拐弯抹角", "甶", "查尔", "老巢", "kein", "來來", "珊莎", "帕特里", "充", "礩", "漂移", "斗牛", "喝得", "freaking", "阿提", "爱咪", "皮博迪", "danke", "新浪", "卷宗", "mach", "销魂", "派人来", "警务", "alert", "神智不清", "会伤", "russo", "防弹背心", "声望", "毀了", "过桥", "錄像", "唐顿", "偏执狂", "不得而知", "默多克", "两块钱", "防身", "里士满", "黑马", "张贴", "tait", "擎天柱", "幕府", "介于", "警戒线", "receive", "业界", "挺大", "先洗", "喜劇", "板凳", "identify", "松动", "哀求", "エ", "热度", "confidence", "看得懂", "六十年代", "强迫症", "孤兒", "divine", "lang", "气管", "真該", "abandoned", "touching", "談判", "csi", "汇聚", "蹿", "手術室", "暫停", "警督", "进退两难", "白鲸", "血色", "过滤器", "乐曲", "sh", "证人席", "屋主", "尾部", "叮叮", "忠贞", "痛不痛", "柘植", "吃不消", "巨乳", "转折", "移居", "很強", "拜见", "何时何地", "诺瓦", "ca", "伊达", "trash", "当值", "有生", "九百", "想先", "美国大使馆", "摊牌", "企圖", "榮耀", "受难", "indian", "同班", "凝结", "經", "薯薯", "文雅", "休学", "威威", "狗窝", "樂趣", "迫", "fourth", "隊員", "證件", "会查", "婚后", "出兵", "两点钟", "病死", "大通", "搞个", "陷落", "渗入", "不觉", "負責人", "喷嚏", "刺眼", "cow", "怕怕", "否則後果", "一家之主", "遣返", "阿荣", "干坏事", "善心", "之作", "怀亚特", "断绝关系", "波妞", "璝", "双性恋", "能令", "logan", "ad", "maura", "扯下来", "巷", "着实", "個性", "赌马", "balance", "书中", "核查", "冰棒", "试卷", "销声匿迹", "家用", "市集", "odin", "發財", "大門", "dolores", "訂", "亚历山德拉", "从何说起", "不需", "防盗", "借給", "elevator", "障碍物", "花边", "辛巴", "九点钟", "杜恩", "侍应", "影印", "希姆莱", "耳闻", "怎敢", "过点", "我装", "栖息", "家长会", "西野", "集团军", "李维", "trail", "卡普", "谈及", "赶得上", "羞", "中餐", "合法化", "听信", "负起", "農民", "靈感", "不详", "双唇", "大件", "撒勒人", "领会", "猴哥", "呆瓜", "获益", "蜂巢", "逐一", "安吉尔", "口琴", "小梅", "炒饭", "葡萄牙语", "大忙人", "插图", "ㄉ", "祝好", "特罗", "翻脸", "裁", "圭多", "跟上来", "东哥", "陈词滥调", "預約", "大陸", "sykes", "破坏性", "索要", "唱的歌", "chang", "米高梅", "趴下来", "shiny", "婴儿车", "胺", "下垂", "厂里", "痕", "澈", "审判长", "雅格", "要教", "推下去", "送点", "数码", "臉色", "看呐", "加尔", "剧集", "合群", "人带", "得力", "逃狱", "插播", "征召", "小贝", "耳目", "加尔各答", "小迈", "昏迷不醒", "突击队员", "妈来", "湖面", "隙", "财前", "ethel", "不菲", "准尉", "庙里", "一走", "密苏里州", "結合", "黄片", "dah", "这层", "更重", "罗娜", "舞台剧", "奴", "西奥多", "動物園", "肥仔", "新鞋", "识相", "悠久", "探索者", "迪亚", "蠟燭", "identity", "疾控中心", "全看", "地为", "出处", "抽血", "有色人种", "晋", "幻灯片", "悼词", "金盆洗手", "緄", "多明", "香奈儿", "误差", "面墙", "ㄟ", "名模", "傳聞", "重置", "踩油门", "姜汁", "類", "擅闯", "条命", "弄混", "劫走", "职业道德", "电话公司", "小牛肉", "那當然", "雷耶斯", "辛苦工作", "衰落", "老去", "homicide", "密尔顿", "goal", "lui", "测", "采取措施", "加水", "养成", "香格里拉", "小饭", "卿", "或常", "可口可乐", "geoffrey", "手推车", "丹尼尔斯", "烟头", "总数", "松本", "号称", "温奇", "自拍", "赚取", "很熟", "八点钟", "老化", "opposite", "救生", "喙", "carver", "惨败", "七分", "小绿", "癌细胞", "milo", "捕杀", "抢钱", "一吨", "情报人员", "阿秋", "好乖", "宝贝儿子", "高考", "自力更生", "威斯康辛", "不哭", "百叶窗", "上百", "一厢情愿", "赔偿金", "小杯", "黑山", "convince", "乱叫", "yay", "butters", "幼鸟", "最后通牒", "确切的说", "女妖", "wishes", "艾丽卡", "confirm", "辦事", "波及", "skills", "弹孔", "上放", "简而言之", "半月", "特别之处", "肚脐", "带人", "俄克拉荷马", "奥特", "阿成", "押金", "伸向", "亲生父母", "成见", "长命百岁", "早死", "三十分", "破门", "pussy", "schmidt", "email", "皱", "总长", "sag", "发亮", "皮肉", "韦尔", "禁不住", "爱得", "吔", "落伍", "手雷", "乐手", "impressed", "值勤", "去处", "二十世纪", "红旗", "土司", "电灯", "费雪", "不离", "榴弹", "展品", "潜质", "说话算话", "張開", "皮箱", "陪葬", "感觉良好", "爱迪生", "纯种", "潛艇", "波斯尼亚", "狱长", "希达", "知会", "签过", "附属", "减压", "船舶", "工作量", "家过夜", "城中", "代言", "基辅", "家去", "国际象棋", "韦斯利", "克莱夫", "protected", "jt", "透纳", "赏脸", "饭团", "有违", "周旋", "溪", "枪子", "平壤", "許能", "大神", "小時候", "马琳", "飞蛾", "块头", "每句话", "拉斯基", "cab", "墙角", "自立", "芳", "查个", "高卢人", "五元", "plain", "学分", "太不像话", "胡言", "獠牙", "完美无缺", "希亚", "地基", "做爱时", "壓", "一二三四", "接任", "卢斯", "總得", "领结", "狾", "坐上", "thee", "begging", "摄氏度", "拐走", "zwei", "少管", "sehen", "伪谓", "重新做人", "造物", "不堪设想", "诺顿", "庆贺", "冥界", "密斯", "特大", "渡过难关", "附件", "惦记着", "哎呀呀", "衣架", "简易", "塔基", "文艺复兴", "老话", "contest", "浪人", "下半场", "慰问", "阵容", "淫秽", "内存", "幼稚园", "疯癫", "howie", "一动不动", "々", "扫描仪", "喺", "戒毒所", "客户端", "起不来", "停泊", "疣", "大奖赛", "更要", "核弹头", "卫星电话", "reid", "baxter", "好评", "东岸", "达到高潮", "痛打", "拉扯", "成瘾", "户", "滑头", "下坡", "迟疑", "自杀式", "旺盛", "酒味", "超好", "高分", "浴衣", "里基", "靠边站", "volker", "换下", "卑躬屈膝", "第一组", "小龙", "一职", "登顶", "甜甜的", "spider", "跳跳", "情报部门", "南方人", "倒好", "班克", "作假", "countries", "求援", "八小时", "敬请", "某地", "高楼", "believes", "眃", "應得", "富饶", "滑落", "百分之五", "票子", "sudden", "人会来", "橘色", "情报机构", "胚胎", "betrayed", "勒姆", "bis", "良多", "清风", "砋", "两辆车", "行在", "奥立佛", "继", "extraordinary", "真品", "和弦", "小帅哥", "检察厅", "stake", "那場", "輕輕", "親自", "原野", "加代", "辽阔", "收银员", "落幕", "布里斯", "竹", "獻", "pike", "里程碑", "分出", "網路", "终点线", "只靠", "猎户座", "蛙", "毀掉", "弗朗茨", "吵得", "events", "漫畫", "表兄弟", "聊天室", "smells", "直白", "投进", "加一点", "坎坷", "gr", "凱特", "迄今", "高下", "蜈蚣", "女人味", "marilyn", "漢堡", "eaten", "多话", "stress", "小民", "cathy", "education", "前路", "枉", "我的頭", "弹得", "湊", "我承認", "桔子", "條子", "要往", "莽撞", "邁克爾", "waters", "拉莫", "尼西", "大庭广众", "扒手", "defence", "往北", "温彻斯特", "沉到", "博览会", "响尾蛇", "鉗", "数额", "爛", "陈词", "檯", "咽喉", "elder", "他会用", "這幾天", "田纳西州", "寒冬", "迪米特里", "公约", "joking", "鲜艳", "協會", "struggle", "睫毛", "新潮", "流言蜚语", "脑细胞", "痔疮", "同龄", "pushed", "世家", "口子", "像头", "小包", "vera", "speaks", "咏春", "风力", "天窗", "居所", "观望", "萌芽", "散发出", "初学者", "阐述", "mc", "以後再", "痛得", "女士优先", "nypd", "sweeney", "hassan", "磁力", "浴巾", "捷克斯洛伐克", "刺绣", "二十多年", "这棵", "kati", "joined", "木已成舟", "cotton", "小胖", "车身", "提神", "complex", "界山", "比试", "series", "吃得下", "兵役", "布洛迪", "担", "最想", "全盘", "魔方", "极少", "撑不下去", "啜泣", "使用者", "君特", "麦克阿瑟", "两座", "卡特里娜", "俘获", "counting", "次长", "甊", "加拉帕戈斯", "干净利落", "中计", "我見過", "evelyn", "叫安", "皮诺", "红色警报", "自知", "停歇", "讶异", "angie", "urgent", "州警", "carmen", "十元", "終結", "追缉", "小可", "静静的", "前來", "办点", "鹈鹕", "交道", "切记", "右派", "合力", "旧约", "迪米", "艾维", "真挚", "奔走", "躯壳", "crush", "莲恩", "hon", "果仁", "大嘴", "diese", "收紧", "光阴", "大喜", "abigail", "机组", "共產黨", "洗净", "覚", "要出", "六点半", "手风琴", "打麻将", "佐罗", "无暇", "鲁宾", "正巧", "坐立不安", "石川", "而亡", "先后", "借着", "入门", "礁石", "丛林中", "vargas", "倔强", "交租", "三口", "麦吉尔", "纽卡斯尔", "襪子", "推移", "金泳三", "潜望镜", "那处", "可汗", "回城", "利萨", "ヒ", "摄政", "挺直", "憋死", "无价之宝", "一成", "短裙", "一來", "古板", "清爽", "死板", "麻醉药", "帥哥", "沒變", "permanent", "董", "没伤", "军校", "皈依", "哈尼", "那多", "饿肚子", "頻道", "防弹", "百分之一", "騷擾", "捐助", "待定", "赤身裸体", "原处", "万次", "看人", "斯圖", "小红", "沒事兒", "摆出", "商会", "conrad", "胡迪尼", "店面", "能过", "公文", "明说", "异教", "交错", "车尾", "讲师", "验血", "参与者", "天道", "咱得", "希伯来语", "手机信号", "警钟", "democracy", "每分", "現在還", "无端", "菲菲", "新民党", "三长两短", "漸漸", "mayans", "羽", "秘书处", "烹调", "therapy", "你贏", "易怒", "限于", "之争", "拾起", "标", "细倩", "最偉大", "啡", "營", "布谷", "誘惑", "decent", "仙崎", "先问", "麦洛", "戈德", "quarter", "dragon", "租出去", "漏油", "advance", "读心术", "趣味", "份文件", "棕", "开明", "ach", "不善", "布鲁特", "fruit", "说笑话", "张唱片", "大娘", "可信度", "蛀虫", "八点半", "内会", "落空", "小鬼头", "紧跟着", "洛蒂", "始終", "歪曲", "请留下", "linus", "当好", "漂漂亮亮", "讲理", "默里", "青山", "剪短", "租房", "上爬", "食物中毒", "举着", "安放", "咬断", "令人激动", "缺氧", "wasted", "第二件", "阳痿", "torture", "一朵花", "phoenix", "那篇", "奇观", "冷冰冰", "亲情", "四分之三", "第二场", "那杯", "alors", "爱德华兹", "飞出去", "cuts", "广袤", "记仇", "衹", "私处", "威猛", "侚", "童", "铺子", "邮报", "霍利", "难懂", "cutting", "cleared", "健", "毛钱", "顶点", "波斯语", "精巧", "傾向", "hip", "蝴蝶结", "刺猬", "费恩", "羞恥", "畒", "皮囊", "阿乔", "十个月", "大将", "语法", "天津", "味觉", "一律", "成形", "萎缩", "手绢", "回歸", "康德", "厮杀", "该名", "麦凯恩", "威望", "两处", "levels", "藩", "ts", "收藏品", "羭", "听人", "可贵", "静脉注射", "旅行车", "蕃茄", "設定", "狗熊", "鼓动", "置身于", "狭隘", "克莉斯", "冲浪板", "基石", "related", "刷新", "巡回演出", "塵", "帖", "眭", "荷恩", "监狱长", "defeat", "总归", "潜", "可会", "乱子", "avancez", "内衣裤", "熙", "麦可", "迪娜", "衰仔", "underneath", "xander", "warrior", "刚开", "采取任何", "病史", "sage", "苺", "辣酱", "太空舱", "loser", "整顿", "拉什", "阿胜", "疹子", "中国政府", "压低", "自生自灭", "拉上去", "干扰器", "海中", "美圆", "先進", "渡船", "脚趾头", "二流", "shen", "咄咄逼人", "菜菜", "不折不扣", "呼声", "青草", "活路", "艾瑪", "evie", "党卫队", "抹黑", "点来", "善罢甘休", "黑烟", "dreaming", "管理者", "blast", "ty", "涵盖", "种田", "rooms", "setting", "狂躁", "黑鹰", "bastards", "更多人", "翻倍", "出彩", "执导", "久仰大名", "洗脱", "彆", "木瓜", "走后", "碎尸万段", "撑得住", "亞歷", "中说", "阵", "试炼", "伏特", "稼", "阴沉", "器具", "庆", "魅影", "他剛", "尼尔斯", "老骨头", "河床", "kayla", "去路", "地要", "開工", "变量", "獗", "艾丽斯", "城裡", "香槟酒", "出新", "哈蒙", "同学会", "来来去去", "不知羞耻", "缺德", "pan", "生日蛋糕", "人肉", "cave", "死寂", "四五", "圣经上", "变数", "幸运地", "这顿", "善恶", "官網", "我敬", "露茜", "搞糟", "连连", "市镇", "回车", "投身", "脈", "决断", "抓错", "謎", "梨子", "裂", "前会", "红包", "波星", "sansa", "邦迪", "失去知觉", "没个", "再敢", "无理取闹", "副驾驶", "纳维尔", "转交", "卡米尔", "創傷", "斤", "政府部门", "序列号", "少管所", "這能", "初始", "太狠", "瞎了眼", "景点", "所有者", "碧翠丝", "安蒂", "大得多", "垃圾车", "ロ", "活要", "蒂森", "募款", "里夫", "米妮", "日式", "太阳镜", "并不一定", "guarantee", "转发", "无路可走", "表态", "沃什", "踢开", "不開", "緑", "先人", "同心协力", "域", "出入口", "保单", "拍得", "阿格", "长到", "爱美", "内出血", "谈些", "雄心", "得克萨斯", "加盟", "阿森", "妒嫉", "薪酬", "獅子", "卡洛安", "将士", "书架", "ヾ", "至爱", "近在眼前", "茴香", "发车", "岔子", "运算", "坎吉", "无事", "fucker", "全责", "狄米", "瘪三", "车行", "美国陆军", "家庭教师", "发表意见", "菲茨杰拉德", "金条", "心眼", "失意", "尹開花", "culture", "前刚", "giles", "欠揍", "棕榈树", "沒給", "丫頭", "西蒙娜", "手电", "流着", "咔肉", "希尔德", "负伤", "利器", "弗瑞", "康纳利", "掂", "金钟", "機關", "祥和", "伯尔尼", "皮皮", "阙", "装潢", "含糊", "每當", "第一排", "timbira", "矮小", "老鬼", "罗莉", "過要", "電車", "接力", "土包子", "难处", "史黛西", "decisions", "散散心", "五百元", "电影节", "追求者", "帮点", "莱莉", "调换", "克瑞斯", "长江", "曲折", "慢点儿", "三餐", "混战", "unlike", "深刻印象", "飞虎队", "behavior", "資訊", "泛滥", "felicity", "好客", "一笑", "basic", "rape", "楼房", "survival", "不教", "落魄", "第八集", "谷川", "有机体", "足跡", "禥", "一百次", "天启", "波诺", "炸薯条", "查過", "泊车", "border", "掠食", "伟同", "来复枪", "林德奎", "安金", "原地待命", "存有", "小白鼠", "無人", "一动", "這該", "放好", "约克郡", "麦克唐纳", "可疑人物", "另一方", "揪出来", "小霸王", "加剧", "搔", "帆布", "全場", "酒都", "trish", "上西天", "掏空", "沒空", "东印度", "nsa", "恶习", "子嗣", "木柴", "贾斯丁", "parties", "指責", "老头儿", "電池", "nolan", "眼珠子", "徵", "告状", "质子", "饮品", "独来独往", "绿卡", "暴力事件", "儒里", "人杀", "巾帼", "催促", "鲍尔斯", "格言", "容不下", "裸奔", "睡著", "knee", "yard", "瓦尔基", "街頭", "考核", "真切", "投出", "新闻报道", "公羊", "神秘感", "崔允", "古典音乐", "dee", "欲火", "þ", "適", "小明", "很會", "轻盈", "本田", "nail", "heute", "笛", "坐呀", "团员", "香煙", "楠", "蛋包饭", "水温", "降臨", "弯道", "关卡", "冬青", "lack", "surgery", "打杂", "我办", "没车", "badly", "gino", "追溯", "colors", "粗略", "euch", "raus", "kommt", "没事干", "maureen", "简化", "dominic", "断腿", "来劲", "爱丁堡", "婷", "nerve", "altman", "喝下", "伸过来", "爆胎", "嗷嗷", "麦克法", "破损", "窃窃私语", "这大", "维茨", "sack", "南加州", "戈多", "阿凡", "gamma", "入口处", "变冷", "kings", "面目全非", "第七集", "伤痕累累", "奎", "鲜明", "贏", "放哨", "图尔", "三點", "看紧", "特丽丝", "ivan", "方丈", "始祖", "随手", "激进分子", "真枪", "辰", "运动衫", "赢球", "應過", "克雷休", "肥皂剧", "美达", "烦扰", "三代", "wanting", "耿耿于怀", "老编", "之命", "运输机", "小妖", "过目", "很帥", "向外", "羙", "晴", "瞭", "艾莉莎", "瓦里", "邻近", "时而", "迪马", "全体人员", "瑞瑞", "晓", "partners", "doris", "singh", "受益人", "散弹枪", "稳固", "瞄准镜", "costs", "口腔", "伪证", "iphone", "钻戒", "拼凑", "兜售", "烟消云散", "新药", "嫖", "maddox", "检查员", "kali", "观众席", "胡同", "會兒", "干枯", "三千万", "付现金", "拖出来", "艺承", "磨磨蹭蹭", "涼", "脑瘤", "相思", "操舵", "一惊", "talkin", "装填", "阿帕奇", "我小時候", "端的", "穿行", "吃奶", "秘書", "比奥", "夏美", "干擾", "訂婚", "赏识", "跡", "也门", "话虽如此", "songs", "塞纳河", "信差", "第一课", "桶子", "占便宜", "停机", "hollywood", "火山口", "哨子", "均匀", "韦伯斯特", "这番话", "一个多月", "女尸", "流过", "三更半夜", "nazir", "慌乱", "刮掉", "博德", "杨小姐", "赶回去", "包给", "一词", "jaimee", "二十三", "bradley", "tax", "磷", "developed", "定性", "开心果", "圣谕", "larger", "燈光", "蛋卷", "恶性", "迪克森", "为伍", "懒虫", "新婚之夜", "畫家", "degree", "苏鲁", "忠心耿耿", "子爵", "并发症", "高度机密", "落网", "美国空军", "礼拜堂", "尼采", "klar", "丽夏", "翻开", "五万块", "玉玺", "哈佛大学", "有戏", "志志雄", "百子", "盚", "美杜莎", "全毁", "情侶", "工艺", "三藩市", "susanna", "女校", "降温", "形影不离", "北极光", "洗澡水", "沽", "班德", "先不说", "竟会", "珊迪", "致富", "模樣", "提心吊胆", "败坏", "主控", "不是太好", "糯米", "匈奴", "相册", "麻利", "竖琴", "warden", "涌出", "狭小", "能飞", "你些", "辱骂", "关键人物", "玛歌", "weg", "vicki", "应为", "依舊", "滑动", "起效", "所想", "小虫", "受困", "高涨", "带球", "还长", "暑期", "逃不过", "烂泥", "说成", "阿尔卑斯山", "颜面", "死守", "无法形容", "攀升", "loan", "埃塞俄比亚", "邻居家", "没为", "monsieur", "奥斯曼", "叠", "蜂窝", "思想家", "制片厂", "碾碎", "清酒", "事实真相", "小于", "要进", "ぬ", "ㄩ", "安珀", "婬", "terrance", "排練", "欠缺", "缘", "异国", "问些", "兩小時", "刀剑", "独唱", "kristen", "骇人", "阉割", "没法子", "拿著", "床头", "competition", "弹珠", "伊德", "家宝", "君士坦丁堡", "夜幕降临", "settled", "separate", "并不多", "弗洛拉", "瑟曦", "性趣", "太像", "流行音乐", "homer", "franco", "随机应变", "一言不发", "多样性", "尔多", "伴唱", "篈", "港湾", "声张", "事務", "个面", "咕哝", "冻住", "許有", "之久", "透過", "結構", "承擔", "何时能", "炮塔", "布鲁姆", "出價", "粇", "必杀", "anger", "獾", "泰晤士河", "動機", "走不开", "交替", "一萬", "deine", "幸灾乐祸", "獨特", "箇", "找過", "絚", "暖化", "溜进去", "小野", "孙悟空", "哪行", "禍", "祈福", "kol", "固体", "快起", "鉤", "斯莱特", "人类学", "魯迪", "奥莉", "citizens", "冰凉", "轉", "切下来", "心地善良", "克里姆林宫", "學到", "参见", "埃斯科", "艾什", "coincidence", "克勒", "零点", "吃顿", "瑞贝卡", "中共", "蓬蓬裙", "拖欠", "三星", "两大", "pauline", "warned", "關起", "被选为", "打掉", "大姨妈", "germany", "chick", "请帖", "三四", "意向", "先救", "德伦", "很着急", "鬼火", "fashion", "properly", "蒙娜丽莎", "stops", "被忽视", "耕", "斬", "之花", "hills", "walks", "来换", "發作", "总让", "joyce", "洋鬼子", "艳舞", "裡有", "捐赠者", "鯊魚", "地壳", "原点", "ebay", "磨练", "設法", "trent", "补习班", "dallas", "threatened", "飞回来", "stopping", "来场", "纳黛特", "受過", "高年级", "兩周", "有能", "杀生", "酿酒", "踩死", "高尔", "北方佬", "魔头", "colt", "半裸", "喜酒", "標記", "旁观", "jeez", "组成部分", "手柄", "东正教", "期待已久", "僅此", "population", "sprint", "milton", "杀出", "斯嘉丽", "阿傑", "叨叨", "脱臼", "ronald", "热潮", "矮人", "facing", "巴伐利亚", "信号弹", "姑且", "runway", "天敌", "麦卡锡", "讣告", "七十年代", "克劳福德", "苏拉", "凶鬼", "肠胃", "村夫", "bold", "臥底", "盘算", "母猪", "节车厢", "宇迦", "远行", "缩减", "亚拉", "凱文", "酶", "起头", "下腰", "束", "甦", "所犯", "难事", "甘道夫", "薰衣草", "悲慘", "數量", "绝好", "曲解", "要不了", "四倍", "贵客", "圖書館", "脚踏", "逃开", "gina", "搗", "怕黑", "追悼会", "简介", "冲击波", "暗地里", "奥布莱恩", "弗洛伦斯", "调和", "苍天", "雪佛兰", "睁大眼睛", "第一晚", "睡房", "擦亮", "外國", "黑水", "carried", "水泵", "性幻想", "識", "后排", "俄军", "胡安娜", "存入", "可说是", "网路上", "老实人", "鞋底", "变质", "唬人", "杀敌", "做买卖", "哈波", "物业", "这单", "光鲜", "菲舍尔", "紧握", "爱管闲事", "三百年", "食肉", "儲備", "所述", "那扇", "盹", "着眼", "浪花", "气候变化", "沿路", "blah", "教员", "prisoners", "仔细观察", "接班人", "passengers", "在後面", "四叔", "植", "大浪", "周游世界", "年纪轻轻", "这多", "全宇宙", "纪子", "竞价", "tyrion", "店裡", "租来", "百个", "日照", "俄勒冈", "diamonds", "安乐死", "调查结果", "玩具店", "srt", "走后门", "乌托邦", "disgusting", "后盾", "琐碎", "貓", "通风报信", "伦斯", "证券交易", "thunder", "嘎吱", "奇缘", "马奇", "roberto", "机组人员", "明儿", "beast", "塞到", "万个", "碍手碍脚", "两票", "由衷", "会住", "相依为命", "蒙大拿", "alexa", "玛雅人", "katrina", "州立大学", "安非他命", "见了面", "广播电台", "带鱼", "打岔", "烤炉", "梦乡", "夺回来", "sounded", "能以", "大汗", "打屁股", "simone", "招致", "average", "懷念", "浓密", "自闭症", "出場", "bible", "觊觎", "想害", "鮑勃", "我亲", "狠毒", "快进", "革命者", "三哥", "起疑", "波尔多", "家長", "洛伦", "全国性", "绿茶", "九成", "完美无瑕", "遇过", "卡佳", "放掉", "dl", "莫兰", "拍攝", "控制塔", "爆炸事件", "britney", "球体", "confirmed", "用法", "mustn", "上要", "nightmare", "崇敬", "黑莓", "一堂课", "delivered", "猛击", "vs", "bars", "纔", "请愿", "par", "抠", "koothrappali", "神不知鬼不觉", "太乱", "掠夺者", "挺胸", "别老是", "吠陀", "我切", "警监", "袭警", "增多", "阿尼", "男伴", "速人", "congress", "engage", "往北走", "清点", "运输船", "度过难关", "借款", "驾驶执照", "不全", "闖進", "党内", "胃伪", "松散", "三振出局", "干出", "星环", "cheryl", "指针", "陶瓷", "受精", "盖儿", "筹集", "hugo", "及格", "motel", "灰飞烟灭", "动弹不得", "长笛", "下凡", "皮尔森", "股权", "chamuel", "精良", "训导主任", "自爆", "再問", "公开赛", "射入", "畫畫", "单方面", "一点钟", "impact", "伊利诺斯州", "我想通", "显摆", "script", "哈蒂", "擦拭", "成效", "融资", "毕夏普", "咳咳", "有要", "凌驾于", "沙漏", "动不动", "纐", "leaders", "乔许", "mask", "本城", "五十个", "土狼", "气派", "購買", "因斯", "阿俊", "钮扣", "三笠", "panda", "这货", "独奏", "血汗", "lion", "剧毒", "谋害", "channel", "帕萨迪纳", "德林", "詹宁斯", "随即", "閃電", "伤兵", "課程", "急促", "兹曼", "cleo", "相等", "车坏", "neville", "煲", "回荡", "inch", "低能儿", "尋常", "列宁格勒", "野鸡", "老朽", "不讲理", "芦笋", "蓖", "修订", "何妨", "mental", "隐匿", "兩條", "scale", "南德", "茂盛", "有船", "嘴硬", "审议", "筍", "豹子", "绰绰有余", "刚巧", "摄氏", "这女", "无人知晓", "要来点", "平奇", "失足", "铁郎", "累人", "阿伯特", "维摩", "取乐", "说白了", "岗", "鬼屋", "有块", "通情达理", "亚特兰蒂斯", "娇小", "钟楼", "還沒到", "说客", "沿著", "组件", "霍伊特", "兜兜", "无论谁", "逃过一劫", "没叫", "wil", "无休止", "配上", "reasonable", "赤色", "查特", "杰特", "schultz", "抜", "所剩无几", "怕不怕", "曾几何时", "呇", "检察院", "橄榄球队", "美日", "左腿", "留话", "倒像", "嗳", "丁字裤", "船身", "奥斯特", "發燒", "木頭", "角逐", "strategy", "餐巾纸", "改行", "说正经", "重整", "ringing", "monk", "大革命", "掠过", "武林", "狄加", "彼拉多", "获释", "次序", "喜事", "vedo", "boo", "大少爷", "按铃", "历程", "超前", "雷声", "足球场", "enjoying", "一比", "清教徒", "德語", "戛纳", "致使", "希臘", "乌利", "凄凉", "侯赛因", "离岸", "进化论", "健康状况", "挥动", "關在", "巴菲", "那一", "反派", "甜饼", "精选", "孟", "幾周", "环绕着", "design", "地下水", "书信", "hugh", "我取", "季節", "每一寸", "服过", "治不好", "tammy", "酒里", "blowing", "temperature", "往昔", "扩音器", "深山", "pathetic", "赞助人", "乐章", "挖洞", "裸照", "別墅", "吸吮", "德伯格", "salvatore", "木兰", "拨款", "卡勒", "桑切斯", "限定", "ham", "閒事", "盯梢", "米哈伊尔", "凯瑟", "奢侈品", "迎娶", "工作狂", "贾马尔", "我觉", "眼见", "參賽", "我话", "綴", "诺里斯", "进不来", "茶杯", "在校", "禁闭室", "说大话", "寒酸", "屈斯", "不乐意", "贝露", "有史", "劳力士", "热得", "克林特", "聊一聊", "窗前", "伴侶", "囚室", "無線", "建个", "往下走", "酒醉", "champagne", "佐久", "掌柜的", "妻女", "messed", "炙热", "过家家", "明治", "七弟", "翹", "mayor", "戴高乐", "種子", "军火商", "troops", "字迹", "fda", "盖世", "投影", "horn", "矿物", "活塞", "phones", "高加索", "蓝宝石", "viel", "正试", "最会", "担惊受怕", "艾波", "當個", "双子座", "你念", "aidan", "资质", "观音", "签到", "老一套", "社会学", "interrupt", "两层", "瓷砖", "中學", "厨神", "史蒂文森", "通电", "劳斯莱斯", "赢取", "巨浪", "點子", "执法人员", "花子", "蕊", "这封", "我醉", "纳入", "巖", "機密", "索马里", "纽带", "嫔", "瓦利", "hates", "慣", "咋啦", "超重", "安眠", "players", "梯", "我喜", "一搏", "吉尔达", "普通话", "心房", "从头到脚", "刑法", "hitting", "laughter", "新陈代谢", "伟业", "灯关", "孤僻", "原始人", "啦啦队长", "非常容易", "食指", "斗牛士", "当家的", "ﻆ", "氣候", "会得", "千克", "league", "largest", "punk", "台下", "本垒打", "灵气", "施暴", "ﾕ", "听天由命", "瓮", "截至", "美式足球", "肝炎", "三家", "鉴别", "或盾", "溃", "tricks", "美兰", "打结", "女歌手", "空想", "趕來", "凯瑞", "random", "繼承", "别带", "處境", "莱昂纳多", "没点", "埃拉", "韋德", "fetch", "极有", "里长", "活干", "斗牛犬", "唵", "sp", "油水", "腹泻", "超酷", "性情", "pero", "垚", "西方人", "prom", "推崇", "溶化", "真诚地", "useless", "投保", "私通", "请安", "失掉", "翻到", "马里斯", "白旗", "第一手", "演化", "grass", "噜", "頭部", "相似之处", "妇产科", "填字游戏", "pearl", "邊境", "人寿保险", "劳作", "賈克", "romeo", "库伯", "找茬", "护盾", "ィ", "智", "nan", "偏头痛", "阿泰", "hodor", "领子", "dit", "残害", "眩晕", "突围", "link", "留出", "自命不凡", "五英里", "热气", "practically", "館長", "一环", "吊灯", "张曼玉", "吕西安", "你死我活", "极高", "为首", "哪见", "终日", "过得去", "disaster", "kiddo", "格鲁", "帮下", "革新", "hudson", "安東尼", "打起", "那卷", "海胆", "办公楼", "富士", "那般", "母乳", "加到", "于事无补", "两项", "einem", "這類", "没那回事", "别放", "杜格尔", "艾倫", "semak", "三爷", "遇袭", "时装秀", "布莱", "桌布", "查爾斯", "换尿布", "许许多多", "学好", "skies", "這本書", "太急", "莲", "兄弟俩", "免不了", "爱滋", "礼拜一", "叹为观止", "愛你們", "predator", "施加压力", "我娘", "準時", "waves", "嗣", "维耶", "歌聲", "言听计从", "来取", "我們將", "supply", "加布里", "去去就来", "非暴力", "helicopter", "那間", "悔改", "灾祸", "乌干达", "润", "遮蔽", "一辉", "猫猫", "christy", "热浪", "別跑", "工业化", "伊索", "航天", "不戴", "没接", "好累", "美嘉", "鲁斯", "神谕", "pretending", "傑森", "譟", "乔伊丝", "仙人", "有见", "太爱", "義的", "检", "妖魔", "主页", "残余", "特别节目", "正当防卫", "草丛", "bitches", "shelter", "基顿", "应聘", "拍些", "会下", "聖經", "逃课", "千叶", "唾弃", "文献", "它关", "慧嫄", "艺名", "染色", "記著", "纳税", "卡玛", "偷窥狂", "mae", "多花", "字体", "蛾", "回家路上", "封存", "螺栓", "继承权", "squad", "最贵", "严", "并不认为", "別來", "色雷斯", "匯報", "截", "纳塔莉", "是麼", "左右手", "搅乱", "运货", "五点钟", "威尔克斯", "動力", "塞尔维亚", "ø", "播音员", "逐个", "送礼", "徐龙学", "平方", "静音", "escaped", "贝恩", "chen", "無處", "酩酊大醉", "谐音", "绝技", "抽取", "事已至此", "人妖", "两百块", "发售", "极小", "高血压", "疟疾", "upper", "炖肉", "血跡", "cells", "坢", "高爾夫", "竞争力", "撑过去", "hoped", "kissing", "六名", "谈不上", "大二", "很渴", "starving", "struck", "奥古斯", "葵", "捆起来", "传染性", "挥棒", "无所不在", "阿雄", "会信", "考得", "情色", "大廈", "舟", "琦", "几遍", "開發", "薛普", "过失杀人", "高低", "松弛", "顺利进行", "超载", "我代", "拉撒", "采石场", "订金", "显露", "两者之间", "毫無疑問", "中暑", "三大", "ihre", "阵型", "瘀", "抢匪", "摒弃", "棚", "特伦", "等同于", "冬日", "小河", "待會兒", "归档", "墨西哥城", "锡拉", "jumped", "碱", "卖弄", "救兵", "开房", "貝貝", "猎捕", "邮政", "产权", "sins", "遙遠", "近亲", "childhood", "掳走", "敲敲", "少數", "公安局", "刻苦", "国语", "possibility", "拉戈", "坦普尔", "星人", "baker", "冰雹", "羬", "达令", "發火", "一大跳", "hawk", "词儿", "烘烤", "天明", "島", "杂音", "旦", "预支", "ps", "畅销书", "六合彩", "kimmy", "收队", "象征性", "公义", "阴间", "就座", "威德", "快成", "赢回来", "gasps", "浩劫", "瓢虫", "死亡率", "路子", "孙子兵法", "镰刀", "大步", "逃脫", "有望", "墩", "有型", "璽", "烫伤", "混帳", "问问看", "ａ", "落单", "名贵", "酒楼", "无期徒刑", "能见", "willst", "麾下", "rajesh", "维奥拉", "省事", "effects", "表述", "快完了", "從此", "scotty", "β", "五五分", "跳进去", "灰暗", "医好", "俞", "扫除", "haley", "拳脚", "停滞", "铃响", "耶酥", "alvarez", "巴厘岛", "强哥", "飞奔", "忙不过来", "永无止境", "玩去", "technically", "pushing", "有話", "不服气", "smaller", "拉扎", "道士", "默默地", "无垢", "someplace", "預測", "出賣", "省点", "javier", "查封", "巴鲁", "人帮", "清凉", "品格", "愚笨", "痛痛", "boots", "守衛", "滾蛋", "模子", "奶粉", "normally", "ぷ", "清洁剂", "安分", "坦纳", "魂魄", "日前", "碧丝朵", "碎裂", "全州", "badge", "刺中", "接口", "战斗力", "油腻", "布萊克", "纵使", "模具", "坦帕", "cheung", "摩萨德", "飞扬", "估算", "石墙", "盤", "湖中", "嘎嘎", "沐", "胡椒粉", "罗琳", "拖进", "动过", "瑪利亞", "我租", "纸袋", "assault", "北斗", "这么些", "fishing", "原罪", "再次出现", "脫下", "shirts", "到過", "奥马哈", "汤玛士", "体形", "温哥华", "碾", "麒麟", "凤梨", "blocks", "蒙斯", "一陣", "时时", "三千块", "普雷斯顿", "误入歧途", "牙科", "三步", "远东", "代理商", "回绝", "汉纳", "提倡", "cmct", "顺子", "掖", "舒坦", "大友", "ﺽ", "文哥", "多用", "放电", "西莉亚", "兩點", "守法", "disappointed", "履", "偏好", "老巴", "摺", "甜點", "连锁店", "为食", "应用程序", "年初", "無視", "稍早", "达阵", "铁人", "缠绵", "助教", "熬过来", "麻将", "揪出", "坚哥", "廷", "虎妞", "花纹", "電視台", "追回", "硫酸", "良机", "遠遠", "意面", "小玉", "解救出来", "多名", "引擎盖", "两条路", "hack", "玩物", "新德里", "全球性", "神职人员", "秦", "装死", "利落", "悄无声息", "提诺", "ambassador", "低谷", "懒散", "假释官", "嘴上", "assure", "下会", "全杀", "坐上去", "護照", "前期", "項", "暍", "隔音", "餐点", "jalapao", "洗碗机", "至尊", "哈迪", "送个", "jewish", "不请", "得付", "昆西", "失调", "热气球", "托拉", "闲人", "fran", "恐嚇", "袜队", "considering", "少來", "webb", "负债", "战警", "模板", "失誤", "吃苦", "lange", "多到", "套子", "butter", "球进", "剑法", "两包", "以备", "noble", "长门", "有损", "全家福", "诈", "警界", "五千元", "悄悄的", "暗语", "显赫", "bolt", "小隊", "露脸", "拒绝接受", "战犯", "涨潮", "图腾", "致辞", "美子", "鳄梨", "分区", "从容", "unser", "难以启齿", "孤立无援", "布萊恩", "environment", "运动会", "拜占庭", "三成", "nc", "宪兵队", "digging", "jb", "好多钱", "兩分鐘", "真甜", "白手起家", "摩卡", "cleaned", "畐", "色魔", "钢丝", "寫作", "自发", "闸", "北极星", "分神", "进洞", "aid", "歌谣", "席琳", "加尔文", "亢奋", "窝囊", "算术", "將成", "李维斯", "别家", "勤快", "阿加", "drawing", "違法", "榎", "方针", "就学", "被窝", "尼古丁", "升温", "梵", "敲門", "raven", "器械", "进餐", "历险记", "遵", "玻璃窗", "毫发", "真慢", "警卫室", "哭闹", "亚军", "sink", "珠穆朗玛峰", "胭脂", "自残", "过早", "小丹", "行刺", "观", "爪牙", "絃", "weaver", "rb", "demand", "无路可逃", "睡過", "當做", "圣玛丽", "wong", "雙", "把持", "原件", "里程", "骑警", "這要", "棚屋", "没脑子", "绞尽脑汁", "阿飘", "uniform", "扶起来", "倒掉", "沙包", "歌德", "阿尔文", "reported", "窜", "自讨苦吃", "爱玛", "听候", "畅通", "cleaning", "faced", "瘦小", "惊魂", "医护", "压着", "操作系统", "欧盟", "高出", "alexandra", "乍", "太想", "鼓声", "肩负", "马来", "胸怀", "carlo", "爬树", "抓稳", "怪客", "滞留", "anytime", "头子", "就任", "rani", "改用", "节制", "自寻死路", "angeles", "scar", "champion", "太難", "审计", "沟里", "cassandra", "前先", "利维坦", "confess", "driscoll", "comin", "杵", "科普", "心电图", "笼罩着", "弗农", "一听", "打法", "安达", "fever", "古柯", "brien", "keinen", "皂", "二十五年", "引见", "爆炸声", "路易士", "原意", "日蚀", "宣泄", "撑过", "编排", "表象", "号令", "有活", "karina", "phillips", "三十五", "花环", "elvis", "恐怖行动", "八年级", "deeper", "足球赛", "麗", "这烂", "废品", "租用", "卫士", "卡布奇诺", "不足为奇", "掌门", "礼拜五", "深邃", "罗兰德", "战绩", "两回事", "姿", "弥漫着", "烂醉如泥", "惠特曼", "雷区", "挪到", "作废", "伏下", "sweets", "恁", "风浪", "瞎搞", "剑士", "atmosphere", "肬", "鎖定", "负鼠", "漂白", "容光焕发", "甘蓝", "diana", "elias", "野花", "泻药", "monique", "饮用水", "混旦", "我行我素", "斯蒂", "嘴脸", "任凭", "reward", "整队", "古柏", "偏袒", "锯子", "皮卡", "suits", "gorgeous", "强烈建议", "居家", "penis", "土生土长", "罩杯", "静默", "之血", "维度", "连载", "半边", "batman", "风波", "爭論", "唤", "underwear", "毒手", "closet", "引述", "菲儿", "婴儿床", "媒介", "紧要关头", "籠子", "亲生女儿", "ee", "上頭", "號房", "母马", "摆盘", "明確", "評委", "马科", "走漏", "自此", "choices", "pit", "香津美", "赞颂", "请愿书", "无政府", "路斯", "福布斯", "调酒", "漫長", "五六", "普西", "驱除", "查不出", "垮掉", "體育", "槍手", "七万", "蜘蛛人", "欧比", "佩珀", "依偎", "亲身经历", "艦隊", "chan", "共谋", "欧蕊", "hers", "俯视", "臭臭", "盛行", "wars", "requires", "二郎", "注销", "既定", "吞食", "十全十美", "夜行", "无法自拔", "时代广场", "憋不住", "苏格拉底", "photograph", "哪一年", "晃来晃去", "沉寂", "我脑", "franny", "我交", "毒物", "打转", "阿育", "迷了路", "underground", "commit", "洋基队", "登陸", "雪白", "全村", "引荐", "四起", "異常", "杆子", "要养", "ordinary", "摇滚音乐", "塔里", "绘图", "长处", "热死", "不选", "电磁脉冲", "行当", "早日康复", "我飞", "严苛", "专制", "三合会", "eigentlich", "无穷的", "努力学习", "大堡礁", "之城", "過你", "老死", "芭比娃娃", "背诵", "肺结核", "往里面", "总以为", "說點", "kidnapped", "jeb", "这宗", "调查组", "出书", "河上", "哂", "統治", "苔", "遏制", "sharing", "穛", "吉蒂", "評委們", "翠", "数百", "急剧", "有远见", "沙场", "买房", "擦肩而过", "毛孩", "烟熏", "雏鸟", "待人", "布勒", "中子", "两对", "托妮", "派系", "璍", "登入", "黑眼圈", "胶布", "不蠢", "打领带", "戀愛", "伪善", "城内", "沙萨", "有段", "河畔", "抬起头来", "盜", "卖国贼", "犯罪率", "groups", "看不惯", "长枪", "industry", "国防军", "供认", "猎魔", "十一年", "一宿", "功绩", "宠物店", "生疏", "点药", "劣势", "黑暗面", "畀", "vessel", "鲁思", "whiskey", "展開", "武赫", "妮儿", "美餐", "高南舜", "不如说是", "逼不得已", "愿景", "一般般", "argh", "幼", "闹够", "盐湖城", "卷土重来", "蕭", "语调", "chips", "哈维尔", "呼啸", "融为一体", "收養", "琳赛", "特家", "ignore", "cigarette", "创可贴", "野蠻", "拐弯", "铁拳", "縉", "拧断", "這車", "几十亿", "何地", "embarrassing", "radiation", "幸福生活", "别伤", "两晚", "着魔", "帮着", "三人行", "破產", "铁石心肠", "并会", "鱼钩", "體驗", "盆地", "何小勇", "這輛", "glen", "睡美人", "商谈", "穘", "翁主", "仅凭", "铁托", "一本正经", "異", "晚间新闻", "天佑", "预言家", "囊中", "老姐", "officially", "因果报应", "要接", "乘务员", "婴孩", "警卫员", "分公司", "夏琳", "wang", "先帮", "水疗", "reporter", "科学界", "小雅", "辛巴达", "fence", "幽靈", "翠丝", "ou", "不唱", "瞎猜", "一分为二", "压轴", "开发商", "雷夫", "bust", "蹄子", "探查", "和田", "hurting", "发过来", "纸上", "生与死", "诺姆", "swarek", "坚挺", "科学研究", "巡邏", "早来", "蚱蜢", "更有意义", "动作片", "終點", "关西", "烟雾弹", "惨重", "新英格兰", "第一支", "原则上", "挨家挨户", "哈丁", "地段", "洋基", "soo", "恶搞", "贡品", "连队", "出风头", "小崽子", "投奔", "黄泉", "纳丁", "司法公正", "再活", "russians", "hatfield", "毛澤東", "編輯", "旅遊", "sabine", "诺德", "别克", "焗", "伸张", "滩", "控", "糵", "不认", "提芬", "瓦克", "低下头", "帕金斯", "georgia", "音梦", "糊口", "哈奇", "雏田", "换装", "常来", "无拘无束", "射出", "发慈悲", "dalton", "wesley", "朝仓", "不懈", "化学家", "白日", "确是", "大美女", "马尾", "那快", "一了百了", "液压", "森山", "緬甸", "放手一搏", "吵吵", "这俩", "柚子", "葛斯", "調整", "本垒", "盗取", "雏菊", "艾米尔", "我入", "priya", "腐化", "身分证", "自带", "軟", "警服", "trey", "稀少", "成功率", "扛着", "一目了然", "糖霜", "大白痴", "辛劳", "你終", "最深处", "還帶", "派翠克", "良心不安", "挑出", "药方", "接连", "灌溉", "数以百计", "古兰经", "jasmine", "亮出", "說謊", "賓館", "一档", "早濑", "灵车", "scientific", "進屋", "斯科菲尔德", "各类", "仪表", "执政官", "全方位", "tre", "球鞋", "请留步", "签发", "送别", "buck", "候选", "出家", "世事难料", "备战", "墙边", "前戏", "道尔顿", "小南", "朝田", "宽大", "助听器", "微臣", "這等", "鹿角", "图灵", "人造卫星", "佛山", "尽到", "素季", "魁北克", "作證", "逆境", "葡萄牙人", "穿孔", "射得", "压倒", "阿峰", "储藏", "巴尔杰", "托罗", "奈莉", "强求", "輝", "白种人", "攝像頭", "焉", "臨", "鸵鸟", "演讲稿", "长夜", "chill", "标注", "硓", "厕纸", "extreme", "躲猫猫", "点滴", "垮台", "瓦尔德", "安卓", "门户", "舒舒服服", "水压", "投訴", "扎根", "一見", "卡利斯", "造出来", "别名", "一毛", "壮举", "河口", "剑客", "吱吱", "铁皮", "民用", "穎", "worlds", "静电", "命根子", "express", "死气沉沉", "富含", "形狀", "表皮", "煎蛋卷", "诺比", "搶劫", "審問", "噩夢", "太多事", "共和军", "跳过去", "看准", "赖利", "賬", "信天翁", "fleet", "长滩", "达科", "新大陆", "真夠", "拖拖拉拉", "有两下子", "露馅", "南区", "别信", "有误", "宴", "坏球", "画布", "透支", "越深", "一帮人", "离了婚", "瑞金", "延后", "借个火", "宽阔", "聖母", "beats", "谁会想到", "阿包", "hammond", "惦记", "汤美", "窰", "龙门", "toy", "皮克斯", "intend", "镖", "如初", "castiel", "五楼", "人間", "keen", "性取向", "atom", "replace", "罰", "李庆莞", "明月", "感叹", "滑铁卢", "把戲", "hardison", "辩护人", "他变", "孞", "opens", "习以为常", "洗個", "圆顶", "樂意", "崔斯坦", "rack", "communication", "垒球", "telephone", "阿花", "lifetime", "悬浮", "火拼", "十一岁", "没生", "遗骸", "努克", "眼中钉", "受贿", "画个", "計算", "毅", "南韩", "蜕变", "毛毛虫", "撞开", "盖房子", "没差", "般地", "发夹", "祝酒", "开窍", "加紧", "本世纪", "打扫卫生", "蓝光", "阿积", "贝纳", "鱼叉", "校规", "不太多", "蒙上", "自夸", "中饭", "他试", "小妖精", "瞩目", "gee", "善用", "一端", "均衡", "梳头", "找事", "息息相关", "拼死", "有色", "应验", "坐等", "烦透了", "树下", "佛教徒", "数天", "tyson", "随性", "kicking", "当头", "难倒", "祖儿", "钠", "林斯基", "bethany", "檢測", "克里夫兰", "阿本", "衬", "电灯泡", "tanner", "xx", "楼梯间", "加勒特", "怀恨在心", "不遠", "裸泳", "lynch", "能先", "百元", "肺里", "gleich", "北海", "波茨", "远见", "新婚夫妇", "鞭炮", "在历史上", "到极点", "惯", "居留", "香农", "卡卡", "烤饼", "撞毁", "幫派", "椿", "申请书", "逃離", "整片", "把門", "嫁出去", "rude", "缩水", "千个", "范畴", "放生", "溶液", "农舍", "克洛维", "抹杀", "死时", "管住", "好勒", "来些", "每一", "公诉人", "particularly", "連我", "上读", "放牧", "长长", "停尸间", "阴霾", "鼓起", "cared", "美利", "spears", "没人住", "王上", "弹弓", "上用", "人话", "woody", "爱迪", "混为一谈", "飘飘", "开胃", "你娘", "尼泊尔", "一言难尽", "转眼", "死角", "这水", "先带", "喂奶", "操作员", "酵酵", "sale", "伏特加酒", "桑娜", "citizen", "百列", "selfish", "私情", "风范", "积", "大明", "再試", "回敬", "我點", "上過", "教師", "麻药", "小美女", "呵护", "齐克", "狀", "比作", "肠", "费利克斯", "黑头发", "致词", "帮别人", "报告书", "不能允许", "哈利波", "惨烈", "人情味", "clint", "铐起来", "机库", "franz", "煞车", "愁眉苦脸", "夜以继日", "搜遍", "贫瘠", "禮服", "singer", "鳴", "美腿", "别喝了", "counter", "乱摸", "砍刀", "买过", "老四", "千方百计", "于心", "花香", "手头上", "垂头丧气", "打草惊蛇", "jerusalem", "早班", "蹕", "几枪", "残缺", "人队", "茂密", "演奏会", "恨意", "九叔", "艾伯", "elton", "肯做", "蝶", "堂兄弟", "这病", "讲课", "引以为傲", "金斯", "问答", "刺进", "alexis", "不加", "敲击", "排水", "撕下来", "自私自利", "肿块", "值得尊敬", "塔纳", "开设", "交个", "扶手", "水塘", "关到", "冲撞", "知名度", "pattern", "不喜", "老几", "巨响", "女性朋友", "史考", "bored", "ipad", "雄哥", "失業", "suspicious", "拙劣", "洛维奇", "衣帽间", "來電", "pod", "污蔑", "說出", "战乱", "給人", "別問", "武馆", "巴勒莫", "货舱", "景", "雄伟", "曲调", "步兵团", "大吵大闹", "挣得", "桃花", "指环", "海顿", "沙灘", "提个醒", "烂掉", "可谈", "配料", "齿", "里弄", "斯塔西", "dein", "toys", "拉着", "异类", "茉莉花", "朝鲜人", "威爾遜", "delia", "膝蓋", "slide", "来查", "快上", "反革命", "ling", "意料之中", "职责所在", "钱会", "貍", "美利坚", "特种兵", "communist", "西村", "seema", "穩", "定为", "理财", "处事", "一面镜子", "他害", "榘", "太牛", "審團", "试验品", "空房间", "风平浪静", "格式", "poker", "agreement", "管不住", "几把", "小指", "杜邦", "波里", "違", "交响曲", "cities", "鳟鱼", "thrown", "真菌", "对照", "华盛顿邮报", "维维安", "嘈杂", "comfort", "曲奇饼", "施法", "围住", "割破", "各路", "森严", "撃", "柔情", "清查", "转帐", "不先", "复", "英式", "embassy", "サ", "遍及", "擔任", "dragons", "落泪", "卡西欧", "卡夫", "待机", "ti", "plates", "皌", "夯", "税金", "大道理", "甘蔗", "behalf", "千秋", "矜持", "hitler", "天快", "活不成", "强风", "爱不爱", "妙不可言", "陈旧", "object", "盧", "对於", "捣蛋鬼", "reminds", "锯木厂", "只当", "把握住", "淸", "杂交", "暂时性", "牽", "两声", "hail", "掙", "没多大", "汉奸", "unknown", "可人", "上时", "非去不可", "帕皮", "階級", "飞离", "差勁", "托雷斯", "无路", "基友", "搭载", "说闲话", "第一周", "更多", "district", "绝配", "击毁", "极致", "掣", "繵", "tut", "上工", "frozen", "prints", "酿", "horror", "碆", "亚力", "镜片", "长腿", "前途无量", "port", "奇哥", "拉莫斯", "指名", "去学", "隐姓埋名", "检察", "还太早", "喧哗", "买进", "自治", "不好惹", "western", "美第奇", "喀布尔", "留念", "电话卡", "想法子", "基姆", "sandwich", "预留", "哪学", "員工", "燒死", "破坏力", "染病", "好自为之", "一年一度", "摇篮曲", "全无", "物有所值", "吃過", "喬伊", "挣到", "一瞥", "汉南", "development", "千智", "棉", "张票", "甩不掉", "亡", "canning", "路灯", "vielleicht", "企划", "塞纳", "欢", "兩句", "gro", "jenn", "羁押", "巴特利", "程序员", "京子", "借个", "立志", "校准", "猪仔", "offense", "握有", "贪得无厌", "不合时宜", "赏光", "lars", "highway", "制毒", "顾忌", "盏灯", "mobile", "盋", "国境", "太阳光", "阿华", "要照", "多得是", "傳言", "啄木鸟", "奴隶制", "那棵树", "官員", "第六个", "籍", "透不过气", "力道", "突破口", "multiple", "一败涂地", "風景", "表示歉意", "科隆", "益处", "情况紧急", "沙耶", "几样", "anniversary", "uses", "lawyers", "砬", "老三", "換了", "后勤", "吉莉安", "李家", "para", "好斗", "號倉", "作業", "艾里", "beatrice", "brett", "已过", "马马虎虎", "winterfell", "material", "莺歌", "野村", "弗里茨", "签合同", "藤井", "穷鬼", "令人难忘", "立足", "小艾", "手把", "雪利", "负载", "曾祖母", "jumping", "神学", "脐带", "淨", "名望", "明朗", "医务人员", "舵手", "cartel", "波斯基", "讬", "破处", "奧利", "創意", "沙司", "妇科医生", "米奥", "拿主意", "辯護", "阿飞", "内到", "制品", "bradbery", "lea", "阿真", "立克", "瞎掰", "纽约大学", "现如今", "独生女", "crisis", "稳重", "教廷", "despite", "伤心欲绝", "本镇", "生产线", "人嘛", "寒风", "女方", "洗澡时", "水枪", "jolly", "阵阵", "退货", "mario", "电线杆", "就范", "多蒂", "放点", "法國人", "买辆", "运回", "警衛", "篮", "分行", "不谢", "林克", "雖", "陪你走", "摔了一跤", "凤尾", "惹出", "肯德尔", "斯蒙德", "泰格", "炸酱面", "指著", "犴", "右腿", "安德斯", "二重唱", "两枚", "臩", "共处一室", "骇人听闻", "平滑", "惠子", "成型", "发工资", "晚年", "科德", "伙計們", "称霸", "swat", "捕手", "卖东西", "我现", "繁化", "家来", "獻給", "低价", "没输", "lions", "石柱", "第三条", "corpse", "wilkes", "臣服于", "apology", "七点钟", "医务", "斯姆兰", "先吃点", "敏俊", "说不上", "更会", "冲昏", "物質", "print", "立体声", "大业", "construction", "烈日", "假惺惺", "新颖", "貂", "电筒", "天眼", "多天", "躲躲藏藏", "巴林", "che", "大會", "一两年", "朱诺", "提成", "咒术", "体位", "vin", "布巴", "按兵不动", "塞尔玛", "大开", "破布", "television", "第三位", "在你看来", "灾星", "探病", "gn", "仍能", "过境", "三支", "詭異", "吸煙", "军备", "那先", "三重", "托马", "工作岗位", "饰品", "站点", "救下", "喝够", "补丁", "蔚蓝", "殉职", "口才", "charity", "合体", "芒", "嘩", "欠下", "良", "運行", "叶问", "通关", "阿丽", "從前", "第二层", "黑斯廷斯", "个案", "掌心", "垫底", "请回到", "坏东西", "水滴", "罗蕾莱", "山林", "价值连城", "葱", "装甲部队", "分期付款", "應用", "绵延", "保健", "井里", "泭", "吸进去", "collection", "也給", "一品", "主见", "没门儿", "热带雨林", "蚚", "ibm", "barone", "messing", "疗养", "無限", "斯托克斯", "恰克", "气得", "打磨", "mina", "阿海", "基础设施", "classic", "尸首", "點的", "這招", "凯洛", "至死不渝", "罪惡", "上門", "珼", "瓦尔特", "筹", "kat", "爱薇", "火山爆发", "联军", "南太平洋", "浩瀚", "晶体", "大获全胜", "一心一意", "海勒", "老练", "賤人", "簽署", "帝国主义", "迫在眉睫", "第十四", "flint", "赴汤蹈火", "冰面", "千里迢迢", "溪流", "低等", "兴许", "螣", "研究成果", "知更鸟", "守望", "社会主义者", "安靜點", "自给自足", "悟", "让出", "毫无保留", "右臂", "placed", "家小", "缓", "基尼", "利益冲突", "庙宇", "打个比方", "dracula", "征战", "中枢", "体质", "slipped", "分離", "快睡吧", "brief", "世外桃源", "狂喜", "小金", "greek", "thor", "謠言", "寒意", "疲惫不堪", "惯用", "侦察兵", "无领", "attend", "主炮", "阿威", "宾利", "耕种", "鴿子", "多美", "伴儿", "逢", "檢驗", "具体情况", "自控", "有光", "畏缩", "ォ", "judah", "ツ", "碝", "這事兒", "眼力", "无限期", "刀伤", "河南", "打火石", "渡边", "那类", "亏待", "巡洋舰", "小巧", "安安静静", "攝影師", "牢狱", "普罗米修斯", "时限", "sur", "名册", "removed", "宾西法尼亚", "无缘", "被装", "不敢当", "台车", "能当", "玭", "送人", "三胞胎", "扫罗", "亲手做", "台球", "桐山", "威信", "剥离", "乐土", "蔔", "搬东西", "隐士", "palm", "搭上", "fighter", "beans", "积木", "allez", "喉", "人上", "火候", "我朝", "放在眼里", "运动场", "睡会", "杠杆", "religious", "好战", "建于", "政坛", "之罪", "挺起", "请用", "organization", "触手", "网友", "土御门", "面带微笑", "shared", "類似", "灵巧", "許", "消化不良", "deadly", "driven", "卡蜜儿", "開啟", "导火线", "萨里", "打头", "klein", "束手就擒", "凝望", "成亲", "廉政公署", "faire", "桥段", "坏透", "得胜", "球拍", "罚金", "总动员", "手牵手", "双子星", "没犯", "千斤顶", "儿媳妇", "右卫", "conditions", "帮倒忙", "本該", "汇款", "ggo", "正道", "放行", "水牛城", "璊", "医术", "紧急状态", "振", "佛罗多", "察看", "防爆", "過敏", "尼日利亚", "舒伯特", "苦工", "接待处", "每逢", "读出", "難得", "一矢", "子儿", "ope", "受过伤", "freddie", "坏脾气", "積極", "有间", "曼森", "雪利酒", "孤军奋战", "bend", "舒展", "臆想", "客串", "过大", "利斯", "母熊", "美得", "马提", "人参", "圣乔治", "雛田", "无痛", "音讯", "侵略性", "前者", "强多", "activity", "威武", "受虐", "没气", "小班", "mayer", "回馈", "更年期", "不费吹灰之力", "没过", "封死", "飞刀", "伊万诺维奇", "imagination", "辞职信", "珍玛", "化装", "锅里", "neha", "眳", "人员伤亡", "几口", "撞球", "皮衣", "奋起", "警视厅", "默认", "炸鱼", "舍伍德", "雜的", "小队长", "保龄球馆", "播音", "白俄罗斯", "阿尔敏", "空空如也", "paradise", "试用期", "tone", "大权", "邻", "高得", "出道", "国家机密", "连天", "轰轰烈烈", "工人阶级", "眼花", "脚踏实地", "吸引住", "律师资格", "專注", "第一节", "師父", "privacy", "正人君子", "很瘦", "脱险", "kelley", "售出", "煤油", "ole", "分红", "美艳", "平方英里", "beside", "茫茫", "yards", "比率", "bowl", "之音", "suffered", "空心", "会教", "马霍尼", "guts", "太强大", "twist", "互", "行政官", "彷佛", "鬣蜥", "悬念", "瑞塔", "头脑清醒", "大家族", "交上", "皇族", "觉察到", "吉冈", "演戲", "spit", "塔波", "玖", "渭蔚", "賭博", "绕圈", "最佳时机", "episode", "收线", "菲利斯", "一时间", "宫城", "基拉", "帕奇", "光学", "衣领", "scratch", "变胖", "不过如此", "leak", "拱手", "deeply", "早有", "走火入魔", "秘密组织", "未蔚谓", "相拥", "那現", "波蘭", "傷痕", "死定", "咀", "戴茜", "堪萨斯城", "柔", "别生", "压榨", "淋病", "太遲", "护着", "終", "爱恋", "一探", "argument", "passport", "印在", "買點", "priority", "lara", "医保", "分析员", "游玩", "sport", "召喚", "速", "音效", "寓言", "微薄", "孖", "蹬", "引發", "阿拉巴马州", "sullivan", "他將", "earn", "酗", "钢筋", "临时工", "暴怒", "打動", "robbery", "丹妮丝", "shinar", "小节", "martinez", "frederic", "天网", "綾", "事关重大", "猪猪", "飞来飞去", "饭桌", "沼", "rising", "leben", "holds", "溜溜", "迷魂", "satellite", "直子", "剩菜", "将领", "流畅", "lois", "propose", "维和", "沉溺于", "鳍", "韦斯顿", "固有", "欧内斯特", "ambulance", "探监", "亚哈", "伊拉", "海草", "dire", "經到", "和睦相处", "edwards", "西里尔", "伐木", "第五次", "科西嘉", "ariel", "大牛", "homes", "獵", "性虐待", "精神疾病", "弹片", "好找", "vast", "火葬场", "艾咪", "钝", "安吉丽娜", "bra", "心臟病", "头等", "耚", "朝下", "einmal", "开开", "内行", "卡尔森", "charged", "sends", "寨", "正雄", "太遠", "服務員", "转手", "牡丹", "磁悬浮列车", "窝藏", "那棵", "交界", "快出", "碳水化合物", "大出血", "舘", "我什", "threats", "和平相处", "小气鬼", "老命", "mv", "问声", "喊出来", "面臨", "海角", "口氣", "exposed", "夏酷", "老毛病", "彈藥", "摔断了", "只為", "用人", "粗话", "客廳", "那小", "从何", "乌龙", "模块", "发高烧", "virgin", "氣息", "滚烫", "壕沟", "omar", "铁杆", "茫然", "百次", "破纪录", "两万块", "证据不足", "小笨蛋", "د", "fifty", "還讓", "电力公司", "盐水", "万日元", "一聊", "德福", "处方药", "只卖", "玛琳", "泳裤", "硌", "清單", "中招", "家驹", "toward", "撕毁", "几瓶", "众议员", "弗朗", "過面", "检疫", "停机坪", "大雾", "如释重负", "阿肯色州", "樰", "instagram", "内蒂", "布拉迪", "割草机", "抽点", "它給", "sweat", "义", "我费", "星体", "cats", "blues", "尼加拉瓜", "濒死", "珠子", "不合逻辑", "空投", "脱胎换骨", "chung", "拼字", "閱讀", "內衣", "七星", "满足感", "违反规定", "刺入", "時尚", "有氧", "投了", "六楼", "flew", "日本帝国", "大费周章", "放进来", "begun", "要交", "比莉", "开尔", "安東", "太田", "australia", "交响乐", "抢手", "论证", "招摇", "叛逃", "奶奶家", "小酒馆", "交流中心", "中槍", "別給", "攝像機", "戲", "過頭", "内政部", "禁止入", "巴拉德", "揣", "新式", "没脸", "其后", "全数", "candace", "孤身", "博爱", "你連", "献", "查完", "火災", "分一杯羹", "explosion", "往上走", "tests", "騎馬", "肉欲", "samcro", "露比", "美洲豹", "高声", "問好", "离远点", "睡袍", "坐到", "有分寸", "safer", "隆尼", "遊行", "丽丽", "赤脚", "regina", "出类拔萃", "诗集", "坐公车", "红毛", "梅莉", "六扇", "白丝", "快报", "槌", "體", "四份", "普利策", "同仁", "服兵役", "时间机器", "异能", "mel", "钻研", "脫離", "司马", "破获", "共济会", "不单是", "怪声", "二十七", "弗朗西", "钟意", "碙", "嫖妓", "helpful", "醒酒", "ャ", "朗格", "投资银行", "水路", "令人恶心", "克利斯", "marc", "stabbed", "省下", "液态", "打包票", "机油", "貴族", "强健", "史迪奇", "够快", "二十二", "爱喝", "可真会", "比彻姆", "何为", "刁难", "齐聚一堂", "阿米尔", "动一动", "閑", "墮落", "效仿", "session", "聪慧", "倒杯水", "外科手术", "奥尔", "servant", "拿給", "洗心革面", "這和", "神智", "打印机", "联络员", "只待", "剃须刀", "内斯特", "军部", "傳播", "狐猴", "镶", "塞萨尔", "诸葛", "医疗队", "藩主", "阴谋论", "虎克", "空无一人", "花束", "乌合之众", "强加", "发送给", "開頭", "亚丝娜", "吃不了兜着走", "大清", "舒服些", "索性", "正对着", "风骚", "开膛", "特洛", "脱逃", "大海捞针", "山大", "小兔", "蓝鲸", "插上", "suite", "妃", "蚝", "造福", "纪", "失踪案", "屋裡", "仙女座", "别去了", "不會給", "法蘭克", "校外", "球技", "吊车", "我戒", "沙尘暴", "靓", "關上", "公用", "科维奇", "格里菲斯", "傻冒", "cdo", "passion", "食宿", "桃", "方世玉", "真對", "浦", "诺伊", "设下", "医", "好麼", "不屬", "市郊", "降临到", "特快", "sunshine", "viva", "耶稣会", "付錢", "坐落", "冒汗", "后路", "动词", "十万元", "ng", "自我感觉", "今时", "查一查", "太猛", "菲尼克斯", "志向", "福祉", "拘谨", "缴税", "肉體", "赌债", "佩拉", "sawyer", "加护", "确立", "电子设备", "盖章", "指挥权", "真早", "带坏", "不人道", "不息", "不忙", "新款", "網", "配角", "纯金", "赤字", "不计其数", "流星雨", "宴會", "walsh", "发型师", "繃", "魔掌", "跡象", "當著", "前死", "tend", "搬迁", "锐利", "有喜", "合众国", "构成威胁", "两千块", "回航", "wilder", "相继", "丁先生", "防晒霜", "veux", "石头砸", "最高级", "阿贝尔", "阿彻", "stanton", "只收", "耑", "入土", "ahran", "吉田", "伊莫金", "kannst", "忌日", "养老", "strip", "畢", "陰影", "涌现", "门把手", "溜掉", "現代", "问完", "currently", "问世", "走秀", "没坏", "思科", "爱莫能助", "同龄人", "贖", "街區", "十万块", "连珠", "矿坑", "辊", "謹慎", "克拉斯", "查下", "虱", "我的車", "老金", "如是", "档案室", "教主", "灼伤", "magazine", "残留物", "扬基", "快用", "一觉", "流域", "boston", "马赫", "情调", "我特", "喀", "统合", "亞伯", "巨龙", "咽", "没找", "乳臭未干", "耍嘴皮子", "請客", "搭船", "品酒", "水深", "爱滋病", "让你能", "惨叫", "挺好吃", "中要", "弥林", "工作日", "躯干", "臭娘们", "玛格利", "第十集", "天狼星", "闹大", "常会", "油轮", "立陶宛", "耶鲁大学", "危地马拉", "国安", "莱登", "russ", "十九岁", "holes", "江山", "凯莱", "彼方", "琴酒", "女声", "莱格", "burton", "塔西", "阿爹", "破除", "最惨", "拘", "花椰菜", "佩蒂", "morris", "攻陷", "敏智", "有颗", "花呢", "delivery", "角质", "消防局", "pages", "划艇", "與眾", "递过来", "前年", "付得", "希克斯", "reverse", "阿克斯", "柏克", "蛋黄", "升迁", "procedure", "沥青", "家常便饭", "年糕", "红利", "州际公路", "撒切尔", "没剩", "麦肯", "最壞", "matty", "proposal", "担子", "敞篷车", "带进去", "传令", "引人入胜", "感触", "华金", "奥克斯", "苏俄", "要试", "gl", "第四名", "開場", "坐地铁", "若非", "圣坛", "磁性", "觉得很有", "nee", "家常", "杖", "發給", "横穿", "钛", "躲进", "拉斯特", "请往", "保护区", "调查报告", "ﺈ", "patch", "真神", "起哄", "火刑", "差別", "舞蹈家", "梳妆台", "相安无事", "我应", "相称", "alcohol", "我系", "沒命", "掺", "柳德", "弗拉德", "出招", "paintings", "韦尔奇", "台詞", "shotgun", "busted", "烤牛肉", "雷纳托", "发电报", "没出", "鐘頭", "色调", "鼠辈", "合一", "錄", "計程車", "拉法", "观铃", "截断", "藏到", "基诺", "虫虫", "洛里", "信号灯", "阿莫", "穆恩", "歡呼", "优待", "bail", "maintain", "ashamed", "开脱", "skull", "崔坤", "答谢", "滑翔", "打发走", "超能", "談戀", "米格", "蜂鸟", "人站", "奥迪", "玩具枪", "爽死", "refused", "人前", "亡者", "掉以轻心", "深入调查", "淺", "芹菜", "這聽", "无中生有", "派拉蒙", "护士长", "優雅", "嘗", "代劳", "緗", "几招", "座头", "摘要", "套路", "耶利米", "无可挑剔", "狗屎运", "会有", "硬照", "不好办", "取缔", "possession", "小學", "新政府", "反叛者", "奥斯本", "坏死", "下周一", "贩", "子弟", "自我牺牲", "富足", "laurent", "抚养权", "鈾", "要关", "技术员", "季后赛", "俗称", "峭壁", "不大可能", "大田", "正忙", "国际刑警组织", "贾巴", "美好事物", "體會", "第一站", "叫唤", "混进去", "早间", "creature", "震荡", "库巴", "rod", "改邪归正", "一意孤行", "号门", "迎击", "塞特", "德夫", "威震", "镇民", "eloise", "失禁", "展翅", "重达", "劫机", "单程", "驷", "軍官", "玛德", "vinci", "贾姬", "母舰", "派兵", "怀俄明州", "mccarthy", "如若", "灾害", "勘察", "三尺", "施虐", "奇人", "moral", "变黑", "亮晶晶", "二十六", "惠特", "插座", "起名", "真身", "好多好多", "included", "格罗斯", "俴", "respond", "鞋跟", "之痛", "一声不吭", "妓暗", "sais", "戲團", "上周末", "給別", "更让人", "约翰斯", "gesagt", "亲哥哥", "б", "长者", "此等", "ズ", "講過", "整套", "空档", "貢獻", "緊要", "accused", "保护伞", "民事", "静下来", "invented", "arranged", "打量", "之门", "高興能", "beijing", "埋没", "悠悠", "kommen", "拥有者", "昆恩", "苟延残喘", "激战", "桌球", "dealer", "现存", "那起", "特例", "光谱", "benefit", "軍團", "新郎新娘", "费罗", "有責任", "pi", "搞搞", "他求", "下三滥", "等會兒", "tig", "質疑", "有劲", "貨車", "縐", "译注", "southern", "traveling", "萨宾", "馒", "naturally", "我爱过", "错怪", "吃不完", "越长", "佛罗伦", "佐拉", "算得", "product", "艾里克", "别唱", "马甲", "璀璨", "一大批", "邓巴", "重审", "拱", "oxygen", "扎拉", "上周五", "奇利", "丝恺", "雨停", "別激動", "吸进", "dex", "ping", "pamela", "做证", "悸动", "女警", "朱丽", "車輛", "输钱", "力所能及", "排泄物", "污辱", "绑架者", "动动脑", "實施", "jemma", "處置", "放高利贷", "昆廷", "portia", "各项", "pharrell", "jersey", "亞絲娜", "中斷", "這嗎", "戲劇", "玜", "当过兵", "枪崩", "女婴", "先下手为强", "先替", "闪闪", "自称为", "台灯", "领教", "如期", "布魯諾", "观战", "霍普", "rats", "你长", "吾爱", "守时", "前沿", "分寸", "懂个", "himher", "夜生活", "奥尔加", "不予", "爱惜", "韦尔斯", "stones", "费舍尔", "他别", "小西", "阿宽", "我服", "迭", "零分", "不變", "霍根", "名聲", "留情", "routine", "讯", "变硬", "东北部", "识", "rt", "举措", "nigger", "休息日", "上吊自杀", "死八婆", "高调", "阴户", "两本", "eddy", "認錯", "疾", "正經", "wounds", "迈耶", "得給", "山鸡", "蜆", "硬幣", "汤姆森", "高中同学", "参照", "sang", "矿区", "小盒子", "溢", "厅长", "矗立", "媽呀", "标志性", "脓", "造船", "路過", "剪报", "五星级", "稻田", "犯罪团伙", "马术", "尉", "充血", "扇贝", "客满", "burns", "硕士学位", "旧衣服", "similar", "安睡", "仅限于", "status", "pin", "剥皮", "represent", "双关", "麦考", "我別", "有伤", "魔術師", "直肠", "格格", "喝喝", "自个", "aim", "锡贤", "dropping", "urban", "塔罗牌", "萝莉", "头奖", "蚯蚓", "万事俱备", "倒转", "女性化", "thorne", "初号机", "建筑工人", "英格丽", "澳大利", "评级", "打火", "榛子", "少数派", "不滿", "trunk", "桑托斯", "普拉特", "夜场", "后事", "百萬", "sheep", "社会福利", "nie", "抽时间", "resources", "蒟", "凑齐", "rifle", "家室", "省略", "触觉", "洛尼", "靠山", "抗议者", "游过去", "没查", "seth", "卡巴", "cj", "分派", "落选", "决", "妝", "抢过来", "巴萨", "prior", "杜比", "纸片", "marine", "屈从", "吟唱", "呆会", "左臂", "尋求", "平平安安", "连夜", "肚里", "virgil", "butch", "跟踪器", "人少", "相亲相爱", "摇滚歌手", "防禦", "阿尔贝", "自投罗网", "bernardo", "两口", "供养", "外地人", "桃乐西", "损失惨重", "邱吉尔", "殺戮", "私人生活", "火海", "异端", "伊登", "shoe", "酒钱", "一两", "雷優", "移送", "实地", "特辑", "亲笔签名", "火车头", "白鸟", "辈", "kendrick", "希金斯", "戈特", "fade", "rope", "过别", "惶恐", "张伯伦", "塞维利亚", "没准儿", "碔", "朱丽亚", "意中人", "提勒", "尊崇", "連接", "帝国大厦", "電台", "速率", "taj", "第二排", "兩種", "殊荣", "窒息而死", "大麻烟", "日间", "腰包", "邪门", "最帅", "冒失", "杰弗瑞", "陆上", "他输", "帕默", "耐克", "休会", "氣味", "触电", "重金属", "八字", "閣下", "無禮", "一己", "如假包换", "护卫队", "握个", "热力", "哀嚎", "wylie", "算了算", "求见", "第九集", "ｏ", "大祸", "鳏夫", "沈佳宜", "货架", "导向", "异人族", "研究院", "那比", "连锁反应", "付过", "顶罪", "場景", "庞", "语无伦次", "牛郎", "源源不断", "仅限", "纵队", "gettin", "tomas", "shouting", "ichi", "marsh", "fuel", "烤熟", "吃错药", "银行帐户", "閒", "箱根", "判处死刑", "再近", "herman", "霸天虎", "记录片", "劳丽", "滴水", "鼻血", "谁的车", "host", "升級", "应变", "他动", "纽瓦克", "光源", "authorities", "批評", "亲过", "骑士团", "这伙", "保鏢", "锁骨", "讲些", "数百年", "之多", "兩杯", "纉", "許可", "无数个", "有血有肉", "隔开", "無知", "祏", "繁华", "稍作", "傳達", "腋下", "年轻漂亮", "打呼噜", "還差", "膽", "重振", "朱迪思", "蹲下来", "近藤", "分组", "中学生", "之主", "鬼神", "hendricks", "凝胶", "所赐", "五美元", "别出去", "parks", "尼乌斯", "圆环", "對待", "托里", "爱娃", "船来", "隆胸", "支索", "修修", "法治", "舉辦", "捐钱", "别拦", "swan", "无语", "生死攸关", "光榮", "hughes", "船要", "阿特拉斯", "结算", "少说", "朴素", "mikael", "marrying", "石棺", "下樓", "掩", "小草", "叶甫盖", "看得起", "进驻", "甭想", "外國人", "包好", "爱玩", "惨案", "病因", "三叉戟", "群星", "人選", "三军", "熟识", "蒙受", "亚士利", "斯坦纳", "美联储", "鲜活", "尼姑", "聚到", "塞姆", "distant", "总机", "高桥", "獎學金", "確切", "alaric", "楚蒂", "纵然", "鼓吹", "卵蛋", "三垒", "清喉", "渡河", "巫師", "关进去", "dancer", "夏尔", "插孔", "一小片", "合上", "词是", "五小时", "佛蒙特州", "赫尔辛基", "焦慮", "骇客", "asks", "某某", "西南部", "向后转", "自稱", "圣代", "做戏", "coal", "红衣", "你弹", "tent", "ter", "第七个", "算不了", "河豚", "wollte", "vance", "剪子", "transfer", "付诸行动", "喝过", "往人", "圈里", "授课", "計划", "fry", "所向披靡", "裂谷", "individual", "击球手", "奉上", "不可否认", "陪伴着", "掩蓋", "偷取", "英國人", "gain", "气力", "ansel", "双关语", "mob", "要你管", "情绪低落", "倾注", "浮标", "雀", "渭伪", "几圈", "西西里岛", "樫", "床头柜", "轉變", "插队", "铺设", "如此一来", "遗留", "艙", "罪责", "克里斯托", "北纬", "嘱咐", "portal", "口粮", "秘", "搞点", "鎊", "夫斯", "會面", "逃往", "那小女孩", "梅因", "回升", "吹笛", "独吞", "傾", "妙计", "四种", "庄重", "两到", "舅父", "妊娠", "反锁", "刨", "你作", "声名狼藉", "越近", "我們給", "授權", "hofstadter", "无可奈何", "自会", "家业", "那堆", "对性", "不法", "上机", "满心", "德文郡", "fifth", "paperwork", "裸體", "真難", "霰弹枪", "脾脏", "montague", "儡", "wondered", "岔路", "小男生", "枕頭", "躓", "我录", "指挥所", "白纸黑字", "奥尔德", "福里", "三郎", "吱吱作响", "铺床", "微缩", "吉莉", "压碎", "瓶颈", "跟屁虫", "african", "南无", "马利克", "牛角", "超多", "鼻梁", "小奈", "清潔", "二十八", "解放出来", "哔哔声", "highest", "肉汤", "堆满", "草皮", "ramon", "大口", "郔", "蜜桃", "单凭", "桌面", "心狠手辣", "三艘", "团队精神", "百花", "低潮", "责骂", "槍給", "牧羊", "雄鹰", "索非亚", "羹", "沃森", "卡伊", "人人平等", "额滴", "finest", "杰斯特", "马奥尼", "余额", "双眸", "麦考密克", "野草", "donovan", "往左边", "并不比", "崎岖", "展望", "genetic", "别有", "你点", "小說", "獴", "瓦妮", "出老千", "拉索", "举重", "济慈", "春卷", "influence", "精心策划", "多花点", "别致", "四日", "和亨利", "遭罪", "煞星", "信物", "提比略", "克萊爾", "然後在", "第二部", "richmond", "絕", "弄不好", "rowan", "虾米", "两国", "奇居子", "止不住", "sadie", "噌", "peach", "金块", "席恩", "塞勒斯", "最重", "天平", "杰斐逊", "自大狂", "氢", "盲选", "廉", "teaching", "英国政府", "哥伦比亚大学", "landed", "私有", "两百年", "罗德斯", "來個", "风采", "播放器", "英熙", "区内", "私家", "cancel", "休姆", "變回", "公海", "秘书室", "先机", "奴仆", "只够", "pirate", "撑腰", "护栏", "善变", "徒步旅行", "三场", "男士们", "線路", "伊莉莎", "ramsay", "五十元", "選手們", "行情", "水井", "邪惡", "ida", "大卸八块", "youth", "生是", "muscle", "沒帶", "打昏", "陪我玩", "不归", "烦死人", "版面", "弟妹", "蒋", "友子", "捕头", "海丝特", "杰弗逊", "写错", "轮机长", "旗舰", "建国", "我令", "更酷", "乔纳", "总局", "俚语", "奥斯陆", "真小", "跳上", "全身上下", "杀个", "猜得到", "家屬", "elf", "初夜", "驮", "高竿", "fields", "ハ", "诺里", "米洛", "uhh", "images", "摆个", "检点", "大饭店", "不賴", "品行", "katya", "楚门", "贝瑞", "普洛斯", "头盖骨", "哪点", "钱宁", "shirin", "heal", "拿點", "雷布林", "撞墙", "拉罗", "认领", "俏", "手掌心", "lydia", "舒缓", "ﺆ", "當局", "莱蒙", "小星星", "克鲁兹", "大膽", "援兵", "你养", "精神病人", "evans", "quentin", "法者", "政界", "bobbi", "女管家", "pile", "reputation", "歩", "博得", "佩林", "shitty", "實", "破爛", "flood", "francisco", "fernando", "责任心", "第一项", "罗科", "彻查", "favour", "借贷", "替天行道", "福利院", "我认", "根筋", "ㄚ", "解析", "法老王", "奎特", "割喉", "藻类", "嘆", "次回", "雞肉", "考夫曼", "厚道", "默默无闻", "举枪", "ip", "屠殺", "白白浪费", "interests", "評論", "徒劳无功", "判決", "斃", "警务人员", "炖菜", "琂", "总台", "baseball", "得寸进尺", "白衣", "丙烷", "蛇头", "渭慰", "磖", "翻遍", "上給", "mixed", "补给品", "ridge", "卡萨诺瓦", "餐饮", "怮", "大马士革", "发酵", "组织者", "瑜珈", "代表作", "晕头转向", "恶达", "初戀", "投标", "luther", "彷徨", "這做", "territory", "人脑", "levine", "贝隆", "没喝", "战俘营", "卖场", "保护措施", "claims", "可憎", "三遍", "保加利亚", "行善", "马诺洛", "不太熟", "呼喚", "脑里", "大不相同", "rap", "闹翻", "怪诞", "借问", "狩獵", "球場", "那刻", "宮", "冬儿", "再忍", "变魔术", "引退", "树敌", "ﺞ", "种植园", "憲法", "拉罕", "椒盐", "雪上加霜", "润滑油", "普兰", "一连", "抉擇", "秃顶", "腹肌", "下节", "右眼", "赛前", "bills", "tobias", "热切", "报警器", "软蛋", "吉诺", "说得通", "bosco", "所見", "十八年", "怎能不", "一新", "朝前", "滑下去", "喜怒无常", "开窗", "九天", "artist", "武装部队", "布什总统", "人身攻击", "关切", "电死", "对冲", "赛亚人", "淫妇", "问路", "此举", "lil", "debs", "洞察", "踏足", "丧心病狂", "開花", "来客", "布加勒斯特", "火龙", "特徵", "礼帽", "疲累", "重归于好", "他敢", "画笔", "ょ", "红茶", "報應", "嬴", "会动", "新世纪", "擦洗", "雷优", "预科", "軌道", "prevent", "他放", "bea", "奇奥", "摧", "搜到", "舱口", "浑身解数", "南北战争", "老马", "多付", "售货员", "颇为", "couch", "无意间", "擦鞋", "手提电脑", "犯罪活动", "这组", "康涅狄格州", "號的", "morgen", "gracie", "golf", "钱币", "选择性", "candidate", "siri", "同乡", "几近", "carr", "预", "驻地", "装扮成", "farmer", "tyra", "出聲", "气闸", "乱马", "阴郁", "骄傲地", "大碗", "收着", "十個", "諸位", "meyer", "rum", "关键词", "attacks", "echt", "已逝", "停到", "全军", "電力", "遥不可及", "protocol", "族长", "甝", "长凳", "蒙古人", "我祝", "罗德岛", "chicks", "摩阿迪巴", "尖塔", "门槛", "那俩", "势头", "改观", "假人", "骆", "他朝", "著想", "瑞特", "抽奖", "佛德", "一概", "定点", "托莱多", "实验品", "会否", "昼夜", "民意", "罗文", "戴米", "搞完", "水蛭", "魔爪", "creek", "第一次世界大战", "建在", "阿瑞斯", "运动服", "vi", "海利", "russia", "家时", "瑪姬", "非比寻常", "galaxy", "mummy", "市子", "我练", "幾小時", "眯", "晚班", "狐狸精", "社團", "雷神", "oath", "提督", "缸", "principal", "脑壳", "赫鲁晓夫", "交锋", "哪部", "减掉", "沸", "夥计", "eon", "炒作", "玦", "数十年", "坎宁", "白费力气", "上能", "开普敦", "owned", "罗曼史", "會過", "独行侠", "洛克先生", "thick", "敦促", "筂", "百慕大", "常春藤", "鞋印", "一盏", "重蹈", "maurice", "夺命", "operations", "别拉", "特异功能", "锁部", "点烟", "henderson", "说三道四", "卡普兰", "涂上", "专题", "jefferson", "热能", "躬", "出发点", "吉格斯", "离线", "humanity", "獎勵", "漤", "投票权", "先天", "樱井", "木浅", "家政", "就此结束", "回教徒", "motor", "原文", "不美", "反响", "套间", "痰", "寮", "重开", "规格", "妞兒", "世世代代", "舉動", "以眼还眼", "pt", "摆明", "評估", "棫", "小道消息", "丹特", "徇", "臫", "cheer", "筆錢", "温特斯", "布罗迪", "装个", "艳", "換成", "彦", "收尸", "连接起来", "钢琴课", "仁太", "还生", "驾驶证", "猴急", "杰拉", "痊", "手來", "石灰", "函", "海盜", "围捕", "德米", "raphael", "penelope", "proudly", "damned", "别错过", "希波", "赚来", "电视网", "槍擊", "供應", "geet", "不顧", "laptop", "難堪", "穓", "咬牙", "銷售", "农药", "老糊涂", "一遭", "我谨", "大龙", "来来回回", "车场", "大伟", "倒流", "customers", "mini", "guthrie", "病重", "蟾蜍", "遣", "事时", "拖出去", "掀开", "抽出来", "周前", "tin", "灵性", "狂怒", "string", "無選擇", "大队长", "全军覆没", "greer", "反光", "天下第一", "太软弱", "麦肯纳", "布拉沃", "闺房", "spin", "藤蔓", "免疫力", "挖走", "intention", "flash", "领悟到", "弑君", "寒", "飞鹰", "制订", "呀呀", "真幸福", "发愁", "典禮", "得出结论", "clients", "年輕", "克西斯", "行業", "damaged", "算错", "每一分", "教得", "特克", "舞狮", "太脏", "新片", "幫手", "enjoyed", "挂钩", "就別", "为数不多", "症候群", "雷伊", "rde", "难以想像", "bait", "covering", "鮮", "右拳", "停滞不前", "帘子", "浓雾", "掌柜", "欺", "男人婆", "行医", "視", "forgiveness", "胃痛", "savannah", "argue", "沒開", "雇来", "吉迪恩", "绝路", "還未", "转换成", "全队", "润滑", "預定", "報酬", "衭", "oc", "我明", "奉行", "有来", "随口", "頁", "过气", "总该", "shining", "自暴自弃", "地心引力", "幕僚长", "yy", "放浪", "特此", "莫过于", "建筑工地", "active", "熄掉", "瘪", "硬是", "空谈", "狙擊手", "十几", "這說", "衝突", "得动", "拔刀斋", "追得", "粘住", "摇摇", "助人", "大时", "老豆", "转化成", "自知之明", "ils", "致谢", "警棍", "碍眼", "扣好", "狄兰", "confident", "攻略", "剖开", "acts", "塞德", "手给", "芲", "prick", "梅子", "领着", "微粒", "卫斯理", "tits", "dis", "下线", "雕", "饮水", "贸然", "三枪", "终了", "海选", "推力", "弗勒", "麦坤", "模糊不清", "韓", "blessed", "茶餐厅", "色情电影", "加斯帕", "左眼", "沒收", "required", "翻翻", "你介", "宽慰", "neighbor", "那桌", "蹦出来", "下蛋", "eliot", "performance", "地球表面", "便衣", "otis", "天主教会", "阿忠", "大白", "下意识", "诧", "凱爾", "大门口", "下部", "贝尔特", "merci", "pepper", "崇尚", "火山灰", "punishment", "旁听", "vampires", "哥斯达黎加", "以斯帖", "mindy", "提醒您", "交换条件", "隶属于", "母性", "略有", "格瑞斯", "綤", "开怀大笑", "漏气", "莫斯利", "sarge", "公诉", "perkins", "伯克利", "地面部队", "瓦伊", "madeline", "学姊", "放错", "exists", "guide", "很多遍", "guilt", "邊緣", "看太多", "一缕", "独生子", "純潔", "活蹦乱跳", "遵守规则", "mathison", "马克西姆", "围成", "基亚", "宏大", "centre", "公升", "亲信", "明日香", "挪用", "画上", "loyalty", "場合", "發過", "艾莉亚", "世娜", "劳里", "記不起", "陷得", "特派", "三根", "老妹", "雷姆", "防腐", "滚下来", "脆饼", "说胡话", "盗窃案", "奈森", "斗嘴", "西北部", "我种", "無力", "侦破", "迫切需要", "酸痛", "堆里", "响子", "骗到", "几多", "保釋", "awkward", "分工", "miami", "包涵", "nss", "润滑剂", "火速", "降下来", "existence", "秃子", "小乖", "好烦", "教導", "蛤蜊", "撅", "红鹰", "宫中", "两句话", "違背", "下身", "feeding", "药都", "找別", "做礼拜", "心得", "爬行动物", "jenkins", "stable", "城池", "肠道", "俄克拉荷马州", "跑遍", "哈伦", "磝", "散个步", "抡", "卡斯滕", "pilar", "中伤", "转瞬即逝", "竤", "fbl", "试下", "蓝精灵", "之女", "什幺", "lolly", "之遥", "牛粪", "继任者", "热茶", "channing", "哭诉", "动脉瘤", "枪里", "ぁ", "目瞪口呆", "群眾", "当当", "名人堂", "长裤", "跑不动", "后视镜", "imagined", "不問", "无精打采", "參議員", "仙尘", "美男子", "圣塔", "放著", "之分", "全包", "跳车", "条线", "三十天", "初选", "还活", "生殖", "懵", "洲际", "变色龙", "连姆", "有福", "亿人", "六处", "紁", "kennedy", "穿梭机", "铁丝", "先給", "童贞", "缩", "障眼法", "尼克尔", "火苗", "女神像", "韋恩", "闻所未闻", "payne", "订做", "在所不惜", "类别", "nazi", "历史课", "我握", "昹", "校方", "相马", "hopefully", "无依无靠", "entered", "archer", "博蒙特", "我太想", "马马", "偽", "太沉重", "埋起来", "钱能", "热吻", "烙", "穆迪", "学识", "五条", "焰火", "检视", "配菜", "好牌", "sucre", "值夜班", "印有", "好好笑", "水边", "玛德琳", "铺位", "milly", "癩", "海神", "有利可图", "玸", "突然袭击", "退场", "資源", "auggie", "吸走", "虳", "wollen", "极佳", "搞些", "阿七", "杀人灭口", "凱西", "wore", "帕丁顿", "在野党", "吹气", "乱窜", "仲裁", "只带", "详细情况", "新秀", "混音", "还算", "音乐吧", "兼顾", "脱手", "困苦", "公证", "苏瓦", "employees", "变通", "闷热", "好怀念", "砉", "神经科", "长进", "毫无根据", "真話", "伤及", "dramatic", "狡诈", "樑", "等离子", "碰碰", "拉动", "脊", "loaded", "查利", "serving", "米洛斯", "一触即发", "suspects", "莱文", "暹罗", "尽心尽力", "远大", "公馆", "炸藥", "康复中心", "窘境", "cheating", "养过", "動起", "护林员", "õ", "吵起来", "我来付", "去不成", "疫情", "社区服务", "万吨", "安全部门", "会会", "情敌", "活過", "pays", "心力", "井井有条", "起飛", "冬", "杀气", "escort", "死刑犯", "马可士", "manav", "cordelia", "特洛克", "唾沫", "七仔", "枕", "laurie", "处刑", "dusty", "才能救", "教头", "aqua", "stannis", "这包", "血浆", "转运", "连带", "西尔维亚", "哄骗", "老顽固", "比伯", "权衡", "出生日期", "肌肉男", "katy", "弃船", "这手", "拖拉", "异禀", "官府", "terrence", "抄近路", "山贼", "waldorf", "火枪手", "遺傳", "费事", "塑造成", "搅局", "大罪", "陰謀", "烈", "endless", "哥伦比亚人", "explanation", "闖入", "resistance", "飙升", "正站", "放倒", "期刊", "二是", "chaos", "oi", "再造", "瑞吉", "就业机会", "延缓", "噱头", "舒尔茨", "龙珠", "必备", "盟国", "血液循环", "玛西娅", "这处", "两千年", "大面积", "倒立", "米酒", "這時", "绿野仙踪", "潔", "指挥室", "外层", "起动", "除臭剂", "失利", "輛", "貸", "theater", "达芙妮", "writer", "变节", "韓民國", "脸皮", "mysterious", "一决胜负", "驰骋", "人名", "ease", "亲家", "得力助手", "克洛斯", "家家", "珊德", "娣", "看家", "提款机", "wagner", "浑水", "年华", "耕作", "转速", "蛹", "聾", "gifts", "forbes", "地洞", "耽誤", "標誌", "历史悠久", "于世", "有何感想", "寻欢作乐", "妮尔", "neighbors", "欠款", "needle", "林顿", "加进", "闪现", "州長", "鞍", "thun", "寄过来", "风铃", "量身", "起源于", "民子", "尤达", "讲台", "役", "诉诸", "axl", "剔除", "stroke", "似地", "证据确凿", "爐", "丹妮莉丝", "外带", "孫女", "杰贝", "泥潭", "闪电侠", "硅", "平民百姓", "希伯来", "卸下来", "电话费", "严惩", "白头偕老", "纸币", "声东击西", "试吃", "大都市", "方形", "傑夫", "红辣椒", "figures", "六分", "冲击力", "这口", "烟灰", "weston", "秀晶", "寻回", "扑通", "原形", "鍛煉", "列夫", "战备", "警員", "糊塗", "老佛爷", "专线", "爬出去", "项羽", "哈卡尼", "救济金", "克思", "完全符合", "太极", "人类文明", "洗涤", "服下", "猜拳", "過會", "苏尔", "陶器", "按部就班", "黑火药", "chemical", "我射", "奈何", "moby", "莫莫", "会演", "请放", "第二任", "好轉", "情境", "在給", "恩德", "require", "當一個", "halfway", "要花费", "危难", "锡安", "soprano", "缰绳", "晃荡", "亚特兰", "mistress", "出獄", "白龙", "treason", "离弃", "粘着", "認不出", "配套", "转右", "未了", "煞", "纽奥良", "小雷", "波纹", "小茜", "increase", "蓝道", "mkv", "藝", "admire", "在职", "苹果汁", "深影", "药草", "千人", "grief", "incredibly", "船厂", "戈麦斯", "combat", "hei", "durch", "够格", "嚇人", "自认", "吐气", "强制性", "timing", "泥浆", "親近", "藉此", "拿上来", "摆脱困境", "抢案", "多才多艺", "洁癖", "新开", "jaime", "出毛病", "起跑", "恭", "骑过", "令人满意", "拉米", "dixie", "personality", "吉尼斯", "二百万", "帶領", "bump", "荒", "一整套", "慈祥", "微光", "霍华", "穿刺", "花太多", "零号", "黑兔", "checks", "許多人", "星尘", "article", "自然规律", "元凶", "votes", "乘飞机", "罐装", "使然", "来教", "张玲子", "车箱", "内置", "chien", "堂妹", "maker", "inform", "开幕式", "然後是", "polly", "正義", "薛", "染指", "增进", "一波", "ensure", "艺术作品", "前座", "客舱", "锭", "史努比", "政见", "actions", "covers", "高等教育", "撕烂", "希区柯克", "多比", "心有", "暴打", "比做", "应召女郎", "那盘", "發行", "海源", "谢幕", "悉听尊便", "枪枝", "迷失方向", "校队", "撒娇", "放风", "roland", "罗汉", "公事包", "耍赖", "污染物", "季风", "山口", "nut", "網球", "講講", "項鏈", "幼儿", "赫本", "尤利西斯", "四张", "为证", "拜倒", "這應", "传呼", "有給", "千禧年", "scm", "落日", "替死鬼", "自古以来", "戴恩", "百分之五十", "佩雷斯", "wieso", "失忆症", "romance", "lina", "俠", "树桩", "猪圈", "一出戏", "而戰", "揩", "義務", "漫漫长夜", "空军一号", "炒面", "遇到困难", "独有", "蝗虫", "carroll", "監視器", "accounts", "拍出", "点力", "三人组", "rosen", "apologies", "足球比赛", "差远了", "點了", "够不着", "安弟", "玛丽恩", "噩耗", "膽子", "returning", "秪", "两手空空", "阰", "風暴", "tiffany", "为例", "很乖", "七日", "私语", "事成", "不言而喻", "你求", "之快", "左轉", "不求", "家俱", "吕克", "埃塔", "jamais", "慘了", "临阵", "英美", "气炸", "千辛万苦", "宰相", "说行", "祢", "气喘", "驯兽师", "production", "鸣声", "詢問", "抯", "chop", "瓦肯", "阿哥", "席勒", "bellick", "恐高", "近來", "快離開", "两成", "家务事", "趴着", "斯瓦尔德", "可樂", "爹娘", "那瓶", "圣像", "reaction", "蛮力", "老同学", "津巴布韦", "涨价", "愚人", "含蓄", "守信", "質", "緓", "作恶", "划痕", "秃", "赃款", "不醉", "costume", "一头雾水", "拼错", "羞涩", "沙律", "麦克尔", "克鲁", "女人真", "immediate", "脱不了", "嵌入", "玛蒂尔", "亚娜", "蠢蠢欲动", "四下", "食人族", "埃娃", "怯懦", "日本政府", "詩乃", "心肝宝贝", "内外", "秋香", "卡上", "juliet", "爪哇", "蜷缩", "独立宣言", "安全帽", "黑豹", "沼田", "氦", "新歌", "杀手锏", "出差错", "柯达", "舱麓", "修指甲", "近视", "gathering", "高射炮", "喜羊羊", "om", "李德", "长距离", "珍貴", "instructions", "記起", "站不住脚", "车牌号码", "灰熊", "科托", "跳出去", "全舰", "閃開", "暗淡", "米开朗基罗", "致力", "追加", "前边", "自相矛盾", "徒刑", "良宵", "再付", "随行", "璓", "希尼", "非官方", "射伤", "放低", "十四年", "andr", "鼻涕虫", "说梦话", "外孙女", "斯巴達", "阿亨", "打平", "robinson", "蜇", "吃宵夜", "亲密关系", "点缀", "凹痕", "神功", "nell", "诉", "重归", "五十岁", "切克", "雌鸟", "霧", "perform", "可儿", "chamber", "装做", "密钥", "compared", "轻信", "心仪", "糉", "发射台", "小罗", "须要", "诺亚方舟", "rien", "迪诺", "伸进去", "newmov", "装子弹", "oo", "麗莎", "电脑公司", "闭着", "咲", "国家队", "我意", "嘀嗒", "腳步", "变戏法", "热血沸腾", "喃喃自语", "这区", "不冷", "我父", "vida", "lets", "占上风", "西兰花", "巴登", "溪谷", "米哈伊", "饭盒", "睡觉时间", "伊兹", "害处", "溶", "奉还", "仰赖", "沙夏", "tale", "打听一下", "故土", "debate", "gym", "鞋匠", "ramirez", "arrange", "夜宵", "十三年", "文森佐", "lonnie", "exia", "看场", "丢人现眼", "drama", "malley", "戀人", "合乎", "鱼翅", "许先生", "孫", "绝症", "好戲", "雨宫", "擂", "厚脸皮", "uncomfortable", "戴个", "minor", "要饭", "灵验", "序幕", "贝西", "有纪", "血缘", "镭射", "我称", "成堆", "aboard", "弹匣", "立定", "是屬", "考斯基", "伀", "打过仗", "爱沙尼亚", "磀", "六位", "投向", "振奋人心", "俺们", "万不得已", "美感", "赏赐", "juliette", "耐德", "javi", "解脫", "提亚", "knocking", "雨下", "全没", "worrying", "无异", "佼佼者", "雙方", "翻个", "姻缘", "取名字", "托管", "盛夏", "惑", "ob", "踢腿", "公诸于世", "心安", "吹奏", "唱反调", "高薪", "气场", "開心點", "为时过早", "流沙", "满地找牙", "软软", "一单", "結尾", "五张", "表露", "好過", "一个包", "碰运气", "咖啡杯", "入会", "划破", "怎说", "寻死", "尽量避免", "范儿", "专栏作家", "而入", "围困", "吓唬人", "惊天动地", "火箭炮", "打卡", "碎玻璃", "kimball", "籠", "飚", "撞破", "野心勃勃", "反复无常", "拉弗", "与其说是", "夜幕", "pirates", "老伴", "手写", "archie", "长路", "培養", "权贵", "會變", "随处", "wizard", "edwin", "太保", "porter", "ﺚ", "这么样", "麦奇", "摸清", "没有碰过", "這已", "遥", "针筒", "查明真相", "先过", "师母", "被劫", "塞拉斯", "噠", "wilhelm", "人事部", "苦闷", "难以捉摸", "殉道者", "自小", "观察员", "席尔瓦", "弹出", "实验性", "几场", "霍布森", "邪灵", "遺忘", "三秒钟", "真货", "這顆", "伊拉克人", "汇报情况", "罂粟", "小数目", "insult", "同流合污", "更美", "鴨子", "thirty", "别缠", "贝斯手", "羊角", "桑德罗", "浆", "前線", "外交部长", "萧红", "工業", "兩者", "传回", "花草", "劫车", "坪", "夜猫子", "摔断", "票据", "蒙提", "搅拌机", "房東", "炫风", "嬤", "蛛", "佛力", "reginamoon", "營地", "公仔", "严刑", "枝", "继承者", "極度", "补上", "呜呼", "碪", "光盘", "春虎君", "摊位", "charm", "cara", "tate", "澳大利亚人", "定会", "高卢", "强奸案", "圆滑", "岗哨", "拖下去", "列尼", "内布拉斯加州", "淘气鬼", "兩邊", "家庭聚会", "塞思", "視線", "拴住", "powder", "点餐", "好惹", "没把握", "precisely", "沙希", "开罚单", "健一", "總比", "疲憊", "班吉", "雇人", "课后", "人理", "sinclair", "村莊", "营养不良", "honour", "手腳", "突", "失去平衡", "期末考试", "昏头", "爹爹", "母爱", "臂膀", "liza", "输不起", "会堂", "库房", "惡化", "给面子", "疑問", "莱维", "laroche", "心虚", "漂亮衣服", "第一种", "医护兵", "燒掉", "联队", "大同", "克勒斯", "流派", "两端", "卡佛", "妍", "句句", "胡鬧", "附着", "唱起", "受挫", "別煩", "當天", "揭曉", "轉向", "笢", "拉姆齐", "零星", "之時", "贤俊", "先打", "变心", "二万", "同床", "第一段", "颤动", "老总", "delay", "轟", "profit", "一去不复返了", "球手", "心理咨询", "平面图", "莱茵河", "smooth", "分不出", "謊話", "bureau", "領帶", "变糟", "玛亚", "辣味", "唐伯虎", "年末", "新作", "點事", "惹祸", "坐进", "一万五", "fame", "雷根", "魄力", "小强", "伊莉", "淡忘", "黛娜", "纯度", "assumed", "速速", "financial", "手印", "映", "多少岁", "提炼", "只准", "驾驶座", "flow", "clayton", "cargo", "要點", "大学教授", "英年早逝", "出水", "cheering", "西姆", "飞机票", "死枪", "精妙", "黑幫", "实习医生", "费特", "ramsey", "ol", "字母表", "法罗", "援救", "紧随其后", "活該", "ц", "战船", "特首", "达蒙", "conscience", "第一幕", "你会用", "直立", "牢狱之灾", "經夠", "莎蒂", "乳液", "frodo", "谨记", "财力", "昨天早上", "淘金", "deserves", "享福", "友爱", "总公司", "禁烟", "买药", "分尸", "少数民族", "糖果店", "jill", "停息", "简要", "石榴", "龙泰瑢", "长得帅", "希瓦", "逃税", "转型", "白云", "vas", "近来可好", "娇妻", "alma", "美津子", "whitehall", "torn", "丰田", "dodge", "不同之处", "见外", "避暑", "叫外卖", "检索", "麥琪", "波涛", "超生", "合夥人", "抵押品", "盆", "拉古", "leroy", "elections", "杰路", "hess", "小树", "女高音", "民政", "wrapped", "库姆", "机不可失", "重做", "好羡慕", "卫生部", "尊尼", "刚生", "交界处", "rounds", "拉起", "特地来", "籤", "转生", "shy", "万人迷", "另一人", "私立", "淫乱", "辛勤", "人數", "祭奠", "枪林弹雨", "大圣", "critical", "土豪", "づ", "道间", "好好学", "真嗣", "驶", "kepner", "奥斯卡奖", "隐患", "打呼", "车头", "駕照", "五处", "磐石", "查理斯", "圣地牙哥", "闪闪发亮", "饥肠辘辘", "篮球队", "革职", "海军基地", "一五一十", "气坏", "cable", "太暗", "威卡", "温习", "改宪", "恼人", "巡回赛", "遺產", "捐贈", "忘不掉", "超时", "几楼", "rice", "交响乐团", "静候", "阿部", "跳板", "gott", "奉獻", "渤", "rusty", "戈里", "改編", "natasha", "漂白剂", "肉体上", "竹竿", "仅此一次", "架构", "没趣", "几处", "客服", "一切权利", "水怪", "巴塔", "asa", "自律", "罗达", "影带", "美奈", "人太", "madame", "babakov", "heidi", "四重奏", "近日", "總要", "隐密", "chairman", "冰镇", "顶撞", "會贏", "处理器", "放些", "修罗", "不读", "图形", "女厕所", "铠甲", "成个", "柯比", "海盗船", "墙外", "永垂不朽", "绝无仅有", "五倍", "珠峰", "自学", "与此有关", "bennet", "货仓", "乘火车", "受用", "匹灵", "一勺", "低着头", "缚", "路旁", "大美人", "酿成", "不畏", "投下", "dahl", "汗衫", "万斯", "暫", "巫", "玛利", "心来", "morrison", "垂涎", "木工", "探長", "布萊", "皮拉", "drone", "这球", "别挤", "高刚", "地狱之火", "大扫除", "碰巧是", "滕", "打小报告", "堅信", "徵兆", "博斯", "火车票", "噶", "骗术", "十美元", "文艺", "鮑", "wi", "主教练", "熱", "planets", "黑死病", "配枪", "broadcast", "矿石", "这挺", "李将军", "很久前", "意外事件", "cooking", "那封", "len", "水银", "煽情", "方程", "合而为一", "nails", "叙旧", "卡丽", "磷虾", "杉", "代数", "coco", "黑心", "没教养", "退钱", "米粒", "swore", "内向", "tracks", "wu", "哈瑞特", "別處", "装配", "美羽", "存亡", "签好", "地利", "要约", "保险杠", "隠", "普普通通", "人工智慧", "面膜", "七個", "塾", "studying", "戰勝", "忧心", "著要", "香甜", "黑影", "betray", "蓝迪", "苦涩", "fury", "水道", "信守诺言", "侧门", "idiots", "变态狂", "儸", "孝敬", "halloween", "仅次于", "金格", "鸟巢", "百分之九十", "美航", "grunts", "调调", "順", "套套", "鲭", "电风扇", "礼拜六", "十六年", "病魔", "从政", "能撑", "石子", "目暮", "別生氣", "moscow", "顫", "isaak", "ˉ", "通路", "foolish", "变卖", "迎面", "packed", "胜地", "resist", "toto", "洪兴", "生日会", "化妆师", "立誓", "黎明前", "演艺", "裸男", "一層", "吸盘", "損傷", "斯密", "attached", "緅", "特色菜", "人脸", "terrific", "渔网", "警用", "clara", "老年痴呆症", "mick", "cunt", "推着", "里维斯", "电脑系统", "usb", "点数", "做广告", "搞怪", "儿媳", "周后", "terrified", "悦耳", "备胎", "燃烧弹", "阴魂不散", "摩登", "我關", "沙嘴", "贾许", "萨卡", "omg", "县里", "說給", "掉包", "下学期", "見證", "wicked", "乳腺癌", "没留", "搞来", "六十年", "數人", "打晕", "魏斯", "庆祝会", "當真", "那到", "入内", "帕格", "deaths", "斯曼", "serial", "生事", "罗伯塔", "王尔德", "隔阂", "杜尔", "娘亲", "creating", "招生", "除草", "动脑筋", "iq", "丝黛拉", "国界", "初一", "幫到", "口舌", "快回到", "如其", "发炮", "热忱", "目擊者", "首级", "回屋", "狗肉", "樓上", "浪漫史", "赞美诗", "袍", "文字游戏", "帮办", "褪去", "男人味", "花盆", "精品", "不间断", "图坦", "带上来", "扫地出门", "周密", "小生意", "两清", "松露", "全球化", "republic", "美国士兵", "這簡直", "ages", "两地", "就此打住", "痲", "租下", "黑狗", "段落", "ㄌ", "抓个", "避開", "乳", "充公", "关门大吉", "这步", "几千块", "三部", "開動", "先祖", "downtown", "shadows", "雪碧", "过门", "翻出来", "吓傻", "种族灭绝", "滚滚", "四十万", "执业", "霉运", "雷斯特", "口述", "重視", "错综复杂", "ǒ", "很辣", "卖不出去", "斯伯格", "脚边", "surrounded", "柳树", "寶貴", "吉拉", "羊皮", "钻洞", "用血", "关连", "偷來", "兽性", "塔林", "雄心勃勃", "是夜", "赞叹", "待见", "鼻屎", "集體", "阻礙", "tap", "长点", "三十二", "笑料", "原稿", "玉帝", "有期徒刑", "刚要", "母亲节", "喷水", "袖口", "予", "adaline", "老狗", "了不得", "一条龙", "木桶", "一区", "意願", "尽是", "最後的", "决胜负", "租客", "佐夫", "喝上", "垒", "石神", "lopez", "湖上", "升华", "被抛弃了", "昧", "伏见", "摊子", "指指点点", "determined", "参演", "请系", "合谋", "唆使", "actor", "贝尔格莱德", "素媛", "口头禅", "配乐", "safely", "突发事件", "打输", "协力", "夜神", "喷洒", "盥洗室", "做什", "kassell", "没饭", "胆识", "只身", "世間", "施以", "哀", "穆雷", "宗介", "懷亞特", "达纳", "手环", "店老板", "歷過", "肇事者", "要事", "种族隔离", "讨债", "合在一起", "青峰", "鲜肉", "贴切", "欲求", "大为", "走光", "巴卡", "servants", "劣质", "上镜", "slightly", "默哀", "還敢", "火中", "太逊", "红星", "趣事", "没日没夜", "穞", "谈婚论嫁", "緻", "soviet", "打道回府", "茱儿", "五尺", "皆知", "不烦", "由不得你", "mj", "稀释", "端口", "休士顿", "卡門", "远远地", "每夜", "生物体", "除夕夜", "幸子", "轿", "颓", "德堡", "行程表", "沾到", "八次", "麦田", "体液", "倒底", "越過", "我份", "灰原", "何度", "寐", "妮琪", "能住", "朱利叶", "梅瑟", "太安静", "列娃", "smiling", "实物", "杆菌", "乖巧", "臭脸", "退回来", "百科全书", "豪车", "野田", "恩施", "罗德里格斯", "車牌", "兩樣", "娱乐圈", "testify", "swimming", "相扑", "小八", "化学武器", "meters", "直呼", "格兰德", "internal", "挑明", "空降师", "姨婆", "脖", "对视", "卡莱", "另当别论", "多長", "行装", "巴巴拉", "溜进来", "格莱美奖", "出任", "吐痰", "舉止", "选拔赛", "丢下去", "保育", "抓活", "beef", "飞鱼", "离场", "簽了", "化工", "离子", "沒說", "一千次", "名校", "下肚", "优等生", "colleen", "师团", "停业", "沃尔姆", "何先生", "巴金", "共同之处", "跛子", "diego", "多时", "半夜三更", "pipe", "毁于一旦", "翻过去", "钮弧", "陈家", "木炭", "领导层", "hopes", "朋子", "べ", "蒙大拿州", "capture", "第一代", "梅赛德斯", "渾身", "空运", "赫德森", "比目鱼", "入迷", "wiki", "insist", "没胆", "楷", "必勝", "會成", "一经", "lookin", "挺进", "去留", "一覺", "庞然大物", "坎特伯雷", "未接", "奶酥", "能载", "好味", "鸡毛蒜皮", "训斥", "吼吼", "拉辛", "饑", "阿香", "戰役", "练球", "打退堂鼓", "杰奎琳", "福克纳", "冷天", "钾", "supreme", "尊嚴", "巳", "骸骨", "asses", "卢先生", "發送", "后藤", "底裤", "漢克", "更想", "huber", "劝服", "冒险家", "米克斯", "打分", "难逃", "伊比", "编制", "芬兰人", "善行", "境遇", "万宝", "大灰狼", "毁容", "不笑", "相交", "tragedy", "匠", "阿斯兰", "颁奖典礼", "执教", "這支", "稍安", "录音室", "苦瓜", "趕出", "真臭", "天要", "matthews", "多數", "尘土飞扬", "秏", "顺畅", "奔放", "架势", "能問", "民权", "瑞克斯", "南海", "shield", "离心机", "johnnie", "难为", "调查科", "寓意", "心神不宁", "reporting", "wissen", "看会", "朗达", "lad", "多德", "一處", "晚报", "log", "motive", "名利", "韵律", "卑贱", "弗里德", "世界纪录", "发痒", "精彩表演", "管区", "新发型", "法克", "伊萨", "口吻", "nos", "electric", "误杀", "靠拢", "莫尼卡", "列姆", "一国", "精靈", "无伤大雅", "咿", "看头", "他读", "卡号", "所到之处", "缝针", "电刑", "臣服", "日圆", "漫无目的", "贊同", "corporate", "暴走", "秘书官", "博取", "虚度", "吱", "糾纏", "弗蘭", "赴死", "剽窃", "島上", "大领", "小瞧", "尼尼", "留斯", "ministers", "靓仔", "势利", "tunnel", "灸", "大眼", "一百五十", "戰機", "正上方", "高唱", "总爱", "地用", "石化", "玩兒", "rey", "地质学家", "ぜ", "重犯", "海特", "proceed", "袒护", "verne", "粗口", "午饭时间", "drawer", "小球", "冰盖", "磁", "飛過", "见效", "贯彻", "returns", "机尾", "浓汤", "一视同仁", "拳打", "可退", "斋", "布伦纳", "ins", "肯德基", "運命", "咽下去", "我越", "出纳", "声带", "擤", "四级", "阿卜杜拉", "畅饮", "袁", "斑斑", "举例", "毒瘤", "进货", "lockwood", "好榜样", "卖房子", "经济舱", "材质", "症狀", "帅小伙", "养父母", "洗漱", "费舍", "瘦弱", "宽度", "闯红灯", "賄賂", "豚鼠", "高见", "专程来", "驶离", "黄河", "牛头", "搞成", "五亿", "鲤", "鼠标", "半场", "til", "布赖", "enforcement", "美香", "失衡", "又坏了", "bam", "静冈", "为重", "驶过", "第二代", "緼", "请个", "拸", "载人", "vale", "师叔", "sports", "reilly", "忍法", "genau", "加长", "画室", "粗心大意", "sample", "挑選", "浮云", "設計師", "打滑", "聆讯", "還把", "皮克", "重拍", "海琳", "年迈", "恼怒", "灌肠", "苔藓", "worries", "瞎眼", "阿仁", "能手", "惧", "那行", "meister", "龟儿子", "无止尽", "小题大作", "homeland", "天灾", "洁白", "sharma", "打獵", "hawkins", "veda", "奎斯", "光看", "申辩", "敲碎", "称不上", "换洗", "两难", "答错", "搬离", "维纳", "犸", "结果显示", "整装待发", "加班费", "一开", "美言", "那塊", "契卡", "wirt", "极强", "标明", "忧郁症", "一百多", "淹", "主办", "luann", "楷模", "氏族", "溜出来", "理疗", "ranger", "密西西比州", "一絲", "entry", "百万分之一", "shooter", "亚曼", "electricity", "xbox", "creepy", "榆树", "接线", "俄文", "criminals", "先开", "vulnerable", "根部", "听歌", "退庭", "懺悔", "詹米", "tuesday", "捂", "橇", "場面", "三百块", "一英寸", "布隆", "巴托", "防毒面具", "咬痕", "本拉登", "洗不掉", "entrance", "人开", "能替", "雨滴", "施洗", "admiral", "年轻貌美", "风间", "涉入", "三票", "盤子", "櫈", "區的", "北风", "努力争取", "悵", "一关", "一壶", "tuco", "第二种", "rumors", "fears", "称王", "篴", "整点", "循環", "royce", "箍", "更強", "還算", "傻傻", "茶茶", "募集", "繋", "纽伦堡", "塞子", "神学院", "不談", "本家", "头套", "圣路易", "好玩儿", "杜拉", "手背", "利普", "斗胆", "矛头", "pace", "策劃", "坦承", "糞", "rosemary", "缝线", "肩并肩", "peg", "菲爾", "歡", "擅离职守", "弄开", "双双", "盼望着", "挽", "艺伎", "不屑一顾", "三英里", "嘻嘻", "機械", "vie", "降职", "红海", "ㄘ", "别要", "身形", "真以", "大功", "伝", "tis", "巴勒斯坦人", "效勞", "阿班", "呱呱", "摔伤", "叶片", "惡魔", "露骨", "过半", "看扁", "挂线", "骑单车", "attractive", "zachary", "令人信服", "boov", "收银机", "奥普拉", "剧名", "妖孽", "长胡子", "批萨", "布拉斯", "挺棒", "剛說", "老张", "亚吉", "过学", "法比奥", "利昂", "叛贼", "afterwards", "天理", "某處", "頭來", "暖炉", "走私犯", "牛津大学", "嚇著", "挑出来", "jer", "posted", "转来转去", "蓝礼", "大显身手", "辛德勒", "ollie", "苏安", "壞人", "麦考利", "全名是", "小调", "grove", "不凡", "豬肉", "无止境", "左拳", "正对", "暗夜", "关东", "魔兽", "羽村", "tanya", "这卷", "代代相传", "无穷无尽", "凿", "ups", "荷包蛋", "通讯设备", "没本事", "纵情", "故事书", "瓦伦丁", "嘻哈", "名義", "兰德斯", "抵触", "狄恩", "咸鱼", "掷骰子", "籹", "当妈", "厚度", "成就感", "goat", "alibi", "调遣", "天方夜谭", "分清", "meetings", "shown", "小淘气", "帕西", "厭惡", "rene", "燃", "管理人员", "worthy", "护目镜", "卡丽熙", "侍", "数着", "dani", "华盛顿州", "給錢", "无惧", "用脚", "宇航", "泽维尔", "自问", "一户", "莱顿", "kensi", "写写", "千枝", "優先", "车房", "梆", "掩飾", "记事本", "花蜜", "bomber", "上铺", "裝飾", "耴", "诗篇", "西达", "不育", "戏里", "穖", "美呆", "急件", "籩", "进宫", "已决", "艾菲尔铁塔", "coward", "软化", "云妮", "喷出来", "每块", "神游", "未经许可", "blade", "双鞋", "静子", "熱鬧", "晨曦", "麻麻", "买杯", "令郎", "佔領", "latin", "卡夫卡", "凤", "临头", "負責任", "拉德曼", "马戏", "sanjay", "抚恤金", "潛", "車庫", "頑固", "勢力", "不難", "民意调查", "北美洲", "丹蒂", "lacey", "秘籍", "fuller", "非同小可", "授粉", "psych", "曲速", "特派员", "apply", "二手车", "磴", "羊排", "打掩护", "转行", "目不转睛", "雅林", "小夫", "化妆间", "一千美元", "小动作", "杰姆", "beers", "政委", "無恥", "卡登", "那话", "记好", "佳丽", "两千五百", "热腾腾", "狼吞虎咽", "滥杀无辜", "钞", "拉出去", "當是", "ﾆ", "布拉克", "很怕", "天长地久", "莫拉莱", "award", "設置", "阿吉", "fund", "smarter", "人民币", "轻度", "高烧", "teams", "不作", "发胶", "摇摇欲坠", "鸣上", "地是", "青青", "按揭", "鐵路", "石像", "托米", "落成", "痛宰", "代碼", "恀", "眨眼睛", "battery", "仅仅只是", "尼克森", "并购", "艾蜜", "演算", "详谈", "聚在", "难产", "rust", "木制", "缝制", "葡萄糖", "菊川", "海马", "特餐", "琁", "军力", "飞溅", "sbk", "杂念", "坐著", "闹心", "tattoos", "马玩", "四十分钟", "他学", "jensen", "independent", "他長", "leena", "汇集", "bare", "云朵", "人得", "mole", "三瓶", "馮", "麦哲伦", "alley", "附体", "刻板", "behave", "一万五千", "维黛", "英华", "越糟", "小城镇", "极乐世界", "我举", "固然", "馨", "諷刺", "那張", "晕车", "索里", "cersei", "statue", "包住", "宠儿", "不辞而别", "总好", "交叉口", "普及", "出示证件", "城里人", "有紀", "输得", "阿武", "colleagues", "candice", "看不見", "凯伊", "大溪地", "上装", "二號", "纳什维尔", "真令", "专攻", "圍巾", "接得", "窟窿", "阿龍", "要收", "唠唠叨叨", "軟弱", "艾德蒙", "传人", "不大清楚", "红豆", "italian", "八戒", "焕发", "飘浮", "庇", "餅", "移位", "爹妈", "cruise", "湿度", "印度尼西亚", "綁架", "constantly", "河道", "中环", "com", "斯金纳", "好脏", "飄", "积分", "舅妈", "运球", "适度", "principle", "discussion", "翻修", "金凯德", "antonia", "之內", "飞盘", "切勿", "种群", "漆黑一片", "三起", "女童", "正以", "伊朗人", "一问", "摊开", "海岸边", "称其为", "早飯", "嚒", "其间", "大限", "禮", "次次", "飞驰", "兢", "女强人", "口风", "延", "载入", "classified", "水深火热", "pigs", "patience", "缺點", "小滴", "忍气吞声", "见报", "应激", "华力", "遮盖", "人身安全", "六七", "review", "一組", "击碎", "外泄", "那颗星", "審訊", "攻击者", "zeit", "杜兰夫科", "归案", "的哥", "脏手", "职工", "盖起来", "soil", "形容词", "缆车", "hayley", "kingdoms", "肯不肯", "cocaine", "eleven", "莎曼", "师爷", "籜", "拓", "切尼", "托馬斯", "疼得", "第二组", "囤积", "格蕾西", "clyde", "享年", "刀枪不入", "比死", "bryant", "阴森", "挣来", "称颂", "找點", "坚", "灵灵", "喜乐", "逃得", "formula", "匆匆忙忙", "sealed", "有何意义", "会晤", "取得成功", "起搏器", "亲事", "雾气", "还少", "lockhartgardner", "五大", "汇", "神話", "钢板", "stab", "反擊", "内政", "农家", "没枪", "recorded", "遗传学", "barrett", "群交", "吹响", "遊", "肕", "传递信息", "再下", "茎", "谷風", "鎔", "清纯", "锻造", "甘迺迪", "叫好", "attitude", "白吃", "boot", "導師", "扬帆", "先喝", "玩枪", "castro", "七年级", "脸面", "ge", "hallo", "seize", "forth", "事成之后", "捐出", "触角", "怯场", "落下来", "疏通", "暗礁", "snap", "seats", "得定", "能想", "cannon", "芭蕾舞团", "警务处", "要當", "卷子", "馄饨", "直言", "排行", "infected", "卡尔顿", "一株", "凱妮絲", "变性人", "花式", "clearance", "蔓延到", "巨款", "见面会", "稱钩", "死敌", "帐簿", "sokidon", "dates", "忍受着", "chi", "光凭", "painful", "血統", "whistle", "石器时代", "匹马", "高人", "二维码", "怨气", "粗圆", "雄鹿", "愛河", "generous", "畅所欲言", "印着", "事好", "汉人", "绒毛", "wheeler", "夹击", "租房子", "有根", "變身", "不帶", "flip", "stream", "高獨美", "俊殖", "泰温", "可多", "鬼主意", "光彩照人", "因子", "罷工", "虎视眈眈", "地标", "混日子", "拥护者", "拼字游戏", "掉入", "往好", "板上", "黑尔", "units", "妖女", "编舞", "谜底", "equal", "太黑", "爱哭", "文革", "万千", "满街", "武艺", "一个班", "阿牛", "无人驾驶", "法兰西斯", "厮混", "這本", "马克思主义", "安多", "cayman", "將是", "泰拳", "车速", "阿鬼", "拉布拉多", "瓣產", "除以", "有带", "杜丘", "相依", "妮维雅", "壹", "homework", "明媚", "三天三夜", "cosl", "透彻", "正义感", "巴结", "縊", "解毒", "很逊", "倒水", "逗号", "静观其变", "家喻户晓", "缓冲", "激增", "派个", "斩断", "百倍", "生人", "ihm", "realise", "密西根", "美雪", "工业革命", "缎带", "樹林", "belly", "buildings", "卵巢", "ジ", "张图", "巴茲爾", "幸免于难", "策反", "全怪", "什锦", "燒傷", "正当理由", "飛到", "老狐狸", "bren", "psychic", "缝纫机", "朴兴秀", "昌", "worker", "防护服", "wives", "无异于", "不醒", "发胖", "塗", "頭發", "constant", "climate", "几百万年", "禔", "wisdom", "流鼻涕", "臭美", "operating", "互利", "允熙", "谢尔", "confession", "睡过去", "索萨", "漏斗", "反间谍", "水塔", "出些", "图谋", "假死", "劝阻", "看書", "施瓦辛格", "迪斯尼乐园", "recover", "administration", "会馆", "玛多", "曼波", "抖动", "京", "奶瓶", "satan", "妮斯", "hodgins", "几本", "不活", "睡午觉", "turtle", "贵妇", "这匹", "老年痴呆", "威灵顿", "迎刃而解", "痛失", "翻版", "命悬", "纳斯", "手要", "德格", "寄來", "急流", "消瘦", "mighty", "干什麼", "拒之门外", "恭喜发财", "拉进来", "词来", "散架", "bah", "圣巴巴拉", "国情", "硬要", "几页", "你好坏", "惡作劇", "喜马拉雅山", "霍尔特", "奮鬥", "上色", "心理变态", "談到", "调离", "資本", "glorious", "寫信", "得用", "解不开", "黏糊糊", "而來", "塔尔博特", "兩件", "欧阳", "menschen", "抱著", "heroes", "藏品", "烤面包机", "订阅", "横渡", "委派", "violet", "呈现出", "人之常情", "油管", "丑女", "不出所料", "diner", "互相理解", "来生", "悬疑", "舒心", "主刀", "swallow", "坐垫", "listened", "阿雯", "destruction", "拼出", "latest", "carrington", "杀鸡儆猴", "灯火", "冲刷", "康伦", "控球", "spec", "花岗岩", "回溯", "伸到", "机灵鬼", "扭扭", "里诺", "sylvester", "edison", "dragged", "狗东西", "那怕", "無名", "工场", "动工", "假肢", "同學們", "格罗夫", "隐", "一劫", "下雨天", "朗斯", "不为过", "蜘殊", "booze", "那书", "牵强", "得太早", "出動", "船舰", "美里", "窝里", "阿纳金", "那筆", "候命", "喂给", "bieber", "執", "必死", "成人礼", "兼得", "深表歉意", "无脑", "犯罪者", "救起", "面包圈", "晦气", "映射", "聊些", "想見", "圍", "鸡尾酒会", "养分", "一刀两断", "坐牛", "我想給", "cathia", "信給", "艦飾", "同心", "半句", "回見", "跳動", "挤出来", "音箱", "鲜", "輕點", "提款", "取名为", "前哨", "親親", "凋零", "就緒", "轻描淡写", "sigrid", "不同凡响", "madness", "拉贝", "入骨", "议论纷纷", "潜行", "merely", "游历", "舒畅", "膜拜", "写入", "仁川", "复述", "mozzie", "金斯利", "朱庇特", "迪亚兹", "theirs", "gogol", "选角", "嚇我", "现场报道", "精彩绝伦", "角马", "獎", "羨慕", "蓟", "喝口水", "门厅", "发现者", "逼死", "小蜜蜂", "pound", "地通", "意谓", "别找我", "夸大其词", "电信", "足矣", "gin", "炮台", "假正经", "特么", "查房", "白眼", "擔保", "蒙面", "轻伤", "國外", "將被", "咂", "无言", "让位", "军师", "令人振奋", "throughout", "別急", "上桌", "绝不允许", "discovery", "里格", "crossing", "公事公办", "gwen", "穩住", "一室", "舞蹈演员", "安安", "快捷", "找零", "险些", "weed", "大个", "vaughn", "名譽", "五到", "那下", "赫曼", "七點", "钻探", "三振", "巴隆", "档子", "wealth", "亲耳", "新闻报导", "喊道", "弄弄", "时能", "出资", "闹腾", "万一出", "purse", "玩遊戲", "sweep", "外有", "跟得上", "我想学", "相識", "肆无忌惮", "五万元", "arts", "管线", "单间", "精神病学", "别离", "academy", "新建", "光景", "改天再来", "根葱", "輸給", "砒霜", "出产", "艾莉儿", "情有可原", "登堡", "飛翔", "newspaper", "相恋", "监护室", "杰茜卡", "浮动", "开局", "traci", "抚平", "定格", "厂商", "斯科", "本体", "六万", "usa", "沒有關", "按鈕", "傳給", "大一", "一刻钟", "别谢", "影集", "feelin", "凶险", "滋养", "说词", "硬化", "ﾖ", "作坊", "妮克", "呆呆", "要作", "断送", "設施", "书页", "撬棍", "特森", "原名", "總能", "atcu", "醱", "放血", "这信", "瓦尼亚", "降级", "无花果", "鹌鹑", "冷饮", "trina", "阿格拉", "憋着", "地看", "坚持不懈", "擅于", "纸箱", "吓呆了", "walkers", "急忙", "梦幻岛", "whales", "sm", "过客", "大展", "筋骨", "维托", "背著", "stall", "lap", "父辈", "艾克曼", "能见度", "文化大革命", "此项", "爱德蒙", "沙比", "畓", "我妈会", "操縱", "小千", "給點", "拉客", "camille", "酷热", "何處", "萨米尔", "找水", "gentle", "获得胜利", "前奏", "空格", "虎王", "recording", "瑞瑟", "acid", "新界", "王权", "籈", "还会来", "最令", "偿", "首批", "坛", "不明飞行物", "找碴", "帕卢姆", "玵", "苯", "光波", "男厕所", "significant", "咖啡豆", "慕斯", "cyril", "定位系统", "wiped", "换种", "好事儿", "woodhouse", "钮癬", "刪除", "食人鱼", "basis", "理央", "純", "低空", "神户", "胖兔", "情圣", "上班时间", "生怕", "沃夫", "任何借口", "浆糊", "錯事", "该用", "战局", "六點", "管辖权", "farrell", "家庭暴力", "招认", "有了钱", "见好就收", "capitol", "自然法则", "施特劳斯", "入场券", "确凿证据", "懸崖", "不救", "格尔达", "戒心", "拆下来", "靜靜", "三强", "人血", "vivian", "任教", "抢先一步", "能付", "镜像", "concerns", "wednesday", "britain", "br", "珆", "owns", "亞諾", "公开场合", "cowboy", "達到", "casino", "满舵", "透透", "叩", "plants", "灵通", "老孙", "城户", "拔河", "dumped", "intended", "现正", "抽打", "休整", "贡", "残存", "照明弹", "乾坤", "ant", "晚會", "改变现状", "森哥", "吹风", "纬度", "不乖", "献唱", "省心", "一码事", "排泄", "矿业", "幫上", "bl", "男女朋友", "鄙人", "本質", "讲道", "失禮", "胸肌", "团结一心", "湖底", "两碗", "脏死", "布蘭", "川岛", "michel", "罗勃特", "狗食", "因涉嫌", "貨", "小索", "浩司", "sands", "忽", "哈米", "拿不出", "拦着", "不倒", "不說", "下着雨", "暴发户", "这一下", "scavo", "受创", "坐骑", "绝命", "就寝", "牛油", "挼", "友军", "一八", "旅社", "一跳", "横越", "牙仙", "专为", "谷地", "体育老师", "創", "腔调", "營業", "奥马", "爱妻", "凯尔特人", "terror", "高深", "马丽雅", "魔族", "亚姆", "波霸", "及时行乐", "商社", "安乐", "batiatus", "aster", "小生", "lean", "平底锅", "旱", "能算", "臂弯", "mueller", "和威尔", "threatening", "heels", "过来人", "帕维尔", "七大", "独白", "音樂會", "监工", "沃尔什", "ties", "昭和", "太丑", "千名", "delfino", "沃顿", "腳下", "盛事", "春秋", "sonya", "飛船", "遭报应", "乡民", "美甲", "电磁波", "借此机会", "松口", "布哥", "迪肯", "职权", "妥妥", "新品", "多多少少", "漱口", "贝比", "帶子", "蒙罗", "车夫", "辛漢", "核爆", "生蛋", "sneak", "captured", "马里兰", "thirsty", "一刹那", "有部", "杀意", "匪夷所思", "dar", "harker", "eyed", "福瑞", "nigga", "塑像", "小酒", "问道", "倍受", "同期", "挂到", "宽宏大量", "男装", "愿神", "耳聋", "零售", "metres", "稀巴烂", "战无不胜", "不合情理", "找间", "鍊", "丹东", "迪兰", "想当年", "跑跑", "榔头", "通讯器", "喷气机", "违法行为", "夫特", "虚拟世界", "滾出", "西施", "抽屜", "挠痒痒", "市面上", "老公公", "女同学", "飘扬", "相愛", "relief", "客套", "假使", "邓小平", "马走", "撫養", "螺丝刀", "幸", "尤拉", "玛尔尼", "臭气", "大法", "完全恢复", "卡瓦", "catching", "镣铐", "海螺", "腦部", "沙地", "人脉", "火坑", "网球场", "不失", "台面", "母语", "总线", "很爛", "料子", "體力", "舞姿", "猪油", "yelling", "中村", "小蛋", "祖传", "感情生活", "修过", "壁球", "静坐", "觀賞", "奥丁", "提示音", "aldous", "運轉", "焦头烂额", "螡", "稀薄", "癟", "死去活来", "天籁", "邃", "黑漆漆", "不知好歹", "偏光", "首页", "擴散", "家園", "诺娜", "同意书", "親生", "ji", "下坠", "铁锹", "修炼", "个州", "kai", "翻過", "受骗", "竞选活动", "很榮幸", "desmond", "优迪", "斯威夫特", "密西西比河", "明尼阿波利斯", "宁子", "高喊", "抛售", "卡斯卡", "翩翩起舞", "大爺", "巾", "苦海", "公顷", "内讧", "水里去", "吓住", "问一问", "面颊", "达罗", "尘埃落定", "柏纳", "怪味", "搜刮", "純粹", "师长", "红花", "房价", "liu", "appearance", "勤务", "本年度", "笔下", "lynn", "超度", "上千人", "winnie", "尼昂", "紧急会议", "遇难者", "運用", "尤因", "音速", "启蒙", "写日记", "海報", "门牙", "实质性", "guerrero", "愛爾蘭", "龟悔", "賦予", "大杯", "扔下来", "凉鞋", "b型", "生鱼片", "李博士", "检票", "nana", "好端端", "visual", "内维尔", "原委", "跑动", "簽證", "割草", "goose", "會永遠", "痢疾", "芛", "榜首", "全权负责", "自我意识", "年时", "肺病", "多罗", "套近乎", "brooks", "租借", "有鱼", "布下", "規模", "体征", "德州人", "burnt", "parent", "横梁", "穫", "雄狮", "hacked", "慈善事业", "经手", "攸关", "蓄势待发", "强纳森", "電線", "爱尔莎", "老处女", "米迦勒", "拔剑", "沙特阿拉伯", "安特卫普", "若要", "納森", "克拉夫", "桅杆", "化學", "shed", "德鲁伊", "膛", "无益", "觀看", "august", "分界线", "诸", "误认为", "講什麼", "誰給", "出货", "injured", "況且", "罗索", "人见人爱", "其实不然", "李静", "favourite", "逮个", "dug", "心境", "隐私权", "民心", "天下太平", "青春痘", "我争", "很严", "不弃", "没醒", "twisted", "海景", "襟翼", "luper", "進監獄", "操纵杆", "回娘家", "三十个", "蓬松", "門關", "骑着马", "豢", "庞培", "痛处", "脑损伤", "变弱", "塔塔", "poisoned", "福克", "格拉斯哥", "服装店", "moses", "考古学", "九州", "blonde", "那鬼", "难逃一死", "尖尖", "impression", "索拉诺", "考慮過", "点上", "叛", "栖身", "showtime", "satisfied", "从头来", "黑衣人", "柏林墙", "企划部", "obsessed", "司法官", "thieves", "beings", "這歌", "conny", "谋反", "三样", "爱会", "別以", "杀人罪", "axe", "穀", "演艺圈", "website", "看多", "我存", "三到", "梅洛", "卧床", "雄基", "信标", "浅滩", "visited", "弄懂", "交还给", "要装", "未试过", "开拓者", "西塔", "音樂劇", "大岛", "进入状态", "面相", "specifically", "请说出", "藍領", "却克", "机甲", "没教过", "耳塞", "利维", "symbol", "出岔子", "偷出来", "男童", "保证金", "代名词", "隨身", "如出一辙", "褓", "女鬼", "仁河", "塞克", "這裡面", "决一死战", "托勒密", "归类", "下半生", "貪婪", "冥王星", "intense", "坏男孩", "开曼群岛", "搜索队", "十七年", "人一", "从技术上", "确有", "亏损", "砂糖", "几块钱", "北极圈", "先想", "展馆", "独家新闻", "溺爱", "有本", "内乱", "神经过敏", "賽車", "應當", "劳动节", "毕肖", "著称", "因特网", "engagement", "快去快回", "悲情", "快爬", "先驱报", "部手机", "地活", "海因斯", "操练", "计策", "数百万年", "muslim", "那怎么行", "揣测", "留胡子", "脑波", "求偶", "阿姐", "状元", "自摸", "potato", "恩斯特", "多问", "piney", "粘液", "scan", "债主", "天下无敌", "这店", "compton", "何谓", "西克", "突尼斯", "瞓", "留存", "judges", "一剑", "再念", "cosmic", "入学考试", "制动", "edith", "kindness", "箴言", "住家", "投到", "運動員", "张力", "jokes", "活兒", "退去", "知否", "杜撰", "電報", "一点半", "进行曲", "有所准备", "装病", "罗伯托", "弹跳", "由谁来", "蛀牙", "plastic", "坊", "静养", "韦弗", "男男女女", "豺狼", "问及", "遞", "养父", "tide", "逊毙", "总监制", "增長", "缪斯", "接听电话", "人體", "红玫瑰", "御林", "诱惑力", "黛丝", "贝思", "后脑", "铁卫", "守灵", "音节", "家居", "杜兰", "性伴侣", "没进", "有样", "伊莎貝爾", "宽限", "常态", "涉案", "示好", "风琴", "murdock", "拿错", "用个", "moody", "floyd", "decima", "他够", "汞", "painted", "碰巧在", "坦白讲", "性器官", "skype", "反战", "lands", "大红", "bello", "莱森", "射出来", "巴克莱", "很生", "共党", "吐血", "重物", "大小便", "雷劈", "哈伊", "夏安", "放送", "滔滔不绝", "庞贝", "車來", "米克尔", "週日", "见见面", "加利利", "特人", "阿扎", "獎金", "拉姆斯", "拆毁", "财政部长", "keating", "检查官", "渡口", "弗伦奇", "临阵脱逃", "没学过", "realm", "人行", "轻蔑", "康罗伊", "放大镜", "懊恼", "盟", "百吉饼", "海商", "神速", "之泉", "引出来", "取款机", "armor", "记忆犹新", "保母", "田园", "粆", "翻校", "testing", "清高", "珊珊", "教条", "甜味", "lit", "廊", "别来无恙", "朸", "tradition", "missiles", "咽下", "拉帕", "威奇", "软管", "這幾個", "近年来", "manny", "戒备森严", "幹過", "點心", "贾伯利", "湘瑩", "情夫", "娇娃", "最難", "公家", "阿尔梅", "理查森", "瑙", "阿基", "分文", "紅酒", "闪失", "报信", "累不累", "除此以外", "威斯康星州", "原味", "剖腹产", "解围", "淚水", "佛羅里", "answering", "应答", "永无", "十里", "直译", "management", "卢浮宫", "miriam", "乱成一团", "枙", "闹别扭", "真本事", "彼得堡", "河川", "闪耀着", "挡箭牌", "订位", "sung", "破费", "前到", "偏心", "维克斯", "whip", "恪守", "打压", "溃疡", "弄回", "狡", "mp", "二把手", "弦乐", "眦", "開到", "como", "太臭", "阿当", "wooley", "粗人", "开办", "继女", "玲", "深思", "炮友", "泰姬陵", "担负", "塞勒", "随波逐流", "tastes", "刺骨", "sets", "银座", "麦蒂", "夹心", "customer", "無數", "正浩", "倒挂", "音乐声", "sings", "拂晓", "唱出来", "好容易", "苟活", "highness", "几千个", "小团体", "研熙", "两道", "lorelei", "凡间", "五只", "accepted", "終止", "胖胖的", "爱将", "不正经", "raising", "frightened", "無意", "正因", "试图用", "狮", "advanced", "可想而知", "淋雨", "并排", "吨重", "小女子", "狄克", "hdc", "漠视", "换台", "定向", "才干", "倒杯茶", "纯情", "burden", "hostage", "undercover", "乱流", "ego", "liquor", "虚空", "fights", "无产阶级", "这路", "感染力", "窽", "人静", "叢林", "人頭", "云云", "監禁", "正说", "点去", "罪状", "熟食店", "化为乌有", "ram", "opposition", "多血", "os", "tools", "福雷斯", "姨媽", "suggested", "活性", "音乐盒", "斐", "grid", "五點", "迈可", "门德斯", "很沉", "這真", "厚重", "去度", "茧子", "脏活", "suggesting", "description", "tries", "好强", "经济危机", "daft", "球星", "篶", "metro", "其餘", "侠盗", "簽約", "本舰", "政治犯", "行行行", "明人", "原田", "皮大衣", "可看", "我選", "cartwright", "tune", "急转弯", "枫树", "上級", "地契", "advise", "生儿育女", "烘", "登机口", "跑题", "药厂", "passenger", "discover", "留院", "bald", "露宿", "能教", "多心", "补补", "主治医生", "凭直觉", "訊息", "个人资料", "anders", "各個", "坐直", "毒杀", "长途旅行", "故鄉", "习性", "knox", "一去不回", "包圍", "nearby", "问心无愧", "叔公", "剃光", "北冰洋", "不堪回首", "冲凉", "偿命", "消失掉", "全心", "悖论", "消音器", "越来越快", "films", "办过", "日月", "提問", "依賴", "维提", "粒粒", "公車", "rand", "阴暗面", "牙线", "通货膨胀", "两套", "坐电梯", "我必", "它动", "找件", "cid", "鼠疫", "养着", "帕蕊", "grayer", "活物", "paolo", "dwight", "剛來", "男演员", "maniac", "典当", "蒂凡尼", "第四天", "征程", "挫伤", "丟在", "紧身裤", "十五个", "麦肯锡", "松软", "繁重", "小俊", "悬案", "人问", "dustin", "利比", "嫄", "一肚子", "斯特罗", "assuming", "冀", "收押", "measure", "睜開", "二度", "小名", "吉赛尔", "知错", "岬", "德维尔", "第一颗", "只想去", "自求多福", "背地里", "关口", "弗朗丝", "上半身", "branch", "说谎者", "伊沙", "兩張", "carbon", "磗", "超声波", "斯顿", "阿妹", "辞典", "蒙骗", "时间段", "过低", "卢森堡", "各樣", "有路", "首歌曲", "阿布拉", "责难", "茶会", "臭钱", "木棉", "守望者", "诚", "滴血", "skinny", "大宝", "停掉", "老人院", "promotion", "理赔", "猛料", "一雙", "theodore", "tes", "阿隆索", "rayvon", "七人", "抗战", "狂歡", "一盏灯", "毁灭者", "笨重", "内核", "我非", "澎湃", "一层楼", "佴", "挽留", "别争", "thornhill", "所向无敌", "城邦", "白光", "艾纳", "outer", "陈太太", "短语", "坐视不理", "purple", "樣本", "子公司", "cain", "月初", "表上", "吊床", "连篇", "大官", "总计", "買個", "连上", "左拐", "blomfeld", "大不列颠", "五侠", "differently", "小卓", "联网", "赫尔穆特", "coup", "同班同学", "ceremony", "目擊", "visiting", "起爆", "波登", "邻国", "entertainment", "美林", "舒適", "浓咖啡", "三头", "鸟蛋", "赶不及", "這身", "安生", "阻隔", "编辑部", "双向", "四散", "明知故问", "此理", "erlich", "所得税", "dope", "十一个", "朝阳", "镶嵌", "新欢", "船夫", "纳尼亚", "鸡舍", "夫曼", "員警", "满屋子", "林小姐", "拉森", "私酒", "作客", "老鹰队", "連環", "掉队", "撕下", "想生", "我静", "升降", "代课老师", "雖說", "aids", "马哈", "亏了", "吃香", "不孝", "布偶", "饕餮", "別裝", "英磅", "稠密", "准是", "军法", "不高興", "埋头", "自满", "天庭", "我晚", "令人感动", "门关", "顺便来", "久久", "西班牙文", "亿万", "卡迈", "刺探", "鮑爾", "ｂ", "砍倒", "科利", "噎住", "多元", "反叛军", "心平气和", "败露", "蒂瑪", "虛弱", "小国", "参孙", "rhythm", "顺势", "房裡", "我太忙", "轻便", "吉勒", "業", "勒住", "捡回", "乐师", "稬", "昂斯", "叫辆", "accurate", "effective", "這絕", "訴訟", "擅", "取決", "新闻网", "多变", "王老爷", "写文章", "静态", "wirklich", "swift", "museum", "跨国", "马丁内斯", "sorts", "蓋茲比", "spill", "反对派", "譬如说", "registered", "上辈子", "嗓门", "splendid", "blanket", "用电", "背信弃义", "太假", "賜予", "tee", "多得很", "hagan", "西莉", "排长", "forms", "特训", "恩恩", "装货", "phresh", "冊", "一輪", "阿齐", "颈动脉", "传授给", "八點", "做鬼", "哪邊", "caffrey", "planes", "鲔", "iet", "珍品", "数值", "夕", "ㄒ", "后半生", "哚", "调配", "微乎其微", "娼妇", "granted", "长短", "腐敗", "面色", "马球", "fl", "揺", "撒手", "死亡威胁", "arrangement", "动漫", "履行职责", "快步", "鲍姆", "摄制", "人送", "朵玫瑰", "anita", "herd", "交汇", "poetry", "惡夢", "饿着肚子", "sober", "小心眼", "這很好", "推測", "简爱", "donnelly", "诚然", "辨认出", "第一辆", "皇子", "反对者", "有数", "stacie", "中华", "francois", "迅猛", "要读", "糾結", "璐", "封口", "不孕", "光屁股", "吝啬鬼", "十點", "斯普林", "跳過", "犯錯", "然後去", "worm", "数位", "结婚的人", "阿尔贝托", "阴沟", "核战", "艾欧", "中立区", "economy", "可愛", "特索", "领了", "死到", "成事", "大醉", "教子", "显出", "墙里", "睝", "燒", "泰武", "戏份", "春药", "扫清", "斯特凡", "瞌睡", "阿卡迪亚", "马耳他", "唾手可得", "maman", "小贼", "推進", "硚", "五星", "mexican", "肉馅", "猜測", "鄭老師", "敏儿", "tris", "鲤鱼", "searched", "lend", "武当", "时光倒流", "三项", "暴跌", "备案", "ops", "亚诺", "破肚", "钝器", "没动静", "edjp", "銬", "monitor", "里维拉", "咎由自取", "忽視", "执法者", "牙痛", "有票", "发源地", "发生冲突", "謝莉", "放映机", "真妙", "应是", "颅骨", "放眼", "血滴", "吖", "boxes", "流行病", "ignacio", "神鹰", "能治", "该往", "和平主义者", "丧气", "良性", "ソ", "翻越", "不羁", "tons", "情报部", "stuxnet", "不愛我", "红牛", "值不值得", "彻彻底底", "大虾", "騙人", "帶到", "weiss", "啱", "游得", "升龙", "喂鱼", "尼科尔", "珠珠", "能进", "渾蛋", "沒看", "強盜", "库柏", "性侵", "丧", "产下", "headquarters", "帖子", "assigned", "刃", "成哥", "matches", "update", "爱侣", "斯克利夫", "黑羽", "背痛", "规章制度", "传召", "瑆", "再管", "线虫", "安乐窝", "heights", "sauce", "点球", "不以为然", "treasury", "marian", "薪资", "persona", "废止", "connect", "痴心妄想", "stiles", "早熟", "promises", "沙展", "文學", "virtue", "整周", "软肋", "征收", "请吃", "勾住", "买酒", "阻擋", "棕熊", "conspiracy", "relationships", "misery", "heavens", "公证人", "端正", "源治", "anxiety", "很闷", "睨", "圣安东尼奥", "撞伤", "时至今日", "催化剂", "固執", "喝口", "身處", "梅丽娅", "骨盆", "某件", "啮齿动物", "归西", "hid", "computers", "贏家", "偏激", "closest", "天下大乱", "izzy", "马高", "绑票", "大尾", "特斯拉", "戴蒙", "抓伤", "jeannie", "绕圈子", "cookies", "蓄意谋杀", "狄仁杰", "鼓動", "校庆", "breakthrough", "ambush", "堂哥", "vater", "cosmos", "歧途", "有著", "追回来", "職", "此言", "流到", "著手", "细说", "剝奪", "惡劣", "聽話", "阿港", "四哥", "巴纳", "弹劾", "雪山", "倒數", "孙膑", "老爷车", "concentrate", "老把戏", "惹人厌", "软体", "华达", "absolute", "天来", "下岗", "肃清", "五日", "棚里", "梅林达", "点解", "捉摸", "pleasant", "francesca", "列出来", "歇息", "不花", "叫车", "冰柜", "哈定", "吵过", "营火", "急急如律令", "嫔宫", "門鎖", "书吧", "sao", "日用", "自怨自艾", "偶而", "著迷", "备好", "優迪", "完成学业", "蚂蚱", "僚机", "自信心", "大三", "卡辛努", "围棋", "迂回", "绫波", "截稿", "贊助", "苔莎", "挑拨", "长不大", "鬼脸", "讲稿", "母校", "鈔票", "佩罗", "制造业", "波长", "漢斯", "读一读", "气囊", "theme", "索斯", "之梦", "苗", "盒里", "正妹", "玩点", "抛光", "沙林", "樓下", "利佳子", "頌", "先王", "山野", "介紹給", "篮板", "斯韦尔", "无影", "车钱", "万英尺", "朱利亚", "提托", "驚嚇", "色情狂", "电话录音", "lindsey", "莱希", "尔瓦", "冰原", "nik", "送进去", "可够", "据此", "拉伸", "itsuki", "攀岩", "真实情况", "接待室", "这盒", "拳頭", "驚奇", "水族", "费斯", "甚于", "bucket", "阿道", "鬼灵精", "爽歪歪", "施陶芬", "居高临下", "攫取", "从根本上", "牦牛", "無比", "在位", "薩沙", "尝到了", "科尼", "捆住", "吉士", "stepped", "临时演员", "缝上", "晃晃", "gap", "九条", "踢出来", "西伯", "sausage", "树里", "assistance", "妮基", "波兰语", "centuries", "紧紧抓住", "tool", "纠缠不清", "巧遇", "核反应堆", "木箱", "自转", "福岛", "歌里", "物色", "打情骂俏", "价位", "pow", "洗劫一空", "歌舞伎", "励", "笱", "不相上下", "食人怪", "真會", "發言", "路邊", "之位", "研究者", "小伤", "艾许", "诧异", "冰山一角", "共生", "恒河", "rage", "婆婆妈妈", "人給", "丽雅", "外行人", "周游", "栩栩如生", "衂", "已經過", "羽翼", "不遗余力", "jew", "像素", "下课后", "calvert", "易燃", "想当然", "cupcake", "amos", "这几年来", "后能", "沙鼠", "homeless", "工蚁", "fallback", "开瓶器", "那不关", "接二连三", "mosby", "丽达", "匮乏", "奴隶主", "超群", "伽玛", "节日快乐", "blessing", "药瓶", "水瓶", "射进", "一步之遥", "东家", "还装", "missile", "哪一条", "板仓", "叉烧", "刮伤", "戈尔巴乔夫", "貧窮", "engineer", "篓", "算盘", "心跳声", "高级官员", "祝你幸福", "壽", "小提琴手", "raw", "逼问", "進出", "拿稳", "花苞", "幼小", "熨斗", "这面", "joining", "大展身手", "溜出", "科南", "罪孽深重", "leid", "死于非命", "搞头", "羽毛球", "每间", "当官", "賬戶", "侵扰", "影评", "所在位置", "拉芙", "发廊", "糖糖", "无可避免", "梅琳", "老电影", "盖饭", "國內", "保护性", "遲早", "handled", "无线网络", "fndroid", "艾克斯", "天真无邪", "镊子", "相仿", "萨拉热窝", "拍成", "奇科", "画里", "corbett", "开导", "摩妮", "普鲁斯特", "倾心", "很妙", "手感", "投稿", "惠灵顿", "嘀", "hola", "芙尼", "感化", "幾時", "创下", "射到", "eastern", "雪莱", "怀表", "丰富多彩", "图米", "吉本", "颜", "老本行", "勿躁", "最高点", "共通点", "丝蒂", "复杂化", "personnel", "wa", "阿芝", "许三守", "抵抗力", "最弱", "满天", "摄取", "提奥", "西雅圖", "接进来", "東西來", "地势", "马背上", "lassen", "留声机", "里卡", "九次", "劉", "真牛", "千在", "新纪元", "张世东", "我杯", "沒準", "经度", "坦尼", "神是", "科琳", "minecraft", "database", "育儿", "静流", "有架", "喷射机", "八個", "长期以来", "rory", "谈个", "老樣子", "只须", "pork", "willy", "青年人", "mer", "blackmail", "蜜亚", "安哥拉", "亡魂", "库里", "定理", "无恙", "侧写", "我吸", "至亲", "skip", "学年", "murray", "金牛", "新约", "乳糖", "隱形", "denied", "pujol", "嗡", "arrival", "忘得", "therefore", "发话", "诺埃尔", "登錄", "捉贼", "国民党", "獲取", "engineering", "刘海", "arlene", "绐", "申明", "脱轨", "两极", "他令", "這有點", "萨克斯风", "via", "牙疼", "不太能", "葛雷博", "绷紧", "西城", "daylight", "青霉素", "mysilu", "来者", "點什麼", "dinozzo", "坐馆", "云宝黛茜", "五分之一", "能看懂", "倭寇", "patrice", "freund", "私人秘书", "海德尔", "天腾", "能生", "嵌", "没起", "一百倍", "汽车站", "tzu", "口口声声", "叙事", "随风", "监控器", "拉曼", "退却", "谁又能", "sont", "尔格", "格里斯", "利卡", "輪胎", "抢占", "约伯", "顶不住", "太阳穴", "heir", "海怪", "朝上", "倒入", "警报系统", "战马", "没洗", "终会", "七楼", "玛格丽", "teii", "mai", "毒藥", "只限", "传真机", "canyon", "压根儿", "费伊", "组里", "非人", "麝香", "gerald", "放得", "作答", "卖个", "bean", "只知", "球童", "多毛", "茱恩", "请勿打扰", "大难临头", "最喜歡", "纳奥米", "斯泰尔", "交警", "水手长", "十五万", "受阻", "团子", "装甲师", "蹒跚", "鹰巢", "泡泡糖", "索引", "有其父必有其子", "雷利亚", "第十八", "spinning", "地头", "海牛", "寄給", "唐恩", "爱不释手", "来演", "hiv", "协奏曲", "面料", "半人", "多项", "树脂", "飞力", "都灵", "抓进", "卡灰", "空手而归", "魷魚", "豹哥", "律师费", "這你", "approval", "室裡", "水晶球", "音域", "特产", "贝奥武", "x射线", "announce", "july", "沉默寡言", "内要", "夹层", "出錯", "screams", "記號", "七十五", "市议会", "eggsy", "十条", "克莱因", "但當", "火上浇油", "操之过急", "人潮", "marion", "胡作非为", "后部", "碰過", "frances", "关系密切", "有胆", "行动计划", "天妇", "严实", "脱光光", "放风筝", "gaia", "妙子", "下放", "那枚", "看海", "重操旧业", "politicians", "花絮", "听点", "一滩", "乔治城", "驱动程序", "轻快", "扬起", "男女之间", "beverly", "木有", "assholes", "没过多久", "东振", "世界观", "实况", "土拨鼠", "夥", "埃尔顿", "黑海", "搭帐篷", "亲自出马", "provided", "伤寒", "波利斯", "推土机", "加进去", "透气", "herb", "点会", "事说", "别见怪", "舞娘", "乌索普", "攻城", "托曼", "拍成电影", "meantime", "停着", "葵丝", "dos", "预估", "光棍", "高强", "導彈", "抬頭", "我分", "gaga", "花销", "corrupt", "五级", "阴唇", "分上", "空战", "苦差事", "林立", "未麻", "布坎南", "菲力浦", "定时器", "davina", "用脑", "游民", "拉丁人", "矩阵", "humor", "醫學院", "asset", "安上", "神器", "文员", "derrick", "数十亿美元", "clarence", "中田", "vodka", "德米特里", "拳擊", "优于", "senate", "remarkable", "通天", "虜", "伏地", "queens", "focused", "续", "砍伐", "赚够", "首场", "還有個", "相传", "reception", "少说两句", "阿邦", "覜", "認同", "科里亚", "哥萨克", "倾盆大雨", "藝人", "途", "前功尽弃", "讨伐", "tess", "tanks", "畕", "高人一等", "剐", "對此", "hali", "四杯", "正下方", "civilization", "埃菲尔铁塔", "喇叭声", "流露", "变故", "terribly", "發起", "灯亮", "苦不堪言", "很合", "供品", "無罪", "極限", "刚满", "禁食", "比划", "安格尔", "不顺心", "古迹", "arena", "十五日", "輩", "寻开心", "飞速", "基兰", "狱", "寫著", "醫院裡", "号桌", "广告公司", "绝大部分", "卡布", "没权", "看门狗", "吹过", "蛤蟆", "袋里", "掉进去", "万万", "金牙", "半途", "naughty", "弗蘭基", "偽裝", "高管", "你頭", "左耳", "诉苦", "球隊", "flame", "工藤新", "搬回去", "故作", "发送到", "anxious", "退位", "mar", "科巴", "斑比", "无双", "縫合", "干事", "阿蒙", "驱车", "实事", "迷迷糊糊", "乌鸦嘴", "内布拉斯加", "赠品", "多只", "损", "真敢", "阿塔", "达菲", "建好", "为名", "解放军", "欢送", "玩花样", "静悄悄", "输球", "彭妮", "大闹", "浮在", "获得成功", "哈羅", "勳章", "切实", "breach", "册子", "糖水", "看不上", "窦", "一百分", "退步", "戰術", "柑橘", "duane", "聚一聚", "谭雅", "投票决定", "久保", "minus", "臭烘烘", "神通广大", "琼妮", "时别", "被单", "跳入", "doe", "腿毛", "肋", "mainland", "身体检查", "常任", "不听使唤", "咖啡壶", "奶嘴", "贱民", "ancestors", "筆記", "有夫之妇", "复印机", "赶工", "右后卫", "星野", "musical", "地下组织", "灌满", "东线", "华夫饼", "别多", "巴士站", "长胖", "再战", "wears", "说太多", "成田", "多惠", "爱荷华", "问号", "标价", "parliament", "contain", "接踵而至", "麦康", "汤马斯", "信神", "踢走", "剖腹", "陨落", "枪膛", "腹中", "生命线", "镬", "φ", "這沒什麼", "侗", "赴宴", "邁阿密", "迷药", "西亞", "迪迪", "抬举", "归根结底", "里特", "幽", "唠", "晨光", "三四个", "象形文字", "号子", "重金", "十五号", "縱", "独行", "极端分子", "贪欲", "私人侦探", "来办", "几片", "多谢您", "应不应该", "布雷德", "莎琳", "动情", "所踪", "香山", "kerry", "公厕", "可以信赖", "sanders", "波段", "信是", "扯谎", "海市蜃楼", "大团圆", "comet", "曼哈頓", "菲德尔", "德威克", "正有此意", "clown", "高速路", "猛攻", "yuri", "intelligent", "偷过", "生長", "fascinating", "弩", "后尘", "白熊", "服务中心", "撼动", "几间", "褪", "坐满", "雷尔", "有妇之夫", "两米", "药箱", "gef", "同床共枕", "合乎逻辑", "长假", "凋谢", "我党", "爵德", "stahl", "长老会", "太亮", "這首", "葬送", "素妍", "眼影", "酷爱", "霓", "坚称", "erst", "学说", "獨處", "有令", "契士", "黑黑的", "斋藤", "三组", "ピ", "难免会", "动植物", "备", "质感", "尼欧", "檀香山", "狱卒", "陀螺", "過份", "动脑子", "analysis", "船运", "运毒", "吠叫", "艾丹", "grounds", "滑下来", "熱烈", "fits", "amongst", "军火库", "菲威", "媛", "瞒过", "知音", "秋田", "克勞斯", "記不記", "俐落", "砍成", "便利商店", "banana", "公物", "甜酒", "phase", "喊声", "在案", "湖南", "基督山", "ingrid", "芭蕾舞者", "垦炳", "三姐", "今朝", "亚达", "獨", "吸过", "寵物", "刀法", "敬业", "mercedes", "言葉", "逃窜", "皮鞭", "burger", "铁门", "狠揍", "炎", "酷酷", "drawn", "supernatural", "暗殺", "荞麦面", "坳", "cafe", "一线希望", "几百块", "黑田", "anonymous", "复查", "vee", "总额", "人类学家", "咱要", "惡棍", "sy", "催泪瓦斯", "救主", "pole", "烘干机", "克里斯琴", "算作", "lorenzo", "精锐", "beta", "hdchina", "lowell", "贤者", "鹿肉", "slaves", "高风险", "放晴", "藏宝图", "dell", "牛扒", "會後悔", "經給", "获知", "四角", "涌动", "代子", "classes", "派大星", "定做", "sekou", "我象", "论据", "点汤", "朋", "龙凤", "arr", "roxy", "氮气", "歸來", "targets", "阿蓝", "precure", "剌", "家暴", "依次", "海倫", "药局", "手忙脚乱", "窃案", "决不允许", "prayer", "寇特", "問了", "堅定", "挫", "母老虎", "小良", "内里", "我願", "beaten", "磉", "sinatra", "我儿", "野种", "吹毛求疵", "下套", "半生", "三思而后行", "安防", "唱戏", "说走就走", "癱瘓", "瑪", "康沃尔", "几百人", "trans", "冲上去", "能出", "塌陷", "祔", "阑尾", "四叶", "rosita", "自然科学", "找条", "大賽", "万全", "丟失", "老王", "眼眶", "联谊", "手会", "我领", "索命", "契尔", "cha", "动力学", "完婚", "暗自", "想谈", "圆盘", "仇杀", "因陀罗", "zetrov", "纳粹德国", "袜", "圣剑", "一擊", "疗效", "questioning", "躇", "胯下", "迪亚戈", "整支", "步子", "飛去", "西非", "出千", "lambert", "白头发", "railway", "誇", "势不可挡", "rumor", "推遲", "保拉", "逆向", "各个方面", "凯岩城", "虹膜", "奥尔巴尼", "elmer", "tips", "nfl", "凌辱", "乱世", "贩卖机", "活火山", "waren", "pietro", "五十年代", "欲仙欲死", "金日成", "elliott", "clarkson", "稀客", "白发", "死对头", "榜", "接线生", "威士忌酒", "倒卖", "给与", "subtitles", "闲谈", "格瑞", "停学", "冷嘲热讽", "降世", "梅勒妮", "训", "恢复健康", "韩琛", "夭折", "带齐", "工时", "一转眼", "cher", "林檎", "长存", "之墙", "第三种", "汇票", "确保安全", "郴", "不负", "失重", "太嫩", "blaine", "第三代", "造影", "藏书", "肖邦", "回礼", "人性化", "钻出来", "宇航局", "農夫", "推给", "niklaus", "stretch", "恐惧感", "急情", "sum", "轻抚", "芖", "魯", "大胸", "东南部", "苏厄德", "船屋", "及早", "hare", "亚尼", "裝修", "搐", "派恩", "换车", "成吉思汗", "operate", "一声令下", "有道", "gordo", "右面", "这够", "杀伤", "湘", "背下来", "mackenzie", "我光", "亚瑟王", "enormous", "硅谷", "安洁", "旧日", "帷幕", "instance", "随和", "黄金时代", "云霄", "成群结队", "方方面面", "排到", "烫死", "十五秒", "别冲", "外籍", "特雷莎", "danni", "百分之二十", "挺难", "看报", "金恩", "泰國", "男方", "健太", "义体", "进站", "召妓", "griffin", "拉奇", "方才", "限量", "传个", "西纳", "拟定", "包装纸", "化妝", "十万火急", "瓦莱", "齐步走", "声乐", "尼格", "溜冰鞋", "契合", "承办", "做大", "副总", "腦子裡", "ﺂ", "人长", "性奋", "格特鲁德", "良药", "露一手", "人出", "伊莎贝", "塞尔吉奥", "佩佩", "聚首", "菲特", "小样", "凯罗", "遮挡", "整部", "對決", "欺压", "萊莉", "commercial", "匹敌", "jango", "积聚", "中美洲", "水在", "祑", "高歌", "一响", "告上", "無事", "期末考", "矿物质", "精于", "承包", "抗命", "表达方式", "傳來", "地待", "奇袭", "照管", "壁纸", "多洛丝", "教务长", "cassidy", "确", "电汇", "晚才", "皮特森", "先送", "騎兵", "惯坏", "这双鞋", "櫻井", "supplies", "有名气", "幸虧", "林家", "這副", "汤里", "满天飞", "这股", "请不起", "茜茜", "春香", "货轮", "鲁道", "换钱", "negan", "逾越节", "scout", "執照", "叻", "頸", "久美", "礟", "惯犯", "georgina", "恩达", "卡劳利", "热咖啡", "这事会", "阿特金", "怜", "阿尔特", "舰船", "完全一致", "irish", "林地", "相框", "侣", "专务", "牙套", "conflict", "卢旺达", "腾", "他选", "焦耳", "奔流", "优胜", "大条", "随心", "但別", "旁遮普", "阿勒", "亂來", "茶点", "火影", "击剑", "公车站", "文职", "玛丽和", "顽童", "語氣", "iove", "基奥", "塔蒂", "富婆", "文具", "仆街", "拼搏", "买入", "多万", "检阅", "临终前", "永不分离", "mhm", "考卷", "graiman", "会接", "波哥大", "若干", "老好人", "鷹", "適當", "谎称", "多快", "傷到", "受辱", "督促", "蒼蠅", "转储", "涂点", "二人组", "lungs", "sales", "alliance", "robbed", "天底下", "谢泼德", "accent", "人流", "弗伦", "fianc", "正规军", "一进", "carly", "巨怪", "布列", "帕夫", "怪異", "別著", "一丁点儿", "禿", "菲戈", "接回来", "勞達", "前兆", "月饼", "超级市场", "门缝", "加些", "单手", "北军", "п", "之镜", "所幸", "一泡", "想來", "老生常谈", "不重", "remote", "射击场", "小白兔", "霍安", "拉高", "破伤风", "recommend", "pax", "引以为豪", "飞回", "一决", "芅", "莉安", "新花样", "dedee", "大卡车", "林区", "养猫", "几滴", "席根斯", "碎屑", "甜瓜", "hunted", "大哥大", "限速", "艮", "types", "開關", "wounded", "牢不可破", "connelly", "有钱赚", "抚养费", "patrol", "卡托", "葬身", "工程学", "泰国人", "存进", "brass", "发表演说", "spoon", "不单单是", "功課", "联", "珍重", "漲", "华而不实", "未找到", "跟別", "交还", "追忆", "抱头", "不时之需", "以後會", "挨骂", "玛卡", "伊藤", "杜德", "卡罗斯", "繩", "三位一体", "四海", "外交政策", "喜悅", "miserable", "攬", "常年", "撵", "电气", "sterling", "講述", "这段话", "sticks", "squeeze", "本区", "條路", "情事", "服务台", "平复", "investment", "数日", "產常", "恃", "卖艺", "鮮血", "八重", "纸板", "原子能", "aeu", "氯", "占星", "浅野", "灌篮", "一而再", "補充", "大增", "一談", "太空服", "加強", "isobel", "鸟中", "一万年", "十二分", "手續", "手续费", "通力合作", "罗茜", "空余", "七十二", "松惠", "第二点", "爱子", "猛犸象", "adults", "大脚怪", "废弃物", "次元", "小姨子", "高枕无忧", "洁丝", "长篇大论", "七成", "演完", "precrime", "高貴", "应战", "大眾", "areas", "切碎", "加梅莉亚", "观察力", "緍", "割礼", "ё", "我困", "断断续续", "窘迫", "电极", "讨生活", "cease", "后宫", "賤貨", "许多次", "当之无愧", "先见", "达尼", "還錢", "股掌", "姨父", "钱庄", "特级", "天子", "影音", "哨声", "塞克斯", "屎尿", "货品", "這不會", "顺利完成", "多留", "點半", "dessert", "半左右", "壞事", "苹果酒", "wexler", "销售额", "哄哄", "mcdonald", "北野", "取走", "一夫一妻制", "小香", "百合花", "壘", "俘", "不演", "之恋", "宝莉", "滚远", "赫兹", "捷", "一夥", "洛妮", "最低工资", "名媛", "讨回公道", "上課", "来意", "我正", "不具", "道个", "桒", "勝", "卡米洛", "會覺", "莫希", "atlantic", "暂缓", "事出", "nazarene", "东侧", "冰棍", "強調", "carbury", "亩", "螺絲", "钩住", "活过", "会照", "牛肉干", "等同", "少得", "創始", "小铜", "execution", "相守", "十九世纪", "呆坐", "褂", "竕", "goods", "其母", "明蒂", "馆里", "尼根", "struggling", "小慎", "schools", "那顆", "狂妄自大", "地爱上", "票价", "再装", "花痴", "木下", "耻笑", "贝茜", "取水", "钻孔", "亚美尼亚人", "超想", "轮奸", "区里", "咔嚓", "绳结", "败给", "站成", "聽器", "为乐", "老虎机", "一周年", "吉隆坡", "瘫", "韩先生", "烛台", "莫蒂", "payment", "上等兵", "前能", "摆姿势", "卸掉", "松口气", "信纸", "干妈", "你治好", "genovia", "唱歌跳舞", "乌拉圭", "女同", "浅色", "圣彼得", "小鳥", "每週", "比西", "解职", "肉丸子", "舉手", "之初", "再起", "排水沟", "自食其果", "新闻媒体", "只字不提", "一上午", "马斯特", "hrer", "麦德林", "永恆", "软绵绵", "眼眸", "埃尔维斯", "四轮", "weakness", "那幢", "shortly", "虹", "四川", "大耳", "杰里科", "阿基里", "社群", "纽约城", "綪", "感到痛苦", "菏夯", "小石头", "驱走", "共进", "旧时", "枪子儿", "阿菲", "浅薄", "出乱子", "同个", "国道", "雷纳德", "更上一层楼", "赫克", "愁愁", "交易员", "carpet", "complain", "安徒生", "怠慢", "振泰", "草根", "ming", "严刑拷打", "lazy", "硖", "智囊团", "billions", "层层", "木卫一", "奥兰", "死死", "新进展", "戴维森", "这楼", "阿里巴巴", "木头人", "自由派", "西特", "不怀好意", "尚有", "drei", "绕开", "殷勤", "阿亚", "wendell", "交织", "跨国公司", "样片", "chaz", "活儿干", "deng", "母后", "百般", "富江", "melvin", "拖垮", "秀才", "烧成灰", "杞人忧天", "古德", "振作起", "巴西人", "海洛英", "一樁", "兩份", "泄", "调转", "挣点", "嚇", "玛戈", "當上", "保列", "负面影响", "这岛", "邮轮", "落跑", "所受", "rein", "西侧", "杂", "利亚诺", "彭德", "闲置", "波拉克", "特立独行", "戴好", "珊侬", "更別", "述", "诺莉", "检修", "多點", "凉子", "庙会", "嫂", "推特上", "血泊", "fridge", "depend", "crawford", "现阶段", "亲娘", "香水味", "车停", "腮", "少年犯", "毛虫", "雄风", "先停", "达赖喇嘛", "寧靜", "法戈", "建設", "蜿蜒", "萬人", "通緝", "又会有", "这不太", "笭", "本森", "economic", "后患", "编成", "基因组", "麦迪森", "相距", "小亮", "sticking", "注目", "诺福克", "劳改", "内罗", "宜人", "coin", "gemacht", "上部", "sacred", "甩卖", "驾崩", "丽尔", "appeal", "修理厂", "succeed", "大丧", "擅自行动", "夏利", "sunlight", "国立", "多田", "飘荡", "高僧", "姨母", "发自", "雅致", "戏子", "變形", "不俗", "返程", "下文", "煩死", "瓷", "葛伦", "來臨", "每部", "榜樣", "而今", "黑寡妇", "谢里", "大马哈鱼", "饭钱", "larson", "遮遮掩掩", "局子", "引线", "弗兰茨", "joanna", "lyla", "深表同情", "ohne", "還年", "大英", "無緣", "沙哑", "mayo", "哪张", "惹是生非", "跳海", "送來", "詭計", "莴苣", "a型", "开回去", "犯事", "热那亚", "大學生", "敞開", "法拉第", "惊心动魄", "remy", "靶心", "不自量力", "洋溢", "一条心", "少说废话", "瓦砾", "帳戶", "主动权", "没敢", "草纸", "截停", "入座", "小卡", "魔法石", "田径", "外祖父", "胖胖", "洛夫斯基", "tables", "无法回答", "這給", "餘", "东亚", "contacts", "visitors", "fraud", "抗爭", "色盲", "regarding", "守卫者", "教化", "敲开", "岩漿", "穐", "埋单", "形体", "要演", "云霄飞车", "杜夫", "狗命", "anchor", "全顺", "大佐", "充沛", "噫", "加速度", "angus", "solved", "约见", "步步", "认不", "盟主", "偽造", "機上", "照相馆", "高难度", "教材", "次日", "近身", "大不一样", "hooker", "色情杂志", "轉到", "剪接", "一抹", "脸朝下", "水闸", "天王星", "马粪", "悝", "开支票", "洽谈", "占优势", "核电厂", "斯坦福大学", "十万美元", "原材料", "匿名信", "流体", "走访", "奥德曼", "維護", "typical", "丹佛斯", "午餐会", "達西", "入行", "卡通片", "再烦", "滩头", "血肉之躯", "克拉科夫", "米琪", "circus", "滥交", "發脾氣", "吃不饱", "碰壁", "奇卡", "一玩", "就連", "一窝", "皮夹克", "勞", "业务员", "password", "出戏", "莫须有", "單上", "核电", "场外", "稳定性", "过载", "矿上", "穕", "別理", "见面礼", "這棟", "可怖", "医官", "糷", "控罪", "俗", "蜂拥而至", "禁地", "手榴彈", "太緊", "那球", "produce", "我冲", "格蕾", "密尔沃基", "嵯", "娃娃脸", "transferred", "天职", "米塔", "乐声", "邏輯", "第三章", "难得一见", "神侯府", "缺水", "没大没小", "小光", "得偿", "脾", "累得", "九點", "你造", "三万块", "刊物", "推想", "歌喉", "施放", "雷雨", "月色", "死槍", "瞯", "水瓶座", "soze", "意淫", "塔卡", "聖人", "你演", "乐哥", "基的", "阎王", "畄", "但求", "阿克巴", "当是", "干到", "一在", "洞悉", "著急", "放狗", "harbor", "千次", "宰杀", "怀尔德", "红葡萄酒", "星团", "亚麻", "cupcakes", "快點兒", "不脱", "拜读", "ム", "浓缩铀", "朱蒂", "进出口", "垂死挣扎", "大森", "阐明", "杂技", "塞古", "第二章", "zed", "酒气", "数百人", "情願", "imanity", "捐精", "爆满", "求得", "激", "脱节", "stare", "谘", "贷", "一个打", "停课", "潦倒", "打击犯罪", "伊利诺", "科尔特", "酒席", "水裡", "激流", "违章", "塞拉利昂", "牵绊", "puppy", "桑顿", "佛斯", "初见", "咱能", "限量版", "fold", "高高兴兴", "帐目", "生者", "一尘不染", "借鉴", "滑水", "nix", "筆記本", "百分比", "獵物", "大卖", "理想主义", "喷漆", "預算", "处得", "compound", "這感覺", "压到", "安康", "douche", "快照", "卡彭特", "换位", "炖牛肉", "判他", "风险投资", "录音棚", "间谍活动", "monte", "cardinal", "奥地利人", "变色", "willis", "随叫随到", "歎", "航天员", "布兰森", "送些", "沒門", "跳台", "敢情", "洗发精", "过段时间", "杨戈", "傻站", "针孔", "经不起", "收支", "顿悟", "爵位", "無憂", "哽咽", "供货商", "蘿", "发色", "允诺", "snl", "工友", "錯什麼", "缴纳", "hastings", "隱私", "事与愿违", "joker", "亮片", "氧气瓶", "縣", "读书人", "那组", "celebration", "晶晶", "门后", "娜迪雅", "精校", "阿兹", "melt", "wheaton", "蟲", "freezing", "進到", "克罗伊", "撒拉", "grabbed", "底座", "瑪莉", "小寶貝", "致命伤", "餐会", "伎", "平次", "不渴", "expression", "bran", "很慘", "科学实验", "祭拜", "真准", "慧琳", "自焚", "小空", "engines", "偷猎者", "查问", "believing", "尝点", "伯吉斯", "lana", "yoyo", "olga", "维苏威", "督德", "三百元", "骗徒", "斥责", "葛瑞", "达卡", "病毒感染", "被炸飞", "果戈理", "raul", "验", "高位", "事由", "中字", "布丽", "不恨", "费尽", "红皮", "普金", "避難", "白領", "米长", "载入史册", "写照", "后顾之忧", "mall", "会留", "无忧", "那全", "震驚", "瞥见", "夜叉", "这太扯", "艳遇", "抓贼", "地写", "小五郎", "煎锅", "左面", "调味料", "咸菜", "前院", "武田", "没好", "没品", "烟幕", "开眼界", "风衣", "攜帶", "登出", "mayfair", "simms", "hulk", "穆克", "互相照顾", "麻瓜", "彭彭", "雞尾酒", "junk", "死缠烂打", "reveal", "投怀送抱", "交上去", "造谣", "新专辑", "汽笛", "五件", "丽茜", "ﾛ", "比尼", "特战", "塞浦路斯", "厂房", "lemon", "红地毯", "米沙", "狗娘養", "玼", "探照灯", "驶往", "东非", "漫天", "教课", "有条理", "洛莉", "朱利", "delete", "谢礼", "你会害", "索林", "goodnight", "税款", "氢弹", "震颤", "previous", "太瘋狂", "georg", "tragic", "聚合", "无不", "克里尔", "slim", "要务", "語音", "虐", "精神分析", "七位", "supper", "两公里", "小虫子", "内幕消息", "露易", "标枪", "采食", "聪明绝顶", "高素", "沒死", "憋气", "鏽", "太公", "取自", "祖伊", "爆竹", "涂满", "异域", "驼鹿", "葛林", "洞窟", "金黄色", "跩", "沟渠", "斩草除根", "屑", "不安分", "appropriate", "民主化", "戴伦", "沒有別", "活动家", "bagwell", "起色", "若真", "示爱", "春子", "用剑", "喷到", "重度", "將近", "费里", "茁壮成长", "宫女", "senses", "昏昏欲睡", "昏厥", "informed", "之术", "pose", "饭厅", "棒球帽", "反坦克", "朝拜", "事务部", "情節", "入围", "接班", "没玩过", "colony", "念经", "河邊", "淤泥", "小安", "大受欢迎", "英特尔", "勃艮第", "火口", "亲朋好友", "牢牢地", "米雪儿", "強暴", "hu", "我烦", "唱过", "meadows", "六块", "自宅", "塞西莉亚", "没停", "合眼", "planted", "别掉", "hotch", "巨猩", "危机四伏", "mansi", "santiago", "白鬼", "handling", "王大人", "度假胜地", "虎式", "平生", "毫无希望", "背书", "去問", "爷们儿", "paddy", "心神", "认字", "不吸", "陈老师", "每周日", "beloved", "报表", "erin", "光之王", "专横", "生意兴隆", "脸色苍白", "闭一只眼", "罪大恶极", "普吉", "阿弟", "挥杆", "杨先生", "大半个", "同甘共苦", "森美", "fools", "大戏", "temporary", "普罗维登斯", "本性难移", "马吉德", "agnes", "banner", "交学费", "産", "企鵝", "酒厂", "民主主义", "好慢", "ap", "ء", "健将", "艳丽", "證詞", "歌唱家", "機票", "载有", "holt", "金童", "起跑线", "吹拂", "祠堂", "cromwell", "狂风暴雨", "xxx", "幅度", "获奖者", "本台", "刑场", "fujii", "死过", "似有", "侦探小说", "征途", "pillow", "太怪", "退让", "ｅ", "家臣", "mahone", "氣色", "identified", "salazar", "真一", "最迟", "市价", "邪念", "用用", "anjali", "tracked", "elaine", "阿莱", "一樂", "簽個", "令牌", "里斯特", "切拉", "尊姓大名", "widow", "金表", "暴動", "长跑", "prophecy", "一千五百", "崔益", "亚法隆", "認罪", "里希特", "物归原主", "込", "完整性", "様", "哈洛德", "煩人", "软骨", "起家", "万磅", "廻", "ginny", "捐献者", "哦哦哦", "consequences", "没定", "還小", "陸", "飘忽不定", "ganze", "怂", "支那", "几年级", "小到", "期末", "靠窗", "红衣服", "棒球赛", "游动", "常数", "现下", "冰室", "plot", "抖出来", "靶", "加沙", "instant", "校内", "偷跑", "短剑", "ranch", "以东", "翻译成", "继任", "他个", "推举", "府邸", "疾风", "jorge", "半路上", "世贸中心", "粗魯", "做下", "這麼問", "供述", "驢", "你夠", "奥特曼", "幾分", "八周", "maddie", "阿德莱德", "花梨", "尽忠职守", "不毛之地", "不知所谓", "能放", "翠西", "哈肯", "火枪", "中旬", "outfit", "印出来", "白厅", "棕发", "眼部", "dunn", "靜", "重來", "raid", "越障", "ﺊ", "同位素", "衰败", "上策", "病危", "sylvie", "畅游", "小川", "hui", "逢场作戏", "規律", "上主", "亡命之徒", "名不虚传", "保險箱", "盃", "你點", "错位", "接好", "德布", "擔憂", "斯菲尔德", "配额", "德尼", "主动出击", "counts", "瘸腿", "星象", "双翼", "卡迪亚", "直击", "大车", "捷足先登", "coffin", "因人", "夹紧", "布伦", "水会", "性是", "精心设计", "军械库", "咏叹调", "收发室", "球探", "我怀", "dewy", "卡什", "everyday", "夜深", "通敌", "abuse", "简简单单", "所写", "绷", "球季", "呼吸声", "会待", "dawson", "bolton", "黑衣服", "放暑假", "vern", "残局", "乔舒亚", "shove", "小蘭", "荣获", "寝宫", "武器库", "arrow", "世故", "machines", "貂皮", "reddington", "字符串", "调制", "阿肯", "华伦天奴", "远超过", "吊桥", "辣椒酱", "空中小姐", "甁", "征得", "克什", "棒球棒", "近代", "官人", "搭话", "冤", "自身难保", "肉食", "位数", "兴旺", "代表性", "海沃德", "苹果树", "问询", "詩", "装点", "原作", "丽子", "奥德赛", "罗妮", "设有", "加菲猫", "紫禁城", "計算機", "当差", "報社", "hanson", "locker", "leah", "tusk", "急救室", "失联", "奠", "几個", "肯辛顿", "欧米茄", "honored", "错人", "明朝", "斋戒", "竞拍", "发出信号", "二猛", "会受", "弥莎", "优厚", "ar", "胖小子", "游乐", "克罗克", "屍体", "吊起", "慢动作", "roommate", "敏珠", "太妃糖", "胖女人", "drayer", "自由女神", "裁判官", "一舉", "安裝", "這東", "斗山", "砐", "觀眾們", "过好", "小规模", "买花", "驶入", "籌碼", "隐退", "快没了", "macpherson", "分机", "人向", "roses", "牟利", "賭注", "菲恩", "欧利", "呯", "节俭", "進化", "市值", "theresa", "armstrong", "gracias", "骨瘦如柴", "绘里", "pradeep", "夜景", "胸毛", "五月花", "玻璃瓶", "第二道", "亞倫", "praying", "hodges", "黯淡", "奸杀", "遞給", "那太糟", "取回来", "雪雁", "二货", "刻骨铭心", "常驻", "能克服", "切丽", "愛了", "订过", "撤诉", "不能逃避", "第三步", "敌手", "焚毁", "巨无霸", "簗", "法务", "本尊", "测定", "执行公务", "点灯", "做派", "成功人士", "四十个", "螌", "浮冰", "continued", "启齿", "施咒", "胎盘", "莎莎", "揸", "racing", "protest", "右轉", "beep", "blocked", "卡文", "圣物", "瑪麗亞", "趕時間", "袖扣", "破船", "杀猪", "julius", "指示灯", "直冲", "原油", "健怡", "那层", "引導", "半瓶", "lessons", "他怕", "落败", "manhattan", "依恋", "斯密斯", "起劲", "幼兒園", "跪拜", "闲晃", "salad", "麻省理工学院", "条河", "lobby", "颠", "事出有因", "jojo", "风纪", "化妆室", "门下", "宋先生", "点见", "安全漏洞", "梅耶", "玩過", "运输车", "哨", "斯塔斯", "请代", "下一阶段", "malaya", "messala", "毫无道理", "谈情说爱", "立花", "cyber", "桌边", "枢木", "树屋", "threaten", "名為", "化为灰烬", "虔", "刀具", "您老", "審查", "提着", "marcia", "快進", "中川", "优先权", "理顺", "说不过去", "适者生存", "tango", "间隙", "沉痛", "值得注意", "穷追不舍", "火器", "情意", "智妍", "适时", "technical", "理科", "幻听", "演了", "這又是", "个人信息", "不急", "發抖", "優點", "强权", "抽动", "血洗", "古力", "三架", "astrid", "多虑", "投票表决", "挨个", "带狗", "european", "白纸", "诸事", "thea", "别是", "福星", "共同努力", "cheat", "静谧", "十萬", "东风", "remaining", "傖", "首屈一指", "求婚者", "近海", "汉妮", "愛死", "打头阵", "塞尔达", "吃水果", "缝好", "merlyn", "先坐", "利科", "叛党", "鏈", "萝伦", "低調", "跟上去", "乌鲁克", "富家女", "防晒油", "泰晤士报", "定好", "背景音乐", "解藥", "对不上", "沃尔科特", "瓶装", "这列", "拉蒙特", "连话都", "公益", "婆罗", "機長", "历历在目", "贖罪", "钢琴师", "地死", "量子力学", "玪", "奥图", "屠", "拉赫", "戈斯", "奇曼", "訴", "小卢", "鲜红", "皮包骨", "關聯", "搞錯", "一个头", "养不起", "付給", "小英", "开户", "血染", "阿勝", "米盖尔", "剿灭", "滚下去", "阿好", "reek", "jasper", "外賣", "punished", "巴厘", "石田", "cochran", "美国公司", "圣旨", "迪科", "快动", "家禽", "將他", "想不开", "布特", "誓词", "proved", "用武之地", "走著", "錄影", "相比之下", "那輛車", "兰斯洛特", "tires", "降雨", "皇军", "达里奥", "男儿", "有条不紊", "ira", "暂住", "蕴藏", "茶楼", "说话算数", "躲避球", "設", "月刊", "每根", "卡明", "哲學", "翻阅", "导管", "kin", "耶夫斯基", "引信", "市區", "不告", "墨染", "白板", "abandon", "殘殺", "杏子", "美莉", "回天", "导火索", "坐過", "耶诞", "脑瓜", "赶跑", "永永远远", "连尼", "长年", "控股", "温尼", "尺度", "罗兹", "生产商", "格瓦拉", "供货", "那趟", "半空中", "體溫", "无垠", "心安理得", "综合征", "毛手毛脚", "泰哥", "七妹", "贝尔斯", "constance", "能装", "听筒", "默罕", "helmet", "部里", "卡拉奇", "rodriguez", "牵线", "birdee", "偌珀", "mid", "界定", "木雕", "杰佛逊", "卖座", "無領", "展露", "哥谭", "离异", "避风港", "猜出", "相告", "塔吉", "奧迪", "蹈", "罗伦斯", "莊園", "早退", "保安人员", "阿雪", "毕夫", "独立战争", "仲", "順序", "布罗德", "克莱蒙", "氢气", "雷達", "史葛", "一叠", "鲁兹", "过剩", "阿鲁", "却成", "播送", "特種", "路况", "申先生", "追过来", "狗血", "模擬", "哪出", "之行", "娜斯", "各界", "瞺", "打成一片", "步调", "翻天覆地", "delta", "编导", "skill", "伊丽娜", "多条", "發什麼", "凶徒", "建设性", "韦斯莱", "芳名", "侏罗纪", "立功", "十八个", "三十八", "腓利", "法特", "在精神上", "心血来潮", "剛到", "livin", "计算器", "燒了", "财阀", "groans", "小馬", "许仙", "backson", "止血带", "becker", "黄先生", "荡漾", "肣", "现况", "鳌拜", "犊子", "剩饭", "decades", "肉卷", "净空", "幸运星", "任何一方", "小器", "局限于", "喝到", "僅", "一整瓶", "没装", "注意事项", "仇视", "处子", "isabel", "小豆", "指给", "大酱", "埃莉", "表现出色", "针锋相对", "口角", "因该", "高材生", "人知", "但系", "相随", "technique", "霸王龙", "florence", "红绿灯", "上画", "韋", "格局", "人心惶惶", "贝托", "明妮", "michonne", "正有", "减低", "gmo", "刀割", "那盒", "倾泻", "滑翔机", "給我點", "涩", "建议您", "羊皮纸", "我闭", "铁锤", "mowgli", "導", "这祥", "清一色", "縮", "crackers", "昇", "解放者", "直树", "艾卡", "狄伦", "轉告", "eternal", "非常明显", "再长", "两亿", "killers", "witten", "一盎司", "英鎊", "几晚", "调低", "名门", "捏碎", "图森", "歆", "concept", "dial", "正途", "万名", "夺下", "优先级", "一介", "陣", "emotions", "领奖", "修缮", "雄鸟", "易碎", "挺舒服", "你並", "淡淡的", "bowman", "旧时代", "重磅", "胚子", "紙條", "鼠尾草", "颧骨", "无损", "一試", "不告而别", "极少数", "小島", "最新进展", "鎗", "免税", "螛", "乔布斯", "鬼门关", "spotted", "spirits", "先请", "上学时", "揮", "擁", "罕有", "多高", "大威", "无味", "吞并", "裂口", "棍棒", "姨", "尝一尝", "胚", "停放", "调去", "木质", "肘", "无业游民", "换点", "两方", "亚德", "寄到", "干架", "叫嚣", "霍蘭", "faraday", "magical", "伶俐", "buster", "花都", "非走不可", "白骨", "sim", "哈里发", "答得", "迪奇", "玛莉莎", "阿加莎", "松田", "inn", "厭煩", "横幅", "约翰森", "升值", "途经", "埃利希", "補習", "rv", "换身", "豪瑟", "限期", "姆斯基", "行车", "晨间", "罪過", "就医", "peaceful", "不亲", "狼族", "瓜分", "势均力敌", "品脱", "击个", "小直", "kneel", "gimme", "全说", "玩忽职守", "学医", "hooked", "chains", "别关", "纵观", "recovered", "马太福音", "翻车", "踩踏", "absence", "hopkins", "张口", "回落", "lords", "太旧", "吐出", "manner", "有興趣", "湿气", "悲痛欲绝", "巫医", "售卖", "贊", "欧律狄", "攔住", "reaching", "rival", "绞刑架", "砖块", "marius", "甲状腺", "幽暗", "马山", "影射", "yuki", "瑾", "呼应", "一去不复返", "惟一", "beaumont", "machst", "邪神", "阿列克谢", "法朗", "快脱", "diary", "用量", "拉拉队长", "花費", "重重的", "电厂", "停用", "josie", "還從", "蜜月旅行", "登月舱", "无情地", "末尾", "會為", "小黄", "红外", "桐原", "第二段", "鲜奶油", "哈比人", "焦炭", "索伦", "renee", "媲美", "博伊", "戴爾", "盖勒", "火场", "面包机", "方尖碑", "小儿", "酥皮", "妇孺", "半死不活", "whores", "冲澡", "斯内普", "电视新闻", "接地", "美籍", "jacks", "息怒", "δ", "机械化", "不死心", "砂", "鞋店", "追兵", "跳上来", "實家", "麻美", "whitmore", "還沒來", "杜利", "金门", "登山者", "山脚下", "晴子", "坚定不移", "自告奋勇", "凱撒", "白银", "杀人不眨眼", "announced", "毛伊", "十有八九", "词典", "洄", "iii", "文身", "booked", "yell", "发信", "出窍", "巴恩", "人全", "坐视", "送上去", "养殖", "撇", "預料", "做何", "摇曳", "落井下石", "指挥家", "这点儿", "titties", "罗摩", "gently", "马诺", "特林", "科学技术", "简单明了", "贤狼", "很巧", "营里", "小椿", "光溜溜", "水声", "现场报导", "小铃", "theta", "ramos", "二头肌", "sworn", "花些", "luna", "各式", "自杀身亡", "bohm", "禁制令", "富家", "occasion", "摩天轮", "bisschen", "扮演着", "梅铎", "傳遞", "临癘", "美好生活", "attacking", "雀鹰", "古董店", "雄心壮志", "静下心来", "青豆", "察", "还记", "各州", "teachers", "脑电波", "病理", "会进", "科蒂", "青菜", "toe", "在所难免", "爵爷", "酋長", "浓郁", "狮群", "crunch", "水电", "我滴", "真知", "骡", "最老", "恥辱", "马可斯", "祝你成功", "肩部", "彼尔汗", "太感謝", "回扣", "杂乱", "特攻", "一百八十", "meghna", "性事", "进修", "昆斯", "甘油", "青色", "借机", "犯病", "警車", "神勇", "受限", "木卫三", "居民区", "出洋相", "祈愿", "仁兄", "特迪", "发仔", "受累", "萨满", "膝下", "随时奉陪", "冠稱", "这见", "选得", "真琴", "指日可待", "而家", "义和团", "撵走", "凤姐", "美丽动人", "只许", "mount", "撒过", "圖片", "热舞", "紧凑", "活尸", "愿人", "岂能", "nyle", "持有者", "熟女", "会因", "弹道导弹", "惡意", "闪避", "空控", "不周", "坑洞", "卡塞尔", "蝉", "moron", "cjc", "时雄", "hannan", "开家", "弗雷斯", "伯利恒", "失踪者", "会起", "informant", "铁头", "军令", "攻克", "划桨", "拦不住", "消防栓", "韦克斯勒", "dreamed", "click", "浑", "葛瑞丝", "呱", "日向", "黄铜", "码线", "奎斯特", "繁体", "容身", "帕米拉", "曉", "根肋骨", "来开", "大麦", "mari", "有风", "撮", "看走眼", "遗留下来", "bothering", "毕沙罗", "诚心诚意", "坦诚相待", "阿努", "摄像师", "情郎", "诉求", "希腊文", "恕罪", "浪荡", "米色", "controlled", "根深蒂固", "礤", "花莲", "钻进去", "较真", "gale", "婉转", "プ", "一蹶不振", "收買", "不发", "试点", "时薪", "波罗的海", "懒人", "血亲", "掃描", "复数", "有权有势", "religion", "捌", "围起来", "眼红", "芝湖", "淡出", "巡抚", "自然资源", "较劲", "功勞", "凑热闹", "说老实话", "演艺事业", "停船", "掛", "老鸨", "记得住", "跳槽", "海鸟", "八爪", "有客", "德伯", "产出", "两班", "杨家", "沒禮貌", "预付款", "锈", "伺机", "个人隐私", "背离", "疑难杂症", "週六", "lockdown", "bi", "seed", "你许", "走钢丝", "恩点", "离过婚", "生命安全", "幫幫忙", "杰勒德", "遂", "叙利亚人", "天上飞", "shocked", "熊仔俠", "rains", "违禁", "路费", "arya", "两圈", "注視", "布袋", "bells", "鬼佬", "预报", "scat", "之屋", "newton", "金波", "风凉话", "兩倍", "业余爱好", "车恩尚", "爱德华多", "goran", "萨顿", "拉乌", "带出", "employee", "功臣", "凯子", "有礼", "berlin", "睁一只眼", "猶太", "塞迪", "redllne", "势必", "心律", "崔普", "ikabula", "還我", "終身", "greta", "上野", "暴龙蛋", "殖民者", "推他", "蹄", "persons", "染发", "大款", "见上帝", "装车", "幼年", "婶", "布娃娃", "美極", "那什麼", "樂队", "加价", "第一本", "overnight", "西洋棋", "無疑", "大计", "我仅", "急死了", "黏住", "玛克辛", "苦战", "相見", "摩拉", "会费", "血汗钱", "分段", "你加", "姐们", "拖后腿", "胸骨", "别向", "beck", "某羽", "抠门", "不交", "嘴角", "廟", "遍体鳞伤", "siren", "allie", "真家伙", "寿星", "光線", "說定", "莎侬", "制伏", "shaking", "亚戈", "农", "declared", "cousins", "哈巴狗", "后撤", "地鼠", "feds", "赔上", "只留", "creation", "mona", "朴鲁圭", "起得", "关塔那摩", "心想事成", "守旧", "馀", "gg", "放声", "彬", "messenger", "元音", "庆功宴", "恨之入骨", "靠邊", "所願", "諒", "新发明", "开裂", "藍伯特", "ﾋ", "一千五", "酒囊饭袋", "感化院", "兔肉", "亚伯特", "外型", "一尊", "摩利", "败诉", "坐监", "一隊", "果果", "利剑", "新鲜感", "早該", "植物园", "vamos", "反动", "就餐", "任何迹象", "说动", "react", "少点", "海冰", "一醉方休", "小惠", "地检", "虾子", "爱默生", "cynthia", "巴拉克", "民主党人", "蚕", "劳顿", "gen", "億元", "ssr", "应许", "渔业", "麻省", "盲眼", "底牌", "沫", "艾米麗", "老頭子", "令人羡慕", "门将", "保留地", "排气", "三等", "laser", "助兴", "叙叙旧", "brazil", "冻坏", "作伪证", "难保", "装进去", "战果", "老早", "環節", "没写", "carmela", "史派", "中选", "加农炮", "裁掉", "君上", "爭吵", "雷波", "駆", "贤", "返乡", "屈尊", "心腹", "tot", "罗夫", "glove", "我發", "美国国会", "terrorists", "roads", "stackhouse", "信以为真", "花火", "收费站", "恐吓信", "週一", "那使", "不知去向", "孕", "fingerprints", "conner", "喪失", "欲罢不能", "anyways", "航空局", "hardy", "worship", "好多天", "他定", "萨罗", "自闭", "embarrassed", "決鬥", "对立面", "mud", "斯奈德", "bhaiyyaji", "他問", "阿一", "阿云", "哈雅", "和好如初", "武士刀", "bottles", "第一把", "糊里糊涂", "要換", "陪著", "别介", "宗教仪式", "远走", "康涅狄格", "mcbride", "丈母娘", "半自动", "赌神", "防水布", "triple", "奥娜", "英理", "比利时人", "贪吃", "manuel", "赚了钱", "评断", "压在", "janine", "買下", "直行", "珠宝商", "傳送", "梵语", "自食其力", "鱼头", "舞男", "岛崎", "老说", "熔炉", "不见不散", "帝皇", "答辩", "干麻", "变卦", "黑娃", "哀号", "發音", "餐后", "跳来跳去", "灵界", "平凡人", "空话", "亚耶", "分化", "超高", "要定", "核准", "挤进", "社交生活", "戰鬥機", "包法利", "controls", "刘邦", "亦然", "drank", "四點", "台前", "摆在首位", "lizzy", "考夫", "寡不敌众", "換句", "放空", "顺便去", "定居点", "幼鲸", "做秀", "我梦里", "太長", "sunrise", "傑瑞", "powell", "石棉", "尼奇", "instinct", "充其量", "斯里兰卡", "傑作", "reservation", "mutual", "布鲁图", "实惠", "小曲", "大连", "中風", "絕不", "影響力", "写点", "国库", "車的", "惊悚", "封建", "wohl", "communications", "斗鸡", "靳", "deer", "掐住", "窝心", "哐", "公款", "明灯", "童話", "重修", "韩信", "名稱", "公共关系", "prophet", "梑", "遊客", "扫描器", "紧缩", "阿墨", "性无能", "克林格", "還沒死", "极点", "正當", "堇", "商学院", "相约", "祭壇", "奢求", "熊宝宝", "七层", "當晚", "姑奶奶", "稱稱", "列侬", "章程", "飞出", "走多远", "爆掉", "人爱", "fargo", "踢死", "抗辩", "geez", "罗切斯特", "戴娜", "jocelyn", "小狼", "還有點", "多样", "啞巴", "lovers", "毫不在意", "神经错乱", "高过", "预告片", "敗", "改名字", "湯川", "二十五万", "收錢", "viele", "鲁朴", "地过", "澤澤", "军事力量", "正合", "filthy", "搬开", "人手不足", "蓬", "锋", "眼科", "她還", "jung", "白兰度", "冰天雪地", "送出", "酒庄", "越南战争", "充电器", "谈得", "开外", "撂", "癞蛤蟆", "奇奇怪怪", "鸣笛", "阿富汗人", "逼得", "买醉", "再者", "fled", "女超人", "calendar", "次级", "三度", "順風", "竟有", "洒水", "小满", "javadi", "他演", "耍帅", "nephew", "攒钱", "重新分配", "mimi", "附在", "ripped", "渡蜜月", "温情", "苦心", "锁匠", "商界", "落实", "方向感", "葆", "攻入", "臉頰", "时来", "我脚", "贝尼托", "自助餐厅", "大洲", "毫不在乎", "拖慢", "风笛", "能贏", "手頭", "堂口", "鏡", "情况有变", "rajpal", "吉它", "镀", "本席", "編號", "幸福美满", "弄碎", "leute", "出界", "反之", "拉出", "终归", "断路器", "蓝尼", "僧", "斯黛拉", "冻得", "tancredi", "营部", "枫叶", "再说下去", "folk", "含意", "解剖学", "拔刀", "眼色", "奥创", "崔利", "著什麼", "自責", "西点军校", "有伴", "剪发", "第二张", "掀翻", "虚惊一场", "那東西", "dieser", "俗世", "美色", "約束", "压得", "wheels", "運輸", "威尔科", "犹", "佛蒙特", "多苦", "沏", "刚帝士", "鸟笼", "布希", "觕", "這看", "五成", "hadassah", "前些天", "误判", "庭", "几回", "社的", "六条", "无多", "取消资格", "萨萨", "mame", "火线", "学科", "蠕动", "狗儿", "皮耶罗", "floating", "laying", "莱诺", "兑", "百货商店", "天里", "身下", "家母", "埃尔斯", "ﾒ", "左右为难", "許還", "染红", "forty", "drill", "金银财宝", "aisle", "美国联邦调查局", "斯塔尔", "shrek", "議會", "焦油", "他管", "试运行", "不為", "朴实", "向右走", "欠钱", "现代人", "裡頭", "shark", "保安局", "勃勃", "路卡", "听令", "没忘", "黑鸟", "finlay", "溱", "伤残", "英男", "莱娜", "卡妙", "空无一物", "刑侦", "完成使命", "电单车", "rear", "费拉", "鱼汤", "reform", "独享", "外傷", "引誘", "阿喀琉斯", "生存者", "格洛克", "五周", "巴斯蒂安", "直言不讳", "猜出来", "小凯", "干上", "陷进", "大锤", "温度计", "空房子", "自创", "第一队", "公立", "免去", "無故", "比鲁斯", "发电站", "希克", "操劳", "该会", "era", "泽村", "愚蠢地", "孙儿", "黏液", "导航员", "魂灵", "反对党", "syd", "他发", "蛮横", "冲水", "樞木", "波库", "拥抱着", "能演", "乖女", "我整", "羞于", "睫毛膏", "利亚斯", "大半辈子", "写过信", "統統", "备注", "輸掉", "大屋", "填表", "shanti", "深更半夜", "新手机", "angelo", "云宝", "快生了", "便携式", "冒出", "本應", "年來", "乱打", "普雷斯", "长洲", "现形", "童鞋", "提克", "横向", "背脊", "bela", "大刀", "wallet", "斗不过", "早年", "一声不响", "戒子", "lovin", "sheryl", "得名", "天边", "庆功", "关岛", "招妓", "deaf", "倒点", "大发慈悲", "航法", "耗时", "小青", "咬了一口", "始作俑者", "生根", "砸开", "数次", "清朝", "complaint", "直斗", "上行", "棋局", "minnie", "副社长", "此种", "墨西哥湾", "口碑", "避一避", "要過", "baratheon", "蛋糕店", "sherry", "sources", "咖啡屋", "纪念馆", "较为", "略知一二", "nanny", "試鏡", "翩翩", "瘦子", "嘴裡", "又称", "停一停", "金银", "hay", "加勒比", "窒", "盌", "里维", "炮艇", "带离", "泥沼", "寻思", "憐憫", "协和", "retired", "理所应当", "兰博", "人力资源", "血栓", "通红", "烘干", "针灸", "那樣子", "喝高", "转盘", "吴俐珍", "高特", "活见鬼", "出逃", "早會", "tribe", "医嘱", "整得", "wiley", "造个", "爱爱", "communicate", "聋哑人", "托斯卡", "limited", "手巾", "公平竞争", "姬莎", "靜脈", "海君", "broad", "thumb", "戰略", "第二幕", "远航", "误伤", "刺破", "事人", "马基", "支部", "諾特", "打广告", "甲醛", "二字", "缺什么", "屌丝", "扔出来", "乖宝宝", "休伯特", "fin", "蟹黄", "摇摇晃晃", "夏绿特", "慎重考虑", "有肉", "expose", "台湾人", "hee", "年龄段", "islands", "羽衣", "沃尔沃", "华氏度", "一睹", "美国银行", "安道尔", "想像得到", "挺会", "中死", "男高音", "我包", "利安", "wildlife", "santos", "想當", "招呼客人", "舞妓", "尊称", "违禁品", "倒胃口", "补课", "ideal", "avenue", "姜饼", "棉被", "计分", "片甲不留", "toss", "嘟囔", "车型", "他並", "兵卫", "ginn", "fndfmarugothic", "百里", "直属", "exercise", "算进去", "可当", "仪表板", "阿娇", "电机", "異性", "克里克", "陰暗", "fedora", "patsy", "sire", "铺天盖地", "回顧", "航速", "祝酒词", "殺光", "richards", "闭关", "認輸", "擺平", "葛雷格", "戏码", "药师", "kimi", "躺椅", "包烟", "polite", "分水岭", "逆行", "趁此机会", "stavros", "打过架", "汉字", "触怒", "cohle", "见分晓", "更差", "調情", "站不稳", "撞擊", "哈灵顿", "男女关系", "喝奶", "瓦托", "疼疼", "求人", "共同语言", "hut", "阿娜", "莫尔斯", "纺织", "好丑", "watanabe", "小文", "列克", "global", "一仗", "痴情", "诊疗", "盖德", "betsy", "档案馆", "官网", "预产期", "事理", "坡道", "挺身", "赶在", "阿尔布", "政府军", "budget", "別擋", "拉宾", "古物", "篇章", "足立", "停飞", "蒙眼", "中继站", "印第", "停步", "法例", "皮波", "上浮", "马尼拉", "眼前一亮", "蓝星", "倉", "恩祖", "抢到", "核战争", "右拐", "一字", "演奏家", "馏", "傷亡", "lizzie", "sos", "能弹", "拉托夫", "hosts", "边疆", "万股", "瞑目", "上长", "提包", "kit", "男声", "borrowed", "structure", "留名", "輻射", "drops", "人证", "凯夫", "戻", "地质学", "伯勒", "担保人", "我愛他", "上访", "好后", "飙", "锄头", "肖像画", "闲暇", "他行", "體面", "白头", "润色", "丁克", "多摩", "避雨", "迷彩", "容颜", "几针", "cried", "山猫", "白金汉", "雞蛋", "封閉", "印地语", "目中无人", "沙威", "乘机", "翻来覆去", "学监", "有何不妥", "酒桶", "聪明才智", "marcy", "結實", "十日", "inches", "厌食症", "李欧", "医科", "金融危机", "沉默不语", "有备而来", "実", "不见踪影", "禀告", "气枪", "今非昔比", "andrews", "里外", "塔勒", "春节", "神志", "黑锅", "桑杰", "arrangements", "trucks", "操场上", "佛林特", "舍监", "天蝎座", "revealed", "没工夫", "passes", "法外", "之士", "帕里斯", "账簿", "贝尔格", "大写", "萦绕在", "lick", "臨床", "苏丝", "丹娜", "往右边", "唐诺", "niece", "良心发现", "负有责任", "金手指", "秋葵", "放开手", "再赢", "网址", "riot", "这堂", "学坏", "小雞", "伊斯兰堡", "甲壳虫", "事得", "thrill", "伤风", "cort", "挪动", "還跟", "棺", "美春", "脏乱", "毛绒", "穷苦", "榭", "小毛毛", "奥列格", "桂冠", "胀", "赫米", "冠冕堂皇", "唱唱", "洛普", "车后", "国事", "眈", "金曲", "一阵风", "处有", "fais", "篋", "傻丫头", "闯过", "大爱", "没前途", "哈克斯", "吊唁", "方休", "保镳", "毛片", "areyou", "惡心", "古惑仔", "他命", "痸", "二天", "窗簾", "桂", "克隆人", "马拉喀什", "寶藏", "戏班", "性急", "制约", "土著人", "窺", "占有欲", "阿蟀", "你毀", "阿珠", "未解", "爱到", "没商量", "卑鄙无耻", "amc", "动真格的", "費利", "老九", "风流韵事", "护卫舰", "chibs", "重大新闻", "豆芽", "渡海", "打蜡", "大胜", "闪烁着", "二千万", "与其说", "希利", "報到", "测谎仪", "处女座", "无法弥补", "达琳", "罗勒", "哪一個", "这番", "尽失", "瑞士人", "cultural", "眼角", "暴虐", "application", "决胜", "试听", "commitment", "境", "要管", "festival", "高阶", "这队", "满腔", "水淹", "插进来", "丝绒", "钻牛角尖", "捕捞", "收录", "澳門", "signature", "诱", "萨曼塔", "短命", "舖", "pixie", "路德维希", "卡波", "ehome", "村長", "时刻表", "非常低", "血战", "翘曲", "參加過", "老色鬼", "铁球", "千钧一发", "tick", "阿欣", "舅母", "器官移植", "嚇唬", "碑文", "神经元", "杻", "针刺", "給我個", "對手", "开恩", "砍树", "会考", "入党", "叫喊声", "我們終", "吃饭时间", "無所", "滯", "康奈利", "举例来说", "重中之重", "金毛", "凯丝", "总统府", "天城", "纳斯卡", "applause", "阵风", "motherfuckers", "扣掉", "espn", "蒙着", "磕药", "injury", "白衬衫", "血腥味", "山姆大叔", "香蕉皮", "持有人", "指掌", "撑起", "队服", "私心", "hooch", "阵雨", "神神秘秘", "奸情", "locke", "排水管", "答话", "ﻁ", "奏鸣曲", "之友", "sheets", "崎", "lapd", "跌入", "要数", "rely", "防卫厅", "暨", "min", "诱捕", "corn", "星门", "鐘內", "殉情", "悍妇", "就定", "燴", "陰", "pinky", "辛辣", "染料", "真金", "特拉弗斯", "shipping", "色素", "艾弗里", "无所适从", "哈利法克斯", "推算", "麻醉枪", "知识产权", "蘇菲", "udinov", "共渡", "通俗", "泡个", "欢欣", "市江", "抓痕", "驶来", "一百多年", "菲拉", "deserved", "锂", "小洞", "诸脑", "马太", "五层", "緇", "期中考试", "意饺", "bjarne", "愛過", "塞米", "stinson", "最底层", "说得过去", "决裂", "地下通道", "几世纪", "radar", "主题公园", "阿丽亚娜", "洗胃", "gegen", "兴高采烈", "特尼", "却会", "班恩", "難題", "诱骗", "decade", "eep", "hunger", "豬頭", "培恩", "麻辣", "着眼于", "假动作", "反過", "幽谷", "睡眠不足", "哈尔西", "皮爾斯", "tops", "寻人启事", "传下去", "多管", "悔过", "display", "氣死", "法军", "服務生", "那船", "燉", "webster", "满溢", "突入", "谋求", "埃里森", "转舵", "luis", "小约翰", "nygaard", "崇子", "人面", "新货", "firing", "敞篷", "nada", "yu", "吾王", "换回来", "举足轻重", "挖到", "耕地", "哈姆林", "变样", "dolly", "喊停", "拉得", "大街小巷", "老牌", "傻到", "两万五", "彼此之间", "朝鲜战争", "零錢", "cursed", "可取", "年轻一代", "上个", "十诫", "匙", "荣华富贵", "大度", "摸不到", "安姬", "之翼", "isabelle", "礼拜三", "独角", "勒曼", "武藤", "史基", "海龙", "植被", "任一", "預期", "别到", "李斯", "应门", "风雪", "那用", "老妇", "碳酸", "那像", "分校", "刚进", "compression", "同夥", "林德伯格", "mira", "押运", "那马", "防部", "參考", "會帶", "faithful", "游击队员", "滑雪板", "衾", "特拉维夫", "死有余辜", "摇摆不定", "剎車", "霍姆", "瓦罗", "忧心忡忡", "阿甘", "颤栗", "小強", "難民", "申", "funding", "益浩", "歇一会", "古德温", "duluth", "初恋情人", "真累", "条鱼", "茱迪", "戴假发", "别踢", "有会", "屍", "弗曼", "治治", "阿敏", "奥里", "一字不差", "那出", "排气管", "藍隊", "依附", "monkeys", "弹球", "证监会", "高频", "扯开", "causing", "六角", "全中", "一快", "玲珑", "张画", "四成", "先有", "所杀", "paracelsus", "一命呜呼", "莫斯坦", "马蒂尼", "澄", "咄", "游水", "那丫头", "第一页", "爸来", "宾至如归", "cheated", "逃回", "卿卿我我", "stefano", "按原", "在此之后", "elephant", "ballard", "约翰内斯堡", "谦", "其父", "sheng", "科贝特", "太硬", "工事", "阿捷", "映像", "這倒", "口讯", "我省", "塌下来", "异次元", "抵赖", "发哥", "利刃", "兵马", "艾格", "好几千", "一月份", "逃亡者", "大古", "laundry", "河内", "他覺", "伊卡", "手足无措", "言喻", "兒科", "探头", "加奶", "弄钱", "志同道合", "plankton", "washing", "卖车", "触发器", "追捧", "他算", "compare", "近路", "斗气", "三樓", "我馬", "雄介", "fiance", "寫給", "特西", "客场", "怀了孕", "inappropriate", "unhappy", "charlene", "醉成", "計時", "升旗", "gambling", "脑膜炎", "إ", "剧目", "自动化", "没帮", "clubs", "釋", "approaching", "苏军", "睡床", "洪柱", "男同", "superior", "切除术", "不合身", "收件人", "下列", "壊", "克什米尔", "痞", "盛名", "圣莫尼卡", "无以", "女修道院", "貨物", "前門", "不可救药", "撤军", "小点心", "紀", "作业本", "理查兹", "芔", "裡了", "搞了个", "求职", "吹捧", "吁", "第二队", "订下", "parked", "极寒", "整體", "屏", "泰伦斯", "测出", "博文", "纵火犯", "花丛", "troubles", "第三阶段", "shinwell", "端木", "便于", "脱口而出", "千尺", "谈吐", "添麻煩", "動脈", "kjeii", "妃子", "套索", "东厂", "王道", "叽叽喳喳", "萬元", "人革联", "自作多情", "罚球", "事故现场", "衣子", "帧", "把頭", "去逛", "凯顿", "拼盘", "三间", "谢罪", "tennis", "josef", "要將", "jewels", "国宝", "必要性", "够近", "熱狗", "蛮族", "筳", "联邦军", "醉得", "朱廉", "高额", "拿件", "甘草", "元朗", "方格", "保险费", "完人", "旗号", "不站", "开怀", "支撐", "相吻合", "叮咚", "劳动者", "晕眩", "秀美", "奥斯威辛", "惦", "畊", "上半场", "蒼白", "禽流感", "zhi", "小黛", "brent", "催眠术", "多汗", "第一波", "拼圖", "刪", "馈赠", "接龙", "痘痘", "得益", "maximum", "cooperate", "咱去", "泰瑞莎", "慈", "教過", "传得", "lannisters", "罗曼诺夫", "每座", "易于", "別用", "三千年", "海岛", "夜市", "没事找事", "加點", "评选", "wagon", "damien", "加在一起", "嘶嘶声", "凡尔赛", "前段时间", "ashes", "noelle", "弗朗兹", "两度", "浮肿", "sis", "兰考", "如是说", "我谈", "电码", "hannibal", "监视系统", "蛤帝", "unfortunate", "十步", "wrist", "再算", "音樂家", "佛雷", "清道夫", "whispering", "宿敌", "当红", "孩", "脚踢", "打胜仗", "不敢苟同", "大大小小", "振翅", "二十元", "操守", "celebrity", "搬动", "湿婆", "倾家荡产", "嫌多", "内伤", "柊", "rihanna", "緹", "光有", "採用", "raina", "内心世界", "提亲", "警察署", "別太", "極了", "阿丽雅", "我治好", "尿片", "坎伯", "儿科", "奥丽", "壮汉", "争相", "吐槽", "jed", "爆笑", "晨", "售价", "頭痛", "深埋", "塔德", "阿乐", "突突", "goddess", "機槍", "烂片", "何求", "人均", "平反", "陶", "岱", "塔莎", "打水", "多地", "不嫉妒", "lattimer", "一石二鸟", "武美", "萨博", "好困", "技", "莫洛", "拼出来", "kristin", "緋聞", "花樣", "沃多", "熱愛", "重装", "分秒必争", "约尔", "水野", "敬禮", "归属感", "understands", "蔻", "谱写", "克里斯托夫", "consciousness", "铺上", "气阀", "菸", "一滴水", "強行", "绿草", "接驳", "拉文", "内克", "没钱买", "斯皮尔斯", "效用", "硷", "我讀", "冤家", "八千万", "两百五十", "骗钱", "不劳而获", "卡通人物", "打贏", "好辣", "musst", "史帝芬", "烏龜", "飢渴", "来份", "共匪", "墜入", "harlan", "最赞", "科伊", "這呢", "wonders", "那顶", "好人家", "玮", "蛇毒", "想求", "床單", "英雄救美", "西风", "童谣", "来历不明", "臣妾", "全景", "别上", "porn", "幕僚", "八十岁", "item", "我起", "ganzel", "還留", "万法郎", "重出江湖", "娘養", "越长越", "rocking", "罗勃", "情理", "百科", "io", "病原体", "crashed", "吹风机", "探探", "医务兵", "机会难得", "親眼", "agenda", "伯曼", "我得接", "實上", "卫生巾", "泷川", "八条", "穆尼", "但事", "发威", "眉", "清淡", "領養", "不愁", "紧追", "纠葛", "逝", "特務", "住持", "棒球场", "搪塞", "sucked", "讲求", "预备队", "本傑明", "定个", "周而复始", "和蔼可亲", "公寓楼", "艾勒", "索罗斯", "栏目", "管理处", "深喉", "抬出去", "废掉", "吐掉", "特是", "上花", "尔克", "breast", "一空", "朝著", "johnse", "gerade", "春山", "罗姆尼", "康奈尔", "往年", "暴食", "何何", "肯顿", "negotiate", "搞什", "婆子", "姜老師", "光纤", "逾越", "夹板", "伊果", "媳婦", "罗伦", "主義的", "秒杀", "佳代", "下楼来", "江戶", "列举", "僧人", "波哥", "云顿", "骏马", "佳肴", "海泽尔", "luc", "睡懒觉", "白白的", "定价", "出國", "grandson", "塔尼亚", "chelsea", "还跟着", "维持秩序", "小聲點", "晾干", "哥俩", "推下", "赌金", "沙士", "装神弄鬼", "冗长", "稱弧", "猠", "埃布", "鸟鸣", "诈欺", "貮", "同盟国", "未见", "沉溺", "满怀希望", "allies", "付之一炬", "nde", "两三次", "圣恩", "甘特襄", "盲女", "怠", "鬚", "抽掉", "比助", "反物质", "恐", "赋", "司令员", "桑福德", "花圈", "霍比特", "经济衰退", "人贩子", "冲掉", "马森", "哭鼻子", "州际", "初八", "聞起", "螞蟻", "恭敬", "签上", "奥路菲", "分數", "winds", "毕拿", "新闻稿", "總理", "里布", "斯是", "多家", "祓", "逃进", "述说", "日以继夜", "滑轮", "耳膜", "老照片", "eileen", "系统故障", "只值", "房间内", "中亚", "服务区", "篏", "elisabeth", "调试", "光之城", "zac", "民国", "活动室", "纱枝", "道听途说", "德叔", "mag", "全罗道", "大寿", "枪上", "洗好", "托姆", "生物武器", "救世", "鸣谢", "凯尔特", "鼬", "copies", "bmw", "雷内", "人满为患", "着重", "混口饭吃", "夹着尾巴", "柳德米拉", "revolutionary", "遭天", "订制", "绝密文件", "副校长", "aww", "輕時", "海湾战争", "苦楚", "能助", "进房", "第一流", "会卖", "多米尼加", "胁持", "手拿着", "数以", "莱茵", "alvin", "满上", "伊萨克", "奇草", "走快", "胡德", "鬼城", "再談", "哈林", "采样", "tinke", "speltzer", "压缩机", "一付", "门诊", "东大", "臉上", "美知", "philipp", "山村", "明日之星", "欧文斯", "jews", "移植手术", "居住地", "穿墙", "炙手可热", "陡", "指挥塔", "小虾", "没换", "钱够", "华夫", "透漏", "白内障", "区有", "利厄", "战力", "陆军部", "德加", "小王", "胖墩", "那包", "玩水", "storage", "小樱", "史戴芬", "妈蛋", "三圈", "调度员", "香菜", "下一话", "recognition", "咨詢", "道长", "摔碎", "皮帶", "亮度", "吉赛", "孪生", "栋梁", "南军", "可恥", "舞技", "利奥波德", "工艺品", "冷掉", "放飞", "尔夫人", "他肯", "颂扬", "sting", "十名", "黄眼", "噎着", "公干", "布雷顿", "orlando", "别学", "一尺", "众目睽睽", "检控官", "沙里", "investigating", "釣", "eun", "变差", "heavily", "绕路", "律师协会", "各位朋友", "它闻", "定型", "心形", "版图", "霉菌", "viens", "德雷斯", "勒令", "頂級", "amigo", "问卷", "荷叶", "dismissed", "association", "震慑", "奔腾", "inner", "俗语", "每颗", "說句", "八楼", "上將", "駕駛員", "米粉", "拉迪斯", "怪怪", "思維", "复健", "细雨", "贝克汉姆", "体罚", "colleague", "可人儿", "mendoza", "盐酸", "奴婢", "那个游戏", "items", "親熱", "flags", "韧带", "罗贝尔", "狮子狗", "德雷珀", "五金", "感慨", "莱丽", "蠄", "kern", "阿玉", "明白人", "艾薇尼", "oops", "硝化甘油", "半身", "關進", "好好先生", "swords", "和约", "痛风", "令人钦佩", "会宰", "louder", "半兽人", "爬进", "说瞎话", "醜聞", "買家", "忙些", "澳洲人", "赤城", "万宝路", "砥", "meets", "射手网", "解决之道", "受損", "爸要", "含着", "三联", "连体", "归位", "妄图", "veer", "梢", "两万五千", "不承認", "车要", "麦卡伦", "先抓", "一百万元", "报仇雪恨", "绞架", "一文不名", "generations", "太难受", "一伙儿", "七嘴八舌", "疩", "尊夫人", "积攒", "数学老师", "kaplan", "大水", "platt", "得夠", "结伴", "掛了", "杜瓦尔", "潛力", "faut", "前一阵子", "變種", "孩提", "悬而未决", "塞戈", "近些", "treating", "繁榮", "丧事", "滅絕", "科瑞", "大劲", "幸会幸", "旧车", "個個", "改变命运", "麦克拉", "阻击", "leland", "井然有序", "十强", "斧", "何尝", "转台", "花蕾", "loses", "刷刷", "麦兜", "遭人", "好歌", "战斧", "诬告", "明哥", "velcoro", "买一送一", "台长", "买条", "relieved", "function", "充满热情", "爬虫类", "剛從", "克莱斯勒", "slash", "eiiing", "籃", "嚴禁", "confidential", "科尼岛", "五角大厦", "两匹马", "中量级", "母狮", "翻墙", "坐会", "几万", "別浪費", "别无所求", "奥德萨", "springs", "那死", "诫", "海耶斯", "cs", "爱比", "我校", "担起", "有创造力", "exhausted", "vanished", "高龄", "裝滿", "拟", "邦联", "吹灭", "海床", "越线", "罗特", "雅娜", "轟炸", "没见识", "该亚法", "绝交", "要花点", "yash", "入海", "铁塔", "家谱", "言表", "硝烟", "misunderstanding", "拧下来", "綟", "苏州", "螺母", "盧卡", "中彈", "风靡", "入怀", "异国情调", "dunbar", "每队", "我會用", "邀约", "藏毒", "菲克", "augustine", "弱肉强食", "warriors", "腹腔", "几千人", "爱能", "商业化", "氣體", "好来", "禁果", "骗取", "在政治上", "历时", "祕", "加兰", "笹", "寻人", "留步", "wilcox", "不了了之", "怕水", "comrade", "嚇得", "損害", "掺杂", "requested", "vada", "印第安纳波利斯", "女色", "第三排", "unable", "伏尔泰", "神人", "scenario", "地貌", "赫希", "食道", "世熙", "不领情", "天龙", "hbo", "傳到", "外侧", "活体", "索夫", "试管", "覆盆子", "加莱", "奇奇", "斯塔夫", "紧盯", "疍", "俄罗斯语", "饱满", "右方", "缔造", "据为己有", "harsh", "亂語", "集合点", "一體", "利爪", "崔伊", "車手", "我帶", "脱脂", "次子", "aqu", "中性", "埃伯霍夫", "强烈要求", "卓别林", "用過", "霍爾登", "linked", "历法", "随它", "起锚", "琉南", "梅姬", "格兰瑟姆", "狐步", "幼时", "双头", "集會", "公共电话", "不洁", "dwarf", "驳船", "遣散费", "叛乱分子", "罗南", "几月", "grug", "论坛报", "斯塔特", "失业率", "瑅", "barb", "携", "飞黄腾达", "月夜", "摇铃", "新版", "尿急", "穿帮", "好帮手", "汉江", "gratitude", "意在", "alternative", "离席", "dolan", "毫不费力", "紅衛兵", "表达能力", "collapse", "巴拉巴", "buzz", "牛皮", "爱莉丝", "拍戲", "救命稻草", "打飞", "后巷", "莎丽", "高二", "弃置", "第纳尔", "陷在", "行骗", "怕人", "全要", "每周五", "陬", "涂抹", "变白", "的門", "flynt", "必会", "三亿", "射手座", "小毛头", "我后", "三队", "半神", "阅历", "鉊", "巨变", "足智多谋", "玲玉", "撈", "美味佳肴", "密切注意", "康乃馨", "介绍信", "特爾", "盲肠", "parce", "谈钱", "skunk", "麻吉", "禽獸", "十方", "burst", "用户名", "nigel", "想吸", "把車", "离境", "单是", "恶龙", "按规定", "犯罪心理", "votre", "誤解", "艾莲", "针线", "哲理", "儀器", "父亲节", "楝", "vicious", "埃特", "小群", "值得纪念", "拉米雷斯", "停播", "polish", "ritual", "尘归尘", "大打出手", "先拍", "便盆", "feast", "hause", "朱塞佩", "乱飞", "真言", "新房", "slaughter", "这则", "烦不烦", "彻底搜查", "平常人", "kimberly", "twins", "孔子", "看守所", "组了", "法律责任", "報答", "silk", "逾期", "渲染", "扑倒", "但用", "vault", "屠龙", "俯身", "龙瑟姆", "淘", "殡葬", "关键问题", "grows", "basketball", "spongebob", "触须", "临界点", "贱种", "irving", "彬彬有礼", "獄", "發光", "轉換", "慢速", "阿朗", "外婆家", "顺心", "原子核", "钟情", "职能", "崔妮蒂", "了給", "每况愈下", "氧氣", "為定", "做时", "stepping", "有情人", "女式", "室里", "butcher", "专业知识", "十一点半", "弗丽达", "亏本", "点唱机", "守株待兔", "秘訣", "乌克兰人", "嘈", "四溅", "香腸", "谈下", "未知数", "隔膜", "屙", "酒驾", "武汉", "梅甘", "此片", "pad", "中山", "撒哈拉", "lex", "大减价", "鲸鲨", "警察厅", "標", "战衣", "开瓶", "经期", "觉察", "世玉", "necessarily", "过歉", "混杂", "溺毙", "坑道", "参拜", "自怜", "降压", "迪亚斯", "推卸责任", "德温特", "quarters", "彰显", "退潮", "逃避现实", "開來", "全归", "拖时间", "劇終", "matilda", "大饼", "啼", "爱巢", "电视广告", "講得", "缩头乌龟", "駛", "第一家", "领走", "divx", "可想", "克雷默", "掩盖真相", "多個", "克鲁索", "丹顿", "sheet", "脓包", "塞族", "因维人", "突襲", "西斯科", "奉陪到底", "買些", "三具", "十小时", "團聚", "奇迹般地", "大規模", "神在", "顿号", "寻欢", "照实", "dressing", "收費", "fo", "platform", "智取", "小龙虾", "要输", "芦苇", "带钱来", "安朵", "皚", "小卒", "塔诺", "content", "波塞冬", "火里", "輸入", "阿基拉", "超帅", "beard", "花俏", "六日", "privilege", "改变方向", "eroll", "展覽", "oklahoma", "隔離", "玛西", "戳穿", "压垮", "米老鼠", "連你", "阿毛", "教育部", "經歷過", "真心实意", "弃明投暗", "负重", "sicher", "有仇", "horsemen", "大四", "灼烧", "哪樣", "fairly", "這更", "自有办法", "赖以生存", "洗过澡", "oldest", "滥用职权", "抢购", "敲诈勒索", "主旨", "好点没", "首爾", "磁石", "师部", "严格说来", "發動機", "钱要", "版税", "л", "辿", "香阪", "anse", "课外活动", "肯帮", "手下人", "漱口水", "药材", "這杯", "后世", "春梦", "民眾", "黑侠", "艺术展", "节点", "渝", "vanua", "化工厂", "这裹", "直布罗陀", "meiner", "記", "剪輯", "炒肝", "任天堂", "熟客", "去換", "媲", "姜姜", "六只", "说一说", "铤而走险", "言出必行", "talented", "粮仓", "嶄", "connections", "拍点", "出镜", "没路", "房钱", "葛底斯堡", "皇太后", "腐肉", "題", "白蘭地", "一跃", "小火", "最红", "zen", "guten", "碲", "整艘", "智囊", "不明不白", "手摸", "吃零食", "焦虑症", "slut", "正带", "太软", "producer", "松果", "蚌", "完颜", "船里", "chrissy", "suspected", "马斯克", "可行性", "旧货", "火柴盒", "左側", "у", "当地政府", "多蠢", "muy", "塔布", "房中", "勞斯", "留不住", "新罕布什尔", "打醒", "主干道", "覆蓋", "milky", "示弱", "架设", "绝活", "春田", "石匠", "夸夸其谈", "傑爾比昂", "重燃", "惹祸上身", "中锋", "peut", "sybil", "conduct", "美娜", "欣然接受", "大理寺", "座机", "微积分", "声调", "kidnapping", "养子", "马堤", "核试验", "正牌", "专卖店", "难以承受", "擴大", "生龙活虎", "或否", "白死", "bacon", "塔伯特", "maester", "hillary", "科布", "處罰", "衱", "northern", "一上", "element", "完会", "魁梧", "乱逛", "酵母", "布拉莫", "尼龙", "二十分", "情况危急", "哼唱", "再花", "退还", "ditch", "西里", "食尸", "耳洞", "chapter", "zoey", "mistaken", "叫个", "vietnam", "不太懂", "gigi", "甘甜", "调过来", "博卡", "输液", "怨念", "大君", "太神", "輪椅", "程子", "斟酌", "casa", "鐘前", "在建", "刻着", "痛击", "凯希", "化学药品", "好孤单", "压下去", "皮球", "elequent", "看樣子", "罗曼蒂克", "宋恩彩", "gt", "海德里希", "法尔科内", "數到", "夷平", "点要", "东柏林", "翘辫子", "白兰", "轻罪", "检官", "覆辙", "欧姆", "水痘", "連累", "船員", "硕大", "马改", "力不从心", "博人", "图样", "力氣", "羊绒", "罗林", "犯不着", "人管", "阿雷", "乱闯", "打拳击", "纳布", "标牌", "藏得", "嫁不出去", "這不關", "殓", "细路", "希律", "counsel", "蒂默", "女巨人", "一說", "麻花", "冬马", "rolled", "椅上", "蓝眼", "主廚", "介生", "灯亮了", "nicely", "虚荣心", "一百二十", "死死的", "isles", "kang", "苛求", "田民", "割腕", "ruiz", "熟透", "头昏", "阿雷路亚", "神保", "教坏", "punish", "filed", "拿開", "國安局", "死脑筋", "最高峰", "跑啦", "导", "讲到", "真事", "gonzalez", "拜神", "罗宋汤", "毯", "targaryen", "功成名就", "冲入", "trudy", "潘朵拉", "椭圆", "醉人", "slap", "陓", "中土", "烧饭", "剥落", "拔牙", "佳佳", "beckett", "预审", "装不下", "這艘", "人间地狱", "孪生兄弟", "聲稱", "destination", "色诱", "不悦", "drown", "剃须", "男厕", "头壳", "烟枪", "打字员", "荒郊野外", "journeys", "washed", "ktv", "特罗夫", "南朝鲜", "減肥", "油嘴滑舌", "說現", "考虑看看", "观察者", "gong", "纳瑟", "測驗", "死人头", "画外音", "谢谢合作", "摇钱树", "布劳恩", "失戀", "邀请卡", "贤妻", "亲子鉴定", "真厲害", "barking", "上周日", "drowning", "正中间", "弱势", "特指", "paws", "小威", "首度", "斯米", "赫尔利", "globe", "莎宾娜", "数学课", "krieg", "路牌", "robby", "借到", "twelve", "景仰", "limits", "婆罗洲", "斯芬克斯", "養活", "滿滿", "变压器", "从零开始", "冤屈", "茅坑", "轻笑", "便行", "麥克風", "stack", "逆流", "套上", "chadwick", "油桶", "音像店", "大粪", "渡過", "眉目", "想以", "全灭", "人力资源部", "歌舞片", "案發", "頭盔", "女侠", "同房", "节骨眼", "聼", "每周三", "吃货", "funds", "麦尔", "奥诺玛", "ultimate", "夫妻俩", "杰丝", "收服", "由不得", "可达", "平方英尺", "诺贝尔", "没卖", "个澡", "瓊", "襄", "問起", "刚买", "一大帮", "膠", "梨花", "理工", "拉到", "珍珠项链", "未满", "samples", "todo", "乐观主义", "敲钟", "自家人", "可控", "星爷", "外皮", "内部消息", "报恩", "找家", "乱猜", "变回来", "二樓", "disagree", "笔友", "expansion", "leather", "丹波桥", "外景", "威吓", "火之歌", "宪章", "沃特森", "宴会厅", "dewey", "华侨", "暗藏", "名分", "玩死", "某物", "lem", "fairies", "冷汗", "布法罗", "流媒体", "legitimate", "jeans", "单行道", "einstein", "巴比特", "自來", "広", "灾变", "sniper", "反对票", "逼人", "缩影", "开罐器", "肋排", "云梯", "當場", "蹲大牢", "冒风险", "不争气", "天主教堂", "市议员", "半吊子", "visa", "appeared", "瑞琪", "佛朗哥", "奶水", "受到感染", "框框", "小老婆", "hatte", "體重", "按压", "parole", "strings", "messner", "三味线", "之舞", "tedward", "摸过", "贾法尔", "明目张胆", "tous", "心願", "鎮定", "journalist", "iraq", "默许", "儿歌", "seeking", "過人", "美联航", "焚化炉", "大事儿", "lousy", "誘餌", "特姆", "太窄", "飞进", "冒泡", "槍聲", "呆板", "社交活动", "tai", "葉", "过界", "大肠", "全明星", "天朝", "temps", "用做", "失言", "pale", "调包", "allende", "繪畫", "不计后果", "卡达", "不太远", "质数", "使点", "首映式", "首阳", "华尔街日报", "科学院", "combination", "具体位置", "赠予", "孤家寡人", "towel", "西山", "ravens", "骷髅头", "卵石", "三部曲", "哈珊", "講的", "想入非非", "批评家", "相互信任", "manners", "billie", "della", "伺服器", "战栗", "洪熙官", "钦", "勁兒", "chao", "locate", "行天", "会签", "这床", "麗子", "信賴", "种地", "棕榈泉", "乖乖女", "裂纹", "脚上", "maze", "exception", "名画", "wanker", "交付给", "一無", "mgm", "专案", "摩洛", "大声嚷嚷", "dealt", "pourquoi", "航天局", "sherman", "超车", "excalibur", "两段", "矿产", "暴龙", "真覺", "hush", "利亞", "戰隊", "胃部", "探路", "cult", "浩介", "海威", "随风飘", "唱功", "本份", "笹垣", "darryl", "同花顺", "留级", "埋掉", "地方法院", "doakes", "佐伯", "检控", "看球", "聚集地", "康恩", "全貌", "傑康", "失传", "科索沃", "索波诺", "哆嗦", "搭公车", "正大光明", "annual", "抄本", "氮莱", "拉塔", "cue", "肥大", "希奇", "给力", "五行", "一跤", "recognized", "泡面", "挪威人", "hooli", "frankly", "水喝", "两招", "翻腾", "教書", "刮脸", "二选", "turk", "阿修", "很窄", "不能自拔", "布莱迪", "切爾", "粘到", "好搭档", "第一台", "戴斯蒙", "ㄥ", "mothers", "pj", "法学", "修学", "看顾", "改道", "海托華", "上架", "副将", "心儿", "冉阿让", "其名", "兴奋不已", "调派", "猿猴", "科泰", "急呀", "瑌", "haus", "我天", "林登", "躲不了", "人生目标", "akeela", "掩人耳目", "姿色", "wreck", "套件", "短波", "开心起来", "轿子", "狼来了", "mccluskey", "opera", "moz", "收據", "雅虎", "輿", "密语", "對抗", "爬虫", "praise", "本剧", "不入流", "有車", "aussi", "reg", "再大", "托运", "透析", "真可憐", "車嗎", "重头戏", "铃儿", "弁", "令人费解", "原盘", "害成", "雷蒙娜", "科菲", "附送", "小品", "四座", "论者", "灾民", "弗瑞德", "斯特森", "记恨", "真不简单", "下城", "个儿", "柯文", "shoulders", "几支", "波斯湾", "招揽", "放宽", "留個", "伤患", "人山人海", "receiving", "贺礼", "无声无息", "关羽", "腹痛", "分会", "礼拜四", "赢下", "之妻", "亚美尼亚", "死不瞑目", "貝拉", "按个", "快门", "比上", "逗乐", "奥妙", "弼", "梅莉莎", "胯", "mei", "敬语", "那破", "海战", "確有", "冥王", "海賊", "骑兵队", "精简", "西部片", "三四天", "筹集资金", "御用", "malvo", "逆风", "alphahff", "lightning", "琴弦", "闯荡", "樂園", "苏利", "单打独斗", "awfully", "頬", "翻白眼", "霓虹灯", "查尔顿", "念珠", "缝起来", "编了", "刘先生", "dia", "赞誉", "良民", "席维", "里屋", "凶悍", "小鼠", "真象", "jun", "试飞", "超负荷", "quote", "女明星", "邁克", "稀饭", "博因顿", "全岛", "哪是", "曼斯菲尔德", "slayer", "alton", "開得", "追著", "准点", "污迹", "小破", "螫", "多言", "狙击步枪", "抄写", "选歌", "水花", "為什", "菲佛", "guitar", "洒落", "趁火打劫", "连击", "职场", "仿", "多带", "效益", "空门", "混合体", "没赢", "信函", "周详", "氯仿", "狼姐", "传家宝", "做官", "atoms", "convincing", "网格", "晚到", "时好时坏", "重整旗鼓", "baghdad", "派斯", "拍谢", "失守", "詹尼", "反目", "养鸡", "結了", "戈壁", "幾位", "得学", "给点钱", "命丧", "黑麦", "brandy", "心机", "两发", "紫月", "認定", "收银台", "杭柏特", "forests", "违抗命令", "几部", "ey", "牧村", "那请", "心有灵犀", "调酒师", "核电站", "东征", "酿造", "那該", "感言", "哈伍德", "书记员", "自由选择", "一動", "旧式", "悉心", "百万年", "土里", "prostitute", "没弄", "会员卡", "表层", "白来"];

  // src/background/prefilter.ts
  var MAX_CJK_WORD = 4;
  var CJK = /[\u4e00-\u9fff]/;
  var LATIN_TRIM = /^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu;
  var DIGITS_ONLY = /^\p{N}+$/u;
  var SOURCES = {
    zh_cn: known_zh_cn_default,
    en: known_en_default
  };
  var ranks = new Map;
  function normalizeLang(language) {
    const bare = (language || "").toLowerCase().split(/[-_]/)[0];
    if (bare === "zh" || bare === "chinese")
      return "zh_cn";
    if (bare === "en" || bare === "english")
      return "en";
    return null;
  }
  function rankMap(lang) {
    const cached = ranks.get(lang);
    if (cached)
      return cached;
    const words = SOURCES[lang];
    if (!words)
      return null;
    const map = new Map;
    for (let i = 0;i < words.length; i++) {
      const word = words[i];
      if (!map.has(word))
        map.set(word, i + 1);
    }
    ranks.set(lang, map);
    return map;
  }
  function cjkTokens(text, known) {
    const out = [];
    let i = 0;
    while (i < text.length) {
      const char = text[i];
      if (!CJK.test(char)) {
        i += 1;
        continue;
      }
      let matched = "";
      for (let len = Math.min(MAX_CJK_WORD, text.length - i);len >= 2; len--) {
        const candidate = text.slice(i, i + len);
        if (known.has(candidate)) {
          matched = candidate;
          break;
        }
      }
      out.push(matched || char);
      i += matched.length || 1;
    }
    return out;
  }
  function latinTokens(text) {
    return text.split(/\s+/).map((w) => w.replace(LATIN_TRIM, "").toLowerCase()).filter(Boolean);
  }
  function rareTokens(text, inputLanguage2, knownRank, outputLanguage2, recent = []) {
    const trimmed = (text || "").trim();
    if (!trimmed)
      return [];
    const seenRecently = new Set;
    for (const word of recent)
      seenRecently.add(word.toLowerCase());
    const lang = normalizeLang(inputLanguage2);
    if (!lang)
      return null;
    const known = rankMap(lang);
    if (!known)
      return null;
    const inputScript = scriptOfLanguage(inputLanguage2);
    const outputScript = scriptOfLanguage(outputLanguage2);
    const tokens = lang === "zh_cn" ? cjkTokens(trimmed, known) : latinTokens(trimmed);
    if (tokens.length === 0)
      return null;
    const rare = [];
    const seen = new Set;
    for (const token of tokens) {
      if (DIGITS_ONLY.test(token))
        continue;
      if (inputScript !== outputScript && isOutputScript(token, inputScript))
        continue;
      if (seenRecently.has(token.toLowerCase()))
        continue;
      const rank = known.get(token);
      if (rank != null && rank <= knownRank)
        continue;
      if (seen.has(token))
        continue;
      seen.add(token);
      rare.push({ token, rank: rank ?? Number.MAX_SAFE_INTEGER });
    }
    return rare.sort((a, b) => b.rank - a.rank).map((r) => r.token);
  }
  function hasRareToken(text, inputLanguage2, knownRank, outputLanguage2, recent = []) {
    const rare = rareTokens(text, inputLanguage2, knownRank, outputLanguage2, recent);
    return rare === null || rare.length > 0;
  }
  function isOutputScript(token, inputScript) {
    if (inputScript === "han")
      return !CJK.test(token);
    return CJK.test(token);
  }

  // src/background/ReverseGlosser.ts
  var log4 = createLogger("reverse");
  var LATIN_WORD = /[A-Za-z\u00c0-\u024f][A-Za-z\u00c0-\u024f'’-]*/g;
  var HAN = /[\u4e00-\u9fff]/;

  class ReverseGlosser {
    session;
    onWords;
    inFlight = false;
    pending = null;
    recent = new Map;
    constructor(session, onWords) {
      this.session = session;
      this.onWords = onWords;
    }
    consider(text, settings, utteranceId) {
      if (!reverseApplies(settings))
        return false;
      const fallback = fallbackWords(text, settings, this.recentKeys(Date.now()));
      if (fallback.length === 0)
        return false;
      if (this.inFlight) {
        this.pending = { text, utteranceId };
        diagnostics.increment("reverse.coalesced");
        return true;
      }
      this.run(text, settings, utteranceId);
      return true;
    }
    reset() {
      this.pending = null;
      this.recent.clear();
    }
    async run(text, settings, utteranceId) {
      this.inFlight = true;
      diagnostics.increment("reverse.requests");
      const eligibleAt = Date.now();
      const result = await requestGloss(this.session, {
        conversationContext: text,
        inputLanguage: outputLanguage(settings),
        outputLanguage: inputLanguage(settings),
        fluencyLevel: settings.proficiency,
        recentWords: this.recentKeys(eligibleAt),
        purpose: "reverse",
        knownRank: settings.reverseKnownRank,
        maxWords: tunable("reverseMaxWords")
      }, { eligibleAt, queueReason: "none", trigger: "final", utteranceId });
      this.inFlight = false;
      if (result.ok) {
        const now = Date.now();
        const shown = [];
        for (const word of result.data.words) {
          const key = bare(word.word);
          const last = this.recent.get(key);
          if (last && now - last < tunable("wordDedupMs"))
            continue;
          this.recent.set(key, now);
          shown.push({ ...word, at: now, direction: "reverse" });
        }
        diagnostics.increment("reverse.words", shown.length);
        log4.info("reverse gloss applied", { returned: result.data.words.length, shown: shown.length });
        if (shown.length > 0)
          this.onWords(shown);
      } else {
        diagnostics.increment("reverse.errors");
        log4.warn("reverse gloss failed", { message: result.message });
      }
      const next = this.pending;
      this.pending = null;
      if (next)
        this.run(next.text, settings, next.utteranceId);
    }
    recentKeys(now) {
      for (const [word, at] of this.recent) {
        if (now - at > tunable("wordDedupMs"))
          this.recent.delete(word);
      }
      return [...this.recent.keys()];
    }
  }
  function reverseApplies(settings) {
    if (!settings.reverseGloss || settings.mode === "translation")
      return false;
    const input = scriptOfLanguage(inputLanguage(settings));
    const output = scriptOfLanguage(outputLanguage(settings));
    return input !== "unknown" && output !== "unknown" && input !== output;
  }
  function fallbackWords(text, settings, recent = []) {
    const output = outputLanguage(settings);
    const input = inputLanguage(settings);
    const words = scriptOfLanguage(output) === "latin" ? (text.match(LATIN_WORD) ?? []).join(" ") : [...text].filter((c) => HAN.test(c)).join("");
    if (!words)
      return [];
    const rare = rareTokens(words, output, settings.reverseKnownRank, input, recent);
    if (rare === null)
      return words.split(/\s+/).filter(Boolean);
    return rare;
  }
  function bare(word) {
    return word.toLowerCase().replace(/\s*\([^)]*\)/g, "").trim();
  }

  // src/background/shadowInterim.ts
  var STABLE_MS = 300;
  var GROWTH_CHARS = 6;

  class ShadowInterimDetector {
    tracked = new Map;
    completed = [];
    observe(input) {
      const now = input.now ?? Date.now();
      const text = input.text.trim();
      const existing = this.tracked.get(input.utteranceId);
      if (input.isFinal) {
        if (existing)
          this.complete(input.utteranceId, existing, text, now, input.lastGlossContext);
        this.tracked.delete(input.utteranceId);
        this.prune();
        return;
      }
      if (!existing) {
        this.tracked.set(input.utteranceId, { text, seenAt: now, triggers: {} });
        return;
      }
      if (existing.text !== text) {
        const grown = text.length - input.lastGlossContext.trim().length;
        if (!existing.triggers.growth6 && grown >= GROWTH_CHARS) {
          existing.triggers.growth6 = { at: now, chars: text.length, text };
        }
        existing.text = text;
        existing.seenAt = now;
        return;
      }
      if (!existing.triggers.stable300 && now - existing.seenAt >= STABLE_MS) {
        existing.triggers.stable300 = { at: now, chars: text.length, text };
      }
    }
    drain() {
      if (this.completed.length === 0)
        return [];
      const out = this.completed;
      this.completed = [];
      return out;
    }
    reset() {
      this.tracked.clear();
      this.completed = [];
    }
    complete(utteranceId, tracked, finalText, finalAt, lastGlossContext) {
      for (const [variant, trigger] of Object.entries(tracked.triggers)) {
        this.completed.push({
          utteranceId,
          variant,
          leadMs: Math.max(0, finalAt - trigger.at),
          wouldDuplicate: trigger.text === lastGlossContext.trim(),
          charsAtTrigger: trigger.chars,
          charsAtFinal: finalText.length
        });
      }
      if (this.completed.length > 200)
        this.completed = this.completed.slice(-200);
    }
    prune() {
      if (this.tracked.size <= 20)
        return;
      const ids = [...this.tracked.keys()].slice(0, this.tracked.size - 20);
      for (const id of ids)
        this.tracked.delete(id);
    }
  }

  // src/background/TranscriptBuffer.ts
  var MAX_UTTERANCES = 10;
  var MAX_AGE_MS = 30000;

  class TranscriptBuffer {
    utterances = [];
    nextId = 1;
    push(text, isFinal, language, at = Date.now()) {
      const trimmed = text.trim();
      const last = this.utterances[this.utterances.length - 1];
      if (last && !last.isFinal) {
        last.text = trimmed;
        last.isFinal = isFinal;
        last.language = language;
        last.at = at;
        this.prune(at);
        return last;
      }
      const entry = {
        id: `u${this.nextId++}`,
        text: trimmed,
        isFinal,
        language,
        at
      };
      this.utterances.push(entry);
      this.prune(at);
      return entry;
    }
    context(maxChars = 400) {
      return this.utterances.map((u) => u.text).join(" ").trim().slice(-maxChars);
    }
    clear() {
      this.utterances = [];
    }
    list() {
      return [...this.utterances];
    }
    prune(now) {
      this.utterances = this.utterances.filter((u) => now - u.at <= MAX_AGE_MS);
      if (this.utterances.length > MAX_UTTERANCES) {
        this.utterances = this.utterances.slice(-MAX_UTTERANCES);
      }
    }
  }
  function stripIncompleteLastWord(text) {
    const trimmed = text.trim();
    if (!trimmed)
      return "";
    if (/[.!?。！？；;：:]$/.test(trimmed))
      return trimmed;
    const words = trimmed.split(/\s+/);
    if (words.length <= 1)
      return trimmed;
    return words.slice(0, -1).join(" ");
  }
  function hasSentenceEnd(text) {
    return /[.!?。！？]/.test(text);
  }

  // src/background/GlossEngine.ts
  var log5 = createLogger("engine");
  var LEGACY_GLOSS_COOLDOWN_MS = 2000;
  var UPGRADE_COOLDOWN_MS = 8000;
  var UPGRADE_DRAIN_MS = 5000;
  var MIN_UTTERANCE_CHARS = 4;
  var MIN_CONTEXT_CHARS = 8;

  class GlossEngine {
    session;
    buffer;
    callbacks;
    cache;
    lastGlossAt = 0;
    lastUpgradeAt = 0;
    lastGlossContext = "";
    glossInFlight = false;
    upgradeInFlight = false;
    pending = null;
    pendingTimer = null;
    shadow = new ShadowInterimDetector;
    interimTimer = null;
    interimText = "";
    interimGlossed = null;
    pendingAsrLeadMs = null;
    recent = new Map;
    recentUpgrades = [];
    upgradeQueue = [];
    upgradeTimer = null;
    shownUpgrade = null;
    reverse;
    constructor(session, buffer, callbacks, cache = null) {
      this.session = session;
      this.buffer = buffer;
      this.callbacks = callbacks;
      this.cache = cache;
      this.reverse = new ReverseGlosser(session, (words) => callbacks.onWords(words));
    }
    consider(text, isFinal, settings, utteranceId) {
      if (settings.mode === "translation")
        return isFinal ? "translation_mode" : null;
      const now = Date.now();
      const reversed = isFinal && this.reverse.consider(text, settings, utteranceId);
      if (!utteranceInInputLanguage(text, inputLanguage(settings), outputLanguage(settings))) {
        if (isFinal) {
          if (reversed)
            return "reverse_gloss";
          diagnostics.increment("engine.gloss_skipped.language_mismatch");
          log5.debug("utterance is in the output language; not glossing", { chars: text.trim().length });
          return "skipped_language";
        }
        return null;
      }
      if (utteranceId) {
        this.shadow.observe({ utteranceId, text, isFinal, lastGlossContext: this.lastGlossContext, now });
      }
      if (isFinal) {
        this.clearInterimTimer();
        this.interimText = "";
        if (this.interimGlossed && this.interimGlossed.utteranceId === utteranceId) {
          this.pendingAsrLeadMs = Math.max(0, now - this.interimGlossed.at);
          diagnostics.observe("engine.asrLead", this.pendingAsrLeadMs);
          this.interimGlossed = null;
        }
      } else {
        preconnect();
        if (settings.interimTrigger)
          this.considerInterim(text, settings, utteranceId, now);
      }
      const shouldGloss = shouldQueueGloss({
        text,
        isFinal,
        context: this.buffer.context()
      });
      let disposition = isFinal ? "skipped_short" : null;
      if (shouldGloss)
        disposition = this.queueGloss(settings, now, utteranceId, "final");
      if (settings.wordUpgrades && now - this.lastUpgradeAt >= UPGRADE_COOLDOWN_MS) {
        this.runUpgrade(settings);
      }
      return isFinal ? disposition : null;
    }
    considerInterim(text, settings, utteranceId, now) {
      const trimmed = text.trim();
      if (trimmed.length < MIN_UTTERANCE_CHARS)
        return;
      if (trimmed === this.interimText)
        return;
      this.interimText = trimmed;
      const grown = trimmed.length - this.lastGlossContext.trim().length;
      if (grown >= tunable("interimGrowthChars")) {
        this.clearInterimTimer();
        this.triggerInterimGloss(settings, utteranceId, now);
        return;
      }
      this.clearInterimTimer();
      this.interimTimer = setTimeout(() => {
        this.interimTimer = null;
        this.triggerInterimGloss(settings, utteranceId, Date.now());
      }, tunable("interimStableMs"));
    }
    triggerInterimGloss(settings, utteranceId, now) {
      const disposition = this.queueGloss(settings, now, utteranceId, "interim");
      if (disposition !== "queued_gloss" || !utteranceId)
        return;
      diagnostics.increment("engine.gloss_interim_triggered");
      this.interimGlossed = { utteranceId, at: now };
    }
    clearInterimTimer() {
      if (!this.interimTimer)
        return;
      clearTimeout(this.interimTimer);
      this.interimTimer = null;
    }
    cachedWordsFor(context, settings) {
      if (!this.cache)
        return [];
      const input = inputLanguage(settings);
      const output = outputLanguage(settings);
      const rare = rareTokens(context, input, knownRankFor(settings.proficiency), output, this.recent.keys());
      if (!rare || rare.length === 0)
        return [];
      const budget = Math.max(1, wordRowsFor(settings.mode) - 1);
      const out = [];
      const now = Date.now();
      for (const token of rare) {
        if (out.length >= budget)
          break;
        const last = this.recent.get(bare2(token));
        if (last && now - last < tunable("wordDedupMs"))
          continue;
        const hit = this.cache.get(token, input, output);
        if (hit)
          out.push(hit);
      }
      return out;
    }
    takeAsrLeadMs() {
      const value = this.pendingAsrLeadMs;
      this.pendingAsrLeadMs = null;
      return value ?? undefined;
    }
    drainShadowObservations() {
      return this.shadow.drain();
    }
    currentWords(glossed, settings, now = Date.now()) {
      const maxGloss = wordRowsFor(settings.mode);
      const live = glossed.filter((w) => now - w.at <= tunable("wordTtlMs"));
      const glossRows = live.slice(-maxGloss);
      const upgrade = this.shownUpgrade && now - this.shownUpgrade.at <= tunable("wordTtlMs") ? this.shownUpgrade : null;
      if (!settings.wordUpgrades || !upgrade)
        return glossRows;
      const room = Math.max(0, maxGloss - 1);
      return [...glossRows.slice(-room), upgrade];
    }
    nextExpiry(glossed, settings, now = Date.now()) {
      const shown = this.currentWords(glossed, settings, now);
      if (shown.length === 0)
        return null;
      return Math.min(...shown.map((w) => w.at)) + tunable("wordTtlMs");
    }
    reset() {
      log5.debug("engine reset", {
        recentWords: this.recent.size,
        queuedUpgrades: this.upgradeQueue.length
      });
      diagnostics.increment("engine.resets");
      this.pending = null;
      this.reverse.reset();
      this.shadow.reset();
      this.clearInterimTimer();
      this.interimText = "";
      this.interimGlossed = null;
      this.pendingAsrLeadMs = null;
      this.lastGlossContext = "";
      if (this.pendingTimer) {
        clearTimeout(this.pendingTimer);
        this.pendingTimer = null;
      }
      this.recent.clear();
      this.recentUpgrades = [];
      this.upgradeQueue = [];
      this.shownUpgrade = null;
      if (this.upgradeTimer) {
        clearTimeout(this.upgradeTimer);
        this.upgradeTimer = null;
      }
    }
    queueGloss(settings, eligibleAt, utteranceId, trigger) {
      const context = this.contextForCall(false);
      if (!context) {
        diagnostics.increment("engine.gloss_skipped.no_context");
        return "skipped_short";
      }
      if (context === this.lastGlossContext) {
        diagnostics.increment("engine.gloss_skipped.duplicate");
        return "skipped_duplicate";
      }
      if (!hasRareToken(context, inputLanguage(settings), knownRankFor(settings.proficiency), outputLanguage(settings), this.recent.keys())) {
        diagnostics.increment("engine.gloss_skipped.no_candidates");
        return "skipped_no_candidates";
      }
      if (this.glossInFlight) {
        diagnostics.increment("engine.gloss_coalesced");
        log5.debug("gloss coalesced behind in-flight call", { contextChars: context.length });
        this.pending = { context, eligibleAt, utteranceId, trigger };
        return "queued_gloss";
      }
      const cooldownMs = settings.fastCooldown ? tunable("glossCooldownMs") : LEGACY_GLOSS_COOLDOWN_MS;
      const sinceLast = eligibleAt - this.lastGlossAt;
      const newChars = context.length - this.lastGlossContext.length;
      if (sinceLast < cooldownMs && newChars < tunable("cooldownBypassChars")) {
        diagnostics.increment("engine.gloss_skipped.cooldown");
        log5.debug("gloss suppressed by cooldown", { sinceLast, cooldownMs, newChars });
        return "skipped_cooldown";
      }
      this.runGloss(settings, { context, eligibleAt, utteranceId, trigger }, "none");
      return "queued_gloss";
    }
    async runGloss(settings, attempt, queueReason) {
      const { context } = attempt;
      this.glossInFlight = true;
      this.callbacks.onProcessing(true);
      this.lastGlossAt = Date.now();
      const cached = this.cachedWordsFor(context, settings);
      if (cached.length > 0) {
        diagnostics.increment("cache.hits", cached.length);
        for (const word of cached)
          this.recent.set(bare2(word.word), Date.now());
        this.callbacks.onWords(cached);
      }
      const result = await requestGloss(this.session, {
        conversationContext: context,
        inputLanguage: inputLanguage(settings),
        outputLanguage: outputLanguage(settings),
        fluencyLevel: settings.proficiency,
        recentWords: [...this.recent.keys()]
      }, {
        eligibleAt: attempt.eligibleAt,
        queueReason,
        trigger: attempt.trigger,
        utteranceId: attempt.utteranceId
      });
      this.glossInFlight = false;
      this.callbacks.onProcessing(false);
      this.lastGlossContext = context;
      if (!result.ok) {
        this.callbacks.onBackendError(result.message);
        this.schedulePending(settings, context);
        return;
      }
      this.callbacks.onProfiling(result.data.profiling);
      const now = Date.now();
      this.pruneRecent(now);
      const accepted = [];
      let deduped = 0;
      for (const word of result.data.words) {
        const key = bare2(word.word);
        const last = this.recent.get(key);
        if (last && now - last < tunable("wordDedupMs")) {
          deduped += 1;
          continue;
        }
        this.recent.set(key, now);
        accepted.push({ ...word, at: now });
      }
      if (deduped > 0)
        diagnostics.increment("engine.words_deduped", deduped);
      diagnostics.increment("engine.words_shown", accepted.length);
      this.cache?.remember(accepted, inputLanguage(settings), outputLanguage(settings));
      log5.info("gloss applied", {
        returned: result.data.words.length,
        shown: accepted.length,
        deduped,
        recentTracked: this.recent.size
      });
      if (accepted.length > 0)
        this.callbacks.onWords(accepted);
      if (result.data.profiling.requestId) {
        glossTelemetry.noteRendered(result.data.profiling.requestId);
      }
      this.schedulePending(settings, context);
    }
    schedulePending(settings, justFinished) {
      const next = this.pending;
      if (!next)
        return;
      this.pending = null;
      if (next.context === justFinished || next.context === this.lastGlossContext) {
        diagnostics.increment("engine.gloss_skipped.duplicate");
        return;
      }
      const cooldownMs = settings.fastCooldown ? tunable("glossCooldownMs") : LEGACY_GLOSS_COOLDOWN_MS;
      const wait = Math.max(0, cooldownMs - (Date.now() - this.lastGlossAt));
      const reason = wait > 0 ? "cooldown" : "coalesced";
      if (this.pendingTimer)
        clearTimeout(this.pendingTimer);
      this.pendingTimer = setTimeout(() => {
        this.pendingTimer = null;
        this.runGloss(settings, next, reason);
      }, wait);
    }
    async runUpgrade(settings) {
      if (this.upgradeInFlight)
        return;
      const context = this.contextForCall(true);
      if (!context)
        return;
      this.upgradeInFlight = true;
      this.lastUpgradeAt = Date.now();
      const result = await requestUpgrade(this.session, {
        conversationContext: context,
        inputLanguage: inputLanguage(settings),
        outputLanguage: outputLanguage(settings),
        fluencyLevel: settings.proficiency,
        recentUpgrades: this.recentUpgrades
      });
      this.upgradeInFlight = false;
      if (!result.ok) {
        this.callbacks.onBackendError(result.message);
        return;
      }
      const { word, meaning, profiling } = result.data;
      if (!word || !meaning) {
        diagnostics.increment("engine.upgrade_empty");
        return;
      }
      diagnostics.increment("engine.upgrade_queued");
      this.callbacks.onProfiling(profiling);
      this.recentUpgrades = [...this.recentUpgrades, word, meaning].slice(-12);
      this.upgradeQueue.push({
        word,
        translation: meaning,
        isUpgrade: true,
        at: Date.now()
      });
      this.drainUpgradeQueue();
    }
    drainUpgradeQueue() {
      if (this.upgradeTimer)
        return;
      const next = () => {
        const item = this.upgradeQueue.shift();
        if (item) {
          this.shownUpgrade = item;
          this.callbacks.onWords([]);
        }
        if (this.upgradeQueue.length > 0) {
          this.upgradeTimer = setTimeout(next, UPGRADE_DRAIN_MS);
        } else {
          this.upgradeTimer = null;
        }
      };
      next();
    }
    contextForCall(keepLastWord) {
      const raw = this.buffer.context();
      return keepLastWord ? raw : stripIncompleteLastWord(raw);
    }
    pruneRecent(now) {
      for (const [word, at] of this.recent) {
        if (now - at > tunable("wordDedupMs"))
          this.recent.delete(word);
      }
    }
  }
  function bare2(word) {
    return word.toLowerCase().replace(/\s*\([^)]*\)/g, "").trim();
  }
  function shouldQueueGloss(opts) {
    const current2 = opts.text.trim();
    if (!current2)
      return false;
    if (opts.isFinal) {
      return current2.length >= MIN_UTTERANCE_CHARS || opts.context.trim().length >= MIN_CONTEXT_CHARS;
    }
    return hasSentenceEnd(current2) && stripIncompleteLastWord(current2).length >= MIN_UTTERANCE_CHARS;
  }

  // src/background/locales.ts
  var LOCALES = {
    ar: "ar-SA",
    de: "de-DE",
    en: "en-US",
    es: "es-ES",
    fr: "fr-FR",
    it: "it-IT",
    ko: "ko-KR",
    nl: "nl-NL",
    pt: "pt-BR",
    ru: "ru-RU",
    tr: "tr-TR",
    zh: "zh-CN"
  };
  function toLocale(code) {
    if (code.includes("-"))
      return code;
    return LOCALES[code] ?? code;
  }

  // src/background/settings.ts
  var log6 = createLogger("settings");
  var KEY2 = "linklingo:settings";
  async function loadSettings(session) {
    try {
      const raw = await session.storage.get(KEY2);
      if (!raw) {
        log6.info("no stored settings; using factory defaults", {
          source: DEFAULT_SETTINGS.sourceLanguage,
          target: DEFAULT_SETTINGS.targetLanguage
        });
        return { ...DEFAULT_SETTINGS };
      }
      const parsed = JSON.parse(raw);
      const fromVersion = parsed.schemaVersion ?? 1;
      const next = migrateSettings(parsed);
      if (fromVersion < SETTINGS_SCHEMA_VERSION) {
        diagnostics.increment("settings.migrations");
        log6.info("migrated stored settings", {
          fromVersion,
          toVersion: SETTINGS_SCHEMA_VERSION,
          pairBefore: `${parsed.sourceLanguage ?? "?"}->${parsed.targetLanguage ?? "?"}`,
          pairAfter: `${next.sourceLanguage}->${next.targetLanguage}`
        });
        await saveSettings(session, next);
      }
      return next;
    } catch (err) {
      diagnostics.increment("settings.load_failures");
      log6.error("could not read stored settings; falling back to defaults", { error: err });
      return { ...DEFAULT_SETTINGS };
    }
  }
  async function saveSettings(session, settings) {
    await session.storage.set(KEY2, JSON.stringify(settings));
  }
  function normalizeSettings(settings) {
    const modes = ["gloss", "gloss-captions", "translation"];
    return {
      ...settings,
      schemaVersion: SETTINGS_SCHEMA_VERSION,
      sourceLanguage: settings.sourceLanguage || "zh",
      targetLanguage: settings.targetLanguage || "en",
      proficiency: clamp(settings.proficiency, 0, 100),
      mode: modes.includes(settings.mode) ? settings.mode : "gloss-captions",
      displayLines: clamp(settings.displayLines, 1, HUD_CAPTION_LINES),
      displayWidth: settings.displayWidth === 0 || settings.displayWidth === 2 ? settings.displayWidth : 1,
      reverseGloss: settings.reverseGloss !== false,
      reverseKnownRank: Number.isFinite(settings.reverseKnownRank) ? clamp(Math.round(settings.reverseKnownRank), REVERSE_KNOWN_RANK_LIMITS[0], REVERSE_KNOWN_RANK_LIMITS[1]) : DEFAULT_SETTINGS.reverseKnownRank,
      prefs: cleanPrefs(settings.prefs)
    };
  }
  function cleanPrefs(prefs) {
    if (!prefs || typeof prefs !== "object" || Array.isArray(prefs))
      return {};
    const out = {};
    for (const [key, value] of Object.entries(prefs)) {
      if (!/^[A-Za-z][A-Za-z0-9_]{0,40}$/.test(key))
        continue;
      if (typeof value === "boolean" || typeof value === "string" || typeof value === "number" && Number.isFinite(value)) {
        out[key] = value;
      }
    }
    return out;
  }
  function settingPatch(settings, key, value) {
    if (key.startsWith("prefs.")) {
      const name = key.slice("prefs.".length);
      const next = cleanPrefs({ ...settings.prefs, [name]: value });
      return name in next ? { prefs: next } : null;
    }
    if (!SETTABLE_KEYS.includes(key))
      return null;
    const current2 = DEFAULT_SETTINGS[key];
    if (typeof value !== typeof current2)
      return null;
    return { [key]: value };
  }
  function migrateSettings(parsed) {
    const version = parsed.schemaVersion ?? 1;
    const next = normalizeSettings({ ...DEFAULT_SETTINGS, ...parsed });
    const stillOldDefaultPair = version < SETTINGS_SCHEMA_VERSION && (parsed.sourceLanguage ?? "en") === "en" && (parsed.targetLanguage ?? "zh") === "zh";
    if (stillOldDefaultPair) {
      next.sourceLanguage = "zh";
      next.targetLanguage = "en";
      next.swapDirection = false;
    }
    if (version < 3)
      next.displayLines = HUD_CAPTION_LINES;
    return normalizeSettings(next);
  }
  function clamp(n, min, max) {
    return Math.max(min, Math.min(max, Number.isFinite(n) ? n : min));
  }

  // src/background/translationCache.ts
  var log7 = createLogger("cache");
  var KEY3 = "linklingo:translations";
  var MAX_ENTRIES = 1500;
  function cacheKey(bareWord, inputLanguage2, outputLanguage2) {
    return `${bareWord.toLowerCase()}|${inputLanguage2}|${outputLanguage2}`;
  }

  class TranslationCache {
    session;
    entries = new Map;
    loaded = false;
    dirty = false;
    saveTimer = null;
    constructor(session) {
      this.session = session;
    }
    async load() {
      if (this.loaded)
        return;
      this.loaded = true;
      try {
        const raw = await this.session.storage.get(KEY3);
        if (!raw)
          return;
        const parsed = JSON.parse(raw);
        for (const [key, value] of Object.entries(parsed)) {
          if (value && typeof value.word === "string" && typeof value.translation === "string") {
            this.entries.set(key, value);
          }
        }
        log7.info("translation cache loaded", { entries: this.entries.size });
      } catch (error) {
        diagnostics.increment("cache.load_failures");
        log7.warn("could not read translation cache; starting empty", { error });
      }
    }
    get(bareWord, inputLanguage2, outputLanguage2) {
      const hit = this.entries.get(cacheKey(bareWord, inputLanguage2, outputLanguage2));
      if (!hit)
        return null;
      return { word: hit.word, translation: hit.translation, at: Date.now() };
    }
    remember(words, inputLanguage2, outputLanguage2) {
      for (const word of words) {
        const bare3 = bareWord(word.word);
        if (!bare3 || !word.translation)
          continue;
        const key = cacheKey(bare3, inputLanguage2, outputLanguage2);
        this.entries.delete(key);
        this.entries.set(key, { word: word.word, translation: word.translation, at: Date.now() });
      }
      while (this.entries.size > MAX_ENTRIES) {
        const oldest = this.entries.keys().next().value;
        if (oldest === undefined)
          break;
        this.entries.delete(oldest);
      }
      this.dirty = true;
      this.scheduleSave();
    }
    get size() {
      return this.entries.size;
    }
    scheduleSave() {
      if (this.saveTimer)
        return;
      this.saveTimer = setTimeout(() => {
        this.saveTimer = null;
        this.flush();
      }, 5000);
    }
    async flush() {
      if (!this.dirty)
        return;
      this.dirty = false;
      try {
        await this.session.storage.set(KEY3, JSON.stringify(Object.fromEntries(this.entries)));
      } catch (error) {
        diagnostics.increment("cache.save_failures");
        log7.warn("could not persist translation cache", { error });
      }
    }
  }
  function bareWord(word) {
    return word.replace(/\s*\([^)]*\)/g, "").trim();
  }

  // src/background/LinkLingoController.ts
  var log8 = createLogger("controller");
  var DIAGNOSTICS_INTERVAL_MS = 5000;
  var KEEPALIVE_INTERVAL_MS = 25000;

  class LinkLingoController {
    session;
    settings;
    config = DEFAULT_CONFIG;
    configFetchedAt = 0;
    words = [];
    caption = "";
    translation = "";
    original = "";
    processing = false;
    backend = { status: "idle" };
    profiling = null;
    streamCleanup = null;
    diagnosticsTimer = null;
    keepaliveTimer = null;
    wordExpiryTimer = null;
    uiOpen = false;
    buffer = new TranscriptBuffer;
    display;
    cache;
    engine;
    ui;
    constructor(session) {
      this.session = session;
      this.ui = {
        send: (channel, payload) => this.session.ui.send(channel, payload)
      };
      this.display = new DisplayRenderer(session);
      this.cache = new TranslationCache(session);
      this.engine = new GlossEngine(session, this.buffer, {
        onWords: (incoming) => {
          if (incoming.length > 0) {
            this.words = [...this.words, ...incoming].slice(-6);
          }
          this.refreshWords();
        },
        onProfiling: (profiling) => {
          this.profiling = profiling;
          this.backend = { status: profiling.model === "mock" ? "mock" : "ok" };
          this.ui.send("link:profiling", profiling);
          this.ui.send("link:backend-status", this.backend);
        },
        onBackendError: (message) => {
          if (this.backend.status !== "error" || this.backend.lastError !== message) {
            log8.warn("backend degraded", { message, previous: this.backend.status });
          }
          this.backend = { status: "error", lastError: message };
          this.ui.send("link:backend-status", this.backend);
        },
        onProcessing: (processing) => {
          this.processing = processing;
          this.ui.send("link:processing", { processing });
        }
      }, this.cache);
    }
    async start() {
      const started = Date.now();
      log8.info("session starting", { logLevel });
      this.settings = await loadSettings(this.session);
      this.applyConfig(await loadCachedConfig(this.session));
      this.refreshConfig();
      await this.cache.load();
      log8.info("settings loaded", {
        source: this.settings.sourceLanguage,
        target: this.settings.targetLanguage,
        swap: this.settings.swapDirection,
        mode: this.settings.mode,
        proficiency: this.settings.proficiency,
        upgrades: this.settings.wordUpgrades,
        pinyin: this.settings.pinyinDisplay,
        lines: this.settings.displayLines,
        loadMs: Date.now() - started
      });
      this.display.applySettings(this.settings);
      this.display.showIdle(this.settings);
      this.subscribeStreams();
      this.bindUi();
      this.session.ui.onOpen(() => {
        this.uiOpen = true;
        diagnostics.increment("ui.opens");
        log8.info("webview opened");
        this.ui.send("link:snapshot", this.snapshot());
        this.pushDiagnostics();
      });
      this.startDiagnosticsLoop();
      this.startKeepaliveLoop();
      preconnect(true);
      log8.info("session ready", { startupMs: Date.now() - started });
    }
    refreshWords() {
      const now = Date.now();
      const shown = this.engine.currentWords(this.words, this.settings, now);
      this.display.showWords(shown, this.settings);
      this.ui.send("link:words", shown);
      if (this.wordExpiryTimer) {
        clearTimeout(this.wordExpiryTimer);
        this.wordExpiryTimer = null;
      }
      const expiry = this.engine.nextExpiry(this.words, this.settings, now);
      if (expiry == null)
        return;
      this.wordExpiryTimer = setTimeout(() => {
        this.wordExpiryTimer = null;
        diagnostics.increment("engine.words_expired");
        this.refreshWords();
      }, Math.max(50, expiry - now));
    }
    startDiagnosticsLoop() {
      if (this.diagnosticsTimer)
        return;
      this.diagnosticsTimer = setInterval(() => {
        if (this.uiOpen)
          this.pushDiagnostics();
      }, DIAGNOSTICS_INTERVAL_MS);
    }
    startKeepaliveLoop() {
      if (this.keepaliveTimer)
        return;
      this.keepaliveTimer = setInterval(() => preconnect(), KEEPALIVE_INTERVAL_MS);
    }
    pushDiagnostics() {
      try {
        this.ui.send("link:diagnostics", diagnostics.snapshot());
      } catch (err) {
        this.uiOpen = false;
        log8.debug("diagnostics push failed; assuming webview closed", { error: err });
      }
    }
    bindUi() {
      const on = (channel, handler) => {
        this.session.ui.on(channel, (payload) => handler(payload));
      };
      on("link:request-snapshot", () => {
        this.uiOpen = true;
        this.ui.send("link:snapshot", this.snapshot());
        this.pushDiagnostics();
        if (Date.now() - this.configFetchedAt > CONFIG_STALE_MS)
          this.refreshConfig();
      });
      on("link:set-setting", ({ key, value }) => {
        const partial = settingPatch(this.settings, key, value);
        if (!partial) {
          diagnostics.increment("settings.rejected_remote_key");
          log8.warn("ignored a setting this build cannot change", { key });
          this.ui.send("link:settings-update", this.settings);
          return;
        }
        this.patch(partial);
      });
      on("link:view-request", ({ requestId, screen, query }) => {
        if (!this.config.screens.some((s) => s.id === screen)) {
          this.ui.send("link:view-result", { requestId, ok: false, error: "Unknown screen" });
          return;
        }
        requestView(this.session, screen, query).then((result) => this.ui.send("link:view-result", result.ok ? { requestId, ok: true, view: result.data } : { requestId, ok: false, error: result.message }));
      });
      on("link:set-source-language", ({ language }) => void this.patch({ sourceLanguage: language }));
      on("link:set-target-language", ({ language }) => void this.patch({ targetLanguage: language }));
      on("link:set-swap-direction", ({ swapDirection }) => void this.patch({ swapDirection }));
      on("link:set-proficiency", ({ proficiency }) => void this.patch({ proficiency }));
      on("link:set-mode", ({ mode }) => void this.patch({ mode }));
      on("link:set-word-upgrades", ({ wordUpgrades }) => void this.patch({ wordUpgrades }));
      on("link:set-display-lines", ({ displayLines }) => void this.patch({ displayLines }));
      on("link:set-display-width", ({ displayWidth }) => void this.patch({ displayWidth }));
      on("link:set-word-breaking", ({ wordBreaking }) => void this.patch({ wordBreaking }));
      on("link:set-pinyin-display", ({ pinyinDisplay }) => void this.patch({ pinyinDisplay }));
      on("link:set-interim-trigger", ({ interimTrigger }) => void this.patch({ interimTrigger }));
      on("link:set-fast-cooldown", ({ fastCooldown }) => void this.patch({ fastCooldown }));
      on("link:feedback", ({ requestId, note }) => void this.askAnalyst(requestId, note));
      on("link:clear", () => {
        log8.info("hud cleared by user");
        diagnostics.increment("ui.clears");
        if (this.wordExpiryTimer) {
          clearTimeout(this.wordExpiryTimer);
          this.wordExpiryTimer = null;
        }
        this.words = [];
        this.caption = "";
        this.translation = "";
        this.original = "";
        this.buffer.clear();
        this.engine.reset();
        this.display.clear(this.settings);
        this.ui.send("link:snapshot", this.snapshot());
      });
    }
    applyConfig(config) {
      this.config = config;
      const applied = applyTunables(config.tunables);
      const prefs = cleanPrefs({ ...config.prefDefaults, ...this.settings.prefs });
      this.settings = { ...this.settings, prefs };
      setPrefs(prefs);
      log8.info("config applied", { revision: config.revision, tunables: applied.length, screens: config.screens.length });
    }
    async refreshConfig() {
      this.configFetchedAt = Date.now();
      const result = await requestConfig(this.session);
      if (!result.ok) {
        log8.warn("config fetch failed; keeping the last good copy", { message: result.message });
        return;
      }
      const fresh = validConfig(result.data);
      if (!fresh) {
        diagnostics.increment("config.rejected");
        log8.warn("server config was malformed; keeping the last good copy");
        return;
      }
      if (fresh.revision === this.config.revision)
        return;
      this.applyConfig(fresh);
      await saveConfig(this.session, fresh);
      diagnostics.increment("config.updates");
      if (this.uiOpen)
        this.ui.send("link:snapshot", this.snapshot());
    }
    async patch(partial) {
      const prev = this.settings;
      this.settings = normalizeSettings({ ...this.settings, ...partial });
      if (partial.prefs)
        setPrefs(this.settings.prefs);
      const saveStarted = Date.now();
      try {
        await saveSettings(this.session, this.settings);
        diagnostics.observe("settings.saveMs", Date.now() - saveStarted);
      } catch (err) {
        diagnostics.increment("settings.save_failures");
        log8.error("failed to persist settings", { error: err, changed: Object.keys(partial).join(",") });
      }
      diagnostics.increment("settings.changes");
      log8.info("setting changed", {
        changed: Object.entries(partial).map(([key, value]) => `${key}=${String(value)}`).join(",")
      });
      this.display.applySettings(this.settings);
      const streamChanged = prev.mode !== this.settings.mode || prev.sourceLanguage !== this.settings.sourceLanguage || prev.targetLanguage !== this.settings.targetLanguage || prev.swapDirection !== this.settings.swapDirection;
      if (streamChanged) {
        log8.info("resubscribing streams after settings change", {
          mode: `${prev.mode}->${this.settings.mode}`,
          listening: `${inputLanguage(prev)}->${inputLanguage(this.settings)}`
        });
        this.words = [];
        this.caption = "";
        this.translation = "";
        this.original = "";
        this.buffer.clear();
        this.engine.reset();
        this.display.applySettings(this.settings);
        this.display.showIdle(this.settings);
        this.subscribeStreams();
      }
      this.ui.send("link:settings-update", this.settings);
      this.ui.send("link:snapshot", this.snapshot());
    }
    subscribeStreams() {
      if (this.streamCleanup) {
        try {
          this.streamCleanup();
        } catch (err) {
          log8.warn("stream cleanup threw", { error: err });
        }
        this.streamCleanup = null;
      }
      if (this.settings.mode === "translation") {
        const source = toLocale(inputLanguage(this.settings));
        const target = toLocale(outputLanguage(this.settings));
        try {
          this.streamCleanup = this.session.translation.fromTo(source, target, (data) => {
            this.handleTranslation(data);
          });
          diagnostics.increment("streams.translation_fromTo");
          log8.info("subscribed to translation stream", { source, target });
        } catch (err) {
          diagnostics.increment("streams.translation_fallback");
          log8.error("translation fromTo failed; falling back to target-only", { source, target, error: err });
          this.streamCleanup = this.session.translation.to(target, (data) => this.handleTranslation(data));
        }
        return;
      }
      const language = toLocale(inputLanguage(this.settings));
      try {
        this.streamCleanup = this.session.transcription.forLanguage(language, (data) => {
          this.handleTranscription(data);
        });
        diagnostics.increment("streams.transcription_pinned");
        log8.info("subscribed to transcription stream", { language, mode: this.settings.mode });
      } catch (err) {
        diagnostics.increment("streams.transcription_fallback");
        log8.error("pinned transcription failed; falling back to auto-detect", { language, error: err });
        this.streamCleanup = this.session.transcription.on((data) => this.handleTranscription(data));
      }
    }
    handleTranscription(data) {
      const text = data.text.trim();
      diagnostics.increment(data.isFinal ? "transcription.finals" : "transcription.interims");
      if (data.isFinal) {
        diagnostics.increment("transcription.finalChars", text.length);
        log8.debug("final transcript", {
          chars: text.length,
          language: data.language,
          contextChars: this.buffer.context().length
        });
        if (data.language && data.language !== toLocale(inputLanguage(this.settings))) {
          diagnostics.increment("transcription.language_mismatch");
          log8.warn("transcript language differs from the configured input", {
            got: data.language,
            expected: toLocale(inputLanguage(this.settings))
          });
        }
      }
      const utterance = this.buffer.push(text, data.isFinal, data.language);
      this.caption = text;
      this.display.showCaption(text, data.isFinal, this.settings, this.engine.currentWords(this.words, this.settings));
      this.ui.send("link:caption", { text, isFinal: data.isFinal });
      const disposition = this.engine.consider(text, data.isFinal, this.settings, utterance.id);
      if (data.isFinal && text && disposition) {
        this.recordTranscript(text, data.language, disposition, utterance.id);
      }
    }
    handleTranslation(data) {
      const original = (data.originalText ?? "").trim();
      const translated = data.text.trim();
      diagnostics.increment(data.isFinal ? "translation.finals" : "translation.interims");
      if (data.isFinal) {
        log8.debug("final translation", {
          originalChars: original.length,
          translatedChars: translated.length,
          source: data.sourceLanguage
        });
        if (!translated) {
          diagnostics.increment("translation.empty");
          log8.warn("translation stream returned empty text", { source: data.sourceLanguage });
        }
      }
      const utterance = this.buffer.push(original || translated, data.isFinal, data.sourceLanguage);
      this.original = original;
      this.translation = translated;
      this.display.showTranslation(original, translated, this.settings);
      this.ui.send("link:translation", { original, translated, isFinal: data.isFinal });
      if (data.isFinal && (original || translated)) {
        this.recordTranscript(original || translated, data.sourceLanguage, "translation_mode", utterance.id);
      }
    }
    async askAnalyst(requestId, note) {
      diagnostics.increment("ui.feedback");
      log8.info("feedback submitted", { chars: note.trim().length });
      const result = await requestFeedback(this.session, {
        note,
        settings: {
          inputLanguage: inputLanguage(this.settings),
          outputLanguage: outputLanguage(this.settings),
          proficiency: this.settings.proficiency,
          mode: this.settings.mode
        },
        recentUtterances: this.buffer.list().map((u) => ({ text: u.text, at: u.at, language: u.language })),
        shownWords: this.engine.currentWords(this.words, this.settings),
        recentWords: this.words,
        caption: this.caption,
        translation: this.translation,
        original: this.original
      });
      if (!result.ok) {
        this.ui.send("link:feedback-result", { requestId, ok: false, error: result.message });
        return;
      }
      this.ui.send("link:feedback-result", { requestId, ok: true, analysis: result.data });
    }
    recordTranscript(text, detectedLanguage, disposition, utteranceId) {
      const shadowInterim = this.engine.drainShadowObservations();
      reportTranscript(this.session, {
        text,
        detectedLanguage,
        inputLanguage: inputLanguage(this.settings),
        outputLanguage: outputLanguage(this.settings),
        fluencyLevel: this.settings.proficiency,
        mode: this.settings.mode,
        disposition,
        utteranceId,
        shadowInterim: shadowInterim.length > 0 ? shadowInterim : undefined,
        asrLeadMs: this.engine.takeAsrLeadMs()
      });
    }
    snapshot() {
      return {
        settings: this.settings,
        words: this.engine.currentWords(this.words, this.settings),
        caption: this.caption,
        translation: this.translation,
        original: this.original,
        processing: this.processing,
        backend: this.backend,
        profiling: this.profiling,
        config: this.config
      };
    }
  }

  // src/background/index.ts
  registerMiniapp((session) => {
    new LinkLingoController(session).start();
  });
})();
