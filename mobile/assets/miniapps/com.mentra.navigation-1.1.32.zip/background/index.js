(() => {
  var __create = Object.create;
  var __getProtoOf = Object.getPrototypeOf;
  var __defProp = Object.defineProperty;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  function __accessProp(key) {
    return this[key];
  }
  var __toESMCache_node;
  var __toESMCache_esm;
  var __toESM = (mod, isNodeMode, target) => {
    var canCache = mod != null && typeof mod === "object";
    if (canCache) {
      var cache = isNodeMode ? __toESMCache_node ??= new WeakMap : __toESMCache_esm ??= new WeakMap;
      var cached = cache.get(mod);
      if (cached)
        return cached;
    }
    target = mod != null ? __create(__getProtoOf(mod)) : {};
    const to = isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target;
    for (let key of __getOwnPropNames(mod))
      if (!__hasOwnProp.call(to, key))
        __defProp(to, key, {
          get: __accessProp.bind(mod, key),
          enumerable: true
        });
    if (canCache)
      cache.set(mod, to);
    return to;
  };
  var __commonJS = (cb, mod) => () => (mod || cb((mod = { exports: {} }).exports, mod), mod.exports);
  var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
    get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
  }) : x)(function(x) {
    if (typeof require !== "undefined")
      return require.apply(this, arguments);
    throw Error('Dynamic require of "' + x + '" is not supported');
  });

  // ../../node_modules/.bun/eventemitter3@5.0.4/node_modules/eventemitter3/index.js
  var require_eventemitter3 = __commonJS((exports, module) => {
    var has = Object.prototype.hasOwnProperty;
    var prefix = "~";
    function Events() {}
    if (Object.create) {
      Events.prototype = Object.create(null);
      if (!new Events().__proto__)
        prefix = false;
    }
    function EE(fn, context, once) {
      this.fn = fn;
      this.context = context;
      this.once = once || false;
    }
    function addListener(emitter, event, fn, context, once) {
      if (typeof fn !== "function") {
        throw new TypeError("The listener must be a function");
      }
      var listener = new EE(fn, context || emitter, once), evt = prefix ? prefix + event : event;
      if (!emitter._events[evt])
        emitter._events[evt] = listener, emitter._eventsCount++;
      else if (!emitter._events[evt].fn)
        emitter._events[evt].push(listener);
      else
        emitter._events[evt] = [emitter._events[evt], listener];
      return emitter;
    }
    function clearEvent(emitter, evt) {
      if (--emitter._eventsCount === 0)
        emitter._events = new Events;
      else
        delete emitter._events[evt];
    }
    function EventEmitter() {
      this._events = new Events;
      this._eventsCount = 0;
    }
    EventEmitter.prototype.eventNames = function eventNames() {
      var names = [], events, name;
      if (this._eventsCount === 0)
        return names;
      for (name in events = this._events) {
        if (has.call(events, name))
          names.push(prefix ? name.slice(1) : name);
      }
      if (Object.getOwnPropertySymbols) {
        return names.concat(Object.getOwnPropertySymbols(events));
      }
      return names;
    };
    EventEmitter.prototype.listeners = function listeners(event) {
      var evt = prefix ? prefix + event : event, handlers = this._events[evt];
      if (!handlers)
        return [];
      if (handlers.fn)
        return [handlers.fn];
      for (var i = 0, l = handlers.length, ee = new Array(l);i < l; i++) {
        ee[i] = handlers[i].fn;
      }
      return ee;
    };
    EventEmitter.prototype.listenerCount = function listenerCount(event) {
      var evt = prefix ? prefix + event : event, listeners = this._events[evt];
      if (!listeners)
        return 0;
      if (listeners.fn)
        return 1;
      return listeners.length;
    };
    EventEmitter.prototype.emit = function emit(event, a1, a2, a3, a4, a5) {
      var evt = prefix ? prefix + event : event;
      if (!this._events[evt])
        return false;
      var listeners = this._events[evt], len = arguments.length, args, i;
      if (listeners.fn) {
        if (listeners.once)
          this.removeListener(event, listeners.fn, undefined, true);
        switch (len) {
          case 1:
            return listeners.fn.call(listeners.context), true;
          case 2:
            return listeners.fn.call(listeners.context, a1), true;
          case 3:
            return listeners.fn.call(listeners.context, a1, a2), true;
          case 4:
            return listeners.fn.call(listeners.context, a1, a2, a3), true;
          case 5:
            return listeners.fn.call(listeners.context, a1, a2, a3, a4), true;
          case 6:
            return listeners.fn.call(listeners.context, a1, a2, a3, a4, a5), true;
        }
        for (i = 1, args = new Array(len - 1);i < len; i++) {
          args[i - 1] = arguments[i];
        }
        listeners.fn.apply(listeners.context, args);
      } else {
        var length = listeners.length, j;
        for (i = 0;i < length; i++) {
          if (listeners[i].once)
            this.removeListener(event, listeners[i].fn, undefined, true);
          switch (len) {
            case 1:
              listeners[i].fn.call(listeners[i].context);
              break;
            case 2:
              listeners[i].fn.call(listeners[i].context, a1);
              break;
            case 3:
              listeners[i].fn.call(listeners[i].context, a1, a2);
              break;
            case 4:
              listeners[i].fn.call(listeners[i].context, a1, a2, a3);
              break;
            default:
              if (!args)
                for (j = 1, args = new Array(len - 1);j < len; j++) {
                  args[j - 1] = arguments[j];
                }
              listeners[i].fn.apply(listeners[i].context, args);
          }
        }
      }
      return true;
    };
    EventEmitter.prototype.on = function on(event, fn, context) {
      return addListener(this, event, fn, context, false);
    };
    EventEmitter.prototype.once = function once(event, fn, context) {
      return addListener(this, event, fn, context, true);
    };
    EventEmitter.prototype.removeListener = function removeListener(event, fn, context, once) {
      var evt = prefix ? prefix + event : event;
      if (!this._events[evt])
        return this;
      if (!fn) {
        clearEvent(this, evt);
        return this;
      }
      var listeners = this._events[evt];
      if (listeners.fn) {
        if (listeners.fn === fn && (!once || listeners.once) && (!context || listeners.context === context)) {
          clearEvent(this, evt);
        }
      } else {
        for (var i = 0, events = [], length = listeners.length;i < length; i++) {
          if (listeners[i].fn !== fn || once && !listeners[i].once || context && listeners[i].context !== context) {
            events.push(listeners[i]);
          }
        }
        if (events.length)
          this._events[evt] = events.length === 1 ? events[0] : events;
        else
          clearEvent(this, evt);
      }
      return this;
    };
    EventEmitter.prototype.removeAllListeners = function removeAllListeners(event) {
      var evt;
      if (event) {
        evt = prefix ? prefix + event : event;
        if (this._events[evt])
          clearEvent(this, evt);
      } else {
        this._events = new Events;
        this._eventsCount = 0;
      }
      return this;
    };
    EventEmitter.prototype.off = EventEmitter.prototype.removeListener;
    EventEmitter.prototype.addListener = EventEmitter.prototype.on;
    EventEmitter.prefixed = prefix;
    EventEmitter.EventEmitter = EventEmitter;
    if (typeof module !== "undefined") {
      module.exports = EventEmitter;
    }
  });
  // ../../node_modules/.bun/eventemitter3@5.0.4/node_modules/eventemitter3/index.mjs
  var import__ = __toESM(require_eventemitter3(), 1);

  // ../../mobile/modules/miniapp/dist/envelope.js
  function serializeEnvelope(envelope) {
    return JSON.stringify(envelope);
  }
  function parseEnvelope(raw) {
    if (typeof raw !== "string")
      return null;
    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch {
      return null;
    }
    if (typeof parsed !== "object" || parsed === null)
      return null;
    const obj = parsed;
    if (typeof obj.payload !== "object" || obj.payload === null)
      return null;
    if (obj.requestId !== undefined && typeof obj.requestId !== "string")
      return null;
    return {
      payload: obj.payload,
      requestId: obj.requestId
    };
  }
  function makeRequestId() {
    if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
      return crypto.randomUUID();
    }
    return `req_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
  }

  // ../../mobile/modules/miniapp/dist/globals.js
  function getMentraOSGlobals() {
    if (typeof window === "undefined")
      return {};
    return window.MentraOS ?? {};
  }

  // ../../mobile/modules/miniapp/dist/protocol.js
  var MiniappRequestType;
  (function(MiniappRequestType2) {
    MiniappRequestType2["CONNECT"] = "miniapp_connect";
    MiniappRequestType2["AUTH_REFRESH"] = "miniapp_auth_refresh";
    MiniappRequestType2["SUBSCRIBE"] = "miniapp_subscribe";
    MiniappRequestType2["DISPLAY"] = "miniapp_display";
    MiniappRequestType2["RENDER"] = "miniapp_render";
    MiniappRequestType2["PLAY_AUDIO"] = "miniapp_play_audio";
    MiniappRequestType2["STOP_AUDIO"] = "miniapp_stop_audio";
    MiniappRequestType2["SPEAK"] = "miniapp_speak";
    MiniappRequestType2["SPEAKER_STREAM_OPEN"] = "miniapp_speaker_stream_open";
    MiniappRequestType2["SPEAKER_STREAM_WRITE"] = "miniapp_speaker_stream_write";
    MiniappRequestType2["SPEAKER_STREAM_CLOSE"] = "miniapp_speaker_stream_close";
    MiniappRequestType2["SPEAKER_STREAM_ABORT"] = "miniapp_speaker_stream_abort";
    MiniappRequestType2["RGB_LED"] = "miniapp_rgb_led";
    MiniappRequestType2["LOCATION_POLL"] = "miniapp_location_poll";
    MiniappRequestType2["CALENDAR_LIST_EVENTS"] = "miniapp_calendar_list_events";
    MiniappRequestType2["NAVIGATION_START"] = "miniapp_navigation_start";
    MiniappRequestType2["NAVIGATION_STOP"] = "miniapp_navigation_stop";
    MiniappRequestType2["NAVIGATION_DEVIATE"] = "miniapp_navigation_deviate";
    MiniappRequestType2["NAVIGATION_SET_WRONG_SIDEWALK"] = "miniapp_navigation_set_wrong_sidewalk";
    MiniappRequestType2["NAVIGATION_SET_SKIP_CROSSINGS"] = "miniapp_navigation_set_skip_crossings";
    MiniappRequestType2["NAVIGATION_GET_STATE"] = "miniapp_navigation_get_state";
    MiniappRequestType2["NAVIGATION_COMPUTE_ROUTE"] = "miniapp_navigation_compute_route";
    MiniappRequestType2["NAVIGATION_REVERSE_GEOCODE"] = "miniapp_navigation_reverse_geocode";
    MiniappRequestType2["NAVIGATION_PLACE_AUTOCOMPLETE"] = "miniapp_navigation_place_autocomplete";
    MiniappRequestType2["NAVIGATION_PLACE_DETAILS"] = "miniapp_navigation_place_details";
    MiniappRequestType2["NAVIGATION_REQUEST_PERMISSION"] = "miniapp_navigation_request_permission";
    MiniappRequestType2["STORAGE_GET"] = "miniapp_storage_get";
    MiniappRequestType2["STORAGE_SET"] = "miniapp_storage_set";
    MiniappRequestType2["STORAGE_DELETE"] = "miniapp_storage_delete";
    MiniappRequestType2["STORAGE_LIST"] = "miniapp_storage_list";
    MiniappRequestType2["STORAGE_CLEAR"] = "miniapp_storage_clear";
    MiniappRequestType2["STORAGE_HAS"] = "miniapp_storage_has";
    MiniappRequestType2["STORAGE_GET_ALL"] = "miniapp_storage_get_all";
    MiniappRequestType2["STORAGE_SET_MULTIPLE"] = "miniapp_storage_set_multiple";
    MiniappRequestType2["STORAGE_FLUSH"] = "miniapp_storage_flush";
    MiniappRequestType2["CAMERA_FOV"] = "miniapp_camera_fov";
    MiniappRequestType2["CAMERA_WARM_UP"] = "miniapp_camera_warm_up";
    MiniappRequestType2["IMU_SET_ENABLED"] = "miniapp_imu_set_enabled";
    MiniappRequestType2["MIC_SET_VAD_ENABLED"] = "miniapp_mic_set_vad_enabled";
    MiniappRequestType2["MIC_SET_LOUDNESS_GATE_ENABLED"] = "miniapp_mic_set_loudness_gate_enabled";
    MiniappRequestType2["SET_WIFI_ADB_STATE"] = "miniapp_set_wifi_adb_state";
    MiniappRequestType2["SHARE"] = "miniapp_share";
    MiniappRequestType2["OPEN_URL"] = "miniapp_open_url";
    MiniappRequestType2["COPY_CLIPBOARD"] = "miniapp_copy_clipboard";
    MiniappRequestType2["DOWNLOAD"] = "miniapp_download";
    MiniappRequestType2["SCAN_QR"] = "miniapp_scan_qr";
    MiniappRequestType2["BLOB_CREATE"] = "miniapp_blob_create";
    MiniappRequestType2["BLOB_WRITE"] = "miniapp_blob_write";
    MiniappRequestType2["BLOB_COMMIT"] = "miniapp_blob_commit";
    MiniappRequestType2["BLOB_ABORT"] = "miniapp_blob_abort";
    MiniappRequestType2["BLOB_GET"] = "miniapp_blob_get";
    MiniappRequestType2["BLOB_LIST"] = "miniapp_blob_list";
    MiniappRequestType2["BLOB_DELETE"] = "miniapp_blob_delete";
    MiniappRequestType2["BLOB_CLEAR"] = "miniapp_blob_clear";
    MiniappRequestType2["BLOB_USAGE"] = "miniapp_blob_usage";
    MiniappRequestType2["BLOB_OPEN_READ"] = "miniapp_blob_open_read";
    MiniappRequestType2["BLOB_READ"] = "miniapp_blob_read";
    MiniappRequestType2["BLOB_CLOSE_READ"] = "miniapp_blob_close_read";
    MiniappRequestType2["BLOB_SET_FROM_URL"] = "miniapp_blob_set_from_url";
    MiniappRequestType2["BLOB_IMPORT"] = "miniapp_blob_import";
    MiniappRequestType2["BLOB_SHARE"] = "miniapp_blob_share";
    MiniappRequestType2["PING"] = "miniapp_ping";
    MiniappRequestType2["TRANSCRIPTION_CONFIG"] = "miniapp_transcription_config";
    MiniappRequestType2["DASHBOARD_CONTENT_UPDATE"] = "miniapp_dashboard_content_update";
    MiniappRequestType2["PHOTO"] = "miniapp_photo";
    MiniappRequestType2["VIDEO_RECORDING_START"] = "miniapp_video_recording_start";
    MiniappRequestType2["VIDEO_RECORDING_STOP"] = "miniapp_video_recording_stop";
    MiniappRequestType2["STREAM_START"] = "miniapp_stream_start";
    MiniappRequestType2["STREAM_STOP"] = "miniapp_stream_stop";
    MiniappRequestType2["MANAGED_STREAM_START"] = "miniapp_managed_stream_start";
    MiniappRequestType2["MANAGED_STREAM_STOP"] = "miniapp_managed_stream_stop";
    MiniappRequestType2["REQUEST_WIFI_SETUP"] = "miniapp_request_wifi_setup";
    MiniappRequestType2["MINIAPPS_LIST"] = "miniapp_apps_list";
    MiniappRequestType2["MINIAPPS_START"] = "miniapp_apps_start";
    MiniappRequestType2["MINIAPPS_STOP"] = "miniapp_apps_stop";
    MiniappRequestType2["ACTION_INVOKE"] = "miniapp_action_invoke";
    MiniappRequestType2["ACTION_RESULT"] = "miniapp_action_result";
    MiniappRequestType2["MEETING_JOIN"] = "miniapp_meeting_join";
    MiniappRequestType2["MEETING_LEAVE"] = "miniapp_meeting_leave";
    MiniappRequestType2["MEETING_END"] = "miniapp_meeting_end";
    MiniappRequestType2["MEETING_SET_MUTED"] = "miniapp_meeting_set_muted";
    MiniappRequestType2["MEETING_UPDATE_VIDEO_SOURCE"] = "miniapp_meeting_update_video_source";
    MiniappRequestType2["MEETING_GET_STATE"] = "miniapp_meeting_get_state";
  })(MiniappRequestType || (MiniappRequestType = {}));
  var MiniappResponseType;
  (function(MiniappResponseType2) {
    MiniappResponseType2["CONNECT_ACK"] = "miniapp_connect_ack";
    MiniappResponseType2["EVENT"] = "miniapp_event";
    MiniappResponseType2["REQUEST_RESULT"] = "miniapp_request_result";
    MiniappResponseType2["CAPABILITIES_UPDATE"] = "miniapp_capabilities_update";
    MiniappResponseType2["VISIBILITY_CHANGE"] = "miniapp_visibility_change";
    MiniappResponseType2["COLOR_SCHEME_CHANGE"] = "miniapp_color_scheme_change";
    MiniappResponseType2["SPEAKER_STATE"] = "miniapp_speaker_state";
    MiniappResponseType2["PERMISSIONS_UPDATE"] = "miniapp_permissions_update";
    MiniappResponseType2["AUTH_UPDATE"] = "miniapp_auth_update";
    MiniappResponseType2["PONG"] = "miniapp_pong";
    MiniappResponseType2["ACTION_CALL"] = "miniapp_action_call";
    MiniappResponseType2["MEETING_STATE"] = "miniapp_meeting_state";
    MiniappResponseType2["WILL_DISCONNECT"] = "miniapp_will_disconnect";
    MiniappResponseType2["ERROR"] = "miniapp_error";
  })(MiniappResponseType || (MiniappResponseType = {}));
  var MiniappStreamType;
  (function(MiniappStreamType2) {
    MiniappStreamType2["BUTTON_PRESS"] = "button_press";
    MiniappStreamType2["TOUCH_EVENT"] = "touch_event";
    MiniappStreamType2["HEAD_POSITION"] = "head_position";
    MiniappStreamType2["ACCEL_DATA"] = "accel_data";
    MiniappStreamType2["GLASSES_BATTERY"] = "glasses_battery";
    MiniappStreamType2["PHONE_BATTERY"] = "phone_battery";
    MiniappStreamType2["GLASSES_CONNECTION"] = "glasses_connection";
    MiniappStreamType2["GLASSES_WIFI"] = "glasses_wifi";
    MiniappStreamType2["TRANSCRIPTION"] = "transcription";
    MiniappStreamType2["TRANSLATION"] = "translation";
    MiniappStreamType2["AUDIO_CHUNK"] = "audio_chunk";
    MiniappStreamType2["VAD"] = "vad";
    MiniappStreamType2["LOCATION_UPDATE"] = "location_update";
    MiniappStreamType2["HEADING_UPDATE"] = "heading_update";
    MiniappStreamType2["NAVIGATION_UPDATE"] = "navigation_update";
    MiniappStreamType2["NAVIGATION_ROUTE"] = "navigation_route";
    MiniappStreamType2["PHONE_NOTIFICATION"] = "phone_notification";
    MiniappStreamType2["PHONE_NOTIFICATION_DISMISSED"] = "phone_notification_dismissed";
    MiniappStreamType2["PHOTO_TAKEN"] = "photo_taken";
    MiniappStreamType2["STREAM_STATUS"] = "stream_status";
  })(MiniappStreamType || (MiniappStreamType = {}));
  var MiniappErrorCode;
  (function(MiniappErrorCode2) {
    MiniappErrorCode2["INVALID_ARGUMENT"] = "INVALID_ARGUMENT";
    MiniappErrorCode2["PERMISSION_NOT_DECLARED"] = "PERMISSION_NOT_DECLARED";
    MiniappErrorCode2["PERMISSION_DENIED"] = "PERMISSION_DENIED";
    MiniappErrorCode2["NOT_IMPLEMENTED"] = "NOT_IMPLEMENTED";
    MiniappErrorCode2["REQUEST_ABORTED"] = "REQUEST_ABORTED";
    MiniappErrorCode2["INTERNAL"] = "INTERNAL";
    MiniappErrorCode2["TTS_TEXT_TOO_LONG"] = "TTS_TEXT_TOO_LONG";
    MiniappErrorCode2["TTS_INVALID_VOICE"] = "TTS_INVALID_VOICE";
    MiniappErrorCode2["TTS_UPSTREAM_ERROR"] = "TTS_UPSTREAM_ERROR";
    MiniappErrorCode2["TTS_LOCAL_UNAVAILABLE"] = "TTS_LOCAL_UNAVAILABLE";
    MiniappErrorCode2["NOT_CONNECTED"] = "NOT_CONNECTED";
    MiniappErrorCode2["NOT_PERMITTED"] = "NOT_PERMITTED";
    MiniappErrorCode2["APP_NOT_FOUND"] = "APP_NOT_FOUND";
    MiniappErrorCode2["APP_NOT_COMPATIBLE"] = "APP_NOT_COMPATIBLE";
    MiniappErrorCode2["ACTION_NOT_FOUND"] = "ACTION_NOT_FOUND";
    MiniappErrorCode2["NO_ACTION_HANDLER"] = "NO_ACTION_HANDLER";
    MiniappErrorCode2["WAKE_FAILED"] = "WAKE_FAILED";
    MiniappErrorCode2["ACTION_TIMEOUT"] = "ACTION_TIMEOUT";
    MiniappErrorCode2["PAYLOAD_TOO_LARGE"] = "PAYLOAD_TOO_LARGE";
    MiniappErrorCode2["BLOB_NOT_FOUND"] = "BLOB_NOT_FOUND";
    MiniappErrorCode2["BLOB_QUOTA_EXCEEDED"] = "BLOB_QUOTA_EXCEEDED";
    MiniappErrorCode2["BLOB_TOO_LARGE"] = "BLOB_TOO_LARGE";
    MiniappErrorCode2["BLOB_HANDLE_INVALID"] = "BLOB_HANDLE_INVALID";
    MiniappErrorCode2["BLOB_WRITE_FAILED"] = "BLOB_WRITE_FAILED";
    MiniappErrorCode2["BLOB_DOWNLOAD_FAILED"] = "BLOB_DOWNLOAD_FAILED";
    MiniappErrorCode2["BLOB_IMPORT_FAILED"] = "BLOB_IMPORT_FAILED";
  })(MiniappErrorCode || (MiniappErrorCode = {}));

  // ../../mobile/modules/miniapp/dist/transport/dispatch.js
  class DispatchTransport {
    constructor() {
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.open_ = false;
    }
    static isAvailable() {
      return typeof globalThis.__dispatch === "function";
    }
    async open() {
      if (!DispatchTransport.isAvailable()) {
        throw new Error("DispatchTransport: __dispatch is not installed on globalThis");
      }
      const g = globalThis;
      g.__mentraDeliverBridgeRaw = (raw) => {
        if (this.messageHandler)
          this.messageHandler(raw);
      };
      this.open_ = true;
    }
    send(raw) {
      if (!this.open_) {
        throw new Error("DispatchTransport: send() before open()");
      }
      const g = globalThis;
      if (typeof g.__dispatch !== "function") {
        this.open_ = false;
        this.disconnectHandler?.("DispatchTransport: __dispatch disappeared");
        return;
      }
      try {
        g.__dispatch("__bridge", "send", JSON.stringify([raw]));
      } catch (e) {
        this.disconnectHandler?.(`DispatchTransport: __dispatch threw: ${String(e)}`);
      }
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      this.open_ = false;
      const g = globalThis;
      if (g.__mentraDeliverBridgeRaw) {
        delete g.__mentraDeliverBridgeRaw;
      }
    }
    isOpen() {
      return this.open_;
    }
  }

  // ../../mobile/modules/miniapp/dist/transport/local-socket.js
  var DEFAULT_URL = "ws://127.0.0.1:8765";

  class LocalSocketTransport {
    constructor(options = {}) {
      this.ws = null;
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.url = options.url ?? DEFAULT_URL;
    }
    async open() {
      if (this.ws && this.ws.readyState === WebSocket.OPEN)
        return;
      if (typeof WebSocket === "undefined") {
        throw new Error("LocalSocketTransport: browser WebSocket global not available");
      }
      await new Promise((resolve, reject) => {
        const ws = new WebSocket(this.url);
        let settled = false;
        const settle = (fn) => {
          if (settled)
            return;
          settled = true;
          fn();
        };
        ws.onopen = () => {
          this.ws = ws;
          settle(() => resolve());
        };
        ws.onerror = (ev) => {
          settle(() => reject(new Error(`LocalSocketTransport: failed to connect to ${this.url}: ${String(ev)}`)));
        };
        ws.onmessage = (ev) => {
          const data = ev.data;
          if (typeof data === "string")
            this.messageHandler?.(data);
        };
        ws.onclose = (ev) => {
          if (this.ws === ws)
            this.ws = null;
          this.disconnectHandler?.(`closed: ${ev.code} ${ev.reason}`);
        };
      });
    }
    send(raw) {
      if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
        throw new Error("LocalSocketTransport: not connected");
      }
      this.ws.send(raw);
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      if (!this.ws)
        return;
      try {
        this.ws.close();
      } catch {}
      this.ws = null;
    }
    isOpen() {
      return !!this.ws && this.ws.readyState === WebSocket.OPEN;
    }
  }

  // ../../mobile/modules/miniapp/dist/transport/mock.js
  var LOG_PREFIX = "[mock-transport]";
  function isMockExplicitlyRequested() {
    if (typeof window === "undefined")
      return false;
    try {
      if (typeof window.location !== "undefined" && window.location.search) {
        const params = new URLSearchParams(window.location.search);
        if (params.get("mentra") === "mock")
          return true;
      }
    } catch {}
    try {
      if (typeof localStorage !== "undefined" && localStorage.getItem("MENTRA_MOCK") === "1") {
        return true;
      }
    } catch {}
    return false;
  }

  class MockTransport {
    constructor(options = {}) {
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.open_ = false;
      this.userId = options.userId ?? "mock-user";
      this.authToken = options.authToken ?? "mock-miniapp-token";
      this.packageName = options.packageName ?? null;
      this.silent = options.silent === true;
      this.configuration = { ...options.configuration ?? {} };
    }
    async open() {
      if (this.open_)
        return;
      this.open_ = true;
      this.log("transport opened (no real host; synthetic responses only)");
    }
    send(raw) {
      if (!this.open_) {
        throw new Error("MockTransport: send() before open()");
      }
      const envelope = parseEnvelope(raw);
      if (!envelope) {
        this.log("dropped unparseable envelope:", raw.slice(0, 200));
        return;
      }
      const payload = envelope.payload;
      const type = payload?.type;
      this.log(`recv ${type ?? "<unknown>"}${envelope.requestId ? ` (rid=${envelope.requestId})` : ""}`);
      switch (type) {
        case MiniappRequestType.CONNECT:
          this.deliverConnectAck(payload);
          return;
        case MiniappRequestType.PING:
          return;
        case MiniappRequestType.SUBSCRIBE:
          return;
        default:
          if (envelope.requestId) {
            this.deliverSyntheticResult(envelope.requestId, type ?? "<unknown>", payload);
          }
          return;
      }
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      if (!this.open_)
        return;
      this.open_ = false;
      this.disconnectHandler?.("MockTransport.close()");
    }
    isOpen() {
      return this.open_;
    }
    deliverConnectAck(connectPayload) {
      const incomingPackage = connectPayload.packageName ?? this.packageName ?? "com.mock.app";
      const ackPayload = {
        type: MiniappResponseType.CONNECT_ACK,
        userId: this.userId,
        packageName: incomingPackage,
        capabilities: null,
        visibility: "foreground",
        colorScheme: "light",
        configuration: { ...this.configuration },
        auth: {
          mentraUserId: this.userId,
          oemId: "mock",
          token: this.authToken,
          expiresAt: Date.now() + 60 * 60 * 1000
        }
      };
      const envelope = { payload: ackPayload };
      this.log(`-> CONNECT_ACK userId=${this.userId} pkg=${incomingPackage}`);
      queueMicrotask(() => this.messageHandler?.(serializeEnvelope(envelope)));
    }
    deliverSyntheticResult(requestId, requestType, requestPayload) {
      const data = syntheticDataFor(requestId, requestType, requestPayload);
      const responsePayload = {
        type: MiniappResponseType.REQUEST_RESULT,
        ok: true,
        data
      };
      const envelope = { payload: responsePayload, requestId };
      this.log(`-> REQUEST_RESULT (rid=${requestId}) synthetic ${requestType}`);
      queueMicrotask(() => this.messageHandler?.(serializeEnvelope(envelope)));
    }
    log(...args) {
      if (this.silent)
        return;
      console.log(LOG_PREFIX, ...args);
    }
  }
  function syntheticDataFor(requestId, requestType, requestPayload) {
    switch (requestType) {
      case MiniappRequestType.CAMERA_FOV: {
        const presetFov = requestPayload.preset === "narrow" ? 82 : requestPayload.preset === "wide" ? 118 : requestPayload.preset === "standard" ? 102 : undefined;
        const fov = typeof requestPayload.fov === "number" ? requestPayload.fov : presetFov ?? 102;
        const roi = requestPayload.roiPosition;
        const roiPosition = roi === "bottom" ? "bottom" : roi === "top" ? "top" : "center";
        return {
          requestId,
          fov,
          roiPosition,
          timestamp: Date.now()
        };
      }
      case MiniappRequestType.PHOTO:
        return {
          photoUrl: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkAAIAAAoAAv/lxKUAAAAASUVORK5CYII=",
          requestId: "mock-photo"
        };
      case MiniappRequestType.RGB_LED:
        return { type: "rgb_led_control_response", state: "success", requestId };
      case MiniappRequestType.LOCATION_POLL:
        return { lat: 37.7956, lng: -122.3933, accuracy: 0, timestamp: Date.now() };
      case MiniappRequestType.CALENDAR_LIST_EVENTS:
        return { events: [], truncated: false };
      case MiniappRequestType.STORAGE_GET:
        return { value: null };
      case MiniappRequestType.STORAGE_LIST:
        return { keys: [] };
      case MiniappRequestType.SPEAK:
        return { audioUrl: null, durationMs: 0 };
      case MiniappRequestType.SHARE:
      case MiniappRequestType.OPEN_URL:
      case MiniappRequestType.COPY_CLIPBOARD:
      case MiniappRequestType.DOWNLOAD:
      case MiniappRequestType.REQUEST_WIFI_SETUP:
      case MiniappRequestType.SET_WIFI_ADB_STATE:
        return { ok: true };
      case MiniappRequestType.SCAN_QR:
        return { cancelled: true };
      default:
        return null;
    }
  }

  // ../../mobile/modules/miniapp/dist/transport/postmessage.js
  class PostMessageTransport {
    constructor() {
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.open_ = false;
      this.windowListener = null;
    }
    async open() {
      if (this.open_)
        return;
      if (typeof window === "undefined" || !window.ReactNativeWebView) {
        throw new Error("PostMessageTransport: not running inside a React Native WebView");
      }
      this.windowListener = (ev) => {
        const data = ev.data;
        if (typeof data !== "string")
          return;
        this.messageHandler?.(data);
      };
      window.addEventListener("message", this.windowListener);
      if (typeof document !== "undefined") {
        document.addEventListener("message", this.windowListener);
      }
      window.receiveNativeMessage = (raw) => {
        this.messageHandler?.(raw);
      };
      this.open_ = true;
    }
    send(raw) {
      if (typeof window === "undefined" || !window.ReactNativeWebView) {
        throw new Error("PostMessageTransport: not running inside a React Native WebView");
      }
      window.ReactNativeWebView.postMessage(raw);
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      if (!this.open_)
        return;
      this.open_ = false;
      if (this.windowListener) {
        window.removeEventListener("message", this.windowListener);
        if (typeof document !== "undefined") {
          document.removeEventListener("message", this.windowListener);
        }
        this.windowListener = null;
      }
      if (typeof window !== "undefined" && window.receiveNativeMessage) {
        window.receiveNativeMessage = undefined;
      }
      this.disconnectHandler?.("closed");
    }
    isOpen() {
      return this.open_;
    }
  }

  // ../../mobile/modules/miniapp/dist/transport/auto.js
  var LOCAL_SOCKET_OPEN_TIMEOUT_MS = 500;
  function createTransport(options = {}) {
    if (options.transport)
      return options.transport;
    if (DispatchTransport.isAvailable()) {
      return new DispatchTransport;
    }
    if (typeof window !== "undefined" && window.ReactNativeWebView) {
      return new PostMessageTransport;
    }
    if (isMockExplicitlyRequested()) {
      return new MockTransport;
    }
    if (typeof WebSocket !== "undefined") {
      const localSocketOptions = {};
      if (options.localSocketUrl)
        localSocketOptions.url = options.localSocketUrl;
      return new LocalSocketWithMockFallback(localSocketOptions);
    }
    return new MockTransport;
  }

  class LocalSocketWithMockFallback {
    constructor(options) {
      this.options = options;
      this.active = null;
      this.messageHandler = null;
      this.disconnectHandler = null;
    }
    async open() {
      const local = new LocalSocketTransport(this.options);
      let timedOut = false;
      const timeout = new Promise((_, reject) => {
        setTimeout(() => {
          timedOut = true;
          reject(new Error("LocalSocketTransport open timed out"));
        }, LOCAL_SOCKET_OPEN_TIMEOUT_MS);
      });
      try {
        await Promise.race([local.open(), timeout]);
        this.active = local;
      } catch {
        try {
          local.close();
        } catch {}
        const mock = new MockTransport;
        await mock.open();
        this.active = mock;
        console.log(timedOut ? "[mentra-miniapp] No phone WebSocket reachable; using MockTransport so the page can render." : "[mentra-miniapp] LocalSocketTransport failed; using MockTransport.");
      }
      if (this.messageHandler)
        this.active.onMessage(this.messageHandler);
      if (this.disconnectHandler)
        this.active.onDisconnect(this.disconnectHandler);
    }
    send(raw) {
      if (!this.active)
        throw new Error("LocalSocketWithMockFallback: send() before open()");
      this.active.send(raw);
    }
    onMessage(handler) {
      this.messageHandler = handler;
      this.active?.onMessage(handler);
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
      this.active?.onDisconnect(handler);
    }
    close() {
      this.active?.close();
    }
    isOpen() {
      return this.active?.isOpen() === true;
    }
  }

  // ../../cloud-v2/packages/protocol/src/photo-compression.ts
  var photoCompressionValues = ["none", "low", "medium", "high"];
  function parsePhotoCompression(value = "none") {
    if (typeof value === "string" && photoCompressionValues.includes(value)) {
      return value;
    }
    throw new TypeError(`Invalid photo compression ${JSON.stringify(value)}. Expected none, low, medium, or high.`);
  }

  // ../../mobile/modules/miniapp/dist/modules/camera.js
  class CameraModule {
    constructor(session) {
      this.session = session;
    }
    get hasPermission() {
      return this.session._hasManifestPermission("CAMERA");
    }
    async setFov(request) {
      return this.session.sendRequest({
        type: MiniappRequestType.CAMERA_FOV,
        ...request
      });
    }
    async takePhoto(options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.PHOTO,
        size: options.size ?? "medium",
        mode: options.mode ?? "photo",
        ...options.transferMethod !== undefined ? { transferMethod: options.transferMethod } : {},
        compress: parsePhotoCompression(options.compress),
        sound: options.sound ?? true,
        saveToGallery: options.saveToGallery ?? false,
        exposureTimeNs: options.exposureTimeNs,
        iso: options.iso,
        aeExposureDivisor: options.aeExposureDivisor,
        isoCap: options.isoCap,
        noiseReduction: options.noiseReduction,
        edgeEnhancement: options.edgeEnhancement,
        zsl: options.zsl,
        mfnr: options.mfnr,
        ispDigitalGain: options.ispDigitalGain,
        ispAnalogGain: options.ispAnalogGain
      }, options.timeoutMs != null ? { timeoutMs: options.timeoutMs } : undefined);
    }
    async warmUp(options = {}) {
      await this.session.sendRequest({
        type: MiniappRequestType.CAMERA_WARM_UP,
        size: options.size ?? "medium",
        mode: options.mode ?? "photo",
        exposureTimeNs: options.exposureTimeNs,
        durationMs: options.durationMs ?? 15000,
        zsl: options.zsl,
        mfnr: options.mfnr
      });
    }
    async startVideoRecording(options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.VIDEO_RECORDING_START,
        width: options.width,
        height: options.height,
        fps: options.fps,
        sound: options.sound ?? true,
        save: options.save ?? false
      });
    }
    async stopVideoRecording(recordingId, options = {}) {
      await this.session.sendRequest({
        type: MiniappRequestType.VIDEO_RECORDING_STOP,
        recordingId,
        uploadUrl: options.uploadUrl,
        uploadAuthToken: options.uploadAuthToken
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/auth.js
  var DEFAULT_MIN_TTL_MS = 30000;

  class AuthModule {
    constructor(session) {
      this.session = session;
    }
    get current() {
      return this.session._getAuth();
    }
    get mentraUserId() {
      return this.current?.mentraUserId ?? null;
    }
    get oemId() {
      return this.current?.oemId ?? null;
    }
    async getToken(options = {}) {
      const auth = await this.session._waitForAuth(options.minTtlMs ?? DEFAULT_MIN_TTL_MS);
      return auth.token;
    }
    async getAuthHeader(options = {}) {
      return `Bearer ${await this.getToken(options)}`;
    }
    async fetch(input, init = {}) {
      const { minTtlMs, ...requestInit } = init;
      const token = await this.getToken({ minTtlMs });
      const headers = mergeHeaders(requestInit.headers, { Authorization: `Bearer ${token}` });
      return fetch(input, { ...requestInit, headers });
    }
    onUpdate(handler) {
      return this.session.on("auth", handler);
    }
  }
  function mergeHeaders(base, next) {
    const headers = {};
    if (Array.isArray(base)) {
      for (const [key, value] of base) {
        headers[key] = value;
      }
    } else if (typeof Headers !== "undefined" && base instanceof Headers) {
      base.forEach((value, key) => {
        headers[key] = value;
      });
    } else if (base && typeof base === "object") {
      for (const [key, value] of Object.entries(base)) {
        if (typeof value === "string")
          headers[key] = value;
      }
    }
    return { ...headers, ...next };
  }

  // ../../mobile/modules/miniapp/dist/modules/cloud.js
  var CLOUD_STATUS_STREAM = "_cloud_status";
  var DEFAULT_STATUS = {
    status: "disconnected",
    audioTransport: "none"
  };
  function normalizeCloudStatus(data) {
    if (!data || typeof data !== "object")
      return null;
    const raw = data;
    const status = raw.status;
    const audioTransport = raw.audioTransport;
    if (status !== "connected" && status !== "connecting" && status !== "reconnecting" && status !== "disconnected") {
      return null;
    }
    if (audioTransport !== "udp" && audioTransport !== "ws" && audioTransport !== "offline" && audioTransport !== "none") {
      return null;
    }
    return { status, audioTransport };
  }

  class CloudModule {
    constructor(session) {
      this.session = session;
      this.emitter = new import__.default;
      this.current = { ...DEFAULT_STATUS };
      this.session._subscribe(CLOUD_STATUS_STREAM, (data) => {
        const next = normalizeCloudStatus(data);
        if (!next)
          return;
        if (next.status === this.current.status && next.audioTransport === this.current.audioTransport)
          return;
        this.current = next;
        this.emitter.emit("status", { ...this.current });
      });
    }
    get status() {
      return { ...this.current };
    }
    get connected() {
      return this.current.status === "connected";
    }
    isConnected() {
      return this.connected;
    }
    onStatusChanged(handler) {
      handler({ ...this.current });
      this.emitter.on("status", handler);
      return () => {
        this.emitter.off("status", handler);
      };
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/configuration.js
  class MiniappConfigurationError extends Error {
    constructor(key) {
      super(`Required miniapp configuration is missing: ${key}`);
      this.key = key;
      this.name = "MiniappConfigurationError";
    }
  }

  class ConfigurationModule {
    constructor(session) {
      this.session = session;
    }
    async get(key) {
      await this.session.waitForReady();
      const configuration = this.session._getConfiguration();
      return Object.prototype.hasOwnProperty.call(configuration, key) ? configuration[key] : undefined;
    }
    async require(key) {
      const value = await this.get(key);
      if (value === undefined)
        throw new MiniappConfigurationError(key);
      return value;
    }
    async getAll() {
      await this.session.waitForReady();
      return Object.assign(Object.create(null), this.session._getConfiguration());
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/dashboard.js
  class DashboardAPI {
    constructor(session) {
      this.session = session;
      this.warned = false;
    }
    setContent(mode, content) {
      if (!this.warned) {
        console.warn("[@mentra/miniapp] dashboard.setContent() is deferred in v1.");
        this.warned = true;
      }
      this.session.sendOneShot({
        type: MiniappRequestType.DASHBOARD_CONTENT_UPDATE,
        mode,
        content
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/display.js
  class DisplayManager {
    constructor(session) {
      this.session = session;
    }
    render(elements, options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.RENDER,
        view: options.view ?? "main",
        elements,
        durationMs: options.durationMs
      }).catch((err) => ({
        status: "blocked",
        reason: typeof err === "object" && err !== null && "message" in err ? String(err.message) : String(err)
      }));
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/events.js
  class EventManager {
    constructor(session) {
      this.session = session;
      this.emitter = new import__.default;
      this.refCounts = new Map;
      this.forceLocalRefCounts = new Map;
    }
    subscribe(stream, handler, options = {}) {
      const isInternal = stream.startsWith("_");
      const forceLocal = options.forceLocal === true && stream.startsWith(`${MiniappStreamType.TRANSCRIPTION}:`);
      const listener = (data, route) => {
        if (stream.startsWith(`${MiniappStreamType.TRANSCRIPTION}:`)) {
          if (forceLocal ? route !== "forceLocal" && route !== "all" : route === "forceLocal")
            return;
        }
        handler(data);
      };
      this.emitter.on(stream, listener);
      if (!isInternal) {
        const before = this.refCounts.get(stream) ?? 0;
        this.refCounts.set(stream, before + 1);
        const forceLocalBefore = this.forceLocalRefCounts.get(stream) ?? 0;
        const defaultBefore = before - forceLocalBefore;
        if (forceLocal)
          this.forceLocalRefCounts.set(stream, forceLocalBefore + 1);
        if (before === 0 || forceLocal && forceLocalBefore === 0 || !forceLocal && defaultBefore === 0) {
          this.sendSubscriptionUpdate();
        }
      }
      return () => {
        this.emitter.off(stream, listener);
        if (isInternal)
          return;
        const current = this.refCounts.get(stream) ?? 0;
        const forceLocalCurrent = this.forceLocalRefCounts.get(stream) ?? 0;
        let subscriptionChanged = current <= 1;
        if (current <= 1) {
          this.refCounts.delete(stream);
        } else {
          this.refCounts.set(stream, current - 1);
        }
        if (forceLocal) {
          if (forceLocalCurrent <= 1) {
            this.forceLocalRefCounts.delete(stream);
            subscriptionChanged = true;
          } else {
            this.forceLocalRefCounts.set(stream, forceLocalCurrent - 1);
          }
        } else if (current - forceLocalCurrent <= 1) {
          subscriptionChanged = true;
        }
        if (subscriptionChanged)
          this.sendSubscriptionUpdate();
      };
    }
    unsubscribeAll() {
      this.emitter.removeAllListeners();
      this.refCounts.clear();
      this.forceLocalRefCounts.clear();
      this.sendSubscriptionUpdate();
    }
    _forwardEvent(stream, data, transcriptionRoute) {
      this.emitter.emit(stream, data, transcriptionRoute);
      if (stream.startsWith("transcription:") && stream !== "transcription:auto") {
        this.emitter.emit("transcription:auto", data, transcriptionRoute);
      } else if (stream.startsWith("translation:")) {
        const parts = stream.split(":");
        const patterns = new Set(["translation:auto"]);
        if (parts.length === 3) {
          const [, source, target] = parts;
          patterns.add("translation:*:*");
          patterns.add(`translation:*:${target}`);
          patterns.add(`translation:${source}:*`);
        }
        patterns.delete(stream);
        for (const pattern of patterns) {
          this.emitter.emit(pattern, data);
        }
      }
    }
    sendSubscriptionUpdate() {
      const subscriptions = Array.from(this.refCounts.keys()).map((stream) => {
        if (stream === MiniappStreamType.LOCATION_UPDATE)
          return { stream: "location_stream", rate: "realtime" };
        const forceLocalRefs = this.forceLocalRefCounts.get(stream) ?? 0;
        if (forceLocalRefs === 0)
          return stream;
        const totalRefs = this.refCounts.get(stream) ?? 0;
        return {
          stream,
          forceLocal: true,
          ...totalRefs > forceLocalRefs ? { includeCloud: true } : {}
        };
      });
      this.session.sendOneShot({
        type: MiniappRequestType.SUBSCRIBE,
        subscriptions
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/glasses.js
  class GlassesModule {
    constructor(session) {
      this.session = session;
    }
    onBattery(handler) {
      return this.session._subscribe(MiniappStreamType.GLASSES_BATTERY, handler);
    }
    onConnection(handler) {
      return this.session._subscribe(MiniappStreamType.GLASSES_CONNECTION, handler);
    }
    onWifi(handler) {
      return this.session._subscribe(MiniappStreamType.GLASSES_WIFI, handler);
    }
    async requestWifiSetup(reason) {
      await this.session.sendRequest({
        type: MiniappRequestType.REQUEST_WIFI_SETUP,
        reason
      });
    }
    async setWifiAdbState(enabled) {
      await this.session.sendRequest({
        type: MiniappRequestType.SET_WIFI_ADB_STATE,
        enabled
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/heading.js
  class HeadingModule {
    constructor(session) {
      this.session = session;
    }
    get hasPermission() {
      return this.session._hasManifestPermission("LOCATION");
    }
    onUpdate(handler) {
      return this.session._subscribe(MiniappStreamType.HEADING_UPDATE, handler);
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/imu.js
  class ImuModule {
    constructor(session) {
      this.session = session;
    }
    onHeadPosition(handler) {
      return this.session._subscribe(MiniappStreamType.HEAD_POSITION, handler);
    }
    onAccel(handler) {
      return this.session._subscribe(MiniappStreamType.ACCEL_DATA, handler);
    }
    setEnabled(enabled) {
      return this.session.sendRequest({
        type: MiniappRequestType.IMU_SET_ENABLED,
        enabled
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/input.js
  class InputModule {
    constructor(session) {
      this.session = session;
    }
    onButtonPress(handler) {
      return this.session._subscribe(MiniappStreamType.BUTTON_PRESS, handler);
    }
    onTouch(gestureOrHandler, maybeHandler) {
      if (typeof gestureOrHandler === "function") {
        return this.session._subscribe(MiniappStreamType.TOUCH_EVENT, gestureOrHandler);
      }
      const handler = maybeHandler;
      const gestures = Array.isArray(gestureOrHandler) ? gestureOrHandler : [gestureOrHandler];
      if (gestures.length === 0)
        return () => {};
      const unsubs = [];
      for (const g of gestures) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TOUCH_EVENT}:${g}`, handler));
      }
      return () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/led.js
  class LedModule {
    constructor(session) {
      this.session = session;
    }
    async turnOn(options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.RGB_LED,
        action: "on",
        color: options.color ?? "red",
        ontime: options.ontime ?? 1000,
        offtime: options.offtime ?? 0,
        count: options.count ?? 1
      });
    }
    async turnOff() {
      return this.session.sendRequest({
        type: MiniappRequestType.RGB_LED,
        action: "off"
      });
    }
    async blink(color, ontime, offtime, count) {
      return this.turnOn({ color, ontime, offtime, count });
    }
    async solid(color, duration) {
      return this.turnOn({ color, ontime: duration, offtime: 0, count: 1 });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/location.js
  class LocationModule {
    constructor(session) {
      this.session = session;
    }
    get hasPermission() {
      return this.session._hasManifestPermission("LOCATION");
    }
    onUpdate(handler) {
      return this.session._subscribe(MiniappStreamType.LOCATION_UPDATE, handler);
    }
    getOnce() {
      return this.session.sendRequest({
        type: MiniappRequestType.LOCATION_POLL
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/mic.js
  class MicModule {
    constructor(session) {
      this.session = session;
      this.unsubs = new Set;
    }
    onVoiceActivity(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.VAD, handler));
    }
    onAudioChunk(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.AUDIO_CHUNK, handler));
    }
    setVoiceActivityDetectionEnabled(enabled) {
      return this.session.sendRequest({
        type: MiniappRequestType.MIC_SET_VAD_ENABLED,
        enabled
      });
    }
    setLoudnessGateEnabled(enabled) {
      return this.session.sendRequest({
        type: MiniappRequestType.MIC_SET_LOUDNESS_GATE_ENABLED,
        enabled
      });
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
    get hasPermission() {
      return this.session._hasManifestPermission("MICROPHONE");
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/pivots/geometry.js
  var TURN_THRESHOLD_DEG = 15;
  var SAME_DIR_MERGE_M = 25;
  var RDP_EPSILON_M = 5;
  var MIN_BEND_PER_POINT_DEG = 10;
  var STRAIGHT_SEGMENT_BREAK_M = 1;
  var INTERSECTION_CLUSTER_M = 30;
  function haversineMeters(a, b) {
    const R = 6371000;
    const toRad = (d) => d * Math.PI / 180;
    const dLat = toRad(b.lat - a.lat);
    const dLng = toRad(b.lng - a.lng);
    const lat1 = toRad(a.lat);
    const lat2 = toRad(b.lat);
    const x = Math.sin(dLat / 2) ** 2 + Math.sin(dLng / 2) ** 2 * Math.cos(lat1) * Math.cos(lat2);
    return 2 * R * Math.asin(Math.sqrt(x));
  }
  function bearingDeg(a, b) {
    const toRad = (d) => d * Math.PI / 180;
    const toDeg = (r) => r * 180 / Math.PI;
    const lat1 = toRad(a.lat);
    const lat2 = toRad(b.lat);
    const dLng = toRad(b.lng - a.lng);
    const y = Math.sin(dLng) * Math.cos(lat2);
    const x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLng);
    return (toDeg(Math.atan2(y, x)) + 360) % 360;
  }
  function signedAngleDiff(target, actual) {
    return (target - actual + 540) % 360 - 180;
  }
  function rdpSimplify(points, epsilonMeters) {
    if (points.length < 3)
      return points.map((_, i) => i);
    const keep = new Array(points.length).fill(false);
    keep[0] = true;
    keep[points.length - 1] = true;
    const stack = [[0, points.length - 1]];
    while (stack.length) {
      const [lo, hi] = stack.pop();
      let maxDist = 0;
      let maxIdx = -1;
      for (let i = lo + 1;i < hi; i++) {
        const d = perpDistMeters(points[i], points[lo], points[hi]);
        if (d > maxDist) {
          maxDist = d;
          maxIdx = i;
        }
      }
      if (maxIdx !== -1 && maxDist > epsilonMeters) {
        keep[maxIdx] = true;
        stack.push([lo, maxIdx], [maxIdx, hi]);
      }
    }
    const out = [];
    for (let i = 0;i < keep.length; i++)
      if (keep[i])
        out.push(i);
    return out;
  }
  function perpDistMeters(p, a, b) {
    const mPerDegLat = 111320;
    const mPerDegLng = 111320 * Math.cos(a.lat * Math.PI / 180);
    const bx = (b.lng - a.lng) * mPerDegLng;
    const by = (b.lat - a.lat) * mPerDegLat;
    const px = (p.lng - a.lng) * mPerDegLng;
    const py = (p.lat - a.lat) * mPerDegLat;
    const dx = bx;
    const dy = by;
    const len = Math.sqrt(dx * dx + dy * dy);
    if (len === 0)
      return Math.sqrt(px * px + py * py);
    return Math.abs(dx * -py - -px * dy) / len;
  }
  function extractPivots(rawPoints) {
    if (rawPoints.length < 3)
      return [];
    const keptIdx = rdpSimplify(rawPoints, RDP_EPSILON_M);
    const simplified = keptIdx.map((i) => rawPoints[i]);
    if (simplified.length < 3)
      return [];
    const deltas = [];
    for (let i = 1;i < simplified.length - 1; i++) {
      const inBearing = bearingDeg(simplified[i - 1], simplified[i]);
      const outBearing = bearingDeg(simplified[i], simplified[i + 1]);
      deltas.push(signedAngleDiff(outBearing, inBearing));
    }
    const candidates = [];
    let runStart = -1;
    let runSum = 0;
    let runSign = 0;
    const flushRun = (endExclusive) => {
      if (runStart === -1)
        return;
      if (Math.abs(runSum) >= TURN_THRESHOLD_DEG) {
        let bestIdx = runStart;
        let bestAbs = 0;
        for (let k = runStart;k < endExclusive; k++) {
          const a = Math.abs(deltas[k]);
          if (a > bestAbs) {
            bestAbs = a;
            bestIdx = k;
          }
        }
        const simplifiedIdx = bestIdx + 1;
        candidates.push({
          lat: simplified[simplifiedIdx].lat,
          lng: simplified[simplifiedIdx].lng,
          direction: runSum > 0 ? "right" : "left",
          simplifiedRouteIndex: simplifiedIdx,
          rawRouteIndex: keptIdx[simplifiedIdx],
          headingDelta: runSum
        });
      }
      runStart = -1;
      runSum = 0;
      runSign = 0;
    };
    let metersSinceLastBend = 0;
    for (let k = 0;k < deltas.length; k++) {
      const d = deltas[k];
      const sign = d > 0 ? 1 : d < 0 ? -1 : 0;
      const segLen = haversineMeters(simplified[k + 1], simplified[k + 2]);
      if (sign === 0 || Math.abs(d) < MIN_BEND_PER_POINT_DEG) {
        if (runStart !== -1) {
          if (sign === runSign || sign === 0)
            runSum += d;
          metersSinceLastBend += segLen;
          if (metersSinceLastBend >= STRAIGHT_SEGMENT_BREAK_M) {
            flushRun(k + 1);
          }
        }
        continue;
      }
      if (runStart === -1) {
        runStart = k;
        runSum = d;
        runSign = sign;
        metersSinceLastBend = segLen;
      } else if (sign === runSign) {
        if (metersSinceLastBend >= STRAIGHT_SEGMENT_BREAK_M) {
          flushRun(k);
          runStart = k;
          runSum = d;
          runSign = sign;
        } else {
          runSum += d;
        }
        metersSinceLastBend = segLen;
      } else {
        flushRun(k);
        runStart = k;
        runSum = d;
        runSign = sign;
        metersSinceLastBend = segLen;
      }
    }
    flushRun(deltas.length);
    const merged = [];
    for (const p of candidates) {
      const last = merged[merged.length - 1];
      if (last && last.direction === p.direction && haversineMeters({ lat: last.lat, lng: last.lng }, { lat: p.lat, lng: p.lng }) < SAME_DIR_MERGE_M) {
        if (Math.abs(p.headingDelta) > Math.abs(last.headingDelta)) {
          merged[merged.length - 1] = p;
        }
        continue;
      }
      merged.push(p);
    }
    const clustered = [];
    for (const p of merged) {
      const last = clustered[clustered.length - 1];
      if (last && haversineMeters({ lat: last.lat, lng: last.lng }, { lat: p.lat, lng: p.lng }) < INTERSECTION_CLUSTER_M) {
        const netDelta = last.headingDelta + p.headingDelta;
        const anchor = Math.abs(p.headingDelta) > Math.abs(last.headingDelta) ? p : last;
        clustered[clustered.length - 1] = {
          ...anchor,
          direction: netDelta > 0 ? "right" : "left",
          headingDelta: netDelta
        };
        continue;
      }
      clustered.push(p);
    }
    return clustered.filter((p) => Math.abs(p.headingDelta) >= TURN_THRESHOLD_DEG);
  }
  function cumulativeDistances(points) {
    const out = new Array(points.length);
    out[0] = 0;
    for (let i = 1;i < points.length; i++) {
      out[i] = out[i - 1] + haversineMeters(points[i - 1], points[i]);
    }
    return out;
  }

  // ../../mobile/modules/miniapp/dist/modules/pivots/instructions.js
  var DIRECTION_WORDS = new Set(["right", "left", "the right", "the left", "north", "south", "east", "west"]);
  var MANEUVER_VERBS = /\b(turn|slight|sharp|continue|head|merge|exit|uturn|u-turn|then|keep)\b/i;
  function roadNameFromInstruction(instruction) {
    if (!instruction)
      return null;
    const firstLine = instruction.split(`
`)[0] ?? "";
    const m = firstLine.match(/\bonto\s+(.+)$/i);
    let raw = (m ? m[1] : "").trim();
    if (!raw)
      return null;
    if (raw.includes(","))
      return null;
    raw = raw.split(/\s+(?:toward|towards|to|and|then|for)\b/i)[0]?.trim() ?? "";
    raw = raw.replace(/\s+#.*$/, "").trim();
    if (!raw)
      return null;
    if (DIRECTION_WORDS.has(raw.toLowerCase()))
      return null;
    if (MANEUVER_VERBS.test(raw))
      return null;
    return raw;
  }
  var ROAD_SUFFIXES = /\b(st|street|ave|avenue|blvd|boulevard|rd|road|dr|drive|ln|lane|way|ct|court|pl|place|ter|terrace|hwy|highway)\b\.?/g;
  function normalizeRoad(road) {
    return road.toLowerCase().replace(ROAD_SUFFIXES, "").replace(/[^a-z0-9 ]/g, "").replace(/\s+/g, " ").trim();
  }
  function sameRoad(a, b) {
    return normalizeRoad(a) === normalizeRoad(b);
  }
  function turnDirection(maneuver) {
    if (!maneuver)
      return null;
    const m = maneuver.toUpperCase();
    if (m.includes("LEFT"))
      return "left";
    if (m.includes("RIGHT"))
      return "right";
    return null;
  }
  var PROBE_METERS = 22;
  function signedBendAt(points, junction) {
    if (points.length < 3)
      return null;
    let mid = 0;
    let bestDist = Infinity;
    for (let i = 0;i < points.length; i++) {
      const d = haversineMeters(points[i], junction);
      if (d < bestDist) {
        bestDist = d;
        mid = i;
      }
    }
    let before = mid;
    while (before > 0 && haversineMeters(points[before], points[mid]) < PROBE_METERS)
      before--;
    let after = mid;
    while (after < points.length - 1 && haversineMeters(points[after], points[mid]) < PROBE_METERS)
      after++;
    if (before === mid || after === mid)
      return null;
    const incoming = bearingDeg(points[before], points[mid]);
    const outgoing = bearingDeg(points[mid], points[after]);
    return signedAngleDiff(outgoing, incoming);
  }
  var MIN_TURN_ANGLE_DEG = 30;
  function extractPivotsFromComputedSteps(steps, polyline) {
    if (!steps || steps.length < 2)
      return [];
    const initial = steps.map((s, i) => ({
      stepIdx: i,
      name: s.road ?? roadNameFromInstruction(s.instruction)
    }));
    let annotated = initial;
    for (let pass = 0;pass < 4; pass++) {
      const collapsed = [];
      for (let i = 0;i < annotated.length; i++) {
        const prev = collapsed[collapsed.length - 1];
        const here = annotated[i];
        const next = annotated[i + 1];
        if (prev?.name && next?.name && here.name && !sameRoad(prev.name, here.name) && sameRoad(prev.name, next.name)) {
          continue;
        }
        collapsed.push(here);
      }
      if (collapsed.length === annotated.length)
        break;
      annotated = collapsed;
    }
    const out = [];
    for (let i = 0;i < annotated.length - 1; i++) {
      const here = annotated[i];
      const nextAnn = annotated[i + 1];
      const s = steps[here.stepIdx];
      const next = steps[nextAnn.stepIdx];
      const fromRoad = here.name;
      const toRoad = nextAnn.name;
      if (!fromRoad)
        continue;
      if (toRoad && sameRoad(fromRoad, toRoad))
        continue;
      if (!Number.isFinite(s.endLat) || !Number.isFinite(s.endLng))
        continue;
      const junction = { lat: s.endLat, lng: s.endLng };
      const signedBend = signedBendAt(polyline, junction);
      if (signedBend != null && Math.abs(signedBend) < MIN_TURN_ANGLE_DEG)
        continue;
      const geomDir = signedBend == null ? null : signedBend > 0 ? "right" : "left";
      const direction = geomDir ?? turnDirection(next.maneuver);
      out.push({
        lat: s.endLat,
        lng: s.endLng,
        fromRoad,
        toRoad,
        direction,
        maneuver: next.maneuver ?? (direction === "left" ? "TURN_LEFT" : "TURN_RIGHT")
      });
    }
    return out;
  }

  // ../../mobile/modules/miniapp/dist/modules/pivots/engine.js
  var RADIUS_DEFAULTS_M = {
    walking: 7,
    cycling: 15,
    driving: 40,
    two_wheeler: 25
  };
  var APPROACH_DEFAULTS_M = {
    walking: 100,
    cycling: 300,
    driving: 800,
    two_wheeler: 500
  };
  var NON_TURN_MANEUVERS = new Set(["STRAIGHT", "NAME_CHANGE", "DEPART", "ARRIVE"]);
  var STEP_MATCH_MAX_INDEX_DELTA = 8;
  var ON_ROUTE_PERP_TOLERANCE_M = 50;

  class PivotEngine {
    constructor(mode, opts) {
      this.pivots = [];
      this.states = [];
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = [];
      this.cumulative = [];
      this.roadNameResolver = null;
      this.routeGeneration = 0;
      this.subscribers = new Set;
      this.opts = resolveOptions(mode, opts);
    }
    updateOptions(mode, opts) {
      this.opts = resolveOptions(mode, opts);
      for (const p of this.pivots) {
        p.radiusMeters = this.opts.radiusMeters;
      }
    }
    setRoadNameResolver(resolver) {
      this.roadNameResolver = resolver;
    }
    reset() {
      if (this.activePivotIndex !== null) {
        const active = this.pivots[this.activePivotIndex];
        if (active)
          this.emit({ kind: "exited", pivot: active });
      }
      this.pivots = [];
      this.states = [];
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = [];
      this.cumulative = [];
    }
    setRouteFromComputedSteps(route, computedSteps) {
      const points = route.points ?? [];
      if (this.activePivotIndex !== null) {
        const active = this.pivots[this.activePivotIndex];
        if (active)
          this.emit({ kind: "exited", pivot: active });
      }
      if (points.length < 3 || !computedSteps || computedSteps.length < 2) {
        this.setRoute(route, null);
        return;
      }
      const cumulative = cumulativeDistances(points);
      const instructionPivots = extractPivotsFromComputedSteps(computedSteps, points);
      console.log(`[PivotEngine] setRouteFromComputedSteps: steps=${computedSteps.length} instructionPivots=${instructionPivots.length}` + (instructionPivots.length > 0 ? `
` + instructionPivots.map((p, i) => `  pivot[${i}] ${p.fromRoad ?? "—"} → ${p.toRoad ?? "—"} dir=${p.direction} @ (${p.lat.toFixed(5)}, ${p.lng.toFixed(5)})`).join(`
`) : ""));
      if (instructionPivots.length === 0) {
        console.log(`[PivotEngine] falling back to setRoute (geometry) — input steps:
` + computedSteps.map((s, i) => `  step[${i}] road=${s.road ?? "—"} maneuver=${s.maneuver ?? "—"} @ (${s.lat.toFixed(5)}, ${s.lng.toFixed(5)}) → (${s.endLat.toFixed(5)}, ${s.endLng.toFixed(5)})`).join(`
`));
        this.setRoute(route, null);
        return;
      }
      const pivots = instructionPivots.map((p, i) => ({
        index: i,
        lat: p.lat,
        lng: p.lng,
        direction: p.direction === "left" ? "left" : "right",
        fromRoad: p.fromRoad,
        toRoad: p.toRoad,
        maneuver: p.maneuver,
        distanceAlongRouteMeters: alongRouteAtCoord(points, cumulative, { lat: p.lat, lng: p.lng }),
        radiusMeters: this.opts.radiusMeters
      }));
      pivots.sort((a, b) => a.distanceAlongRouteMeters - b.distanceAlongRouteMeters);
      for (let i = 0;i < pivots.length; i++)
        pivots[i].index = i;
      this.pivots = pivots;
      this.states = pivots.map(() => ({ approachingFired: false, entered: false, exited: false }));
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = points;
      this.cumulative = cumulative;
      this.routeGeneration++;
      this._resolveMissingRoadNames(this.routeGeneration);
    }
    setRoute(route, _userPosition) {
      const points = route.points ?? [];
      const steps = route.steps ?? [];
      if (this.activePivotIndex !== null) {
        const active = this.pivots[this.activePivotIndex];
        if (active)
          this.emit({ kind: "exited", pivot: active });
      }
      if (points.length < 3) {
        this.pivots = [];
        this.states = [];
        this.cursor = 0;
        this.activePivotIndex = null;
        this.points = [];
        this.cumulative = [];
        return;
      }
      const cumulative = cumulativeDistances(points);
      const raw = extractPivots(points);
      const stepIndex = buildStepIndex(steps);
      const pivots = [];
      for (let i = 0;i < raw.length; i++) {
        const r = raw[i];
        const matched = matchStep(r, stepIndex);
        if (matched && NON_TURN_MANEUVERS.has(matched.maneuver)) {
          continue;
        }
        pivots.push({
          index: pivots.length,
          lat: r.lat,
          lng: r.lng,
          direction: r.direction,
          fromRoad: matched?.fromRoad ?? null,
          toRoad: matched?.toRoad ?? null,
          maneuver: matched?.maneuver ?? (r.direction === "left" ? "TURN_LEFT" : "TURN_RIGHT"),
          distanceAlongRouteMeters: distanceAtIndex(cumulative, r.rawRouteIndex),
          radiusMeters: this.opts.radiusMeters
        });
      }
      pivots.sort((a, b) => a.distanceAlongRouteMeters - b.distanceAlongRouteMeters);
      for (let i = 0;i < pivots.length; i++)
        pivots[i].index = i;
      this.pivots = pivots;
      this.states = pivots.map(() => ({ approachingFired: false, entered: false, exited: false }));
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = points;
      this.cumulative = cumulative;
      this.routeGeneration++;
      this._resolveMissingRoadNames(this.routeGeneration);
    }
    async _resolveMissingRoadNames(generation) {
      const pivots = this.pivots;
      if (pivots.length === 0)
        return;
      for (let i = 0;i < pivots.length - 1; i++) {
        const here = pivots[i];
        const next = pivots[i + 1];
        if (!here.toRoad && next.fromRoad)
          here.toRoad = next.fromRoad;
        if (!next.fromRoad && here.toRoad)
          next.fromRoad = here.toRoad;
      }
      for (let i = pivots.length - 1;i > 0; i--) {
        const here = pivots[i];
        const prev = pivots[i - 1];
        if (!prev.toRoad && here.fromRoad)
          prev.toRoad = here.fromRoad;
        if (!here.fromRoad && prev.toRoad)
          here.fromRoad = prev.toRoad;
      }
      const resolver = this.roadNameResolver;
      if (!resolver)
        return;
      if (this.points.length < 2)
        return;
      const SAMPLE_OFFSETS_M = [18, 30, 50, 80];
      const points = this.points;
      const cumulative = this.cumulative;
      const geocodeWithExpansion = async (pivotAlong, direction) => {
        for (const offset of SAMPLE_OFFSETS_M) {
          const sample = sampleAlongRoute(points, cumulative, pivotAlong + direction * offset);
          if (!sample)
            continue;
          try {
            const road = await resolver(sample);
            if (generation !== this.routeGeneration)
              return null;
            if (road)
              return road;
          } catch {}
        }
        return null;
      };
      const tasks = [];
      for (const pivot of pivots) {
        if (pivot.fromRoad && pivot.toRoad)
          continue;
        const along = pivot.distanceAlongRouteMeters;
        if (!pivot.fromRoad) {
          tasks.push(geocodeWithExpansion(along, -1).then((road) => {
            if (generation !== this.routeGeneration)
              return;
            if (road && !pivot.fromRoad)
              pivot.fromRoad = road;
          }));
        }
        if (!pivot.toRoad) {
          tasks.push(geocodeWithExpansion(along, 1).then((road) => {
            if (generation !== this.routeGeneration)
              return;
            if (road && !pivot.toRoad)
              pivot.toRoad = road;
          }));
        }
      }
      await Promise.all(tasks);
      if (generation !== this.routeGeneration)
        return;
      for (let i = 0;i < pivots.length - 1; i++) {
        const here = pivots[i];
        const next = pivots[i + 1];
        if (!here.toRoad && next.fromRoad)
          here.toRoad = next.fromRoad;
        if (!next.fromRoad && here.toRoad)
          next.fromRoad = here.toRoad;
      }
    }
    onLocationUpdate(coords) {
      if (this.pivots.length === 0)
        return;
      const projection = projectOntoPolyline(this.points, this.cumulative, coords);
      const useAlongPath = projection !== null && projection.perpMeters <= ON_ROUTE_PERP_TOLERANCE_M;
      const userAlong = projection?.alongMeters ?? 0;
      for (let i = this.cursor;i < this.pivots.length; i++) {
        const pivot = this.pivots[i];
        const state = this.states[i];
        if (state.exited)
          continue;
        const aheadDelta = pivot.distanceAlongRouteMeters - userAlong;
        const distanceToPivot = useAlongPath ? Math.abs(aheadDelta) : haversineMeters(coords, { lat: pivot.lat, lng: pivot.lng });
        const approaching = !state.approachingFired && distanceToPivot <= this.opts.approachThresholdMeters && (!useAlongPath || aheadDelta >= -this.opts.radiusMeters);
        if (approaching) {
          state.approachingFired = true;
          this.emit({ kind: "approaching", pivot, distanceMeters: distanceToPivot });
        }
        if (!state.entered && distanceToPivot <= pivot.radiusMeters) {
          state.entered = true;
          this.activePivotIndex = i;
          this.emit({ kind: "entered", pivot });
        }
        const movedPastOnPath = useAlongPath && aheadDelta < -pivot.radiusMeters;
        if ((state.entered && distanceToPivot > pivot.radiusMeters || !state.entered && movedPastOnPath) && !state.exited) {
          if (!state.entered) {
            state.entered = true;
            this.activePivotIndex = i;
            this.emit({ kind: "entered", pivot });
          }
          state.exited = true;
          if (this.activePivotIndex === i)
            this.activePivotIndex = null;
          this.emit({ kind: "exited", pivot });
          if (this.cursor <= i)
            this.cursor = i + 1;
        }
        if (!state.approachingFired && distanceToPivot > this.opts.approachThresholdMeters * 2) {
          break;
        }
      }
    }
    subscribe(fn) {
      this.subscribers.add(fn);
      return () => {
        this.subscribers.delete(fn);
      };
    }
    getPivots() {
      return this.pivots.slice();
    }
    getActivePivot() {
      if (this.activePivotIndex === null)
        return null;
      return this.pivots[this.activePivotIndex] ?? null;
    }
    getUpcomingPivot() {
      for (let i = this.cursor;i < this.pivots.length; i++) {
        if (!this.states[i].exited)
          return this.pivots[i];
      }
      return null;
    }
    emit(event) {
      for (const fn of this.subscribers) {
        try {
          fn(event);
        } catch (err) {
          console.error("[PivotEngine] subscriber threw:", err);
        }
      }
    }
  }
  function resolveOptions(mode, opts) {
    return {
      radiusMeters: opts?.radiusMeters ?? RADIUS_DEFAULTS_M[mode] ?? RADIUS_DEFAULTS_M.walking,
      approachThresholdMeters: opts?.approachThresholdMeters ?? APPROACH_DEFAULTS_M[mode] ?? APPROACH_DEFAULTS_M.walking
    };
  }
  function projectOntoPolyline(points, cumulative, user) {
    if (points.length < 2 || cumulative.length !== points.length)
      return null;
    const mPerDegLat = 111320;
    const mPerDegLng = 111320 * Math.cos(user.lat * Math.PI / 180);
    const ux = user.lng * mPerDegLng;
    const uy = user.lat * mPerDegLat;
    let bestPerp = Number.POSITIVE_INFINITY;
    let bestAlong = 0;
    for (let i = 0;i < points.length - 1; i++) {
      const a = points[i];
      const b = points[i + 1];
      const ax = a.lng * mPerDegLng;
      const ay = a.lat * mPerDegLat;
      const bx = b.lng * mPerDegLng;
      const by = b.lat * mPerDegLat;
      const dx = bx - ax;
      const dy = by - ay;
      const segLen2 = dx * dx + dy * dy;
      const t = segLen2 > 0 ? Math.max(0, Math.min(1, ((ux - ax) * dx + (uy - ay) * dy) / segLen2)) : 0;
      const px = ax + t * dx;
      const py = ay + t * dy;
      const perp = Math.hypot(ux - px, uy - py);
      if (perp < bestPerp) {
        bestPerp = perp;
        const segLen = Math.sqrt(segLen2);
        bestAlong = cumulative[i] + t * segLen;
      }
    }
    if (!Number.isFinite(bestPerp))
      return null;
    return { perpMeters: bestPerp, alongMeters: bestAlong };
  }
  function alongRouteAtCoord(points, cumulative, coord) {
    const projection = projectOntoPolyline(points, cumulative, coord);
    return projection?.alongMeters ?? 0;
  }
  function sampleAlongRoute(points, cumulative, targetMeters) {
    if (points.length < 2 || cumulative.length !== points.length)
      return null;
    const total = cumulative[cumulative.length - 1];
    if (!Number.isFinite(targetMeters))
      return null;
    if (targetMeters <= 0)
      return { lat: points[0].lat, lng: points[0].lng };
    if (targetMeters >= total) {
      const last = points[points.length - 1];
      return { lat: last.lat, lng: last.lng };
    }
    let lo = 0;
    let hi = cumulative.length - 1;
    while (lo + 1 < hi) {
      const mid = lo + hi >>> 1;
      if (cumulative[mid] <= targetMeters)
        lo = mid;
      else
        hi = mid;
    }
    const segStart = cumulative[lo];
    const segEnd = cumulative[hi];
    const segLen = segEnd - segStart;
    const t = segLen > 0 ? (targetMeters - segStart) / segLen : 0;
    const a = points[lo];
    const b = points[hi];
    return { lat: a.lat + (b.lat - a.lat) * t, lng: a.lng + (b.lng - a.lng) * t };
  }
  function distanceAtIndex(cumulative, idx) {
    if (cumulative.length === 0)
      return 0;
    if (idx < 0)
      return 0;
    if (idx >= cumulative.length)
      return cumulative[cumulative.length - 1];
    return cumulative[idx];
  }
  function buildStepIndex(steps) {
    if (!steps.length)
      return [];
    return steps.slice().sort((a, b) => a.routeIndex - b.routeIndex);
  }
  function matchStep(raw, stepIndex) {
    if (stepIndex.length < 2)
      return null;
    let bestJ = -1;
    let bestDelta = Number.POSITIVE_INFINITY;
    for (let i = 1;i < stepIndex.length; i++) {
      const delta = Math.abs(stepIndex[i].routeIndex - raw.rawRouteIndex);
      if (delta <= bestDelta) {
        bestDelta = delta;
        bestJ = i;
      }
    }
    if (bestJ < 1)
      return null;
    if (bestDelta > STEP_MATCH_MAX_INDEX_DELTA)
      return null;
    const SHORT_TRANSIT_METERS = 25;
    const finalIndex = stepIndex.length - 1;
    let j = bestJ;
    while (j < finalIndex - 1 && stepIndex[j].distanceMeters > 0 && stepIndex[j].distanceMeters < SHORT_TRANSIT_METERS) {
      j++;
    }
    if (j >= finalIndex)
      j = finalIndex - 1;
    const fromStep = stepIndex[bestJ - 1];
    const toStep = stepIndex[j];
    return {
      fromRoad: fromStep.road ?? null,
      toRoad: toStep.road ?? null,
      maneuver: fromStep.maneuver
    };
  }

  // ../../mobile/modules/miniapp/dist/modules/navigation.js
  class NavigationModule {
    constructor(session) {
      this.session = session;
      this._pivots = new PivotEngine("walking", undefined);
      this._tripUnsubs = [];
      this._tripStops = null;
      this._tripMode = "walking";
      this._tripAvoid = undefined;
      this._computeRouteSeq = 0;
      this._lastUserPosition = null;
      this._pivots.setRoadNameResolver(async (coord) => {
        try {
          const result = await this.reverseGeocodeRoad(coord);
          if (!result.ok)
            return null;
          return result.road ?? null;
        } catch {
          return null;
        }
      });
    }
    get hasPermission() {
      return this.session._hasManifestPermission("LOCATION");
    }
    requestPermission() {
      if (!this.hasPermission) {
        return Promise.resolve({
          ok: false,
          accepted: false,
          error: "LOCATION permission not declared in miniapp.json (required for navigation.requestPermission)."
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_REQUEST_PERMISSION
      });
    }
    async start(opts) {
      if (!this.hasPermission) {
        return {
          ok: false,
          error: "LOCATION permission not declared in miniapp.json (required for navigation.start)."
        };
      }
      const stops = normalizeStops(opts);
      const mode = opts.mode ?? "driving";
      this._tripStops = stops.length > 0 ? stops : null;
      this._tripMode = mode;
      this._tripAvoid = opts.avoid;
      this._attachPivotTrackingForTrip(mode, opts.pivots);
      const failStart = (error) => {
        this._detachPivotTracking();
        return { ok: false, error };
      };
      if (stops.length === 0) {
        return failStart("navigation.start: no stops");
      }
      let origin = this._lastUserPosition;
      if (!origin) {
        try {
          const fix = await this.session.location.getOnce();
          origin = { lat: fix.lat, lng: fix.lng };
          this._lastUserPosition = origin;
        } catch (err) {
          return failStart(`navigation.start: no GPS fix (${err instanceof Error ? err.message : String(err)})`);
        }
      }
      const restResult = await this.computeRoute({ origin, stops, mode, avoid: opts.avoid });
      if (!restResult.ok || !restResult.routes || restResult.routes.length === 0) {
        return failStart(restResult.error ?? "computeRoute failed");
      }
      const restRoute = restResult.routes[0];
      const nativeResult = await this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_START,
        lat: stops[0]?.lat,
        lng: stops[0]?.lng,
        stops,
        mode,
        avoid: opts.avoid,
        simulate: opts.simulate ?? false,
        speedMultiplier: opts.speedMultiplier ?? 1,
        missedTurnRerouteMeters: opts.missedTurnRerouteMeters
      });
      if (!nativeResult.ok) {
        this._detachPivotTracking();
        return nativeResult;
      }
      const syntheticRoute = buildNavRouteFromComputed(restRoute);
      this.session.events._forwardEvent(MiniappStreamType.NAVIGATION_ROUTE, syntheticRoute);
      return nativeResult;
    }
    stop() {
      this._detachPivotTracking();
      this.session.sendOneShot({ type: MiniappRequestType.NAVIGATION_STOP });
    }
    get dev() {
      return {
        deviate: (offsetMeters = 20) => {
          this.session.sendOneShot({ type: MiniappRequestType.NAVIGATION_DEVIATE, offsetMeters });
        },
        setWrongSidewalkOffset: (enabled) => {
          this.session.sendOneShot({ type: MiniappRequestType.NAVIGATION_SET_WRONG_SIDEWALK, enabled });
        },
        setSkipCrossings: (enabled) => {
          this.session.sendOneShot({ type: MiniappRequestType.NAVIGATION_SET_SKIP_CROSSINGS, enabled });
        }
      };
    }
    onUpdate(handler) {
      return this.session._subscribe(MiniappStreamType.NAVIGATION_UPDATE, handler);
    }
    onRoute(handler) {
      return this.session._subscribe(MiniappStreamType.NAVIGATION_ROUTE, handler);
    }
    async getState() {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_GET_STATE
      });
      return result.ok ? result.state ?? null : null;
    }
    computeRoute(opts) {
      if (!this.hasPermission) {
        return Promise.resolve({
          ok: false,
          error: "LOCATION permission not declared in miniapp.json (required for navigation.computeRoute)."
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_COMPUTE_ROUTE,
        origin: opts.origin,
        stops: opts.stops,
        mode: opts.mode ?? "driving",
        avoid: opts.avoid,
        alternatives: opts.alternatives ?? 1
      });
    }
    reverseGeocodeRoad(coord) {
      if (!this.hasPermission) {
        return Promise.resolve({
          ok: false,
          error: "LOCATION permission not declared in miniapp.json (required for reverseGeocodeRoad)."
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_REVERSE_GEOCODE,
        lat: coord.lat,
        lng: coord.lng
      });
    }
    placeAutocomplete(opts) {
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_PLACE_AUTOCOMPLETE,
        query: opts.query,
        near: opts.near ?? null,
        sessionToken: opts.sessionToken
      });
    }
    placeDetails(opts) {
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_PLACE_DETAILS,
        placeId: opts.placeId,
        sessionToken: opts.sessionToken
      });
    }
    onPivot(handler) {
      return this._pivots.subscribe(handler);
    }
    getPivots() {
      return this._pivots.getPivots();
    }
    getActivePivot() {
      return this._pivots.getActivePivot();
    }
    getUpcomingPivot() {
      return this._pivots.getUpcomingPivot();
    }
    _attachPivotTrackingForTrip(mode, opts) {
      this._detachPivotTracking();
      this._pivots.reset();
      this._pivots.updateOptions(mode, opts);
      this._tripUnsubs.push(this.onRoute((route) => {
        if (route.steps && route.steps.length > 0) {
          const tail = route.points[route.points.length - 1];
          const computedSteps = route.steps.map((s, i) => {
            const next = route.steps?.[i + 1];
            const endLat = next ? next.lat : tail?.lat ?? s.lat;
            const endLng = next ? next.lng : tail?.lng ?? s.lng;
            return {
              lat: s.lat,
              lng: s.lng,
              endLat,
              endLng,
              distanceMeters: s.distanceMeters,
              maneuver: s.maneuver,
              road: s.road ?? undefined
            };
          });
          this._pivots.setRouteFromComputedSteps(route, computedSteps);
          return;
        }
        this._pivots.setRoute(route, null);
        const seq = ++this._computeRouteSeq;
        this._issueComputeRouteForTrip(route).then((result) => {
          if (seq !== this._computeRouteSeq)
            return;
          const computedSteps = result?.routes?.[0]?.steps;
          if (computedSteps && computedSteps.length > 0) {
            this._pivots.setRouteFromComputedSteps(route, computedSteps);
          }
        }).catch((err) => {
          console.warn("[NavigationModule] computeRoute for pivots failed:", err);
        });
      }));
      this._tripUnsubs.push(this.onUpdate((update) => {
        if (update.kind === "arrived") {
          this._pivots.reset();
          return;
        }
      }));
      this._tripUnsubs.push(this.session.location.onUpdate((loc) => {
        this._lastUserPosition = { lat: loc.lat, lng: loc.lng };
        this._pivots.onLocationUpdate({ lat: loc.lat, lng: loc.lng });
      }));
    }
    async _issueComputeRouteForTrip(route) {
      if (!this._tripStops || this._tripStops.length === 0)
        return null;
      const origin = this._lastUserPosition ?? (route?.points && route.points[0] ? { lat: route.points[0].lat, lng: route.points[0].lng } : null);
      if (!origin)
        return null;
      return this.computeRoute({
        origin,
        stops: this._tripStops,
        mode: this._tripMode,
        avoid: this._tripAvoid
      });
    }
    _detachPivotTracking() {
      for (const unsub of this._tripUnsubs) {
        try {
          unsub();
        } catch (err) {
          console.warn("[NavigationModule] pivot-tracking unsubscribe threw:", err);
        }
      }
      this._tripUnsubs = [];
      this._pivots.reset();
      this._tripStops = null;
      this._tripAvoid = undefined;
      this._computeRouteSeq++;
      this._lastUserPosition = null;
    }
  }
  function normalizeStops(opts) {
    if (opts.stops && opts.stops.length > 0) {
      return opts.stops;
    }
    if (typeof opts.lat === "number" && typeof opts.lng === "number") {
      return [{ lat: opts.lat, lng: opts.lng }];
    }
    return [];
  }
  function buildNavRouteFromComputed(computed) {
    const points = computed.points ?? [];
    const steps = (computed.steps ?? []).map((s) => {
      let routeIndex = 0;
      let best = Infinity;
      for (let i = 0;i < points.length; i++) {
        const dLat = points[i].lat - s.lat;
        const dLng = points[i].lng - s.lng;
        const d = dLat * dLat + dLng * dLng;
        if (d < best) {
          best = d;
          routeIndex = i;
        }
      }
      return {
        lat: s.lat,
        lng: s.lng,
        routeIndex,
        road: s.road ?? null,
        maneuver: s.maneuver ?? "STRAIGHT",
        distanceMeters: s.distanceMeters
      };
    });
    return {
      points,
      totalDistanceMeters: computed.totalDistanceMeters,
      totalDurationSeconds: computed.totalDurationSeconds,
      steps: steps.length > 0 ? steps : undefined
    };
  }

  // ../../mobile/modules/miniapp/dist/modules/permissions.js
  class PermissionsModule {
    constructor(session) {
      this.session = session;
    }
    has(type) {
      return this.session._getPermissions()[type] === true;
    }
    getAll() {
      return this.session._getPermissions();
    }
    onUpdate(handler) {
      return this.session.on("permissions", handler);
    }
    onPermissionError(handler) {
      return this.session.on("error", (e) => {
        const maybe = e;
        if (maybe?.code === MiniappErrorCode.PERMISSION_NOT_DECLARED) {
          handler({
            code: String(maybe.code),
            message: String(maybe.message ?? ""),
            permission: maybe.permission,
            subscription: maybe.subscription,
            operation: maybe.operation
          });
        }
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/phone.js
  class TrackedSubs {
    constructor() {
      this.unsubs = new Set;
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
  }

  class PhoneNotificationsModule extends TrackedSubs {
    constructor(session) {
      super();
      this.session = session;
    }
    on(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.PHONE_NOTIFICATION, handler));
    }
    onDismissed(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.PHONE_NOTIFICATION_DISMISSED, handler));
    }
    get hasPermission() {
      return this.session._hasManifestPermission("READ_NOTIFICATIONS");
    }
  }

  class PhoneCalendarModule {
    constructor(session) {
      this.session = session;
    }
    listEvents(options) {
      const startsAt = normalizeCalendarDate(options?.startsAt, "startsAt");
      const endsAt = normalizeCalendarDate(options?.endsAt, "endsAt");
      return this.session.sendRequest({
        type: MiniappRequestType.CALENDAR_LIST_EVENTS,
        startsAt,
        endsAt,
        ...options.limit === undefined ? {} : { limit: options.limit }
      });
    }
    get hasPermission() {
      return this.session._hasManifestPermission("CALENDAR");
    }
  }
  function normalizeCalendarDate(value, field) {
    const date = value instanceof Date ? value : new Date(value ?? "");
    if (Number.isNaN(date.getTime()))
      throw new TypeError(`${field} must be a valid Date or ISO 8601 string`);
    return date.toISOString();
  }

  class PhoneModule {
    constructor(session) {
      this.session = session;
      this.notifications = new PhoneNotificationsModule(session);
      this.calendar = new PhoneCalendarModule(session);
    }
    onBattery(handler) {
      return this.session._subscribe(MiniappStreamType.PHONE_BATTERY, handler);
    }
  }

  // ../../cloud-v2/packages/protocol/src/languages.ts
  var CANONICAL_TAG_BY_CODE = {
    af: "af-ZA",
    am: "am-ET",
    ar: "ar-AE",
    az: "az-AZ",
    be: "be-BY",
    bg: "bg-BG",
    bn: "bn-IN",
    bs: "bs-BA",
    ca: "ca-ES",
    cs: "cs-CZ",
    cy: "cy-GB",
    da: "da-DK",
    de: "de-DE",
    el: "el-GR",
    en: "en-US",
    es: "es-ES",
    et: "et-EE",
    eu: "eu-ES",
    fa: "fa-IR",
    fi: "fi-FI",
    fr: "fr-FR",
    gl: "gl-ES",
    gu: "gu-IN",
    he: "he-IL",
    hi: "hi-IN",
    hr: "hr-HR",
    hu: "hu-HU",
    hy: "hy-AM",
    id: "id-ID",
    it: "it-IT",
    ja: "ja-JP",
    ka: "ka-GE",
    kk: "kk-KZ",
    kn: "kn-IN",
    ko: "ko-KR",
    lt: "lt-LT",
    lv: "lv-LV",
    mk: "mk-MK",
    ml: "ml-IN",
    mr: "mr-IN",
    ms: "ms-MY",
    nb: "nb-NO",
    ne: "ne-NP",
    nl: "nl-NL",
    no: "nb-NO",
    pa: "pa-IN",
    pl: "pl-PL",
    pt: "pt-BR",
    ro: "ro-RO",
    ru: "ru-RU",
    sk: "sk-SK",
    sl: "sl-SI",
    sq: "sq-AL",
    sr: "sr-RS",
    sv: "sv-SE",
    sw: "sw-KE",
    ta: "ta-IN",
    te: "te-IN",
    th: "th-TH",
    tl: "fil-PH",
    tr: "tr-TR",
    uk: "uk-UA",
    ur: "ur-IN",
    vi: "vi-VN",
    zh: "zh-CN"
  };
  var EXTRA_REGIONAL_TAGS = [
    "ar-EG",
    "ar-SA",
    "de-AT",
    "de-CH",
    "en-AU",
    "en-CA",
    "en-GB",
    "en-IN",
    "es-419",
    "es-MX",
    "es-US",
    "fr-CA",
    "nl-BE",
    "pt-PT",
    "zh-HK",
    "zh-TW"
  ];
  var SUPPORTED_LANGUAGE_HINTS = Object.freeze([...new Set(Object.keys(CANONICAL_TAG_BY_CODE))].sort());
  var SUPPORTED_TRANSCRIPTION_LANGUAGES = Object.freeze([
    ...new Set([
      ...Object.values(CANONICAL_TAG_BY_CODE),
      ...EXTRA_REGIONAL_TAGS
    ])
  ].sort());
  var TAG_SET = new Set(SUPPORTED_TRANSCRIPTION_LANGUAGES);
  var HINT_SET = new Set(SUPPORTED_LANGUAGE_HINTS);
  function toTranscriptionLanguage(value) {
    if (TAG_SET.has(value))
      return value;
    const canonical = CANONICAL_TAG_BY_CODE[value.toLowerCase()];
    return canonical ?? null;
  }
  function toLanguageHint(value) {
    const primary = value.split("-")[0].toLowerCase();
    return HINT_SET.has(primary) ? primary : null;
  }
  function suggestTranscriptionLanguage(value) {
    const normalized = value.replace(/_/g, "-");
    const parts = normalized.split("-");
    const recased = parts.length >= 2 ? `${parts[0].toLowerCase()}-${parts[1].toUpperCase()}` : normalized.toLowerCase();
    return toTranscriptionLanguage(recased);
  }

  // ../../mobile/modules/miniapp/dist/modules/languages.js
  class MiniappValidationError extends Error {
    constructor(message) {
      super(message);
      this.name = "MiniappValidationError";
    }
  }
  function requireTranscriptionLanguage(value, param) {
    const canonical = toTranscriptionLanguage(value);
    if (canonical)
      return canonical;
    const suggestion = suggestTranscriptionLanguage(value);
    throw new MiniappValidationError(`${param}: unknown language ${JSON.stringify(value)}` + (suggestion ? ` — did you mean ${JSON.stringify(suggestion)}?` : "") + ` Supported values are BCP-47 tags from SUPPORTED_TRANSCRIPTION_LANGUAGES (e.g. "en-US", "fr-FR").`);
  }
  function requireLanguageHint(value, param) {
    const hint = toLanguageHint(value);
    if (hint)
      return hint;
    throw new MiniappValidationError(`${param}: unknown language hint ${JSON.stringify(value)}. ` + `Hints are bare ISO 639-1 codes from SUPPORTED_LANGUAGE_HINTS (e.g. "en", "fr").`);
  }

  // ../../mobile/modules/miniapp/dist/modules/transcription.js
  class TranscriptionModule {
    constructor(session) {
      this.session = session;
      this.unsubs = new Set;
      this.currentConfig = null;
    }
    on(handler, options = {}) {
      return this.track(this.session._subscribe(`${MiniappStreamType.TRANSCRIPTION}:auto`, handler, options));
    }
    forLanguage(language, handler, options = {}) {
      const langs = (Array.isArray(language) ? language : [language]).map((lang) => requireTranscriptionLanguage(lang, "transcription.forLanguage(language)"));
      if (langs.length === 0)
        return () => {};
      const unsubs = [];
      for (const lang of langs) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TRANSCRIPTION}:${lang}`, handler, options));
      }
      const combined = () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
      return this.track(combined);
    }
    configure(config) {
      const normalized = {
        ...config,
        languageHints: config.languageHints?.map((hint) => requireLanguageHint(hint, "transcription.configure(languageHints)"))
      };
      this.currentConfig = { ...normalized };
      return this.session.sendRequest({
        type: MiniappRequestType.TRANSCRIPTION_CONFIG,
        config: { ...normalized }
      }).then(() => {
        return;
      });
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
    get hasPermission() {
      return this.session._hasManifestPermission("MICROPHONE");
    }
    _getConfig() {
      return this.currentConfig ? { ...this.currentConfig } : null;
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/translation.js
  class TranslationModule {
    constructor(session) {
      this.session = session;
      this.unsubs = new Set;
    }
    on(handler) {
      return this.track(this.session._subscribe(`${MiniappStreamType.TRANSLATION}:*:*`, handler));
    }
    to(target, handler) {
      const targets = (Array.isArray(target) ? target : [target]).map((t) => requireTranscriptionLanguage(t, "translation.to(target)"));
      if (targets.length === 0)
        return () => {};
      const unsubs = [];
      for (const t of targets) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TRANSLATION}:*:${t}`, handler));
      }
      const composite = () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
      return this.track(composite);
    }
    fromTo(source, target, handler) {
      const validSource = source === "auto" ? "auto" : requireTranscriptionLanguage(source, "translation.fromTo(source)");
      const targets = (Array.isArray(target) ? target : [target]).map((t) => requireTranscriptionLanguage(t, "translation.fromTo(target)"));
      if (targets.length === 0)
        return () => {};
      const unsubs = [];
      for (const t of targets) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TRANSLATION}:${validSource}:${t}`, handler));
      }
      const composite = () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
      return this.track(composite);
    }
    forLanguagePair(fromLang, toLang, handler) {
      return this.fromTo(fromLang, toLang, handler);
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
    get hasPermission() {
      return this.session._hasManifestPermission("MICROPHONE");
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/ui.js
  function rpcErrorFromUnknown(e) {
    if (e instanceof Error) {
      const own = e;
      const cause = own.cause;
      return compactEnvelope({
        message: e.message,
        code: own.code ?? cause?.code,
        stage: own.stage,
        transport: own.transport
      });
    }
    if (e && typeof e === "object") {
      const o = e;
      return compactEnvelope({
        message: typeof o.message === "string" ? o.message : JSON.stringify(e),
        code: typeof o.code === "string" ? o.code : undefined,
        stage: typeof o.stage === "string" ? o.stage : undefined,
        transport: typeof o.transport === "string" ? o.transport : undefined
      });
    }
    return { message: String(e) };
  }
  function compactEnvelope(env) {
    const out = { message: env.message };
    if (env.code)
      out.code = env.code;
    if (env.stage)
      out.stage = env.stage;
    if (env.transport)
      out.transport = env.transport;
    return out;
  }

  class UIModuleImpl {
    constructor(session) {
      this.session = session;
      this.bound = false;
      this.nextSeq = 1;
      this.openHandlers = new Set;
      this.closeHandlers = new Set;
      this.channelHandlers = new Map;
      this.rpcHandlers = new Map;
      this.inflightRpc = new Map;
      this.isOpen = () => {
        return this.bound;
      };
      this.onOpen = (cb) => {
        this.openHandlers.add(cb);
        if (this.bound) {
          if (this.session.ready) {
            try {
              cb();
            } catch (e) {
              console.warn("session.ui.onOpen late-fire threw:", e);
            }
          }
        }
        return () => {
          this.openHandlers.delete(cb);
        };
      };
      this.onClose = (cb) => {
        this.closeHandlers.add(cb);
        return () => {
          this.closeHandlers.delete(cb);
        };
      };
      this.send = (channel, payload) => {
        if (!this.bound) {
          return;
        }
        const seq = this.nextSeq++;
        const envelope = { type: "UI_SEND", channel, payload, seq };
        this.session.sendOneShot(envelope);
      };
      this.on = (channel, cb) => {
        let set = this.channelHandlers.get(channel);
        if (!set) {
          set = new Set;
          this.channelHandlers.set(channel, set);
        }
        set.add(cb);
        return () => {
          set.delete(cb);
        };
      };
      this.handle = (channel, handler) => {
        const key = channel;
        if (this.rpcHandlers.has(key)) {
          throw new Error(`session.ui.handle: a handler is already registered for "${key}"`);
        }
        this.rpcHandlers.set(key, handler);
        return () => {
          this.rpcHandlers.delete(key);
        };
      };
      this.session._subscribe("_ui", (env) => this.handleInbound(env));
    }
    fireOpenHandlers() {
      for (const h of this.openHandlers) {
        try {
          h();
        } catch (e) {
          console.warn("session.ui.onOpen handler threw", e);
        }
      }
    }
    handleInbound(env) {
      if (env.type === "UI_OPEN") {
        this.bound = true;
        this.nextSeq = 1;
        if (this.session.ready) {
          this.fireOpenHandlers();
        } else {
          const off = this.session.on("ready", () => {
            off();
            if (this.bound)
              this.fireOpenHandlers();
          });
        }
        return;
      }
      if (env.type === "UI_CLOSE") {
        this.bound = false;
        for (const h of this.closeHandlers) {
          try {
            h();
          } catch (e) {
            console.warn("session.ui.onClose handler threw", e);
          }
        }
        return;
      }
      if (env.type === "UI_MESSAGE") {
        if (typeof env.requestId === "string") {
          this.dispatchRpcCall(env.channel, env.payload, env.requestId);
          return;
        }
        const set = this.channelHandlers.get(env.channel);
        if (!set || set.size === 0)
          return;
        for (const h of set) {
          try {
            h(env.payload);
          } catch (e) {
            console.warn(`session.ui.on(${env.channel}) threw`, e);
          }
        }
        return;
      }
      if (env.type === "UI_CANCEL") {
        const ctrl = this.inflightRpc.get(env.requestId);
        if (ctrl) {
          try {
            ctrl.abort();
          } catch {}
        }
        return;
      }
    }
    dispatchRpcCall(channel, payload, requestId) {
      const handler = this.rpcHandlers.get(channel);
      if (!handler) {
        this.sendRpcReply(channel, requestId, {
          ok: false,
          error: { message: `no handler registered for "${channel}"` }
        });
        return;
      }
      const ctrl = new AbortController;
      this.inflightRpc.set(requestId, ctrl);
      const ctx = { signal: ctrl.signal };
      const finish = (envelope) => {
        this.inflightRpc.delete(requestId);
        if (ctrl.signal.aborted)
          return;
        this.sendRpcReply(channel, requestId, envelope);
      };
      let result;
      try {
        result = handler(payload, ctx);
      } catch (e) {
        finish({ ok: false, error: rpcErrorFromUnknown(e) });
        return;
      }
      if (result && typeof result.then === "function") {
        result.then((v) => finish({ ok: true, result: v }), (e) => finish({ ok: false, error: rpcErrorFromUnknown(e) }));
      } else {
        finish({ ok: true, result });
      }
    }
    sendRpcReply(channel, requestId, payload) {
      if (!this.bound)
        return;
      const seq = this.nextSeq++;
      const envelope = { type: "UI_SEND", channel, payload, seq, requestId };
      this.session.sendOneShot(envelope);
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/storage.js
  class SimpleStorage {
    constructor(session) {
      this.session = session;
    }
    async get(key) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_GET,
        key
      });
      return result?.value ?? null;
    }
    async set(key, value) {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_SET,
        key,
        value
      });
    }
    async delete(key) {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_DELETE,
        key
      });
    }
    async keys() {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_LIST
      });
      return result?.keys ?? [];
    }
    async list() {
      return this.keys();
    }
    async clear() {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_CLEAR
      });
    }
    async has(key) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_HAS,
        key
      });
      return !!result?.has;
    }
    async getAll() {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_GET_ALL
      });
      return result?.values ?? {};
    }
    async setMultiple(values) {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_SET_MULTIPLE,
        values
      });
    }
    async flush() {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_FLUSH
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/base64.js
  var ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  var LOOKUP = (() => {
    const t = new Int16Array(256).fill(-1);
    for (let i = 0;i < ALPHABET.length; i++)
      t[ALPHABET.charCodeAt(i)] = i;
    t[61] = 0;
    return t;
  })();
  function toUint8Array(input) {
    if (input instanceof Uint8Array)
      return input;
    if (input instanceof ArrayBuffer)
      return new Uint8Array(input);
    return new Uint8Array(input.buffer, input.byteOffset, input.byteLength);
  }
  function bytesToBase64(input) {
    const bytes = input instanceof Uint8Array ? input : new Uint8Array(input);
    const len = bytes.length;
    let out = "";
    let i = 0;
    for (;i + 2 < len; i += 3) {
      const n = bytes[i] << 16 | bytes[i + 1] << 8 | bytes[i + 2];
      out += ALPHABET[n >> 18 & 63] + ALPHABET[n >> 12 & 63] + ALPHABET[n >> 6 & 63] + ALPHABET[n & 63];
    }
    const rem = len - i;
    if (rem === 1) {
      const n = bytes[i] << 16;
      out += ALPHABET[n >> 18 & 63] + ALPHABET[n >> 12 & 63] + "==";
    } else if (rem === 2) {
      const n = bytes[i] << 16 | bytes[i + 1] << 8;
      out += ALPHABET[n >> 18 & 63] + ALPHABET[n >> 12 & 63] + ALPHABET[n >> 6 & 63] + "=";
    }
    return out;
  }
  function base64ToBytes(b64) {
    let validChars = 0;
    let pad = 0;
    for (let i = 0;i < b64.length; i++) {
      const c = b64.charCodeAt(i);
      if (c === 61) {
        pad++;
        validChars++;
      } else if (LOOKUP[c] !== -1) {
        validChars++;
      }
    }
    const fullGroups = Math.floor(validChars / 4);
    const remChars = validChars - fullGroups * 4;
    let outLen = fullGroups * 3 - (pad > 0 && remChars === 0 ? pad : 0);
    if (remChars === 2)
      outLen += 1;
    else if (remChars === 3)
      outLen += 2;
    if (outLen < 0)
      outLen = 0;
    const out = new Uint8Array(outLen);
    let acc = 0;
    let bits = 0;
    let o = 0;
    for (let i = 0;i < b64.length && o < outLen; i++) {
      const c = b64.charCodeAt(i);
      if (c === 61)
        break;
      const v = LOOKUP[c];
      if (v === -1)
        continue;
      acc = acc << 6 | v;
      bits += 6;
      if (bits >= 8) {
        bits -= 8;
        out[o++] = acc >> bits & 255;
      }
    }
    return out;
  }

  // ../../mobile/modules/miniapp/dist/modules/speaker.js
  var SPEAKER_WRITE_CHUNK_BYTES = 256 * 1024;
  var SPEAKER_WRITE_CHUNK_B64 = Math.floor(SPEAKER_WRITE_CHUNK_BYTES / 6) * 8;
  class SpeakerStreamWriter {
    constructor(session, streamId) {
      this.session = session;
      this.streamId = streamId;
      this.settled = false;
      this.writeChain = Promise.resolve();
    }
    async write(chunk) {
      this.assertOpen();
      const bytes = toUint8Array(chunk);
      if (bytes.byteLength === 0)
        throw new Error("PCM chunk cannot be empty");
      if (bytes.byteLength % 2 !== 0)
        throw new Error("PCM chunk must contain complete 16-bit samples");
      return this.enqueueWrite(async () => {
        let last = { bufferedMs: 0 };
        for (let off = 0;off < bytes.length; off += SPEAKER_WRITE_CHUNK_BYTES) {
          last = await this.send(bytesToBase64(bytes.subarray(off, off + SPEAKER_WRITE_CHUNK_BYTES)));
        }
        return last;
      });
    }
    async writeBase64(b64) {
      this.assertOpen();
      if (b64.length === 0 || b64.length % 4 !== 0)
        throw new Error("PCM base64 must be non-empty and padded");
      const padding = b64.endsWith("==") ? 2 : b64.endsWith("=") ? 1 : 0;
      const decodedBytes = b64.length / 4 * 3 - padding;
      if (decodedBytes % 2 !== 0)
        throw new Error("PCM base64 must contain complete 16-bit samples");
      return this.enqueueWrite(async () => {
        let last = { bufferedMs: 0 };
        for (let off = 0;off < b64.length; off += SPEAKER_WRITE_CHUNK_B64) {
          last = await this.send(b64.slice(off, off + SPEAKER_WRITE_CHUNK_B64));
        }
        return last;
      });
    }
    async close() {
      this.assertOpen();
      this.settled = true;
      await this.writeChain;
      const res = await this.session.sendRequest({ type: MiniappRequestType.SPEAKER_STREAM_CLOSE, streamId: this.streamId }, { timeoutMs: 0 });
      return res ?? {};
    }
    async abort() {
      if (this.settled)
        return;
      this.settled = true;
      await this.session.sendRequest({
        type: MiniappRequestType.SPEAKER_STREAM_ABORT,
        streamId: this.streamId
      });
    }
    assertOpen() {
      if (this.settled)
        throw new Error("SpeakerStreamWriter is already closed/aborted");
    }
    async send(base64) {
      const res = await this.session.sendRequest({
        type: MiniappRequestType.SPEAKER_STREAM_WRITE,
        streamId: this.streamId,
        base64
      });
      return res ?? { bufferedMs: 0 };
    }
    enqueueWrite(operation) {
      const result = this.writeChain.then(operation);
      this.writeChain = result.then(() => {
        return;
      }, () => {
        return;
      });
      return result;
    }
  }

  class SpeakerModule {
    constructor(session) {
      this.session = session;
      this._state = "idle";
      this._lastEvent = { state: "idle" };
    }
    get state() {
      return this._state;
    }
    get isPlaying() {
      return this._state === "playing";
    }
    async play(options) {
      await this.session.sendRequest({
        type: MiniappRequestType.PLAY_AUDIO,
        audioUrl: options.audioUrl,
        volume: options.volume,
        stopOtherAudio: options.stopOtherAudio ?? false
      }, { timeoutMs: 0 });
    }
    async speak(text, options = {}) {
      const normalized = Array.isArray(text) ? text.map((sentence) => sentence.trim()).filter(Boolean) : text.trim();
      if (Array.isArray(normalized) && normalized.length === 0 || normalized === "") {
        throw { code: MiniappErrorCode.INTERNAL, message: "speak requires at least one non-empty sentence" };
      }
      try {
        const result = await this.session.sendRequest({
          type: MiniappRequestType.SPEAK,
          text: normalized,
          voice_id: options.voice_id,
          voice_settings: options.voice_settings,
          volume: options.volume,
          stopOtherAudio: options.stopOtherAudio ?? false,
          enableSanitization: options.enableSanitization ?? true,
          forceLocal: options.forceLocal ?? false
        }, { timeoutMs: 0 });
        return result ?? { completed: true };
      } catch (err) {
        if (err && typeof err === "object" && "code" in err) {
          throw err;
        }
        throw { code: MiniappErrorCode.INTERNAL, message: String(err) };
      }
    }
    async createStream(options = {}) {
      if (options.volume !== undefined && (!Number.isFinite(options.volume) || options.volume < 0 || options.volume > 1)) {
        throw new RangeError("speaker stream volume must be between 0 and 1");
      }
      const res = await this.session.sendRequest({
        type: MiniappRequestType.SPEAKER_STREAM_OPEN,
        sampleRate: options.sampleRate ?? 16000,
        channels: options.channels ?? 1,
        volume: options.volume,
        stopOtherAudio: options.stopOtherAudio ?? true
      });
      return new SpeakerStreamWriter(this.session, res.streamId);
    }
    stop() {
      this.session.sendOneShot({ type: MiniappRequestType.STOP_AUDIO });
    }
    onStateChange(handler) {
      return this.session.on("speakerState", handler);
    }
    _applyState(event) {
      if (event.state === this._state && event.state !== "error")
        return;
      this._state = event.state;
      this._lastEvent = event;
    }
    _getLastEvent() {
      return { ...this._lastEvent };
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/stream.js
  class StreamModule {
    constructor(session) {
      this.session = session;
    }
    async startStream(options = {}) {
      if (options.direct !== undefined) {
        return this.session.sendRequest({
          type: MiniappRequestType.STREAM_START,
          streamUrl: options.direct,
          video: options.video,
          audio: options.audio,
          sound: options.sound ?? true,
          ...options.authToken ? { authToken: options.authToken } : {},
          ...typeof options.captureAudio === "boolean" ? { captureAudio: options.captureAudio } : {}
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.MANAGED_STREAM_START,
        restreamDestinations: options.destinations,
        video: options.video,
        audio: options.audio,
        sound: options.sound ?? true,
        ingest: options.ingest,
        ...typeof options.captureAudio === "boolean" ? { captureAudio: options.captureAudio } : {}
      });
    }
    async stop(streamId) {
      await this.session.sendRequest({
        type: MiniappRequestType.STREAM_STOP,
        streamId
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/system.js
  class SystemModule {
    constructor(session) {
      this.session = session;
    }
    async share(options) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.SHARE,
        ...options
      });
      return result ?? { success: false };
    }
    openUrl(url) {
      this.session.sendOneShot({
        type: MiniappRequestType.OPEN_URL,
        url
      });
    }
    async copyToClipboard(text) {
      await this.session.sendRequest({
        type: MiniappRequestType.COPY_CLIPBOARD,
        text
      });
    }
    async download(options) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.DOWNLOAD,
        ...options
      });
      return result ?? { success: false };
    }
    async scanQr(options = {}) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.SCAN_QR,
        ...options
      }, { timeoutMs: 0 });
      return result ?? { cancelled: true };
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/miniapps.js
  class MiniappsModule {
    constructor(session) {
      this.session = session;
    }
    async list(opts) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.MINIAPPS_LIST,
        includeIncompatible: opts?.includeIncompatible ?? false
      });
      return result ?? [];
    }
    async start(packageName) {
      await this.session.sendRequest({
        type: MiniappRequestType.MINIAPPS_START,
        packageName
      });
    }
    async stop(packageName) {
      await this.session.sendRequest({
        type: MiniappRequestType.MINIAPPS_STOP,
        packageName
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/actions.js
  var HANDLER_WAIT_MS = 5000;

  class ActionsModule {
    constructor(session) {
      this.session = session;
      this.handlers = new Map;
      this.buffered = new Map;
    }
    invoke(packageName, actionId, params, opts) {
      return this.session.sendRequest({
        type: MiniappRequestType.ACTION_INVOKE,
        targetPackageName: packageName,
        actionId,
        params: params ?? {},
        ...opts?.timeoutMs != null ? { timeoutMs: opts.timeoutMs } : {}
      });
    }
    handle(actionId, handler) {
      if (this.handlers.has(actionId)) {
        throw new Error(`session.actions.handle: a handler is already registered for "${actionId}"`);
      }
      this.handlers.set(actionId, handler);
      const waiting = this.buffered.get(actionId);
      if (waiting) {
        this.buffered.delete(actionId);
        for (const call of waiting) {
          clearTimeout(call.timer);
          this.dispatch(call.callId, actionId, call.params, call.ctx);
        }
      }
      return () => {
        if (this.handlers.get(actionId) === handler)
          this.handlers.delete(actionId);
      };
    }
    _deliver(callId, actionId, params, ctx) {
      if (this.handlers.has(actionId)) {
        this.dispatch(callId, actionId, params, ctx);
        return;
      }
      const timer = setTimeout(() => {
        const arr2 = this.buffered.get(actionId);
        if (arr2) {
          const idx = arr2.findIndex((c) => c.callId === callId);
          if (idx >= 0)
            arr2.splice(idx, 1);
          if (arr2.length === 0)
            this.buffered.delete(actionId);
        }
        this.sendResult(callId, false, undefined, {
          code: MiniappErrorCode.NO_ACTION_HANDLER,
          message: `No handler registered for action "${actionId}"`
        });
      }, HANDLER_WAIT_MS);
      const arr = this.buffered.get(actionId) ?? [];
      arr.push({ callId, params, ctx, timer });
      this.buffered.set(actionId, arr);
    }
    async dispatch(callId, actionId, params, ctx) {
      const handler = this.handlers.get(actionId);
      if (!handler)
        return;
      try {
        const result = await handler(params, ctx);
        this.sendResult(callId, true, result ?? null);
      } catch (e) {
        this.sendResult(callId, false, undefined, {
          code: MiniappErrorCode.INTERNAL,
          message: e?.message ?? "action handler threw"
        });
      }
    }
    sendResult(callId, ok, result, error) {
      this.session.sendOneShot({
        type: MiniappRequestType.ACTION_RESULT,
        callId,
        ok,
        ...ok ? { result } : { error }
      });
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/blob.js
  var BLOB_WRITE_CHUNK_BYTES = 1024 * 1024;
  var BLOB_WRITE_CHUNK_B64 = Math.floor(BLOB_WRITE_CHUNK_BYTES / 3) * 4;
  var BLOB_READ_ALL_MAX_BYTES = 32 * 1024 * 1024;

  class BlobWriter {
    constructor(session, key) {
      this.session = session;
      this.key = key;
      this.settled = false;
    }
    async write(chunk) {
      this.assertOpen();
      const bytes = toUint8Array(chunk);
      for (let off = 0;off < bytes.length; off += BLOB_WRITE_CHUNK_BYTES) {
        await this.send(bytesToBase64(bytes.subarray(off, off + BLOB_WRITE_CHUNK_BYTES)));
      }
    }
    async writeBase64(b64) {
      this.assertOpen();
      for (let off = 0;off < b64.length; off += BLOB_WRITE_CHUNK_B64) {
        await this.send(b64.slice(off, off + BLOB_WRITE_CHUNK_B64));
      }
    }
    async writeAt(offset, chunk) {
      this.assertOpen();
      await this.session.sendRequest({
        type: MiniappRequestType.BLOB_WRITE,
        key: this.key,
        offset,
        base64: bytesToBase64(toUint8Array(chunk))
      });
    }
    async close(meta) {
      this.assertOpen();
      this.settled = true;
      return this.session.sendRequest({ type: MiniappRequestType.BLOB_COMMIT, key: this.key, meta });
    }
    async abort() {
      if (this.settled)
        return;
      this.settled = true;
      await this.session.sendRequest({ type: MiniappRequestType.BLOB_ABORT, key: this.key });
    }
    assertOpen() {
      if (this.settled)
        throw new Error("BlobWriter is already closed/aborted");
    }
    send(base64) {
      return this.session.sendRequest({
        type: MiniappRequestType.BLOB_WRITE,
        key: this.key,
        base64
      });
    }
  }

  class BlobReader {
    constructor(session, handle, meta) {
      this.session = session;
      this.handle = handle;
      this.meta = meta;
      this.closed = false;
    }
    async read(maxBytes = BLOB_WRITE_CHUNK_BYTES) {
      if (this.closed)
        throw new Error("BlobReader is closed");
      const res = await this.session.sendRequest({
        type: MiniappRequestType.BLOB_READ,
        handle: this.handle,
        maxBytes
      });
      return { bytes: base64ToBytes(res?.base64 ?? ""), done: !!res?.done };
    }
    async close() {
      if (this.closed)
        return;
      this.closed = true;
      await this.session.sendRequest({ type: MiniappRequestType.BLOB_CLOSE_READ, handle: this.handle });
    }
  }

  class BlobModule {
    constructor(session) {
      this.session = session;
    }
    async set(key, data, opts = {}) {
      const writer = await this.createWriteStream(key, opts);
      try {
        if (typeof data === "string")
          await writer.writeBase64(data);
        else
          await writer.write(data);
        return await writer.close();
      } catch (err) {
        await writer.abort().catch(() => {});
        throw err;
      }
    }
    setFromUrl(key, url, opts = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.BLOB_SET_FROM_URL,
        key,
        url,
        mimeType: opts.mimeType,
        name: opts.name,
        headers: opts.headers,
        meta: opts.meta
      });
    }
    importFile(opts = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.BLOB_IMPORT,
        key: opts.key,
        mimeType: opts.mimeType,
        meta: opts.meta
      });
    }
    async createWriteStream(key, opts = {}) {
      const res = await this.session.sendRequest({
        type: MiniappRequestType.BLOB_CREATE,
        key,
        mimeType: opts.mimeType,
        name: opts.name,
        meta: opts.meta
      });
      return new BlobWriter(this.session, res.key);
    }
    get(key) {
      return this.session.sendRequest({ type: MiniappRequestType.BLOB_GET, key });
    }
    stat(key) {
      return this.get(key);
    }
    async has(key) {
      return await this.get(key) !== null;
    }
    async keys() {
      return (await this.list()).map((m) => m.key);
    }
    async list() {
      const res = await this.session.sendRequest({ type: MiniappRequestType.BLOB_LIST });
      return res?.blobs ?? [];
    }
    async createReadStream(key) {
      const res = await this.session.sendRequest({
        type: MiniappRequestType.BLOB_OPEN_READ,
        key
      });
      return new BlobReader(this.session, res.handle, res.meta);
    }
    async bytes(key) {
      let reader;
      try {
        reader = await this.createReadStream(key);
      } catch {
        return null;
      }
      const parts = [];
      let total = 0;
      try {
        for (;; ) {
          const { bytes, done } = await reader.read();
          if (bytes.length) {
            total += bytes.length;
            if (total > BLOB_READ_ALL_MAX_BYTES) {
              throw new Error(`Blob "${key}" exceeds the in-memory read cap — stream it with createReadStream()`);
            }
            parts.push(bytes);
          }
          if (done)
            break;
        }
      } finally {
        await reader.close().catch(() => {});
      }
      const out = new Uint8Array(total);
      let at = 0;
      for (const p of parts) {
        out.set(p, at);
        at += p.length;
      }
      return out;
    }
    usage() {
      return this.session.sendRequest({
        type: MiniappRequestType.BLOB_USAGE
      });
    }
    async delete(key) {
      await this.session.sendRequest({ type: MiniappRequestType.BLOB_DELETE, key });
    }
    async clear() {
      await this.session.sendRequest({ type: MiniappRequestType.BLOB_CLEAR });
    }
    async share(key) {
      const res = await this.session.sendRequest({
        type: MiniappRequestType.BLOB_SHARE,
        key
      });
      return res ?? { success: false };
    }
  }

  // ../../mobile/modules/miniapp/dist/modules/meeting.js
  var MEETING_HOST_UPDATE_MESSAGE = "Update the Mentra App to use Teams calling";
  function validateMeetingVideoSource(source) {
    const value = source ?? {};
    if (value.type === "whep") {
      const url = typeof value.url === "string" ? value.url.trim() : "";
      if (!url) {
        throw { code: MiniappErrorCode.INVALID_ARGUMENT, message: "videoSource.url is required for a WHEP source" };
      }
      return { type: "whep", url };
    }
    if (value.type === "softap") {
      const ssid = typeof value.ssid === "string" ? value.ssid.trim() : "";
      const passphrase = typeof value.passphrase === "string" ? value.passphrase : "";
      if (Boolean(ssid) !== Boolean(passphrase)) {
        throw {
          code: MiniappErrorCode.INVALID_ARGUMENT,
          message: "videoSource.ssid and videoSource.passphrase must be provided together"
        };
      }
      return ssid ? { type: "softap", ssid, passphrase } : { type: "softap" };
    }
    throw {
      code: MiniappErrorCode.INVALID_ARGUMENT,
      message: `videoSource must be {type: "whep", url} or {type: "softap"}`
    };
  }
  function parseMeetingEndReason(raw) {
    if (!raw || typeof raw !== "object")
      return;
    const value = raw;
    const number = (field) => typeof field === "number" && Number.isFinite(field) ? field : undefined;
    const code = number(value.code);
    const subcode = number(value.subcode);
    const message = typeof value.message === "string" && value.message ? value.message : undefined;
    if (code === undefined && subcode === undefined && message === undefined)
      return;
    return {
      ...code !== undefined ? { code } : {},
      ...subcode !== undefined ? { subcode } : {},
      ...message !== undefined ? { message } : {}
    };
  }
  function parseMeetingCapabilities(raw) {
    if (!raw || typeof raw !== "object")
      return;
    const value = raw.hangUpForEveryone;
    if (!value || typeof value !== "object")
      return;
    const capability = value;
    return {
      hangUpForEveryone: {
        allowed: typeof capability.allowed === "boolean" ? capability.allowed : null,
        reason: typeof capability.reason === "string" && capability.reason ? capability.reason : null
      }
    };
  }
  var SOFTAP_STEPS = new Set(["hotspot", "scopedJoin", "acsJoin", "publish", "live"]);
  var SOFTAP_STEP_STATUSES = new Set(["pending", "running", "done", "failed"]);
  var SOFTAP_PHASES = new Set([
    "idle",
    "starting",
    "recovering",
    "live",
    "stopping",
    "failed"
  ]);
  function parseMeetingSoftApProgress(raw) {
    if (!raw || typeof raw !== "object")
      return;
    const value = raw;
    if (!SOFTAP_PHASES.has(String(value.phase)) || !Array.isArray(value.steps))
      return;
    const steps = [];
    for (const entry of value.steps) {
      if (!entry || typeof entry !== "object")
        continue;
      const step = entry;
      if (!SOFTAP_STEPS.has(String(step.step)) || !SOFTAP_STEP_STATUSES.has(String(step.status)))
        continue;
      steps.push({
        step: step.step,
        status: step.status,
        detail: typeof step.detail === "string" && step.detail ? step.detail : undefined,
        error: typeof step.error === "string" && step.error ? step.error : undefined,
        durationMs: typeof step.durationMs === "number" && Number.isFinite(step.durationMs) ? step.durationMs : undefined
      });
    }
    return {
      traceId: typeof value.traceId === "string" && value.traceId ? value.traceId : undefined,
      phase: value.phase,
      steps,
      elapsedMs: typeof value.elapsedMs === "number" && Number.isFinite(value.elapsedMs) ? value.elapsedMs : 0
    };
  }
  function parseMeetingRecovery(raw) {
    if (!raw || typeof raw !== "object")
      return;
    const value = raw;
    if (typeof value.active !== "boolean")
      return;
    const generation = typeof value.generation === "number" && Number.isFinite(value.generation) ? value.generation : undefined;
    const deadlineAt = typeof value.deadlineAt === "number" && Number.isFinite(value.deadlineAt) ? value.deadlineAt : undefined;
    const phase = typeof value.phase === "string" && value.phase ? value.phase : undefined;
    return {
      active: value.active,
      ...generation !== undefined ? { generation } : {},
      ...deadlineAt !== undefined ? { deadlineAt } : {},
      ...phase ? { phase } : {}
    };
  }
  var PARTICIPANT_STATES = new Set([
    "idle",
    "connecting",
    "connected",
    "lobby",
    "hold",
    "disconnected"
  ]);
  var MEDIA_SOURCES = new Set(["idle", "connecting", "live", "failed"]);
  function parseMeetingMediaSource(raw) {
    return MEDIA_SOURCES.has(String(raw)) ? raw : undefined;
  }
  function parseMeetingParticipants(raw) {
    if (!Array.isArray(raw))
      return;
    const result = [];
    for (const entry of raw) {
      if (!entry || typeof entry !== "object")
        continue;
      const value = entry;
      if (typeof value.id !== "string" || !value.id)
        continue;
      result.push({
        id: value.id,
        displayName: typeof value.displayName === "string" && value.displayName ? value.displayName : null,
        state: PARTICIPANT_STATES.has(String(value.state)) ? value.state : "idle",
        isMuted: Boolean(value.isMuted),
        isSpeaking: Boolean(value.isSpeaking)
      });
    }
    return result;
  }
  function isMiniappRequestError(error) {
    return Boolean(error && typeof error === "object" && "code" in error);
  }
  function mapHostError(error) {
    if (isMiniappRequestError(error) && error.code === MiniappErrorCode.NOT_IMPLEMENTED) {
      throw { code: MiniappErrorCode.NOT_IMPLEMENTED, message: MEETING_HOST_UPDATE_MESSAGE };
    }
    throw error;
  }

  class MeetingModule {
    constructor(session) {
      this.session = session;
      this._state = { state: "idle", muted: false };
    }
    get state() {
      return { ...this._state };
    }
    async join(options) {
      if (options.provider !== "acs-teams") {
        throw { code: MiniappErrorCode.INVALID_ARGUMENT, message: `Unsupported meeting provider: ${options.provider}` };
      }
      if (!options.meetingUrl?.trim()) {
        throw { code: MiniappErrorCode.INVALID_ARGUMENT, message: "meetingUrl is required" };
      }
      const videoSource = validateMeetingVideoSource(options.videoSource);
      if (!options.token?.trim()) {
        throw { code: MiniappErrorCode.INVALID_ARGUMENT, message: "token is required" };
      }
      try {
        const result = await this.session.sendRequest({
          type: MiniappRequestType.MEETING_JOIN,
          provider: options.provider,
          meetingUrl: options.meetingUrl,
          videoSource,
          token: options.token,
          displayName: options.displayName,
          ...options.origin ? { origin: options.origin } : {},
          ...options.video ? { video: options.video } : {}
        }, { timeoutMs: 0 });
        if (result)
          this._applyState(result);
        return this.state;
      } catch (error) {
        mapHostError(error);
      }
    }
    async leave() {
      try {
        await this.session.sendRequest({ type: MiniappRequestType.MEETING_LEAVE });
      } catch (error) {
        mapHostError(error);
      }
    }
    async end() {
      try {
        await this.session.sendRequest({ type: MiniappRequestType.MEETING_END }, { timeoutMs: 0 });
      } catch (error) {
        mapHostError(error);
      }
    }
    async setMuted(muted) {
      try {
        const result = await this.session.sendRequest({
          type: MiniappRequestType.MEETING_SET_MUTED,
          muted
        });
        if (result)
          this._applyState(result);
      } catch (error) {
        mapHostError(error);
      }
    }
    async updateVideoSource(source) {
      const validated = validateMeetingVideoSource(source);
      if (validated.type !== "whep") {
        throw {
          code: MiniappErrorCode.INVALID_ARGUMENT,
          message: "updateVideoSource accepts a WHEP source; a SoftAP call recovers by rejoining"
        };
      }
      try {
        await this.session.sendRequest({
          type: MiniappRequestType.MEETING_UPDATE_VIDEO_SOURCE,
          videoSource: validated
        });
      } catch (error) {
        mapHostError(error);
      }
    }
    async getState() {
      try {
        const result = await this.session.sendRequest({
          type: MiniappRequestType.MEETING_GET_STATE
        });
        if (result)
          this._applyState(result);
        return this.state;
      } catch (error) {
        mapHostError(error);
      }
    }
    onState(handler) {
      return this.session.on("meetingState", handler);
    }
    _applyState(event) {
      this._state = {
        state: event.state,
        muted: Boolean(event.muted),
        error: event.error,
        endReason: parseMeetingEndReason(event.endReason),
        meetingUrl: event.meetingUrl,
        provider: event.provider,
        audioSource: event.audioSource,
        audioSourceReason: event.audioSourceReason,
        activeStream: event.activeStream,
        audioSafety: event.audioSafety,
        mediaSource: parseMeetingMediaSource(event.mediaSource),
        participants: parseMeetingParticipants(event.participants),
        capabilities: parseMeetingCapabilities(event.capabilities) ?? this._state.capabilities,
        softap: parseMeetingSoftApProgress(event.softap),
        recovery: parseMeetingRecovery(event.recovery) ?? this._state.recovery
      };
    }
  }

  // ../../mobile/modules/miniapp/dist/session.js
  var ALL_PERMISSION_TYPES = [
    "location",
    "microphone",
    "camera",
    "notifications",
    "calendar"
  ];

  class NotConnectedError extends Error {
    constructor(message = "MiniappSession is not connected") {
      super(message);
      this.code = MiniappErrorCode.NOT_CONNECTED;
      this.name = "NotConnectedError";
    }
  }
  var DEFAULT_CONNECT_TIMEOUT_MS = 1e4;
  var DEFAULT_REQUEST_TIMEOUT_MS = 60000;

  class MiniappSession {
    constructor(options = {}) {
      this.capabilities = null;
      this.hostFeatures = null;
      this.userId = "";
      this.packageName = "";
      this.visibility = "foreground";
      this.colorScheme = "light";
      this.ready = false;
      this.emitter = new import__.default;
      this.authState = null;
      this.configurationState = {};
      this.authWaiters = new Set;
      this.authRefreshPromise = null;
      this.outboundQueue = [];
      this.pendingRequests = new Map;
      this.connectPromise = null;
      this.disposed = false;
      this._permissions = {
        location: false,
        microphone: false,
        camera: false,
        notifications: false,
        calendar: false
      };
      this.transport = createTransport(options);
      this.connectTimeoutMs = options.connectTimeoutMs ?? DEFAULT_CONNECT_TIMEOUT_MS;
      const injected = getMentraOSGlobals();
      this.packageName = options.packageName ?? injected.packageName ?? "";
      if (injected.colorScheme === "light" || injected.colorScheme === "dark") {
        this.colorScheme = injected.colorScheme;
      }
      this.auth = new AuthModule(this);
      this.configuration = new ConfigurationModule(this);
      this.events = new EventManager(this);
      this.speaker = new SpeakerModule(this);
      this.meeting = new MeetingModule(this);
      this.camera = new CameraModule(this);
      this.cloud = new CloudModule(this);
      this.dashboard = new DashboardAPI(this);
      this.display = new DisplayManager(this);
      this.glasses = new GlassesModule(this);
      this.heading = new HeadingModule(this);
      this.imu = new ImuModule(this);
      this.input = new InputModule(this);
      this.led = new LedModule(this);
      this.location = new LocationModule(this);
      this.mic = new MicModule(this);
      this.navigation = new NavigationModule(this);
      this.permissions = new PermissionsModule(this);
      this.phone = new PhoneModule(this);
      this.storage = new SimpleStorage(this);
      this.blob = new BlobModule(this);
      this.stream = new StreamModule(this);
      this.system = new SystemModule(this);
      this.transcription = new TranscriptionModule(this);
      this.translation = new TranslationModule(this);
      this.ui = new UIModuleImpl(this);
      this.miniapps = new MiniappsModule(this);
      this.actions = new ActionsModule(this);
    }
    _hasManifestPermission(manifestKey) {
      const canonical = manifestKeyToCanonical(manifestKey);
      if (!canonical)
        return false;
      return this._permissions[canonical] === true;
    }
    _getPermissions() {
      return { ...this._permissions };
    }
    _getAuth() {
      return this.authState ? { ...this.authState } : null;
    }
    _getConfiguration() {
      return { ...this.configurationState };
    }
    _waitForAuth(minTtlMs, timeoutMs = 1e4) {
      const current = this.authState;
      if (current && this.authHasTtl(current, minTtlMs)) {
        return Promise.resolve({ ...current });
      }
      this.requestAuthRefresh(minTtlMs);
      return new Promise((resolve, reject) => {
        const waiter = {
          minTtlMs,
          resolve,
          reject,
          timer: setTimeout(() => {
            this.authWaiters.delete(waiter);
            reject(new NotConnectedError("Miniapp auth token is not available"));
          }, timeoutMs)
        };
        this.authWaiters.add(waiter);
      });
    }
    _subscribe(streamType, handler, options = {}) {
      return this.events.subscribe(streamType, handler, options);
    }
    connect() {
      if (this.disposed) {
        return Promise.reject(new NotConnectedError("MiniappSession was disposed"));
      }
      if (this.connectPromise)
        return this.connectPromise;
      const readyPromise = new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
          const err = new Error("MiniappSession: CONNECT_ACK timeout");
          this.failAllPending({ code: MiniappErrorCode.NOT_CONNECTED, message: err.message });
          this.emitter.emit("error", err);
          reject(err);
        }, this.connectTimeoutMs);
        this.emitter.once("ready", () => {
          clearTimeout(timer);
          resolve();
        });
        this.emitter.once("error", (err) => {
          clearTimeout(timer);
          reject(err);
        });
      });
      this.connectPromise = (async () => {
        this.transport.onMessage((raw) => this.handleIncoming(raw));
        this.transport.onDisconnect((reason) => this.handleTransportDisconnect(reason));
        await this.transport.open();
        const requestId = makeRequestId();
        const connectPayload = {
          type: MiniappRequestType.CONNECT,
          packageName: this.packageName
        };
        this.transport.send(serializeEnvelope({ payload: connectPayload, requestId }));
        await readyPromise;
      })();
      return this.connectPromise;
    }
    waitForReady() {
      if (this.ready)
        return Promise.resolve();
      return this.connect();
    }
    isConnected() {
      return this.ready && this.transport.isOpen();
    }
    disconnect() {
      if (this.disposed)
        return;
      this.disposed = true;
      try {
        this.emitter.emit("beforeDisconnect", "disconnect called");
      } catch (err) {
        console.warn("[MiniappSession] beforeDisconnect handler threw:", err);
      }
      this.failAllPending({ code: MiniappErrorCode.REQUEST_ABORTED, message: "Session disconnected" });
      try {
        this.transport.close();
      } catch {}
      this.ready = false;
      this.emitter.emit("disconnect", "disconnect called");
    }
    sendOneShot(payload) {
      const envelope = { payload };
      this.enqueueOrSend(serializeEnvelope(envelope));
    }
    sendRequest(payload, opts) {
      if (this.disposed) {
        return Promise.reject(new NotConnectedError);
      }
      const requestId = makeRequestId();
      const envelope = { payload, requestId };
      const timeoutMs = opts?.timeoutMs ?? DEFAULT_REQUEST_TIMEOUT_MS;
      return new Promise((resolve, reject) => {
        const timer = timeoutMs > 0 ? setTimeout(() => {
          const pending = this.pendingRequests.get(requestId);
          if (!pending)
            return;
          this.pendingRequests.delete(requestId);
          pending.reject({
            code: MiniappErrorCode.ACTION_TIMEOUT,
            message: "Request timed out waiting for a response from the host"
          });
        }, timeoutMs) : undefined;
        this.pendingRequests.set(requestId, {
          requestId,
          resolve,
          reject,
          timer
        });
        this.enqueueOrSend(serializeEnvelope(envelope));
      });
    }
    on(event, handler) {
      this.emitter.on(event, handler);
      return () => this.emitter.off(event, handler);
    }
    off(event, handler) {
      this.emitter.off(event, handler);
    }
    onBeforeDisconnect(handler) {
      return this.on("beforeDisconnect", handler);
    }
    onVisibilityChange(handler) {
      return this.on("visibility", handler);
    }
    onCapabilitiesChange(handler) {
      return this.on("capabilities", handler);
    }
    onColorSchemeChange(handler) {
      return this.on("colorScheme", handler);
    }
    enqueueOrSend(raw) {
      if (this.ready) {
        try {
          this.transport.send(raw);
        } catch (err) {
          this.emitter.emit("error", err);
        }
        return;
      }
      this.outboundQueue.push(raw);
    }
    flushQueue() {
      const queue = this.outboundQueue.splice(0);
      for (const raw of queue) {
        try {
          this.transport.send(raw);
        } catch (err) {
          this.emitter.emit("error", err);
        }
      }
    }
    handleIncoming(raw) {
      const envelope = parseEnvelope(raw);
      if (!envelope)
        return;
      const payload = envelope.payload;
      const type = payload?.type;
      switch (type) {
        case MiniappResponseType.CONNECT_ACK: {
          const ack = payload;
          this.userId = ack.userId ?? "";
          if (ack.packageName)
            this.packageName = ack.packageName;
          this.capabilities = ack.capabilities ?? null;
          this.hostFeatures = ack.hostFeatures ?? null;
          if (ack.visibility)
            this.visibility = ack.visibility;
          if (ack.colorScheme === "light" || ack.colorScheme === "dark") {
            this.colorScheme = ack.colorScheme;
          }
          if (ack.auth) {
            this.applyAuth(ack.auth);
            if (!this.userId)
              this.userId = ack.auth.mentraUserId;
          }
          this.configurationState = Object.freeze({ ...ack.configuration });
          if (ack.permissions)
            this.applyPermissions(ack.permissions);
          this.ready = true;
          this.flushQueue();
          this.emitter.emit("ready");
          return;
        }
        case MiniappResponseType.AUTH_UPDATE: {
          const next = payload.auth;
          if (next) {
            this.applyAuth(next);
            if (!this.userId)
              this.userId = next.mentraUserId;
          }
          return;
        }
        case MiniappResponseType.PERMISSIONS_UPDATE: {
          const next = payload.permissions;
          if (next)
            this.applyPermissions(next);
          return;
        }
        case MiniappResponseType.SPEAKER_STATE: {
          const state = payload.state;
          if (!state)
            return;
          const event = {
            state,
            errorCode: payload.errorCode,
            errorMessage: payload.errorMessage,
            durationMs: payload.durationMs
          };
          this.speaker._applyState(event);
          this.emitter.emit("speakerState", event);
          return;
        }
        case MiniappResponseType.MEETING_STATE: {
          const state = payload.state;
          if (!state)
            return;
          const event = {
            state,
            muted: Boolean(payload.muted),
            error: payload.error,
            meetingUrl: payload.meetingUrl,
            provider: payload.provider,
            audioSource: payload.audioSource,
            audioSourceReason: payload.audioSourceReason,
            activeStream: payload.activeStream,
            audioSafety: payload.audioSafety,
            mediaSource: parseMeetingMediaSource(payload.mediaSource),
            endReason: parseMeetingEndReason(payload.endReason),
            participants: parseMeetingParticipants(payload.participants),
            capabilities: parseMeetingCapabilities(payload.capabilities),
            softap: parseMeetingSoftApProgress(payload.softap),
            recovery: parseMeetingRecovery(payload.recovery)
          };
          this.meeting._applyState(event);
          this.emitter.emit("meetingState", event);
          return;
        }
        case MiniappRequestType.PING: {
          const pong = { type: MiniappResponseType.PONG };
          const env = {
            payload: pong,
            ...envelope.requestId ? { requestId: envelope.requestId } : {}
          };
          try {
            this.transport.send(serializeEnvelope(env));
          } catch {}
          return;
        }
        case MiniappResponseType.EVENT: {
          const streamType = payload.streamType;
          if (!streamType)
            return;
          this.events._forwardEvent(streamType, payload.data, payload.transcriptionRoute);
          return;
        }
        case MiniappResponseType.ACTION_CALL: {
          const callId = payload.callId;
          const actionId = payload.actionId;
          if (!callId || !actionId)
            return;
          const params = payload.params ?? {};
          const callerPackageName = payload.callerPackageName ?? "";
          this.actions._deliver(callId, actionId, params, { callerPackageName });
          return;
        }
        case MiniappResponseType.CAPABILITIES_UPDATE: {
          const cap = payload.capabilities ?? null;
          this.capabilities = cap;
          this.emitter.emit("capabilities", cap);
          return;
        }
        case MiniappResponseType.VISIBILITY_CHANGE: {
          const next = payload.visibility;
          if (next === "foreground" || next === "background") {
            this.visibility = next;
            this.emitter.emit("visibility", next);
          }
          return;
        }
        case MiniappResponseType.COLOR_SCHEME_CHANGE: {
          const next = payload.colorScheme;
          if (next === "light" || next === "dark") {
            this.colorScheme = next;
            this.emitter.emit("colorScheme", next);
          }
          return;
        }
        case MiniappResponseType.REQUEST_RESULT: {
          const requestId = envelope.requestId;
          if (!requestId)
            return;
          const pending = this.pendingRequests.get(requestId);
          if (!pending)
            return;
          this.pendingRequests.delete(requestId);
          if (pending.timer)
            clearTimeout(pending.timer);
          if (payload.ok === false) {
            const err = payload.error ?? {
              code: MiniappErrorCode.INTERNAL,
              message: "Unknown error"
            };
            pending.reject(err);
          } else {
            pending.resolve(payload.data ?? null);
          }
          return;
        }
        case MiniappResponseType.WILL_DISCONNECT: {
          const reason = payload.reason ?? "phone unregistering";
          try {
            this.emitter.emit("beforeDisconnect", reason);
          } catch (err) {
            console.warn("[MiniappSession] beforeDisconnect handler threw:", err);
          }
          return;
        }
        case MiniappResponseType.ERROR: {
          const err = new Error(payload.message ?? "MiniappSession error");
          this.emitter.emit("error", err);
          return;
        }
        default:
          return;
      }
    }
    handleTransportDisconnect(reason) {
      this.ready = false;
      this.failAllPending({ code: MiniappErrorCode.NOT_CONNECTED, message: `Transport disconnected: ${reason}` });
      this.emitter.emit("disconnect", reason);
    }
    failAllPending(error) {
      for (const pending of this.pendingRequests.values()) {
        if (pending.timer)
          clearTimeout(pending.timer);
        pending.reject(error);
      }
      this.pendingRequests.clear();
      for (const waiter of Array.from(this.authWaiters)) {
        clearTimeout(waiter.timer);
        this.authWaiters.delete(waiter);
        waiter.reject(new NotConnectedError(error.message));
      }
    }
    authHasTtl(auth, minTtlMs) {
      return auth.expiresAt - Date.now() > minTtlMs;
    }
    requestAuthRefresh(minTtlMs) {
      if (this.authRefreshPromise)
        return this.authRefreshPromise;
      if (!this.ready || !this.transport.isOpen())
        return Promise.resolve(null);
      this.authRefreshPromise = this.sendRequest({
        type: MiniappRequestType.AUTH_REFRESH,
        minTtlMs
      }).then((result) => {
        const auth = result?.auth;
        if (auth)
          this.applyAuth(auth);
        return auth ?? null;
      }).catch((err) => {
        console.warn("[MiniappSession] auth refresh failed:", err);
        return null;
      }).finally(() => {
        this.authRefreshPromise = null;
      });
      return this.authRefreshPromise;
    }
    applyAuth(next) {
      this.authState = { ...next };
      for (const waiter of Array.from(this.authWaiters)) {
        if (!this.authHasTtl(next, waiter.minTtlMs))
          continue;
        clearTimeout(waiter.timer);
        this.authWaiters.delete(waiter);
        waiter.resolve({ ...next });
      }
      this.emitter.emit("auth", { ...next });
    }
    applyPermissions(next) {
      let changed = false;
      const updated = { ...this._permissions };
      for (const k of ALL_PERMISSION_TYPES) {
        const v = next[k] === true;
        if (updated[k] !== v) {
          updated[k] = v;
          changed = true;
        }
      }
      if (changed) {
        this._permissions = updated;
        this.emitter.emit("permissions", { ...updated });
      }
    }
  }
  function manifestKeyToCanonical(manifestKey) {
    switch (manifestKey.toUpperCase()) {
      case "MICROPHONE":
        return "microphone";
      case "CAMERA":
        return "camera";
      case "LOCATION":
      case "BACKGROUND_LOCATION":
        return "location";
      case "READ_NOTIFICATIONS":
      case "POST_NOTIFICATIONS":
        return "notifications";
      case "CALENDAR":
        return "calendar";
      default:
        return null;
    }
  }

  // ../../mobile/modules/miniapp/dist/background/register.js
  function registerMiniapp(handler, options = {}) {
    const g = globalThis;
    g.__mentraInitCallback = (_sessionId) => {
      const session = new MiniappSession(options);
      try {
        const result = handler(session);
        if (result && typeof result.then === "function") {
          result.catch((err) => {
            console.error("[mentra-miniapp] registerMiniapp handler rejected:", err);
          });
        }
      } catch (err) {
        console.error("[mentra-miniapp] registerMiniapp handler threw:", err);
      }
      session.connect().catch((err) => {
        console.error("[mentra-miniapp] session.connect() rejected:", err);
        try {
          const message = err instanceof Error ? err.message : String(err);
          const stack = err instanceof Error && err.stack ? err.stack : "";
          g.__hostError?.(JSON.stringify({ message: `session.connect() failed: ${message}`, stack }));
        } catch {}
      });
    };
  }
  // src/shared/maneuverDisplay.ts
  var AT_TURN_M = 10;
  function deriveManeuverDisplay(maneuver, status, liveDistanceMeters) {
    if (status === "arrived" || !maneuver)
      return null;
    const kind = maneuver.maneuverType;
    const instructionRaw = maneuver.instruction?.trim() || null;
    const liveDist = liveDistanceMeters != null && liveDistanceMeters >= 0 ? liveDistanceMeters : null;
    const eventDist = maneuver.distanceMeters != null && maneuver.distanceMeters >= 0 ? maneuver.distanceMeters : null;
    const distanceMeters = liveDist ?? eventDist;
    const atTurn = eventDist != null && eventDist <= AT_TURN_M;
    if (kind === "ARRIVE") {
      const toDest = liveDist ?? maneuver.distanceToDestinationMeters;
      return {
        instruction: "Arriving",
        kind: "ARRIVE",
        arrow: "↑",
        distanceMeters: toDest != null && toDest >= 0 ? toDest : null,
        atTurn: false,
        arriving: true
      };
    }
    let instruction = instructionRaw;
    if (!instruction) {
      const verb = verbForManeuver(kind);
      const onto = realRoadName(maneuver.nextStepRoad);
      instruction = onto ? `${verb} onto ${onto}` : verb;
    }
    return {
      instruction,
      kind,
      arrow: atTurn ? arrowForKind(kind) : "↑",
      distanceMeters,
      atTurn,
      arriving: false
    };
  }
  function liveDistanceToNextTurn(me, route, steps, remaining, straightLine) {
    if (!me || !route || route.length < 2 || !steps || steps.length === 0)
      return null;
    const meRemaining = remaining(me, route);
    if (meRemaining != null) {
      let bestGap = null;
      for (const s of steps) {
        const stepRemaining = remaining({ lat: s.lat, lng: s.lng }, route);
        if (stepRemaining == null)
          continue;
        const gap = meRemaining - stepRemaining;
        if (gap <= 1)
          continue;
        if (bestGap == null || gap < bestGap)
          bestGap = gap;
      }
      if (bestGap != null)
        return bestGap;
    }
    if (straightLine) {
      let best = null;
      for (const s of steps) {
        const d = straightLine(me, { lat: s.lat, lng: s.lng });
        if (d <= 1)
          continue;
        if (best == null || d < best)
          best = d;
      }
      if (best != null)
        return best;
    }
    return null;
  }
  function arrowForKind(kind) {
    const m = (kind ?? "").toUpperCase();
    if (m.includes("LEFT"))
      return "←";
    if (m.includes("RIGHT"))
      return "→";
    return "↑";
  }
  function verbForManeuver(kind) {
    switch (kind) {
      case "TURN_LEFT":
      case "SLIGHT_LEFT":
      case "SHARP_LEFT":
        return kind === "SLIGHT_LEFT" ? "Slight left" : kind === "SHARP_LEFT" ? "Sharp left" : "Turn left";
      case "TURN_RIGHT":
      case "SLIGHT_RIGHT":
      case "SHARP_RIGHT":
        return kind === "SLIGHT_RIGHT" ? "Slight right" : kind === "SHARP_RIGHT" ? "Sharp right" : "Turn right";
      case "U_TURN":
        return "Turn around";
      case "CONTINUE":
      case "STRAIGHT":
        return "Continue";
      case "NAME_CHANGE":
        return "Continue";
      case "DEPART":
        return "Head out";
      case "CROSS_STREET":
        return "Cross the street";
      default:
        return "Continue";
    }
  }
  function realRoadName(raw) {
    if (!raw)
      return null;
    const trimmed = raw.trim();
    if (trimmed.length === 0)
      return null;
    if (/^(toward|turn|continue|destination|head|cross|slight|sharp|keep|merge|fork|exit|take|roundabout|u[\s-]?turn|arrive|arriving|depart|enter|leave|stay)\b/i.test(trimmed))
      return null;
    return trimmed;
  }

  // src/background/actions/savedAddressActions.ts
  var SAVED_ADDRESS_TYPES = ["home", "work"];
  async function getSavedAddresses(storage) {
    const savedPlaces = await storage.getAllSavedPlaces();
    const addresses = SAVED_ADDRESS_TYPES.flatMap((type) => {
      const place = savedPlaces.find((candidate) => candidate.type === type);
      return place ? [toSavedAddress(place, type)] : [];
    });
    return { addresses };
  }
  async function setSavedAddress(params, storage, resolveAddress) {
    const type = params.type;
    if (type !== "home" && type !== "work") {
      throw new Error("set_saved_address: 'type' must be 'home' or 'work'");
    }
    if (typeof params.address !== "string" || !params.address.trim()) {
      throw new Error("set_saved_address: 'address' is required and must be a non-empty string");
    }
    const query = params.address.trim();
    const place = await resolveAddress(query);
    if (!place) {
      throw new Error(`set_saved_address: couldn't find a place matching "${query}"`);
    }
    const savedPlace = {
      ...place,
      type,
      savedName: type === "home" ? "Home" : "Work"
    };
    await storage.addSavedPlace(savedPlace);
    return { address: toSavedAddress(savedPlace, type) };
  }
  function toSavedAddress(place, type) {
    return {
      type,
      name: place.name,
      address: place.address,
      latitude: place.lat,
      longitude: place.lng
    };
  }

  // src/background/lib/bmp.ts
  var FILE_HEADER = 14;
  var DIB_HEADER = 40;
  var COLOR_TABLE = 8;
  var PIXEL_OFFSET = FILE_HEADER + DIB_HEADER + COLOR_TABLE;
  function setU16LE(buf, off, v) {
    buf[off] = v & 255;
    buf[off + 1] = v >>> 8 & 255;
  }
  function setU32LE(buf, off, v) {
    buf[off] = v & 255;
    buf[off + 1] = v >>> 8 & 255;
    buf[off + 2] = v >>> 16 & 255;
    buf[off + 3] = v >>> 24 & 255;
  }
  function base64(bytes) {
    let binary = "";
    const CHUNK = 32768;
    for (let i = 0;i < bytes.length; i += CHUNK) {
      const slice = bytes.subarray(i, i + CHUNK);
      binary += String.fromCharCode.apply(null, slice);
    }
    return btoa(binary);
  }
  function encodeBmpBase64(gray, width, height) {
    if (gray.length !== width * height) {
      throw new Error(`encodeBmpBase64: expected ${width * height} bytes, got ${gray.length}`);
    }
    const GRAY_COLOR_TABLE = 256 * 4;
    const grayPixelOffset = FILE_HEADER + DIB_HEADER + GRAY_COLOR_TABLE;
    const rowSize = Math.ceil(width / 4) * 4;
    const pixelDataSize = rowSize * height;
    const fileSize = grayPixelOffset + pixelDataSize;
    const buf = new Uint8Array(fileSize);
    buf[0] = 66;
    buf[1] = 77;
    setU32LE(buf, 2, fileSize);
    setU32LE(buf, 6, 0);
    setU32LE(buf, 10, grayPixelOffset);
    setU32LE(buf, 14, DIB_HEADER);
    setU32LE(buf, 18, width);
    setU32LE(buf, 22, height);
    setU16LE(buf, 26, 1);
    setU16LE(buf, 28, 8);
    setU32LE(buf, 30, 0);
    setU32LE(buf, 34, pixelDataSize);
    setU32LE(buf, 38, 2835);
    setU32LE(buf, 42, 2835);
    setU32LE(buf, 46, 256);
    setU32LE(buf, 50, 256);
    for (let i = 0;i < 256; i++) {
      const off = FILE_HEADER + DIB_HEADER + i * 4;
      buf[off] = i;
      buf[off + 1] = i;
      buf[off + 2] = i;
      buf[off + 3] = 0;
    }
    for (let y = 0;y < height; y++) {
      const srcRow = y * width;
      const destRow = grayPixelOffset + (height - 1 - y) * rowSize;
      for (let x = 0;x < width; x++) {
        buf[destRow + x] = gray[srcRow + x];
      }
    }
    return base64(buf);
  }
  function borderTestImageBase64(width, height, thickness = 2) {
    const t = Math.max(1, Math.min(thickness, Math.floor(Math.min(width, height) / 2)));
    const gray = new Uint8Array(width * height);
    for (let y = 0;y < height; y++) {
      for (let x = 0;x < width; x++) {
        const onBorder = x < t || x >= width - t || y < t || y >= height - t;
        if (onBorder)
          gray[y * width + x] = 255;
      }
    }
    return encodeBmpBase64(gray, width, height);
  }

  // src/background/lib/ArrowRenderer.ts
  var BG = 0;
  var INK = 255;
  function maneuverAngleRad(maneuver) {
    const deg = maneuverAngleDeg(maneuver);
    return deg * Math.PI / 180;
  }
  function maneuverAngleDeg(maneuver) {
    if (!maneuver)
      return 0;
    const m = maneuver.toLowerCase();
    if (maneuver.includes("↑"))
      return 0;
    if (maneuver.includes("↗"))
      return 45;
    if (maneuver.includes("→"))
      return 90;
    if (maneuver.includes("↘"))
      return 135;
    if (maneuver.includes("↓"))
      return 180;
    if (maneuver.includes("↙"))
      return 225;
    if (maneuver.includes("←"))
      return 270;
    if (maneuver.includes("↖"))
      return 315;
    if (maneuver.includes("↩") || maneuver.includes("⤵"))
      return 180;
    if (m.includes("uturn") || m.includes("u-turn"))
      return 180;
    const slight = m.includes("slight");
    const sharp = m.includes("sharp");
    if (m.includes("left"))
      return slight ? 315 : sharp ? 225 : 270;
    if (m.includes("right"))
      return slight ? 45 : sharp ? 135 : 90;
    return 0;
  }
  function insideUpArrow(lx, ly, s) {
    const tipY = -0.42 * s;
    const headBaseY = -0.04 * s;
    const headHalf = 0.3 * s;
    const shaftHalf = 0.11 * s;
    const shaftTopY = -0.12 * s;
    const shaftBotY = 0.42 * s;
    if (ly >= tipY && ly <= headBaseY) {
      const t = (ly - tipY) / (headBaseY - tipY);
      if (Math.abs(lx) <= headHalf * t)
        return true;
    }
    if (ly >= shaftTopY && ly <= shaftBotY && Math.abs(lx) <= shaftHalf)
      return true;
    return false;
  }
  function renderManeuverArrowBmp(maneuver, size = 40) {
    const s = Math.max(8, Math.round(size));
    const gray = new Uint8Array(s * s).fill(BG);
    const c = (s - 1) / 2;
    const theta = maneuverAngleRad(maneuver);
    const cosT = Math.cos(theta);
    const sinT = Math.sin(theta);
    for (let py = 0;py < s; py++) {
      for (let px = 0;px < s; px++) {
        const dx = px - c;
        const dy = py - c;
        const lx = dx * cosT + dy * sinT;
        const ly = -dx * sinT + dy * cosT;
        if (insideUpArrow(lx, ly, s))
          gray[py * s + px] = INK;
      }
    }
    return encodeBmpBase64(gray, s, s);
  }

  // src/background/lib/capabilities.ts
  function readGlassesCapabilities(capabilities) {
    const record = capabilities ?? {};
    const display = record.display && typeof record.display === "object" ? record.display : null;
    const modelName = typeof record.modelName === "string" ? record.modelName : null;
    return {
      modelName,
      hasDisplay: record.hasDisplay === true || !!display,
      canPosition: display != null && display.canPosition !== false,
      hasSpeaker: record.hasSpeaker === true,
      hasButton: record.hasButton === true
    };
  }

  // src/background/lib/formatDistance.ts
  var FEET_PER_METER = 3.28084;
  var FEET_PER_MILE = 5280;
  function formatDistance(meters, unit = "metric") {
    if (meters < 0)
      return "—";
    if (unit === "imperial") {
      const feet = meters * FEET_PER_METER;
      if (feet < FEET_PER_MILE * 0.1)
        return `${Math.max(1, Math.round(feet))} ft`;
      const miles = feet / FEET_PER_MILE;
      return `${miles.toFixed(miles < 10 ? 1 : 0)} mi`;
    }
    if (meters < 1000)
      return `${Math.max(1, Math.round(meters))} m`;
    const km = meters / 1000;
    return `${km.toFixed(km < 10 ? 1 : 0)} km`;
  }
  function formatDuration(seconds) {
    if (seconds < 0)
      return "—";
    if (seconds < 60)
      return `${seconds} sec`;
    const minutes = Math.round(seconds / 60);
    if (minutes < 60)
      return `${minutes} min`;
    const hours = Math.floor(minutes / 60);
    const remMin = minutes % 60;
    return remMin === 0 ? `${hours} h` : `${hours} h ${remMin} min`;
  }

  // src/background/lib/geometry.ts
  function haversineMeters2(a, b) {
    const R = 6371000;
    const toRad = (d) => d * Math.PI / 180;
    const dLat = toRad(b.lat - a.lat);
    const dLng = toRad(b.lng - a.lng);
    const lat1 = toRad(a.lat);
    const lat2 = toRad(b.lat);
    const x = Math.sin(dLat / 2) ** 2 + Math.sin(dLng / 2) ** 2 * Math.cos(lat1) * Math.cos(lat2);
    return 2 * R * Math.asin(Math.sqrt(x));
  }
  function bearingDeg2(a, b) {
    const toRad = (d) => d * Math.PI / 180;
    const toDeg = (r) => r * 180 / Math.PI;
    const lat1 = toRad(a.lat);
    const lat2 = toRad(b.lat);
    const dLng = toRad(b.lng - a.lng);
    const y = Math.sin(dLng) * Math.cos(lat2);
    const x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLng);
    return (toDeg(Math.atan2(y, x)) + 360) % 360;
  }
  function signedAngleDiff2(target, actual) {
    return (target - actual + 540) % 360 - 180;
  }
  function perpDistanceMeters(p, a, b) {
    const mPerDegLat = 111320;
    const mPerDegLng = 111320 * Math.cos(a.lat * Math.PI / 180);
    const ax = 0;
    const ay = 0;
    const bx = (b.lng - a.lng) * mPerDegLng;
    const by = (b.lat - a.lat) * mPerDegLat;
    const px = (p.lng - a.lng) * mPerDegLng;
    const py = (p.lat - a.lat) * mPerDegLat;
    const dx = bx - ax;
    const dy = by - ay;
    const len2 = dx * dx + dy * dy;
    if (len2 === 0)
      return Math.sqrt(px * px + py * py);
    let t = (px * dx + py * dy) / len2;
    t = Math.max(0, Math.min(1, t));
    const projx = ax + t * dx;
    const projy = ay + t * dy;
    return Math.sqrt((px - projx) * (px - projx) + (py - projy) * (py - projy));
  }
  function distanceToPolylineMeters(p, points) {
    if (!points || points.length < 2)
      return null;
    let best = Infinity;
    for (let i = 0;i < points.length - 1; i++) {
      const d = perpDistanceMeters(p, points[i], points[i + 1]);
      if (d < best)
        best = d;
    }
    return best === Infinity ? null : best;
  }
  function nextSegmentBearing(me, route) {
    if (!me || !route || route.length < 2)
      return null;
    let bestIdx = 0;
    let bestDist = Infinity;
    for (let i = 0;i < route.length - 1; i++) {
      const d = perpDistanceMeters(me, route[i], route[i + 1]);
      if (d < bestDist) {
        bestDist = d;
        bestIdx = i;
      }
    }
    return bearingDeg2(route[bestIdx], route[bestIdx + 1]);
  }
  function remainingRoutePoints(me, route) {
    if (!route || route.length < 2)
      return route ?? null;
    if (!me)
      return route;
    let bestIdx = 0;
    let bestDist = Infinity;
    for (let i = 0;i < route.length - 1; i++) {
      const d = perpDistanceMeters(me, route[i], route[i + 1]);
      if (d < bestDist) {
        bestDist = d;
        bestIdx = i;
      }
    }
    const seg = route[bestIdx];
    const next = route[bestIdx + 1];
    const mPerDegLat = 111320;
    const mPerDegLng = 111320 * Math.cos(seg.lat * Math.PI / 180);
    const bx = (next.lng - seg.lng) * mPerDegLng;
    const by = (next.lat - seg.lat) * mPerDegLat;
    const px = (me.lng - seg.lng) * mPerDegLng;
    const py = (me.lat - seg.lat) * mPerDegLat;
    const len2 = bx * bx + by * by;
    let t = len2 > 0 ? (px * bx + py * by) / len2 : 0;
    t = Math.max(0, Math.min(1, t));
    const projected = {
      lat: seg.lat + (next.lat - seg.lat) * t,
      lng: seg.lng + (next.lng - seg.lng) * t
    };
    return [projected, ...route.slice(bestIdx + 1)];
  }
  function remainingRouteMeters(me, route) {
    if (!me || !route || route.length < 2)
      return null;
    let bestIdx = 0;
    let bestDist = Infinity;
    for (let i = 0;i < route.length - 1; i++) {
      const d = perpDistanceMeters(me, route[i], route[i + 1]);
      if (d < bestDist) {
        bestDist = d;
        bestIdx = i;
      }
    }
    const mPerDegLat = 111320;
    const seg = route[bestIdx];
    const next = route[bestIdx + 1];
    const mPerDegLng = 111320 * Math.cos(seg.lat * Math.PI / 180);
    const ax = 0;
    const ay = 0;
    const bx = (next.lng - seg.lng) * mPerDegLng;
    const by = (next.lat - seg.lat) * mPerDegLat;
    const px = (me.lng - seg.lng) * mPerDegLng;
    const py = (me.lat - seg.lat) * mPerDegLat;
    const dx = bx - ax;
    const dy = by - ay;
    const len2 = dx * dx + dy * dy;
    let t = len2 > 0 ? (px * dx + py * dy) / len2 : 0;
    t = Math.max(0, Math.min(1, t));
    const projx = ax + t * dx;
    const projy = ay + t * dy;
    let remaining = Math.sqrt((bx - projx) * (bx - projx) + (by - projy) * (by - projy));
    for (let i = bestIdx + 1;i < route.length - 1; i++) {
      remaining += haversineMeters2(route[i], route[i + 1]);
    }
    return remaining;
  }
  function sideOfFinalSegment(route, pin) {
    if (!route || route.length < 2 || !pin)
      return null;
    const b = route[route.length - 1];
    let a = null;
    for (let i = route.length - 2;i >= 0; i--) {
      if (haversineMeters2(route[i], b) > 0.5) {
        a = route[i];
        break;
      }
    }
    if (!a)
      return null;
    const segBearing = bearingDeg2(a, b);
    const pinBearing = bearingDeg2(b, pin);
    const diff = signedAngleDiff2(pinBearing, segBearing);
    if (diff === 0)
      return null;
    return diff > 0 ? "right" : "left";
  }

  // src/background/lib/OsmLineMapRenderer.ts
  var BLACK = 0;
  var ROAD = 77;
  var ROUTE = 255;
  var MARKER = 255;
  var MARKER_OUTLINE = 0;
  var BORDER = 255;
  function toLocalMeters(p, origin) {
    const mPerDegLat = 111320;
    const mPerDegLng = 111320 * Math.cos(origin.lat * Math.PI / 180);
    return {
      x: (p.lng - origin.lng) * mPerDegLng,
      y: (p.lat - origin.lat) * mPerDegLat
    };
  }

  class Raster {
    w;
    h;
    buf;
    constructor(w, h) {
      this.w = w;
      this.h = h;
      this.buf = new Uint8Array(w * h);
      this.buf.fill(BLACK);
    }
    set(x, y, v) {
      if (x < 0 || y < 0 || x >= this.w || y >= this.h)
        return;
      this.buf[y * this.w + x] = v;
    }
    disc(cx, cy, r, v) {
      if (r <= 0) {
        this.set(cx, cy, v);
        return;
      }
      const r2 = r * r;
      for (let dy = -r;dy <= r; dy++) {
        for (let dx = -r;dx <= r; dx++) {
          if (dx * dx + dy * dy <= r2)
            this.set(cx + dx, cy + dy, v);
        }
      }
    }
    ring(cx, cy, r, v, thickness) {
      cx = Math.round(cx);
      cy = Math.round(cy);
      const rOuter = Math.max(1, Math.round(r));
      const rInner = Math.max(0, rOuter - Math.max(1, Math.round(thickness)));
      const o2 = rOuter * rOuter;
      const i2 = rInner * rInner;
      for (let dy = -rOuter;dy <= rOuter; dy++) {
        for (let dx = -rOuter;dx <= rOuter; dx++) {
          const d2 = dx * dx + dy * dy;
          if (d2 <= o2 && d2 >= i2)
            this.set(cx + dx, cy + dy, v);
        }
      }
    }
    triangle(ax, ay, bx, by, cx, cy, v) {
      const minX = Math.max(0, Math.floor(Math.min(ax, bx, cx)));
      const maxX = Math.min(this.w - 1, Math.ceil(Math.max(ax, bx, cx)));
      const minY = Math.max(0, Math.floor(Math.min(ay, by, cy)));
      const maxY = Math.min(this.h - 1, Math.ceil(Math.max(ay, by, cy)));
      const area = (bx - ax) * (cy - ay) - (cx - ax) * (by - ay);
      if (area === 0)
        return;
      for (let y = minY;y <= maxY; y++) {
        for (let x = minX;x <= maxX; x++) {
          const px = x + 0.5;
          const py = y + 0.5;
          const w0 = ((bx - px) * (cy - py) - (cx - px) * (by - py)) / area;
          const w1 = ((cx - px) * (ay - py) - (ax - px) * (cy - py)) / area;
          const w2 = 1 - w0 - w1;
          if (w0 >= 0 && w1 >= 0 && w2 >= 0)
            this.set(x, y, v);
        }
      }
    }
    line(x0, y0, x1, y1, v, thickness) {
      x0 = Math.round(x0);
      y0 = Math.round(y0);
      x1 = Math.round(x1);
      y1 = Math.round(y1);
      const r = Math.max(0, Math.floor(thickness / 2));
      const dx = Math.abs(x1 - x0);
      const dy = -Math.abs(y1 - y0);
      const sx = x0 < x1 ? 1 : -1;
      const sy = y0 < y1 ? 1 : -1;
      let err = dx + dy;
      for (;; ) {
        this.disc(x0, y0, r, v);
        if (x0 === x1 && y0 === y1)
          break;
        const e2 = 2 * err;
        if (e2 >= dy) {
          err += dy;
          x0 += sx;
        }
        if (e2 <= dx) {
          err += dx;
          y0 += sy;
        }
      }
    }
  }
  async function fetchOsmRoads(center, viewRadiusMeters) {
    const ROAD_CLASSES = "motorway|trunk|primary|secondary|tertiary|unclassified|residential|" + "living_street|motorway_link|trunk_link|primary_link|secondary_link|tertiary_link";
    const query = `[out:json][timeout:25];` + `way["highway"~"^(${ROAD_CLASSES})$"](around:${viewRadiusMeters},${center.lat},${center.lng});` + `out geom;`;
    const res = await fetch("https://overpass-api.de/api/interpreter", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        Accept: "application/json",
        "User-Agent": "MentraOS-Navigation-PoC/0.1 (OSM line map dev test)"
      },
      body: `data=${encodeURIComponent(query)}`
    });
    if (!res.ok) {
      throw new Error(`Overpass HTTP ${res.status}`);
    }
    const json = await res.json();
    const polylines = [];
    for (const el of json.elements ?? []) {
      if (el.type !== "way" || !el.geometry)
        continue;
      const pts = el.geometry.map((g) => ({ lat: g.lat, lng: g.lon }));
      if (pts.length >= 2)
        polylines.push(pts);
    }
    return polylines;
  }
  function renderOsmLineMap(roads, opts) {
    const { center, width, height } = opts;
    const viewRadius = opts.viewRadiusMeters ?? 400;
    const lineWidth = opts.lineWidthPx ?? 1;
    const ss = Math.max(1, Math.round(opts.supersample ?? 3));
    const hiW = width * ss;
    const hiH = height * ss;
    const raster = new Raster(hiW, hiH);
    const pxPerMeter = Math.min(hiW, hiH) / (viewRadius * 2);
    const cx = hiW / 2;
    const cy = hiH / 2;
    const rotDeg = opts.rotationDeg ?? null;
    const rotRad = rotDeg != null ? -rotDeg * Math.PI / 180 : 0;
    const rCos = Math.cos(rotRad);
    const rSin = Math.sin(rotRad);
    const project = (p) => {
      const m = toLocalMeters(p, center);
      const ex = m.x * rCos - m.y * rSin;
      const ny = m.x * rSin + m.y * rCos;
      return {
        x: cx + ex * pxPerMeter,
        y: cy - ny * pxPerMeter
      };
    };
    for (const way of roads) {
      for (let i = 0;i < way.length - 1; i++) {
        const a = project(way[i]);
        const b = project(way[i + 1]);
        raster.line(a.x, a.y, b.x, b.y, ROAD, lineWidth * ss);
      }
    }
    const route = opts.route;
    if (route && route.length >= 2) {
      const routeWidth = opts.routeWidthPx ?? lineWidth + 2;
      for (let i = 0;i < route.length - 1; i++) {
        const a = project(route[i]);
        const b = project(route[i + 1]);
        raster.line(a.x, a.y, b.x, b.y, ROUTE, routeWidth * ss);
      }
    }
    const destination = opts.destination;
    if (destination) {
      const d = project(destination);
      const ringR = 3.9 * ss;
      const ringT = Math.max(1, Math.round(ss));
      raster.ring(d.x, d.y, ringR, ROUTE, ringT);
    }
    const marker = opts.marker;
    if (marker) {
      const c = project(marker.at);
      const size = (opts.markerSizePx ?? 14) * ss;
      const effHeading = rotDeg != null ? marker.headingDeg - rotDeg : marker.headingDeg;
      const rad = effHeading * Math.PI / 180;
      const sin = Math.sin(rad);
      const cos = Math.cos(rad);
      const tip = { x: 0, y: -size * 0.6 };
      const left = { x: -size * 0.45, y: size * 0.4 };
      const right = { x: size * 0.45, y: size * 0.4 };
      const rot = (p) => ({
        x: c.x + (p.x * cos - p.y * sin),
        y: c.y + (p.x * sin + p.y * cos)
      });
      const outline = Math.max(1, Math.round(1.5 * ss));
      const ctr = { x: 0, y: (tip.y + left.y + right.y) / 3 };
      const grow = (p) => {
        const dx = p.x - ctr.x;
        const dy = p.y - ctr.y;
        const len = Math.hypot(dx, dy) || 1;
        return { x: p.x + dx / len * outline, y: p.y + dy / len * outline };
      };
      const ot = rot(grow(tip));
      const ol = rot(grow(left));
      const or = rot(grow(right));
      raster.triangle(ot.x, ot.y, ol.x, ol.y, or.x, or.y, MARKER_OUTLINE);
      const t = rot(tip);
      const l = rot(left);
      const r = rot(right);
      raster.triangle(t.x, t.y, l.x, l.y, r.x, r.y, MARKER);
    }
    {
      const armLen = Math.round(width * 0.066) * ss;
      const r = Math.max(1, Math.round(2 * ss));
      const thick = Math.max(1, ss);
      const W = hiW - 1;
      const H = hiH - 1;
      const hLine = (x0, x1, y) => raster.line(x0, y, x1, y, BORDER, thick);
      const vLine = (y0, y1, x) => raster.line(x, y0, x, y1, BORDER, thick);
      const arc = (cx2, cy2, a0, a1) => {
        const steps = Math.max(4, Math.round(r * 2));
        for (let i = 0;i <= steps; i++) {
          const a = a0 + (a1 - a0) * i / steps;
          raster.line(cx2 + Math.cos(a) * r, cy2 + Math.sin(a) * r, cx2 + Math.cos(a) * r, cy2 + Math.sin(a) * r, BORDER, thick);
        }
      };
      arc(r, r, Math.PI, 1.5 * Math.PI);
      hLine(r, r + armLen, 0);
      vLine(r, r + armLen, 0);
      arc(W - r, r, 1.5 * Math.PI, 2 * Math.PI);
      hLine(W - r - armLen, W - r, 0);
      vLine(r, r + armLen, W);
      arc(r, H - r, 0.5 * Math.PI, Math.PI);
      hLine(r, r + armLen, H);
      vLine(H - r - armLen, H - r, 0);
      arc(W - r, H - r, 0, 0.5 * Math.PI);
      hLine(W - r - armLen, W - r, H);
      vLine(H - r - armLen, H - r, W);
    }
    const out = new Uint8Array(width * height);
    if (ss === 1) {
      out.set(raster.buf);
    } else {
      const area = ss * ss;
      for (let oy = 0;oy < height; oy++) {
        for (let ox = 0;ox < width; ox++) {
          let sum = 0;
          for (let sy = 0;sy < ss; sy++) {
            const row = (oy * ss + sy) * hiW + ox * ss;
            for (let sx = 0;sx < ss; sx++)
              sum += raster.buf[row + sx];
          }
          out[oy * width + ox] = Math.round(sum / area);
        }
      }
    }
    return encodeBmpBase64(out, width, height);
  }
  async function buildOsmLineMap(opts) {
    const viewRadius = opts.viewRadiusMeters ?? 400;
    const roads = await fetchOsmRoads(opts.center, viewRadius);
    console.log(`[OSM-MAP] fetched ${roads.length} road ways around ${opts.center.lat},${opts.center.lng}`);
    return renderOsmLineMap(roads, opts);
  }

  // src/background/lib/testBitmap.ts
  var TEST_BITMAP_288_B64 = "Qk02SAEAAAAAADYEAAAoAAAAIAEAACABAAABAAgAAAAAAABEAQATCwAAEwsAAAABAAAAAQAAAAAAAAEBAQACAgIAAwMDAAQEBAAFBQUABgYGAAcHBwAICAgACQkJAAoKCgALCwsADAwMAA0NDQAODg4ADw8PABAQEAAREREAEhISABMTEwAUFBQAFRUVABYWFgAXFxcAGBgYABkZGQAaGhoAGxsbABwcHAAdHR0AHh4eAB8fHwAgICAAISEhACIiIgAjIyMAJCQkACUlJQAmJiYAJycnACgoKAApKSkAKioqACsrKwAsLCwALS0tAC4uLgAvLy8AMDAwADExMQAyMjIAMzMzADQ0NAA1NTUANjY2ADc3NwA4ODgAOTk5ADo6OgA7OzsAPDw8AD09PQA+Pj4APz8/AEBAQABBQUEAQkJCAENDQwBEREQARUVFAEZGRgBHR0cASEhIAElJSQBKSkoAS0tLAExMTABNTU0ATk5OAE9PTwBQUFAAUVFRAFJSUgBTU1MAVFRUAFVVVQBWVlYAV1dXAFhYWABZWVkAWlpaAFtbWwBcXFwAXV1dAF5eXgBfX18AYGBgAGFhYQBiYmIAY2NjAGRkZABlZWUAZmZmAGdnZwBoaGgAaWlpAGpqagBra2sAbGxsAG1tbQBubm4Ab29vAHBwcABxcXEAcnJyAHNzcwB0dHQAdXV1AHZ2dgB3d3cAeHh4AHl5eQB6enoAe3t7AHx8fAB9fX0Afn5+AH9/fwCAgIAAgYGBAIKCggCDg4MAhISEAIWFhQCGhoYAh4eHAIiIiACJiYkAioqKAIuLiwCMjIwAjY2NAI6OjgCPj48AkJCQAJGRkQCSkpIAk5OTAJSUlACVlZUAlpaWAJeXlwCYmJgAmZmZAJqamgCbm5sAnJycAJ2dnQCenp4An5+fAKCgoAChoaEAoqKiAKOjowCkpKQApaWlAKampgCnp6cAqKioAKmpqQCqqqoAq6urAKysrACtra0Arq6uAK+vrwCwsLAAsbGxALKysgCzs7MAtLS0ALW1tQC2trYAt7e3ALi4uAC5ubkAurq6ALu7uwC8vLwAvb29AL6+vgC/v78AwMDAAMHBwQDCwsIAw8PDAMTExADFxcUAxsbGAMfHxwDIyMgAycnJAMrKygDLy8sAzMzMAM3NzQDOzs4Az8/PANDQ0ADR0dEA0tLSANPT0wDU1NQA1dXVANbW1gDX19cA2NjYANnZ2QDa2toA29vbANzc3ADd3d0A3t7eAN/f3wDg4OAA4eHhAOLi4gDj4+MA5OTkAOXl5QDm5uYA5+fnAOjo6ADp6ekA6urqAOvr6wDs7OwA7e3tAO7u7gDv7+8A8PDwAPHx8QDy8vIA8/PzAPT09AD19fUA9vb2APf39wD4+PgA+fn5APr6+gD7+/sA/Pz8AP39/QD+/v4A////AIuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC2i3gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACPiouLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACLirYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACKiouLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIiMiwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIqQi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAhIyTjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiIyPi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABlio+PjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACFio+Mi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACLj4yPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAL+Kj4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIqMjYuPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIyMjIuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjouPi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjo2Ni4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB/io+Li4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACJio+Li4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACJjYyLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAL+KkYuLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIqMjIuLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIuMjIuLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYyOi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYyMi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB/i5CLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACMjI+Li4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACLj4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJKLj4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIuOjIuLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIuPi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAioyOi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiY2Mi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACIi4+Li4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACOjI6Li4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAALaKj4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJCLj4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIuNjIuLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIqPi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAio6Ni4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAioyMi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACOi4+Li4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACJjI2Li4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACLkIuLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJOLj4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAImMjIuLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAYIqQi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAioyMi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAio2Mi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACOi4+Li4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACMi42Li4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJmJkIuLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIWMj4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIqPi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmYuPi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAi42Mi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAi4+Mi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACIjI6Li4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACJjIyLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIWKj4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAI6LjouLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIuPi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAmYuQi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAi4yMi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAio+Li4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACLjI2Li4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACMjYyLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIOLj4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAI2LjouLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAZYuQi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAhYyPi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAioyMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABli5CLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACJjI2Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACKjYyLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJCMj4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIqMjYuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf4uPi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjoqPi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAio+Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjJCLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACKjIyLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACJjoyLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIyKjouLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIyNjIuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjIuPi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjIuPi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAi4+Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACKio+Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACNjoyLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACJjYyLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIuLjouLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIqOjIuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAkIuPi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjoyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAASi4+Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACFi4+Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACLjoyLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACKkIuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAImMjYuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIqMjIuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjYqPi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjIyNi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAipCLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACJi4+Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACKj4yLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMmIkIuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAImNjIuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIuMjIuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYqPi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjI6Mi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACKipCLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACMjI+Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACJjYyLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAI+Kj4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAImPjIuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIuPi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjIyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAioyMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACQi4+Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACJjI6Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACLkIuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJOKkIuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAImMjIuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIuQi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAioyNi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjIyMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACOi4+Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACKjI6Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAALaKkIuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAI2Mj4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIuNjIuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIqPi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAi42Mi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjI6Mi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACLjI+Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACNi42Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAI+Kj4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAI6Lj4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIyPjIuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAeIuPi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAi4yNi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAio+Mi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACNjI6Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACNjYyLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIqLj4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAImLjouLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAImPi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAioyQi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYyMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiZCLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACLjI2Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACMjYyLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIWLj4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAImMjouLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAtomPi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAh4qPi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAi46Mi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiY+Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACNjI2Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACKjoyLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAI6Lj4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAImMjYuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAi4uPi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjoqOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAio+Mi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAC/i4+Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACMjIyLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACJjIyLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIyLjYuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIyOjIuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAkouQi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjIyPi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAio+Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACPipCLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACNjYyLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACLj4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAI6MjouLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIiMjIuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyPi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAi4yOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAio+Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACBjI+Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACLjoyLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACKj4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIiMjYuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIuMjIuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiouPi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAh4yNi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACSi4+Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACLi4+Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACLjIyLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJKKj4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAI+NjIuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIuMjIuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjIuPi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjIyNi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB/ipCLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACJjI+Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACJjYyLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIqLj4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIqMjIuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAImPi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAioyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYyMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACPio+Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACOjI6Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACKj4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHqLkIuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIuMjIuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIqPi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAi4yNi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjIyMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACHjI+Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACLjI6Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH+Lj4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIqMkIuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIuMjIuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf4uOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAio2Mi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAi42Mi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAACFjI+Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACJjI2Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAH+Lj4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIqMj4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAIuOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAkoqQi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAi4yMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiY6Mi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAACOjI2Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAACJjYyLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAKGLj4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAImLjouLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAIqPi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAjYuPi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAi4yMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAiY+Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAACLi42Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAACLjoyLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAJeMj4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAAI6MjYuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAv4qPi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAAAAgYqPi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAi46Mi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAADJio6Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAACNi42Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAACIjYyLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAI6Mj4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAAIqNjYuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAdIqQi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAi4uPi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAi46Mi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAABlipGLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi42NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2QiwAAAAAAAAAAAACLjIyLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAACJjoyLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMiQAAAAAAAAAAAIuLjouLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPiwAAAAAAAAAAAAAAAIuNjIuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uNjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyIhwAAAAAAAAAAv4yPi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4yNigAAAAAAAAAAAAAAiYyPi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi42MjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiY+Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4+MfwAAAAAAAAAAAAB/i4+Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjI6LAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACLjoyLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLj4qNAAAAAAAAAAAAAACLj4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLj4qZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIiMj4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uNjIoAAAAAAAAAAAAAAIuNjIuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPi4sAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAkIuPi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4yPiQAAAAAAAAAAAAAAi4yNi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi42LjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACSio+Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjI+KAAAAAAAAAAAAAACNio+Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjIyKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACJjYyLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLkIuPAAAAAAAAAAAAAACKj4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLkIoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIuMjYuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjIkAAAAAAAAAAAAAAImMjIuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPi4cAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAhouPi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4yOiwAAAAAAAAAAAAAAiYyNi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi46MiQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADJipCLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4+LAAAAAAAAAAAAAACNjI+Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjIyJAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACLjYyLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLkIueAAAAAAAAAAAAAJKKkIuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLkIsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAImNjIuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjIsAAAAAAAAAAAAAAIyPi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPi48AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuPi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi42MiwAAAAAAAAAAAAAAioyNi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4+MhwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACSi4+Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjI+JAAAAAAAAAAAAAACLi4+Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjIyJAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACKjouLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLj4x0AAAAAAAAAAAAAIeMj4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjYwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIqNjIuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjIgAAAAAAAAAAAAAAIuPjIuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjIMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjoyPi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi42MiQAAAAAAAAAAAAAAioyMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4+LiwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACLi4+Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjI6LAAAAAAAAAAAAAACJi46Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjI2MAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACLj4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLj4oAAAAAAAAAAAAAAIeMj4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMjIkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIqMjIuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPipAAAAAAAAAAAAAAtomOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPiwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiI2Ni4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi42MiwAAAAAAAAAAAAAAjIyMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4+KhAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACIi5CLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjIyJAAAAAAAAAAAAAACOi46Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjYyMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH+LkIuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLkIsAAAAAAAAAAAAAAIuMj4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMjIsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIuNjIuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPioUAAAAAAAAAAAAAZYqPi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPiwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjIuNi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi46MiwAAAAAAAAAAAAAAi46Mi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4+LgQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACOjI+Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjYyLAAAAAAAAAAAAAACKjI2Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLj4yQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAL+Lj4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMjYwAAAAAAAAAAAAAAIuLj4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMjowAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIuPjIuLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPiX8AAAAAAAAAAAAAv4qQi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAi4yMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4+MiQAAAAAAAAAAAAAAiY2Mi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4+LmQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACMi4+Li4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjI6LAAAAAAAAAAAAAACKjYyLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLj4yMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIuLj4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMjIkAAAAAAAAAAAAAAI6Lj4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMjIwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAtomPi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uQigAAAAAAAAAAAAAAf4qPi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4yPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAj4yOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4+KhwAAAAAAAAAAAAAAi4uMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4+MAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjoyKAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLj4uBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMjIkAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOjIwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4yOigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi5CKjAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4+LAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjoyPAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLj4yHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMjooAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOi4wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4yNiwAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4yMjgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi5CLmQAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjI6LAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjouKAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLj4uMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMjIkAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPi4sAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4yOiwAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi42MiwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi5CLAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi46JAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLj4uIAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLj4u/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOi4kAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjIoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4yOjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi42LjQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4+LtgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjIyKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLkIyZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLkIwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOi4gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPi4gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4yOjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi46MiAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjI6KAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjIyKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLj4yBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLj4sAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOi4kAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPiowAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4yMjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi46NjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjI+JAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjI2JAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLj4plAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMjYoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjIoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uQi38AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi42MjQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4+KiwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjIyLAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjY2JAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLkIplAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMjIsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uQi40AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uRiwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi46MjwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4+LiAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjIyKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjYyNAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLj4sAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMjYoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPi4cAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4yOiQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4+LjQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4+LhwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjI6KAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjouOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjIsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMjIsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPin8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPiQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4+LjgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi5CMZQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjYyMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLj4uQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMjIsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uNjIsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uQjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4yNigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4+LiQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4+LcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjY6LAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLj4yEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMjYwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOi4wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPiX8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4yPiwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4+LegAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4+KAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLj4yRAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLj4uKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMj4wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uNjIkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPiwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4yMjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi5CLZQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4+MAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjouEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLj4uPAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMjIsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjI0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4yOiQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi42MiQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi5CLkgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjI2JAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLj4uTAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLj4uSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uNi4oAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPi5IAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4yPiwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi42MiwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4+LZQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjIyLAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLj4yQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLj4u2AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOi40AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPi4oAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4yNjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi42MigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4+LAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjI2MAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLj4p/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLkIwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOjIwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPiooAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4yMiwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4+MiQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi46LAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjIyMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLj4p0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMjIoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPjIkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uQi38AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4yNjgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4+LjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjIyMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjY2LAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLj4q2AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMjYsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPiooAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPiwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi42MiQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4+LiAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjIyLAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjoyJAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLj4wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMj4sAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPi4oAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4+MiwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi5CMigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjIyLAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjoqJAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMjYoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMjIoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uQjHQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uNigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4+LjgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi5CLigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjY2KAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLj4yMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMjYoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uNjIkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPi4YAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4yPiwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4+LhQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4+KfwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjY2OAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLj4yHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMj4oAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uNjIkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4yMiwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4+MigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLi5CMyQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLjoyHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uLkIyHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uMjYkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uOjI4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4uPigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4yMigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLi5CMigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLi4+LAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uLjoyJAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uLkIqVAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4uNjIkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4uPjIcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4yPigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4yMiAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLi4+KfwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLi4yMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uLj4yTAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uLj4qSAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4uNi4oAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4uPjJAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4yNiwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLi4yMjgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLi4+LAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLjI2LAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uLj4yMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uLkIsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4uNjIgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi4uPi4gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4yMjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLi42MhwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLi4+JAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLjIyLAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uLj4qFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uLj4oAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi4uOjY8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4uQi4cAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLi42MjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLi4+MjgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLjI6LAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLjI+MAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uLj4qKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uLjosAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4uPjIsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi4uQi38AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLi4yNiQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLi46LiQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLjI2LAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uLjIyMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uLj4sAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uMj4wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi4uPi4EAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4uQirYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLi46MjwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLi4+MhQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLjIyJAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uLjoyKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uLj4oAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uMjokAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi4uPiocAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi4uPjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOi46MjgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMi5CLhwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOjI6MAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuMjouKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYyOjYsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuOjIwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYySi5kAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuPigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlYqLjAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiYuKjwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgYyLAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAi4uKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiIsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAiIgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==";

  // src/background/managers/AudioGuidanceManager.ts
  var THRESHOLDS = {
    walking: { prepareMeters: 60, nowMeters: 10 },
    cycling: { prepareMeters: 200, nowMeters: 25 },
    driving: { prepareMeters: 500, nowMeters: 60 },
    two_wheeler: { prepareMeters: 350, nowMeters: 50 }
  };
  var MIN_AUTOMATIC_PROMPT_GAP_MS = 3500;
  var STARTUP_OFF_ROUTE_GRACE_MS = 15000;
  var TURN_TYPES = new Set([
    "TURN_LEFT",
    "TURN_RIGHT",
    "SLIGHT_LEFT",
    "SLIGHT_RIGHT",
    "SHARP_LEFT",
    "SHARP_RIGHT",
    "U_TURN",
    "CROSS_STREET"
  ]);

  class AudioGuidanceManager {
    speaker;
    log;
    available = false;
    mode = "off";
    tripActive = false;
    tripConfirmed = false;
    tripStartedAt = null;
    startupOffRouteSuppressed = false;
    startupRerouteSuppressed = false;
    allowImplicitResume = true;
    latestUnconfirmedInput = null;
    lastStatus = "idle";
    lastOffRoute = false;
    currentManeuverKey = null;
    currentPivotIndex = null;
    currentRepeatPhrase = null;
    lastSignature = "";
    lastDistance = null;
    syntheticSequence = 0;
    spokenStages = new Set;
    speakingGeneration = 0;
    speaking = false;
    speakingPriority = 0;
    speakingManeuverKey = null;
    pending = null;
    pendingTimer = null;
    lastPromptStartedAt = 0;
    disposed = false;
    constructor(speaker, log = () => {}) {
      this.speaker = speaker;
      this.log = log;
    }
    setAvailable(available) {
      this.available = available;
      if (!available)
        this.stopSpeech();
    }
    setMode(mode) {
      this.mode = mode;
      if (mode === "off")
        this.stopSpeech();
    }
    beginTrip() {
      this.stopSpeech();
      this.tripActive = true;
      this.tripConfirmed = false;
      this.tripStartedAt = null;
      this.startupOffRouteSuppressed = false;
      this.startupRerouteSuppressed = false;
      this.allowImplicitResume = false;
      this.latestUnconfirmedInput = null;
      this.lastStatus = "navigating";
      this.lastOffRoute = false;
      this.resetManeuverState();
    }
    confirmTripStarted(destinationName) {
      if (!this.tripActive)
        return;
      this.tripConfirmed = true;
      this.tripStartedAt = Date.now();
      if (this.canSpeak()) {
        const destination = cleanSpokenText(destinationName);
        this.enqueue({
          text: destination ? `Navigation started to ${destination}.` : "Navigation started.",
          priority: 100,
          expiresAt: Date.now() + 12000
        });
      }
      const latest = this.latestUnconfirmedInput;
      this.latestUnconfirmedInput = null;
      if (latest)
        this.observe(latest);
    }
    observe(input) {
      if (this.disposed)
        return;
      if (!input.running && input.status === "idle") {
        if (this.tripActive)
          this.endTrip();
        this.lastStatus = input.status;
        return;
      }
      if (this.allowImplicitResume && !this.tripActive && input.running && input.status === "navigating") {
        this.tripActive = true;
        this.tripConfirmed = true;
        this.tripStartedAt = null;
        this.allowImplicitResume = false;
      }
      if (!this.tripActive) {
        this.lastStatus = input.status;
        return;
      }
      if (this.tripActive && !this.tripConfirmed) {
        this.latestUnconfirmedInput = input;
        return;
      }
      const startupOffRouteGraceActive = this.isStartupOffRouteGraceActive();
      const enteredRerouting = input.status === "rerouting" && this.lastStatus !== "rerouting";
      const deferredStartupReroute = input.status === "rerouting" && this.startupRerouteSuppressed && !startupOffRouteGraceActive;
      if (enteredRerouting || deferredStartupReroute) {
        this.discardStaleManeuverPrompts();
        this.currentManeuverKey = null;
        this.currentRepeatPhrase = "Rerouting.";
        if (startupOffRouteGraceActive) {
          this.startupRerouteSuppressed = true;
        } else {
          this.startupRerouteSuppressed = false;
          this.enqueue({ text: "Off route. Rerouting.", priority: 100, expiresAt: Date.now() + 1e4 });
        }
      } else if (input.status !== "rerouting") {
        this.startupRerouteSuppressed = false;
      }
      if (input.status === "arrived" && this.lastStatus !== "arrived") {
        const destination = cleanSpokenText(input.destinationName);
        const side = input.arrivalSide ? `, on your ${input.arrivalSide}` : "";
        const phrase = destination ? `You have arrived at ${destination}${side}.` : `You have arrived${side}.`;
        this.currentManeuverKey = null;
        this.currentRepeatPhrase = phrase;
        this.enqueue({ text: phrase, priority: 110, expiresAt: Date.now() + 20000 });
        this.tripActive = false;
        this.allowImplicitResume = false;
        this.lastOffRoute = false;
      }
      this.lastStatus = input.status;
      if (!input.running || input.status !== "navigating")
        return;
      this.tripActive = true;
      if (input.offRoute && startupOffRouteGraceActive) {
        if (!this.startupOffRouteSuppressed) {
          this.discardStaleManeuverPrompts();
          this.currentManeuverKey = null;
          this.currentPivotIndex = null;
          this.currentRepeatPhrase = null;
        }
        this.startupOffRouteSuppressed = true;
        return;
      }
      if (input.offRoute) {
        this.startupOffRouteSuppressed = false;
        if (!this.lastOffRoute) {
          const phrase = "You are off route. Go back to the route.";
          this.discardStaleManeuverPrompts();
          this.currentManeuverKey = null;
          this.currentRepeatPhrase = phrase;
          this.enqueue({ text: phrase, priority: 100, expiresAt: Date.now() + 12000 });
        }
        this.lastOffRoute = true;
        return;
      }
      if (this.lastOffRoute || this.startupOffRouteSuppressed) {
        this.currentManeuverKey = null;
        this.currentPivotIndex = null;
      }
      this.startupOffRouteSuppressed = false;
      this.lastOffRoute = false;
      const instruction = cleanSpokenText(input.instruction);
      const maneuverType = input.maneuverType?.toUpperCase() ?? null;
      const distance = validDistance(input.distanceMeters);
      if (!instruction || !maneuverType)
        return;
      const signature = `${input.routeRevision}|${maneuverType}|${instruction.toLowerCase()}`;
      const thresholds = THRESHOLDS[input.travelMode];
      const previousNowSpoken = this.currentManeuverKey != null && this.spokenStages.has(`${this.currentManeuverKey}|now`);
      const distanceRebounded = input.pivotIndex == null && signature === this.lastSignature && distance != null && this.lastDistance != null && (distance > this.lastDistance + Math.max(25, thresholds.prepareMeters / 2) || previousNowSpoken && distance > thresholds.nowMeters && distance > this.lastDistance + Math.max(10, thresholds.nowMeters / 2));
      const pivotChanged = this.currentPivotIndex != null && input.pivotIndex != null && input.pivotIndex !== this.currentPivotIndex;
      const newSemanticManeuver = this.currentManeuverKey == null || signature !== this.lastSignature || pivotChanged || distanceRebounded;
      if (newSemanticManeuver) {
        this.discardStaleManeuverPrompts();
        this.syntheticSequence += 1;
        this.currentManeuverKey = `${signature}|semantic-${this.syntheticSequence}`;
        this.currentPivotIndex = input.pivotIndex;
      } else if (this.currentPivotIndex == null && input.pivotIndex != null) {
        this.currentPivotIndex = input.pivotIndex;
      }
      this.lastSignature = signature;
      this.lastDistance = distance;
      const maneuverKey = this.currentManeuverKey;
      if (!maneuverKey)
        return;
      const preparePhrase = buildPreparationPhrase(instruction, distance, input.unitSystem);
      const nowPhrase = buildNowPhrase(instruction, maneuverType);
      if (maneuverType === "ARRIVE") {
        const approachPhrase = distance == null ? "Approaching your destination." : `Destination in ${formatSpokenDistance(distance, input.unitSystem)}.`;
        this.currentRepeatPhrase = approachPhrase;
        const approachStage = `${maneuverKey}|prepare`;
        if (this.canSpeak() && this.mode === "full" && distance != null && distance <= thresholds.prepareMeters && !this.spokenStages.has(approachStage)) {
          this.spokenStages.add(approachStage);
          this.enqueue({
            text: approachPhrase,
            priority: 30,
            expiresAt: Date.now() + 15000,
            maneuverKey
          });
        }
        return;
      }
      this.currentRepeatPhrase = distance != null && distance <= thresholds.nowMeters && TURN_TYPES.has(maneuverType) ? nowPhrase : preparePhrase;
      if (!this.canSpeak())
        return;
      const nowStage = `${maneuverKey}|now`;
      if (TURN_TYPES.has(maneuverType) && distance != null && distance <= thresholds.nowMeters && !this.spokenStages.has(nowStage)) {
        this.spokenStages.add(nowStage);
        this.enqueue({
          text: nowPhrase,
          priority: 90,
          expiresAt: Date.now() + 7000,
          maneuverKey
        });
        return;
      }
      const prepareStage = `${maneuverKey}|prepare`;
      if (this.mode === "full" && distance != null && distance <= thresholds.prepareMeters && distance > thresholds.nowMeters && !this.spokenStages.has(nowStage) && !this.spokenStages.has(prepareStage)) {
        this.spokenStages.add(prepareStage);
        this.enqueue({
          text: preparePhrase,
          priority: 30,
          expiresAt: Date.now() + 15000,
          maneuverKey
        });
      }
    }
    repeatCurrent() {
      if (!this.canSpeak() || !this.tripActive || !this.currentRepeatPhrase)
        return false;
      this.enqueue({
        text: this.currentRepeatPhrase,
        priority: 95,
        expiresAt: Date.now() + 8000,
        maneuverKey: this.currentManeuverKey ?? undefined
      });
      return true;
    }
    endTrip() {
      this.tripActive = false;
      this.tripConfirmed = false;
      this.tripStartedAt = null;
      this.startupOffRouteSuppressed = false;
      this.startupRerouteSuppressed = false;
      this.allowImplicitResume = false;
      this.latestUnconfirmedInput = null;
      this.lastStatus = "idle";
      this.lastOffRoute = false;
      this.currentRepeatPhrase = null;
      this.resetManeuverState();
      this.stopSpeech();
    }
    dispose() {
      this.disposed = true;
      this.endTrip();
    }
    canSpeak() {
      return !this.disposed && this.available && this.mode !== "off";
    }
    isStartupOffRouteGraceActive() {
      return this.tripStartedAt != null && Date.now() - this.tripStartedAt < STARTUP_OFF_ROUTE_GRACE_MS;
    }
    resetManeuverState() {
      this.currentManeuverKey = null;
      this.currentPivotIndex = null;
      this.currentRepeatPhrase = null;
      this.lastSignature = "";
      this.lastDistance = null;
      this.syntheticSequence = 0;
      this.spokenStages.clear();
      this.pending = null;
      this.clearPendingTimer();
    }
    enqueue(prompt) {
      if (!this.canSpeak() || !prompt.text)
        return;
      if (prompt.priority >= 90) {
        this.pending = null;
        this.clearPendingTimer();
        if (this.speaking && prompt.priority >= this.speakingPriority) {
          this.speaker.stop();
          this.startPrompt(prompt);
          return;
        }
      }
      if (this.speaking) {
        if (!this.pending || prompt.priority >= this.pending.priority)
          this.pending = prompt;
        return;
      }
      const gap = prompt.priority >= 90 ? 0 : MIN_AUTOMATIC_PROMPT_GAP_MS;
      const wait = Math.max(0, this.lastPromptStartedAt + gap - Date.now());
      if (wait > 0) {
        if (!this.pending || prompt.priority >= this.pending.priority)
          this.pending = prompt;
        if (!this.pendingTimer) {
          this.pendingTimer = setTimeout(() => {
            this.pendingTimer = null;
            this.drainPending();
          }, wait);
        }
        return;
      }
      this.startPrompt(prompt);
    }
    startPrompt(prompt) {
      if (!this.isPromptValid(prompt))
        return;
      const generation = ++this.speakingGeneration;
      this.speaking = true;
      this.speakingPriority = prompt.priority;
      this.speakingManeuverKey = prompt.maneuverKey ?? null;
      this.lastPromptStartedAt = Date.now();
      this.log(`VOICE ${prompt.text}`);
      this.speaker.speak(prompt.text, {
        stopOtherAudio: false,
        voice_settings: { speed: 1.05 }
      }).catch((err) => {
        this.log(`VOICE failed: ${err instanceof Error ? err.message : String(err)}`);
      }).finally(() => {
        if (generation !== this.speakingGeneration)
          return;
        this.speaking = false;
        this.speakingPriority = 0;
        this.speakingManeuverKey = null;
        this.drainPending();
      });
    }
    drainPending() {
      if (this.speaking)
        return;
      const next = this.pending;
      this.pending = null;
      if (!next || !this.isPromptValid(next))
        return;
      this.enqueue(next);
    }
    isPromptValid(prompt) {
      if (!this.canSpeak() || Date.now() > prompt.expiresAt)
        return false;
      return !prompt.maneuverKey || prompt.maneuverKey === this.currentManeuverKey;
    }
    discardStaleManeuverPrompts() {
      if (this.pending?.maneuverKey) {
        this.pending = null;
        this.clearPendingTimer();
      }
      if (!this.speaking || !this.speakingManeuverKey)
        return;
      this.speakingGeneration += 1;
      this.speaker.stop();
      this.speaking = false;
      this.speakingPriority = 0;
      this.speakingManeuverKey = null;
    }
    stopSpeech() {
      this.pending = null;
      this.clearPendingTimer();
      this.speakingGeneration += 1;
      if (this.speaking)
        this.speaker.stop();
      this.speaking = false;
      this.speakingPriority = 0;
      this.speakingManeuverKey = null;
    }
    clearPendingTimer() {
      if (!this.pendingTimer)
        return;
      clearTimeout(this.pendingTimer);
      this.pendingTimer = null;
    }
  }
  function selectAudioGuidanceDistance(maneuverType, eventDistanceMeters, liveDisplayDistanceMeters) {
    const eventDistance = validDistance(eventDistanceMeters ?? null);
    if (maneuverType?.toUpperCase() !== "ARRIVE")
      return eventDistance;
    return validDistance(liveDisplayDistanceMeters ?? null) ?? eventDistance;
  }
  function validDistance(value) {
    return value != null && Number.isFinite(value) && value >= 0 ? value : null;
  }
  function cleanSpokenText(value) {
    return (value ?? "").replace(/[\n\r]+/g, " ").replace(/[←→↑↺↰↱↖↗⤴⤵●⇆]/g, "").replace(/\s+/g, " ").replace(/[.\s]+$/, "").trim();
  }
  function buildPreparationPhrase(instruction, distanceMeters, unit) {
    if (distanceMeters == null)
      return `${capitalize(instruction)}.`;
    return `In ${formatSpokenDistance(distanceMeters, unit)}, ${lowercaseFirst(instruction)}.`;
  }
  function buildNowPhrase(instruction, maneuverType) {
    if (maneuverType === "CROSS_STREET")
      return "Cross the street now.";
    if (maneuverType === "U_TURN")
      return "Turn around now.";
    return `${capitalize(instruction)} now.`;
  }
  function formatSpokenDistance(meters, unit) {
    if (unit === "imperial") {
      const feet = meters * 3.28084;
      if (feet < 528)
        return `${Math.max(10, Math.round(feet / 10) * 10)} feet`;
      const miles = feet / 5280;
      return `${miles.toFixed(1)} ${miles >= 0.95 && miles < 1.05 ? "mile" : "miles"}`;
    }
    if (meters < 1000) {
      const rounded = meters < 100 ? Math.max(5, Math.round(meters / 5) * 5) : Math.round(meters / 10) * 10;
      return `${rounded} meters`;
    }
    const kilometers = meters / 1000;
    return `${kilometers.toFixed(1)} ${kilometers >= 0.95 && kilometers < 1.05 ? "kilometer" : "kilometers"}`;
  }
  function capitalize(value) {
    return value ? value.charAt(0).toUpperCase() + value.slice(1) : value;
  }
  function lowercaseFirst(value) {
    return value ? value.charAt(0).toLowerCase() + value.slice(1) : value;
  }

  // src/background/managers/CompassManager.ts
  class CompassManager {
    session;
    constructor(session) {
      this.session = session;
    }
    onUpdate(handler) {
      return this.session.heading.onUpdate(handler);
    }
  }

  // src/background/managers/DisplayManager.ts
  class DisplayManager2 {
    session;
    constructor(session) {
      this.session = session;
    }
    get bitmapLimits() {
      const display = this.session.capabilities?.display;
      const dimension = (value, fallback) => typeof value === "number" && Number.isInteger(value) && value > 0 ? value : fallback;
      const width = dimension(display?.width, 576);
      const height = dimension(display?.height, 288);
      return {
        width,
        height,
        maxWidth: display?.maxImageElements === 0 ? 0 : Math.min(width, dimension(display?.maxImagePx?.width, width)),
        maxHeight: display?.maxImageElements === 0 ? 0 : Math.min(height, dimension(display?.maxImagePx?.height, height))
      };
    }
    getBitmapSize(width = 288, height = 140) {
      const { maxWidth, maxHeight } = this.bitmapLimits;
      const w = Math.min(width, maxWidth);
      const h = Math.min(height, maxHeight);
      this.bitmapBox(w, h);
      return { w, h };
    }
    bitmapBox(w, h) {
      const { width, height, maxWidth, maxHeight } = this.bitmapLimits;
      if (!Number.isInteger(w) || !Number.isInteger(h) || w <= 0 || h <= 0 || w > maxWidth || h > maxHeight) {
        throw new RangeError(`Bitmap ${w}x${h} is unsupported; maximum image size is ${maxWidth}x${maxHeight}`);
      }
      return { x: Math.round((width - w) / 2), y: Math.round((height - h) / 2), w, h };
    }
    static HUD = {
      map: { x: 340, y: 80, w: 140, h: 140 },
      arrow: { x: 0, y: 182, w: 38, h: 38 },
      clock: { x: 0, y: 0, w: 64, h: 40 },
      stats: { x: 280, y: 0, w: 200, h: 80 },
      maneuver: { x: 40, y: 100, w: 270, h: 120 },
      message: { x: 12, y: 54, w: 310, h: 156 }
    };
    mode = null;
    arrowBmp = null;
    mapBmp = null;
    clock = null;
    stats = null;
    maneuver = null;
    message = null;
    buildFrame() {
      const els = [];
      if (this.mode === "hud") {
        if (this.arrowBmp)
          els.push({ type: "image", id: "arrow", box: DisplayManager2.HUD.arrow, data: this.arrowBmp });
        if (this.maneuver != null)
          els.push({ type: "text", id: "maneuver", box: DisplayManager2.HUD.maneuver, text: this.maneuver });
        if (this.stats != null)
          els.push({ type: "text", id: "stats", box: DisplayManager2.HUD.stats, text: this.stats });
      } else if (this.mode === "message" && this.message != null) {
        els.push({
          type: "text",
          id: "message",
          box: DisplayManager2.HUD.message,
          text: this.message,
          ...readGlassesCapabilities(this.session.capabilities).canPosition ? { style: { breakMode: "word" } } : {}
        });
      }
      if (this.clock != null)
        els.push({ type: "text", id: "clock", box: DisplayManager2.HUD.clock, text: this.clock });
      if (this.mapBmp)
        els.push({ type: "image", id: "map", box: DisplayManager2.HUD.map, data: this.mapBmp });
      return els;
    }
    pushFrame() {
      this.safeCall(() => void this.session.display.render(this.buildFrame()));
    }
    showNavHud(frame) {
      this.mode = "hud";
      if (frame.arrowBmp !== undefined)
        this.arrowBmp = frame.arrowBmp;
      if (frame.stats !== undefined)
        this.stats = frame.stats;
      if (frame.maneuver !== undefined)
        this.maneuver = frame.maneuver;
      if (frame.clock !== undefined)
        this.clock = frame.clock;
      this.pushFrame();
    }
    showNavMessage(text, clock) {
      this.mode = "message";
      this.message = text;
      if (clock !== undefined)
        this.clock = clock;
      this.pushFrame();
    }
    showCompactNavHud(maneuver, stats) {
      this.mode = "message";
      this.message = [maneuver, stats].filter(Boolean).join(`

`);
      this.clock = null;
      this.mapBmp = null;
      this.pushFrame();
    }
    enqueue(_box, fn) {
      this.safeCall(fn);
    }
    showText(text, durationMs) {
      const { width: w, height: h } = this.bitmapLimits;
      this.enqueue("wall", () => void this.session.display.render([{ type: "text", id: "wall", box: { x: 0, y: 0, w, h }, text }], durationMs != null ? { durationMs } : undefined));
    }
    showTextTest() {
      this.showText("Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec venenatis vulputate lorem. Maecenas vestibulum mollis diam. Pellentesque ut neque. Sed lectus. Donec sodales sagittis magna.");
    }
    showBitmap(base64Bmp) {
      this.mapBmp = base64Bmp;
      this.pushFrame();
    }
    clearMinimap() {
      this.mapBmp = null;
      this.pushFrame();
    }
    showTestBox(width, height) {
      const { w, h } = this.bitmapBox(width, height);
      const base64Bmp = borderTestImageBase64(w, h);
      this.safeCall(() => void this.session.display.render([]));
      setTimeout(() => {
        this.renderCenteredBitmap(base64Bmp, w, h);
      }, 1000);
    }
    renderCenteredBitmap(data, w, h) {
      const box = this.bitmapBox(w, h);
      this.safeCall(() => void this.session.display.render([{ type: "image", id: "bmp", box, data }]));
    }
    showLargeBitmap(base64Bmp, width = 288, height = 140) {
      this.renderCenteredBitmap(base64Bmp, width, height);
    }
    static MANEUVER_REGION = { x: 0, y: 0, width: 500, height: 220 };
    renderRegionText(text) {
      const r = DisplayManager2.MANEUVER_REGION;
      this.session.display.render([{ type: "text", id: "msg", box: { x: r.x, y: r.y, w: r.width, h: r.height }, text }]);
    }
    showManeuver(text) {
      this.enqueue("maneuver", () => this.renderRegionText(text));
    }
    showLoadingMessage(text) {
      this.safeCall(() => this.renderRegionText(text));
    }
    clearLoadingMessage() {
      this.safeCall(() => this.renderRegionText(""));
    }
    showTripStats(text) {
      this.enqueue("stats", () => this.renderRegionText(text));
    }
    showBitmapTest(base64Bmp) {
      this.renderCenteredBitmap(base64Bmp, 288, 288);
    }
    showBitmapSize(size, height) {
      const { w, h } = this.bitmapBox(size, height ?? size);
      const base64Bmp = borderTestImageBase64(w, h);
      this.safeCall(() => void this.session.display.render([]));
      setTimeout(() => {
        this.renderCenteredBitmap(base64Bmp, w, h);
      }, 3000);
    }
    showRawBitmap(base64Bmp, width, height) {
      this.renderCenteredBitmap(base64Bmp, width, height);
    }
    clear() {
      this.mode = null;
      this.arrowBmp = null;
      this.mapBmp = null;
      this.clock = null;
      this.stats = null;
      this.maneuver = null;
      this.message = null;
      this.safeCall(() => void this.session.display.render([]));
    }
    safeCall(fn) {
      try {
        fn();
      } catch (err) {
        console.log("[NAV-MINI] display call ignored:", err);
      }
    }
  }

  // src/background/managers/LocationManager.ts
  class LocationManager {
    session;
    constructor(session) {
      this.session = session;
    }
    onUpdate(handler) {
      return this.session.location.onUpdate(handler);
    }
    getOnce() {
      return this.session.location.getOnce();
    }
  }

  // src/background/managers/ManeuverFormatter.ts
  var IMMINENT_M = 30;

  class ManeuverFormatter {
    isStraight(m) {
      return !!m && (m.maneuverType === "STRAIGHT" || m.maneuverType === "CONTINUE");
    }
    cap(s) {
      return s.charAt(0).toUpperCase() + s.slice(1);
    }
    glyph(type) {
      switch (type.toUpperCase()) {
        case "TURN_LEFT":
          return "↰";
        case "TURN_RIGHT":
          return "↱";
        case "SLIGHT_LEFT":
          return "↖";
        case "SLIGHT_RIGHT":
          return "↗";
        case "SHARP_LEFT":
          return "⤴";
        case "SHARP_RIGHT":
          return "⤵";
        case "U_TURN":
          return "↶";
        case "STRAIGHT":
        case "CONTINUE":
          return "↑";
        case "ARRIVE":
          return "●";
        case "CROSS_STREET":
          return "⇆";
        default:
          return "↑";
      }
    }
    arrow(type) {
      const t = type.toUpperCase();
      if (t === "CROSS_STREET")
        return "⇆";
      if (t.includes("LEFT"))
        return "←";
      if (t.includes("RIGHT"))
        return "→";
      if (t === "U_TURN")
        return "↺";
      return "↑";
    }
    humanize(type) {
      switch (type.toUpperCase()) {
        case "TURN_LEFT":
          return "turn left";
        case "TURN_RIGHT":
          return "turn right";
        case "SLIGHT_LEFT":
          return "slight left";
        case "SLIGHT_RIGHT":
          return "slight right";
        case "SHARP_LEFT":
          return "sharp left";
        case "SHARP_RIGHT":
          return "sharp right";
        case "U_TURN":
          return "turn around";
        case "STRAIGHT":
        case "CONTINUE":
          return "continue straight";
        case "ARRIVE":
          return "arrive";
        case "CROSS_STREET":
          return "cross the road";
        default:
          return type.toLowerCase().replace(/_/g, " ");
      }
    }
    headline(m, unit = "metric") {
      const verb = this.humanize(m.maneuverType);
      if (m.maneuverType === "ARRIVE") {
        return m.distanceMeters > 0 ? `Arriving in ${formatDistance(m.distanceMeters, unit)}` : "Arriving";
      }
      if (m.maneuverType === "STRAIGHT") {
        return "Continue straight";
      }
      if (m.distanceMeters > 0) {
        return `In ${formatDistance(m.distanceMeters, unit)}, ${verb}`;
      }
      return this.cap(verb);
    }
    glassesLines(m, unit = "metric") {
      const dist = m.distanceMeters;
      const isStraightT = this.isStraight(m);
      const arrowed = (verb2) => `${this.arrow(m.maneuverType)} ${verb2}`;
      const toRoad = this.cleanRoad(m.toRoad, m.maneuverType);
      if (!isStraightT && dist >= 0 && dist <= IMMINENT_M) {
        const verb2 = this.humanize(m.maneuverType);
        const onto2 = m.maneuverType === "CROSS_STREET" || !toRoad ? "" : ` onto ${toRoad}`;
        return { now: arrowed(`${this.cap(verb2)}${onto2}`), next: null };
      }
      const road = this.cleanRoad(m.fromRoad, m.maneuverType);
      const distStr = dist > 0 ? formatDistance(dist, unit) : null;
      const nowLine = road && distStr ? `↑ ${road} • ${distStr}` : road ? `↑ ${road}` : distStr ? `↑ Continue ${distStr}` : "↑ Continue";
      if (isStraightT) {
        return { now: nowLine, next: null };
      }
      const verb = this.humanize(m.maneuverType);
      const onto = m.maneuverType === "CROSS_STREET" || !toRoad ? "" : ` onto ${toRoad}`;
      return { now: nowLine, next: arrowed(`Then ${verb}${onto}`) };
    }
    glassesProgressLine(m, unit = "metric") {
      const dist = m.distanceToDestinationMeters;
      const time = m.timeToDestinationSeconds;
      const haveDist = typeof dist === "number" && dist >= 0;
      const haveTime = typeof time === "number" && time >= 0;
      if (!haveDist && !haveTime)
        return null;
      const distStr = haveDist ? `${formatDistance(dist, unit)} to destination` : null;
      const timeStr = haveTime ? formatDuration(time) : null;
      return [distStr, timeStr].filter(Boolean).join(" · ");
    }
    cleanRoad(road, maneuverType) {
      const trimmed = road?.trim();
      if (!trimmed)
        return null;
      const verb = this.humanize(maneuverType).toLowerCase();
      const lower = trimmed.toLowerCase();
      if (lower === verb || lower.startsWith(verb))
        return null;
      return trimmed;
    }
  }

  // src/background/managers/NavigationManager.ts
  class NavigationManager {
    session;
    format = new ManeuverFormatter;
    constructor(session) {
      this.session = session;
    }
    get hasPermission() {
      return this.session.navigation.hasPermission;
    }
    requestPermission() {
      return this.session.navigation.requestPermission();
    }
    start(opts) {
      return this.session.navigation.start(opts);
    }
    stop() {
      this.session.navigation.stop();
    }
    get dev() {
      return this.session.navigation.dev;
    }
    onUpdate(handler) {
      return this.session.navigation.onUpdate(handler);
    }
    onRoute(handler) {
      return this.session.navigation.onRoute(handler);
    }
    getState() {
      return this.session.navigation.getState();
    }
    computeRoute(opts) {
      return this.session.navigation.computeRoute(opts);
    }
    async reverseGeocode(coord) {
      const result = await this.session.navigation.reverseGeocodeRoad(coord);
      if (!result.ok)
        return { road: null, address: null };
      return { road: result.road ?? null, address: result.address ?? null };
    }
    onPivot(handler) {
      return this.session.navigation.onPivot(handler);
    }
    getPivots() {
      return this.session.navigation.getPivots();
    }
    getActivePivot() {
      return this.session.navigation.getActivePivot();
    }
    getUpcomingPivot() {
      return this.session.navigation.getUpcomingPivot();
    }
  }

  // src/background/lib/places.ts
  class PlacesSession {
    session;
    token;
    constructor(session) {
      this.session = session;
      this.token = newToken();
    }
    async autocomplete(input, near) {
      if (!input.trim())
        return [];
      const res = await this.session.navigation.placeAutocomplete({
        query: input,
        near,
        sessionToken: this.token
      });
      if (!res.ok)
        throw new Error(res.error || "autocomplete failed");
      return res.suggestions ?? [];
    }
    async details(placeId) {
      const res = await this.session.navigation.placeDetails({
        placeId,
        sessionToken: this.token
      });
      if (!res.ok || !res.place)
        throw new Error(res.error || "details failed");
      const { placeId: id, name, address, lat, lng } = res.place;
      return { placeId: id, name, address, lat, lng };
    }
    reset() {
      this.token = newToken();
    }
  }
  function newToken() {
    if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
      return crypto.randomUUID();
    }
    return Math.random().toString(36).slice(2) + Date.now().toString(36);
  }

  // src/background/managers/PlacesManager.ts
  class PlacesManager {
    session;
    constructor(session) {
      this.session = new PlacesSession(session);
    }
    autocomplete(query, near) {
      return this.session.autocomplete(query, near);
    }
    async details(placeId) {
      const result = await this.session.details(placeId);
      this.session.reset();
      return result;
    }
  }

  // src/background/managers/SimpleStorageManager.ts
  class SimpleStorageManager {
    session;
    constructor(session) {
      this.session = session;
    }
    get(key) {
      return this.session.storage.get(key);
    }
    set(key, value) {
      return this.session.storage.set(key, value);
    }
    delete(key) {
      return this.session.storage.delete(key);
    }
    list() {
      return this.session.storage.list();
    }
    async getJSON(key) {
      const raw = await this.session.storage.get(key);
      if (raw === null)
        return null;
      try {
        return JSON.parse(raw);
      } catch {
        return null;
      }
    }
    setJSON(key, value) {
      return this.session.storage.set(key, JSON.stringify(value));
    }
    static RECENT_SEARCHES_KEY = "recentSearches";
    static RECENT_SEARCHES_MAX = 10;
    async getRecentSearches() {
      return await this.getJSON(SimpleStorageManager.RECENT_SEARCHES_KEY) ?? [];
    }
    async addRecentSearch(place) {
      const current = await this.getRecentSearches();
      const next = [place, ...current.filter((p) => p.placeId !== place.placeId)].slice(0, SimpleStorageManager.RECENT_SEARCHES_MAX);
      await this.setJSON(SimpleStorageManager.RECENT_SEARCHES_KEY, next);
    }
    static SAVED_PLACES_KEY = "savedPlaces";
    static SAVED_MAX = 20;
    async getAllSavedPlaces() {
      return await this.getJSON(SimpleStorageManager.SAVED_PLACES_KEY) ?? [];
    }
    async addSavedPlace(place) {
      const current = await this.getAllSavedPlaces();
      const filtered = current.filter((p) => {
        if (place.type && p.type === place.type)
          return false;
        if (p.placeId === place.placeId)
          return false;
        return true;
      });
      const next = [place, ...filtered].slice(0, SimpleStorageManager.SAVED_MAX);
      await this.setJSON(SimpleStorageManager.SAVED_PLACES_KEY, next);
    }
    async removeSavedPlace(placeId) {
      const current = await this.getAllSavedPlaces();
      const next = current.filter((p) => p.placeId !== placeId);
      if (next.length !== current.length) {
        await this.setJSON(SimpleStorageManager.SAVED_PLACES_KEY, next);
      }
    }
    static UNIT_SYSTEM_KEY = "unitSystem";
    async getUnitSystem() {
      const raw = await this.get(SimpleStorageManager.UNIT_SYSTEM_KEY);
      return raw === "imperial" ? "imperial" : "metric";
    }
    async setUnitSystem(unit) {
      await this.set(SimpleStorageManager.UNIT_SYSTEM_KEY, unit);
    }
    static VOICE_GUIDANCE_MODE_KEY = "voiceGuidanceMode";
    async getVoiceGuidanceMode() {
      const raw = await this.get(SimpleStorageManager.VOICE_GUIDANCE_MODE_KEY);
      return raw === "off" || raw === "essential" || raw === "full" ? raw : null;
    }
    async setVoiceGuidanceMode(mode) {
      await this.set(SimpleStorageManager.VOICE_GUIDANCE_MODE_KEY, mode);
    }
  }

  // src/background/NavigationController.ts
  class NavigationController {
    session;
    ui;
    location;
    compass;
    display;
    navigation;
    storage;
    places;
    audioGuidance;
    osmMapCenter = { lat: 37.7766853, lng: -122.4229361 };
    OSM_MAP_SIZE = 88;
    OSM_MAP_RADIUS_M = 133;
    unsubs = [];
    started = false;
    logSeq = 0;
    lastHudKey = "";
    lastArrowKey = "";
    lastHudAt = 0;
    lastMinimapPng = null;
    lastMinimapAt = 0;
    minimapTrailingTimer = null;
    minimapWatchdogTimer = null;
    lastMinimapPushAt = 0;
    MINIMAP_WATCHDOG_IDLE_MS = 2000;
    MINIMAP_WATCHDOG_INTERVAL_MS = 2000;
    forceMinimapPush = false;
    startingShownAt = 0;
    showMinimap = true;
    lastTripStats = "";
    lastTripStatsAt = 0;
    largeMapShown = false;
    largeMapTransitioning = false;
    starting = false;
    osmRoadsCache = null;
    osmRoadsCenter = null;
    osmFetchInFlight = false;
    lastCoordsAt = 0;
    gettingFix = false;
    hasCompletedTrip = false;
    lastOffRouteBucket = 0;
    offRouteAdvisory = false;
    offRouteAdvisoryDistanceM = null;
    tripStartCoords = null;
    lastStartOpts = null;
    lastAutoRebuildAt = 0;
    pendingRebuildTimer = null;
    coords = null;
    heading = null;
    moveBearingAnchor = null;
    moveBearingDeg = null;
    MOVE_BEARING_MIN_M = 3;
    trip = {
      status: "idle",
      running: false,
      maneuver: null,
      activeDestination: null,
      activeDestinationName: null,
      routePoints: null,
      routeSteps: null,
      offRouteAt: null,
      arrivalSide: null
    };
    activePivot = null;
    upcomingPivot = null;
    log = [];
    devSettings = {
      simulate: false,
      speedMultiplier: 5,
      wrongSidewalk: false,
      skipCrossings: false,
      useRawInstructions: true,
      largeMapEnabled: false
    };
    unitSystem = "metric";
    capabilities = {
      modelName: null,
      hasDisplay: false,
      canPosition: false,
      hasSpeaker: false,
      hasButton: false
    };
    voiceGuidanceMode = "off";
    voiceGuidancePreferenceLoaded = false;
    voiceGuidancePreferenceExplicit = false;
    routeRevision = 0;
    cachedInstructions = null;
    refetchingInstructions = false;
    constructor(session) {
      this.session = session;
      this.ui = session.ui;
      this.location = new LocationManager(session);
      this.compass = new CompassManager(session);
      this.display = new DisplayManager2(session);
      this.navigation = new NavigationManager(session);
      this.storage = new SimpleStorageManager(session);
      this.places = new PlacesManager(session);
      this.audioGuidance = new AudioGuidanceManager(session.speaker, (message) => this.appendLog(message));
    }
    start() {
      if (this.started)
        return;
      this.started = true;
      this.applyCapabilities(this.session.capabilities);
      this.loadVoiceGuidanceMode();
      this.wireSensorSubscriptions();
      this.wireCapabilityChanges();
      this.wireRpcHandlers();
      this.wireUIBroadcasts();
      this.registerActions();
      this.wireHUDPump();
      this.wireTouchGestures();
      this.wireRepeatButton();
      this.primeNavigationPermission();
      this.seedInitialFix();
      this.loadUnitSystem();
      this.session.onBeforeDisconnect(() => this.dispose());
    }
    defaultVoiceGuidanceMode(capabilities = this.capabilities) {
      if (!capabilities.hasSpeaker)
        return "off";
      return capabilities.hasDisplay ? "essential" : "full";
    }
    applyCapabilities(raw) {
      const previous = this.capabilities;
      this.capabilities = readGlassesCapabilities(raw);
      this.audioGuidance.setAvailable(this.capabilities.hasSpeaker);
      if (!this.voiceGuidancePreferenceExplicit) {
        this.voiceGuidanceMode = this.defaultVoiceGuidanceMode();
        this.audioGuidance.setMode(this.voiceGuidanceMode);
      }
      if (!this.capabilities.hasDisplay) {
        this.stopMinimapWatchdog();
        this.lastMinimapPng = null;
      } else if (!previous.hasDisplay && this.trip.running) {
        this.startMinimapWatchdog();
        this.lastHudKey = "";
        this.refreshHUD();
      } else if (previous.canPosition !== this.capabilities.canPosition && this.trip.running) {
        if (this.capabilities.canPosition) {
          this.startMinimapWatchdog();
        } else {
          this.stopMinimapWatchdog();
          this.lastMinimapPng = null;
        }
        this.lastHudKey = "";
        this.refreshHUD();
      }
      this.broadcastVoiceGuidanceState();
    }
    wireCapabilityChanges() {
      this.unsubs.push(this.session.on("ready", () => this.applyCapabilities(this.session.capabilities)));
      this.unsubs.push(this.session.onCapabilitiesChange((capabilities) => this.applyCapabilities(capabilities)));
    }
    broadcastVoiceGuidanceState() {
      this.ui.send("nav:voice-guidance-update", {
        voiceGuidanceMode: this.voiceGuidanceMode,
        capabilities: this.capabilities
      });
    }
    loadVoiceGuidanceMode() {
      this.storage.getVoiceGuidanceMode().then((stored) => {
        if (this.voiceGuidancePreferenceLoaded)
          return;
        this.voiceGuidancePreferenceLoaded = true;
        this.voiceGuidancePreferenceExplicit = stored != null;
        this.voiceGuidanceMode = stored ?? this.defaultVoiceGuidanceMode();
        this.audioGuidance.setMode(this.voiceGuidanceMode);
        this.broadcastVoiceGuidanceState();
      }).catch((err) => {
        if (this.voiceGuidancePreferenceLoaded)
          return;
        this.voiceGuidancePreferenceLoaded = true;
        this.appendLog(`voice-guidance load failed: ${err instanceof Error ? err.message : String(err)}`);
      });
    }
    wireRepeatButton() {
      this.unsubs.push(this.session.input.onButtonPress((data) => {
        if (data.pressType !== "short" || !this.trip.running || !this.capabilities.hasButton)
          return;
        if (this.audioGuidance.repeatCurrent())
          this.appendLog(`VOICE repeat (${data.buttonId})`);
      }));
    }
    wireSensorSubscriptions() {
      this.unsubs.push(this.location.onUpdate((d) => {
        const here = { lat: d.lat, lng: d.lng };
        if (this.moveBearingAnchor == null) {
          this.moveBearingAnchor = here;
        } else if (haversineMeters2(this.moveBearingAnchor, here) >= this.MOVE_BEARING_MIN_M) {
          this.moveBearingDeg = bearingDeg2(this.moveBearingAnchor, here);
          this.moveBearingAnchor = here;
        }
        this.coords = {
          lat: d.lat,
          lng: d.lng,
          accuracy: d.accuracy,
          ts: d.timestamp ?? Date.now()
        };
        this.lastCoordsAt = Date.now();
        this.ui.send("nav:coords", this.coords);
        this.logOffRouteThresholds();
        this.maybeFireEarlyArrival();
        this.refreshHUD();
      }));
      const HEADING_MIN_INTERVAL_MS = 100;
      let lastHeadingAt = 0;
      let pendingHeading = null;
      let pendingTimer = null;
      const flushHeading = () => {
        pendingTimer = null;
        if (pendingHeading == null)
          return;
        this.heading = pendingHeading;
        pendingHeading = null;
        lastHeadingAt = Date.now();
        this.ui.send("nav:heading", { degrees: this.heading });
      };
      this.unsubs.push(this.compass.onUpdate((d) => {
        const now = Date.now();
        const elapsed = now - lastHeadingAt;
        if (elapsed >= HEADING_MIN_INTERVAL_MS) {
          this.heading = d.degrees;
          lastHeadingAt = now;
          this.ui.send("nav:heading", { degrees: this.heading });
        } else {
          pendingHeading = d.degrees;
          if (!pendingTimer)
            pendingTimer = setTimeout(flushHeading, HEADING_MIN_INTERVAL_MS - elapsed);
        }
      }));
      this.unsubs.push(() => {
        if (pendingTimer)
          clearTimeout(pendingTimer);
        pendingTimer = null;
        pendingHeading = null;
      });
      this.unsubs.push(this.navigation.onPivot(() => {
        this.activePivot = this.navigation.getActivePivot();
        this.upcomingPivot = this.navigation.getUpcomingPivot();
        this.ui.send("nav:pivots", {
          active: this.activePivot,
          upcoming: this.upcomingPivot
        });
        this.refreshHUD();
      }));
      this.unsubs.push(this.navigation.onUpdate((u) => {
        this.appendLog(this.formatUpdate(u));
        switch (u.kind) {
          case "maneuver":
            if (this.trip.status === "arrived")
              break;
            this.trip = {
              ...this.trip,
              status: "navigating",
              running: true,
              maneuver: u,
              offRouteAt: null
            };
            this.heartbeatLocationIfStale();
            break;
          case "off_route":
            this.trip = { ...this.trip, offRouteAt: Date.now() };
            break;
          case "rerouting":
            this.trip = { ...this.trip, status: "rerouting", maneuver: null };
            break;
          case "arrived": {
            const side = sideOfFinalSegment(this.trip.routePoints, this.trip.activeDestination);
            this.trip = {
              ...this.trip,
              status: "arrived",
              running: false,
              maneuver: null,
              activeDestination: null,
              routePoints: null,
              routeSteps: null,
              offRouteAt: null,
              arrivalSide: side
            };
            this.hasCompletedTrip = true;
            this.activePivot = null;
            this.upcomingPivot = null;
            this.cancelPendingRebuild();
            this.tripStartCoords = null;
            this.lastStartOpts = null;
            this.lastAutoRebuildAt = 0;
            this.lastOffRouteBucket = 0;
            this.offRouteAdvisory = false;
            this.offRouteAdvisoryDistanceM = null;
            this.cachedInstructions = null;
            this.exitLargeMap();
            break;
          }
          case "error":
            this.trip = { ...this.trip, status: "idle", running: false };
            this.cancelPendingRebuild();
            this.tripStartCoords = null;
            this.lastStartOpts = null;
            this.lastAutoRebuildAt = 0;
            this.lastOffRouteBucket = 0;
            this.offRouteAdvisory = false;
            this.offRouteAdvisoryDistanceM = null;
            this.cachedInstructions = null;
            this.exitLargeMap();
            break;
        }
        this.ui.send("nav:trip-state", this.trip);
        this.refreshHUD();
      }));
      this.unsubs.push(this.navigation.onRoute((route) => {
        this.routeRevision += 1;
        const steps = route.steps && route.steps.length > 0 ? route.steps.map((s, i) => ({
          lat: s.lat,
          lng: s.lng,
          road: s.road ?? null,
          maneuver: s.maneuver,
          distanceMeters: s.distanceMeters,
          instruction: this.cachedInstructions && i < this.cachedInstructions.length ? this.cachedInstructions[i] || null : null
        })) : null;
        const status = this.trip.status === "rerouting" ? "navigating" : this.trip.status;
        this.trip = { ...this.trip, status, routePoints: route.points, routeSteps: steps };
        this.lastOffRouteBucket = 0;
        this.offRouteAdvisory = false;
        this.offRouteAdvisoryDistanceM = null;
        if (this.coords) {
          this.tripStartCoords = { lat: this.coords.lat, lng: this.coords.lng };
        }
        this.ui.send("nav:route", { points: route.points, steps });
        this.ui.send("nav:trip-state", this.trip);
        logLiveRoute(route);
        if (this.devSettings.useRawInstructions && steps && steps.length > 0 && (this.cachedInstructions == null || this.cachedInstructions.length !== steps.length)) {
          this.refetchInstructionsForLiveRoute(steps.length);
        }
        setTimeout(() => {
          this.activePivot = this.navigation.getActivePivot();
          this.upcomingPivot = this.navigation.getUpcomingPivot();
          this.ui.send("nav:pivots", { active: this.activePivot, upcoming: this.upcomingPivot });
          this.refreshHUD();
        }, 0);
      }));
    }
    wireRpcHandlers() {
      this.unsubs.push(this.ui.handle("nav:compute-route", async (opts) => {
        const result = await this.navigation.computeRoute(opts);
        const steps = result.routes?.[0]?.steps;
        if (steps && steps.length > 0) {
          this.cachedInstructions = steps.map((s) => cleanInstruction(s.instruction));
        }
        return result;
      }));
      this.unsubs.push(this.ui.handle("nav:request-permission", () => this.navigation.requestPermission()));
      this.unsubs.push(this.ui.handle("nav:get-snapshot", () => this.buildSnapshot()));
      this.unsubs.push(this.ui.handle("nav:get-pivots", () => this.navigation.getPivots()));
      this.unsubs.push(this.ui.handle("places:autocomplete", ({ query, near }) => this.places.autocomplete(query, near)));
      this.unsubs.push(this.ui.handle("places:details", ({ placeId }) => this.places.details(placeId)));
      this.unsubs.push(this.ui.handle("places:reverse-geocode", ({ lat, lng }) => this.navigation.reverseGeocode({ lat, lng })));
      this.unsubs.push(this.ui.handle("storage:list-saved", () => this.storage.getAllSavedPlaces()));
      this.unsubs.push(this.ui.handle("storage:add-saved", (p) => this.storage.addSavedPlace(p)));
      this.unsubs.push(this.ui.handle("storage:remove-saved", ({ placeId }) => this.storage.removeSavedPlace(placeId)));
      this.unsubs.push(this.ui.handle("storage:list-recent", () => this.storage.getRecentSearches()));
      this.unsubs.push(this.ui.handle("storage:add-recent", (p) => this.storage.addRecentSearch(p)));
    }
    async beginTrip(opts) {
      if (this.starting) {
        this.appendLog("START ignored — already starting");
        return { ok: false, error: "A navigation start is already in progress" };
      }
      this.starting = true;
      const { destinationName, ...startOpts } = opts;
      this.trip = {
        ...this.trip,
        status: "navigating",
        running: true,
        activeDestination: startOpts.stops?.[startOpts.stops.length - 1] ?? null,
        activeDestinationName: destinationName ?? null,
        maneuver: null,
        routePoints: null,
        routeSteps: null,
        offRouteAt: null,
        arrivalSide: null
      };
      this.lastStartOpts = opts;
      this.audioGuidance.beginTrip();
      this.startMinimapWatchdog();
      this.tripStartCoords = this.coords ? { lat: this.coords.lat, lng: this.coords.lng } : null;
      this.moveBearingAnchor = this.coords ? { lat: this.coords.lat, lng: this.coords.lng } : null;
      this.moveBearingDeg = null;
      this.lastAutoRebuildAt = 0;
      this.lastOffRouteBucket = 0;
      this.offRouteAdvisory = false;
      this.offRouteAdvisoryDistanceM = null;
      this.activePivot = null;
      this.upcomingPivot = null;
      this.cancelPendingRebuild();
      this.appendLog(`START ${destinationName ?? "(unnamed)"}`);
      this.ui.send("nav:trip-state", this.trip);
      this.refreshHUD();
      try {
        const res = await this.navigation.start(withPivotDefaults(startOpts));
        if (!res.ok) {
          this.appendLog(`START failed: ${res.error ?? "unknown"}`);
          this.rollbackTripToIdle();
        } else {
          this.audioGuidance.confirmTripStarted(destinationName ?? null);
        }
        return res;
      } catch (err) {
        const error = err instanceof Error ? err.message : String(err);
        this.appendLog(`START error: ${error}`);
        this.rollbackTripToIdle();
        return { ok: false, error };
      } finally {
        this.starting = false;
      }
    }
    rollbackTripToIdle() {
      this.audioGuidance.endTrip();
      this.trip = {
        ...this.trip,
        status: "idle",
        running: false,
        activeDestination: null,
        activeDestinationName: null,
        maneuver: null,
        routePoints: null,
        routeSteps: null
      };
      this.ui.send("nav:trip-state", this.trip);
      this.refreshHUD();
    }
    registerActions() {
      try {
        this.unsubs.push(this.session.actions.handle("start_navigation", (params) => this.startNavigationAction(params)));
        this.unsubs.push(this.session.actions.handle("get_saved_addresses", () => getSavedAddresses(this.storage)));
        this.unsubs.push(this.session.actions.handle("set_saved_address", (params) => setSavedAddress(params, this.storage, (query) => this.resolveDestination(query))));
      } catch (err) {
        this.appendLog(`actions register failed: ${err instanceof Error ? err.message : String(err)}`);
      }
    }
    async startNavigationAction(params) {
      if (!this.navigation.hasPermission) {
        return { ok: false, error: "Location permission is required for navigation." };
      }
      const mode = MODES.has(params.travel_mode) ? params.travel_mode : "walking";
      const explicitName = typeof params.destination_name === "string" ? params.destination_name.trim() : "";
      const hasLat = typeof params.latitude === "number";
      const hasLng = typeof params.longitude === "number";
      const query = typeof params.query === "string" && params.query.trim() ? params.query.trim() : null;
      let dest = null;
      if (hasLat && hasLng) {
        const latitude = params.latitude;
        const longitude = params.longitude;
        if (!Number.isFinite(latitude) || !Number.isFinite(longitude) || Math.abs(latitude) > 90 || Math.abs(longitude) > 180) {
          return { ok: false, error: "latitude and longitude must be finite coordinates (|lat| ≤ 90, |lng| ≤ 180)." };
        }
        dest = { lat: latitude, lng: longitude, name: explicitName || undefined };
      } else if (query) {
        dest = await this.resolveDestination(query);
        if (!dest)
          return { ok: false, error: `Couldn't find a place matching "${query}".` };
      } else if (hasLat || hasLng) {
        return { ok: false, error: "Provide both latitude and longitude, or a destination query." };
      } else {
        return { ok: false, error: "Provide a destination query, or latitude and longitude." };
      }
      const res = await this.beginTrip({
        stops: [{ lat: dest.lat, lng: dest.lng }],
        mode,
        destinationName: explicitName || dest.name
      });
      if (!res.ok)
        return { ok: false, error: res.error ?? "Failed to start navigation." };
      return { ok: true, destination: dest };
    }
    async resolveDestination(query) {
      try {
        let near = this.coords ? { lat: this.coords.lat, lng: this.coords.lng } : undefined;
        if (!near) {
          try {
            const d = await this.location.getOnce();
            near = { lat: d.lat, lng: d.lng };
            if (!this.coords) {
              this.coords = { lat: d.lat, lng: d.lng, accuracy: d.accuracy, ts: d.timestamp ?? Date.now() };
              this.lastCoordsAt = Date.now();
              this.ui.send("nav:coords", this.coords);
            }
          } catch {}
        }
        const suggestions = await this.places.autocomplete(query, near);
        if (!suggestions.length)
          return null;
        const details = await this.places.details(suggestions[0].placeId);
        return details;
      } catch (err) {
        this.appendLog(`resolveDestination failed: ${err instanceof Error ? err.message : String(err)}`);
        return null;
      }
    }
    wireUIBroadcasts() {
      this.unsubs.push(this.ui.on("nav:start", async (opts) => {
        await this.beginTrip(opts);
      }));
      this.unsubs.push(this.ui.on("nav:stop", () => {
        this.appendLog("STOP");
        this.audioGuidance.endTrip();
        try {
          this.navigation.stop();
        } catch {}
        this.cancelPendingRebuild();
        this.tripStartCoords = null;
        this.lastStartOpts = null;
        this.lastAutoRebuildAt = 0;
        this.lastOffRouteBucket = 0;
        this.offRouteAdvisory = false;
        this.offRouteAdvisoryDistanceM = null;
        this.activePivot = null;
        this.upcomingPivot = null;
        this.cachedInstructions = null;
        this.trip = {
          ...this.trip,
          status: "idle",
          running: false,
          maneuver: null,
          activeDestination: null,
          routePoints: null,
          routeSteps: null,
          offRouteAt: null,
          arrivalSide: null
        };
        this.hasCompletedTrip = true;
        this.stopMinimapWatchdog();
        this.exitLargeMap();
        this.ui.send("nav:trip-state", this.trip);
        this.refreshHUD();
      }));
      this.unsubs.push(this.ui.on("nav:deviate", () => {
        try {
          this.navigation.dev.deviate();
        } catch (err) {
          this.appendLog(`deviate failed: ${err instanceof Error ? err.message : String(err)}`);
        }
      }));
      this.unsubs.push(this.ui.on("nav:reset-location", () => {
        this.appendLog("RESET LOCATION → real fix");
        this.audioGuidance.endTrip();
        try {
          this.navigation.stop();
        } catch {}
        this.cancelPendingRebuild();
        this.tripStartCoords = null;
        this.lastStartOpts = null;
        this.activePivot = null;
        this.upcomingPivot = null;
        this.cachedInstructions = null;
        this.trip = {
          ...this.trip,
          status: "idle",
          running: false,
          maneuver: null,
          activeDestination: null,
          routePoints: null,
          routeSteps: null,
          offRouteAt: null,
          arrivalSide: null
        };
        this.ui.send("nav:trip-state", this.trip);
        this.refreshHUD();
        this.location.getOnce().then((d) => {
          this.coords = { lat: d.lat, lng: d.lng, accuracy: d.accuracy, ts: d.timestamp ?? Date.now() };
          this.lastCoordsAt = Date.now();
          this.ui.send("nav:coords", this.coords);
          this.appendLog(`reset → ${d.lat.toFixed(5)}, ${d.lng.toFixed(5)}`);
        }).catch((err) => {
          this.appendLog(`reset-location fix failed: ${err instanceof Error ? err.message : String(err)}`);
        });
      }));
      this.unsubs.push(this.ui.on("nav:set-destination", (place) => {
        if (place)
          this.appendLog(`set-destination ${place.name}`);
      }));
      this.unsubs.push(this.ui.on("nav:set-dev-settings", (partial) => {
        const next = { ...this.devSettings, ...partial };
        try {
          if (partial.wrongSidewalk !== undefined && partial.wrongSidewalk !== this.devSettings.wrongSidewalk) {
            this.navigation.dev.setWrongSidewalkOffset(partial.wrongSidewalk);
          }
          if (partial.skipCrossings !== undefined && partial.skipCrossings !== this.devSettings.skipCrossings) {
            this.navigation.dev.setSkipCrossings(partial.skipCrossings);
          }
        } catch (err) {
          this.appendLog(`dev-settings forward failed: ${err instanceof Error ? err.message : String(err)}`);
        }
        const rawJustEnabled = partial.useRawInstructions === true && !this.devSettings.useRawInstructions;
        this.devSettings = next;
        this.ui.send("nav:dev-settings-update", this.devSettings);
        this.refreshHUD();
        if (rawJustEnabled && this.trip.running) {
          const liveLen = this.trip.routeSteps?.length ?? 0;
          if (liveLen > 0 && (this.cachedInstructions == null || this.cachedInstructions.length !== liveLen)) {
            this.refetchInstructionsForLiveRoute(liveLen);
          }
        }
      }));
      this.unsubs.push(this.ui.on("nav:set-units", ({ unitSystem }) => {
        if (unitSystem === this.unitSystem)
          return;
        this.unitSystem = unitSystem;
        this.storage.setUnitSystem(unitSystem).catch((err) => {
          this.appendLog(`unit-system persist failed: ${err instanceof Error ? err.message : String(err)}`);
        });
        this.ui.send("nav:units-update", { unitSystem });
        this.refreshHUD();
      }));
      this.unsubs.push(this.ui.on("nav:set-voice-guidance", ({ mode }) => {
        if (mode === this.voiceGuidanceMode)
          return;
        this.voiceGuidancePreferenceLoaded = true;
        this.voiceGuidancePreferenceExplicit = true;
        this.voiceGuidanceMode = mode;
        this.audioGuidance.setMode(mode);
        this.storage.setVoiceGuidanceMode(mode).catch((err) => {
          this.appendLog(`voice-guidance persist failed: ${err instanceof Error ? err.message : String(err)}`);
        });
        this.broadcastVoiceGuidanceState();
        this.refreshHUD();
      }));
      this.unsubs.push(this.ui.on("nav:repeat-direction", () => {
        if (!this.audioGuidance.repeatCurrent())
          this.appendLog("VOICE repeat ignored — no active direction");
      }));
      this.unsubs.push(this.ui.on("nav:set-show-minimap", (show) => {
        if (show === this.showMinimap)
          return;
        this.showMinimap = show;
        if (!show) {
          if (this.capabilities.hasDisplay)
            this.display.clearMinimap();
          this.lastMinimapPng = null;
          this.lastHudKey = "";
        } else {
          this.lastMinimapPng = null;
          this.refreshHUD();
        }
      }));
      this.unsubs.push(this.ui.handle("test:show-text-test", ({ text, durationMs }) => {
        this.display.showText(text, durationMs);
      }));
      this.unsubs.push(this.ui.handle("test:show-bitmap-test", () => {
        this.display.showBitmapTest(TEST_BITMAP_288_B64);
      }));
      this.unsubs.push(this.ui.handle("test:show-bitmap-size", ({ size, height }) => {
        this.display.showBitmapSize(size, height);
      }));
      this.unsubs.push(this.ui.handle("test:show-osm-map", async () => {
        return this.renderOsmMap("draw");
      }));
      this.unsubs.push(this.ui.handle("test:show-large-map", async () => {
        if (!this.coords)
          return { ok: false, error: "no GPS fix yet" };
        const me = { lat: this.coords.lat, lng: this.coords.lng };
        if (!this.osmRoadsCache) {
          try {
            this.osmRoadsCache = await fetchOsmRoads(me, this.OSM_MINIMAP_RADIUS_M * 2);
            this.osmRoadsCenter = me;
          } catch (err) {
            return { ok: false, error: err instanceof Error ? err.message : String(err) };
          }
        }
        this.renderLargeMap(me);
        return { ok: true };
      }));
      this.unsubs.push(this.ui.handle("test:pan-osm-map", async ({ dir }) => {
        const stepM = this.OSM_MAP_RADIUS_M / 2;
        const mPerDegLat = 111320;
        const mPerDegLng = 111320 * Math.cos(this.osmMapCenter.lat * Math.PI / 180);
        const dLat = stepM / mPerDegLat;
        const dLng = stepM / mPerDegLng;
        if (dir === "up")
          this.osmMapCenter.lat += dLat;
        else if (dir === "down")
          this.osmMapCenter.lat -= dLat;
        else if (dir === "left")
          this.osmMapCenter.lng -= dLng;
        else if (dir === "right")
          this.osmMapCenter.lng += dLng;
        return this.renderOsmMap(`pan ${dir}`);
      }));
      this.unsubs.push(this.ui.handle("test:count-1-to-10", () => {
        for (let i = 1;i <= 10; i++) {
          setTimeout(() => this.display.showText(String(i)), (i - 1) * 3000);
        }
      }));
      this.unsubs.push(this.ui.handle("test:count-both-boxes", () => {
        this.runCountBothBoxesTest();
      }));
      this.unsubs.push(this.ui.onOpen(() => this.ui.send("nav:snapshot", this.buildSnapshot())));
    }
    countBothBoxesTimer = null;
    runCountBothBoxesTest() {
      if (this.countBothBoxesTimer != null)
        return;
      this.display.showBitmap(borderTestImageBase64(100, 100));
      let n = 100;
      const tick = () => {
        this.display.showManeuver(`Top
${n}`);
        this.display.showTripStats(`Bottom
${n}`);
        if (n <= 0) {
          if (this.countBothBoxesTimer != null) {
            clearInterval(this.countBothBoxesTimer);
            this.countBothBoxesTimer = null;
          }
          return;
        }
        n--;
      };
      tick();
      this.countBothBoxesTimer = setInterval(tick, 1000);
    }
    async renderOsmMap(reason) {
      const { lat, lng } = this.osmMapCenter;
      const SIZE = this.OSM_MAP_SIZE;
      console.log(`[OSM-MAP] \uD83D\uDDFA️  ${reason} — fetching roads around ${lat.toFixed(6)},${lng.toFixed(6)} (${SIZE}×${SIZE})`);
      const t0 = Date.now();
      try {
        const base642 = await buildOsmLineMap({
          center: { lat, lng },
          width: SIZE,
          height: SIZE,
          viewRadiusMeters: this.OSM_MAP_RADIUS_M,
          lineWidthPx: 2
        });
        console.log(`[OSM-MAP] ✅ rendered ${SIZE}×${SIZE} BMP (${(base642.length / 1024).toFixed(1)} KB) in ${Date.now() - t0}ms — sending to glasses`);
        this.display.showRawBitmap(base642, SIZE, SIZE);
        return { ok: true };
      } catch (err) {
        const error = err instanceof Error ? err.message : String(err);
        console.log(`[OSM-MAP] ❌ failed after ${Date.now() - t0}ms:`, error);
        return { ok: false, error };
      }
    }
    wireHUDPump() {
      const handle = setTimeout(() => {
        try {
          this.refreshHUD();
        } catch {}
      }, 250);
      this.unsubs.push(() => clearTimeout(handle));
      const HUD_TICK_MS = 1000;
      const tick = setInterval(() => {
        if (!this.trip.running)
          return;
        try {
          this.refreshHUD();
        } catch {}
      }, HUD_TICK_MS);
      this.unsubs.push(() => clearInterval(tick));
    }
    wireTouchGestures() {
      this.unsubs.push(this.session.input.onTouch((data) => {
        if (!this.capabilities.hasDisplay)
          return;
        const d = data;
        const gesture = String(d.kind ?? d.gestureName ?? "");
        if (gesture === "system_exit")
          return;
        if (!this.trip.running) {
          console.log(`[TOUCH] ignored — not in live navigation`);
          return;
        }
        const isSwipe = gesture === "swipe_up" || gesture === "swipe_down";
        if (!isSwipe)
          return;
        if (!this.devSettings.largeMapEnabled) {
          console.log(`[TOUCH] swipe ignored — large map disabled (dev toggle off)`);
          return;
        }
        if (this.largeMapTransitioning) {
          console.log(`[TOUCH] swipe ignored — large-map transition in flight`);
          return;
        }
        if (!this.largeMapShown) {
          console.log(`[TOUCH] swipe → showing large route map`);
          this.showLargeMap();
        } else {
          console.log(`[TOUCH] swipe → dismissing large map → HUD`);
          this.largeMapShown = false;
          this.lastHudKey = "";
          this.lastMinimapPng = null;
          this.refreshHUD();
        }
      }));
    }
    exitLargeMap() {
      this.largeMapTransitioning = false;
      if (!this.largeMapShown)
        return;
      this.largeMapShown = false;
      this.lastHudKey = "";
      this.lastMinimapPng = null;
      this.display.clearMinimap();
      this.display.clearLoadingMessage();
    }
    showLargeMap() {
      this.largeMapShown = true;
      this.largeMapTransitioning = true;
      this.lastHudKey = "";
      this.lastMinimapPng = null;
      this.display.clearMinimap();
      this.display.showLoadingMessage("Loading large map");
      if (!this.coords) {
        this.largeMapTransitioning = false;
        return;
      }
      const me = { lat: this.coords.lat, lng: this.coords.lng };
      this.display.clearLoadingMessage();
      this.renderLargeMap(me);
      this.largeMapTransitioning = false;
      const route = this.trip.routePoints;
      if (route && route.length >= 2 && !this.osmFetchInFlight) {
        const lats = [...route, me].map((p) => p.lat);
        const lngs = [...route, me].map((p) => p.lng);
        const center = {
          lat: (Math.min(...lats) + Math.max(...lats)) / 2,
          lng: (Math.min(...lngs) + Math.max(...lngs)) / 2
        };
        const halfH = haversineMeters2({ lat: Math.min(...lats), lng: center.lng }, { lat: Math.max(...lats), lng: center.lng }) / 2;
        const halfW = haversineMeters2({ lat: center.lat, lng: Math.min(...lngs) }, { lat: center.lat, lng: Math.max(...lngs) }) / 2;
        const fetchRadius = Math.max(halfH, halfW) * 1.3 + 50;
        this.osmFetchInFlight = true;
        fetchOsmRoads(center, fetchRadius).then((roads) => {
          this.osmRoadsCache = roads;
          this.osmRoadsCenter = center;
          if (this.largeMapShown && this.coords) {
            this.renderLargeMap({ lat: this.coords.lat, lng: this.coords.lng });
          }
        }).catch((err) => console.log("[LARGE-MAP] road fetch failed:", err)).finally(() => {
          this.osmFetchInFlight = false;
        });
      }
    }
    renderLargeMap(me) {
      const { w, h } = this.display.getBitmapSize(this.OSM_LARGE_MAP_W, this.OSM_LARGE_MAP_H);
      const route = this.trip.routePoints;
      let center = me;
      let viewRadiusMeters = this.OSM_MINIMAP_RADIUS_M;
      if (route && route.length >= 2) {
        const pts = [...route, me];
        const lats = pts.map((p) => p.lat);
        const lngs = pts.map((p) => p.lng);
        const minLat = Math.min(...lats);
        const maxLat = Math.max(...lats);
        const minLng = Math.min(...lngs);
        const maxLng = Math.max(...lngs);
        center = { lat: (minLat + maxLat) / 2, lng: (minLng + maxLng) / 2 };
        const halfH = haversineMeters2({ lat: minLat, lng: center.lng }, { lat: maxLat, lng: center.lng }) / 2;
        const halfW = haversineMeters2({ lat: center.lat, lng: minLng }, { lat: center.lat, lng: maxLng }) / 2;
        viewRadiusMeters = Math.max(80, Math.max(halfH, halfW) * 1.15);
      }
      const routeBearing = nextSegmentBearing(me, route);
      const markerHeading = this.moveBearingDeg ?? routeBearing ?? this.heading;
      const png = renderOsmLineMap(this.osmRoadsCache ?? [], {
        center,
        width: w,
        height: h,
        viewRadiusMeters,
        lineWidthPx: 2,
        route,
        marker: markerHeading != null ? { at: me, headingDeg: markerHeading } : null
      });
      console.log(`[LARGE-MAP] render: roads=${this.osmRoadsCache?.length ?? 0} routePts=${route?.length ?? 0} radius=${Math.round(viewRadiusMeters)}m size=${w}x${h} png=${png ? png.length + "b" : "NULL"}`);
      if (png)
        this.display.showLargeBitmap(png, w, h);
    }
    refreshHUD() {
      const { status, running, activeDestinationName, maneuver, arrivalSide } = this.trip;
      const me = this.coords ? { lat: this.coords.lat, lng: this.coords.lng } : null;
      const liveDist = maneuver?.maneuverType === "ARRIVE" ? remainingRouteMeters(me, this.trip.routePoints) : liveDistanceToNextTurn(me, this.trip.routePoints, this.trip.routeSteps, remainingRouteMeters, haversineMeters2);
      const md = deriveManeuverDisplay(maneuver, status, liveDist);
      this.audioGuidance.observe({
        status,
        running,
        routeRevision: this.routeRevision,
        pivotIndex: this.upcomingPivot?.index ?? null,
        maneuverType: md?.kind ?? null,
        instruction: md?.instruction ?? null,
        distanceMeters: selectAudioGuidanceDistance(maneuver?.maneuverType, maneuver?.distanceMeters, md?.distanceMeters),
        offRoute: this.offRouteAdvisory,
        destinationName: activeDestinationName,
        arrivalSide,
        travelMode: this.lastStartOpts?.mode ?? "walking",
        unitSystem: this.unitSystem
      });
      if (!this.capabilities.hasDisplay || this.largeMapShown)
        return;
      if (this.capabilities.canPosition)
        this.refreshMinimap();
      let next = null;
      let durationMs;
      let maneuverArrow = null;
      let maneuverBody = null;
      if (status === "arrived") {
        const at = activeDestinationName ? ` at ${activeDestinationName}` : "";
        const side = arrivalSide ? `, on your ${arrivalSide}` : ", up ahead";
        next = `You have arrived${at}${side}`;
        durationMs = 1e4;
      } else if (!running && status !== "rerouting" && !this.hasCompletedTrip) {
        next = `Welcome to Mentra Maps!
Pick a destination to get started.`;
      } else if (status === "rerouting") {
        next = "Rerouting…";
      } else if (this.offRouteAdvisory && running) {
        const d = this.offRouteAdvisoryDistanceM;
        next = d != null ? `Go back
in ${formatDistance(d, this.unitSystem)}` : `Go back
to route`;
      } else if (md) {
        if (md.arriving) {
          maneuverArrow = "↑";
          maneuverBody = md.instruction || "Arriving";
          next = maneuverBody;
        } else {
          const dTurn = liveDist ?? md.distanceMeters;
          const distLine = md.atTurn ? "Now" : dTurn != null ? formatDistance(dTurn, this.unitSystem) : null;
          maneuverArrow = md.arrow || "↑";
          maneuverBody = [distLine, md.instruction].filter(Boolean).join(`
`);
          next = [md.arrow || "↑", distLine, md.instruction].filter(Boolean).join(`
`);
        }
      } else if (running) {
        const startedAt = this.startingShownAt || Date.now();
        if (this.startingShownAt === 0)
          this.startingShownAt = startedAt;
        const stuck = Date.now() - startedAt >= STARTING_WATCHDOG_MS;
        const firstStep = this.firstNavigableStep();
        if (stuck && firstStep) {
          const arrow = arrowFor(firstStep.maneuver, null);
          const onto = isRealRoadName(firstStep.road);
          const dist = firstStep.distanceMeters > 0 ? `In ${formatDistance(firstStep.distanceMeters, this.unitSystem)}` : null;
          next = [arrow, onto ? `Onto ${onto}` : null, dist].filter(Boolean).join(`
`) || `Starting…`;
        } else {
          next = `Starting…`;
        }
      } else {
        this.startingShownAt = 0;
      }
      if (next !== "Starting…")
        this.startingShownAt = 0;
      if (next == null) {
        if (this.lastHudKey !== "") {
          this.lastHudKey = "";
          this.lastArrowKey = "";
          try {
            this.display.clear();
          } catch {}
        }
        return;
      }
      const showStats = running && !(this.offRouteAdvisory && status !== "rerouting" && status !== "arrived");
      const stats = showStats ? this.buildTripStats() : null;
      const clock = this.buildClock();
      if (maneuverBody != null && running && this.capabilities.canPosition) {
        const key2 = `hud|${maneuverArrow}|${maneuverBody}|${stats ?? ""}|${clock}`;
        const nowHud2 = Date.now();
        const unchanged = key2 === this.lastHudKey;
        if (unchanged && nowHud2 - this.lastHudAt <= 3000)
          return;
        const forced = unchanged;
        this.lastHudAt = nowHud2;
        this.lastHudKey = key2;
        const arrowChanged = forced || maneuverArrow !== this.lastArrowKey;
        if (arrowChanged)
          this.lastArrowKey = maneuverArrow ?? "";
        this.display.showNavHud({
          arrowBmp: arrowChanged ? renderManeuverArrowBmp(maneuverArrow) : undefined,
          maneuver: maneuverBody,
          stats: stats ?? "",
          clock
        });
        return;
      }
      const combined = [next, stats].filter(Boolean).join(`

`);
      const displayClock = this.capabilities.canPosition ? clock : null;
      const key = `msg|${combined}${durationMs ?? 0}|${displayClock ?? ""}`;
      const nowHud = Date.now();
      if (key === this.lastHudKey && nowHud - this.lastHudAt <= 3000)
        return;
      this.lastHudAt = nowHud;
      this.lastHudKey = key;
      if (this.capabilities.canPosition) {
        this.display.showNavMessage(combined, displayClock);
      } else {
        this.display.showCompactNavHud(next, stats);
      }
    }
    firstNavigableStep() {
      const steps = this.trip.routeSteps;
      if (!steps || steps.length === 0)
        return null;
      const skip = new Set(["DEPART", "CONTINUE", "STRAIGHT", "NAME_CHANGE"]);
      const turn = steps.find((s) => !skip.has((s.maneuver ?? "").toUpperCase()));
      return turn ?? steps[0];
    }
    buildClock() {
      const now = new Date;
      const hh = String(now.getHours()).padStart(2, "0");
      const mm = String(now.getMinutes()).padStart(2, "0");
      return `${hh}:${mm}`;
    }
    buildTripStats() {
      const me = this.coords ? { lat: this.coords.lat, lng: this.coords.lng } : null;
      const distM = this.trip.maneuver?.distanceToDestinationMeters ?? remainingRouteMeters(me, this.trip.routePoints) ?? undefined;
      if (distM == null || distM < 0)
        return null;
      const etaS = this.trip.maneuver?.timeToDestinationSeconds ?? distM / this.FALLBACK_WALKING_M_PER_S;
      const dist = formatDistance(distM, this.unitSystem);
      return etaS >= 0 ? `${dist}  ${formatDuration(etaS)}` : dist;
    }
    OSM_MINIMAP_SIZE = 100;
    OSM_MINIMAP_RADIUS_M = 133;
    OSM_LARGE_MAP_W = 288;
    OSM_LARGE_MAP_H = 140;
    OSM_REFETCH_THRESHOLD_M = 120;
    FALLBACK_WALKING_M_PER_S = 1.4;
    MINIMAP_MIN_INTERVAL_MS = 300;
    refreshMinimap() {
      if (!this.capabilities.hasDisplay || !this.capabilities.canPosition)
        return;
      if (this.largeMapShown)
        return;
      if (!this.showMinimap)
        return;
      if (!this.trip.running || !this.coords)
        return;
      const now = Date.now();
      const sinceLast = now - this.lastMinimapAt;
      if (!this.forceMinimapPush && sinceLast < this.MINIMAP_MIN_INTERVAL_MS) {
        if (this.minimapTrailingTimer == null) {
          this.minimapTrailingTimer = setTimeout(() => {
            this.minimapTrailingTimer = null;
            this.refreshMinimap();
          }, this.MINIMAP_MIN_INTERVAL_MS - sinceLast);
        }
        return;
      }
      this.lastMinimapAt = now;
      const me = { lat: this.coords.lat, lng: this.coords.lng };
      const movedFar = !this.osmRoadsCenter || haversineMeters2(me, this.osmRoadsCenter) > this.OSM_REFETCH_THRESHOLD_M;
      if (movedFar && !this.osmFetchInFlight) {
        this.osmFetchInFlight = true;
        const fetchCenter = me;
        fetchOsmRoads(fetchCenter, this.OSM_MINIMAP_RADIUS_M * 2).then((roads) => {
          this.osmRoadsCache = roads;
          this.osmRoadsCenter = fetchCenter;
          console.log(`[OSM-MINIMAP] fetched ${roads.length} roads around ${fetchCenter.lat.toFixed(5)},${fetchCenter.lng.toFixed(5)}`);
          this.refreshMinimap();
        }).catch((err) => console.log("[OSM-MINIMAP] fetch failed:", err)).finally(() => {
          this.osmFetchInFlight = false;
        });
      }
      const routeBearing = nextSegmentBearing(me, this.trip.routePoints);
      const markerHeading = this.moveBearingDeg ?? routeBearing ?? this.heading;
      const remainingRoute = remainingRoutePoints(me, this.trip.routePoints);
      const fullRoute = this.trip.routePoints;
      const destination = fullRoute && fullRoute.length > 0 ? fullRoute[fullRoute.length - 1] : null;
      const png = renderOsmLineMap(this.osmRoadsCache ?? [], {
        center: me,
        width: this.OSM_MINIMAP_SIZE,
        height: this.OSM_MINIMAP_SIZE,
        viewRadiusMeters: this.OSM_MINIMAP_RADIUS_M,
        lineWidthPx: 2,
        route: remainingRoute,
        destination,
        rotationDeg: 0,
        marker: markerHeading != null ? { at: me, headingDeg: markerHeading } : null
      });
      const distM = this.trip.maneuver?.distanceToDestinationMeters ?? remainingRouteMeters(me, this.trip.routePoints) ?? undefined;
      const etaS = this.trip.maneuver?.timeToDestinationSeconds ?? (distM != null ? distM / this.FALLBACK_WALKING_M_PER_S : undefined);
      console.log(`[TRIP-STATS] distM=${distM} etaS=${etaS} (will push: ${distM != null && distM >= 0})`);
      if (distM != null && distM >= 0) {
        const distStr = formatDistance(distM, this.unitSystem);
        const etaStr = etaS != null && etaS >= 0 ? `⊙ ${formatDuration(etaS)}` : null;
        const stats = etaStr ? `${distStr} · ${etaStr}` : distStr;
        const now2 = Date.now();
        const changed = stats !== this.lastTripStats;
        const stale = now2 - this.lastTripStatsAt > 3000;
        if (changed || stale) {
          this.lastTripStats = stats;
          this.lastTripStatsAt = now2;
        }
      }
      if (!png || png === this.lastMinimapPng && !this.forceMinimapPush) {
        console.log(`[MINIMAP] skip push (png ${png ? "unchanged" : "null"}, force=${this.forceMinimapPush})`);
        return;
      }
      this.lastMinimapPng = png;
      this.lastMinimapPushAt = Date.now();
      console.log(`[MINIMAP] push bitmap (${png.length} b64 chars, force=${this.forceMinimapPush})`);
      this.display.showBitmap(png);
    }
    minimapWatchdogTick() {
      if (this.largeMapShown || !this.showMinimap) {
        console.log(`[MINIMAP-WATCHDOG] tick skipped (largeMap=${this.largeMapShown} showMinimap=${this.showMinimap})`);
        return;
      }
      if (!this.trip.running || !this.coords) {
        console.log(`[MINIMAP-WATCHDOG] tick skipped (running=${this.trip.running} coords=${!!this.coords})`);
        return;
      }
      const idle = Date.now() - this.lastMinimapPushAt;
      console.log(`[MINIMAP-WATCHDOG] tick: ${idle}ms since last push (threshold ${this.MINIMAP_WATCHDOG_IDLE_MS}ms)`);
      if (idle < this.MINIMAP_WATCHDOG_IDLE_MS)
        return;
      console.log(`[MINIMAP-WATCHDOG] no push for ${idle}ms — forcing refresh`);
      this.forceMinimapPush = true;
      try {
        this.refreshMinimap();
      } finally {
        this.forceMinimapPush = false;
      }
    }
    startMinimapWatchdog() {
      if (!this.capabilities.hasDisplay || !this.capabilities.canPosition)
        return;
      if (this.minimapWatchdogTimer != null)
        return;
      console.log(`[MINIMAP-WATCHDOG] started (every ${this.MINIMAP_WATCHDOG_INTERVAL_MS}ms, idle threshold ${this.MINIMAP_WATCHDOG_IDLE_MS}ms)`);
      this.minimapWatchdogTimer = setInterval(() => this.minimapWatchdogTick(), this.MINIMAP_WATCHDOG_INTERVAL_MS);
    }
    stopMinimapWatchdog() {
      if (this.minimapWatchdogTimer == null)
        return;
      clearInterval(this.minimapWatchdogTimer);
      this.minimapWatchdogTimer = null;
    }
    primeNavigationPermission() {
      this.session.waitForReady().then(() => this.navigation.requestPermission()).then((r) => this.appendLog(`requestPermission: ${JSON.stringify(r)}`)).catch((err) => {
        console.warn("[NavigationController] requestPermission failed", err);
      });
    }
    seedInitialFix() {
      this.location.getOnce().then((d) => {
        if (this.coords)
          return;
        this.coords = { lat: d.lat, lng: d.lng, accuracy: d.accuracy, ts: d.timestamp ?? Date.now() };
        this.lastCoordsAt = Date.now();
        this.ui.send("nav:coords", this.coords);
      }).catch(() => {});
    }
    heartbeatLocationIfStale() {
      const STALE_MS = 5000;
      if (this.gettingFix)
        return;
      if (Date.now() - this.lastCoordsAt < STALE_MS)
        return;
      this.gettingFix = true;
      this.location.getOnce().then((d) => {
        this.coords = { lat: d.lat, lng: d.lng, accuracy: d.accuracy, ts: d.timestamp ?? Date.now() };
        this.lastCoordsAt = Date.now();
        this.ui.send("nav:coords", this.coords);
      }).catch(() => {}).finally(() => {
        this.gettingFix = false;
      });
    }
    logOffRouteThresholds() {
      if (!this.coords)
        return;
      const route = this.trip.routePoints;
      if (!route || route.length < 2) {
        this.lastOffRouteBucket = 0;
        this.offRouteAdvisory = false;
        this.offRouteAdvisoryDistanceM = null;
        return;
      }
      const here = { lat: this.coords.lat, lng: this.coords.lng };
      const dist = distanceToPolylineMeters(here, route);
      if (dist == null)
        return;
      const bucket = classifyOffRouteAdvisory(dist, this.offRouteAdvisory) ? 1 : 0;
      const prevDistance = this.offRouteAdvisoryDistanceM;
      this.offRouteAdvisoryDistanceM = bucket === 1 ? dist : null;
      if (bucket === this.lastOffRouteBucket && bucket === 1 && prevDistance != null && Math.round(prevDistance) !== Math.round(dist)) {
        this.refreshHUD();
      }
      if (bucket === this.lastOffRouteBucket)
        return;
      this.lastOffRouteBucket = bucket;
      this.offRouteAdvisory = bucket === 1;
      if (bucket === 0) {
        const msg = `back on route (${dist.toFixed(1)}m) — restoring directions`;
        console.log(`[NavOffRoute] ${msg}`);
        this.appendLog(`[NavOffRoute] ${msg}`);
        this.refreshHUD();
      } else {
        const msg = `> ${OFF_ROUTE_ADVISORY_M}m off route (${dist.toFixed(1)}m) — go back / awaiting native reroute`;
        console.log(`[NavOffRoute] ${msg}`);
        this.appendLog(`[NavOffRoute] ${msg}`);
        this.refreshHUD();
      }
    }
    maybeFireEarlyArrival() {
      const ARRIVAL_REMAINING_M = 7;
      const ARRIVAL_NEAR_ROUTE_END_M = 15;
      const ARRIVAL_NEAR_PIN_M = 15;
      const ARRIVAL_NEAR_END_M = 40;
      if (!this.coords)
        return;
      if (this.trip.status === "arrived" || !this.trip.running)
        return;
      const route = this.trip.routePoints;
      const me = { lat: this.coords.lat, lng: this.coords.lng };
      if (!Number.isFinite(me.lat) || !Number.isFinite(me.lng))
        return;
      if (!route || route.length < 2 || route.some((p) => !Number.isFinite(p.lat) || !Number.isFinite(p.lng)))
        return;
      const remaining = remainingRouteMeters(me, route);
      if (remaining == null || !Number.isFinite(remaining))
        return;
      const dest = this.trip.activeDestination;
      const straightLineToPin = dest ? haversineMeters2(me, dest) : null;
      const straightLineToRouteEnd = haversineMeters2(me, route[route.length - 1]);
      const alongRouteArrived = remaining <= ARRIVAL_REMAINING_M && straightLineToRouteEnd <= ARRIVAL_NEAR_ROUTE_END_M;
      const nearPinArrived = straightLineToPin != null && straightLineToPin <= ARRIVAL_NEAR_PIN_M && remaining <= ARRIVAL_NEAR_END_M;
      if (!alongRouteArrived && !nearPinArrived)
        return;
      const side = sideOfFinalSegment(route, this.trip.activeDestination);
      const why = alongRouteArrived ? `${remaining.toFixed(1)}m of route remaining` : `${straightLineToPin?.toFixed(1)}m from pin, ${remaining.toFixed(1)}m route left`;
      this.appendLog(`ARRIVED (early, ${why})`);
      this.trip = {
        ...this.trip,
        status: "arrived",
        running: false,
        maneuver: null,
        activeDestination: null,
        routePoints: null,
        routeSteps: null,
        offRouteAt: null,
        arrivalSide: side
      };
      this.hasCompletedTrip = true;
      this.activePivot = null;
      this.upcomingPivot = null;
      this.cancelPendingRebuild();
      this.tripStartCoords = null;
      this.lastStartOpts = null;
      this.lastAutoRebuildAt = 0;
      this.lastOffRouteBucket = 0;
      this.offRouteAdvisory = false;
      this.offRouteAdvisoryDistanceM = null;
      this.cachedInstructions = null;
      try {
        this.navigation.stop();
      } catch {}
      this.exitLargeMap();
      this.ui.send("nav:trip-state", this.trip);
    }
    cancelPendingRebuild() {
      if (this.pendingRebuildTimer) {
        clearTimeout(this.pendingRebuildTimer);
        this.pendingRebuildTimer = null;
      }
    }
    appendLog(line) {
      const entry = { id: ++this.logSeq, ts: Date.now(), line };
      this.log = [entry, ...this.log].slice(0, 100);
      this.ui.send("nav:log-append", entry);
    }
    lookupRawInstructionForPivot(pivot) {
      const steps = this.trip.routeSteps;
      if (!steps || steps.length === 0)
        return null;
      const EPS = 0.00001;
      for (const s of steps) {
        if (Math.abs(s.lat - pivot.lat) < EPS && Math.abs(s.lng - pivot.lng) < EPS) {
          return s.instruction || null;
        }
      }
      return null;
    }
    async refetchInstructionsForLiveRoute(expectedStepCount) {
      if (this.refetchingInstructions)
        return;
      const origin = this.coords ? { lat: this.coords.lat, lng: this.coords.lng } : null;
      const dest = this.trip.activeDestination;
      if (!origin || !dest)
        return;
      this.refetchingInstructions = true;
      try {
        const res = await this.navigation.computeRoute({
          origin,
          stops: [dest],
          mode: this.lastStartOpts?.mode ?? "walking"
        });
        const steps = res.routes?.[0]?.steps;
        if (!steps || steps.length === 0)
          return;
        this.cachedInstructions = steps.map((s) => cleanInstruction(s.instruction));
        const live = this.trip.routeSteps;
        if (live && live.length > 0) {
          const merged = live.map((s, i) => ({
            ...s,
            instruction: this.cachedInstructions && i < this.cachedInstructions.length ? this.cachedInstructions[i] || null : null
          }));
          this.trip = { ...this.trip, routeSteps: merged };
          this.ui.send("nav:route", { points: this.trip.routePoints ?? [], steps: merged });
          this.ui.send("nav:trip-state", this.trip);
          this.refreshHUD();
        }
        if (steps.length !== expectedStepCount) {
          this.appendLog(`raw-instructions: refetch step count ${steps.length} ≠ live ${expectedStepCount}`);
        }
      } catch (err) {
        this.appendLog(`raw-instructions refetch failed: ${err instanceof Error ? err.message : String(err)}`);
      } finally {
        this.refetchingInstructions = false;
      }
    }
    formatUpdate(u) {
      switch (u.kind) {
        case "maneuver":
          return `MANEUVER ${u.maneuverType} dist=${u.distanceMeters.toFixed(0)}m`;
        case "off_route":
          return `OFF_ROUTE ${Math.round(u.offRouteDistanceMeters)}m off`;
        case "rerouting":
          return "REROUTING";
        case "arrived":
          return "ARRIVED";
        case "error":
          return `ERROR ${u.message}`;
        default:
          return `UPDATE ${u.kind ?? "?"}`;
      }
    }
    buildSnapshot() {
      return {
        coords: this.coords,
        heading: this.heading,
        trip: this.trip,
        activePivot: this.activePivot,
        upcomingPivot: this.upcomingPivot,
        log: [...this.log],
        devSettings: this.devSettings,
        unitSystem: this.unitSystem,
        voiceGuidanceMode: this.voiceGuidanceMode,
        capabilities: this.capabilities
      };
    }
    loadUnitSystem() {
      this.storage.getUnitSystem().then((unit) => {
        if (unit === this.unitSystem)
          return;
        this.unitSystem = unit;
        this.ui.send("nav:units-update", { unitSystem: unit });
        this.refreshHUD();
      }).catch((err) => {
        this.appendLog(`unit-system load failed: ${err instanceof Error ? err.message : String(err)}`);
      });
    }
    dispose() {
      this.audioGuidance.dispose();
      this.cancelPendingRebuild();
      this.stopMinimapWatchdog();
      if (this.minimapTrailingTimer != null) {
        clearTimeout(this.minimapTrailingTimer);
        this.minimapTrailingTimer = null;
      }
      try {
        this.navigation.stop();
      } catch {}
      if (this.capabilities.hasDisplay) {
        try {
          this.display.clear();
        } catch {}
      }
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs = [];
    }
  }
  function isRealRoadName(s) {
    if (!s)
      return null;
    if (/^Pivot \d+$/i.test(s))
      return null;
    return s;
  }
  function arrowFor(maneuver, direction) {
    const m = (maneuver ?? "").toUpperCase();
    if (m.includes("LEFT"))
      return "←";
    if (m.includes("RIGHT"))
      return "→";
    if (direction === "left")
      return "←";
    if (direction === "right")
      return "→";
    return "↑";
  }
  var MODES = new Set(["walking", "driving", "cycling", "two_wheeler"]);
  var PIVOT_RADIUS_M_WALKING = 14;
  function withPivotDefaults(opts) {
    return {
      ...opts,
      pivots: {
        radiusMeters: PIVOT_RADIUS_M_WALKING,
        ...opts.pivots ?? {}
      }
    };
  }
  var OFF_ROUTE_ADVISORY_M = 20;
  var OFF_ROUTE_RECOVERY_M = 15;
  function classifyOffRouteAdvisory(distanceMeters, advisoryActive) {
    return advisoryActive ? distanceMeters >= OFF_ROUTE_RECOVERY_M : distanceMeters >= OFF_ROUTE_ADVISORY_M;
  }
  var STARTING_WATCHDOG_MS = 6000;
  function cleanInstruction(raw) {
    if (!raw)
      return "";
    return raw.replace(/\s*[|.]?\s*(?:your\s+)?destination will be on the (left|right)\s*\.?\s*$/i, "").trim();
  }
  function logLiveRoute(route) {
    const steps = route.steps ?? [];
    const polyline = route.points ?? [];
    const annotated = steps.map((s, i) => ({ stepIdx: i, name: s.road ?? null }));
    const roads = [];
    for (const a of annotated) {
      if (!a.name)
        continue;
      if (roads.length > 0 && roads[roads.length - 1].toLowerCase() === a.name.toLowerCase())
        continue;
      roads.push(a.name);
    }
    console.log(`[NavLive] roads: ${roads.join(" → ")}`);
    console.log(`[NavLive] resolution:
` + annotated.map((a) => `  step ${a.stepIdx} → ${a.name ?? "(none)"}`).join(`
`));
    console.log(`[NavLive] steps:
` + steps.map((s, i) => `  step ${i}: ${s.road ?? "(unnamed)"} | ${s.maneuver ?? "—"} | ${s.distanceMeters}m`).join(`
`));
    const stride = Math.max(1, Math.ceil(polyline.length / 30));
    const sampled = polyline.filter((_, i) => i % stride === 0 || i === polyline.length - 1);
    console.log(`[NavLive] polyline (${polyline.length} pts, showing ${sampled.length}):
` + sampled.map((p, i) => `  ${i}: ${p.lat.toFixed(5)}, ${p.lng.toFixed(5)}`).join(`
`));
    const turns = [];
    for (let i = 0;i < annotated.length - 1; i++) {
      const here = annotated[i];
      const next = annotated[i + 1];
      if (!here.name || !next.name)
        continue;
      if (here.name.toLowerCase() === next.name.toLowerCase())
        continue;
      const junction = steps[here.stepIdx];
      turns.push(`  ${turns.length}: ${here.name} → ${next.name} @ (${junction.lat.toFixed(5)}, ${junction.lng.toFixed(5)})`);
    }
    console.log(`[NavLive] turns (${turns.length}):
${turns.join(`
`)}`);
  }

  // src/background/index.ts
  registerMiniapp((session) => {
    new NavigationController(session).start();
  });
})();
