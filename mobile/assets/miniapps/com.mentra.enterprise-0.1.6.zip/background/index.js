(() => {
  var __create = Object.create;
  var __getProtoOf = Object.getPrototypeOf;
  var __defProp = Object.defineProperty;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  function __accessProp(key) {
    return this[key];
  }
  var __toESMCache_node;
  var __toESMCache_esm;
  var __toESM = (mod, isNodeMode, target) => {
    var canCache = mod != null && typeof mod === "object";
    if (canCache) {
      var cache = isNodeMode ? __toESMCache_node ??= new WeakMap : __toESMCache_esm ??= new WeakMap;
      var cached = cache.get(mod);
      if (cached)
        return cached;
    }
    target = mod != null ? __create(__getProtoOf(mod)) : {};
    const to = isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target;
    for (let key of __getOwnPropNames(mod))
      if (!__hasOwnProp.call(to, key))
        __defProp(to, key, {
          get: __accessProp.bind(mod, key),
          enumerable: true
        });
    if (canCache)
      cache.set(mod, to);
    return to;
  };
  var __commonJS = (cb, mod) => () => (mod || cb((mod = { exports: {} }).exports, mod), mod.exports);
  var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
    get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
  }) : x)(function(x) {
    if (typeof require !== "undefined")
      return require.apply(this, arguments);
    throw Error('Dynamic require of "' + x + '" is not supported');
  });

  // ../node_modules/eventemitter3/index.js
  var require_eventemitter3 = __commonJS((exports, module) => {
    var has = Object.prototype.hasOwnProperty;
    var prefix = "~";
    function Events() {}
    if (Object.create) {
      Events.prototype = Object.create(null);
      if (!new Events().__proto__)
        prefix = false;
    }
    function EE(fn, context, once) {
      this.fn = fn;
      this.context = context;
      this.once = once || false;
    }
    function addListener(emitter, event, fn, context, once) {
      if (typeof fn !== "function") {
        throw new TypeError("The listener must be a function");
      }
      var listener = new EE(fn, context || emitter, once), evt = prefix ? prefix + event : event;
      if (!emitter._events[evt])
        emitter._events[evt] = listener, emitter._eventsCount++;
      else if (!emitter._events[evt].fn)
        emitter._events[evt].push(listener);
      else
        emitter._events[evt] = [emitter._events[evt], listener];
      return emitter;
    }
    function clearEvent(emitter, evt) {
      if (--emitter._eventsCount === 0)
        emitter._events = new Events;
      else
        delete emitter._events[evt];
    }
    function EventEmitter() {
      this._events = new Events;
      this._eventsCount = 0;
    }
    EventEmitter.prototype.eventNames = function eventNames() {
      var names = [], events, name;
      if (this._eventsCount === 0)
        return names;
      for (name in events = this._events) {
        if (has.call(events, name))
          names.push(prefix ? name.slice(1) : name);
      }
      if (Object.getOwnPropertySymbols) {
        return names.concat(Object.getOwnPropertySymbols(events));
      }
      return names;
    };
    EventEmitter.prototype.listeners = function listeners(event) {
      var evt = prefix ? prefix + event : event, handlers = this._events[evt];
      if (!handlers)
        return [];
      if (handlers.fn)
        return [handlers.fn];
      for (var i = 0, l = handlers.length, ee = new Array(l);i < l; i++) {
        ee[i] = handlers[i].fn;
      }
      return ee;
    };
    EventEmitter.prototype.listenerCount = function listenerCount(event) {
      var evt = prefix ? prefix + event : event, listeners = this._events[evt];
      if (!listeners)
        return 0;
      if (listeners.fn)
        return 1;
      return listeners.length;
    };
    EventEmitter.prototype.emit = function emit(event, a1, a2, a3, a4, a5) {
      var evt = prefix ? prefix + event : event;
      if (!this._events[evt])
        return false;
      var listeners = this._events[evt], len = arguments.length, args, i;
      if (listeners.fn) {
        if (listeners.once)
          this.removeListener(event, listeners.fn, undefined, true);
        switch (len) {
          case 1:
            return listeners.fn.call(listeners.context), true;
          case 2:
            return listeners.fn.call(listeners.context, a1), true;
          case 3:
            return listeners.fn.call(listeners.context, a1, a2), true;
          case 4:
            return listeners.fn.call(listeners.context, a1, a2, a3), true;
          case 5:
            return listeners.fn.call(listeners.context, a1, a2, a3, a4), true;
          case 6:
            return listeners.fn.call(listeners.context, a1, a2, a3, a4, a5), true;
        }
        for (i = 1, args = new Array(len - 1);i < len; i++) {
          args[i - 1] = arguments[i];
        }
        listeners.fn.apply(listeners.context, args);
      } else {
        var length = listeners.length, j;
        for (i = 0;i < length; i++) {
          if (listeners[i].once)
            this.removeListener(event, listeners[i].fn, undefined, true);
          switch (len) {
            case 1:
              listeners[i].fn.call(listeners[i].context);
              break;
            case 2:
              listeners[i].fn.call(listeners[i].context, a1);
              break;
            case 3:
              listeners[i].fn.call(listeners[i].context, a1, a2);
              break;
            case 4:
              listeners[i].fn.call(listeners[i].context, a1, a2, a3);
              break;
            default:
              if (!args)
                for (j = 1, args = new Array(len - 1);j < len; j++) {
                  args[j - 1] = arguments[j];
                }
              listeners[i].fn.apply(listeners[i].context, args);
          }
        }
      }
      return true;
    };
    EventEmitter.prototype.on = function on(event, fn, context) {
      return addListener(this, event, fn, context, false);
    };
    EventEmitter.prototype.once = function once(event, fn, context) {
      return addListener(this, event, fn, context, true);
    };
    EventEmitter.prototype.removeListener = function removeListener(event, fn, context, once) {
      var evt = prefix ? prefix + event : event;
      if (!this._events[evt])
        return this;
      if (!fn) {
        clearEvent(this, evt);
        return this;
      }
      var listeners = this._events[evt];
      if (listeners.fn) {
        if (listeners.fn === fn && (!once || listeners.once) && (!context || listeners.context === context)) {
          clearEvent(this, evt);
        }
      } else {
        for (var i = 0, events = [], length = listeners.length;i < length; i++) {
          if (listeners[i].fn !== fn || once && !listeners[i].once || context && listeners[i].context !== context) {
            events.push(listeners[i]);
          }
        }
        if (events.length)
          this._events[evt] = events.length === 1 ? events[0] : events;
        else
          clearEvent(this, evt);
      }
      return this;
    };
    EventEmitter.prototype.removeAllListeners = function removeAllListeners(event) {
      var evt;
      if (event) {
        evt = prefix ? prefix + event : event;
        if (this._events[evt])
          clearEvent(this, evt);
      } else {
        this._events = new Events;
        this._eventsCount = 0;
      }
      return this;
    };
    EventEmitter.prototype.off = EventEmitter.prototype.removeListener;
    EventEmitter.prototype.addListener = EventEmitter.prototype.on;
    EventEmitter.prefixed = prefix;
    EventEmitter.EventEmitter = EventEmitter;
    if (typeof module !== "undefined") {
      module.exports = EventEmitter;
    }
  });
  // ../node_modules/eventemitter3/index.mjs
  var import__ = __toESM(require_eventemitter3(), 1);

  // ../vendor/miniapp/dist/envelope.js
  function serializeEnvelope(envelope) {
    return JSON.stringify(envelope);
  }
  function parseEnvelope(raw) {
    if (typeof raw !== "string")
      return null;
    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch {
      return null;
    }
    if (typeof parsed !== "object" || parsed === null)
      return null;
    const obj = parsed;
    if (typeof obj.payload !== "object" || obj.payload === null)
      return null;
    if (obj.requestId !== undefined && typeof obj.requestId !== "string")
      return null;
    return {
      payload: obj.payload,
      requestId: obj.requestId
    };
  }
  function makeRequestId() {
    if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
      return crypto.randomUUID();
    }
    return `req_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
  }

  // ../vendor/miniapp/dist/globals.js
  function getMentraOSGlobals() {
    if (typeof window === "undefined")
      return {};
    return window.MentraOS ?? {};
  }

  // ../vendor/miniapp/dist/protocol.js
  var MiniappRequestType;
  (function(MiniappRequestType2) {
    MiniappRequestType2["CONNECT"] = "miniapp_connect";
    MiniappRequestType2["AUTH_REFRESH"] = "miniapp_auth_refresh";
    MiniappRequestType2["SUBSCRIBE"] = "miniapp_subscribe";
    MiniappRequestType2["DISPLAY"] = "miniapp_display";
    MiniappRequestType2["RENDER"] = "miniapp_render";
    MiniappRequestType2["PLAY_AUDIO"] = "miniapp_play_audio";
    MiniappRequestType2["STOP_AUDIO"] = "miniapp_stop_audio";
    MiniappRequestType2["SPEAK"] = "miniapp_speak";
    MiniappRequestType2["SPEAKER_STREAM_OPEN"] = "miniapp_speaker_stream_open";
    MiniappRequestType2["SPEAKER_STREAM_WRITE"] = "miniapp_speaker_stream_write";
    MiniappRequestType2["SPEAKER_STREAM_CLOSE"] = "miniapp_speaker_stream_close";
    MiniappRequestType2["SPEAKER_STREAM_ABORT"] = "miniapp_speaker_stream_abort";
    MiniappRequestType2["RGB_LED"] = "miniapp_rgb_led";
    MiniappRequestType2["LOCATION_POLL"] = "miniapp_location_poll";
    MiniappRequestType2["CALENDAR_LIST_EVENTS"] = "miniapp_calendar_list_events";
    MiniappRequestType2["NAVIGATION_START"] = "miniapp_navigation_start";
    MiniappRequestType2["NAVIGATION_STOP"] = "miniapp_navigation_stop";
    MiniappRequestType2["NAVIGATION_DEVIATE"] = "miniapp_navigation_deviate";
    MiniappRequestType2["NAVIGATION_SET_WRONG_SIDEWALK"] = "miniapp_navigation_set_wrong_sidewalk";
    MiniappRequestType2["NAVIGATION_SET_SKIP_CROSSINGS"] = "miniapp_navigation_set_skip_crossings";
    MiniappRequestType2["NAVIGATION_GET_STATE"] = "miniapp_navigation_get_state";
    MiniappRequestType2["NAVIGATION_COMPUTE_ROUTE"] = "miniapp_navigation_compute_route";
    MiniappRequestType2["NAVIGATION_REVERSE_GEOCODE"] = "miniapp_navigation_reverse_geocode";
    MiniappRequestType2["NAVIGATION_PLACE_AUTOCOMPLETE"] = "miniapp_navigation_place_autocomplete";
    MiniappRequestType2["NAVIGATION_PLACE_DETAILS"] = "miniapp_navigation_place_details";
    MiniappRequestType2["NAVIGATION_REQUEST_PERMISSION"] = "miniapp_navigation_request_permission";
    MiniappRequestType2["STORAGE_GET"] = "miniapp_storage_get";
    MiniappRequestType2["STORAGE_SET"] = "miniapp_storage_set";
    MiniappRequestType2["STORAGE_DELETE"] = "miniapp_storage_delete";
    MiniappRequestType2["STORAGE_LIST"] = "miniapp_storage_list";
    MiniappRequestType2["STORAGE_CLEAR"] = "miniapp_storage_clear";
    MiniappRequestType2["STORAGE_HAS"] = "miniapp_storage_has";
    MiniappRequestType2["STORAGE_GET_ALL"] = "miniapp_storage_get_all";
    MiniappRequestType2["STORAGE_SET_MULTIPLE"] = "miniapp_storage_set_multiple";
    MiniappRequestType2["STORAGE_FLUSH"] = "miniapp_storage_flush";
    MiniappRequestType2["CAMERA_FOV"] = "miniapp_camera_fov";
    MiniappRequestType2["CAMERA_WARM_UP"] = "miniapp_camera_warm_up";
    MiniappRequestType2["IMU_SET_ENABLED"] = "miniapp_imu_set_enabled";
    MiniappRequestType2["MIC_SET_VAD_ENABLED"] = "miniapp_mic_set_vad_enabled";
    MiniappRequestType2["MIC_SET_LOUDNESS_GATE_ENABLED"] = "miniapp_mic_set_loudness_gate_enabled";
    MiniappRequestType2["SET_WIFI_ADB_STATE"] = "miniapp_set_wifi_adb_state";
    MiniappRequestType2["SHARE"] = "miniapp_share";
    MiniappRequestType2["OPEN_URL"] = "miniapp_open_url";
    MiniappRequestType2["COPY_CLIPBOARD"] = "miniapp_copy_clipboard";
    MiniappRequestType2["DOWNLOAD"] = "miniapp_download";
    MiniappRequestType2["SCAN_QR"] = "miniapp_scan_qr";
    MiniappRequestType2["BLOB_CREATE"] = "miniapp_blob_create";
    MiniappRequestType2["BLOB_WRITE"] = "miniapp_blob_write";
    MiniappRequestType2["BLOB_COMMIT"] = "miniapp_blob_commit";
    MiniappRequestType2["BLOB_ABORT"] = "miniapp_blob_abort";
    MiniappRequestType2["BLOB_GET"] = "miniapp_blob_get";
    MiniappRequestType2["BLOB_LIST"] = "miniapp_blob_list";
    MiniappRequestType2["BLOB_DELETE"] = "miniapp_blob_delete";
    MiniappRequestType2["BLOB_CLEAR"] = "miniapp_blob_clear";
    MiniappRequestType2["BLOB_USAGE"] = "miniapp_blob_usage";
    MiniappRequestType2["BLOB_OPEN_READ"] = "miniapp_blob_open_read";
    MiniappRequestType2["BLOB_READ"] = "miniapp_blob_read";
    MiniappRequestType2["BLOB_CLOSE_READ"] = "miniapp_blob_close_read";
    MiniappRequestType2["BLOB_SET_FROM_URL"] = "miniapp_blob_set_from_url";
    MiniappRequestType2["BLOB_IMPORT"] = "miniapp_blob_import";
    MiniappRequestType2["BLOB_SHARE"] = "miniapp_blob_share";
    MiniappRequestType2["PING"] = "miniapp_ping";
    MiniappRequestType2["TRANSCRIPTION_CONFIG"] = "miniapp_transcription_config";
    MiniappRequestType2["DASHBOARD_CONTENT_UPDATE"] = "miniapp_dashboard_content_update";
    MiniappRequestType2["PHOTO"] = "miniapp_photo";
    MiniappRequestType2["VIDEO_RECORDING_START"] = "miniapp_video_recording_start";
    MiniappRequestType2["VIDEO_RECORDING_STOP"] = "miniapp_video_recording_stop";
    MiniappRequestType2["STREAM_START"] = "miniapp_stream_start";
    MiniappRequestType2["STREAM_STOP"] = "miniapp_stream_stop";
    MiniappRequestType2["MANAGED_STREAM_START"] = "miniapp_managed_stream_start";
    MiniappRequestType2["MANAGED_STREAM_STOP"] = "miniapp_managed_stream_stop";
    MiniappRequestType2["REQUEST_WIFI_SETUP"] = "miniapp_request_wifi_setup";
    MiniappRequestType2["MINIAPPS_LIST"] = "miniapp_apps_list";
    MiniappRequestType2["MINIAPPS_START"] = "miniapp_apps_start";
    MiniappRequestType2["MINIAPPS_STOP"] = "miniapp_apps_stop";
    MiniappRequestType2["ACTION_INVOKE"] = "miniapp_action_invoke";
    MiniappRequestType2["ACTION_RESULT"] = "miniapp_action_result";
    MiniappRequestType2["MEETING_JOIN"] = "miniapp_meeting_join";
    MiniappRequestType2["MEETING_LEAVE"] = "miniapp_meeting_leave";
    MiniappRequestType2["MEETING_END"] = "miniapp_meeting_end";
    MiniappRequestType2["MEETING_SET_MUTED"] = "miniapp_meeting_set_muted";
    MiniappRequestType2["MEETING_UPDATE_VIDEO_SOURCE"] = "miniapp_meeting_update_video_source";
    MiniappRequestType2["MEETING_GET_STATE"] = "miniapp_meeting_get_state";
  })(MiniappRequestType || (MiniappRequestType = {}));
  var MiniappResponseType;
  (function(MiniappResponseType2) {
    MiniappResponseType2["CONNECT_ACK"] = "miniapp_connect_ack";
    MiniappResponseType2["EVENT"] = "miniapp_event";
    MiniappResponseType2["REQUEST_RESULT"] = "miniapp_request_result";
    MiniappResponseType2["CAPABILITIES_UPDATE"] = "miniapp_capabilities_update";
    MiniappResponseType2["VISIBILITY_CHANGE"] = "miniapp_visibility_change";
    MiniappResponseType2["COLOR_SCHEME_CHANGE"] = "miniapp_color_scheme_change";
    MiniappResponseType2["SPEAKER_STATE"] = "miniapp_speaker_state";
    MiniappResponseType2["PERMISSIONS_UPDATE"] = "miniapp_permissions_update";
    MiniappResponseType2["AUTH_UPDATE"] = "miniapp_auth_update";
    MiniappResponseType2["PONG"] = "miniapp_pong";
    MiniappResponseType2["ACTION_CALL"] = "miniapp_action_call";
    MiniappResponseType2["MEETING_STATE"] = "miniapp_meeting_state";
    MiniappResponseType2["WILL_DISCONNECT"] = "miniapp_will_disconnect";
    MiniappResponseType2["ERROR"] = "miniapp_error";
  })(MiniappResponseType || (MiniappResponseType = {}));
  var MiniappStreamType;
  (function(MiniappStreamType2) {
    MiniappStreamType2["BUTTON_PRESS"] = "button_press";
    MiniappStreamType2["TOUCH_EVENT"] = "touch_event";
    MiniappStreamType2["HEAD_POSITION"] = "head_position";
    MiniappStreamType2["ACCEL_DATA"] = "accel_data";
    MiniappStreamType2["GLASSES_BATTERY"] = "glasses_battery";
    MiniappStreamType2["PHONE_BATTERY"] = "phone_battery";
    MiniappStreamType2["GLASSES_CONNECTION"] = "glasses_connection";
    MiniappStreamType2["GLASSES_WIFI"] = "glasses_wifi";
    MiniappStreamType2["TRANSCRIPTION"] = "transcription";
    MiniappStreamType2["TRANSLATION"] = "translation";
    MiniappStreamType2["AUDIO_CHUNK"] = "audio_chunk";
    MiniappStreamType2["VAD"] = "vad";
    MiniappStreamType2["LOCATION_UPDATE"] = "location_update";
    MiniappStreamType2["HEADING_UPDATE"] = "heading_update";
    MiniappStreamType2["NAVIGATION_UPDATE"] = "navigation_update";
    MiniappStreamType2["NAVIGATION_ROUTE"] = "navigation_route";
    MiniappStreamType2["PHONE_NOTIFICATION"] = "phone_notification";
    MiniappStreamType2["PHONE_NOTIFICATION_DISMISSED"] = "phone_notification_dismissed";
    MiniappStreamType2["PHOTO_TAKEN"] = "photo_taken";
    MiniappStreamType2["STREAM_STATUS"] = "stream_status";
  })(MiniappStreamType || (MiniappStreamType = {}));
  var MiniappErrorCode;
  (function(MiniappErrorCode2) {
    MiniappErrorCode2["INVALID_ARGUMENT"] = "INVALID_ARGUMENT";
    MiniappErrorCode2["PERMISSION_NOT_DECLARED"] = "PERMISSION_NOT_DECLARED";
    MiniappErrorCode2["PERMISSION_DENIED"] = "PERMISSION_DENIED";
    MiniappErrorCode2["NOT_IMPLEMENTED"] = "NOT_IMPLEMENTED";
    MiniappErrorCode2["REQUEST_ABORTED"] = "REQUEST_ABORTED";
    MiniappErrorCode2["INTERNAL"] = "INTERNAL";
    MiniappErrorCode2["TTS_TEXT_TOO_LONG"] = "TTS_TEXT_TOO_LONG";
    MiniappErrorCode2["TTS_INVALID_VOICE"] = "TTS_INVALID_VOICE";
    MiniappErrorCode2["TTS_UPSTREAM_ERROR"] = "TTS_UPSTREAM_ERROR";
    MiniappErrorCode2["TTS_LOCAL_UNAVAILABLE"] = "TTS_LOCAL_UNAVAILABLE";
    MiniappErrorCode2["NOT_CONNECTED"] = "NOT_CONNECTED";
    MiniappErrorCode2["NOT_PERMITTED"] = "NOT_PERMITTED";
    MiniappErrorCode2["APP_NOT_FOUND"] = "APP_NOT_FOUND";
    MiniappErrorCode2["APP_NOT_COMPATIBLE"] = "APP_NOT_COMPATIBLE";
    MiniappErrorCode2["ACTION_NOT_FOUND"] = "ACTION_NOT_FOUND";
    MiniappErrorCode2["NO_ACTION_HANDLER"] = "NO_ACTION_HANDLER";
    MiniappErrorCode2["WAKE_FAILED"] = "WAKE_FAILED";
    MiniappErrorCode2["ACTION_TIMEOUT"] = "ACTION_TIMEOUT";
    MiniappErrorCode2["PAYLOAD_TOO_LARGE"] = "PAYLOAD_TOO_LARGE";
    MiniappErrorCode2["BLOB_NOT_FOUND"] = "BLOB_NOT_FOUND";
    MiniappErrorCode2["BLOB_QUOTA_EXCEEDED"] = "BLOB_QUOTA_EXCEEDED";
    MiniappErrorCode2["BLOB_TOO_LARGE"] = "BLOB_TOO_LARGE";
    MiniappErrorCode2["BLOB_HANDLE_INVALID"] = "BLOB_HANDLE_INVALID";
    MiniappErrorCode2["BLOB_WRITE_FAILED"] = "BLOB_WRITE_FAILED";
    MiniappErrorCode2["BLOB_DOWNLOAD_FAILED"] = "BLOB_DOWNLOAD_FAILED";
    MiniappErrorCode2["BLOB_IMPORT_FAILED"] = "BLOB_IMPORT_FAILED";
  })(MiniappErrorCode || (MiniappErrorCode = {}));

  // ../vendor/miniapp/dist/transport/dispatch.js
  class DispatchTransport {
    constructor() {
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.open_ = false;
    }
    static isAvailable() {
      return typeof globalThis.__dispatch === "function";
    }
    async open() {
      if (!DispatchTransport.isAvailable()) {
        throw new Error("DispatchTransport: __dispatch is not installed on globalThis");
      }
      const g = globalThis;
      g.__mentraDeliverBridgeRaw = (raw) => {
        if (this.messageHandler)
          this.messageHandler(raw);
      };
      this.open_ = true;
    }
    send(raw) {
      if (!this.open_) {
        throw new Error("DispatchTransport: send() before open()");
      }
      const g = globalThis;
      if (typeof g.__dispatch !== "function") {
        this.open_ = false;
        this.disconnectHandler?.("DispatchTransport: __dispatch disappeared");
        return;
      }
      try {
        g.__dispatch("__bridge", "send", JSON.stringify([raw]));
      } catch (e) {
        this.disconnectHandler?.(`DispatchTransport: __dispatch threw: ${String(e)}`);
      }
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      this.open_ = false;
      const g = globalThis;
      if (g.__mentraDeliverBridgeRaw) {
        delete g.__mentraDeliverBridgeRaw;
      }
    }
    isOpen() {
      return this.open_;
    }
  }

  // ../vendor/miniapp/dist/transport/local-socket.js
  var DEFAULT_URL = "ws://127.0.0.1:8765";

  class LocalSocketTransport {
    constructor(options = {}) {
      this.ws = null;
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.url = options.url ?? DEFAULT_URL;
    }
    async open() {
      if (this.ws && this.ws.readyState === WebSocket.OPEN)
        return;
      if (typeof WebSocket === "undefined") {
        throw new Error("LocalSocketTransport: browser WebSocket global not available");
      }
      await new Promise((resolve, reject) => {
        const ws = new WebSocket(this.url);
        let settled = false;
        const settle = (fn) => {
          if (settled)
            return;
          settled = true;
          fn();
        };
        ws.onopen = () => {
          this.ws = ws;
          settle(() => resolve());
        };
        ws.onerror = (ev) => {
          settle(() => reject(new Error(`LocalSocketTransport: failed to connect to ${this.url}: ${String(ev)}`)));
        };
        ws.onmessage = (ev) => {
          const data = ev.data;
          if (typeof data === "string")
            this.messageHandler?.(data);
        };
        ws.onclose = (ev) => {
          if (this.ws === ws)
            this.ws = null;
          this.disconnectHandler?.(`closed: ${ev.code} ${ev.reason}`);
        };
      });
    }
    send(raw) {
      if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
        throw new Error("LocalSocketTransport: not connected");
      }
      this.ws.send(raw);
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      if (!this.ws)
        return;
      try {
        this.ws.close();
      } catch {}
      this.ws = null;
    }
    isOpen() {
      return !!this.ws && this.ws.readyState === WebSocket.OPEN;
    }
  }

  // ../vendor/miniapp/dist/transport/mock.js
  var LOG_PREFIX = "[mock-transport]";
  function isMockExplicitlyRequested() {
    if (typeof window === "undefined")
      return false;
    try {
      if (typeof window.location !== "undefined" && window.location.search) {
        const params = new URLSearchParams(window.location.search);
        if (params.get("mentra") === "mock")
          return true;
      }
    } catch {}
    try {
      if (typeof localStorage !== "undefined" && localStorage.getItem("MENTRA_MOCK") === "1") {
        return true;
      }
    } catch {}
    return false;
  }

  class MockTransport {
    constructor(options = {}) {
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.open_ = false;
      this.userId = options.userId ?? "mock-user";
      this.authToken = options.authToken ?? "mock-miniapp-token";
      this.packageName = options.packageName ?? null;
      this.silent = options.silent === true;
      this.configuration = { ...options.configuration ?? {} };
    }
    async open() {
      if (this.open_)
        return;
      this.open_ = true;
      this.log("transport opened (no real host; synthetic responses only)");
    }
    send(raw) {
      if (!this.open_) {
        throw new Error("MockTransport: send() before open()");
      }
      const envelope = parseEnvelope(raw);
      if (!envelope) {
        this.log("dropped unparseable envelope:", raw.slice(0, 200));
        return;
      }
      const payload = envelope.payload;
      const type = payload?.type;
      this.log(`recv ${type ?? "<unknown>"}${envelope.requestId ? ` (rid=${envelope.requestId})` : ""}`);
      switch (type) {
        case MiniappRequestType.CONNECT:
          this.deliverConnectAck(payload);
          return;
        case MiniappRequestType.PING:
          return;
        case MiniappRequestType.SUBSCRIBE:
          return;
        default:
          if (envelope.requestId) {
            this.deliverSyntheticResult(envelope.requestId, type ?? "<unknown>", payload);
          }
          return;
      }
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      if (!this.open_)
        return;
      this.open_ = false;
      this.disconnectHandler?.("MockTransport.close()");
    }
    isOpen() {
      return this.open_;
    }
    deliverConnectAck(connectPayload) {
      const incomingPackage = connectPayload.packageName ?? this.packageName ?? "com.mock.app";
      const ackPayload = {
        type: MiniappResponseType.CONNECT_ACK,
        userId: this.userId,
        packageName: incomingPackage,
        capabilities: null,
        visibility: "foreground",
        colorScheme: "light",
        configuration: { ...this.configuration },
        auth: {
          mentraUserId: this.userId,
          oemId: "mock",
          token: this.authToken,
          expiresAt: Date.now() + 60 * 60 * 1000
        }
      };
      const envelope = { payload: ackPayload };
      this.log(`-> CONNECT_ACK userId=${this.userId} pkg=${incomingPackage}`);
      queueMicrotask(() => this.messageHandler?.(serializeEnvelope(envelope)));
    }
    deliverSyntheticResult(requestId, requestType, requestPayload) {
      const data = syntheticDataFor(requestId, requestType, requestPayload);
      const responsePayload = {
        type: MiniappResponseType.REQUEST_RESULT,
        ok: true,
        data
      };
      const envelope = { payload: responsePayload, requestId };
      this.log(`-> REQUEST_RESULT (rid=${requestId}) synthetic ${requestType}`);
      queueMicrotask(() => this.messageHandler?.(serializeEnvelope(envelope)));
    }
    log(...args) {
      if (this.silent)
        return;
      console.log(LOG_PREFIX, ...args);
    }
  }
  function syntheticDataFor(requestId, requestType, requestPayload) {
    switch (requestType) {
      case MiniappRequestType.CAMERA_FOV: {
        const presetFov = requestPayload.preset === "narrow" ? 82 : requestPayload.preset === "wide" ? 118 : requestPayload.preset === "standard" ? 102 : undefined;
        const fov = typeof requestPayload.fov === "number" ? requestPayload.fov : presetFov ?? 102;
        const roi = requestPayload.roiPosition;
        const roiPosition = roi === "bottom" ? "bottom" : roi === "top" ? "top" : "center";
        return {
          requestId,
          fov,
          roiPosition,
          timestamp: Date.now()
        };
      }
      case MiniappRequestType.PHOTO:
        return {
          photoUrl: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkAAIAAAoAAv/lxKUAAAAASUVORK5CYII=",
          requestId: "mock-photo"
        };
      case MiniappRequestType.RGB_LED:
        return { type: "rgb_led_control_response", state: "success", requestId };
      case MiniappRequestType.LOCATION_POLL:
        return { lat: 37.7956, lng: -122.3933, accuracy: 0, timestamp: Date.now() };
      case MiniappRequestType.CALENDAR_LIST_EVENTS:
        return { events: [], truncated: false };
      case MiniappRequestType.STORAGE_GET:
        return { value: null };
      case MiniappRequestType.STORAGE_LIST:
        return { keys: [] };
      case MiniappRequestType.SPEAK:
        return { audioUrl: null, durationMs: 0 };
      case MiniappRequestType.SHARE:
      case MiniappRequestType.OPEN_URL:
      case MiniappRequestType.COPY_CLIPBOARD:
      case MiniappRequestType.DOWNLOAD:
      case MiniappRequestType.REQUEST_WIFI_SETUP:
      case MiniappRequestType.SET_WIFI_ADB_STATE:
        return { ok: true };
      case MiniappRequestType.SCAN_QR:
        return { cancelled: true };
      default:
        return null;
    }
  }

  // ../vendor/miniapp/dist/transport/postmessage.js
  class PostMessageTransport {
    constructor() {
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.open_ = false;
      this.windowListener = null;
    }
    async open() {
      if (this.open_)
        return;
      if (typeof window === "undefined" || !window.ReactNativeWebView) {
        throw new Error("PostMessageTransport: not running inside a React Native WebView");
      }
      this.windowListener = (ev) => {
        const data = ev.data;
        if (typeof data !== "string")
          return;
        this.messageHandler?.(data);
      };
      window.addEventListener("message", this.windowListener);
      if (typeof document !== "undefined") {
        document.addEventListener("message", this.windowListener);
      }
      window.receiveNativeMessage = (raw) => {
        this.messageHandler?.(raw);
      };
      this.open_ = true;
    }
    send(raw) {
      if (typeof window === "undefined" || !window.ReactNativeWebView) {
        throw new Error("PostMessageTransport: not running inside a React Native WebView");
      }
      window.ReactNativeWebView.postMessage(raw);
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      if (!this.open_)
        return;
      this.open_ = false;
      if (this.windowListener) {
        window.removeEventListener("message", this.windowListener);
        if (typeof document !== "undefined") {
          document.removeEventListener("message", this.windowListener);
        }
        this.windowListener = null;
      }
      if (typeof window !== "undefined" && window.receiveNativeMessage) {
        window.receiveNativeMessage = undefined;
      }
      this.disconnectHandler?.("closed");
    }
    isOpen() {
      return this.open_;
    }
  }

  // ../vendor/miniapp/dist/transport/auto.js
  var LOCAL_SOCKET_OPEN_TIMEOUT_MS = 500;
  function createTransport(options = {}) {
    if (options.transport)
      return options.transport;
    if (DispatchTransport.isAvailable()) {
      return new DispatchTransport;
    }
    if (typeof window !== "undefined" && window.ReactNativeWebView) {
      return new PostMessageTransport;
    }
    if (isMockExplicitlyRequested()) {
      return new MockTransport;
    }
    if (typeof WebSocket !== "undefined") {
      const localSocketOptions = {};
      if (options.localSocketUrl)
        localSocketOptions.url = options.localSocketUrl;
      return new LocalSocketWithMockFallback(localSocketOptions);
    }
    return new MockTransport;
  }

  class LocalSocketWithMockFallback {
    constructor(options) {
      this.options = options;
      this.active = null;
      this.messageHandler = null;
      this.disconnectHandler = null;
    }
    async open() {
      const local = new LocalSocketTransport(this.options);
      let timedOut = false;
      const timeout = new Promise((_, reject) => {
        setTimeout(() => {
          timedOut = true;
          reject(new Error("LocalSocketTransport open timed out"));
        }, LOCAL_SOCKET_OPEN_TIMEOUT_MS);
      });
      try {
        await Promise.race([local.open(), timeout]);
        this.active = local;
      } catch {
        try {
          local.close();
        } catch {}
        const mock = new MockTransport;
        await mock.open();
        this.active = mock;
        console.log(timedOut ? "[mentra-miniapp] No phone WebSocket reachable; using MockTransport so the page can render." : "[mentra-miniapp] LocalSocketTransport failed; using MockTransport.");
      }
      if (this.messageHandler)
        this.active.onMessage(this.messageHandler);
      if (this.disconnectHandler)
        this.active.onDisconnect(this.disconnectHandler);
    }
    send(raw) {
      if (!this.active)
        throw new Error("LocalSocketWithMockFallback: send() before open()");
      this.active.send(raw);
    }
    onMessage(handler) {
      this.messageHandler = handler;
      this.active?.onMessage(handler);
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
      this.active?.onDisconnect(handler);
    }
    close() {
      this.active?.close();
    }
    isOpen() {
      return this.active?.isOpen() === true;
    }
  }

  // ../vendor/miniapp/dist/modules/camera.js
  class CameraModule {
    constructor(session) {
      this.session = session;
    }
    get hasPermission() {
      return this.session._hasManifestPermission("CAMERA");
    }
    async setFov(request) {
      return this.session.sendRequest({
        type: MiniappRequestType.CAMERA_FOV,
        ...request
      });
    }
    async takePhoto(options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.PHOTO,
        size: options.size ?? "medium",
        mode: options.mode ?? "photo",
        ...options.transferMethod !== undefined ? { transferMethod: options.transferMethod } : {},
        compress: options.compress ?? "none",
        sound: options.sound ?? true,
        saveToGallery: options.saveToGallery ?? false,
        exposureTimeNs: options.exposureTimeNs,
        iso: options.iso,
        aeExposureDivisor: options.aeExposureDivisor,
        isoCap: options.isoCap,
        noiseReduction: options.noiseReduction,
        edgeEnhancement: options.edgeEnhancement,
        zsl: options.zsl,
        mfnr: options.mfnr,
        ispDigitalGain: options.ispDigitalGain,
        ispAnalogGain: options.ispAnalogGain
      }, options.timeoutMs != null ? { timeoutMs: options.timeoutMs } : undefined);
    }
    async warmUp(options = {}) {
      await this.session.sendRequest({
        type: MiniappRequestType.CAMERA_WARM_UP,
        size: options.size ?? "medium",
        mode: options.mode ?? "photo",
        exposureTimeNs: options.exposureTimeNs,
        durationMs: options.durationMs ?? 15000,
        zsl: options.zsl,
        mfnr: options.mfnr
      });
    }
    async startVideoRecording(options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.VIDEO_RECORDING_START,
        width: options.width,
        height: options.height,
        fps: options.fps,
        sound: options.sound ?? true,
        save: options.save ?? false
      });
    }
    async stopVideoRecording(recordingId, options = {}) {
      await this.session.sendRequest({
        type: MiniappRequestType.VIDEO_RECORDING_STOP,
        recordingId,
        uploadUrl: options.uploadUrl,
        uploadAuthToken: options.uploadAuthToken
      });
    }
  }

  // ../vendor/miniapp/dist/modules/auth.js
  var DEFAULT_MIN_TTL_MS = 30000;

  class AuthModule {
    constructor(session) {
      this.session = session;
    }
    get current() {
      return this.session._getAuth();
    }
    get mentraUserId() {
      return this.current?.mentraUserId ?? null;
    }
    get oemId() {
      return this.current?.oemId ?? null;
    }
    async getToken(options = {}) {
      const auth = await this.session._waitForAuth(options.minTtlMs ?? DEFAULT_MIN_TTL_MS);
      return auth.token;
    }
    async getAuthHeader(options = {}) {
      return `Bearer ${await this.getToken(options)}`;
    }
    async fetch(input, init = {}) {
      const { minTtlMs, ...requestInit } = init;
      const token = await this.getToken({ minTtlMs });
      const headers = mergeHeaders(requestInit.headers, { Authorization: `Bearer ${token}` });
      return fetch(input, { ...requestInit, headers });
    }
    onUpdate(handler) {
      return this.session.on("auth", handler);
    }
  }
  function mergeHeaders(base, next) {
    const headers = {};
    if (Array.isArray(base)) {
      for (const [key, value] of base) {
        headers[key] = value;
      }
    } else if (typeof Headers !== "undefined" && base instanceof Headers) {
      base.forEach((value, key) => {
        headers[key] = value;
      });
    } else if (base && typeof base === "object") {
      for (const [key, value] of Object.entries(base)) {
        if (typeof value === "string")
          headers[key] = value;
      }
    }
    return { ...headers, ...next };
  }

  // ../vendor/miniapp/dist/modules/cloud.js
  var CLOUD_STATUS_STREAM = "_cloud_status";
  var DEFAULT_STATUS = {
    status: "disconnected",
    audioTransport: "none"
  };
  function normalizeCloudStatus(data) {
    if (!data || typeof data !== "object")
      return null;
    const raw = data;
    const status = raw.status;
    const audioTransport = raw.audioTransport;
    if (status !== "connected" && status !== "connecting" && status !== "reconnecting" && status !== "disconnected") {
      return null;
    }
    if (audioTransport !== "udp" && audioTransport !== "ws" && audioTransport !== "offline" && audioTransport !== "none") {
      return null;
    }
    return { status, audioTransport };
  }

  class CloudModule {
    constructor(session) {
      this.session = session;
      this.emitter = new import__.default;
      this.current = { ...DEFAULT_STATUS };
      this.session._subscribe(CLOUD_STATUS_STREAM, (data) => {
        const next = normalizeCloudStatus(data);
        if (!next)
          return;
        if (next.status === this.current.status && next.audioTransport === this.current.audioTransport)
          return;
        this.current = next;
        this.emitter.emit("status", { ...this.current });
      });
    }
    get status() {
      return { ...this.current };
    }
    get connected() {
      return this.current.status === "connected";
    }
    isConnected() {
      return this.connected;
    }
    onStatusChanged(handler) {
      handler({ ...this.current });
      this.emitter.on("status", handler);
      return () => {
        this.emitter.off("status", handler);
      };
    }
  }

  // ../vendor/miniapp/dist/modules/configuration.js
  class MiniappConfigurationError extends Error {
    constructor(key) {
      super(`Required miniapp configuration is missing: ${key}`);
      this.key = key;
      this.name = "MiniappConfigurationError";
    }
  }

  class ConfigurationModule {
    constructor(session) {
      this.session = session;
    }
    async get(key) {
      await this.session.waitForReady();
      const configuration = this.session._getConfiguration();
      return Object.prototype.hasOwnProperty.call(configuration, key) ? configuration[key] : undefined;
    }
    async require(key) {
      const value = await this.get(key);
      if (value === undefined)
        throw new MiniappConfigurationError(key);
      return value;
    }
    async getAll() {
      await this.session.waitForReady();
      return Object.assign(Object.create(null), this.session._getConfiguration());
    }
  }

  // ../vendor/miniapp/dist/modules/dashboard.js
  class DashboardAPI {
    constructor(session) {
      this.session = session;
      this.warned = false;
    }
    setContent(mode, content) {
      if (!this.warned) {
        console.warn("[@mentra/miniapp] dashboard.setContent() is deferred in v1.");
        this.warned = true;
      }
      this.session.sendOneShot({
        type: MiniappRequestType.DASHBOARD_CONTENT_UPDATE,
        mode,
        content
      });
    }
  }

  // ../vendor/miniapp/dist/modules/display.js
  class DisplayManager {
    constructor(session) {
      this.session = session;
    }
    render(elements, options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.RENDER,
        view: options.view ?? "main",
        elements,
        durationMs: options.durationMs
      }).catch((err) => ({
        status: "blocked",
        reason: typeof err === "object" && err !== null && "message" in err ? String(err.message) : String(err)
      }));
    }
  }

  // ../vendor/miniapp/dist/modules/events.js
  class EventManager {
    constructor(session) {
      this.session = session;
      this.emitter = new import__.default;
      this.refCounts = new Map;
      this.forceLocalRefCounts = new Map;
    }
    subscribe(stream, handler, options = {}) {
      const isInternal = stream.startsWith("_");
      const forceLocal = options.forceLocal === true && stream.startsWith(`${MiniappStreamType.TRANSCRIPTION}:`);
      const listener = (data, route) => {
        if (stream.startsWith(`${MiniappStreamType.TRANSCRIPTION}:`)) {
          if (forceLocal ? route !== "forceLocal" && route !== "all" : route === "forceLocal")
            return;
        }
        handler(data);
      };
      this.emitter.on(stream, listener);
      if (!isInternal) {
        const before = this.refCounts.get(stream) ?? 0;
        this.refCounts.set(stream, before + 1);
        const forceLocalBefore = this.forceLocalRefCounts.get(stream) ?? 0;
        const defaultBefore = before - forceLocalBefore;
        if (forceLocal)
          this.forceLocalRefCounts.set(stream, forceLocalBefore + 1);
        if (before === 0 || forceLocal && forceLocalBefore === 0 || !forceLocal && defaultBefore === 0) {
          this.sendSubscriptionUpdate();
        }
      }
      return () => {
        this.emitter.off(stream, listener);
        if (isInternal)
          return;
        const current = this.refCounts.get(stream) ?? 0;
        const forceLocalCurrent = this.forceLocalRefCounts.get(stream) ?? 0;
        let subscriptionChanged = current <= 1;
        if (current <= 1) {
          this.refCounts.delete(stream);
        } else {
          this.refCounts.set(stream, current - 1);
        }
        if (forceLocal) {
          if (forceLocalCurrent <= 1) {
            this.forceLocalRefCounts.delete(stream);
            subscriptionChanged = true;
          } else {
            this.forceLocalRefCounts.set(stream, forceLocalCurrent - 1);
          }
        } else if (current - forceLocalCurrent <= 1) {
          subscriptionChanged = true;
        }
        if (subscriptionChanged)
          this.sendSubscriptionUpdate();
      };
    }
    unsubscribeAll() {
      this.emitter.removeAllListeners();
      this.refCounts.clear();
      this.forceLocalRefCounts.clear();
      this.sendSubscriptionUpdate();
    }
    _forwardEvent(stream, data, transcriptionRoute) {
      this.emitter.emit(stream, data, transcriptionRoute);
      if (stream.startsWith("transcription:") && stream !== "transcription:auto") {
        this.emitter.emit("transcription:auto", data, transcriptionRoute);
      } else if (stream.startsWith("translation:")) {
        const parts = stream.split(":");
        const patterns = new Set(["translation:auto"]);
        if (parts.length === 3) {
          const [, source, target] = parts;
          patterns.add("translation:*:*");
          patterns.add(`translation:*:${target}`);
          patterns.add(`translation:${source}:*`);
        }
        patterns.delete(stream);
        for (const pattern of patterns) {
          this.emitter.emit(pattern, data);
        }
      }
    }
    sendSubscriptionUpdate() {
      const subscriptions = Array.from(this.refCounts.keys()).map((stream) => {
        if (stream === MiniappStreamType.LOCATION_UPDATE)
          return { stream: "location_stream", rate: "realtime" };
        const forceLocalRefs = this.forceLocalRefCounts.get(stream) ?? 0;
        if (forceLocalRefs === 0)
          return stream;
        const totalRefs = this.refCounts.get(stream) ?? 0;
        return {
          stream,
          forceLocal: true,
          ...totalRefs > forceLocalRefs ? { includeCloud: true } : {}
        };
      });
      this.session.sendOneShot({
        type: MiniappRequestType.SUBSCRIBE,
        subscriptions
      });
    }
  }

  // ../vendor/miniapp/dist/modules/glasses.js
  class GlassesModule {
    constructor(session) {
      this.session = session;
    }
    onBattery(handler) {
      return this.session._subscribe(MiniappStreamType.GLASSES_BATTERY, handler);
    }
    onConnection(handler) {
      return this.session._subscribe(MiniappStreamType.GLASSES_CONNECTION, handler);
    }
    onWifi(handler) {
      return this.session._subscribe(MiniappStreamType.GLASSES_WIFI, handler);
    }
    async requestWifiSetup(reason) {
      await this.session.sendRequest({
        type: MiniappRequestType.REQUEST_WIFI_SETUP,
        reason
      });
    }
    async setWifiAdbState(enabled) {
      await this.session.sendRequest({
        type: MiniappRequestType.SET_WIFI_ADB_STATE,
        enabled
      });
    }
  }

  // ../vendor/miniapp/dist/modules/heading.js
  class HeadingModule {
    constructor(session) {
      this.session = session;
    }
    get hasPermission() {
      return this.session._hasManifestPermission("LOCATION");
    }
    onUpdate(handler) {
      return this.session._subscribe(MiniappStreamType.HEADING_UPDATE, handler);
    }
  }

  // ../vendor/miniapp/dist/modules/imu.js
  class ImuModule {
    constructor(session) {
      this.session = session;
    }
    onHeadPosition(handler) {
      return this.session._subscribe(MiniappStreamType.HEAD_POSITION, handler);
    }
    onAccel(handler) {
      return this.session._subscribe(MiniappStreamType.ACCEL_DATA, handler);
    }
    setEnabled(enabled) {
      return this.session.sendRequest({
        type: MiniappRequestType.IMU_SET_ENABLED,
        enabled
      });
    }
  }

  // ../vendor/miniapp/dist/modules/input.js
  class InputModule {
    constructor(session) {
      this.session = session;
    }
    onButtonPress(handler) {
      return this.session._subscribe(MiniappStreamType.BUTTON_PRESS, handler);
    }
    onTouch(gestureOrHandler, maybeHandler) {
      if (typeof gestureOrHandler === "function") {
        return this.session._subscribe(MiniappStreamType.TOUCH_EVENT, gestureOrHandler);
      }
      const handler = maybeHandler;
      const gestures = Array.isArray(gestureOrHandler) ? gestureOrHandler : [gestureOrHandler];
      if (gestures.length === 0)
        return () => {};
      const unsubs = [];
      for (const g of gestures) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TOUCH_EVENT}:${g}`, handler));
      }
      return () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
    }
  }

  // ../vendor/miniapp/dist/modules/led.js
  class LedModule {
    constructor(session) {
      this.session = session;
    }
    async turnOn(options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.RGB_LED,
        action: "on",
        color: options.color ?? "red",
        ontime: options.ontime ?? 1000,
        offtime: options.offtime ?? 0,
        count: options.count ?? 1
      });
    }
    async turnOff() {
      return this.session.sendRequest({
        type: MiniappRequestType.RGB_LED,
        action: "off"
      });
    }
    async blink(color, ontime, offtime, count) {
      return this.turnOn({ color, ontime, offtime, count });
    }
    async solid(color, duration) {
      return this.turnOn({ color, ontime: duration, offtime: 0, count: 1 });
    }
  }

  // ../vendor/miniapp/dist/modules/location.js
  class LocationModule {
    constructor(session) {
      this.session = session;
    }
    get hasPermission() {
      return this.session._hasManifestPermission("LOCATION");
    }
    onUpdate(handler) {
      return this.session._subscribe(MiniappStreamType.LOCATION_UPDATE, handler);
    }
    getOnce() {
      return this.session.sendRequest({
        type: MiniappRequestType.LOCATION_POLL
      });
    }
  }

  // ../vendor/miniapp/dist/modules/mic.js
  class MicModule {
    constructor(session) {
      this.session = session;
      this.unsubs = new Set;
    }
    onVoiceActivity(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.VAD, handler));
    }
    onAudioChunk(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.AUDIO_CHUNK, handler));
    }
    setVoiceActivityDetectionEnabled(enabled) {
      return this.session.sendRequest({
        type: MiniappRequestType.MIC_SET_VAD_ENABLED,
        enabled
      });
    }
    setLoudnessGateEnabled(enabled) {
      return this.session.sendRequest({
        type: MiniappRequestType.MIC_SET_LOUDNESS_GATE_ENABLED,
        enabled
      });
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
    get hasPermission() {
      return this.session._hasManifestPermission("MICROPHONE");
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
  }

  // ../vendor/miniapp/dist/modules/pivots/geometry.js
  var TURN_THRESHOLD_DEG = 15;
  var SAME_DIR_MERGE_M = 25;
  var RDP_EPSILON_M = 5;
  var MIN_BEND_PER_POINT_DEG = 10;
  var STRAIGHT_SEGMENT_BREAK_M = 1;
  var INTERSECTION_CLUSTER_M = 30;
  function haversineMeters(a, b) {
    const R = 6371000;
    const toRad = (d) => d * Math.PI / 180;
    const dLat = toRad(b.lat - a.lat);
    const dLng = toRad(b.lng - a.lng);
    const lat1 = toRad(a.lat);
    const lat2 = toRad(b.lat);
    const x = Math.sin(dLat / 2) ** 2 + Math.sin(dLng / 2) ** 2 * Math.cos(lat1) * Math.cos(lat2);
    return 2 * R * Math.asin(Math.sqrt(x));
  }
  function bearingDeg(a, b) {
    const toRad = (d) => d * Math.PI / 180;
    const toDeg = (r) => r * 180 / Math.PI;
    const lat1 = toRad(a.lat);
    const lat2 = toRad(b.lat);
    const dLng = toRad(b.lng - a.lng);
    const y = Math.sin(dLng) * Math.cos(lat2);
    const x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLng);
    return (toDeg(Math.atan2(y, x)) + 360) % 360;
  }
  function signedAngleDiff(target, actual) {
    return (target - actual + 540) % 360 - 180;
  }
  function rdpSimplify(points, epsilonMeters) {
    if (points.length < 3)
      return points.map((_, i) => i);
    const keep = new Array(points.length).fill(false);
    keep[0] = true;
    keep[points.length - 1] = true;
    const stack = [[0, points.length - 1]];
    while (stack.length) {
      const [lo, hi] = stack.pop();
      let maxDist = 0;
      let maxIdx = -1;
      for (let i = lo + 1;i < hi; i++) {
        const d = perpDistMeters(points[i], points[lo], points[hi]);
        if (d > maxDist) {
          maxDist = d;
          maxIdx = i;
        }
      }
      if (maxIdx !== -1 && maxDist > epsilonMeters) {
        keep[maxIdx] = true;
        stack.push([lo, maxIdx], [maxIdx, hi]);
      }
    }
    const out = [];
    for (let i = 0;i < keep.length; i++)
      if (keep[i])
        out.push(i);
    return out;
  }
  function perpDistMeters(p, a, b) {
    const mPerDegLat = 111320;
    const mPerDegLng = 111320 * Math.cos(a.lat * Math.PI / 180);
    const bx = (b.lng - a.lng) * mPerDegLng;
    const by = (b.lat - a.lat) * mPerDegLat;
    const px = (p.lng - a.lng) * mPerDegLng;
    const py = (p.lat - a.lat) * mPerDegLat;
    const dx = bx;
    const dy = by;
    const len = Math.sqrt(dx * dx + dy * dy);
    if (len === 0)
      return Math.sqrt(px * px + py * py);
    return Math.abs(dx * -py - -px * dy) / len;
  }
  function extractPivots(rawPoints) {
    if (rawPoints.length < 3)
      return [];
    const keptIdx = rdpSimplify(rawPoints, RDP_EPSILON_M);
    const simplified = keptIdx.map((i) => rawPoints[i]);
    if (simplified.length < 3)
      return [];
    const deltas = [];
    for (let i = 1;i < simplified.length - 1; i++) {
      const inBearing = bearingDeg(simplified[i - 1], simplified[i]);
      const outBearing = bearingDeg(simplified[i], simplified[i + 1]);
      deltas.push(signedAngleDiff(outBearing, inBearing));
    }
    const candidates = [];
    let runStart = -1;
    let runSum = 0;
    let runSign = 0;
    const flushRun = (endExclusive) => {
      if (runStart === -1)
        return;
      if (Math.abs(runSum) >= TURN_THRESHOLD_DEG) {
        let bestIdx = runStart;
        let bestAbs = 0;
        for (let k = runStart;k < endExclusive; k++) {
          const a = Math.abs(deltas[k]);
          if (a > bestAbs) {
            bestAbs = a;
            bestIdx = k;
          }
        }
        const simplifiedIdx = bestIdx + 1;
        candidates.push({
          lat: simplified[simplifiedIdx].lat,
          lng: simplified[simplifiedIdx].lng,
          direction: runSum > 0 ? "right" : "left",
          simplifiedRouteIndex: simplifiedIdx,
          rawRouteIndex: keptIdx[simplifiedIdx],
          headingDelta: runSum
        });
      }
      runStart = -1;
      runSum = 0;
      runSign = 0;
    };
    let metersSinceLastBend = 0;
    for (let k = 0;k < deltas.length; k++) {
      const d = deltas[k];
      const sign = d > 0 ? 1 : d < 0 ? -1 : 0;
      const segLen = haversineMeters(simplified[k + 1], simplified[k + 2]);
      if (sign === 0 || Math.abs(d) < MIN_BEND_PER_POINT_DEG) {
        if (runStart !== -1) {
          if (sign === runSign || sign === 0)
            runSum += d;
          metersSinceLastBend += segLen;
          if (metersSinceLastBend >= STRAIGHT_SEGMENT_BREAK_M) {
            flushRun(k + 1);
          }
        }
        continue;
      }
      if (runStart === -1) {
        runStart = k;
        runSum = d;
        runSign = sign;
        metersSinceLastBend = segLen;
      } else if (sign === runSign) {
        if (metersSinceLastBend >= STRAIGHT_SEGMENT_BREAK_M) {
          flushRun(k);
          runStart = k;
          runSum = d;
          runSign = sign;
        } else {
          runSum += d;
        }
        metersSinceLastBend = segLen;
      } else {
        flushRun(k);
        runStart = k;
        runSum = d;
        runSign = sign;
        metersSinceLastBend = segLen;
      }
    }
    flushRun(deltas.length);
    const merged = [];
    for (const p of candidates) {
      const last = merged[merged.length - 1];
      if (last && last.direction === p.direction && haversineMeters({ lat: last.lat, lng: last.lng }, { lat: p.lat, lng: p.lng }) < SAME_DIR_MERGE_M) {
        if (Math.abs(p.headingDelta) > Math.abs(last.headingDelta)) {
          merged[merged.length - 1] = p;
        }
        continue;
      }
      merged.push(p);
    }
    const clustered = [];
    for (const p of merged) {
      const last = clustered[clustered.length - 1];
      if (last && haversineMeters({ lat: last.lat, lng: last.lng }, { lat: p.lat, lng: p.lng }) < INTERSECTION_CLUSTER_M) {
        const netDelta = last.headingDelta + p.headingDelta;
        const anchor = Math.abs(p.headingDelta) > Math.abs(last.headingDelta) ? p : last;
        clustered[clustered.length - 1] = {
          ...anchor,
          direction: netDelta > 0 ? "right" : "left",
          headingDelta: netDelta
        };
        continue;
      }
      clustered.push(p);
    }
    return clustered.filter((p) => Math.abs(p.headingDelta) >= TURN_THRESHOLD_DEG);
  }
  function cumulativeDistances(points) {
    const out = new Array(points.length);
    out[0] = 0;
    for (let i = 1;i < points.length; i++) {
      out[i] = out[i - 1] + haversineMeters(points[i - 1], points[i]);
    }
    return out;
  }

  // ../vendor/miniapp/dist/modules/pivots/instructions.js
  var DIRECTION_WORDS = new Set(["right", "left", "the right", "the left", "north", "south", "east", "west"]);
  var MANEUVER_VERBS = /\b(turn|slight|sharp|continue|head|merge|exit|uturn|u-turn|then|keep)\b/i;
  function roadNameFromInstruction(instruction) {
    if (!instruction)
      return null;
    const firstLine = instruction.split(`
`)[0] ?? "";
    const m = firstLine.match(/\bonto\s+(.+)$/i);
    let raw = (m ? m[1] : "").trim();
    if (!raw)
      return null;
    if (raw.includes(","))
      return null;
    raw = raw.split(/\s+(?:toward|towards|to|and|then|for)\b/i)[0]?.trim() ?? "";
    raw = raw.replace(/\s+#.*$/, "").trim();
    if (!raw)
      return null;
    if (DIRECTION_WORDS.has(raw.toLowerCase()))
      return null;
    if (MANEUVER_VERBS.test(raw))
      return null;
    return raw;
  }
  var ROAD_SUFFIXES = /\b(st|street|ave|avenue|blvd|boulevard|rd|road|dr|drive|ln|lane|way|ct|court|pl|place|ter|terrace|hwy|highway)\b\.?/g;
  function normalizeRoad(road) {
    return road.toLowerCase().replace(ROAD_SUFFIXES, "").replace(/[^a-z0-9 ]/g, "").replace(/\s+/g, " ").trim();
  }
  function sameRoad(a, b) {
    return normalizeRoad(a) === normalizeRoad(b);
  }
  function turnDirection(maneuver) {
    if (!maneuver)
      return null;
    const m = maneuver.toUpperCase();
    if (m.includes("LEFT"))
      return "left";
    if (m.includes("RIGHT"))
      return "right";
    return null;
  }
  var PROBE_METERS = 22;
  function signedBendAt(points, junction) {
    if (points.length < 3)
      return null;
    let mid = 0;
    let bestDist = Infinity;
    for (let i = 0;i < points.length; i++) {
      const d = haversineMeters(points[i], junction);
      if (d < bestDist) {
        bestDist = d;
        mid = i;
      }
    }
    let before = mid;
    while (before > 0 && haversineMeters(points[before], points[mid]) < PROBE_METERS)
      before--;
    let after = mid;
    while (after < points.length - 1 && haversineMeters(points[after], points[mid]) < PROBE_METERS)
      after++;
    if (before === mid || after === mid)
      return null;
    const incoming = bearingDeg(points[before], points[mid]);
    const outgoing = bearingDeg(points[mid], points[after]);
    return signedAngleDiff(outgoing, incoming);
  }
  var MIN_TURN_ANGLE_DEG = 30;
  function extractPivotsFromComputedSteps(steps, polyline) {
    if (!steps || steps.length < 2)
      return [];
    const initial = steps.map((s, i) => ({
      stepIdx: i,
      name: s.road ?? roadNameFromInstruction(s.instruction)
    }));
    let annotated = initial;
    for (let pass = 0;pass < 4; pass++) {
      const collapsed = [];
      for (let i = 0;i < annotated.length; i++) {
        const prev = collapsed[collapsed.length - 1];
        const here = annotated[i];
        const next = annotated[i + 1];
        if (prev?.name && next?.name && here.name && !sameRoad(prev.name, here.name) && sameRoad(prev.name, next.name)) {
          continue;
        }
        collapsed.push(here);
      }
      if (collapsed.length === annotated.length)
        break;
      annotated = collapsed;
    }
    const out = [];
    for (let i = 0;i < annotated.length - 1; i++) {
      const here = annotated[i];
      const nextAnn = annotated[i + 1];
      const s = steps[here.stepIdx];
      const next = steps[nextAnn.stepIdx];
      const fromRoad = here.name;
      const toRoad = nextAnn.name;
      if (!fromRoad)
        continue;
      if (toRoad && sameRoad(fromRoad, toRoad))
        continue;
      if (!Number.isFinite(s.endLat) || !Number.isFinite(s.endLng))
        continue;
      const junction = { lat: s.endLat, lng: s.endLng };
      const signedBend = signedBendAt(polyline, junction);
      if (signedBend != null && Math.abs(signedBend) < MIN_TURN_ANGLE_DEG)
        continue;
      const geomDir = signedBend == null ? null : signedBend > 0 ? "right" : "left";
      const direction = geomDir ?? turnDirection(next.maneuver);
      out.push({
        lat: s.endLat,
        lng: s.endLng,
        fromRoad,
        toRoad,
        direction,
        maneuver: next.maneuver ?? (direction === "left" ? "TURN_LEFT" : "TURN_RIGHT")
      });
    }
    return out;
  }

  // ../vendor/miniapp/dist/modules/pivots/engine.js
  var RADIUS_DEFAULTS_M = {
    walking: 7,
    cycling: 15,
    driving: 40,
    two_wheeler: 25
  };
  var APPROACH_DEFAULTS_M = {
    walking: 100,
    cycling: 300,
    driving: 800,
    two_wheeler: 500
  };
  var NON_TURN_MANEUVERS = new Set(["STRAIGHT", "NAME_CHANGE", "DEPART", "ARRIVE"]);
  var STEP_MATCH_MAX_INDEX_DELTA = 8;
  var ON_ROUTE_PERP_TOLERANCE_M = 50;

  class PivotEngine {
    constructor(mode, opts) {
      this.pivots = [];
      this.states = [];
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = [];
      this.cumulative = [];
      this.roadNameResolver = null;
      this.routeGeneration = 0;
      this.subscribers = new Set;
      this.opts = resolveOptions(mode, opts);
    }
    updateOptions(mode, opts) {
      this.opts = resolveOptions(mode, opts);
      for (const p of this.pivots) {
        p.radiusMeters = this.opts.radiusMeters;
      }
    }
    setRoadNameResolver(resolver) {
      this.roadNameResolver = resolver;
    }
    reset() {
      if (this.activePivotIndex !== null) {
        const active = this.pivots[this.activePivotIndex];
        if (active)
          this.emit({ kind: "exited", pivot: active });
      }
      this.pivots = [];
      this.states = [];
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = [];
      this.cumulative = [];
    }
    setRouteFromComputedSteps(route, computedSteps) {
      const points = route.points ?? [];
      if (this.activePivotIndex !== null) {
        const active = this.pivots[this.activePivotIndex];
        if (active)
          this.emit({ kind: "exited", pivot: active });
      }
      if (points.length < 3 || !computedSteps || computedSteps.length < 2) {
        this.setRoute(route, null);
        return;
      }
      const cumulative = cumulativeDistances(points);
      const instructionPivots = extractPivotsFromComputedSteps(computedSteps, points);
      console.log(`[PivotEngine] setRouteFromComputedSteps: steps=${computedSteps.length} instructionPivots=${instructionPivots.length}` + (instructionPivots.length > 0 ? `
` + instructionPivots.map((p, i) => `  pivot[${i}] ${p.fromRoad ?? "—"} → ${p.toRoad ?? "—"} dir=${p.direction} @ (${p.lat.toFixed(5)}, ${p.lng.toFixed(5)})`).join(`
`) : ""));
      if (instructionPivots.length === 0) {
        console.log(`[PivotEngine] falling back to setRoute (geometry) — input steps:
` + computedSteps.map((s, i) => `  step[${i}] road=${s.road ?? "—"} maneuver=${s.maneuver ?? "—"} @ (${s.lat.toFixed(5)}, ${s.lng.toFixed(5)}) → (${s.endLat.toFixed(5)}, ${s.endLng.toFixed(5)})`).join(`
`));
        this.setRoute(route, null);
        return;
      }
      const pivots = instructionPivots.map((p, i) => ({
        index: i,
        lat: p.lat,
        lng: p.lng,
        direction: p.direction === "left" ? "left" : "right",
        fromRoad: p.fromRoad,
        toRoad: p.toRoad,
        maneuver: p.maneuver,
        distanceAlongRouteMeters: alongRouteAtCoord(points, cumulative, { lat: p.lat, lng: p.lng }),
        radiusMeters: this.opts.radiusMeters
      }));
      pivots.sort((a, b) => a.distanceAlongRouteMeters - b.distanceAlongRouteMeters);
      for (let i = 0;i < pivots.length; i++)
        pivots[i].index = i;
      this.pivots = pivots;
      this.states = pivots.map(() => ({ approachingFired: false, entered: false, exited: false }));
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = points;
      this.cumulative = cumulative;
      this.routeGeneration++;
      this._resolveMissingRoadNames(this.routeGeneration);
    }
    setRoute(route, _userPosition) {
      const points = route.points ?? [];
      const steps = route.steps ?? [];
      if (this.activePivotIndex !== null) {
        const active = this.pivots[this.activePivotIndex];
        if (active)
          this.emit({ kind: "exited", pivot: active });
      }
      if (points.length < 3) {
        this.pivots = [];
        this.states = [];
        this.cursor = 0;
        this.activePivotIndex = null;
        this.points = [];
        this.cumulative = [];
        return;
      }
      const cumulative = cumulativeDistances(points);
      const raw = extractPivots(points);
      const stepIndex = buildStepIndex(steps);
      const pivots = [];
      for (let i = 0;i < raw.length; i++) {
        const r = raw[i];
        const matched = matchStep(r, stepIndex);
        if (matched && NON_TURN_MANEUVERS.has(matched.maneuver)) {
          continue;
        }
        pivots.push({
          index: pivots.length,
          lat: r.lat,
          lng: r.lng,
          direction: r.direction,
          fromRoad: matched?.fromRoad ?? null,
          toRoad: matched?.toRoad ?? null,
          maneuver: matched?.maneuver ?? (r.direction === "left" ? "TURN_LEFT" : "TURN_RIGHT"),
          distanceAlongRouteMeters: distanceAtIndex(cumulative, r.rawRouteIndex),
          radiusMeters: this.opts.radiusMeters
        });
      }
      pivots.sort((a, b) => a.distanceAlongRouteMeters - b.distanceAlongRouteMeters);
      for (let i = 0;i < pivots.length; i++)
        pivots[i].index = i;
      this.pivots = pivots;
      this.states = pivots.map(() => ({ approachingFired: false, entered: false, exited: false }));
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = points;
      this.cumulative = cumulative;
      this.routeGeneration++;
      this._resolveMissingRoadNames(this.routeGeneration);
    }
    async _resolveMissingRoadNames(generation) {
      const pivots = this.pivots;
      if (pivots.length === 0)
        return;
      for (let i = 0;i < pivots.length - 1; i++) {
        const here = pivots[i];
        const next = pivots[i + 1];
        if (!here.toRoad && next.fromRoad)
          here.toRoad = next.fromRoad;
        if (!next.fromRoad && here.toRoad)
          next.fromRoad = here.toRoad;
      }
      for (let i = pivots.length - 1;i > 0; i--) {
        const here = pivots[i];
        const prev = pivots[i - 1];
        if (!prev.toRoad && here.fromRoad)
          prev.toRoad = here.fromRoad;
        if (!here.fromRoad && prev.toRoad)
          here.fromRoad = prev.toRoad;
      }
      const resolver = this.roadNameResolver;
      if (!resolver)
        return;
      if (this.points.length < 2)
        return;
      const SAMPLE_OFFSETS_M = [18, 30, 50, 80];
      const points = this.points;
      const cumulative = this.cumulative;
      const geocodeWithExpansion = async (pivotAlong, direction) => {
        for (const offset of SAMPLE_OFFSETS_M) {
          const sample = sampleAlongRoute(points, cumulative, pivotAlong + direction * offset);
          if (!sample)
            continue;
          try {
            const road = await resolver(sample);
            if (generation !== this.routeGeneration)
              return null;
            if (road)
              return road;
          } catch {}
        }
        return null;
      };
      const tasks = [];
      for (const pivot of pivots) {
        if (pivot.fromRoad && pivot.toRoad)
          continue;
        const along = pivot.distanceAlongRouteMeters;
        if (!pivot.fromRoad) {
          tasks.push(geocodeWithExpansion(along, -1).then((road) => {
            if (generation !== this.routeGeneration)
              return;
            if (road && !pivot.fromRoad)
              pivot.fromRoad = road;
          }));
        }
        if (!pivot.toRoad) {
          tasks.push(geocodeWithExpansion(along, 1).then((road) => {
            if (generation !== this.routeGeneration)
              return;
            if (road && !pivot.toRoad)
              pivot.toRoad = road;
          }));
        }
      }
      await Promise.all(tasks);
      if (generation !== this.routeGeneration)
        return;
      for (let i = 0;i < pivots.length - 1; i++) {
        const here = pivots[i];
        const next = pivots[i + 1];
        if (!here.toRoad && next.fromRoad)
          here.toRoad = next.fromRoad;
        if (!next.fromRoad && here.toRoad)
          next.fromRoad = here.toRoad;
      }
    }
    onLocationUpdate(coords) {
      if (this.pivots.length === 0)
        return;
      const projection = projectOntoPolyline(this.points, this.cumulative, coords);
      const useAlongPath = projection !== null && projection.perpMeters <= ON_ROUTE_PERP_TOLERANCE_M;
      const userAlong = projection?.alongMeters ?? 0;
      for (let i = this.cursor;i < this.pivots.length; i++) {
        const pivot = this.pivots[i];
        const state = this.states[i];
        if (state.exited)
          continue;
        const aheadDelta = pivot.distanceAlongRouteMeters - userAlong;
        const distanceToPivot = useAlongPath ? Math.abs(aheadDelta) : haversineMeters(coords, { lat: pivot.lat, lng: pivot.lng });
        const approaching = !state.approachingFired && distanceToPivot <= this.opts.approachThresholdMeters && (!useAlongPath || aheadDelta >= -this.opts.radiusMeters);
        if (approaching) {
          state.approachingFired = true;
          this.emit({ kind: "approaching", pivot, distanceMeters: distanceToPivot });
        }
        if (!state.entered && distanceToPivot <= pivot.radiusMeters) {
          state.entered = true;
          this.activePivotIndex = i;
          this.emit({ kind: "entered", pivot });
        }
        const movedPastOnPath = useAlongPath && aheadDelta < -pivot.radiusMeters;
        if ((state.entered && distanceToPivot > pivot.radiusMeters || !state.entered && movedPastOnPath) && !state.exited) {
          if (!state.entered) {
            state.entered = true;
            this.activePivotIndex = i;
            this.emit({ kind: "entered", pivot });
          }
          state.exited = true;
          if (this.activePivotIndex === i)
            this.activePivotIndex = null;
          this.emit({ kind: "exited", pivot });
          if (this.cursor <= i)
            this.cursor = i + 1;
        }
        if (!state.approachingFired && distanceToPivot > this.opts.approachThresholdMeters * 2) {
          break;
        }
      }
    }
    subscribe(fn) {
      this.subscribers.add(fn);
      return () => {
        this.subscribers.delete(fn);
      };
    }
    getPivots() {
      return this.pivots.slice();
    }
    getActivePivot() {
      if (this.activePivotIndex === null)
        return null;
      return this.pivots[this.activePivotIndex] ?? null;
    }
    getUpcomingPivot() {
      for (let i = this.cursor;i < this.pivots.length; i++) {
        if (!this.states[i].exited)
          return this.pivots[i];
      }
      return null;
    }
    emit(event) {
      for (const fn of this.subscribers) {
        try {
          fn(event);
        } catch (err) {
          console.error("[PivotEngine] subscriber threw:", err);
        }
      }
    }
  }
  function resolveOptions(mode, opts) {
    return {
      radiusMeters: opts?.radiusMeters ?? RADIUS_DEFAULTS_M[mode] ?? RADIUS_DEFAULTS_M.walking,
      approachThresholdMeters: opts?.approachThresholdMeters ?? APPROACH_DEFAULTS_M[mode] ?? APPROACH_DEFAULTS_M.walking
    };
  }
  function projectOntoPolyline(points, cumulative, user) {
    if (points.length < 2 || cumulative.length !== points.length)
      return null;
    const mPerDegLat = 111320;
    const mPerDegLng = 111320 * Math.cos(user.lat * Math.PI / 180);
    const ux = user.lng * mPerDegLng;
    const uy = user.lat * mPerDegLat;
    let bestPerp = Number.POSITIVE_INFINITY;
    let bestAlong = 0;
    for (let i = 0;i < points.length - 1; i++) {
      const a = points[i];
      const b = points[i + 1];
      const ax = a.lng * mPerDegLng;
      const ay = a.lat * mPerDegLat;
      const bx = b.lng * mPerDegLng;
      const by = b.lat * mPerDegLat;
      const dx = bx - ax;
      const dy = by - ay;
      const segLen2 = dx * dx + dy * dy;
      const t = segLen2 > 0 ? Math.max(0, Math.min(1, ((ux - ax) * dx + (uy - ay) * dy) / segLen2)) : 0;
      const px = ax + t * dx;
      const py = ay + t * dy;
      const perp = Math.hypot(ux - px, uy - py);
      if (perp < bestPerp) {
        bestPerp = perp;
        const segLen = Math.sqrt(segLen2);
        bestAlong = cumulative[i] + t * segLen;
      }
    }
    if (!Number.isFinite(bestPerp))
      return null;
    return { perpMeters: bestPerp, alongMeters: bestAlong };
  }
  function alongRouteAtCoord(points, cumulative, coord) {
    const projection = projectOntoPolyline(points, cumulative, coord);
    return projection?.alongMeters ?? 0;
  }
  function sampleAlongRoute(points, cumulative, targetMeters) {
    if (points.length < 2 || cumulative.length !== points.length)
      return null;
    const total = cumulative[cumulative.length - 1];
    if (!Number.isFinite(targetMeters))
      return null;
    if (targetMeters <= 0)
      return { lat: points[0].lat, lng: points[0].lng };
    if (targetMeters >= total) {
      const last = points[points.length - 1];
      return { lat: last.lat, lng: last.lng };
    }
    let lo = 0;
    let hi = cumulative.length - 1;
    while (lo + 1 < hi) {
      const mid = lo + hi >>> 1;
      if (cumulative[mid] <= targetMeters)
        lo = mid;
      else
        hi = mid;
    }
    const segStart = cumulative[lo];
    const segEnd = cumulative[hi];
    const segLen = segEnd - segStart;
    const t = segLen > 0 ? (targetMeters - segStart) / segLen : 0;
    const a = points[lo];
    const b = points[hi];
    return { lat: a.lat + (b.lat - a.lat) * t, lng: a.lng + (b.lng - a.lng) * t };
  }
  function distanceAtIndex(cumulative, idx) {
    if (cumulative.length === 0)
      return 0;
    if (idx < 0)
      return 0;
    if (idx >= cumulative.length)
      return cumulative[cumulative.length - 1];
    return cumulative[idx];
  }
  function buildStepIndex(steps) {
    if (!steps.length)
      return [];
    return steps.slice().sort((a, b) => a.routeIndex - b.routeIndex);
  }
  function matchStep(raw, stepIndex) {
    if (stepIndex.length < 2)
      return null;
    let bestJ = -1;
    let bestDelta = Number.POSITIVE_INFINITY;
    for (let i = 1;i < stepIndex.length; i++) {
      const delta = Math.abs(stepIndex[i].routeIndex - raw.rawRouteIndex);
      if (delta <= bestDelta) {
        bestDelta = delta;
        bestJ = i;
      }
    }
    if (bestJ < 1)
      return null;
    if (bestDelta > STEP_MATCH_MAX_INDEX_DELTA)
      return null;
    const SHORT_TRANSIT_METERS = 25;
    const finalIndex = stepIndex.length - 1;
    let j = bestJ;
    while (j < finalIndex - 1 && stepIndex[j].distanceMeters > 0 && stepIndex[j].distanceMeters < SHORT_TRANSIT_METERS) {
      j++;
    }
    if (j >= finalIndex)
      j = finalIndex - 1;
    const fromStep = stepIndex[bestJ - 1];
    const toStep = stepIndex[j];
    return {
      fromRoad: fromStep.road ?? null,
      toRoad: toStep.road ?? null,
      maneuver: fromStep.maneuver
    };
  }

  // ../vendor/miniapp/dist/modules/navigation.js
  class NavigationModule {
    constructor(session) {
      this.session = session;
      this._pivots = new PivotEngine("walking", undefined);
      this._tripUnsubs = [];
      this._tripStops = null;
      this._tripMode = "walking";
      this._tripAvoid = undefined;
      this._computeRouteSeq = 0;
      this._lastUserPosition = null;
      this._pivots.setRoadNameResolver(async (coord) => {
        try {
          const result = await this.reverseGeocodeRoad(coord);
          if (!result.ok)
            return null;
          return result.road ?? null;
        } catch {
          return null;
        }
      });
    }
    get hasPermission() {
      return this.session._hasManifestPermission("LOCATION");
    }
    requestPermission() {
      if (!this.hasPermission) {
        return Promise.resolve({
          ok: false,
          accepted: false,
          error: "LOCATION permission not declared in miniapp.json (required for navigation.requestPermission)."
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_REQUEST_PERMISSION
      });
    }
    async start(opts) {
      if (!this.hasPermission) {
        return {
          ok: false,
          error: "LOCATION permission not declared in miniapp.json (required for navigation.start)."
        };
      }
      const stops = normalizeStops(opts);
      const mode = opts.mode ?? "driving";
      this._tripStops = stops.length > 0 ? stops : null;
      this._tripMode = mode;
      this._tripAvoid = opts.avoid;
      this._attachPivotTrackingForTrip(mode, opts.pivots);
      const failStart = (error) => {
        this._detachPivotTracking();
        return { ok: false, error };
      };
      if (stops.length === 0) {
        return failStart("navigation.start: no stops");
      }
      let origin = this._lastUserPosition;
      if (!origin) {
        try {
          const fix = await this.session.location.getOnce();
          origin = { lat: fix.lat, lng: fix.lng };
          this._lastUserPosition = origin;
        } catch (err) {
          return failStart(`navigation.start: no GPS fix (${err instanceof Error ? err.message : String(err)})`);
        }
      }
      const restResult = await this.computeRoute({ origin, stops, mode, avoid: opts.avoid });
      if (!restResult.ok || !restResult.routes || restResult.routes.length === 0) {
        return failStart(restResult.error ?? "computeRoute failed");
      }
      const restRoute = restResult.routes[0];
      const nativeResult = await this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_START,
        lat: stops[0]?.lat,
        lng: stops[0]?.lng,
        stops,
        mode,
        avoid: opts.avoid,
        simulate: opts.simulate ?? false,
        speedMultiplier: opts.speedMultiplier ?? 1,
        missedTurnRerouteMeters: opts.missedTurnRerouteMeters
      });
      if (!nativeResult.ok) {
        this._detachPivotTracking();
        return nativeResult;
      }
      const syntheticRoute = buildNavRouteFromComputed(restRoute);
      this.session.events._forwardEvent(MiniappStreamType.NAVIGATION_ROUTE, syntheticRoute);
      return nativeResult;
    }
    stop() {
      this._detachPivotTracking();
      this.session.sendOneShot({ type: MiniappRequestType.NAVIGATION_STOP });
    }
    get dev() {
      return {
        deviate: (offsetMeters = 20) => {
          this.session.sendOneShot({ type: MiniappRequestType.NAVIGATION_DEVIATE, offsetMeters });
        },
        setWrongSidewalkOffset: (enabled) => {
          this.session.sendOneShot({ type: MiniappRequestType.NAVIGATION_SET_WRONG_SIDEWALK, enabled });
        },
        setSkipCrossings: (enabled) => {
          this.session.sendOneShot({ type: MiniappRequestType.NAVIGATION_SET_SKIP_CROSSINGS, enabled });
        }
      };
    }
    onUpdate(handler) {
      return this.session._subscribe(MiniappStreamType.NAVIGATION_UPDATE, handler);
    }
    onRoute(handler) {
      return this.session._subscribe(MiniappStreamType.NAVIGATION_ROUTE, handler);
    }
    async getState() {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_GET_STATE
      });
      return result.ok ? result.state ?? null : null;
    }
    computeRoute(opts) {
      if (!this.hasPermission) {
        return Promise.resolve({
          ok: false,
          error: "LOCATION permission not declared in miniapp.json (required for navigation.computeRoute)."
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_COMPUTE_ROUTE,
        origin: opts.origin,
        stops: opts.stops,
        mode: opts.mode ?? "driving",
        avoid: opts.avoid,
        alternatives: opts.alternatives ?? 1
      });
    }
    reverseGeocodeRoad(coord) {
      if (!this.hasPermission) {
        return Promise.resolve({
          ok: false,
          error: "LOCATION permission not declared in miniapp.json (required for reverseGeocodeRoad)."
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_REVERSE_GEOCODE,
        lat: coord.lat,
        lng: coord.lng
      });
    }
    placeAutocomplete(opts) {
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_PLACE_AUTOCOMPLETE,
        query: opts.query,
        near: opts.near ?? null,
        sessionToken: opts.sessionToken
      });
    }
    placeDetails(opts) {
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_PLACE_DETAILS,
        placeId: opts.placeId,
        sessionToken: opts.sessionToken
      });
    }
    onPivot(handler) {
      return this._pivots.subscribe(handler);
    }
    getPivots() {
      return this._pivots.getPivots();
    }
    getActivePivot() {
      return this._pivots.getActivePivot();
    }
    getUpcomingPivot() {
      return this._pivots.getUpcomingPivot();
    }
    _attachPivotTrackingForTrip(mode, opts) {
      this._detachPivotTracking();
      this._pivots.reset();
      this._pivots.updateOptions(mode, opts);
      this._tripUnsubs.push(this.onRoute((route) => {
        if (route.steps && route.steps.length > 0) {
          const tail = route.points[route.points.length - 1];
          const computedSteps = route.steps.map((s, i) => {
            const next = route.steps?.[i + 1];
            const endLat = next ? next.lat : tail?.lat ?? s.lat;
            const endLng = next ? next.lng : tail?.lng ?? s.lng;
            return {
              lat: s.lat,
              lng: s.lng,
              endLat,
              endLng,
              distanceMeters: s.distanceMeters,
              maneuver: s.maneuver,
              road: s.road ?? undefined
            };
          });
          this._pivots.setRouteFromComputedSteps(route, computedSteps);
          return;
        }
        this._pivots.setRoute(route, null);
        const seq = ++this._computeRouteSeq;
        this._issueComputeRouteForTrip(route).then((result) => {
          if (seq !== this._computeRouteSeq)
            return;
          const computedSteps = result?.routes?.[0]?.steps;
          if (computedSteps && computedSteps.length > 0) {
            this._pivots.setRouteFromComputedSteps(route, computedSteps);
          }
        }).catch((err) => {
          console.warn("[NavigationModule] computeRoute for pivots failed:", err);
        });
      }));
      this._tripUnsubs.push(this.onUpdate((update) => {
        if (update.kind === "arrived") {
          this._pivots.reset();
          return;
        }
      }));
      this._tripUnsubs.push(this.session.location.onUpdate((loc) => {
        this._lastUserPosition = { lat: loc.lat, lng: loc.lng };
        this._pivots.onLocationUpdate({ lat: loc.lat, lng: loc.lng });
      }));
    }
    async _issueComputeRouteForTrip(route) {
      if (!this._tripStops || this._tripStops.length === 0)
        return null;
      const origin = this._lastUserPosition ?? (route?.points && route.points[0] ? { lat: route.points[0].lat, lng: route.points[0].lng } : null);
      if (!origin)
        return null;
      return this.computeRoute({
        origin,
        stops: this._tripStops,
        mode: this._tripMode,
        avoid: this._tripAvoid
      });
    }
    _detachPivotTracking() {
      for (const unsub of this._tripUnsubs) {
        try {
          unsub();
        } catch (err) {
          console.warn("[NavigationModule] pivot-tracking unsubscribe threw:", err);
        }
      }
      this._tripUnsubs = [];
      this._pivots.reset();
      this._tripStops = null;
      this._tripAvoid = undefined;
      this._computeRouteSeq++;
      this._lastUserPosition = null;
    }
  }
  function normalizeStops(opts) {
    if (opts.stops && opts.stops.length > 0) {
      return opts.stops;
    }
    if (typeof opts.lat === "number" && typeof opts.lng === "number") {
      return [{ lat: opts.lat, lng: opts.lng }];
    }
    return [];
  }
  function buildNavRouteFromComputed(computed) {
    const points = computed.points ?? [];
    const steps = (computed.steps ?? []).map((s) => {
      let routeIndex = 0;
      let best = Infinity;
      for (let i = 0;i < points.length; i++) {
        const dLat = points[i].lat - s.lat;
        const dLng = points[i].lng - s.lng;
        const d = dLat * dLat + dLng * dLng;
        if (d < best) {
          best = d;
          routeIndex = i;
        }
      }
      return {
        lat: s.lat,
        lng: s.lng,
        routeIndex,
        road: s.road ?? null,
        maneuver: s.maneuver ?? "STRAIGHT",
        distanceMeters: s.distanceMeters
      };
    });
    return {
      points,
      totalDistanceMeters: computed.totalDistanceMeters,
      totalDurationSeconds: computed.totalDurationSeconds,
      steps: steps.length > 0 ? steps : undefined
    };
  }

  // ../vendor/miniapp/dist/modules/permissions.js
  class PermissionsModule {
    constructor(session) {
      this.session = session;
    }
    has(type) {
      return this.session._getPermissions()[type] === true;
    }
    getAll() {
      return this.session._getPermissions();
    }
    onUpdate(handler) {
      return this.session.on("permissions", handler);
    }
    onPermissionError(handler) {
      return this.session.on("error", (e) => {
        const maybe = e;
        if (maybe?.code === MiniappErrorCode.PERMISSION_NOT_DECLARED) {
          handler({
            code: String(maybe.code),
            message: String(maybe.message ?? ""),
            permission: maybe.permission,
            subscription: maybe.subscription,
            operation: maybe.operation
          });
        }
      });
    }
  }

  // ../vendor/miniapp/dist/modules/phone.js
  class TrackedSubs {
    constructor() {
      this.unsubs = new Set;
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
  }

  class PhoneNotificationsModule extends TrackedSubs {
    constructor(session) {
      super();
      this.session = session;
    }
    on(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.PHONE_NOTIFICATION, handler));
    }
    onDismissed(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.PHONE_NOTIFICATION_DISMISSED, handler));
    }
    get hasPermission() {
      return this.session._hasManifestPermission("READ_NOTIFICATIONS");
    }
  }

  class PhoneCalendarModule {
    constructor(session) {
      this.session = session;
    }
    listEvents(options) {
      const startsAt = normalizeCalendarDate(options?.startsAt, "startsAt");
      const endsAt = normalizeCalendarDate(options?.endsAt, "endsAt");
      return this.session.sendRequest({
        type: MiniappRequestType.CALENDAR_LIST_EVENTS,
        startsAt,
        endsAt,
        ...options.limit === undefined ? {} : { limit: options.limit }
      });
    }
    get hasPermission() {
      return this.session._hasManifestPermission("CALENDAR");
    }
  }
  function normalizeCalendarDate(value, field) {
    const date = value instanceof Date ? value : new Date(value ?? "");
    if (Number.isNaN(date.getTime()))
      throw new TypeError(`${field} must be a valid Date or ISO 8601 string`);
    return date.toISOString();
  }

  class PhoneModule {
    constructor(session) {
      this.session = session;
      this.notifications = new PhoneNotificationsModule(session);
      this.calendar = new PhoneCalendarModule(session);
    }
    onBattery(handler) {
      return this.session._subscribe(MiniappStreamType.PHONE_BATTERY, handler);
    }
  }

  // ../vendor/cloud-protocol/src/languages.ts
  var CANONICAL_TAG_BY_CODE = {
    af: "af-ZA",
    am: "am-ET",
    ar: "ar-AE",
    az: "az-AZ",
    be: "be-BY",
    bg: "bg-BG",
    bn: "bn-IN",
    bs: "bs-BA",
    ca: "ca-ES",
    cs: "cs-CZ",
    cy: "cy-GB",
    da: "da-DK",
    de: "de-DE",
    el: "el-GR",
    en: "en-US",
    es: "es-ES",
    et: "et-EE",
    eu: "eu-ES",
    fa: "fa-IR",
    fi: "fi-FI",
    fr: "fr-FR",
    gl: "gl-ES",
    gu: "gu-IN",
    he: "he-IL",
    hi: "hi-IN",
    hr: "hr-HR",
    hu: "hu-HU",
    hy: "hy-AM",
    id: "id-ID",
    it: "it-IT",
    ja: "ja-JP",
    ka: "ka-GE",
    kk: "kk-KZ",
    kn: "kn-IN",
    ko: "ko-KR",
    lt: "lt-LT",
    lv: "lv-LV",
    mk: "mk-MK",
    ml: "ml-IN",
    mr: "mr-IN",
    ms: "ms-MY",
    nb: "nb-NO",
    ne: "ne-NP",
    nl: "nl-NL",
    no: "nb-NO",
    pa: "pa-IN",
    pl: "pl-PL",
    pt: "pt-BR",
    ro: "ro-RO",
    ru: "ru-RU",
    sk: "sk-SK",
    sl: "sl-SI",
    sq: "sq-AL",
    sr: "sr-RS",
    sv: "sv-SE",
    sw: "sw-KE",
    ta: "ta-IN",
    te: "te-IN",
    th: "th-TH",
    tl: "fil-PH",
    tr: "tr-TR",
    uk: "uk-UA",
    ur: "ur-IN",
    vi: "vi-VN",
    zh: "zh-CN"
  };
  var EXTRA_REGIONAL_TAGS = [
    "ar-EG",
    "ar-SA",
    "de-AT",
    "de-CH",
    "en-AU",
    "en-CA",
    "en-GB",
    "en-IN",
    "es-419",
    "es-MX",
    "es-US",
    "fr-CA",
    "nl-BE",
    "pt-PT",
    "zh-HK",
    "zh-TW"
  ];
  var SUPPORTED_LANGUAGE_HINTS = Object.freeze([...new Set(Object.keys(CANONICAL_TAG_BY_CODE))].sort());
  var SUPPORTED_TRANSCRIPTION_LANGUAGES = Object.freeze([
    ...new Set([
      ...Object.values(CANONICAL_TAG_BY_CODE),
      ...EXTRA_REGIONAL_TAGS
    ])
  ].sort());
  var TAG_SET = new Set(SUPPORTED_TRANSCRIPTION_LANGUAGES);
  var HINT_SET = new Set(SUPPORTED_LANGUAGE_HINTS);
  function toTranscriptionLanguage(value) {
    if (TAG_SET.has(value))
      return value;
    const canonical = CANONICAL_TAG_BY_CODE[value.toLowerCase()];
    return canonical ?? null;
  }
  function toLanguageHint(value) {
    const primary = value.split("-")[0].toLowerCase();
    return HINT_SET.has(primary) ? primary : null;
  }
  function suggestTranscriptionLanguage(value) {
    const normalized = value.replace(/_/g, "-");
    const parts = normalized.split("-");
    const recased = parts.length >= 2 ? `${parts[0].toLowerCase()}-${parts[1].toUpperCase()}` : normalized.toLowerCase();
    return toTranscriptionLanguage(recased);
  }

  // ../vendor/miniapp/dist/modules/languages.js
  class MiniappValidationError extends Error {
    constructor(message) {
      super(message);
      this.name = "MiniappValidationError";
    }
  }
  function requireTranscriptionLanguage(value, param) {
    const canonical = toTranscriptionLanguage(value);
    if (canonical)
      return canonical;
    const suggestion = suggestTranscriptionLanguage(value);
    throw new MiniappValidationError(`${param}: unknown language ${JSON.stringify(value)}` + (suggestion ? ` — did you mean ${JSON.stringify(suggestion)}?` : "") + ` Supported values are BCP-47 tags from SUPPORTED_TRANSCRIPTION_LANGUAGES (e.g. "en-US", "fr-FR").`);
  }
  function requireLanguageHint(value, param) {
    const hint = toLanguageHint(value);
    if (hint)
      return hint;
    throw new MiniappValidationError(`${param}: unknown language hint ${JSON.stringify(value)}. ` + `Hints are bare ISO 639-1 codes from SUPPORTED_LANGUAGE_HINTS (e.g. "en", "fr").`);
  }

  // ../vendor/miniapp/dist/modules/transcription.js
  class TranscriptionModule {
    constructor(session) {
      this.session = session;
      this.unsubs = new Set;
      this.currentConfig = null;
    }
    on(handler, options = {}) {
      return this.track(this.session._subscribe(`${MiniappStreamType.TRANSCRIPTION}:auto`, handler, options));
    }
    forLanguage(language, handler, options = {}) {
      const langs = (Array.isArray(language) ? language : [language]).map((lang) => requireTranscriptionLanguage(lang, "transcription.forLanguage(language)"));
      if (langs.length === 0)
        return () => {};
      const unsubs = [];
      for (const lang of langs) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TRANSCRIPTION}:${lang}`, handler, options));
      }
      const combined = () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
      return this.track(combined);
    }
    configure(config) {
      const normalized = {
        ...config,
        languageHints: config.languageHints?.map((hint) => requireLanguageHint(hint, "transcription.configure(languageHints)"))
      };
      this.currentConfig = { ...normalized };
      return this.session.sendRequest({
        type: MiniappRequestType.TRANSCRIPTION_CONFIG,
        config: { ...normalized }
      }).then(() => {
        return;
      });
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
    get hasPermission() {
      return this.session._hasManifestPermission("MICROPHONE");
    }
    _getConfig() {
      return this.currentConfig ? { ...this.currentConfig } : null;
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
  }

  // ../vendor/miniapp/dist/modules/translation.js
  class TranslationModule {
    constructor(session) {
      this.session = session;
      this.unsubs = new Set;
    }
    on(handler) {
      return this.track(this.session._subscribe(`${MiniappStreamType.TRANSLATION}:*:*`, handler));
    }
    to(target, handler) {
      const targets = (Array.isArray(target) ? target : [target]).map((t) => requireTranscriptionLanguage(t, "translation.to(target)"));
      if (targets.length === 0)
        return () => {};
      const unsubs = [];
      for (const t of targets) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TRANSLATION}:*:${t}`, handler));
      }
      const composite = () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
      return this.track(composite);
    }
    fromTo(source, target, handler) {
      const validSource = source === "auto" ? "auto" : requireTranscriptionLanguage(source, "translation.fromTo(source)");
      const targets = (Array.isArray(target) ? target : [target]).map((t) => requireTranscriptionLanguage(t, "translation.fromTo(target)"));
      if (targets.length === 0)
        return () => {};
      const unsubs = [];
      for (const t of targets) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TRANSLATION}:${validSource}:${t}`, handler));
      }
      const composite = () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
      return this.track(composite);
    }
    forLanguagePair(fromLang, toLang, handler) {
      return this.fromTo(fromLang, toLang, handler);
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
    get hasPermission() {
      return this.session._hasManifestPermission("MICROPHONE");
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
  }

  // ../vendor/miniapp/dist/modules/ui.js
  function rpcErrorFromUnknown(e) {
    if (e instanceof Error) {
      const own = e;
      const cause = own.cause;
      return compactEnvelope({
        message: e.message,
        code: own.code ?? cause?.code,
        stage: own.stage,
        transport: own.transport
      });
    }
    if (e && typeof e === "object") {
      const o = e;
      return compactEnvelope({
        message: typeof o.message === "string" ? o.message : JSON.stringify(e),
        code: typeof o.code === "string" ? o.code : undefined,
        stage: typeof o.stage === "string" ? o.stage : undefined,
        transport: typeof o.transport === "string" ? o.transport : undefined
      });
    }
    return { message: String(e) };
  }
  function compactEnvelope(env) {
    const out = { message: env.message };
    if (env.code)
      out.code = env.code;
    if (env.stage)
      out.stage = env.stage;
    if (env.transport)
      out.transport = env.transport;
    return out;
  }

  class UIModuleImpl {
    constructor(session) {
      this.session = session;
      this.bound = false;
      this.nextSeq = 1;
      this.openHandlers = new Set;
      this.closeHandlers = new Set;
      this.channelHandlers = new Map;
      this.rpcHandlers = new Map;
      this.inflightRpc = new Map;
      this.isOpen = () => {
        return this.bound;
      };
      this.onOpen = (cb) => {
        this.openHandlers.add(cb);
        if (this.bound) {
          if (this.session.ready) {
            try {
              cb();
            } catch (e) {
              console.warn("session.ui.onOpen late-fire threw:", e);
            }
          }
        }
        return () => {
          this.openHandlers.delete(cb);
        };
      };
      this.onClose = (cb) => {
        this.closeHandlers.add(cb);
        return () => {
          this.closeHandlers.delete(cb);
        };
      };
      this.send = (channel, payload) => {
        if (!this.bound) {
          return;
        }
        const seq = this.nextSeq++;
        const envelope = { type: "UI_SEND", channel, payload, seq };
        this.session.sendOneShot(envelope);
      };
      this.on = (channel, cb) => {
        let set = this.channelHandlers.get(channel);
        if (!set) {
          set = new Set;
          this.channelHandlers.set(channel, set);
        }
        set.add(cb);
        return () => {
          set.delete(cb);
        };
      };
      this.handle = (channel, handler) => {
        const key = channel;
        if (this.rpcHandlers.has(key)) {
          throw new Error(`session.ui.handle: a handler is already registered for "${key}"`);
        }
        this.rpcHandlers.set(key, handler);
        return () => {
          this.rpcHandlers.delete(key);
        };
      };
      this.session._subscribe("_ui", (env) => this.handleInbound(env));
    }
    fireOpenHandlers() {
      for (const h of this.openHandlers) {
        try {
          h();
        } catch (e) {
          console.warn("session.ui.onOpen handler threw", e);
        }
      }
    }
    handleInbound(env) {
      if (env.type === "UI_OPEN") {
        this.bound = true;
        this.nextSeq = 1;
        if (this.session.ready) {
          this.fireOpenHandlers();
        } else {
          const off = this.session.on("ready", () => {
            off();
            if (this.bound)
              this.fireOpenHandlers();
          });
        }
        return;
      }
      if (env.type === "UI_CLOSE") {
        this.bound = false;
        for (const h of this.closeHandlers) {
          try {
            h();
          } catch (e) {
            console.warn("session.ui.onClose handler threw", e);
          }
        }
        return;
      }
      if (env.type === "UI_MESSAGE") {
        if (typeof env.requestId === "string") {
          this.dispatchRpcCall(env.channel, env.payload, env.requestId);
          return;
        }
        const set = this.channelHandlers.get(env.channel);
        if (!set || set.size === 0)
          return;
        for (const h of set) {
          try {
            h(env.payload);
          } catch (e) {
            console.warn(`session.ui.on(${env.channel}) threw`, e);
          }
        }
        return;
      }
      if (env.type === "UI_CANCEL") {
        const ctrl = this.inflightRpc.get(env.requestId);
        if (ctrl) {
          try {
            ctrl.abort();
          } catch {}
        }
        return;
      }
    }
    dispatchRpcCall(channel, payload, requestId) {
      const handler = this.rpcHandlers.get(channel);
      if (!handler) {
        this.sendRpcReply(channel, requestId, {
          ok: false,
          error: { message: `no handler registered for "${channel}"` }
        });
        return;
      }
      const ctrl = new AbortController;
      this.inflightRpc.set(requestId, ctrl);
      const ctx = { signal: ctrl.signal };
      const finish = (envelope) => {
        this.inflightRpc.delete(requestId);
        if (ctrl.signal.aborted)
          return;
        this.sendRpcReply(channel, requestId, envelope);
      };
      let result;
      try {
        result = handler(payload, ctx);
      } catch (e) {
        finish({ ok: false, error: rpcErrorFromUnknown(e) });
        return;
      }
      if (result && typeof result.then === "function") {
        result.then((v) => finish({ ok: true, result: v }), (e) => finish({ ok: false, error: rpcErrorFromUnknown(e) }));
      } else {
        finish({ ok: true, result });
      }
    }
    sendRpcReply(channel, requestId, payload) {
      if (!this.bound)
        return;
      const seq = this.nextSeq++;
      const envelope = { type: "UI_SEND", channel, payload, seq, requestId };
      this.session.sendOneShot(envelope);
    }
  }

  // ../vendor/miniapp/dist/modules/storage.js
  class SimpleStorage {
    constructor(session) {
      this.session = session;
    }
    async get(key) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_GET,
        key
      });
      return result?.value ?? null;
    }
    async set(key, value) {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_SET,
        key,
        value
      });
    }
    async delete(key) {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_DELETE,
        key
      });
    }
    async keys() {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_LIST
      });
      return result?.keys ?? [];
    }
    async list() {
      return this.keys();
    }
    async clear() {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_CLEAR
      });
    }
    async has(key) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_HAS,
        key
      });
      return !!result?.has;
    }
    async getAll() {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_GET_ALL
      });
      return result?.values ?? {};
    }
    async setMultiple(values) {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_SET_MULTIPLE,
        values
      });
    }
    async flush() {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_FLUSH
      });
    }
  }

  // ../vendor/miniapp/dist/modules/base64.js
  var ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  var LOOKUP = (() => {
    const t = new Int16Array(256).fill(-1);
    for (let i = 0;i < ALPHABET.length; i++)
      t[ALPHABET.charCodeAt(i)] = i;
    t[61] = 0;
    return t;
  })();
  function toUint8Array(input) {
    if (input instanceof Uint8Array)
      return input;
    if (input instanceof ArrayBuffer)
      return new Uint8Array(input);
    return new Uint8Array(input.buffer, input.byteOffset, input.byteLength);
  }
  function bytesToBase64(input) {
    const bytes = input instanceof Uint8Array ? input : new Uint8Array(input);
    const len = bytes.length;
    let out = "";
    let i = 0;
    for (;i + 2 < len; i += 3) {
      const n = bytes[i] << 16 | bytes[i + 1] << 8 | bytes[i + 2];
      out += ALPHABET[n >> 18 & 63] + ALPHABET[n >> 12 & 63] + ALPHABET[n >> 6 & 63] + ALPHABET[n & 63];
    }
    const rem = len - i;
    if (rem === 1) {
      const n = bytes[i] << 16;
      out += ALPHABET[n >> 18 & 63] + ALPHABET[n >> 12 & 63] + "==";
    } else if (rem === 2) {
      const n = bytes[i] << 16 | bytes[i + 1] << 8;
      out += ALPHABET[n >> 18 & 63] + ALPHABET[n >> 12 & 63] + ALPHABET[n >> 6 & 63] + "=";
    }
    return out;
  }
  function base64ToBytes(b64) {
    let validChars = 0;
    let pad = 0;
    for (let i = 0;i < b64.length; i++) {
      const c = b64.charCodeAt(i);
      if (c === 61) {
        pad++;
        validChars++;
      } else if (LOOKUP[c] !== -1) {
        validChars++;
      }
    }
    const fullGroups = Math.floor(validChars / 4);
    const remChars = validChars - fullGroups * 4;
    let outLen = fullGroups * 3 - (pad > 0 && remChars === 0 ? pad : 0);
    if (remChars === 2)
      outLen += 1;
    else if (remChars === 3)
      outLen += 2;
    if (outLen < 0)
      outLen = 0;
    const out = new Uint8Array(outLen);
    let acc = 0;
    let bits = 0;
    let o = 0;
    for (let i = 0;i < b64.length && o < outLen; i++) {
      const c = b64.charCodeAt(i);
      if (c === 61)
        break;
      const v = LOOKUP[c];
      if (v === -1)
        continue;
      acc = acc << 6 | v;
      bits += 6;
      if (bits >= 8) {
        bits -= 8;
        out[o++] = acc >> bits & 255;
      }
    }
    return out;
  }

  // ../vendor/miniapp/dist/modules/speaker.js
  var SPEAKER_WRITE_CHUNK_BYTES = 256 * 1024;
  var SPEAKER_WRITE_CHUNK_B64 = Math.floor(SPEAKER_WRITE_CHUNK_BYTES / 6) * 8;
  class SpeakerStreamWriter {
    constructor(session, streamId) {
      this.session = session;
      this.streamId = streamId;
      this.settled = false;
      this.writeChain = Promise.resolve();
    }
    async write(chunk) {
      this.assertOpen();
      const bytes = toUint8Array(chunk);
      if (bytes.byteLength === 0)
        throw new Error("PCM chunk cannot be empty");
      if (bytes.byteLength % 2 !== 0)
        throw new Error("PCM chunk must contain complete 16-bit samples");
      return this.enqueueWrite(async () => {
        let last = { bufferedMs: 0 };
        for (let off = 0;off < bytes.length; off += SPEAKER_WRITE_CHUNK_BYTES) {
          last = await this.send(bytesToBase64(bytes.subarray(off, off + SPEAKER_WRITE_CHUNK_BYTES)));
        }
        return last;
      });
    }
    async writeBase64(b64) {
      this.assertOpen();
      if (b64.length === 0 || b64.length % 4 !== 0)
        throw new Error("PCM base64 must be non-empty and padded");
      const padding = b64.endsWith("==") ? 2 : b64.endsWith("=") ? 1 : 0;
      const decodedBytes = b64.length / 4 * 3 - padding;
      if (decodedBytes % 2 !== 0)
        throw new Error("PCM base64 must contain complete 16-bit samples");
      return this.enqueueWrite(async () => {
        let last = { bufferedMs: 0 };
        for (let off = 0;off < b64.length; off += SPEAKER_WRITE_CHUNK_B64) {
          last = await this.send(b64.slice(off, off + SPEAKER_WRITE_CHUNK_B64));
        }
        return last;
      });
    }
    async close() {
      this.assertOpen();
      this.settled = true;
      await this.writeChain;
      const res = await this.session.sendRequest({ type: MiniappRequestType.SPEAKER_STREAM_CLOSE, streamId: this.streamId }, { timeoutMs: 0 });
      return res ?? {};
    }
    async abort() {
      if (this.settled)
        return;
      this.settled = true;
      await this.session.sendRequest({
        type: MiniappRequestType.SPEAKER_STREAM_ABORT,
        streamId: this.streamId
      });
    }
    assertOpen() {
      if (this.settled)
        throw new Error("SpeakerStreamWriter is already closed/aborted");
    }
    async send(base64) {
      const res = await this.session.sendRequest({
        type: MiniappRequestType.SPEAKER_STREAM_WRITE,
        streamId: this.streamId,
        base64
      });
      return res ?? { bufferedMs: 0 };
    }
    enqueueWrite(operation) {
      const result = this.writeChain.then(operation);
      this.writeChain = result.then(() => {
        return;
      }, () => {
        return;
      });
      return result;
    }
  }

  class SpeakerModule {
    constructor(session) {
      this.session = session;
      this._state = "idle";
      this._lastEvent = { state: "idle" };
    }
    get state() {
      return this._state;
    }
    get isPlaying() {
      return this._state === "playing";
    }
    async play(options) {
      await this.session.sendRequest({
        type: MiniappRequestType.PLAY_AUDIO,
        audioUrl: options.audioUrl,
        volume: options.volume,
        stopOtherAudio: options.stopOtherAudio ?? false
      }, { timeoutMs: 0 });
    }
    async speak(text, options = {}) {
      const normalized = Array.isArray(text) ? text.map((sentence) => sentence.trim()).filter(Boolean) : text.trim();
      if (Array.isArray(normalized) && normalized.length === 0 || normalized === "") {
        throw { code: MiniappErrorCode.INTERNAL, message: "speak requires at least one non-empty sentence" };
      }
      try {
        const result = await this.session.sendRequest({
          type: MiniappRequestType.SPEAK,
          text: normalized,
          voice_id: options.voice_id,
          voice_settings: options.voice_settings,
          volume: options.volume,
          stopOtherAudio: options.stopOtherAudio ?? false,
          enableSanitization: options.enableSanitization ?? true,
          forceLocal: options.forceLocal ?? false
        }, { timeoutMs: 0 });
        return result ?? { completed: true };
      } catch (err) {
        if (err && typeof err === "object" && "code" in err) {
          throw err;
        }
        throw { code: MiniappErrorCode.INTERNAL, message: String(err) };
      }
    }
    async createStream(options = {}) {
      if (options.volume !== undefined && (!Number.isFinite(options.volume) || options.volume < 0 || options.volume > 1)) {
        throw new RangeError("speaker stream volume must be between 0 and 1");
      }
      const res = await this.session.sendRequest({
        type: MiniappRequestType.SPEAKER_STREAM_OPEN,
        sampleRate: options.sampleRate ?? 16000,
        channels: options.channels ?? 1,
        volume: options.volume,
        stopOtherAudio: options.stopOtherAudio ?? true
      });
      return new SpeakerStreamWriter(this.session, res.streamId);
    }
    stop() {
      this.session.sendOneShot({ type: MiniappRequestType.STOP_AUDIO });
    }
    onStateChange(handler) {
      return this.session.on("speakerState", handler);
    }
    _applyState(event) {
      if (event.state === this._state && event.state !== "error")
        return;
      this._state = event.state;
      this._lastEvent = event;
    }
    _getLastEvent() {
      return { ...this._lastEvent };
    }
  }

  // ../vendor/miniapp/dist/modules/stream.js
  class StreamModule {
    constructor(session) {
      this.session = session;
    }
    async startStream(options = {}) {
      if (options.direct !== undefined) {
        return this.session.sendRequest({
          type: MiniappRequestType.STREAM_START,
          streamUrl: options.direct,
          video: options.video,
          audio: options.audio,
          sound: options.sound ?? true,
          ...options.authToken ? { authToken: options.authToken } : {},
          ...typeof options.captureAudio === "boolean" ? { captureAudio: options.captureAudio } : {}
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.MANAGED_STREAM_START,
        restreamDestinations: options.destinations,
        video: options.video,
        audio: options.audio,
        sound: options.sound ?? true,
        ingest: options.ingest,
        ...typeof options.captureAudio === "boolean" ? { captureAudio: options.captureAudio } : {}
      });
    }
    async stop(streamId) {
      await this.session.sendRequest({
        type: MiniappRequestType.STREAM_STOP,
        streamId
      });
    }
  }

  // ../vendor/miniapp/dist/modules/system.js
  class SystemModule {
    constructor(session) {
      this.session = session;
    }
    async share(options) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.SHARE,
        ...options
      });
      return result ?? { success: false };
    }
    openUrl(url) {
      this.session.sendOneShot({
        type: MiniappRequestType.OPEN_URL,
        url
      });
    }
    async copyToClipboard(text) {
      await this.session.sendRequest({
        type: MiniappRequestType.COPY_CLIPBOARD,
        text
      });
    }
    async download(options) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.DOWNLOAD,
        ...options
      });
      return result ?? { success: false };
    }
    async scanQr(options = {}) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.SCAN_QR,
        ...options
      }, { timeoutMs: 0 });
      return result ?? { cancelled: true };
    }
  }

  // ../vendor/miniapp/dist/modules/miniapps.js
  class MiniappsModule {
    constructor(session) {
      this.session = session;
    }
    async list(opts) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.MINIAPPS_LIST,
        includeIncompatible: opts?.includeIncompatible ?? false
      });
      return result ?? [];
    }
    async start(packageName) {
      await this.session.sendRequest({
        type: MiniappRequestType.MINIAPPS_START,
        packageName
      });
    }
    async stop(packageName) {
      await this.session.sendRequest({
        type: MiniappRequestType.MINIAPPS_STOP,
        packageName
      });
    }
  }

  // ../vendor/miniapp/dist/modules/actions.js
  var HANDLER_WAIT_MS = 5000;

  class ActionsModule {
    constructor(session) {
      this.session = session;
      this.handlers = new Map;
      this.buffered = new Map;
    }
    invoke(packageName, actionId, params, opts) {
      return this.session.sendRequest({
        type: MiniappRequestType.ACTION_INVOKE,
        targetPackageName: packageName,
        actionId,
        params: params ?? {},
        ...opts?.timeoutMs != null ? { timeoutMs: opts.timeoutMs } : {}
      });
    }
    handle(actionId, handler) {
      if (this.handlers.has(actionId)) {
        throw new Error(`session.actions.handle: a handler is already registered for "${actionId}"`);
      }
      this.handlers.set(actionId, handler);
      const waiting = this.buffered.get(actionId);
      if (waiting) {
        this.buffered.delete(actionId);
        for (const call of waiting) {
          clearTimeout(call.timer);
          this.dispatch(call.callId, actionId, call.params, call.ctx);
        }
      }
      return () => {
        if (this.handlers.get(actionId) === handler)
          this.handlers.delete(actionId);
      };
    }
    _deliver(callId, actionId, params, ctx) {
      if (this.handlers.has(actionId)) {
        this.dispatch(callId, actionId, params, ctx);
        return;
      }
      const timer = setTimeout(() => {
        const arr2 = this.buffered.get(actionId);
        if (arr2) {
          const idx = arr2.findIndex((c) => c.callId === callId);
          if (idx >= 0)
            arr2.splice(idx, 1);
          if (arr2.length === 0)
            this.buffered.delete(actionId);
        }
        this.sendResult(callId, false, undefined, {
          code: MiniappErrorCode.NO_ACTION_HANDLER,
          message: `No handler registered for action "${actionId}"`
        });
      }, HANDLER_WAIT_MS);
      const arr = this.buffered.get(actionId) ?? [];
      arr.push({ callId, params, ctx, timer });
      this.buffered.set(actionId, arr);
    }
    async dispatch(callId, actionId, params, ctx) {
      const handler = this.handlers.get(actionId);
      if (!handler)
        return;
      try {
        const result = await handler(params, ctx);
        this.sendResult(callId, true, result ?? null);
      } catch (e) {
        this.sendResult(callId, false, undefined, {
          code: MiniappErrorCode.INTERNAL,
          message: e?.message ?? "action handler threw"
        });
      }
    }
    sendResult(callId, ok, result, error) {
      this.session.sendOneShot({
        type: MiniappRequestType.ACTION_RESULT,
        callId,
        ok,
        ...ok ? { result } : { error }
      });
    }
  }

  // ../vendor/miniapp/dist/modules/blob.js
  var BLOB_WRITE_CHUNK_BYTES = 1024 * 1024;
  var BLOB_WRITE_CHUNK_B64 = Math.floor(BLOB_WRITE_CHUNK_BYTES / 3) * 4;
  var BLOB_READ_ALL_MAX_BYTES = 32 * 1024 * 1024;

  class BlobWriter {
    constructor(session, key) {
      this.session = session;
      this.key = key;
      this.settled = false;
    }
    async write(chunk) {
      this.assertOpen();
      const bytes = toUint8Array(chunk);
      for (let off = 0;off < bytes.length; off += BLOB_WRITE_CHUNK_BYTES) {
        await this.send(bytesToBase64(bytes.subarray(off, off + BLOB_WRITE_CHUNK_BYTES)));
      }
    }
    async writeBase64(b64) {
      this.assertOpen();
      for (let off = 0;off < b64.length; off += BLOB_WRITE_CHUNK_B64) {
        await this.send(b64.slice(off, off + BLOB_WRITE_CHUNK_B64));
      }
    }
    async writeAt(offset, chunk) {
      this.assertOpen();
      await this.session.sendRequest({
        type: MiniappRequestType.BLOB_WRITE,
        key: this.key,
        offset,
        base64: bytesToBase64(toUint8Array(chunk))
      });
    }
    async close(meta) {
      this.assertOpen();
      this.settled = true;
      return this.session.sendRequest({ type: MiniappRequestType.BLOB_COMMIT, key: this.key, meta });
    }
    async abort() {
      if (this.settled)
        return;
      this.settled = true;
      await this.session.sendRequest({ type: MiniappRequestType.BLOB_ABORT, key: this.key });
    }
    assertOpen() {
      if (this.settled)
        throw new Error("BlobWriter is already closed/aborted");
    }
    send(base64) {
      return this.session.sendRequest({
        type: MiniappRequestType.BLOB_WRITE,
        key: this.key,
        base64
      });
    }
  }

  class BlobReader {
    constructor(session, handle, meta) {
      this.session = session;
      this.handle = handle;
      this.meta = meta;
      this.closed = false;
    }
    async read(maxBytes = BLOB_WRITE_CHUNK_BYTES) {
      if (this.closed)
        throw new Error("BlobReader is closed");
      const res = await this.session.sendRequest({
        type: MiniappRequestType.BLOB_READ,
        handle: this.handle,
        maxBytes
      });
      return { bytes: base64ToBytes(res?.base64 ?? ""), done: !!res?.done };
    }
    async close() {
      if (this.closed)
        return;
      this.closed = true;
      await this.session.sendRequest({ type: MiniappRequestType.BLOB_CLOSE_READ, handle: this.handle });
    }
  }

  class BlobModule {
    constructor(session) {
      this.session = session;
    }
    async set(key, data, opts = {}) {
      const writer = await this.createWriteStream(key, opts);
      try {
        if (typeof data === "string")
          await writer.writeBase64(data);
        else
          await writer.write(data);
        return await writer.close();
      } catch (err) {
        await writer.abort().catch(() => {});
        throw err;
      }
    }
    setFromUrl(key, url, opts = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.BLOB_SET_FROM_URL,
        key,
        url,
        mimeType: opts.mimeType,
        name: opts.name,
        headers: opts.headers,
        meta: opts.meta
      });
    }
    importFile(opts = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.BLOB_IMPORT,
        key: opts.key,
        mimeType: opts.mimeType,
        meta: opts.meta
      });
    }
    async createWriteStream(key, opts = {}) {
      const res = await this.session.sendRequest({
        type: MiniappRequestType.BLOB_CREATE,
        key,
        mimeType: opts.mimeType,
        name: opts.name,
        meta: opts.meta
      });
      return new BlobWriter(this.session, res.key);
    }
    get(key) {
      return this.session.sendRequest({ type: MiniappRequestType.BLOB_GET, key });
    }
    stat(key) {
      return this.get(key);
    }
    async has(key) {
      return await this.get(key) !== null;
    }
    async keys() {
      return (await this.list()).map((m) => m.key);
    }
    async list() {
      const res = await this.session.sendRequest({ type: MiniappRequestType.BLOB_LIST });
      return res?.blobs ?? [];
    }
    async createReadStream(key) {
      const res = await this.session.sendRequest({
        type: MiniappRequestType.BLOB_OPEN_READ,
        key
      });
      return new BlobReader(this.session, res.handle, res.meta);
    }
    async bytes(key) {
      let reader;
      try {
        reader = await this.createReadStream(key);
      } catch {
        return null;
      }
      const parts = [];
      let total = 0;
      try {
        for (;; ) {
          const { bytes, done } = await reader.read();
          if (bytes.length) {
            total += bytes.length;
            if (total > BLOB_READ_ALL_MAX_BYTES) {
              throw new Error(`Blob "${key}" exceeds the in-memory read cap — stream it with createReadStream()`);
            }
            parts.push(bytes);
          }
          if (done)
            break;
        }
      } finally {
        await reader.close().catch(() => {});
      }
      const out = new Uint8Array(total);
      let at = 0;
      for (const p of parts) {
        out.set(p, at);
        at += p.length;
      }
      return out;
    }
    usage() {
      return this.session.sendRequest({
        type: MiniappRequestType.BLOB_USAGE
      });
    }
    async delete(key) {
      await this.session.sendRequest({ type: MiniappRequestType.BLOB_DELETE, key });
    }
    async clear() {
      await this.session.sendRequest({ type: MiniappRequestType.BLOB_CLEAR });
    }
    async share(key) {
      const res = await this.session.sendRequest({
        type: MiniappRequestType.BLOB_SHARE,
        key
      });
      return res ?? { success: false };
    }
  }

  // ../vendor/miniapp/dist/modules/meeting.js
  var MEETING_HOST_UPDATE_MESSAGE = "Update the Mentra App to use Teams calling";
  function validateMeetingVideoSource(source) {
    const value = source ?? {};
    if (value.type === "whep") {
      const url = typeof value.url === "string" ? value.url.trim() : "";
      if (!url) {
        throw { code: MiniappErrorCode.INVALID_ARGUMENT, message: "videoSource.url is required for a WHEP source" };
      }
      return { type: "whep", url };
    }
    if (value.type === "softap") {
      const ssid = typeof value.ssid === "string" ? value.ssid.trim() : "";
      const passphrase = typeof value.passphrase === "string" ? value.passphrase : "";
      if (Boolean(ssid) !== Boolean(passphrase)) {
        throw {
          code: MiniappErrorCode.INVALID_ARGUMENT,
          message: "videoSource.ssid and videoSource.passphrase must be provided together"
        };
      }
      return ssid ? { type: "softap", ssid, passphrase } : { type: "softap" };
    }
    throw {
      code: MiniappErrorCode.INVALID_ARGUMENT,
      message: `videoSource must be {type: "whep", url} or {type: "softap"}`
    };
  }
  function parseMeetingCapabilities(raw) {
    if (!raw || typeof raw !== "object")
      return;
    const value = raw.hangUpForEveryone;
    if (!value || typeof value !== "object")
      return;
    const capability = value;
    return {
      hangUpForEveryone: {
        allowed: typeof capability.allowed === "boolean" ? capability.allowed : null,
        reason: typeof capability.reason === "string" && capability.reason ? capability.reason : null
      }
    };
  }
  var SOFTAP_STEPS = new Set(["hotspot", "scopedJoin", "acsJoin", "publish", "live"]);
  var SOFTAP_STEP_STATUSES = new Set(["pending", "running", "done", "failed"]);
  var SOFTAP_PHASES = new Set(["idle", "starting", "live", "stopping", "failed"]);
  function parseMeetingSoftApProgress(raw) {
    if (!raw || typeof raw !== "object")
      return;
    const value = raw;
    if (!SOFTAP_PHASES.has(String(value.phase)) || !Array.isArray(value.steps))
      return;
    const steps = [];
    for (const entry of value.steps) {
      if (!entry || typeof entry !== "object")
        continue;
      const step = entry;
      if (!SOFTAP_STEPS.has(String(step.step)) || !SOFTAP_STEP_STATUSES.has(String(step.status)))
        continue;
      steps.push({
        step: step.step,
        status: step.status,
        detail: typeof step.detail === "string" && step.detail ? step.detail : undefined,
        error: typeof step.error === "string" && step.error ? step.error : undefined,
        durationMs: typeof step.durationMs === "number" && Number.isFinite(step.durationMs) ? step.durationMs : undefined
      });
    }
    return {
      traceId: typeof value.traceId === "string" && value.traceId ? value.traceId : undefined,
      phase: value.phase,
      steps,
      elapsedMs: typeof value.elapsedMs === "number" && Number.isFinite(value.elapsedMs) ? value.elapsedMs : 0
    };
  }
  var PARTICIPANT_STATES = new Set(["idle", "connecting", "connected", "lobby", "hold", "disconnected"]);
  var MEDIA_SOURCES = new Set(["idle", "connecting", "live", "failed"]);
  function parseMeetingMediaSource(raw) {
    return MEDIA_SOURCES.has(String(raw)) ? raw : undefined;
  }
  function parseMeetingParticipants(raw) {
    if (!Array.isArray(raw))
      return;
    const result = [];
    for (const entry of raw) {
      if (!entry || typeof entry !== "object")
        continue;
      const value = entry;
      if (typeof value.id !== "string" || !value.id)
        continue;
      result.push({
        id: value.id,
        displayName: typeof value.displayName === "string" && value.displayName ? value.displayName : null,
        state: PARTICIPANT_STATES.has(String(value.state)) ? value.state : "idle",
        isMuted: Boolean(value.isMuted),
        isSpeaking: Boolean(value.isSpeaking)
      });
    }
    return result;
  }
  function isMiniappRequestError(error) {
    return Boolean(error && typeof error === "object" && "code" in error);
  }
  function mapHostError(error) {
    if (isMiniappRequestError(error) && error.code === MiniappErrorCode.NOT_IMPLEMENTED) {
      throw { code: MiniappErrorCode.NOT_IMPLEMENTED, message: MEETING_HOST_UPDATE_MESSAGE };
    }
    throw error;
  }

  class MeetingModule {
    constructor(session) {
      this.session = session;
      this._state = { state: "idle", muted: false };
    }
    get state() {
      return { ...this._state };
    }
    async join(options) {
      if (options.provider !== "acs-teams") {
        throw { code: MiniappErrorCode.INVALID_ARGUMENT, message: `Unsupported meeting provider: ${options.provider}` };
      }
      if (!options.meetingUrl?.trim()) {
        throw { code: MiniappErrorCode.INVALID_ARGUMENT, message: "meetingUrl is required" };
      }
      const videoSource = validateMeetingVideoSource(options.videoSource);
      if (!options.token?.trim()) {
        throw { code: MiniappErrorCode.INVALID_ARGUMENT, message: "token is required" };
      }
      try {
        const result = await this.session.sendRequest({
          type: MiniappRequestType.MEETING_JOIN,
          provider: options.provider,
          meetingUrl: options.meetingUrl,
          videoSource,
          token: options.token,
          displayName: options.displayName,
          ...options.video ? { video: options.video } : {}
        }, { timeoutMs: 0 });
        if (result)
          this._applyState(result);
        return this.state;
      } catch (error) {
        mapHostError(error);
      }
    }
    async leave() {
      try {
        await this.session.sendRequest({ type: MiniappRequestType.MEETING_LEAVE });
      } catch (error) {
        mapHostError(error);
      }
    }
    async end() {
      try {
        await this.session.sendRequest({ type: MiniappRequestType.MEETING_END }, { timeoutMs: 0 });
      } catch (error) {
        mapHostError(error);
      }
    }
    async setMuted(muted) {
      try {
        const result = await this.session.sendRequest({
          type: MiniappRequestType.MEETING_SET_MUTED,
          muted
        });
        if (result)
          this._applyState(result);
      } catch (error) {
        mapHostError(error);
      }
    }
    async updateVideoSource(source) {
      const validated = validateMeetingVideoSource(source);
      if (validated.type !== "whep") {
        throw {
          code: MiniappErrorCode.INVALID_ARGUMENT,
          message: "updateVideoSource accepts a WHEP source; a SoftAP call recovers by rejoining"
        };
      }
      try {
        await this.session.sendRequest({
          type: MiniappRequestType.MEETING_UPDATE_VIDEO_SOURCE,
          videoSource: validated
        });
      } catch (error) {
        mapHostError(error);
      }
    }
    async getState() {
      try {
        const result = await this.session.sendRequest({
          type: MiniappRequestType.MEETING_GET_STATE
        });
        if (result)
          this._applyState(result);
        return this.state;
      } catch (error) {
        mapHostError(error);
      }
    }
    onState(handler) {
      return this.session.on("meetingState", handler);
    }
    _applyState(event) {
      this._state = {
        state: event.state,
        muted: Boolean(event.muted),
        error: event.error,
        meetingUrl: event.meetingUrl,
        provider: event.provider,
        audioSource: event.audioSource,
        audioSourceReason: event.audioSourceReason,
        activeStream: event.activeStream,
        audioSafety: event.audioSafety,
        mediaSource: parseMeetingMediaSource(event.mediaSource),
        participants: parseMeetingParticipants(event.participants),
        capabilities: parseMeetingCapabilities(event.capabilities) ?? this._state.capabilities,
        softap: parseMeetingSoftApProgress(event.softap)
      };
    }
  }

  // ../vendor/miniapp/dist/session.js
  var ALL_PERMISSION_TYPES = [
    "location",
    "microphone",
    "camera",
    "notifications",
    "calendar"
  ];

  class NotConnectedError extends Error {
    constructor(message = "MiniappSession is not connected") {
      super(message);
      this.code = MiniappErrorCode.NOT_CONNECTED;
      this.name = "NotConnectedError";
    }
  }
  var DEFAULT_CONNECT_TIMEOUT_MS = 1e4;
  var DEFAULT_REQUEST_TIMEOUT_MS = 60000;

  class MiniappSession {
    constructor(options = {}) {
      this.capabilities = null;
      this.hostFeatures = null;
      this.userId = "";
      this.packageName = "";
      this.visibility = "foreground";
      this.colorScheme = "light";
      this.ready = false;
      this.emitter = new import__.default;
      this.authState = null;
      this.configurationState = {};
      this.authWaiters = new Set;
      this.authRefreshPromise = null;
      this.outboundQueue = [];
      this.pendingRequests = new Map;
      this.connectPromise = null;
      this.disposed = false;
      this._permissions = {
        location: false,
        microphone: false,
        camera: false,
        notifications: false,
        calendar: false
      };
      this.transport = createTransport(options);
      this.connectTimeoutMs = options.connectTimeoutMs ?? DEFAULT_CONNECT_TIMEOUT_MS;
      const injected = getMentraOSGlobals();
      this.packageName = options.packageName ?? injected.packageName ?? "";
      if (injected.colorScheme === "light" || injected.colorScheme === "dark") {
        this.colorScheme = injected.colorScheme;
      }
      this.auth = new AuthModule(this);
      this.configuration = new ConfigurationModule(this);
      this.events = new EventManager(this);
      this.speaker = new SpeakerModule(this);
      this.meeting = new MeetingModule(this);
      this.camera = new CameraModule(this);
      this.cloud = new CloudModule(this);
      this.dashboard = new DashboardAPI(this);
      this.display = new DisplayManager(this);
      this.glasses = new GlassesModule(this);
      this.heading = new HeadingModule(this);
      this.imu = new ImuModule(this);
      this.input = new InputModule(this);
      this.led = new LedModule(this);
      this.location = new LocationModule(this);
      this.mic = new MicModule(this);
      this.navigation = new NavigationModule(this);
      this.permissions = new PermissionsModule(this);
      this.phone = new PhoneModule(this);
      this.storage = new SimpleStorage(this);
      this.blob = new BlobModule(this);
      this.stream = new StreamModule(this);
      this.system = new SystemModule(this);
      this.transcription = new TranscriptionModule(this);
      this.translation = new TranslationModule(this);
      this.ui = new UIModuleImpl(this);
      this.miniapps = new MiniappsModule(this);
      this.actions = new ActionsModule(this);
    }
    _hasManifestPermission(manifestKey) {
      const canonical = manifestKeyToCanonical(manifestKey);
      if (!canonical)
        return false;
      return this._permissions[canonical] === true;
    }
    _getPermissions() {
      return { ...this._permissions };
    }
    _getAuth() {
      return this.authState ? { ...this.authState } : null;
    }
    _getConfiguration() {
      return { ...this.configurationState };
    }
    _waitForAuth(minTtlMs, timeoutMs = 1e4) {
      const current = this.authState;
      if (current && this.authHasTtl(current, minTtlMs)) {
        return Promise.resolve({ ...current });
      }
      this.requestAuthRefresh(minTtlMs);
      return new Promise((resolve, reject) => {
        const waiter = {
          minTtlMs,
          resolve,
          reject,
          timer: setTimeout(() => {
            this.authWaiters.delete(waiter);
            reject(new NotConnectedError("Miniapp auth token is not available"));
          }, timeoutMs)
        };
        this.authWaiters.add(waiter);
      });
    }
    _subscribe(streamType, handler, options = {}) {
      return this.events.subscribe(streamType, handler, options);
    }
    connect() {
      if (this.disposed) {
        return Promise.reject(new NotConnectedError("MiniappSession was disposed"));
      }
      if (this.connectPromise)
        return this.connectPromise;
      const readyPromise = new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
          const err = new Error("MiniappSession: CONNECT_ACK timeout");
          this.failAllPending({ code: MiniappErrorCode.NOT_CONNECTED, message: err.message });
          this.emitter.emit("error", err);
          reject(err);
        }, this.connectTimeoutMs);
        this.emitter.once("ready", () => {
          clearTimeout(timer);
          resolve();
        });
        this.emitter.once("error", (err) => {
          clearTimeout(timer);
          reject(err);
        });
      });
      this.connectPromise = (async () => {
        this.transport.onMessage((raw) => this.handleIncoming(raw));
        this.transport.onDisconnect((reason) => this.handleTransportDisconnect(reason));
        await this.transport.open();
        const requestId = makeRequestId();
        const connectPayload = {
          type: MiniappRequestType.CONNECT,
          packageName: this.packageName
        };
        this.transport.send(serializeEnvelope({ payload: connectPayload, requestId }));
        await readyPromise;
      })();
      return this.connectPromise;
    }
    waitForReady() {
      if (this.ready)
        return Promise.resolve();
      return this.connect();
    }
    isConnected() {
      return this.ready && this.transport.isOpen();
    }
    disconnect() {
      if (this.disposed)
        return;
      this.disposed = true;
      try {
        this.emitter.emit("beforeDisconnect", "disconnect called");
      } catch (err) {
        console.warn("[MiniappSession] beforeDisconnect handler threw:", err);
      }
      this.failAllPending({ code: MiniappErrorCode.REQUEST_ABORTED, message: "Session disconnected" });
      try {
        this.transport.close();
      } catch {}
      this.ready = false;
      this.emitter.emit("disconnect", "disconnect called");
    }
    sendOneShot(payload) {
      const envelope = { payload };
      this.enqueueOrSend(serializeEnvelope(envelope));
    }
    sendRequest(payload, opts) {
      if (this.disposed) {
        return Promise.reject(new NotConnectedError);
      }
      const requestId = makeRequestId();
      const envelope = { payload, requestId };
      const timeoutMs = opts?.timeoutMs ?? DEFAULT_REQUEST_TIMEOUT_MS;
      return new Promise((resolve, reject) => {
        const timer = timeoutMs > 0 ? setTimeout(() => {
          const pending = this.pendingRequests.get(requestId);
          if (!pending)
            return;
          this.pendingRequests.delete(requestId);
          pending.reject({
            code: MiniappErrorCode.ACTION_TIMEOUT,
            message: "Request timed out waiting for a response from the host"
          });
        }, timeoutMs) : undefined;
        this.pendingRequests.set(requestId, {
          requestId,
          resolve,
          reject,
          timer
        });
        this.enqueueOrSend(serializeEnvelope(envelope));
      });
    }
    on(event, handler) {
      this.emitter.on(event, handler);
      return () => this.emitter.off(event, handler);
    }
    off(event, handler) {
      this.emitter.off(event, handler);
    }
    onBeforeDisconnect(handler) {
      return this.on("beforeDisconnect", handler);
    }
    onVisibilityChange(handler) {
      return this.on("visibility", handler);
    }
    onCapabilitiesChange(handler) {
      return this.on("capabilities", handler);
    }
    onColorSchemeChange(handler) {
      return this.on("colorScheme", handler);
    }
    enqueueOrSend(raw) {
      if (this.ready) {
        try {
          this.transport.send(raw);
        } catch (err) {
          this.emitter.emit("error", err);
        }
        return;
      }
      this.outboundQueue.push(raw);
    }
    flushQueue() {
      const queue = this.outboundQueue.splice(0);
      for (const raw of queue) {
        try {
          this.transport.send(raw);
        } catch (err) {
          this.emitter.emit("error", err);
        }
      }
    }
    handleIncoming(raw) {
      const envelope = parseEnvelope(raw);
      if (!envelope)
        return;
      const payload = envelope.payload;
      const type = payload?.type;
      switch (type) {
        case MiniappResponseType.CONNECT_ACK: {
          const ack = payload;
          this.userId = ack.userId ?? "";
          if (ack.packageName)
            this.packageName = ack.packageName;
          this.capabilities = ack.capabilities ?? null;
          this.hostFeatures = ack.hostFeatures ?? null;
          if (ack.visibility)
            this.visibility = ack.visibility;
          if (ack.colorScheme === "light" || ack.colorScheme === "dark") {
            this.colorScheme = ack.colorScheme;
          }
          if (ack.auth) {
            this.applyAuth(ack.auth);
            if (!this.userId)
              this.userId = ack.auth.mentraUserId;
          }
          this.configurationState = Object.freeze({ ...ack.configuration });
          if (ack.permissions)
            this.applyPermissions(ack.permissions);
          this.ready = true;
          this.flushQueue();
          this.emitter.emit("ready");
          return;
        }
        case MiniappResponseType.AUTH_UPDATE: {
          const next = payload.auth;
          if (next) {
            this.applyAuth(next);
            if (!this.userId)
              this.userId = next.mentraUserId;
          }
          return;
        }
        case MiniappResponseType.PERMISSIONS_UPDATE: {
          const next = payload.permissions;
          if (next)
            this.applyPermissions(next);
          return;
        }
        case MiniappResponseType.SPEAKER_STATE: {
          const state = payload.state;
          if (!state)
            return;
          const event = {
            state,
            errorCode: payload.errorCode,
            errorMessage: payload.errorMessage,
            durationMs: payload.durationMs
          };
          this.speaker._applyState(event);
          this.emitter.emit("speakerState", event);
          return;
        }
        case MiniappResponseType.MEETING_STATE: {
          const state = payload.state;
          if (!state)
            return;
          const event = {
            state,
            muted: Boolean(payload.muted),
            error: payload.error,
            meetingUrl: payload.meetingUrl,
            provider: payload.provider,
            audioSource: payload.audioSource,
            audioSourceReason: payload.audioSourceReason,
            activeStream: payload.activeStream,
            audioSafety: payload.audioSafety,
            mediaSource: parseMeetingMediaSource(payload.mediaSource),
            participants: parseMeetingParticipants(payload.participants),
            capabilities: parseMeetingCapabilities(payload.capabilities),
            softap: parseMeetingSoftApProgress(payload.softap)
          };
          this.meeting._applyState(event);
          this.emitter.emit("meetingState", event);
          return;
        }
        case MiniappRequestType.PING: {
          const pong = { type: MiniappResponseType.PONG };
          const env = {
            payload: pong,
            ...envelope.requestId ? { requestId: envelope.requestId } : {}
          };
          try {
            this.transport.send(serializeEnvelope(env));
          } catch {}
          return;
        }
        case MiniappResponseType.EVENT: {
          const streamType = payload.streamType;
          if (!streamType)
            return;
          this.events._forwardEvent(streamType, payload.data, payload.transcriptionRoute);
          return;
        }
        case MiniappResponseType.ACTION_CALL: {
          const callId = payload.callId;
          const actionId = payload.actionId;
          if (!callId || !actionId)
            return;
          const params = payload.params ?? {};
          const callerPackageName = payload.callerPackageName ?? "";
          this.actions._deliver(callId, actionId, params, { callerPackageName });
          return;
        }
        case MiniappResponseType.CAPABILITIES_UPDATE: {
          const cap = payload.capabilities ?? null;
          this.capabilities = cap;
          this.emitter.emit("capabilities", cap);
          return;
        }
        case MiniappResponseType.VISIBILITY_CHANGE: {
          const next = payload.visibility;
          if (next === "foreground" || next === "background") {
            this.visibility = next;
            this.emitter.emit("visibility", next);
          }
          return;
        }
        case MiniappResponseType.COLOR_SCHEME_CHANGE: {
          const next = payload.colorScheme;
          if (next === "light" || next === "dark") {
            this.colorScheme = next;
            this.emitter.emit("colorScheme", next);
          }
          return;
        }
        case MiniappResponseType.REQUEST_RESULT: {
          const requestId = envelope.requestId;
          if (!requestId)
            return;
          const pending = this.pendingRequests.get(requestId);
          if (!pending)
            return;
          this.pendingRequests.delete(requestId);
          if (pending.timer)
            clearTimeout(pending.timer);
          if (payload.ok === false) {
            const err = payload.error ?? {
              code: MiniappErrorCode.INTERNAL,
              message: "Unknown error"
            };
            pending.reject(err);
          } else {
            pending.resolve(payload.data ?? null);
          }
          return;
        }
        case MiniappResponseType.WILL_DISCONNECT: {
          const reason = payload.reason ?? "phone unregistering";
          try {
            this.emitter.emit("beforeDisconnect", reason);
          } catch (err) {
            console.warn("[MiniappSession] beforeDisconnect handler threw:", err);
          }
          return;
        }
        case MiniappResponseType.ERROR: {
          const err = new Error(payload.message ?? "MiniappSession error");
          this.emitter.emit("error", err);
          return;
        }
        default:
          return;
      }
    }
    handleTransportDisconnect(reason) {
      this.ready = false;
      this.failAllPending({ code: MiniappErrorCode.NOT_CONNECTED, message: `Transport disconnected: ${reason}` });
      this.emitter.emit("disconnect", reason);
    }
    failAllPending(error) {
      for (const pending of this.pendingRequests.values()) {
        if (pending.timer)
          clearTimeout(pending.timer);
        pending.reject(error);
      }
      this.pendingRequests.clear();
      for (const waiter of Array.from(this.authWaiters)) {
        clearTimeout(waiter.timer);
        this.authWaiters.delete(waiter);
        waiter.reject(new NotConnectedError(error.message));
      }
    }
    authHasTtl(auth, minTtlMs) {
      return auth.expiresAt - Date.now() > minTtlMs;
    }
    requestAuthRefresh(minTtlMs) {
      if (this.authRefreshPromise)
        return this.authRefreshPromise;
      if (!this.ready || !this.transport.isOpen())
        return Promise.resolve(null);
      this.authRefreshPromise = this.sendRequest({
        type: MiniappRequestType.AUTH_REFRESH,
        minTtlMs
      }).then((result) => {
        const auth = result?.auth;
        if (auth)
          this.applyAuth(auth);
        return auth ?? null;
      }).catch((err) => {
        console.warn("[MiniappSession] auth refresh failed:", err);
        return null;
      }).finally(() => {
        this.authRefreshPromise = null;
      });
      return this.authRefreshPromise;
    }
    applyAuth(next) {
      this.authState = { ...next };
      for (const waiter of Array.from(this.authWaiters)) {
        if (!this.authHasTtl(next, waiter.minTtlMs))
          continue;
        clearTimeout(waiter.timer);
        this.authWaiters.delete(waiter);
        waiter.resolve({ ...next });
      }
      this.emitter.emit("auth", { ...next });
    }
    applyPermissions(next) {
      let changed = false;
      const updated = { ...this._permissions };
      for (const k of ALL_PERMISSION_TYPES) {
        const v = next[k] === true;
        if (updated[k] !== v) {
          updated[k] = v;
          changed = true;
        }
      }
      if (changed) {
        this._permissions = updated;
        this.emitter.emit("permissions", { ...updated });
      }
    }
  }
  function manifestKeyToCanonical(manifestKey) {
    switch (manifestKey.toUpperCase()) {
      case "MICROPHONE":
        return "microphone";
      case "CAMERA":
        return "camera";
      case "LOCATION":
      case "BACKGROUND_LOCATION":
        return "location";
      case "READ_NOTIFICATIONS":
      case "POST_NOTIFICATIONS":
        return "notifications";
      case "CALENDAR":
        return "calendar";
      default:
        return null;
    }
  }

  // ../vendor/miniapp/dist/background/register.js
  function registerMiniapp(handler, options = {}) {
    const g = globalThis;
    g.__mentraInitCallback = (_sessionId) => {
      const session = new MiniappSession(options);
      try {
        const result = handler(session);
        if (result && typeof result.then === "function") {
          result.catch((err) => {
            console.error("[mentra-miniapp] registerMiniapp handler rejected:", err);
          });
        }
      } catch (err) {
        console.error("[mentra-miniapp] registerMiniapp handler threw:", err);
      }
      session.connect().catch((err) => {
        console.error("[mentra-miniapp] session.connect() rejected:", err);
        try {
          const message = err instanceof Error ? err.message : String(err);
          const stack = err instanceof Error && err.stack ? err.stack : "";
          g.__hostError?.(JSON.stringify({ message: `session.connect() failed: ${message}`, stack }));
        } catch {}
      });
    };
  }
  // src/shared/config.ts
  var DEFAULT_BACKEND_URL = "https://mentra-enterprise-miniapp-prod.mentraglass.com";
  function enterpriseBackendUrl() {
    const fromEnv = "https://mentra-enterprise-miniapp-prod.mentraglass.com"?.trim();
    return (fromEnv || DEFAULT_BACKEND_URL).replace(/\/+$/, "");
  }

  // src/background/inspectionReportPdf.ts
  var encoder = new TextEncoder;
  function bytes(text) {
    return encoder.encode(text);
  }
  function join(parts) {
    const length = parts.reduce((total, part) => total + part.length, 0);
    const result = new Uint8Array(length);
    let offset = 0;
    for (const part of parts) {
      result.set(part, offset);
      offset += part.length;
    }
    return result;
  }
  var PDF_ASSEMBLY_YIELD_BYTES = 128 * 1024;
  function yieldToHost() {
    return new Promise((resolve) => setTimeout(resolve, 0));
  }
  async function joinYielding(parts) {
    const length = parts.reduce((total, part) => total + part.length, 0);
    const result = new Uint8Array(length);
    let offset = 0;
    let bytesSinceYield = 0;
    for (const part of parts) {
      for (let sourceOffset = 0;sourceOffset < part.length; ) {
        const count = Math.min(PDF_ASSEMBLY_YIELD_BYTES - bytesSinceYield, part.length - sourceOffset);
        result.set(part.subarray(sourceOffset, sourceOffset + count), offset);
        sourceOffset += count;
        offset += count;
        bytesSinceYield += count;
        if (bytesSinceYield >= PDF_ASSEMBLY_YIELD_BYTES) {
          bytesSinceYield = 0;
          await yieldToHost();
        }
      }
    }
    return result;
  }
  function pdfText(value) {
    return value.replace(/[\u2013\u2014]/g, "-").replace(/[\u2022\u00b7]/g, "-").replace(/[^\x20-\x7e]/g, "").replace(/[\\()]/g, "\\$&");
  }
  function line(text, x, y, size = 9, bold = false) {
    return `BT /F${bold ? "B" : "R"} ${size} Tf ${x} ${y} Td (${pdfText(text)}) Tj ET
`;
  }
  function jpegSize(data) {
    if (data[0] !== 255 || data[1] !== 216)
      return null;
    for (let offset = 2;offset + 9 < data.length; ) {
      if (data[offset] !== 255) {
        offset += 1;
        continue;
      }
      const marker = data[offset + 1];
      const length = (data[offset + 2] << 8) + data[offset + 3];
      if ([192, 193, 194, 195, 197, 198, 199, 201, 202, 203, 205, 206, 207].includes(marker)) {
        return { height: (data[offset + 5] << 8) + data[offset + 6], width: (data[offset + 7] << 8) + data[offset + 8] };
      }
      if (!length)
        break;
      offset += length + 2;
    }
    return null;
  }
  function readJpeg(imageBytes) {
    if (!imageBytes?.length)
      return null;
    const size = jpegSize(imageBytes);
    return size ? { ...size, bytes: imageBytes } : null;
  }
  function time(value) {
    return new Date(value).toLocaleTimeString([], { hour12: false });
  }
  async function createInspectionReportPdf(input) {
    const evidence = input.items.map((item) => readJpeg(item.photoBytes));
    const pages = [];
    const vehicle = [input.vehicleInfo?.ModelYear, input.vehicleInfo?.Make, input.vehicleInfo?.Model].filter(Boolean).join(" ") || "Confirmed vehicle";
    let ledger = line("ACME FIELD SERVICE", 42, 750, 17, true);
    ledger += line("DVI INSPECTION REPORT", 42, 730, 11, true);
    ledger += line(`${vehicle}  |  VIN ${input.vin ?? "not available"}`, 42, 715);
    ledger += line("#", 42, 690, 8, true) + line("TIME", 62, 690, 8, true) + line("APP", 112, 690, 8, true) + line("EVENT", 166, 690, 8, true) + line("DETAIL", 270, 690, 8, true) + line("HASH", 495, 690, 8, true);
    let y = 675;
    for (const [index, row] of input.audit.entries()) {
      if (y < 70) {
        pages.push({ content: ledger });
        ledger = line("DVI INSPECTION REPORT - CONTINUED", 42, 750, 12, true);
        y = 725;
      }
      ledger += line(String(index + 1).padStart(3, "0"), 42, y, 7);
      ledger += line(time(row.time), 62, y, 7);
      ledger += line(row.app, 112, y, 7);
      ledger += line(row.event, 166, y, 7, true);
      ledger += line(row.detail.slice(0, 42), 270, y, 7);
      ledger += line(row.hash, 495, y, 7);
      y -= 17;
    }
    ledger += line("Actor: Technician  |  Stored in the shop's own hard drive", 42, Math.max(45, y - 8), 8);
    pages.push({ content: ledger });
    input.items.forEach((item, index) => {
      const image = evidence[index] ?? undefined;
      let content = line("ACME FIELD SERVICE", 42, 750, 15, true);
      content += line("DVI EVIDENCE", 42, 730, 11, true);
      content += line(item.label, 42, 705, 13, true);
      content += line(`Result: ${item.value || "Not recorded"}  |  Status: ${item.status.toUpperCase()}`, 42, 687, 10);
      if (image) {
        const scale = Math.min(500 / image.width, 560 / image.height);
        const width = Math.round(image.width * scale);
        const height = Math.round(image.height * scale);
        const x = Math.round((612 - width) / 2);
        const y2 = Math.round((650 - height) / 2);
        content += `q ${width} 0 0 ${height} ${x} ${y2} cm /Im${pages.length} Do Q
`;
      } else {
        content += line("No photo attached to this inspection item.", 42, 640, 10);
      }
      pages.push({ content, image });
    });
    return assemblePdf(pages);
  }
  async function assemblePdf(pages, rawTranscript) {
    let nextObject = 4;
    const pageRefs = pages.map((page) => {
      const imageObject = page.image ? nextObject++ : undefined;
      const contentObject = nextObject++;
      const pageObject = nextObject++;
      return { imageObject, contentObject, pageObject };
    });
    const objects = new Map;
    objects.set(1, bytes("<< /Type /Catalog /Pages 2 0 R >>"));
    objects.set(2, bytes(`<< /Type /Pages /Kids [${pageRefs.map((page) => `${page.pageObject} 0 R`).join(" ")}] /Count ${pages.length} >>`));
    objects.set(3, bytes(`<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica ${rawTranscript !== undefined ? "/Encoding /WinAnsiEncoding" : ""} >>`));
    const boldFont = nextObject++;
    objects.set(boldFont, bytes(`<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold ${rawTranscript !== undefined ? "/Encoding /WinAnsiEncoding" : ""} >>`));
    for (const [index, page] of pages.entries()) {
      const refs = pageRefs[index];
      if (page.image && refs.imageObject) {
        objects.set(refs.imageObject, await joinYielding([
          bytes(`<< /Type /XObject /Subtype /Image /Width ${page.image.width} /Height ${page.image.height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${page.image.bytes.length} >>
stream
`),
          page.image.bytes,
          bytes(`
endstream`)
        ]));
      }
      const stream = bytes(page.content);
      objects.set(refs.contentObject, join([bytes(`<< /Length ${stream.length} >>
stream
`), stream, bytes("endstream")]));
      const resources = refs.imageObject ? `<< /Font << /FR 3 0 R /FB ${boldFont} 0 R >> /XObject << /Im${index} ${refs.imageObject} 0 R >> >>` : `<< /Font << /FR 3 0 R /FB ${boldFont} 0 R >> >>`;
      objects.set(refs.pageObject, bytes(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources ${resources} /Contents ${refs.contentObject} 0 R >>`));
    }
    if (rawTranscript !== undefined) {
      const streamId = nextObject++;
      const fileId = nextObject++;
      const raw = bytes(rawTranscript);
      objects.set(streamId, join([bytes(`<< /Type /EmbeddedFile /Subtype /text#2Fplain /Length ${raw.length} >>
stream
`), raw, bytes(`
endstream`)]));
      objects.set(fileId, bytes(`<< /Type /Filespec /F (verbatim-transcript.txt) /EF << /F ${streamId} 0 R >> >>`));
      objects.set(1, bytes(`<< /Type /Catalog /Pages 2 0 R /Names << /EmbeddedFiles << /Names [(verbatim-transcript.txt) ${fileId} 0 R] >> >> >>`));
    }
    const totalObjects = nextObject - 1;
    const parts = [bytes(`%PDF-1.4
%ÿÿÿÿ
`)];
    const offsets = new Array(totalObjects + 1).fill(0);
    for (let id = 1;id <= totalObjects; id++) {
      offsets[id] = parts.reduce((total, part) => total + part.length, 0);
      parts.push(bytes(`${id} 0 obj
`), objects.get(id) ?? bytes("<<>>"), bytes(`
endobj
`));
    }
    const xref = parts.reduce((total, part) => total + part.length, 0);
    let trailer = `xref
0 ${totalObjects + 1}
0000000000 65535 f 
`;
    for (let id = 1;id <= totalObjects; id++)
      trailer += `${String(offsets[id]).padStart(10, "0")} 00000 n 
`;
    trailer += `trailer
<< /Size ${totalObjects + 1} /Root 1 0 R >>
startxref
${xref}
%%EOF
`;
    parts.push(bytes(trailer));
    return joinYielding(parts);
  }
  function documentLine(text, x, y, size = 10, bold = false) {
    const extra = { "€": 128, "‚": 130, "ƒ": 131, "„": 132, "…": 133, "†": 134, "‡": 135, "ˆ": 136, "‰": 137, "Š": 138, "‹": 139, "Œ": 140, "Ž": 142, "‘": 145, "’": 146, "“": 147, "”": 148, "•": 149, "–": 150, "—": 151, "˜": 152, "™": 153, "š": 154, "›": 155, "œ": 156, "ž": 158, "Ÿ": 159 };
    const encoded = Array.from(text, (char) => {
      const code = extra[char] ?? char.codePointAt(0);
      return "\\" + (code >= 32 && code <= 255 ? code : 63).toString(8).padStart(3, "0");
    }).join("");
    return `BT /F${bold ? "B" : "R"} ${size} Tf ${x} ${y} Td (${encoded}) Tj ET
`;
  }
  async function createDocumentReportPdf(input) {
    const pages = [];
    let content = "";
    let y = 0;
    const header = () => {
      content = `q 0.698 0.133 0.133 rg 0 700 612 92 re f Q
` + `q 1 1 1 rg
` + line("ACME FIELD SERVICE", 42, 752, 18, true) + line("DOCUMENTATION REPORT", 42, 728, 11, true) + `Q
` + line(new Date(input.createdAt).toLocaleString(), 42, 680, 9);
      y = 653;
    };
    const flush = (image) => {
      content += line(`Acme Field Service  |  ${pages.length + 1}`, 42, 30, 8);
      pages.push({ content, image });
      header();
    };
    const paragraph = (text, bold = false) => {
      for (const rawLine of text.split(/\r\n|\r|\n/)) {
        let rest = rawLine;
        do {
          let count = Math.min(54, rest.length);
          if (count < rest.length) {
            const space = rest.lastIndexOf(" ", count);
            if (space > 20)
              count = space + 1;
          }
          const part = rest.slice(0, count);
          rest = rest.slice(count);
          if (y < 65)
            flush();
          const utf16 = "FEFF" + Array.from({ length: part.length }, (_, i) => part.charCodeAt(i).toString(16).padStart(4, "0")).join("");
          content += `/Span << /ActualText <${utf16}> >> BDC
` + documentLine(part, 42, y, 10, bold) + `EMC
`;
          y -= 15;
        } while (rest.length);
      }
      y -= 9;
    };
    header();
    paragraph("SUMMARY", true);
    paragraph(input.summary);
    paragraph("VERBATIM RECORD", true);
    for (const record of input.records) {
      if (y < 110)
        flush();
      if (record.text !== undefined) {
        paragraph(new Date(record.at).toLocaleString(), true);
        paragraph(record.text);
      } else {
        const image = readJpeg(record.photoBytes);
        if (!image)
          throw new Error("A document photo could not be embedded. Please retry the report.");
        if (y < 275)
          flush();
        paragraph(new Date(record.at).toLocaleString(), true);
        const scale = Math.min(528 / image.width, (y - 65) / image.height);
        const width = image.width * scale;
        const height = image.height * scale;
        content += `q ${width} 0 0 ${height} 42 ${y - height} cm /Im${pages.length} Do Q
`;
        flush(image);
      }
      await yieldToHost();
    }
    if (y !== 653 || !pages.length)
      flush();
    const transcript = input.records.map((record) => `[${new Date(record.at).toISOString()}]
${record.text !== undefined ? record.text : "[Photo attached in report]"}`).join(`

`);
    return assemblePdf(pages, transcript);
  }

  // src/background/debug.ts
  function debugLog(...args) {
    if (false)
      ;
  }

  // src/background/ttsTiming.ts
  var TTS_VOICE_SETTINGS = {
    speed: 1,
    stability: 0.95,
    similarity_boost: 0.7,
    style: 0
  };
  var DEFAULT_SPEAK_OPTIONS = { voice_settings: TTS_VOICE_SETTINGS };
  function withDefaultVoiceSettings(options) {
    if (!options)
      return DEFAULT_SPEAK_OPTIONS;
    return { ...options, voice_settings: options.voice_settings ?? TTS_VOICE_SETTINGS };
  }
  async function speakWithTiming(session, text, options, onState) {
    const logText = Array.isArray(text) ? text.join(" | ") : text;
    const startedAt = Date.now();
    let warmed = false;
    let playingMs;
    const unsubscribe = session.speaker.onStateChange((event) => {
      if (event.state === "loading" && !warmed) {
        warmed = true;
        onState?.("loading");
        debugLog(`[tts] warmup ${Date.now() - startedAt}ms "${logText}"`);
      }
      if (event.state === "playing" && playingMs === undefined) {
        playingMs = Date.now() - startedAt;
        onState?.("playing");
        debugLog(`[tts] playing ${playingMs}ms "${logText}"`);
      }
    });
    debugLog(`[tts] start "${logText}"`);
    try {
      const speakOptions = withDefaultVoiceSettings(options);
      const result = await (Array.isArray(text) ? session.speaker.speak(text, speakOptions) : session.speaker.speak(text, speakOptions));
      debugLog(`[tts] done ${Date.now() - startedAt}ms "${logText}"`);
      return result;
    } finally {
      unsubscribe();
    }
  }

  // src/background/controllers/DocumentController.ts
  class DocumentController {
    session;
    mode;
    snapshot = { entries: [], liveText: "", capturing: false, generating: false };
    sequence = 0;
    generation = 0;
    photoUtterance = { text: "", checked: "", triggered: false, busy: false, final: false };
    intentRequests = new Set;
    intentTasks = new Set;
    introTask = Promise.resolve();
    photoSpeech = Promise.resolve();
    captureTask = Promise.resolve();
    reportTask = Promise.resolve({ success: true });
    summaryRequest;
    photoKeys = new Map;
    reportKeys = new Map;
    ui;
    constructor(session, mode) {
      this.session = session;
      this.mode = mode;
    }
    start() {
      this.ui = this.session.ui;
      this.ui.onOpen(() => this.publish());
      this.ui.on("document:request-snapshot", () => this.publish());
      this.ui.handle("document:generate", () => {
        if (this.mode.page !== "document")
          return Promise.resolve({ success: false, error: "Start Document mode first." });
        if (this.snapshot.generating || this.snapshot.capturing || this.snapshot.liveText.trim())
          return Promise.resolve({ success: false, error: "Wait for the current recording to finish." });
        this.reportTask = this.generate();
        return this.reportTask;
      });
      this.ui.handle("document:share", async ({ reportId }) => {
        const key = reportId ? this.reportKeys.get(reportId) : undefined;
        if (!key)
          return { success: false, error: "This report is unavailable." };
        try {
          return { success: (await this.session.blob.share(key)).success };
        } catch {
          return { success: false, error: "Could not share the report. Please try again." };
        }
      });
      this.session.transcription.on((event) => {
        if (this.mode.page !== "document")
          return;
        const utterance = this.photoUtterance;
        utterance.text = event.text;
        utterance.final = event.isFinal;
        this.schedulePhotoIntent(utterance);
        if (event.isFinal)
          this.photoUtterance = { text: "", checked: "", triggered: false, busy: false, final: false };
        if (!event.isFinal) {
          this.snapshot.liveText = event.text;
          this.ui.send("document:live", { text: event.text });
          return;
        }
        this.snapshot.liveText = "";
        this.ui.send("document:live", { text: "" });
        if (event.text.trim()) {
          this.snapshot.entries.push({ id: this.id(), at: Date.now(), kind: "text", text: event.text });
        }
        this.publish();
      });
      this.session.input.onButtonPress((event) => {
        if (this.mode.page === "document" && event.pressType === "short")
          this.takePhoto();
      });
    }
    async activate() {
      await this.session.mic.setLoudnessGateEnabled(true);
      this.publish();
    }
    speakIntro() {
      if (this.mode.page !== "document")
        return;
      this.introTask = speakWithTiming(this.session, "Documentation mode started, just speak and take pictures to start documenting.").catch(() => {
        console.warn("[document] startup speech failed");
      });
    }
    async deactivate() {
      this.generation++;
      clearTimeout(this.photoUtterance.timer);
      this.photoUtterance = { text: "", checked: "", triggered: false, busy: false, final: false };
      for (const request of this.intentRequests)
        request.abort();
      this.summaryRequest?.abort();
      await Promise.allSettled([this.captureTask, this.reportTask, this.introTask, this.photoSpeech, ...this.intentTasks]);
      this.snapshot.liveText = "";
      this.publish();
    }
    schedulePhotoIntent(utterance) {
      if (this.mode.page !== "document" || utterance.triggered || utterance.busy || !utterance.text.trim())
        return;
      if (utterance.timer) {
        if (!utterance.final)
          return;
        clearTimeout(utterance.timer);
      }
      const generation = this.generation;
      const current = () => this.mode.page === "document" && this.generation === generation;
      utterance.timer = setTimeout(() => {
        utterance.timer = undefined;
        if (!current() || utterance.triggered || utterance.busy || utterance.checked === utterance.text)
          return;
        const text = utterance.text;
        utterance.checked = text;
        utterance.busy = true;
        const abort = new AbortController;
        this.intentRequests.add(abort);
        const timer = setTimeout(() => abort.abort(), 4500);
        const task = (async () => {
          try {
            const response = await fetch(`${enterpriseBackendUrl()}/api/document/photo-intent`, {
              method: "POST",
              signal: abort.signal,
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ text })
            });
            const decision = await response.json();
            if (!response.ok || typeof decision.takePhoto !== "boolean")
              throw new Error("Photo intent failed");
            if (current() && decision.takePhoto && !utterance.triggered) {
              utterance.triggered = true;
              this.takePhoto(true);
            }
          } catch {
            if (current() && utterance.final) {
              this.snapshot.error = "Photo voice commands are temporarily unavailable. Your words are saved; use the glasses button to take a photo.";
              this.publish();
            }
          } finally {
            clearTimeout(timer);
            this.intentRequests.delete(abort);
            utterance.busy = false;
            if (current() && !utterance.triggered && utterance.text !== text)
              this.schedulePhotoIntent(utterance);
          }
        })();
        this.intentTasks.add(task);
        task.finally(() => this.intentTasks.delete(task));
      }, utterance.final ? 0 : 250);
    }
    id() {
      return `document-${Date.now()}-${++this.sequence}`;
    }
    publish() {
      this.ui.send("document:snapshot", this.snapshot);
      this.ui.send("document:live", { text: this.snapshot.liveText });
    }
    takePhoto(announce = false) {
      if (this.snapshot.capturing || this.mode.page !== "document")
        return;
      const entry = { id: this.id(), at: Date.now(), kind: "photo", pending: true };
      this.snapshot.entries.push(entry);
      this.snapshot.capturing = true;
      this.snapshot.error = undefined;
      this.publish();
      this.captureTask = this.mode.withCamera(async () => {
        if (this.mode.page !== "document")
          throw new Error("Photo cancelled when leaving Document mode.");
        if ("data:audio/wav;base64,UklGRrqpAABXQVZFZm10IBAAAAABAAIAgLsAAADuAgAEABAAZGF0YSCpAADE9t/2/gADAc0FpQVt9cP0ue4X7vP3evdfBR0FYQyWDN8Ovg9tEn8TjBQ7FSAWkxaCCJgIrvHc8Gj1YfSsCVoJCQQKBPLwwfBQ/ZP9vQxFDfTzgPON4qnhsPfD93gBwAFM9wb37AIzA44QixFC/af9LO0G7Sn8VPzoCOAIXv5N/X/z8/ER9AXz6vV59XH+cv6hFEkVriSSJXsV+xWX7jbuvNax1RntEuw5GMYXWRkRGSz20fXh7dztHwMiAxUGOgUX9a7zqvbF9Z0BzwCC96r1XPCI7lP/7/7TCgILfA1eDcYaRRsdH1ggiwCMAA/oRuY470/tAeoa6NvVSdNa3xLdk/qy+RgHSgdXEAIREB69Hu0keCUQGTIZufOU8orZL9eQ78DtrgUhBdzyEPKR9Nzz2BlPGuIS5RLd7kTtzPaU9acNag1TBJEDWfM78rz3mveMA2MD7fi+9yzb59lP26TapwYGBmgZsxhp/xv/B/sC+5QKQwpn9HzzudhY1xvst+pUAxkCePdq9n3w+O/cCvQKOySHJGAVeBWk9Vf10vOY83YBYQHC/Df80/fC9mL8qvsj8cDw6eb45ZX7j/oiDygPHgT3BN34mfk0BtMGGxYbFwsNqQ3u6Nzn+siwxg3TItLn9VL2cQjmB4kQaBBBF8UZog4REOEC5gAkBJIDXwFqAzL6APolBL4CvQ0pD+r7H/0z4SjflNr/2Lzpf+q8/AX9qAVMBa8KmwsmD+MQhA6pD24NtA1TCxsLewO4A1T5hfl98lXx3vPU8tr5jPrj+jr71/jc9678qvyaAMABLfyJ/JgB0QFcFtUX3BihGvEEAwbT+z/8pfdL99Pg+t8+0cPPa94X3H3pu+e86kfrSgcRCSI3qzgoRYhHYihrK2cCPAPI7ojtL/LF8STxD/HC4VDgveG94H3t8O1U7vvtGfI68awAPwH5DFUOKxpyG1EkMiZqEiUUvvEv8hfq8+ky6onpFtdS1QLVrtNp9ov2QRSvFE8fFiBeJUknEB7KH3UE4wTE877zqvnd+S78QPyh7Vbt/eWS5dzuy+7O9jz3kfpZ+0b9hP6k/Qr/ogZWB1gQbRAG/nr+xeh66YH7tvvWC2MLdPK58YnsfuxSE8oU6x0GIM3/+AB5/+z/jxhGGYAFEwZ54LHg6u+s8PsEawVi5y3mM9153BwF8wZGCg0MlOsh61f49fcbEeURDf9u/0T3pveDCtQLyApoC+EQmxC4JIMlQgytDcjkJuWC8U/wJRAJDvEP5g5U+Fr5ruLB4wLyhvGtGAMYnRTEFGHuO+9D5VbmCfYf9ngBJQCOBngFWxL/EmQoBCuYHxUif+mK6JzUmtCf8EHtvO6S7WXgreBSB1kIYTRGNe4mTCe0/y8Awvb493MFxwYgA2cDlO+T7j/wIe9YBDoEsv/I/w3m7OQR7CnqAwwNC84UdRU6DZ4O4h0WH0M1/DVXDAoMV7i0tmS6irnzCP4JEhN9E9HqEerm/aL+oR2QH5IIegl198P3YgFvATj6gPhZ8djux/0s/V79LP7t9VD27v/V/6MDUgMZDm8O0C8FMoAuwzHQ/RQAjtqJ2mnf09wp+174PgKvAcTp5eqX8fbycBe9FwYQzQ22+uL3PxKBEgMk6Cb7FakYfAzaDYb+7P0B6OXlGeMA4jTiB+OO4H7h1PKb8rQAE/8Q/tX7PA7dDXYhsiPZDdYPEfa09f4EpAMXDvMMyupC6WzVntQr+aH6chP2FIf63vkl+DP4LxxRHmwWIhcl/Uz83gknCpwNhQ0T+6H5DvCX79rc8dyx3MzbdwTGA0EF8QSQ3mHe//S89pEnhSqKGQgb2fpj+8MFOQYdDmENW/kv+Kvrkesg8ffwrfAJ7xvu4utmCW0IUTUXN4gvKDP0+/n+aOkZ63f0DPRP9z70igFK/7UD0gTN8uz0d/rG+9gXOBliGCQYAQp0B20WxRU+FIcW1Oaf50HTn9IV9Kf0bQvfCuMHowUZE6UUASQiKW4YyhpfDaAMURXWFB4JaweF6gLnWujg5nnz4PRY6Fzpzezo7EgQYRD+G3IckQrgCzcHqgg6EBIRyAtxDY8EQwaDB9YF0/u8+NHcedz+2c7ZewhDBj0paClwDlIR+/lv+nYamBksJTInPvfv+dXemd+T8nvzzfnQ+lTrY+rD5aDjkPsL+oMaHRq7FrIXkgJuBDEWXRc+MhAzBBH9ETjca9tU4ljgvfS/9A/cPt3p38Pf9CbgJwBIYkujDdYP7uph6xMQXRGgEDEQ0tb+0iDAn70v5Z7lGhb8FbkjGCQYAacERu4H8g8NjQ1VCmgJ/ORe5Qj2D/dYIc0hlSjsKV8OKxAY6s7pI+b65Pv9X/2d/Ar7uPHp8OMGCQkRF6IY2AI3AvjyafQ6AlgFKhzkHIQV6hV56tXsmuUs5uwIKQYG9/T0dsqHyhHqsemmKTIpvSkCLE8LSw4BAeoAJPjy9tLleeYJ1cvUzd6x3AAN2A0ZKVwsZhCKECoBJwBOHHIeAhu8G1vzoO+R8dbvxQMrBfLpU+jn0dvOEfpx+/go0ioSF7UUL/gF9+8IYwy5HaIfHxQIElsNbgyVAdYBhtUr0lrHVMKR+Ff3ERoqG4YR4xC3DgcNvw/QDw4HkwgoAyMDDflY9hbnUuUS6xHshvvj+jUCQP62Bw8GexAhE24cDB7GHYYbF/0t+hzbmdrN6W/q2wXdA0EChP08/DP7wf35AvX2J/rnATX9gB/rGtIfpyP5AOUG1fFh8CPuQ+iL3lLcxOlz6xIIEAi0+an1b+p952MT4BYAKEgt4go8CWUPQwmjJxAn4guXEcjr5O68/w/9DAyHCDDrsekF4czg5wTrBSUU0BS49ObyP9lA14nwx/HHHDgeoh1iGyP9pfv39bv5sAXiCdf/Hf5R7jDp3Pzy+m0bhx6nE3oXuPT59Pj1P/NCBUgDzf4E/6Hroeuq5Mzi/AQvBCEl8CZAFYEX3QSHBh0HIgf2AG7+PAFyAI/+lQE75aTlb+Ku3Zb9QvvJ9dD3gONV4l8PIgvhNWA3dwoNEXvjTeVJ/BL3fgm9BILx9/EF4B/iV+Aj4NT0EvTbEu8SKxxUGu8Ljwhy+8j7ZgQOCUYauhu8GN8TUfn29F/eMd8j5zvprv4k/2b7tvt55bvkk+9w7KAXRhadHeYgBgEXBNv+ff3cEwUR6wooCmrvbe+u+Ar4SRNSExMEJQUp2uDZatJ4z9v06/H/D0oQIg7XEFIHNQlnBbEFHAL2ARADKgLgC1oJ6AtnCa/+Sv5z80b0u+jn5xrlCOIx+Yb2XAqHCXL+sP7995H4swjLCfALggz6CBcIFxkOF40TQBFF9Q30/PSq9SYBuAE75y/l/cbBwkTaDtZ4Cy0Jfx0RHrgGxgke8PrygPvc+3wXshUUF0UVovYC9nngvuA57VvtVwNmApAE/wHl/aj6RAmcB/oVzBbLD6URmg80EREUrBSP/pr9R+mj55Htk+zd843zV/fO9239j/5JAfcBegIzAlTz7PGu4C/eLvGW7ksFsANb8hrybvHB8t0jfyUhO4Y6CRUJE2jig+EYx6XG7Nv62hEM0gt8G1sbFROdEasSHBEH/AT8ic7IznLWFdXBFssUqSr+KXEBJQLJ6y3s2vvY+qUDLwIMAH3/xhCiEd4h+SN8DJAOKvCK78/7B/g1DQ4Ky+mZ6gS7QL1p2QjZLjDCLURU0lLhKKUptv5oAR7x6/Nd0YDQTcnHxPn/OPwtKsApeyhoKgQQ1hHS4JLf88R2wQ33LvbhQ4pGrEFqQ8IUrBSD+p76GdFB0ILGDMWm9bP13w7lDoYEPAKJ/m384hS6FsofiiN+9aP2JdRx0mHcxNmr9FLy0w/rD9UVGRneEIwUyRx2HlQr1isEG+AbKewf7afQMtGw15fXdOy46woQtg+5KYUq4hxjHiQC0gNr+bT66v9IAAoHEwc8C5sL8vfH9yLT4tHfzz/PdOyU7I4N/gwzH50etgj7CHDmFOZ35qjkewo2CUkUThSN5zjnJ+f+5sgl5ibkOhM8RhPRE0HojOjo4dPhCvjs9zwDjANo867z7PAc8X4ZkxqmKZkqXgTKAyftWuxZ70bvo+0X7fvomef37//u1wrKCkQb1BrVB0kGy/n1+HYGXAdHDeoNph1yHc0zEDUfFE8WwNU41tXDNcPl7fvuBQwgDsj2yvebBl0ItzpqPkUvDzK/+6r8tt8h4FLhWOGI8NnvNPR084jsRewP/Hn8DTBVMcdElUXQFBMU9+hA6I7gIeAz6ALmdPlh9pf5S/jQ35ffsMYnxQTk7OJ8KBMqvSUVJ8r8bPyuBVwGzfy7/jXSOdMM2tPa5BsHHmdPglJjPUpAOQYZCMX3wfhfHuYeRySbI5/rBelXyfPGrdQB1DXnbead+N72bQ6oDTwbiBt9+E736NfK1d73nPcBEmESyAkICXoL1ApdCVYJL/KD8VrZ2ddB1OjSiuwK7HsY7xjjNK816TEFMycoECrIFDAXR/TV9X3rnOz6AG0C9g/yEBP9rPzb29HaxdXR1KLuG+15EVAPGh9RHb4BQQBd3pncP+BS3vn5M/h9B+YFf/9//v/38veyADsBhh66HwY+2j+cMAkyEgBYAAHc69tdztXN19Nz0ojq7OigBOkDLQw8DOEBSwLLBvEHkB9VIeYrcy3zFsEXbeuE61rL9cq+zCzM3OVx5W8EhwQGJuMmEkRkRaFFkUZ2JaIlBfyS+2Ddf9xV0jfRod0A3RX3gvd2D+cQuRaHGE0KDAzD/k0ANv8VAEkETgRZBfgEjPnq+HPqp+nu7DvsKgOSAkIahRl/IiIikhfsF4H7uPvr9j33jBDoEQgDgQTc2a3aG9qA28339vnECpsMMg/vENkZTBzsKn8tlidVKWgRfhLP/of/5fO/85fifeEgyq3Ij8ZqxdHpIekyHhAepzoEO4czJTT2IHshiAVeBc3clNvnzUfM6umu6N4DAgOsAWwBp/uv/OcO+RDuL90x/DVEN90bBB2++L/5D9tH2yzWOdZB8h3zjRmqGmUqAisUFX0VmvH98S7q8+n/Ce0IoSIxIUsMwgrm6SXo9eP44XvuYeyF+db3aAQoA1AMEQs9CwMK4v9B/xv04/Ot8UzxY/dY9+/6Pfwa+jr8KAROBmIW4hhpHE4f2RXqF1EN3w0dBS4F6+sA7AvNcMwt5j3lMSfXJgo4ojcODxkOmN853jPJ1MeO0pPRVO7T7RQKKAr3GxgdghO2FYn0lvYU9af2uRxrHo0p7iqKDPQMRe1x7bbjQeRi6tHqB/IY8mf/2f+UC6oMggigCd4LAw0IH3UggCazJwoTYRPX9Qz12OMK4o7dINtb1DXRPM61ylPqd+cNFB8SFyBOHmMfZR47HaEdBw3TDe727fdD6V/rwunM7ATy6fR6BqAJ3Bu8H8sYDRx0GLEaZScPKYolFCaaEW0Qbv0T+zfuF+sx33vbC9VD0d7Yl9Xc7Cfqnw/NDQUlzCMaFgMVBvgl9/jmKebR6I3nNO+w7X3tYeyZ5c3kYO7b7XkV9xWZNhw4fz51QDw/yEFlMI4zIwpkDazm6+ng4BDkJvMD9jX+awA28onz8uI14yHoWOdo+rT4AAp2B2QXShThHlAb5BHLDd3sLOiNxoXBLr9nukXWUNL07FDq6/Y+9p79Df9CCt0M3SK9Jes04TcnIrEkIfCa8dnOCtDC5LDm5RIVFc80bzb+RPVGeiQvJuTjEORFzsfNPPFN8YAhxCEUOkQ6ljlqOqgnsShdB/sGj/Ty8njtO+v928PYntLtziLYAdXN3yndrOk+5wz2PvSq+HP3EOvb6U/xs/CUFRYW3Si4KXUkmSUMHAYelRGzE2UM/w1YDt4PggzmDbv+eP/T7N3s3tuw26fUJdSy7Ffs1wr4CicLiwtQAT8C9AZOCHMWGhc2GO4XDwPBAgjglt+7ycnIgeM240sQOxEhIdQh+B/rH9IVfhXJAtIBs/Wc8/z6fPgzDFkK5hCZDz0J/gdVCDUH2gMSA0zskesb2V3YJej359sO/Q/ZK+wtOCmPK5UTDhZt/NH+o+L941rca9y/9En04wjbB74IDgerBqIE9w3dC2wZNRemHD8aChGUDjP9xPoX5I/hYso4x33GCsNC1sTSs90z2tfa1tfL4yHiPgeJBpg0KzSKR1dHlx8ZH/3Nb8yGoMee3rBMsIPdcd7YGBIcMlI8WA102Xsie/9/mXAceHNWSFwVLVIwewi/CXXlKOV1xFLCG8f7w5XfJdzD41Pf8820yLe497Nhvmi6Y9+521MW6RPePII8hyPuI6n0KfXX6f3q9/NL9eX4SvlP9Ar02+2k7SXsAuzt8cDx4gZzB3UjXyU2NBk3rjIcNoAdECFp98X60tBg0667AL0qvWe9qs9az5bn/eYj/MD6nRaVFPM1bDO/PzA8di9pKncSuwwg76Lp+tL6zZzN1Mk84rLgZP+DAB4WXRmNMJM1WUy6Ul1QL1eYNac7yw53EyXwN/N14AnibNuD23TegN2i7ZTsY/16/GYESQNyE10SzSL+IW8WZRV68/7xq9IO0fHFN8QPz9jMkt/q3InoieXb5rXjXeMM4BTrmec+A+T/pRSpEQsDMQAo2rDXBMDTvg7Nuc2a9/D5rCzkMClYSF4JW6lhvj1gQ2Ij8CftEBUUewLWA/j4APnP8ljyh/K28dL6MPlMCMwFmA7QC8n9C/vh3i/cWNxm2o4AJwDxIHohBx5LHon+mf7g3PHcMcZ4xXjKIcnZ9zj3IiMZI10p/ihoEgsSA+HU4Jy2LLZywT7Bhfdg+BkiDiQuJfQnPhi6GzsMVA9eBoII2gVaB0v6+/oP8aPwH/1i/OAN8gz1Dg4NPwU/AkwAF/0L9rPyEOd+43fvn+xABYkDzA2VDPwHFwfq+Gb4/+za7Gzzm/PoCY0KLB5SH4YgACJmEecSof6p/y/31/fC9nn3APPb8370kfU1A9sEbheNGZshcyOkHvQfAxMHFGrxyvFkyvHJg8fgxtfgA+CP9wP2FP9I/fD5Pvgt9jH0VwAn/v8TTxJME9QRjPi29j3ikOBA1CDTes6ezcTghuBNBG0F6yVVKOE5RT3XPt5CMzmUPXcs4jAAHMAfVQ0VEOkB6APx723xSeDY4NDqy+rLCvcKDyOOI7chpiGGGxob9BqFGi/7y/kwx2nEG7M2sOi7hrljzUjLueqP6YsU7hS/OhE8LENVRDAsMy15CG8J3udB6I3dpN1T5BTl4eZV6KjtqO+cBWMI1yBzJPwp3S3NJNkoeCK7JkkdIiEuEQQUJwANAp3hIeIjxDzDncAEv3vW+dTt+cP4iyEsIe1BdUJNSDhJXC79Lr4ECAWI34/fPc45zjXWudb/7qTwHw0GENIleSlbMC80TSvfLlIZBBzTAjkEYvXf9cjr6Ouf24Pb5dS51OXjQORu/Ur++BDZEZ0WfBeLEYoSCATZBEf3ifdA+zL7AAcFB3oDcAPQ8a7xa+d9597xQfLXCDUJWxZeFv8PDBAn+sL6md2A3pDXx9j59yf6QhkFHDoamxywAo4EYuoB7DHmZefY+G75cxcKGB0tJC7pJtsn+RF2EnQGrQZfAoQC0P24/Qj/3f7VCEcJahCSESIHmAhV8q/zqOpI7D3x2PLe9vD3hPxN/dD8wv1e9Of0DvP28ur+ev7cCkoKoAmBCMwBZgBE/wX+n/pS+Xj16vMe+6f5zgCt/6r7wfox8rDxaO+D70H3yfetAFIBTgAbAan1sfa87vXvS/rU+7MQfhI+HRAfqRgqGhgMAg1JApoCw/3R/YX/pf9mDNEM8yS8JQU37jfVK0csawgTCKzlheRk1LnShdWv02Lg3N7R7t/tAf1b/EkFzAToAmEC6vlE+Xj45PfJA4kDeA/HD00OHA/sASkDT/fH+A32wPdQ+x/9OAQCBi8UJhYyIvUjOh4+H6ELsQth8Z/wW9dz1YnKoscVzfbJ4Nbn027hc95j9dPypRISEbAh7iAoIA4gTxsOHL4TGhWSCA0KTPya/azywfMT8kbz9PyV/vML1g1pIaojMTzzPoE99T/zHEweIfLS8iDNes1vvkG+s9Fp0df6GPuwFzYYShR1FDcC4gGo99X2S/3A+0IK8AcQCB0FXPAC7cTSXs+QwxjAnM1+ykbwYe4pF+kWJCsGLAovJjGKI6gm3gYJCkzuzfCE5Y7nQ+X/5h7reuwB/fn90RukHF811zWUNEU0uR1OHHAFRANM8qDvxOOb4JDfK9wj5Tji4+2M64n1nfNhAxsCGRjfF3cdoh1GE1QTRgoyCgX8ePuA5gPl6Nb31EzVsNMs4UnghvWx9aoOLRCiJjUptjOnNg8rvC0gDCsOyeg76vPV1NYd3YHdofYB93oQ9xArGzEbPRZGFUIMnwpx9eXylNbf0ifRTM2x46XgcvVK84UAYf/sCEAJNBJ3E6AYEhqTF+sYcwiwCX/zevQF7/nvVPkr+hEG5AblD+cQHRTkFKkUqxRlEjsSQwlICaf1KvV39MrzaA2DDWoMkwzS82XzJu3r7P/y8PIa+WH4MP/+/d4DsQJ1/sH8s+487NXjGuFo3p3bS99y3JrrKunM+hL5lQWwBBIM5wtGEbERYRU4FqISwBOgAacCuu167i3t4e1L+rH6SwZTBoILyAvfCmALhhK+Eswk4iQLK/IqwQ6kDT7j9uAq0ubPwdsa2u/ute0ABQgE0BJkEpwWBxfhFsgXXROlExsJlghL/Xj8lfHI79vldeIK5Wfhi+sA6ffyG/FBAq8AZxAeD94RIhEdEf8RQR0iIMspnSyIF04YW+6i7fTTgdLK1RLTnehN5bX7svlABJUDzARQBMcC9gH3/aT8B/hg9l7ywfAC8gTw1/2p+zgJAQi2B3MHHgWMBG0KDQrQESQSVBb2FQIZ7xdQFwwYkBH2FDQLPQ+8+0T90eOW4c7YOtWF5SzkcwDyAI4ZShooK8osWzSXNksoCil0/yb/CdIv0grGPsYZ3wnfDvun+y8DQgQcAzkEXg8FEIMiziCcIqEeNQu/CPXxlvLJ5IjmPuIE5knmxe1n7lj11fzL/RsOBgt8FZsTZxP2E0YQrBANDV8KrAe1AhH2VPSU1lHb/MbezRfZL96F88f48AYjDMoeyR6pMA4scSxlKhMbSB0gAmgCSunQ5K7p2+ahAsUIYRRoIegRyhzYBpELMwKtAp0F7gDR/EfyFuYL3SrhUOAL7iHyEe/78uzqJ++K9Yz62gQUCLYLNws5CJEFRf0q/M36n/vIBQAFUAfmBZf5y/uG97v7ewlIDHcWLRtYECUZYQKJCTf3sfZM9MvsIvqc8Nf52vJX7fvr0ukK74D2DwAp/4oI6vhy/g7sHOxN6HLkyPYF89oLGAgWGQUTdRysGA8SBxeNAUkLF/7ABM8EzQeJDWkQoRi2HOASJBZL+Of2CuqU5BLyLO1W/k77BQW6AuH6Hfzg6ZfvEfIO+NkG5QrBBd4HwfqG+Pb5TvS7/m36EwVYAh4I3gXmBMoGEgKrB/b7UQHT8735I/g//O79k/mG8/nqjeqt5eLwAO1m94z0gPnf/d8BOQmvC+MOfgpsDLADvgVPA08DjwaFB04JpAo5DxALNRG8CsoIPQcbBCsG9AY9CkIBGQfK9eP7RPh/+qkI+AaYEEwNoP/I/JvhLd7bz+HIcdU9zpvvzu9HELsV8B/lI0Qbwx7qEeQVYQZ/BeT2cvEg7BrnvuqZ5s/xk+9I+4n9gwDFA/sKPQzwG9odZhv6HS8IAAn2+zP74Pje9Wry/+2b6qTp6uiX6oP0hPJdCjIHaxcYGjgU/RmfC/gNdAN5A6L7cfuZ9gXz6Pa58In81vprAcUESAKWA7kGyQWOEYkUcxe+HBwM4gxw83rwxeUC5Zfx1/JEBJwDIgsjCSMK/AmMCRALOQurC/IEgQPy7krtTd323Efiy+G287XxVAeAB0QTyRhxDDkSKQPUApsDgP9z/lX8ePf99qf4jfbQ9j/1SPi8+xAEcwm8CNQJVw1oDAQdCyAnGwkgev8AAP/mUuJA4NXbGu1c7G8ADP/MAE/8Af11/RQOhhY8G0IhlxE2EpkGRQm5AI4CJPa97gPsEuEw7ZLpLP6lAc8TShhYGOAbIw6rEYIJTgxoCmIKqgTRAu75svio8S3vH+x35VnqdOKv9DDxnAfdCrcPHRcnC74QzAZkB53/Sv639uH1uPfs9M33c/J38R/sv/ip88YFAgKMA7gFyAMlDHwQ6xcwEfkS/gJKAS35V/Z59VvwpfHt6HztweTD7t/rYf/TArkXdB3HHtUkGA67E136o/x79wH18wEq/HMJOAOQEB4OMh24HpMcPByWB8QENfQ99WHtBvOO8E72k/md/C35k/fU9VDw1QbgAf0VxhCwBmb+PfGk6zrpCuxW6VbwHfas+6wDKQfOAowElAcNBzsSGw9WC1IGqAbOAe0Sdw/XELIPiP6tAIX0JPfs7p7vXPA88+4BnAcCC7cLAgCj+fb5w/OQ/dn6tP6a+7gDX/6fCP0FLvszADXnUu6P55TnbPnT9KYJTwgKFBkW4RuHHr4bIB3yDTsKsvoa9E3zuvEC/AL/fgRtB7P+/gI98273dvfg9T0OWAmOGysZpApWCtnxEfOS7x/yB/yw+4wAe/xB+mL4ZPS39wz5av1zBN8D7wcGA30DDAJ9Af4ECf46/tnzEvAY7FHsRfFS9DMH1gaXHx4eIiBoIRUNnA8GAvgDJv+q/8r4zPf+9OL0R/ZZ97j4X/eq/nP6NwGU/iP6D/xW9x77Tf85ACsEUALU/b/7pe8j7Vfi3uAW427mQPer++YSrRFUIJccshP1ErL9xv0/9772YP0GAEwEpgo1EuIXEiECIzQZDRnX/vH/zey07Tzqreap8xDuEAUQBFsJHAyU93j4ZOpB6XPsDe2G7WzwHvF187P9jf3BBP0CPwRYApsCVAAg/ar7fgJiBHAaVh4/JOUm0BT6FiwIdwuRAYcErvda+Rj1z/Qm97HzzvGL7QPvtO2v91T4wAMYBNsLHwyICYMJCPyF+xzxFfJw8jL1+PgC+//5qfgD9LjuCezi5f/j0OGU5ZHnZQQNB8EzpDYiRZxJaS2GMdEOOxCS+Fr4F+RB46rd/ttI8dfv4gymDOwbwxvDHj0e0Rl0GlYOdhCkAXEEjfSN9v3k4+MM3r/Z4Oij5Bb7wPjJCpwKyheWGeYaGxzBCo8IHe8I7CjfA97P6Pno9Pu5/UIAPgPr++P6TQGm+2UJXwfOCWINBwztDSMTmRGqElATyQnVDEsCWwPx/J/7Vvm/+FABmQMfFBcYJxyIHb0MfAna8HXsXNaH01vJxsZV1CHSlO2b7boAEQIzDPsMMRO9E/IPwxC4CkkLqw5nDnEQNQ8uCAEH2P+ZACD/DwI3CzQPQSAOJEklcyfsEHYRp/6A/2L+KADAAl8DAQSHAmsFcgMNCFwHKAtGDLwHogk4+ET5weii6IXm1eUS7bzrjfXC8+j8r/tW/F/7j/Pu8Q7vLO0g90D2XwSSBBcG/gbw+yv9zfq4/DgGZghJCywM4A3bDNMX2hbcFD4VHQEWApr4Ufl//Vn9T/8o/gUArv5r/sn9tvae9mD3dvenBbcFfBEmEUwObw0d/ZX7je226+Tw++86AOIAuAs9DRASgBPBEv4T/AwyDp4JlgoPCzwLhAsJCzkM5guKDLMMggPLAxDy4vFT6N/nWO9D79v67/oo/nf9N/0V/Jf75Poj9CzzxOey5fHeItzv4oDgffbX9QcKmAt8DT0QOgsADhgRfxPHFiwYDxIZEgYG4ARJ+Yz3KPF978byBvIAAKcACA8UEUwQxBLgBKcGVvri+nTzofJh8Svvuvob+KYHeQXlCHQHIwGLACz9y/3//40BuQBrAsL5i/rj9Jr0hPrO+SIEZQPuDDwMQBObEhMQUw/wB1sHNAfMB0oIQgqRABUDJfcb+cT1hPZs+Z34jfo9+AL3rvPU8WLu1O4k7IPxHvDm+hT7AARlBZMENwbX/e/+TfdT9/H1v/Qw+hn4fgIaAH0KhwjPB6gGpvgh+KHv6+/v92X5HgQWBl0K+Qu9C5cMfQZJBv4A9/+6Bp8FcBLKEQoY8xfPFYoWDg+gEF4HiQnjAO4Caftc/ED3i/Z/82vxrvDd7W3xxO4j8grwHPE/7+rzYPJI9yD2MvRE88HwTfBV8nvygPbu9kb+m/71ByYINg4iDsQPqg/rDPMMOgldCTQKlwp5DCMNOAzzDBcLIwwiB3IISwGLAvz+AwDP/jH/4/9W/5MCPQGf/nr8yfT28Szxae5W80Dx2PV89JP6KPpG/qD+Af2W/dn6Ovs6+ez4L/nj9+3/IP7dCkUJPhFPEAoSLxLWERwTDxI6FIEQ/BIvDE4OfwflCCoClgJP+GP38OyV6mvqXufK8yLxDv5+/KT+Mf6D+eP5kPeF+MD5yvor/bD9s/5j/rH7dPrm9yP2pPkf+LUA/f89CrQK6hGWE5YRMRSjC64OiAenCh8HvgmuCksMdRAEEXMQ/g8xCRkIPQNVAoUCVAJdBPsEGAUsBm3/aQDW8i3zI+jD5+/nDOfD8H/vZPrH+HAAs/5IA+cBSgHEAJ77y/t3+UX6I/1R/hACTwOEBtoHwgk9CzEKmgssClELEQuiC0cKVwoXCPUH5AU/Bm0CZQPW/S3/4voR/Db6yfqA+VT5Qfd/9qrzkfJb7zvuue3B7JTzL/Ou/RH+twK4A2MCowPOA08FoQgzCggNgA5hD5oQZxCLERwQUxHjDD8OfQjdCeIGUwhJBr4HeQK5A/n98f7w+6L8+Po3+0/6B/qg+dn4PPci9qj0kvOn9N7zK/bJ9V/5SfmX/sv+iAC/APr79vsn99D2Zffz9sj6UPoL/5j+IAQFBCcJoQmwDOANoAw2Di0IiwmZA2QEjAK5As8BjgHr/37/ggBAACkDOwMLBB0EhwNkA2gCBgJF/8L+Bvt++g73kvan8w/zSvSU8wL7Wfr1AYgBpgRoBMIEzgTHAwUEIANuA58F9AXDCCEJtAbsBm3/XP9J+A34F/fd9u/8+vzVAgcDYgJvAsz+n/7i+5D7OPmv+Kb5/viE/wj/cAU5BaEFnQU4ACMATvn8+JT2//Xu+Er4Tfug+gz7dPp/+hL6EPvN+j/9BP0IAbsA+QOKA8ADSQPTAHoAeP5O/t7/AgDbAxoESwZ9BokFiwXoAuMC9AD9AFoBfwEqA04D8ATeBD0FAQXgAYwBtvxY/Mv6lPp8/Gv8uf+f/zgCFwI/APf/Xfv2+g/6r/nl+5T7jf0G/Yv/0/66/+7+q/zZ+4/65PmS+iv6FPut+jj95Pzx/qP+tvxZ/Mr5ZPl5+i/6sf6B/s0EyAQ7CWMJvQnvCY4HyAd8A5EDWf8l/yr+u/1o/gD+K/7F/Wb/Tv/WAOQA0P+8//L+if4d/5P+rv7+/QP/kf5YACEA6f/O/+3+vf4B/8H+lv5G/qj9U/1x/Tn9Cv7Z/fL/2f+RAogCdQNvA8QCtALbAckBtgCaAF3/KP80/vT9Kf3k/ED89ftJ+wb7zPp6+vv7svv0/bf9E//m/sj/o//j/9T/Df/9/ur/6v9MAnYCMQJZAqMAwgDkARQCmwPpA6UC2wJ/AakB0QH7ATMBTwFQ/0f/Y/0u/bP7QftK+9L65Px1/N79kP0y/eX8+Pyu/Ff9Af2g/Df8DvyX+1j9/fwj//j+YwBrAJ0BvwFmAp4CQwJcAt4B4gFMAj4CygPeA0wFfQUgBWgFgwOwAxYBCgF8/Rr9lfnf+G73jfax99/2Xvq5+QD+lf2s/0z/P//K/mD+zP2D/NL7YPqa+YX72Ppx/xD/CQPcAngFjgV0Bp4GLwVVBSYEOATqBPAELQUnBTIEDgR9A00DaAIrAsIAYQBSANj/GwGOAFkB0QARAZ4ADwC6/+X9hv3C/FH8nP4x/hwBsgABAYMA7P5C/oP9vvwW/kz9oP/c/oIAxP9pAMD/7/+C/1n/Ev9Z/hX+O/3P/BL9dvzQ/Sj9yf0T/SX9bPyr/vz95AFTAQcDdQJwAc8AGv+I/lL98/xf/Un9wf/5/zsCmAIKA00DKgIvAgEBswDVAWQB0gRvBH0GQAbDBaUF9wP1AzEBNAE+/jz+2/zE/HX8UvyD/G78+f0C/t3/8v/9APwAbwEzAXkAGwDH/mj+cv5B/qL/z/8AAsACKwV6BrUFJwc0AnADF//r/zX/yP/FACYBggGeAVgAJgD4/Z79cvsX+6/4RPhU9/32cfmB+fv7ZfyO+yP8s/pU+wr8h/wP/n3+N/+J/7f+2v73/PP8jPzL/K//VAA/BWMGAwq8C1ELYw0hCTcLrQWgB/cClwQxAlIDKQLyAtT/HwDb+ob6kfbV9Wn1mPQl9232cPn6+BP6AfoP+jL6zvo7+xX8vfyc/kv/sQJxA3QFUwZlBTYG2gSVBe4E2QXJBdYGqAcACQ4JrwoiB8kIrAL2A/r+IACX/Yb++vyH/VL8mfw2/DP86vt4+6n50fjq9s31mvZa9Y74nvc0+sb53/qt+gb8CfyL/dH9/P1L/nH+tv6bAB4B9AK0A1IENQX2BRkHxwbzB/0E9QXaAsIDgQJPA+gCpAPUA6wEIAUBBlsEBwWtAAoBjPyB/Iz6GPqG+w379/62/r0CvAIxBGEEEAJSAsv9tP1o+f74S/bJ9XL29fWA+kX6ef++/94CWgP8BGoF0AQyBd0BCAJg/0L/JP8S/zn/N//0/uj+wv6z/p/9cf1//A388/2J/VABGQGMA3EDZQNlA0kBXwEA/tT99Pp4+t75H/k2+1v6r/3O/Fr/tv4yALz/ngFMAY4DdgOQBGoEnQNOAy0BtwA8/qP9FP1k/Bf/pP7NAo8COgUSBWAFSAWhA5UDXAEjAd4AmABVAkMCpAOPA64DlAO9AqkCMgH+AJ8AXABNARkB9gC/ALr/Yv8v/9H+fP7//d79VP0A/5T+yf9r/2H+8v11/RP9bv0a/av8KvxJ/ez8xQC0AC0DQAOjAtYCxwEkAp0B4QFTAZIBzAEgAiEDggPCAiYDfwDeACcAgQCRAvsCsQMNBP4BEgIzAA8AY/9M//z+6/7a/8z/0QHzAXUCngIhAP//bfsN+133vvZm97v20vuU+6kBIwI+BvoGygeOCOwFpwbcAmQD9wA2AWIAtwD5AIABlQI3AywD1gPCAWsC2QAlAY8BdAF1AVMBqf+s/+r97v0+/Gf8GPqV+vn4afkn+h/61vyR/Lb/k//OAcsBUgKYAicCvwIHAr8C7gG1At4BogLCAVUC7ABAAY//EgAd/8n/twAkARQEbwQMB4wH9gY2B6sDXwPj/z7/Qv2l/EP72Pqd+YX5pPmx+Rb8FPzc/hD/vv8CALT/Uv9NAB//tACT/w0AcP/A/2D/EwABAC8AwQCNAIgBowGPAsUCcQP3A3kEYwXjBVkFIAY7Ax0E6wBNAeP+1v7/+6r7avmP+LX5d/jJ/GH8hgCdAfsCxQSIA6MEdAJMAhIAuv5K/Sj7qPxR+jb/tv0LAhwCbAK9A0QBlQLT/4IACP9j/9f/HQAuASIBYgFEAUoCqwL6BPoFngaOB+oFDQbyBEYEkQOnAvj/Xf8Z+9z6avdO95L1VfUY9UD0CPZO9Cj51vbR/dj76QDj/ywABwCa/cT9ivyC/K/9a/3U/zb/dAJkAYQFrwSQCOMItQoiDEIL3wzqCaYLXAdsCcEEGAYSA24CrgO/AWUHCwZEC1ILGAnDCQEAggC+9xz4u/d1+Gb/dACtB2gImgaNBjb4xvdT6YzoAutt6cf8DvrFD2INIRa1Fc0HxAjt6/HrD9sW2j3nvOeLCXwMqitdLhY1RzWlHPYa+fW4857dJ9vq2wPaneiY6B/6Kfx5CGUL5g/0EWsSmBJ2EgcSFhDEEDkI/whz+P/2CeaY4pXacNew3Nba8e4C7vMItAiyFcIVowvkC9n65vpt84nyofOh8RX2APSI+2D6wAMIBOANQBBlHdYh1y/iNKozbze9GiscJfJL8fXWbdX12B7ZQvR09hMZSxugMkE0sDPDNYQbnhzN8FHuAcnYxBnEZMKg4zfkhf/v/jD5nvXM2SbUP7xytlW4tLSF2eTZMhFDFmg+x0ZfSJxP2ir/K5n5Y/R03C3Wv+zL68YVGhzJLK42pyRnLW8WZhzNGMgbkCEcIRYaRRcBAlb/veou6VvdiNyV2w3b5ehu6Pr9D/6ABXUGL/cg95PmpuMq7NfnhAeMBOIdEh2ZFpwX2fig+37kU+go7L/vyAP7BVUVYRZhGIEZchLUE3YKswq1AkABofz7+gb67fnb99r5R/Ef9P/pIuty7Hbqu/xR+aEUOxKgJ68m4iV6JdIHxAba22PZUb/ou6/DR8EP4p/iwQgVDWArjDJsQjFJsEMXRr8qIyiWCN4Etvap9tX4xv27/bME9fqU/kvzSPCQ69zjK+cj4N3pk+YJ9kD2ZAmQC88VbBfdCAsHbObA4EbL3cT2zqLLXPIz9AUkOirERj9NFkRlRs4hsh8X+Qf2Zt6o3L/aUNqr6yHthwH7BasMCxOoDu4TmBOZFdcbGRpyF/USu/yJ9xPaCdYgx+rEJc0dzNfkpePR/5X9qQ+ZDUEQwBAACsANXgWBCj0EFwhFBw0I9gunCSIMhwi2CMoGFQxUDkAb8CG+LRA2+DSxOj8msyYoA7n+fdwi1nTIZ8OJ0JLNK+mz5vb8DvqQADH+6/jY973wRfDj7YXs+u857ZbyDO9a8g7vpvI08Ef6uPlSCqUM/BpzH7AiPyYFHgUfdROOExULtAwbBZ8H7/yx/Zz0I/Oz9BDzpwC4AHoQaRGoFnEWVwxECtP4S/bJ62Xqte3P7fr4vvmlAVsCHQHFAPD5u/cA9ULx3vm59tkGfgaSEEQTLA0SEZH+sQGt8Dryle7c7o75fvhsB8QEfAxjCOwGFwN3/x/+G/26/57+eATc/lgFN/sN/yr2F/Xd9UHwy/2M9kQIQwPNCnMKFQLSBS72Pvty8qr1bflS+UkDvgCDB7cElgRHA2/+kP4Q+Vf5AveA9i75JPg4/pH9DAI9ArcBbQLNAHQBkwXlBSMOUw76EKUR+wnRC8P/vwJG/P3+igIfA6sLjAm9DqYLpAoeCR4ENgUr/osASPnB+k/2CvYp9u/0PPcP9sH1gvRx8SjvAPF27df4SPUWAjUAVwL+AuX4RvsR72nxS+4F76X2KvW9ACP+tgjJBlsPgA+9EqYUGg9+EWsGiwh6/7cBCv61APP/WwKMAYUCOgOCAhEHkQVCCggJagfmBnX/1/8R+oj7I/xb/qABYQMhAy4DNf9e/Yn6z/fB+C72FfkP98H4XveX9/z2zfgp+Uv9bv4WAYUCKgJHAzkDlwPPBDUEPQQHA9kB+QBTAZ0B/QM3BYgGrwdABaYFwACkABn9F/0N/CX82vt5+076Fvl/94v1Kvb/8474ovZ+/ET7Yf/t/kEBVwHhAdMB0/9k/8/8X/xX/Hn8tP9tADcGEwceDcsN/Q+cEOkMdw02BngGTAAoAJX+c/46AbgBKAVBBrcG1AdKBOAEAv/u/k/6u/ly+WD4nfsQ+nn9wPul/Df7z/n2+EX44vdf+mT6cP7d/rcAiwEnAPYA7/40/5P/Pf/9Am0Cjgc+B4AJawkTBv8FQv8x/y36hfoG+v36/v1Q/8oCEAQVBfUF9gNeBFkB/gC2/o/9+/xs+9r9svyEAFkAiQEyAjcAOgFF/3IA5P8OAYkAXAH9/wcA7v0b/br7h/qt+4/6Cv47/R0BogAYAyYDGwPkA6wBHgPIAIAC9gGiA9UERQbJBqwHkASBBAH/9P29+1D62f0B/YMCtgKZBbkGyARVBlf/yADz98f4k/OO89T0D/Ry+lT56wDM//sD8ALfAeYArv30/Dr7DvuU+yb8Gf5s//sBzwNgBV0HeQYHCJAFWwapBLIEuARqBPsEvgQ5BV0FBwa9Bn4GuAfRBDEGzgDRAWv8tPzk+Yj5P/pt+cH7nvqw+0v6Lfq5+Hz5Pvg5+l/5Nvu4+nz8Y/zx/kD/yQFxAjAD2gMcA4ID2wL9ArcCqwKCAnECGQMSA2wElwRyBc0FTAXXBaoDGARKAGsArvx0/Nj6VfqK+tn5pvrU+fH6EfrD++z69/xH/H7+8v35/7j/AAHsADoBZwEYAVoBEgFlAXUB1wF9AvICaAQJBSgH+gecCaYKNgpJCz0IMQmMBDMF/wBXAZL+pf7K/KT8NvvR+gH6dPnZ+Bb4rPfH9pH3h/ak+Iz3eflt+IP5lfhR+X74/fhM+J75CvmV/Df8kACHAP0COAMiBLgE3QXJBvwHPwldCdIKYgnPCowHygiHBHwFmQJgAxQDvgO5BFEFLwWaBW0DkwMJAM//9ftS+3f4efdV9yn2n/h496v5mvjw+MP32Pej9sz3lPZ3+ID3L/qM+Tr9Bv1DAY8BjwVRBrMIwAmsCbAKPgkpCnMJYApiCmoLTApjC1sIUQnVBZgGvgNQBBMBLwFV/er8vvrQ+Xz6WPmQ+mX5Mfnl96H2K/VG9KfyDfNj8Ubzn/Ey9arzsvmG+OT/RP+LBHoEuAXmBUkEkwTDAf8Bxv8PAOr/SwA2AtkCjQV4BisJYQoJDFENogzFDc8KrAtFB8MHmQLLAvz96v1B+xX7Hvvt+n78Pfy//WL9U/7M/W7+0/1C/qv9EP6Q/Qz+tv3U/Zf9vvyF/Dv75PrN+l/6SPzh+1n/G/8BAxMD/gVTBs8GVQcFBXwFggHKAd397v0T/BD8Qv1A/VAAbQATA0MDiATHBEoElQRaAooCMwBQAJz/pf/B/7r/1/6+/vz8rvzt+4D7wPxJ/Oz+jv6TAFAAJADS/6r9Rf1E+8L69vqE+sT8Zvzi/qL+tACMAFYCWQINAxoDWgJ4AsYB2QFNAogCFQN4A3ED7wNwA+0DYwPEA2IDqwOJA7QDWwNxA84C0wJJAkcCgQF6Adv/rv+M/SX9Yvu5+lv6gvni+gL6mvzH+17+tP1i/9H+Lf+u/gv+hf3e/FP8bPzi+w39mvzB/nv+BQHxAP8CDgNPBHkE+AQrBcMEAQW7A+4DUgKCAh0BPwE8AFUAb/9h/+D+qv5M//7+XAAGAOMAmQB9ADUAv/+F//P+u/4Y/tz9W/0H/Vr9AP20/mT+pgB6AL0BqwHkAfEBqwHCAbQA0gBA/0v/lf6X/hb/Ff9LAEwAewF0AcMBuQH+AO4AMgAeANL/u/9+/2L/gf9u/xoAAwDk/8z/Zf45/jn9/vyY/V79cf5J/sz+vf5N/1//vwD+AFoCvwITA4gDlQL8AnEBuAF0AKIA3f/1/6b/sv8CABcA4AD6ANcA/wAZ/zb/1vzi/N/72PvQ/NH8+v4J/+EAAAFhAYEBiACmAE7/Xv9g/mf+/v33/Sf+KP4I/yD/xQDqAG8CrgIJA0oD0wIVAwoCPAJGAGgAP/5Z/lX9Yf22/b792f7s/kkAYQBhAXkBLQEzAYn/jv+j/Zr9q/ya/Av9CP1k/nf+6f8OAM4A/ABxAaYBgAK3AmQDnQPWAggDKgFRAeX/DwCa/8L/tP/f//D/FwBcAHYA1wD2AAcBIQHUAOwAtQDOAA4BJwEwAVYBOABLADv+Of56/GH8Qvwg/N39x/2TAI8A/wIFA7EDxQM/AkcCZv9e/xz9Dv0J/ff8gP6H/rf/xf/3/w8AEQAeAKYAuADyAQoCeAOPA8QD1QMkAjYCa/9y/6n8mfxM+0P7IP0n/XEBmQG2BPUEFgVlBRIEVgT/AjYD4gESAqkAywCY/6n/sv68/hj+Lf6r/sP+vADWAE0DawNcBIME7QILA/v/CQC3/bf9g/2P/cL+z/6M/47/DP/6/nX+YP4Z/wH/9ADqAEkDXwPTBO8E3QMLBIkAjAD1/Or8kPtt+yj9Ff12AHYA7gL6AtsC9gLwAPMAaf5R/nH8PPwH/M771PyU/In9Wv0F/tv9z/66/o//gf/y//D/KQAkABMAHgAtAEUAuwDZACYBTgGWAdEBsALuAnYDsAMNA0UDsQLlAvUCJAMiA1gDYQOUA74D8QM4A1sDJgE6AWz+X/5f/D78KPz5+1z9Kv0//gv+Sf4W/gX+yv2A/UD92fyc/KP8aPwL/dj8w/2g/RH/Bf8CAQoB5gICA68DzgPmAgsDiwGeAWIAaQBo/2r/GP8S/4n/gf/v/+f/KAAiAKIAmADIALYA6f/Y/6r+kv5l/T/9Svwm/DT8D/xF/SX9rf6R/uj/3f+pAKcAgACCAA4AFABEAFcADgErAbUB2gEgAkkC5wIbAy4EaQTYBBwF7AMTBBsCSQKoAK8ACf8W/2b9Uf0C/en8R/4n/m3/VP8n/w3/Nf4M/hP+5P2g/oD+rP6P/uj9zf2w/ZD9pf6N/p7/jf+7/6T/Of8e/w//8v5X/1X/4P/b/w0ADwAQABYAKwA3AGQAbgCtALYADQESAUUBVQEaAScBvQDLAIYAiQCLAI4AagBjAKL/jv+D/m7+Wv5C/hT///52/2X/KP8Z/7/+ov6S/nD+6v7I/sv/qf9vAEIAFQDx/43/X/8E/97+Pv4N/pb9av0j/vr9lv94/94AzwB5AWsBxgHDAUQCPwJjAmQCogGfAeAA0wD+APEAigGFAd4B3gEJAgMCzwHDAeEA1wCb/4P/Qv4U/kr9Df30/Lf8B/3M/D79B/0a/uT9fv9a/2YAUwBZADoAbf9Q/+P+xf7P/8H/eAFwASICLAIgAisCGgIpAnYBeAEuADIAxv/I/5YAmwCuAbgBCAIgAoUBjQFCAD0AFf/1/nT+V/7Q/qP+kv9t/6n/g/8G/+L+kP5s/jT+B/6S/Wz9gP1h/Yf+df4aABcAjgGpAZsCtAKhAsECJAI4AgMCKQI6Ak4C0gH3ATEBVwFKAW4B2gEEAisCVAI4AlkCAgIOAigBNgFLAFMA9P/x/0X/MP+0/Z79w/yo/Az95vwD/u39xv/A/6kBrwHWAd0BFwAWAIz+h/40/hz+jP6E/lH/Uv9UAGAADQEaAUwBXgGQAaIB+wEHAjUCQgIDAgwCNgE8AbX/p//S/bn9xfyc/CP99vxq/kv+n/+G/zEAKQBzAG4AwwDLAOgA7wCfAKoAPgBAAC8ANQBbAG4AGAEvAQ8CMALUAvUCRwN1AxsDQAOeAboBzv/0/4//ov89AGIAoACzAFsAbwCX/4z/fv5u/kz+QP58/3D/fgCAACwAKQCl/qb+Qf02/Sv9I/2F/on+QgBUAG0BjAGNAa4BwQDkAPP/CQDC/9j/DAAjAJ4AxgBRAXoBgQGtASwBVQGrAM4Asv/D/0v+Vf5t/W39XP1a/Zb9nf34/f/9jf6Z/in/Of9M/1r/8v4K/x3/Pf+PALMA9wEsAvUBKwL4ACUB9f8TAJv/vf9xAJ4A7wElAp0C3wI5AoICgwHPAdQADwFOAH0ARABwAJEArwCuAMkAnQCpAGAAZgDx//P/Vf9J/8z+y/7e/tL+Of9D/zr/Pf+5/sD+dP52/rb+uP4V/wz/0P67/vn92v2v/ZT9n/6N/u3/5//VAOQAhwGgAcEB4wFZAXkB5gALAQcBIwEgAToB4AD6AIEAjQA4ADgACwACAJv/iv/b/s3+h/55/tv+0v45/z3/Of8+/wT/C/+//rT+bf5f/qb+k/5h/0j/pv+M/zz/Kf/v/t/+K/8b/4n/j/8dACgAIgFHAaQCygL3AzQEewS1BJEDvgN+AZMBaP9o/0j+Ov4n/hT+jf5z/hr/DP+v/53/9P/l/8D/tP+J/3n/a/9U/9L+tP6u/Yr9wfyU/JL8XvxD/R791v66/m8AYQDyAPUAwADHANcA8QBNAWMBegGbAWUBiAFQAWsBCgEjAZMAogB/AIgAGgEZAZ0BnAFWAVYB0gDSAHIAXQDA/7T/pf6I/lf9Mf10/EH81Pyo/H3+XP4yAB8ABgH4ADEBJgHMAMEAFQAJAJP/h//G/8P/mQCcAKABtgFMAmACUAJnAuEB7AFoAW8BWwFfAZQBlQE8AT0BTABKAIj/d/8d/wj/vv6h/rH+jP7L/qH+p/6E/nz+W/5+/mP+u/6a/kb/M//u/9j/HgATACoAFQBCADUAQwA+ACgAIABPAE4AqgCnAOwA6wCnAKMA7v/d/5//kv9NAEMAAwEGAekA5gDq/+P/ev5i/nL9Uf2W/XD94f7A/rgAqABIAkUClgKeAqMBnwEsACkA/v7u/sX+uP6S/4b/bgBvAOIA6gDyAPkAegB7AOz/8P8bAA8AZgBgAFgAUABsAHEAuAC+AKUArABiAGUABwAEAED/Nv/Y/s/+c/9v/7oAwQDsAfsBRAJbAoMBiwFJAFAAhf+B/yn/IP8v/yv/h/+E/+D/3P9NAFAA7ADkAAwBAgFwAF4Anv+K/87+s/4L/vH92P3F/XP+Wf5X/0v/DQAFAK8AtABoAWoBEAIhAmsCfAIdAi4CMgE7ATsAQwDl/+r/DQAYAFQAVgCJAIwAhQCIAHAAbwCEAIEAegBwAC4ALwDz/+X/iP97/+7+1f7U/sX+Vf8//6//pP8eABwA6wDuAHkBiwF4AYEBOgFJAQsBGAHqAPQAkACgAO//8v+L/5j/6//p/1sAXQBSAEwA4f/V/0H/Nf8E//P+Tf9D/4//g/8d/w7/J/4X/kn9Mv1g/Vr9Bf///gQBFgEMAiACxgHkAeEA8gAXACsAEwAjAJ8AwAABAR0BzADtACQARACS/6v/dP+D/8X/1f9bAGwAygDeAC0ANAC4/rP+B/4C/oT+eP7o/ur+Df8O/5v/rv+IAJwAKAFRAWwBjQENASoBWQB4AOr/BwDk//v/GQAtAJQArgDaAO4ATgBeALr/xf9KAFUAIgEsAf8ADAH1//j/3P7Y/h3+E/7V/cb99f3e/VL+Rv7p/uD+ef98/6X/pP+6/8b///8KACEAMwArAEQA1ADyAJwBvAG5AdwBUAFvARMBKwESAS0BRQFbATkBSwFjAGwA8f7w/gT++/0Y/gP+2v7R/t7/1f8wACUAev9s/8X+s/4J///+kf+B/5n/jv+v/6f/BQD7/wMAAAD5//n/tAC4AKoBrQGzAb0B2ADhAAIAAADI/8r/IgAnAJ8AqADZAOIApAClAAEAAABV/0n/+/7n/uP+yv6m/o3+Vv47/m/+Vf7O/rb+Gv8L/zj/K/9u/1//1P/U/3YAfQD0AP8ABQEUAeYA7wC1AMMARgBKAOL/6P8wADgA/AALAZQBtAHeAfMBwQHiAUUBVAGoALcAJAAkANT/yv+5/6//hP90//3+5f65/qP++v7a/iT/Df8o/w3/Cv/w/sj+tv6o/pn++P7y/lf/Sv99/3n/0f/M/1IAUgAAAQEBvQHNAU0CYgIpAj0CWAFvAWoAeQAAABQAGwAhAEQAVQChAKsAGwEtASYBLgGbAKQA4//f/yn/If+L/n/+Yf5R/qP+nf5d/1T/MwA0AIcAigB2AHYAZABiAA4ACQCK/4P/gP9+/9T/zv/1//f/LgA1AJAAkgDUAOEAPQFJAY8BlgEwATkBpwClAGEAYAAQAAkAoP+Q/1v/Tv8+/yf/Lf8h/27/X//g/9n/TQBGAGMAYADS/8f/Gf8L//L+3/4h/xH/P/8u/37/e/8DAPn/bAB0AK8AtwD+AA0BRwFXAWABfQE3AU0ByQDeAFkAZgBKAFkAlwCdAM8A1QDtAPMA7gDwAHUAfADw/+3/BQAFAGYAYgAtADAAf/94/xb/DP9m/13/RQBBALUArgABAPP//f7r/sD+r/5C/zb/8f/p/4AAgADCAMoAtQC7AGoAdgAeACAAHgAkAFMAVAAsACwA5v/p/+n/3v/N/8X/iv+B/6L/nv8aABkAewCCAKwAvgCBAIwA5//0/4n/lP/K/9P/UwBkAM0A2AAAARMBzADVAGoAeABKAFEAZgBxAJkApQCVAKUANgA/AKX/sv9u/3D/h/+O/8j/y/8ZABcALQAtAP////+W/47/Iv8Z/9/+0v4f/xj/dv9z/7f/uf8hACcA7gD5AGABbwE+AUoBsACyAP7/+/9a/1T/6v7e/qj+n/6//rL+X/9f/yAAHwCEAIUAewB/AFIAVAAFAAUAnf+d/1H/UP9V/1j/dv9y/5j/of8mACkAGQEpAbEBxAGkAbkBNgFMAZwApwDz/wEAd/97/yf/K/9M/0v/6//u/38AgwCUAJQAaQBsAA8ABQBQ/0z/v/6y/pz+jv6z/qX+8f7m/lr/Tv+1/6r/BQD9/zoANwALAAcAvv+3/7P/sf/l/+f/CwALAA8AEwApACMAbgBvAGcAYgDU/8r/gP9x/9n/zf8yAC0ARwBEADwANwASABQA+P/3//b/8f/C/7H/fP9s/4T/cv+D/3D/VP9G/5X/hv8vACkAjwCGAHAAbgApACgAIAAlAEwATAAuADYALgApAGcAZQB3AHYAJwAmABIAGQBxAHcAfwCJAPb/9f9E/zj/5f7O/uT+1P4q/xz/uf+u/0IARABPAEoAuv+7/zb/L/9O/0f/6f/p/5QAlQCtALIAPQBDAOv/6//3/wMAWQBlALgAzQDYAPMAwQDYAKEAsQB0AHgAMgAlAAQA9/8JAPv/JwAjAEkATQB4AIMAeQCLAFEAWAAdAC4AMAAxAG8AdQBlAGkAwv/A//X+9f7Q/s/+cP94/1cAZADgAPQA+QANAZYAoADW/9r/Qf8y/xr/Bf8b///++P7h/vb+3f5H/z//+//1/98A5gB+AY0BfwGSAfQACgE7AEcAqf+z/5b/kv/S/9P/JwAiAH0AigDHANYAwwDeAIoAmAAPAB8Adv9u/wH/+f4q/xb/of+V/+//4P/t/+b/2P/I/+3/6P8jABwAVQBdAIYAnACUALAAcwCXAGIAeABoAHcAOQA6AOD/3v/V/9f/JgA1AKwAwwD8ABgB0gDgAFYAXwDR/8T/df9o/3H/Yf99/2n/bP9h/3H/Xv9+/3j/e/91/6P/rP9AAFIAuADYAKkAxgBlAHwAKAA1ANL/0v+z/7T/CwAJAH8AiwCsAL0AnACwAI4ApgCdAK4AxQDTAOIA5QCMAIMAsf+k/wH/5/7W/sL+Kv8b/8b/xf9TAF8AewCTAHQAhABVAG0AOQA3ABMAGwDc/9P/Wf9Z//H+7/4G/wn/gf+D/18AZAA8AUUBSAFSAc8A2ACGAI8AbgBwADoAMwAAAPL/lf+E/2f/V//P/8z/ggCFAN0A6QDKANQANAA0AGD/XP/y/uT+CP/6/l//Wv/f/9j/JQAtAB0AHQAEAA4A+f/4/8j/zf+g/53/lP+Z/67/rP/E/8X/pv+c/43/hf/S/8T/GgAUABoADQAlACQAHAAXALr/wf+t/6P/GQAiAFsAUwAHAAcA0f/D/9j/1f/q/+L/1v/V/wEAAgBCAEYASwBTADAAMwBJAE8AegB+AIIAgACCAIIAWwBYAOz/4f9l/17/NP8f/1r/UP/p/97/ZgBiAHcAewBIAEwAEQAUAPz//f/y/+r/1f/J/4T/eP9h/1b/iv+F//X/9/90AHcAgwCJAAgABACd/5f/dP9s/3P/Zv+5/6//DgABAAUA+f+4/63/l/+L/8X/vP9EAEQArgCxAHoAgAAHAA0A0f/O/5z/nP+//67////9/wAA9P+//8D/1P/W/xgAHQBwAHQAtgC6AKoApwAfABwA0v/M/+j/4f8YABMARAA7AEcAQgANAAcA3//f/wMAAwBHAEoAWwBkABcAGgDp/+7/8P/w/wgACgAOAA0AHAAiACkAKgAgACQABgAIALn/uv+C/33/mP+W/7f/rv+6/7T/8f/l/ywAKAArACYAEAALACUAJQAhACUABAAJABoAHgBaAF4AhACJAIkAjwBZAGQAGwAcAPv/AwAFAAQA+f/6/9n/2f/K/8n/AwAEAF0AYACPAI4APwA6AMj/uv+g/5D/vf+t//D/5v8DAP7/JQAlAFUAWgCHAIwAcgB2ABMAFwCw/7H/qv+w//T/+P87AEEAQgBAAC0ALwAeABoALgAuAHsAgAC4AL0AZwBxALP/qf9V/0f/Yf9J/2n/T/+C/2n/1f/N/ygAJABZAGYAhQCSAHgAgwAPABoAxP/F/7P/uP+t/7H/rv+u/9H/1P/w//D/5P/m/9f/2f8dACUAoQCpAOsA+ADNAM0AMQAqAHv/Z/8s/xD/cP9Y/97/zf8yACoAcQB3AHkAfwBRAF0AUQBWAFQAWwBPAFcAPQBEAA0AGAAJABEARQBNAGAAaAAtAC4A8v/t//H/8v8MAP3/+P/1/+b/zv+0/6r/jv93/6f/mf8kAB0AegB3AEQAPgDm/+P/xv+3/6z/qf/M/7//MwA4AMEAxwDjAPgAcgCBANX/3v+e/6D/tP+u/7z/tP+U/4f/Qf83/xT/Cf89/zX/ov+c/+z/6f8HAAYA6P/n/6P/o/9f/1v/Xf9R/5//mf8OAAMAWwBhAKIApwDTAOoA4ADxALMAyACAAI4AMAA0ANv/3v/J/8X/x//J/9L/0v8PABYARwBUAEUAUQBcAGsAYQB0AOr/9v9l/2v/bP9u/8D/uf+//7f/kf+K/4L/f/+7/8H/FgAjADwASABcAGgAUwBYAPX/9/+q/6r/1//b/x0AKAAqADMAAwATAMb/zv+R/53/1v/b/08AXwCdAKoAjgCeAFgAZQDx//f/hf+H/23/Yv+c/5j/vP+0/6v/qf+//8H/DwAWAGYAbACDAIwAPABBAJj/of9c/1//2v/p/48AmQC2AMYAYABrAA0AGgARAB8ASQBXAGMAcAA8AEgA8f/4/7P/sv+q/6b/nf+T/5D/f//O/8b/KgAkAPn///+p/7H/CAAUAGsAegBkAHEANQA8AP7/AQDr/+3/MAAuAC0AOgDH/8f/jf+Y/+7/+f9sAHQAmwClAG8AawD4//D/lv+K/5P/gP/C/7X/AQD1/wMAAwDS/9X/sP+7/wcADgCjAK8AFAEXAb0AwQDT/8//Lf8v/zD/Lv/P/9f/xgDOAA4BGgFdAGEAw/+8/8T/v//a/8z/q/+d/3n/Yf9a/03/XP9M/3v/dP/t//D/3wDhAHwBlAEpAS4BQABLAJf/lP8f/yD/PP8w/xIAFgDlAOMA1ADdAFcAWAAnACoAVgBWAHsAeQBNAEQAzf+//0v/N/9L/zb/1f/F/0sAPwBIAEIASgBIAF0AYwAjACsAk/+R/2L/W//J/8H/IwAcAPH/7f/M/8b/NgA4AH8AgwAMAAkAt/+u/8T/t//c/8r/8//i//f/6v/Q/8T//v/0/20AYgA7ADgAtP+j/5n/l//B/7n/+v/6/2UAZQBnAGcA6//q/83/yf9AAEYApQClALwAxACaAJoA/f8CAHb/av+e/5b/BwD5/wIA8//s/93/CAABAO7/7P/A/77/MgAzAMwA0ACfAKAA5P/f/2b/Yv+J/4H/FwAZALAAtQCzAMEAOABIAMf/1v/F/83/8f/5/w4ABADl/+H/pP+S/2n/Y/+W/47/+/8AACYAKgAlACsATwBUACYAKQCz/6//xf/A/2gAaQCEAIoAIQAnABoAIwBVAGcARQBQAEQAUwC2AMAA1ADlACMAKwB4/3P/kv+M/+H/1P+H/3b/Av/3/jv/Nv8uADwAHgExATMBRAFTAFYAPv85/7P+lv4D//n+/P/v/4YAlwCdAK4AwwDgAL4A1AD//wcAsv+p/0MAPwBKAE0AZv9d/yv/K//f/9f/OAA0ABAABAAbABkAMwA1ACsANgBfAGgAXwBnAKD/mv/q/tf+Zv9S/w0ACwDM/83/l/+k/0QAWwDVAOkAhACTAAMA9/+8/7b/hf9q/1H/Qv9O/zj/kf+J/xAADgB2AH4AkACdAIYAkQBnAGgANgAtAMj/uv/6/uf+lP6K/nv/ev+UAKgAjgCfAAwAFAA/AEcAsQCyAJIAlgBXAFYADgARACH/I/8w/hv+k/6E/iEACQBGAUYBjQGWAfEADwH7/xUAaP91/1v/UP9J/yv/Rf8k/0j/O/95/4T/DgEtAV0DlQPsAhMDlP+U/1D9M/2u/ZH9rv6a/pb/kf+wAL0AggGYAaoBtgHBAMAAL/8f/7H+pf6b/6b/SQBZADgASQBZAFkADwAFAG3/Vf+o/5r/nQCrAPgAFgHBAOcAaQCGAKD/qP/T/r3+6f7E/uP/zf/+APwAhgGaAQIBIAGz/77/r/6u/r3+pf6d/4n/WwBMAHsAfwCPAJgA6AAAAd8A6wD6/wEASf8//5T/kv80AEAAcgB5AGMAcgCAAH0AkACOACwAHQBe/1P/LP8p/9z/6/+hALQAjACbANn/0v8P//j+vv6b/gP/5f6s/6D/SQBXALkA0gDeAP0AwADSAC4ALwB3/2r/RP8s/6//qP8iACQAXwBwAL4A0gDgAPgAlQCiAFEAVACNAJEAkwCRAP3/+f96/3D/d/9u/67/pP8MAAMAfwCCAKYArQBSAGEA2P/i/3f/fP9B/zb/ZP9a/6n/mP/S/9L/IAAnAI4AogD2AA4BCAEdAZAAnACt/7H/YP9X/9P/zP/8//X/lP+D/4T/fP/X/8v/7//v//z/9//0//n/u/+4/6T/n//H/7//2v/K//L/6v8bABIABQATAAUADgBbAHcAoACuAJkAqABzAHIADgAPAK7/pv/P/9D/RwBIAJMAlwBvAHIACQD//73/uP/y/+X/BAD+/+n/5f8NAAcAJwArAML/vP9Y/1T/cP9x//r//v+aAKcAxADUAEMAUACj/6n/iP+K/7//wP8VABYAWwBgAGUAagA8AEMAzv/O/2D/V/+Y/4n/8P/h/5f/iP9g/1T//P/+/4sAkgBrAHIASwBRADMAMwDG/8n/kv+Q/7//x/8fACoAXgBpAEQAUwD4//n/4f/r/yEAIABDAE0AYQBkAFIAWgAdABoA/v/4/xYACgAQAAMADgAGACIAIwA7AEIAOwBEAP3///+i/5z/jf+C/6v/n/+L/4T/oP+e/ygAMgB6AIcAJgArAMr/y/+b/4//f/90/43/gv/G/7r/DQARAEUAQQBFAEsA///5/6n/oP+U/5H/7P/k/zoAOwBEAEEADgAIAMT/vf+b/5T/w/+5/+z/7f/s/+v/CQAMAGAAaQBUAFUA5P/j/7b/sP/e/9f//f///x0AGQAVACAAJQApAGYAcQCOAJgAZQBoAD4AQwA4ADcAAQAFAKv/pv9t/2r/m/+V//n/9/87ADsARABLAEEARwAyADkABgALAMn/yP+H/4P/kf+P/wIA/v9ZAGYAYQBlAEoAXABQAFsALgA6AAAACQDo/+j/5v/q/wMABAAYABgAGQAbABgAFAATABYAAQD9//j//P/8//7/BAAKACsAMABoAG8AagBtABIAEgCz/7D/qP+k/8L/yP/p/+7/FgAgAHQAhQCvALUAkQCeAEMAPwDk/+D/p/+e/6H/m//L/8X/FQATAEgASAA8ADkAJwAkAA8ABQDs/+r/2P/R/8b/xv/C/8L/2P/Y/9z/3//m/+P/CwAMAEMARQAyADcAFQAbABkAJADu//f/yf/P/+n/6f8HAAUAAQD6/xYAEQASABAA8P/w//b/9f8LAAwA7P/l/9H/0P/j/9j/3v/g//7/9P8hACYAIAAiABEAEgAQABQACgAHAOf/6v/U/9b//P///y0AOgArAC4AIAAsADAAMQD//wYAsv+v/6j/pf/H/8n/3v/b/9P/1f/c/9r/+f/5/x8AHQAWABMA8P/t/wYAAQAQAA0A0//Q/4j/hP+M/4b/0//W/zkANgBoAHAAcwB3AHAAeQBsAHQADgATAKz/r/+a/5z/2v/d/w4AEAA8AEIAXgBjAGMAZwBIAE0ALQAqAOf/5/+r/6X/nf+V/7X/r//C/7n/xP+8/9v/0v8PAAkAJgAmAA4ACwD5//n/6//u/+L/3f/a/+D/5f/i//n/AQAxADEAgACNAJsApABtAHoAQwBLADAANgAtADEAEgARAO3/7v/w/+n/EwAUADQALQAMAAkA1v/M/7v/t//G/7z/4//g//H/6f/Y/9H/3P/X/+T/4//i/+H/7f/u/y4AOABZAGEAMQA+ACIALAASABsA8P/4//r///8zADgAQgBLABsAGwDp/+3/6f/o//P/8P/e/9b/3v/V/9n/0f/F/7j/uv+1/9j/yv/Z/9j/6P/e/+7/7v/4//b/5v/q/yQAKABcAGUASQBSADYAOwAwAD0AHwAnACEAKwBHAFIAbQB3AGgAbgA/AEUA///+/8//zP/Q/8n/4P/b/+n/4v/y/+z/6f/i/+T/2//y/+z//f/2/9//2f/k/97/+//5//H/9P8BAAEAHgAnAC8ANQAjAC4AIwApAB0AKAARABcAAAAHAPz/AgASABcAHwAjAAEAAgDc/93/7P/m//v/+v/1/+//6P/i/+H/3f/j/9j/1//S/9f/zf/Z/9T/+v/3/y8ALwBDAEcANgA6ABoAIAAQABIACwAVACcAKAA9AEoAQwBLAEUATABPAFsAMwA0APH/+//Z/9H/9P/5/wcAAADY/9b/z//H/+v/5v/e/9b/xf+7/8P/vP/N/8b/6//n/xEADQAXABcA+//5//H/8v8HAAcAFwAeADIANgBHAFIAVgBeAEoAVgAzADYAEQAaAAUABgAVABcAIQAkABgAGADq/+n/zf/I/9n/1P/o/+D/7P/o/xIABwAoACYADAAEANH/yv/a/9b/9//0/9v/1//z//b/MwA1AE0AVQA6AEAALQAwABEAGQDy//f/3v/g/+H/6v8EAAQAIwAqADUANwA1ADcAJQAkABAAEAD7//P/4f/e/9j/0//O/8X/3f/a//f/7f/0//L/+f/x/w0ADwAsACYAGwAkABQADQD9/wgA+//8/wAABgAdACMAPwBIAEIASQBFAFIARwBNACEAKwALABAABwALAAQACQD4//T/6v/p/wQAAAD6//j/4f/c/+n/4P/Z/9f/rf+h/4X/gv+x/6f/4//i//b/8v/n/+n////+/xcAIAAeACIAIgArAC8APAAoAC8AIQAwAC0AMQBDAE8AQgBJAC0AMgAdACMAKgAsABMAFADy/+//5//k//T/8P8EAPr/7//q/+z/4f/0/+//GwAXACAAGQACAAIAAQAAABAAEwAtAC8ANwA+AC8ANQAiACoAKgAwADIAQQAqAC4AHAAuAEEAPgAtAD0ADAAJAOj/6v/d/9n/1v/U/9P/z//O/8n/4f/a/+n/5//V/8v/0P/O//f/7//3//f/1v/Q/9j/1f/r/+z/AgACABQAGQBIAE0AdQB+AGMAZwAdACkAEQAPAAcAFAAOAAsACAARAB8AHgApADIAMwAvAC8ANgAUABEA4v/i//T/7/8NAA0A+P/v/+T/5f8BAPn/EAARAAkAAwDx//H/+P/1/w0ADwANAA8A1P/Q/7//wv/a/9X/2//h/9v/1f/0//z/GwAdABoAIgAIAAgABgALAOn/5v/O/9L/3v/W/+P/6P/p/+T/CQAKACIAIgAVABAA6//u/+f/2/8LAA4AHgAWAO//7f/f/9r/BgAFABMADgD9//7/EAALAC4AMAApACsA+v/7//v//P8PABEAAgACAO//7//k/+j/AAD+/yEAJAAxADMAEAASAO//7//2//T/7f/p/9//3f/w/+v/AwADAP7/+f8CAAAA9P/z/9L/zv/A/7z/2P/V//P/8P/m/+X/DAAJADkAPQA4ADgAEAAQAPr//f/v/+///v///xsAIAAhAB8ACAAMABoAGwAMAAsA1P/Y/9P/zf/7/wAAAwABAPf/9////wAAEgAPAPv/+//l/97/yv/M/8j/wv/l/+n/BAAAAAkADQARABIAIQAfABcAHQAJAAUA/P8AAP//AQAFAAYAIAAlADYAPABAAEEAOwBBADIAMAAUABgAAQD9//H/9P/t/+n/5//n//j/9P8RABAAEwAVAAoABwAKAAsAFAARAPP/9v/N/8j/0//W/woACQAFAAkA/P/9/ysAMgAyADYAEgAXACkALAAuADUADAANAPT/9P8HAAoAAwACAN//3f/7//n/FAAUAPz//P/+//n/9v/3/+T/3f/U/9L/6//m//T/8//u/+v/DQASAC8ALgAsADQANwA3ADAANwAYABsAEQAXAB0AHwARABkACQAHABQAGAAWABsACQAFAB0AIAAiACAAAAD///f/8//5//n/6P/i/9z/2f/8//j/EAAPAPL/7//5//f/GAAZABAAEgAJAAkAAgAFAPf/+//x//H//v8DAA8ADgALABIAAwACAPD/9//5//n//f/+/+b/6f/b/9b/7f/w//n/9v/x//H/8f/u/+7/7f/s/+j/7f/t//D/7P/z//L/GQAYAB8AHgAMAA4AFgATAEAARQA0ADQA+v/7/wkADAAiACMA/P8BAA4ADgAbACEABQAGAPD/8P8EAAkACgALAPP/9v8DAAMAFQAXAPj/+f/o/+P/9f/4//3/9//2//X/+v/5//7/+P/2//j/8P/p/+b/6f/8//P/EQAYAA4ACADy//b/9//2/woACwAlACoAOQA7AD8ARAAhACYACAAIAAsAEwAYABQABQAKAAsACAAYABkAFgAaACgAJQAhACUACwAIANr/2f/S/83/z//N/9v/1v/s/+v/DgAKAA0ADwATABEAFAAVAAMABwANAAkAAwAMAA0ACQD0//3/BQABAA4AEwAWABkACAAIAAAABAAMAA4AHQAgAA0ADwAAAP3/+f/9/wUA/f/////////9//j/9P/9/wEAHgAcACYAJwAJAAoA+f/3/+z/6//W/9X/3P/a/woADQAYABoA+v/7//7/AgAMAA8AFwAXABkAHwAQAA4A9//7//b/9P/4//3/8P/r/+z/8P8MAAoAEwAUAA0ADQALAAsA+f/3/9f/1f/C/7//1f/S/+P/3//w//T/BQD///7/BwAFAAIACQAMAAEAAwDp/+f/4//k//D/8f/3//X/DgARACoAKwAjACQAIwAjACgAKQAdABwA+//7/+7/6v/y/+7/8P/s/+T/4v/u/+j/EgAWAB0AGgAHAAcAAAD+/wUABAAAAAIA5f/j//b/+P8XABcAEAATACEAIQApAC8ADwARAP3//P8NAA8ACQAGAND/z/+3/7H/1f/R//f/8/8DAP3/+f/5//j/8/8BAP//EQAMAPf/9P/i/97/6v/n/w0ADwAdABwAGgAdAC0ALwAyADYAHAAgABoAHgAyADcAMgA1AB0AHwAJAAkACAALAAQAAgDy//P/AwD//xMAFwAIAAEA6P/o/+v/4//k/+P/3v/Y/9r/1f/o/+n/9P/y/wAAAgAFAAUA//8CAPb/9v8AAAUAGQAaABcAHAAFAA0A+f/7/wsAEQAvADQAJgAoAAgADgAgAB0AEAAWAOH/3v/Y/9X/9P/5/wEA+f/0//n/AgD6/wEAAgD2//X/BwAFAPj/+f/X/9X/6P/l/+//9f/q/+n/DAAQAEkATwBcAGEANwA8ADoAPwAdACMA3f/e/+f/7P/+////8//0/wMABgAiACIAHwAkAAMABQAMAAgA+/8AAND/yP/P/87/7//t//7/+v8RABIADgAMAAcACQAKAAcAGQAcABUAFQD3//n/8P/y/wQABgAQABAAAQAHAP7/+v8GAA8AKwAqACoAMQAfACAAKQAuAC8AMgAHAAYA6v/r//L/7//2//j/CgAHACMAIwAeAB8ACgAJAPz//P8IAAUABgAHAPv/+P/2//T/BAAEABoAGQAEAAYA+P/2/woACwAjACUABQAGAOj/6/8gAB4ANgBAAB0AFwD4////4f/e/9r/2//9//3/KQArACIAJQATABMAHgAgAAUABADr/+n/8//y////+//v//D/8//v//f//f////j/+f/8//3/+v/5//j/8P/y//b/8//0//j/AQADAA4ADAAGAAkA+v/7//D/7//5//3/DAALAAgADADt/+z/6f/q/+//7P/T/9X/0P/M/wYABwA2ADQAHwAiAO//6f/u//L/AgD6/+b/6P/x/+r/CgANAA0ACgAIAAoAEAAOAP3//v/0//H/BAADAAkACQD7//7/FwASACQALAAEAP//8v/2/wMAAAAKAAwAFQASAAwAEAAHAAIAAgAFAAgABADU/9L/z//M/wEA///5//j/7//q//f/+P/+//3/4P/e/9z/2f/1//H/5f/n/+P/3f8BAAMABwAHAPj/+P8GAAkADgAPAAoACQD6//v/AwACAAMAAwAMAAwACAAEAPr//P/s/+j/7v/v/wEA+v/8//7/BAD+/xIAFgAnACMABwAHAN//3f/j/9//5v/s/wEA+f8iACoANAAzACwAMQAoACkAFgAaAPL/8//e/9z/7//0/wAA/P8HAAsAEgARABoAGQAZABoACgAGANj/1v/H/8L/2f/Z//T/7//t/+3//v/6/w0ADAD7//7//v/5//n///////z/8P/1/+T/5P8KAA8ANQA4ABkAHAD9//7/EAASABIAFQD6//n/+f/8/wMAAgAOABAAIAAdACMAIgAGAAUACQAFABYAGAD5//X/5f/k//b/9P8HAAgAHwAeACIAJAAXABgADgAPACMAKAApAC4AEwAYAAgADQARABUAFwAXAAQACQD3//X/+/8AABsAHQAGAAkA8P/x//j/9//q/+v/3v/c//b/9P/8//v/6f/m/+r/5//t/+//6v/m/+b/6v8EAAMABwAJAAkADgAHAAUABAAIABcAFwAjACYAHgAjAB4AHwAjACgAGgAdAB4AJAA/AEEAHQAhAOP/4//V/9H/2f/b/+n/5P8BAAIAGgAbABYAGQATABAACAAOAAkAAgDq//H/9//w/wQACAAaABkAEQASABIAEQAgACIALAAvACkALgAZABsADwAPAAIABAAaABwAGAAYAAIABAD1//X//v/+//f//P/t/+r//P/9/xEAEgD8////AQABAAUABgD+//v/+//+/xMAEAARABYADwAQABIAEAANABAABgADAAQABAADAAUADQAKADEANAAzADQAFQAVAPb/9P/+//z/AQACAPv/+/8DAAMAAAAAAP7/AAASABUABgAHAPz/AAAPAAsAEAAZAPD/6f/K/8//9v/v//v//P8CAAMALQAuABwAHgD1//X////9/wgACQD4//P/5f/m/wIA/P8UABgAAgD+/wIAAQALAAoADAAPABMAEwADAAgA+v/1//P/9f/z/+//4//l/+D/4P/4//f/AgAGAAcABgD9/wEA5v/p/+v/5//6/wEADAAGAPn//P////v/FwAYABMAEgD4//f/BwAHAAwADgACAAEACQAJABkAFwAWABYABgAFAAIAAAD7//z/+P/1/w0ADQAZABsABQAGAPz/+//5//r/AAD///L/8P/3//n/BwAFAAsADQD9//v/7P/v//b/8f/9/wEACwAIABgAGgAdAB4AFgAXAAYABAD+/wIA9v/x//L/9f/v/+7//f/6/wUABwAGAAUA//8CAO//7P/o/+n/7f/r//H/8P/p/+r/8f/v/wgACAAHAAkA+v/2//z//P8LAA4AGAAXAAcACgD9//r//P/7/w8AEQAMAAsADQAIAAkADgASAA4A9//9//n/9/8DAAMAFQAYABoAGgAPAA8AEgASABkAGgD+////8f/w//T/8/8NAA8AEgASABEAFAAOAAwABgAHAPv/+v/w/+7/+//5/wgACgAQAA4ADwASAAwACwADAAMA9f/1/+b/6P/g/9z/3f/f/+3/6//8//3/8//0//D/8P8KAAwAEwAVAAIAAwDt/+3/+f/5/wEAAQD1//X//f/8/w4ADwACAAIABwAJABkAGAAVABYADgANABUAFQAaABwABAAAAPz/+v8XABgABAACAOz/7v8RAA4AKgAuABwAHQD7//r/6v/o/+v/6f8AAAEAHAAfAAUAAgDv/+//FwAaACIAIgD9////8P/t//r/+/8HAAkABAADAAAA/f/w//D/BQAEABgAHAD0//H/2f/c//b/7//8/wIADAAIABQAGAAUABMA5//o/93/2v8CAAYA9v/y//D/9P8SAA8AEwAYAAMAAgD5//v/BQAAAAgADQAUAA4ADgAWABsAFQAkACoAJQAiACAAIgAlACQAEwAUAAEAAQAGAAgAJAAlABkAHAAQABAAHAAiAAgAAwD2////AwD///7/AwDy//D//f/+/xMAFwAJAAgA8P/z//n/+P8EAAUA//8CAAAA/P/6//3/BAABABEAFAAUABIA+P/7//T/8P8SABYAHQAcAB4AIAAsACwAFwAYAP3//v8MAA4AFwAXAAYACAD///7/DAASABgAFgAEAAoACQAEAAkADwAKAAkA/f8AAAEA/f8HAAkAFQAUAAwACwAEAAcAEQALAB8AJgAbABUADgATAA4ABgAFAAsACgADAA0AEQAUABMADwANAPX/9f/n/+f//////wEABAD6//n/AwAEAAYACADw/+7/5v/p//L/8P/6//z//f/8/wEAAAD+/wIACgAIAAoADAD//wAA/v/7/wAABAAGAAEAAgADABUAEgAaABwADwAOAPX/9v////v/CwARAA8ADADy//X/4//d//b/+f8MAAoA9P/4/9v/1f/w//X/EwARAAoADwD9//z/AQD+/wcACgAJAAoACAAFAPj/+f8AAPz/BwALAAkACAAFAAYAFwAUABUAGQADAP//8//1/wEA/v8FAAUA9//3/+v/6P/6//3/FAASABEAEQAXABcAFgAXABAAEgAPAA0A/f/+//j/9P8IAAwAHgAcAAoACwAJAAkAFQAVAP7//v/p/+v//v/7/wQABwAEAAIAAwADAP7//f/2//b/9P/y//n//P/y/+//4f/j//D/7v/+//////8AAPT/8//x//H/8P/x//j/9v/9////7//t/+n/6P8WABgAIQAgAAAAAgADAAIAEQATAAAA///j/+P/+//4/wwADgDt/+z/+//5/xwAIAAHAAQA//8CABAADgAMAA4ACgALABIAEgAaABsAFQAUAAMAAwAAAAEABwAFAA8AEgAEAAMACgAMABAADgD//wMA8f/s//r///8JAAEA8v/4/wAA/P8NAA4ABwAJABEAEgALAA0A/P////n/9//7//7//f/9//z//f8FAAQA+f/7/wYABgAKAAsA9f/0//f/+f8IAAgABgAHAP7//f8HAAcAEwASAPj/+f/7//v/DwALAAgADAAJAAUAHQAgACAAIQAZABoADAAMABMAFAAXABcA/f/9//D/8f8EAAIABAAIAPb/9P/0//b/+v/6//j/+f/9//7/AwAFAPr/+P/q/+n/9//2/wYABgD5//j/+P/5/wQAAwATABYAFQATAAcACAD+//v///8BAPr/9//j/+X/5//f//D/9P8DAP//CwAOAA4ADgALAAwA/f////H/8P/u/+7/+//7//v/9//+/wEAEgAQABgAGwANAA8ADAAJAAcADAAOAAwACgANABQAEAAYABsAJAAgAA4AEQAJAAYAAgAAAAMABgARAA8AFgAbAA8ADgD3//f/AgAEABsAFwABAAYA///7/wsAEgAOAAoABAAIAAcABwAJAAoABgAJAA4ADQAGAAoAAwAAAPz/AQD+//n/+/8BAA8ACwAPABQAEQAPABQAFQAeAB8ADAAMAPz//f8KAAsA+f/6/+//7//4//j/AQAEAAAA/f/2//r//P/4//z/AgD6//T/9P/4/wYABAANABAAFAASAA4AEAARABEABwAHAPz//P/6//j/AQABAA8AEAAfACEAHAAdABsAGQAYABwAEgAQAAQABAD8//v/AQAAABAAEQAZABsA/f/7//n/+/8NAAwABgAJAOf/5//s/+n/9P/1/wEA//8FAAYADAALAAIAAQD7//r/BwAKAAMA///y//X//f/5/wIABAAAAPz/8f/0//b/7//w//X////6//f/+v/+//3/DgAPAAUACAD8//j/9f/6//7/+f/9/wEA+v/4/wAAAAD7//z/CgAKABQAFQAQABEADQAOAAkACAASABAAEAASABMADwAHAAsAFQATACAAIQAQAA0AAQAEABYAEQARABcABAD//wMABQAFAAMAAgACAP3//v8BAAAA8P/z//L/7/8CAAUABgAGAPv/+v/1//j/9P/w//L/+P/5//T/+/8AAP3/+P///wQABgAEAPn//P/0//L/AAABAAIAAQABAAIAAQAAAAoACwAEAAMA9//4//v/+P8FAAoAAAD6//n//f8OAAwABQAFAPj/+f////3/DwARAAoACgD///7/AgADABUAFgAPABAADwANAAsADQAGAAYADgANAAgACgAGAAMAAQACABAAEQAJAAgAAgAEAA8ADQAWABgADAAMAP3////5//f/7P/t//L/8P/+//3//v8BAAQAAgD5//n/8v/0//7/9//7/wEA/P/3//r//P8JAAcADQANAAAA/v/+//7/+//7/wUABQADAAQABgAFAAMABQANAAwADQAPAAkACQAJAAcACgAPAAUAAgAKAA4ABgAEAAMABwASABUAEgARAPX/9//v/+z/AQAFAAcABwD+//7/CAAHABwAHAALAA4ADwAOABIAEwD5//f//v/9////AQADAAEA/f/7/wsADAAVABQA+f/8//b/9P8CAAMABgAIAAgABwACAAMAAQACAA4ADAALABIACQAGAPb/+f8BAAEAEAARABUAGQATABIACQANAA0ACwALAAsA/f/+//f/8f8CAAkAHAAXABQAGgAPAAsACQANAAgAAwAJAA8AEgAMAAsAEAANAAoABwAIABIAEgAVABcADQAMAAoACgAWABgAFQAWAAsACwAUABYAIgAfABIAGQAHAAQACAAMAAkACQD///3/GgAeAB0AHwAHAAYACAAOABgAFAAJAAwA8f/y/////P8LAA8ABwAHAAEA//8KAA8AEQAKAAMACgAFAAIA/f////r/+f/5//r/9//0/+7/7//7//f/DAASABEADgD6//z//P/7/wMABwAAAAAA/P/+/wAAAAAJAAgACQAMAA0ADAD6//n/8//0/xcAGQAZABkA/v8BAP7/+v8RABUAEAAOAPf/+P/9//b/+v/+//T/8P/+/wEABgABAPf/+P8HAAQAIAAgAA8AEAD///r/AQAEABIADQD2//j//P/4/wUACAAHAAYACwANABEAEAD6//r/7//u//n/+v8BAAAA7P/r//H/8f8LAAoA+f/5/+7/7//7//f/+//9//r/9//9////BAACAAIAAwD8//j/BwAJAAEA/v/4//f/+f/3/wQAAQAFAAgACwAJAP7////4//b/+v/5//3/AAD4//f/+f/2/wgADAALAAcA9//8//j/9f/6//7/BgADAAAABwAIAAUAAQAFAP/////3//T/+v///wMA/v/5//z//f/4/wYACwAVABEACgAOAP///P/1//X/+v/6//z//P/8//v/8f/w//T/8f8CAAQABgAHAAEA///3//v/AAD9/wQABgAQABEABQADAPb/+f8FAAEAEgAYABYAEwD//wQAAAD8/wQACAAUABQAEwATAAAAAAD3//X/AgADAAUABgD8//r///8BAAoABwAOABIACgAIAAIAAQAGAAYAAgAAAAMABwD9//n//f8AAAIAAQAPABAADgAOAAEABAD6//n/+f/8//v/+P/6//7/DAAJAAAABQD5//T/9//5/wcACQAHAAYA+f/8//b/8v8CAAMABQAJAAIAAQD5//n/AgAEAAIAAAABAAIA+v/6//////8BAAEA/f/9//f/9//4//f/BAAFAAoACgAAAAEAAAD/////AAD///3/AQAFAP7/+/8AAAIAAAD//woACgAEAAYABAADAAkACgD9//3/+P/4//X/8//8//7/AAD//wkACQAJAAoA8v/w/+//7//8//7/AAD9//7///8GAAkADQAIAAYADAAHAAQACwAMAP3//f/5//j/AAAAAAgACgASABEAFAAWAA0ACgAHAAsACgAIAAMABgD7//j/AwAGABwAGwAFAAcA+//4/wkACwAGAAUAAQACAAMAAwAEAAMADgAOAAkACwAIAAYAEgAVABUAEgD2//r////8/w8AEwAGAAUA/f/8//r//P8OAAwADgASAPv/+P/5//b/AwAHAAoABgAAAAUA+v/0//b//P////j//P8EAP7/+v/+//7/AQACAAMAAAADAAYABAADAP/////6//r/AgAAAP7/AgAEAP7//f8CAAkABgABAAMACQAHAPf/+v////r//P8AAAUAAAD7//7/+P/3//j/+P/1//X/+//5/+3/7v/5//f/EgAWAAwACgD5//r/9//2/wIAAwADAAQA/v/9//7/AQANAAoADAAOAAQABAANAAoAAwAJAPr/9P/6/wEAAgD///z//f/7//r/AwADAA0ADwALAAoA/v////3//P/4//f//P/9/wcABwAHAAcAAAABAAAA/v8CAAQAEAAOAAkADAAEAAIABAAGAAMAAgD7//n/+v/9/wUAAQAAAAIA9//3//j/9P8BAAQA/f/6//z//f8FAAUABQACAPn/+/8GAAMAAgADAAQAAwADAAEACAAKAAAA/v/0//X/BgAEAAoACgACAAQABwADAAcACwAHAAMABQAIAAkABgADAAMA9v/3//3//P8GAAUA/v////f/8v/8/wEA+v/3//7///8EAAQAEAAOAAMABgDx/+7//f////7//f/r/+3/9v/z//3/AAD///3/BQAGAAcACQAGAAIA9f/3//X/9f8BAAAA8//3//z/9/8BAAYABwAFAAUABgD8///////5//r/AQAGAP//+P8AAP7/+P8FAAoABgAFAAYABgD//wIAAAD7/wIACAAJAAUABwAIAP3///8CAP7/EQAVAA0ADAD///v///8EAA8ACwADAAYAAQD+/wEAAgAZABYADwATAAwACQAXABkADgANAPD/8P8EAAIAAgAFAP3/+v/7//3/BwADAAMABgD4//T/+//+//z/+P/v//H/8f/u//T/9f/5//j/CAAGAAsADQANAAsABQAEAAwADgAGAAMA9P/3/woABwAPABIACgAIAAsADAAMAA4AEAAOAAUABwAFAAUAAgADAAQAAwD+/wIADAALAAgACQD//wAA/////wAAAAAEAAcAAQD//wgACQADAAMABgAGAA0ADQAVABgAEgAPAAQABQANAA0ACwANAA4ADAACAAUABQACAAgADAD///7/AwADAAwADAAFAAUA/P/+//3//f/+/wAAAgAAAAQABAAHAAoABQADAP3/AQAIAAcABQAGAP7/AQAEAAIABQAHAAwACQALAA8AFAANAAcADgAGAAEAAwAHAAsACAD//wEAAAD//wIABQAMAAsACAAIAAQAAgD6//3/BQACAAIABwD+//r//P/9/wYABwABAP//BgAJABEAEAAQAA8ABQAHAAkABwAPABMADwANAAsADQAIAAgAFQAVABIAEgAbABsAEQAQABEAEQANAA0ACAAJAP3/+f/9/wAA/P/8/wIA//8LABEAEQALAAgACgACAAQABgACAAMACAAJAAUABAAHAP///f/6//n/9f/3/wIAAAAJAAsABAACAPz////9//n/AQAEAPj/9v/s/+z/9v/3/wcABwD4//f/8//z//n/+f/6//n//v/+/wAAAAAAAP//BQAHAAYABAAEAAUACgAKAAMAAwD6//r/DAAMAA8AEAAHAAYAAAD//wEAAAAKAAwA//////v/+v/9////CwAIAAkADAAKAAgAAwAGAAMAAQD//wIAAgABAPv/+//2//b////+/wgACwD8//n/+//8//7//f/8//z/9f/2//7//P/4//r/8v/w/+z/7v8KAAUA+v////X/8f8DAAMA/v////z/+v/9////BgADAP//AQD///3/AwADAAUABQD7//n/AAACAAIAAAD8//3/+//7/wAA//8DAAUACgAHAAcACwAPAAoABAAIAAUA//8IAAwAAwACAP3/+//2//b/AQABAAAAAQAIAAkACwAKAAMABAAEAAIABQAHAAYABAD3//n/+v/5//n/+/8CAAEA+P/5//f/+P/8//n/BgAKAAMAAQAAAAIACgALAAsACQAAAAMABgADAAQACAAKAAcAAAAEAAIA///9//////8AAAgABgAEAAcACgAIAAsADQAQAA8ABgAIAAQAAwABAAIABAAEAAAA/f/8/wEAEwANAAYADgD+//f//v8DAAIAAAD//////P/8/wQAAwAMAA0A+//6//j/+v8AAP3//f///wAA/v8DAAMACQAKAAoACQAFAAYAAAAAAAEA//8FAAYABQAFAAEAAQAOAA8ADwAMAP7/AAD7//v/AgADAAQAAwD7//3/AQD8/xQAGwALAAQA9//8/wAA/f8BAAIA9//3//7//v8KAAoABwAIAAgABQD//wUABgACAP7/AwABAP//AwAFAAcABgAIAAgABQAGAAIAAAD+/wIA+f/2//v//v8BAAAAAgABAAMABQAUABEACAAMAP//+//8//7/AgADAP///P/6////AgD9/wcADAAQAAwABAAFAP////8GAAQACAALAA0ACgD//wIAAQD//wQAAgAFAAgACwAJAAsADQALAAkAAAAAAAcABgALAAwACQAIAP7//v/z//P/+P/3/wcABwD9//7/9//1/wAAAgADAAMA9//1//j/+v/7//r/AgADAP7//v8CAAMACAAIAAIAAQDw//D//v////7//P/7//3////8/wQABgADAAQACAAIAAMABQABAP7/CAALABMAEQABAAUAAQD+/wEABQALAAkACwANAA4ADgAMAAwACAAGABYAGAATABEAAgACAAkADQAHAAQAAgAEAAsADAANAA0ACwAMAP//AAAHAAYABAAGAPz/+v/9//3/+v/7//n/+f8AAAEA9v/2//b/9f/8//3/EAAPAAoADAD9//n//f8CAAAA/P/y//X/9//2//n/+P/5//n///8AAAkABQAFAAgABQACAPT/9v8GAAUA/P/9//b/9f/+/wAACwAKAAcACgAAAPv/AAAEAAkABwAIAAkABgAGAAgABwAEAAMACwAMABIAEQAKAAwABgADAAYACgALAAgABQAHAP///f8MAA0ADQAPAP3//P8EAAQA/v/9//7//v///wEA/P/7//r/+//y//L/CAAIAP//AADx//H/AAABAAYABgD7//7/9f/y//3/AQAAAP7/BQAFAP7//v8DAAUA/f/5//z/AQD4//X/+v/9/wEAAAAEAAQA/f/+//v/+/8EAAMACQAMAAYAAwD0//b/+f/6//7/+//5//z/+v/3//r//v8CAP3/BQAKAAIA/v/5//v/AgAAAAcACQAFAAEAAAAEAAYAAwD8//z//////wIAAAAEAAQA/f/+/wQAAQAIAAoABgADAP//AgAGAAYACQAIAAMABQACAAAABgAHAAYABgACAAEA+v/9/wgABgD//wIABQACAA0ADQAKAAwA/P/4////BQAHAAEA/v8GAPz/9f/6///////8/wQAAgADAAgABgABAPv//f8BAAIABwADAAUACwAJAAUACwAOAAwACwACAAMA9P/1/wkACAATABQAAgABAPz//f/9//3//v/8//3///8FAAMAEwAWAAwACAD6//7/DAAHAAYACwAKAAgA//8AAAEAAQAEAAMAFQAWABYAFQD8//7//P/5/xEAFAABAAAA+P/1/wAABQAHAAQA+//8//r/+//9//z/AQAEAPL/7//0//b/CgAJAAEAAAD6//7/CAAFAAIABAD4//r//f/4//n/AAD+//n/+f/8/wkACQAEAAQA/f/+/wQABgAHAAMA+/8AAPv/+P8AAAIACwAKAA0ADwAFAAMABQAIAAoABwAHAAgACAAIAAsACgAJAAwACQAIAA0ADgAPABEADAAJAAoADgAMAAgADQAQABAADQAFAAcABQADAAUABwAEAAIA/P/8//v/+//+//3//v////z/+/8IAAcAAAD//wAA//8IAAgAAQD+/wMABQD9//n/AQACAAQAAAADAAcACQAEAAMABgAOAAwACQAHAAAAAgAGAAMA//8BAAIAAQD6//r//v8AAAcAAwADAAcAAQD8//r//v8CAAEABgAFAAEAAwAFAAMABwAJAAoACgAIAAYABAAGAAMAAgAAAAAABAAHAAYAAwAFAAcAAAD+/wEAAwD9//3/+f/6//f/9f/6//3//f/7//v//P8AAAEAAAAAAPf/9v/4//z/+v/1//j//v/2//P/9//4///////3//f/9P/0//3//v8DAAMAAQAAAPr//P/+//3/BQAEAP3/AADw/+3/8f/0//3/+v8AAAIA/P/7//3//f/2//b/AwACAP3//v8BAAAA+v/5/wAAAgD5//f/AAADAAEA/v/x//L/+f/4//z///8IAAIA+////wcABQAEAAQAAQACAPb/9P/+//7/AwAEAAcABQACAAQAAwACAAkACAAHAAcAAwADAP3//f8CAAEA/////wQABAAFAAMABAAGAAMA//8CAAUA///8//z//P8DAAIAAgAAAAUACQAGAAMABAAGAAcABQAIAAoACAAGAAIABQAIAAUAAgADAAsACwAJAAgABAAEAPz//f8IAAUA/v8BAAIA/v8DAAgABwACAAQACAAFAAMA///+/wMABgAKAAcA//8DAAcAAwADAAUAAwAEAAIA/v8EAAoACAABAAEABgAIAAUAAQAGAAMA//8CAAUAAwACAP3//v8JAAoABAAFAP7//f/7//3/AwABAAQABQD3//n/+//6/wYABQAEAAcA+v/3//3/AQAPABAADwALAP7/BAAIAAUABgAJAAoACgD8//v/AAADAAIAAQAHAAkADAAKAPj/+f/2//b//////wUABgD+//z//v/+/wkACgAAAP///v8BAAYABAD5//n/+v/8/wIAAAAFAAcABwAEAAcACQAAAP///f/9/wkACAABAAEA/P/8/wAAAQAEAAIABQAHAAgABgAKAAsAAQADAAoABQD//wYABAD8//v/AwAFAP///f8AAAUABQAMAAoABgAIAAgABwAGAAcACwANAA0ADgAHAAUA//8CAAYAAwAMABIACQAFAAwADwAMAAoACwAMAAQAAwAFAAYABQADAPz/AAAMAAcABAAJAAUAAQD//wQACQAFAAUACwAAAPv//f8CAP3/+f8GAAkA///9//7///8HAAcAAAAAAAEA/v/8/wEABAD9//r/AgAGAP7/AgAHAPv/9//5//z/AwABAPv//P/4//j////7/wAABgAAAPz//f8AAP7/+//+///////+/wQAAgAEAAcABwAEAP3///8HAAcAAwACAAgACQD//wAAAwACAAYABgALAA0ACwAIAAMACAAHAAIABAAJAAYAAQAFAAkAAQD//wEAAwAEAAMA//8EAAkAAwD+/wcACgACAAAABgAJAAUAAQAEAAEAAAAAAAMAAwAAAPz/AQD7//b/+/8AAAMAAADy//P/9v/2//3//P/+//7//v/8//j/+f/+//3//P/7//r//P/4//b//f/+//3//f/7//r//P/+/wQAAQD9/wAA/P/5//n//P8EAP7/BAAJAAYAAQD//wMAAQD9/wIABQABAP7/AAAEAAYAAgAFAAgABwAFAP//AAD9//3/CAAIAAYABAADAAMABgAFAAYABwABAAEA/v/8//n/+f/4//n/+f/4/wMABQABAP7/9//5/wYABQAIAAgA/v/9//3//P/8//3//v/+//L/8/8AAP7/+v/7//3//f8CAAIADAAMAP3//v8BAAEAAgACAP3//f/5//r/+v/7/wcACAABAAEAAgABAAIABAAFAAQAAwADAAMABQAGAAMAAwAFAP7//P///wAAAwAFAAgABgAPABAADQALAAUABwAHAAUACAAMAAgABQD//wEABgAEAAMABAAFAAUAEQAQAAoADAD///3/BwAIAAcABwD8//z/AAADAAMAAgAIAAcA//8DAAcAAwAGAAkA/v/9/wUABQD/////AAABAP///f/9////+v/5/////P8DAAcABAABAPv//f/4//j/+v/4//f/+v8BAPz//P8DAAgAAQD9/wMABgACAP3//f8EAAYA///9//3//v/9//z/AgACAAcABgAIAAsADwANABAADwAKAA4ACAAEAPr//v/8//r/CgALABAADgAIAAkABQADAAoADAAMAAsABgAGAAcABgANAA0ABgAGAAIAAgAOAA0ABQAGAAIAAgAKAAkACQAJAAIAAwAAAP7/AQAFAAMA/v/6//3/AwD///v//v8DAAIABgAFAAMABQAGAAIA/f8AAAYAAwD+/wIABwADAAUACQAFAAMA//8BAAIAAgACAAEAAgAEAAIA/v8FAAkADQAJAAYACgAKAAkABwAGAAIABQAJAAYACwAOAAcABwAHAAYABwAJAAkACAAPABAAFgAVAA4ADQD8//3/DgALAA0AEAAFAAEAAAAEAAwACQAJAAoACgANAAkAAwACAAkACQAEAAQABQAEAAcACgAGAAgACgABAP//AwAFAAIAAQAAAAIA+v/3////AwAGAAMA/f/+//z//v8FAP//AAAGAAUAAAABAAUA/v/7/wEAAwADAAAABQAJAAkABQD6///////7/wYACAAGAAYA/v/+/wUABQAJAAwADAAHAAAABQADAP//AAAEAAQAAQD+/wAABwAGAAUABQALAAsABgAHAAgABgACAAQAAgABAPz//P8HAAgADAAKAAIAAwADAAIADwAQAAAA/v/+/wEAAAD9/wMABAD+////BQABAAwAEAD5//b/+P/6/wYABwAHAAUA/P/+//v/+f8DAAQAAwADAAIAAwD3//T/+//+//7/+/8BAAQA///8/wAAAwD8//r/AwAEAAEAAgABAP7/+v/9/wEA/v8CAAQABgADAAAAAAD7//v/+f/4//v//f8CAAAAAAAAAAcABwALAAsACQAJAAEAAAAFAAcAAQAAAP7///8CAAAABQAGAAMABwAGAAMAAAADABAADgAJAAoA/f8AAAsACAAKAA0AAgACAAIAAwAJAAoABwAGAAAAAAAEAAUADQALAAAAAwD///v/DQAQAAcABAD4//v/BgACAAYACwAIAAUA+v/9/wEA//8HAAgAAAABAPv/+v8FAAYAAQABAPv/+v8CAAIABgAGAAAAAQABAAAACAAJAAMAAgD5//f/+P/9/wgABQAKAAsACAAKAAgAAwAGAAsAEAAMAAoADQADAAMAAQD//wUABwD///7//v/9/wYACQAIAAUACAAJAAoACQADAAIAAAABAAEA//8GAAkA/f/7//7/AAAJAAgACgAKAAAA//8BAAAAAgAEAAQAAQD7//7/AQD+/wgACAABAAEAAQD//wQABwAEAAAA/v8BAAEA//8DAAQA/////wIAAQAFAAcAAQD//wYACQAIAAQA+f/9//7/+/8DAAYABgAFAAQAAwAGAAkACAAEAAEABgAGAAIACAAKAAcABQD+/wAADAAJAAQABwAIAAUAAQABAAcACgAKAAYACAAMAAwACgAGAAYAAAABABAADgARABQACAAGAAIABAALAAgABwAKAAkABgD+/wMAAgD+/wMABQALAAsACAAKAAYABQADAAMABQAFAAMAAwABAAEAAgACAAgACgAGAAUA/v/+/////v8IAAkABQAEAAMABQAKAAgABwAIAAcABwAIAAYAAwAGAAYAAwAIAAsAAgD///v///8DAP3/BAAKAAQA/f8EAAwADQAGAAUACAACAAAACQAKAAEAAgABAP//AAABAAEAAAABAAIACQAJAAQAAwAGAAgABAACAAMABAD9//3/AgABAAIAAwD///7/AwAEAAQABAACAAAAAgAEAAkABQACAAUA/v/7//7////8//v/BAADAPj/+P/9//v/AAAAAAYABQD5//r//P/5////AwADAP//8P/z/////v8EAAEA+f/8/wAA/f///wEA/P/6//3//P8DAAUACAAGAPz//f/6//j/BAAFAAEAAgD9//7//P/9/wMAAgD+////AAD+//r/+/8BAAAAAAAAAAAAAgACAP//AAADAAUAAgD8//7//f/9/wEAAQABAAMA+v/2//v//v8MAAkAAwAEAPj/+P8GAAYACAAHAPX/9v/9//3//P/7/wAAAgD9//r///8CAAUAAwAEAAUAAQAAAPz//v/9//n/+f/9/wQA///8/wIA/v/7//T/9v8AAP7/AAACAAMAAQD//wEA+v/5//f/9v8CAAEA/P/9//z/+v/3//r/BAABAP7/AAD+//3//f/+/wkABwACAAUAAgD+//n//f8CAP3/AwAGAAUAAwD9/////f/8/wYABwAGAAMA/v8CAAIA/v/7////BAABAP3/AAABAP7/BwAIAAwADwAJAAYA//8FAAcA///9/wUABgACAAkACgABAAMABwADAAIABgAKAAgABQAHAAUABQD6//n/AgAFAAkABgABAAUA///7/wgADAAIAAUAAQAEAAYAAwAHAAsADAAHAPz/AgACAP3/BQAIAAQAAgD8////AgAAAAAAAQAHAAgAAgD//wEABAAAAP///////wIAAgAIAAoA///7/wgADQAKAAQACQAPAAgAAwAIAAwADQAJAAQABQACAAIABQAFAP7//f8CAAQABAAAAAIABgD7//n/+f/5//z//f8IAAQA//8FAAIA/P8DAAcAAgD9//T/9/8BAP//CAAJAAwACwAEAAMAAAABAAQABAAGAAUAAgADAAYABQAMAAsABgAKAAgABAAFAAcAAAAAAPz//P8BAAAA/f///wYABQANAA4ABwAKAP///P8JAAwACgAJAAQABAACAAMACQAIAAoACgAGAAYABwAGAAUABgACAAQA///+/wMABAAGAAQABwAJAAYABwAHAAYAAwAGAAgABAAAAAIABgAHAAAA/v8BAAEABQAHAAgABQD//wQABgAFAAsABwACAAkABQD+/wEABQAGAAYADAAKAAUACgAGAAEA/P///wYABQAIAAkABQADAAEABAADAAAABwAKAAIA/////wIABgACAAkADgAHAAMABAAGAP7//v8DAAEA//8CAAAA/v/3//f//f/+/wYABQACAAMABQAEAAMAAwAHAAUAAAADAAAA+//4//3/BAAAAP7/AgAEAP//+/8AAAEA+////wMAAgAAAAAAAAD5//v//v/7//7/AQADAAAA/P/+/wUABAACAAMAAwABAAQABwABAP3//f8BAAEA/v8AAAIA/f/8//7//f8CAAUAAQD9////BAAEAP///v8AAPr/+v/9//r//P8BAP7/+//6//v//P/9/wAA/P8AAAYAAAD7//r///8GAP//+P/+/wIA/P/6/wEADAAFAP7/AwAIAAQA+P/9/wQA/f/2//7/BQD+/wAABAAIAAcA/v/+///////6//n/+P/3//f/9v8CAAQABgAEAP//AAD+////AwAAAP//AgD9//r///8CAP3//P8EAAIA+////wQA//8DAAgAAQD+/wIAAgAHAAgADgAMAAEAAgD8//z/+f/4/wEAAgD+//7/AgABAAIABAAJAAcAAgACAAQABAD8//7/AQD+//r/AAAEAPz//f8FAAsABQABAAUA/P/5//7/AAAIAAcA/P/+/wAA/v8GAAgADAALAAoACwABAP7/BgAJAAQAAgAAAAMABAADAAIAAgAFAAQACQAMAA4ACwAEAAUA/////wAA//8CAAUABwAEAAEABAAGAAMAAwAGAAkABwAIAAkABQAFAAUABgAEAAMAAwAEAP7//f/8////CgAIAAkADAAEAP7/AAAHAAgAAAACAAkABQAAAP7/AAD///7/+f/5/wMAAgACAAQA///7/wMABwAIAAQAAQADAP////8HAAcABQAHAP///f8BAAIABgAFAPv//v8BAP3///8DAAQAAQACAAMAAQABAAcABQAFAAYACAAIAAUABAD//wIAAAD8//v//v8FAAMABAAEAPz///8DAAAAAAACAAUAAgD7////AgD9//v///8DAAAABwAHAAEABAABAPv//f8CAAUAAQD8//3/+v/8//7/+/8IAAsABAABAP7/AQACAP7/AwAIAAcAAgD5////CAADAAcACgAHAAUAAAADAAoACQAIAAsAAwAAAAMABQAFAAQAAwAGAAQAAwAEAAUABgAGAAMABAANAAwABgAIAAEAAAADAAQABwAHAAIAAgACAAIAAQACAAgABwD+//7/AgABAAMAAwAEAAUABgAFAAMABAACAAEA/v/+//3//P8BAAAAAwAEAAoACQAFAAYAAwAAAAAAAwAGAAMA/v8DAPr/9//7//3/AwABAPz//v////3//f8AAAYABwAGAAUA/v/+//7///////3/BQAKAAEA/v/3//j/+v/7/////P/7////BQABAP7////9//7/BQACAAYACQADAAIA+P/1//f/+/8CAP//AAAAAP7///8GAAUABQAEAPz//f8FAAIACAAJAAIAAgAAAAEAAgD///v/AAD8//b/+f///wAA+//9/wAAAgABAAIAAgD4//n////+/wEAAwAEAAQA+f/6//v/+//8//z/+//9//3/+v/+/wIABQACAPv//P/9//z//v8AAAEA///+/wIA/v/4//P/+f8CAPz//v8EAAQA///9/wEABAD//wIAAwAFAAQAAQABAP7///////3/CwANAAUAAgD4//r/+v/5//7//v/5//n//v/+/wAA//8DAAMA/P/9/wIAAQD+/wAAAAD9//z//v//////+//6/wEABAACAP//AgAEAP7//v8LAAoABQALAAQA/f/8/wQABAD9/wMACQADAP//AQADAAAAAAAFAAIABAAIAAwACAD8/wEAAAD6//v/AAADAP//AgAGAAIA/v/9/wAABgADAAYACgAJAAYAAQADAP3/+//9//3/AgACAAEAAQD8//z//P/8/wUABQAOAA4AAwAEAAIA/////wQACAACAAEABwD8//j/AgADAAcACgAOAAkA//8FAAEA/P/+/wIA///+/wYABQAFAAcAAgABAAcABwANAA0AAwACAPH/9P/7//f//v8DAP//+//4//n//f///wMA/v/9/wIACAAGAPz/+//0//f/AAD6//7/BAD9//j/+f/8/wMAAAAAAAAA+f/7/wMAAAD6////AAD8////AQD4//j//v/6/wAABAAQAA0ADAAPAAcABAAEAAYAAwD+//z/AAD///7/BQAFAP7/AQAAAP3/AgAEAAcABwAEAAIA/f///wEA//8DAAUAAAACAP//+/8EAAoACAACAPj//f8CAAAACQAIAAIABQABAP7/BAAGAAwACwADAAIAAgACAAIAAwAFAAQA/v///wIAAAAEAAcABwAFAAcACAAAAAAABgAFAAQABQAAAP//AwAFAAoACAAJAAsABQACAAEABAAEAAEA//8DAAUAAQACAAcACgAFAAoAEAAQAAsABwAKAAEAAQAHAAcAAwAFAAEA//8IAA0AFgARAAYADQAGAAAA/f8BAAwACgABAAMAAQAAAAQABQD/////BAADAAQABAADAAQAAAD+/wMABQAIAAQAAwAHAAoABgD9/wEA/f/6//n/+v/+//z//v////v//P/9//v/+f/9/wEA/P8EAAgACQAFAP7/AQD9//v/BQAGAPz/+////wEA/v/7/wAABAD7//n//f/+/wIAAwD9//z//P/9//7//f/+/wAA/v/7//3/AAD///z//f////7//v8BAAEA/f/+/wIAAAAFAAcABwAGAP3//v8CAAEABQAFAAAAAAD9////AgD/////AgD///v/AQACAAEAAAD9//v/9//6//v/+P/7//7/+//4//z///8BAP7//f/+//7/AAAEAAEA/v8BAPr/9//8//v/AAADAPv/+f/2//b//v///wQAAwABAAIAAAAAAP///v8AAAAABQAGAP///v/7//7//f/6/wAABAD+//z//v8AAP///v8DAAMA///+/wIABAAAAP7/+v/8/wIAAQACAAIA/v/8//r//P8EAAIABgAIAAIAAQAEAAQACAAHAAEAAwACAAEABQAEAAgACgAGAAMAAAADAAUAAwACAAMAAgACAAAAAQACAAEABAAEAAkACgD/////AAD///z//v8JAAYA/f8AAAMAAQABAAIABwAHAAMABAAFAAEAAQAHAAYA//8AAAcACAADAP7///8DAAUAAwAAAAIABAD+//3/AgADAAMAAgD9//3//v///wMAAQD9/wAA///8//z//f8BAAIABwAHAAoACAACAAUABQABAP7/AQADAAAA9//6/wQAAwACAAAAAAAEAAMA/v8CAAcAAwAAAP3//v8EAAEA//8CAAQAAQACAAQAAAD///v//P8EAAIAAAADAAIA/v/9/wAA/P/7/wIAAwAEAAIA+f/9/wMA/f8DAAkACAADAAAABAACAP//AgAEAAIAAgADAAIADQAOAP3//P/7//z/DAALAAwADgAEAAIA9P/3/wEA/v8DAAcABQACAAEAAwAAAP//AwADAP//AAAFAAQA/v///wIAAQD7//v//f/+//3//f/8//v/+P/5/wEA//8EAAkACgAGAPz///8EAAAABgALAAkABgAGAAgAAQD+//3//f8DAAUAAgAAAPr/+//7//v/BAADAP//AQACAAAA//8AAP/////4//f/+P/5//z//P8CAAIA/v///wcABAD+/wEABAADAP//AAAAAP//+v/6////AAADAAIAAgAEAAsACAD8/////f/7/wAAAgD8//3/AwABAPf/+/8DAP//AAADAAIAAgACAP3/AQAJAAQA/f/+/wMA/P/5//3//v/+//3//f///wEA//8EAAQA//8AAP///P/9/wAA///8//3////+//3/AQABAAEAAQD+//3//P/9//3//f8BAAEA/f/9/wIAAwACAAEABQAFAP3//f/4//j/+v/6//z//f8AAP///f8AAAMAAgAEAAQAAgACAP///////wAA///+////AAD///7/AAACAAMAAQABAAQAAgD8////BwAHAP7/AAAHAAYA//8AAAYABQD///r//v8BAP///v/9//3/AgD///j//f8CAP///P///wEAAAD///z//P8BAAAA/////wEAAwAAAP7/AAACAAgABQD+/wIAAQD+//3/AAAFAAMAAAAAAP//AAADAAMAAwABAPz////8//n//P////3//P/7//j/9//8/wAA+/8GAAoAAQD+/wAAAwABAP7/BQAGAAEA///+/wAA/////wAA///8//z/BgAGAPv/+//7//v/+v/5/wAAAgD8//r/9v/4/////f8DAAQAAQABAP7//v8EAAMAAQADAAYABAD+/wAAAwABAP//AgD///v//v8CAAMA//8BAAQAAQABAAkABgACAAYAAwD///3/AAAFAAMAAwAEAAUABgACAAMAAgACAAQAAwAHAAkAAQABAP///v8IAAoABwAFAAEABAAFAAMABwAJAAQAAgAEAAQABgAJAAQA///6/wAABwABAAYACgADAAAAAwAHAAkABAAEAAgABAAAAAYACAACAAEAAgAEAAMAAQAJAAsABQACAAIABQAAAP7/AwAFAAQAAQABAAYA/v/7/wEABQABAP7/CAAIAAIABAACAP///v8CAAYAAwAAAAEABgAHAAkABwAKAAwABQAFAAQAAwAEAAQAAQABAPr/+v/+/wAAAQD+//7/AAD6//n/9//2//n/+/8GAAMAAQAEAP///v////3//v8DAAMA+//z//z/AQD5//r//v8EAAEACAAIAAMABQD8//r//f/+/woACAD9/wAABQABAP3/AQACAAAA/v/+//7/AQABAPz//P///wEAAAAGAAgAAAD+//7/AgABAPv/AwAJAAUAAAD6//7/AQD+/wEAAgAFAAgAAgD+//f//f8FAP//AQAEAAAAAAABAAAAAQADAAYAAwACAAQABQAEAAUABgAFAAUA/v/8/wAAAwACAP//+v/8/wAA//8CAAIACgAKAAIAAwALAAgABQAIAAIAAAD9//7/+//6/wEAAgAAAAAABwAGAPz//v8IAAUA/v8BAAEAAAACAAEABwAJAAcABAADAAYACAAGAAkADAD+//z//v8AAP//+//7/wEA/f/3////BAABAAAAAwAAAAUACAADAAEAAQACAP3///8CAP7///8DAAQA//8DAAkA///6/wEABgAIAAMABQAIAPr/+f/9//z//f///wUAAgD9/wAAAAD9/wAAAgADAAAA//8CAAcAAwABAAYAAAD6//7/BQADAPz/AgAHAP///f8EAAQABgAHAAIAAAD8////AQD+//3/AAD///v/AAAEAAQAAgADAAIA/v8BAAIA/v///wIA/f/8/wEAAAD8//7/AgABAP7//f8GAAgAAgAAAP//AAAGAAcAAwACAP///f/1//n/AAD7////AwACAAEABQABAAUACgAFAAEAAQAFAP7//P/9//3//v/9//z//v8DAAAA/v8DAAgAAgD+/wMABwADAPv//v8FAAMA+//9/wQAAwD//wAA/f/9/wIABAABAAEABwAHAAUABQAHAAcACQAIAPz//v////3//f/+/wEAAgACAP//BwAKAAMAAQD+/wAA/v/7/wAAAwABAP7/AQADAPz//f8BAP3//P8CAAQA/v8AAAQAAgAAAAIAAgAGAAgACgAIAAUABQACAAQABwADAAQACQAIAAQAAQADAAUABgD7//r/AQACAP3/+////wIA///9/wQABAD+/wEABAD+/wMACQACAP//AAD///7/AQAFAAMABgAGAAQABwAGAAEA/v8AAAgACQAHAAQAAwAGAP///v8FAAQAAQAEAAMA/v///wQAAwD///z//v8DAAUABQD///r/AgD+//b/+v8BAP3/+f8DAAQABQAFAAIAAgABAAAAAAABAAQAAQD//wIA///9/wUABwAAAP7/AQACAAkABgAAAAMAAQAAAAQAAwD+/wEAAAD8//7/AQAEAAMAAQABAAEAAQAEAAMA//8AAP3//P8EAAcAAgD9////BQACAPv/AAAGAAAA+//+/wMABAABAP7/AAD/////AgAAAP7/AQAEAAAAAgAFAAQAAgAFAAUAAAABAAUAAwD9/wAA///9/wAAAAAGAAYAAQACAAEA//8EAAUABQAHAAkABAD6/wEAAwD9/wAAAwABAAAAAQAAAAMABgADAAEAAgACAP//AAACAP//AAAFAAYAAQD9/wEABAABAAIAAwADAAQAAAD//wMAAwAAAAEAAgAAAAAAAgD+//3////+//z//f8FAAUABAABAAAABAABAPr//f8FAAQA/f/+/wIAAQAAAAAA//8BAAAA+v/9/wQA///9/wEAAQD8//7/AQAFAAEA+//+/wIA///9//3/AAABAAEA//8CAAIABAACAAUABQADAAIAAgAEAAYAAAD9/wMABAD8//r/AQAEAAAA/f/+/wEAAQAAAAAAAwABAAUABwADAP//BAAGAAIAAQAEAAIABgAJAAMA/v8FAAoAAwD9/wIABwAAAP3/BAAEAAMABQAEAAIAAwAFAP///f8BAAIAAQABAAIAAgAAAAAA/v/+/wEAAAD+/wEA///+/wEAAAD//wAAAAABAP3//P/+/wIA///5//3/AgAAAPz//f8BAAEA//////7/AQAEAAEA/f/8/wAA///9//7////8//v/AgADAAAAAAACAAMAAgADAAUAAwAFAAcA//8AAAYABQD8////AwABAP3///8AAAEABAADAAAAAwAEAAEA/P8BAAMAAAACAAMAAgAEAAEAAQABAAIAAwABAAAAAgABAP//AQAFAAEA/v8BAAQAAwAAAAQABwAEAAQABwAEAP7/AwAGAAIAAQADAAIAAgAAAP//AAACAAAA/v///wMABAABAAEABAADAAEAAQACAAIAAQABAAIAAAAAAAQAAwABAAIABQAGAAAAAAAFAAYA///+/wYABgD//wEABQAEAAAAAgAGAAMAAAADAAgABgAHAAgABQAFAAYABgADAAIA//8CAAUAAAD+/wQACQADAP7/AwADAAAAAwAEAAMABAAIAAMA/v8DAAcAAQD+/wMACAACAAEABAADAAAAAgADAAUAAwACAAQAAgAAAAEAAgABAAAABAADAP//AQAFAAMABQAFAAIAAQAGAAYAAgADAAAAAAAFAAMAAgAFAAQAAQAEAAYABAAEAAwACAAEAAYABwACAAIABgADAAAAAgAEAAUAAwAFAAUABwAIAAYABwAFAAMAAgADAAAAAAAAAP///v8AAAcABQABAAAAAwAEAAIAAAAGAAYAAQADAAYAAwD//wIAAAD+/wIAAQAEAAUAAwABAAIABAAEAAQABAACAAIABQAAAPz/AQAFAAIA//8AAAMA///+/wMAAQD+/wIABQABAAEABAAEAAIAAgAEAAUAAgAAAAMABwACAAEABQAGAAQA//8AAAQABQABAP7///8CAAEA/v8DAAcABQACAAAAAwADAP//AwAGAAEAAQAEAAUAAgABAAMABgAEAAAAAwAIAAUAAQAHAAkABQADAAQACAAEAP//AQAEAAUAAwACAAIAAQADAAYABAAAAAEAAwADAAAAAAADAAMABQAEAAIAAwAGAAQABAAFAAQAAwABAAIAAQAAAP7///8BAP///v8BAAIAAQACAAMAAAD/////AQAAAP3/AgADAAAA//8DAAIA//8AAAYABQD8//3/AgABAPv//P8CAP///v8CAAQA//8AAAQAAwAAAAEAAwD//wAABAABAAAAAAAEAAQAAAD9/wUACgADAP7/BAAIAAIA//8FAAUAAQACAAMAAgABAAEAAAACAAMAAAACAAYAAAD8/wMABQAAAP//AAACAAEAAAD//wEAAgD//wEAAwAAAP///f/+/wAAAAAAAP7///8BAP///v8AAAMAAwABAAIAAgABAAEA//////7///8BAAEAAAD+/wEAAwACAAAAAwAFAAIAAgAGAAIA/v8EAAUA///6////AgAAAP7//P///wMA///6//z/AgD9//n//f8DAAEA+//9/wIA/f/5//7/AgD///7/AQACAAAAAgACAAEABQAHAAQAAQACAAUAAwABAAEAAgACAAMAAwADAAEAAQAEAAQAAgACAAMABAAAAP//AQAEAAIA//8EAAUAAQABAAMAAgABAAQABQABAAAABAADAP//AQAEAAEAAAADAAIAAwAFAAUAAwAEAAYABgAEAAMABQADAAAAAgAGAAUAAwAGAAYAAwADAAUABAAEAAYABgAEAAEABQAFAP7/AQAHAAIA//8BAAIAAQABAAIAAgADAAMABQAFAAUABgAEAAEAAgAFAAQABAAFAAMAAgAEAAQAAwAFAAQA/v8AAAQAAwAAAP3/AwAIAAYA//8AAAQAAwABAP7//f8EAAQA/v/+/wIAAQD//wEAAwACAAEAAQADAAMA///+/wMABQACAAAAAAABAAMAAQABAAIABQAEAAEAAwAFAAIABAAGAAAAAQAHAAMA//8FAAUA//8DAAgAAwD//wEABAAEAAMAAQABAAYABwAAAP7/BgAIAP///v8EAAQAAAABAAEA//8EAAUAAQD//wMAAwAAAAEABAAAAP//AwBMSVNULgAAAElORk9JU0ZUIgAAAExhdmY1OS4yNy4xMDAgKGxpYnNuZGZpbGUtMS4wLjMxKQBpZDMgOAAAAElEMwQAQAAAAC0AAAAMASAFDSs7Vj9UWFhYAAAAFwAAAFNvZnR3YXJlAExhdmY1OS4yNy4xMDAA") {
          await this.session.speaker.play({ audioUrl: "data:audio/wav;base64,UklGRrqpAABXQVZFZm10IBAAAAABAAIAgLsAAADuAgAEABAAZGF0YSCpAADE9t/2/gADAc0FpQVt9cP0ue4X7vP3evdfBR0FYQyWDN8Ovg9tEn8TjBQ7FSAWkxaCCJgIrvHc8Gj1YfSsCVoJCQQKBPLwwfBQ/ZP9vQxFDfTzgPON4qnhsPfD93gBwAFM9wb37AIzA44QixFC/af9LO0G7Sn8VPzoCOAIXv5N/X/z8/ER9AXz6vV59XH+cv6hFEkVriSSJXsV+xWX7jbuvNax1RntEuw5GMYXWRkRGSz20fXh7dztHwMiAxUGOgUX9a7zqvbF9Z0BzwCC96r1XPCI7lP/7/7TCgILfA1eDcYaRRsdH1ggiwCMAA/oRuY470/tAeoa6NvVSdNa3xLdk/qy+RgHSgdXEAIREB69Hu0keCUQGTIZufOU8orZL9eQ78DtrgUhBdzyEPKR9Nzz2BlPGuIS5RLd7kTtzPaU9acNag1TBJEDWfM78rz3mveMA2MD7fi+9yzb59lP26TapwYGBmgZsxhp/xv/B/sC+5QKQwpn9HzzudhY1xvst+pUAxkCePdq9n3w+O/cCvQKOySHJGAVeBWk9Vf10vOY83YBYQHC/Df80/fC9mL8qvsj8cDw6eb45ZX7j/oiDygPHgT3BN34mfk0BtMGGxYbFwsNqQ3u6Nzn+siwxg3TItLn9VL2cQjmB4kQaBBBF8UZog4REOEC5gAkBJIDXwFqAzL6APolBL4CvQ0pD+r7H/0z4SjflNr/2Lzpf+q8/AX9qAVMBa8KmwsmD+MQhA6pD24NtA1TCxsLewO4A1T5hfl98lXx3vPU8tr5jPrj+jr71/jc9678qvyaAMABLfyJ/JgB0QFcFtUX3BihGvEEAwbT+z/8pfdL99Pg+t8+0cPPa94X3H3pu+e86kfrSgcRCSI3qzgoRYhHYihrK2cCPAPI7ojtL/LF8STxD/HC4VDgveG94H3t8O1U7vvtGfI68awAPwH5DFUOKxpyG1EkMiZqEiUUvvEv8hfq8+ky6onpFtdS1QLVrtNp9ov2QRSvFE8fFiBeJUknEB7KH3UE4wTE877zqvnd+S78QPyh7Vbt/eWS5dzuy+7O9jz3kfpZ+0b9hP6k/Qr/ogZWB1gQbRAG/nr+xeh66YH7tvvWC2MLdPK58YnsfuxSE8oU6x0GIM3/+AB5/+z/jxhGGYAFEwZ54LHg6u+s8PsEawVi5y3mM9153BwF8wZGCg0MlOsh61f49fcbEeURDf9u/0T3pveDCtQLyApoC+EQmxC4JIMlQgytDcjkJuWC8U/wJRAJDvEP5g5U+Fr5ruLB4wLyhvGtGAMYnRTEFGHuO+9D5VbmCfYf9ngBJQCOBngFWxL/EmQoBCuYHxUif+mK6JzUmtCf8EHtvO6S7WXgreBSB1kIYTRGNe4mTCe0/y8Awvb493MFxwYgA2cDlO+T7j/wIe9YBDoEsv/I/w3m7OQR7CnqAwwNC84UdRU6DZ4O4h0WH0M1/DVXDAoMV7i0tmS6irnzCP4JEhN9E9HqEerm/aL+oR2QH5IIegl198P3YgFvATj6gPhZ8djux/0s/V79LP7t9VD27v/V/6MDUgMZDm8O0C8FMoAuwzHQ/RQAjtqJ2mnf09wp+174PgKvAcTp5eqX8fbycBe9FwYQzQ22+uL3PxKBEgMk6Cb7FakYfAzaDYb+7P0B6OXlGeMA4jTiB+OO4H7h1PKb8rQAE/8Q/tX7PA7dDXYhsiPZDdYPEfa09f4EpAMXDvMMyupC6WzVntQr+aH6chP2FIf63vkl+DP4LxxRHmwWIhcl/Uz83gknCpwNhQ0T+6H5DvCX79rc8dyx3MzbdwTGA0EF8QSQ3mHe//S89pEnhSqKGQgb2fpj+8MFOQYdDmENW/kv+Kvrkesg8ffwrfAJ7xvu4utmCW0IUTUXN4gvKDP0+/n+aOkZ63f0DPRP9z70igFK/7UD0gTN8uz0d/rG+9gXOBliGCQYAQp0B20WxRU+FIcW1Oaf50HTn9IV9Kf0bQvfCuMHowUZE6UUASQiKW4YyhpfDaAMURXWFB4JaweF6gLnWujg5nnz4PRY6Fzpzezo7EgQYRD+G3IckQrgCzcHqgg6EBIRyAtxDY8EQwaDB9YF0/u8+NHcedz+2c7ZewhDBj0paClwDlIR+/lv+nYamBksJTInPvfv+dXemd+T8nvzzfnQ+lTrY+rD5aDjkPsL+oMaHRq7FrIXkgJuBDEWXRc+MhAzBBH9ETjca9tU4ljgvfS/9A/cPt3p38Pf9CbgJwBIYkujDdYP7uph6xMQXRGgEDEQ0tb+0iDAn70v5Z7lGhb8FbkjGCQYAacERu4H8g8NjQ1VCmgJ/ORe5Qj2D/dYIc0hlSjsKV8OKxAY6s7pI+b65Pv9X/2d/Ar7uPHp8OMGCQkRF6IY2AI3AvjyafQ6AlgFKhzkHIQV6hV56tXsmuUs5uwIKQYG9/T0dsqHyhHqsemmKTIpvSkCLE8LSw4BAeoAJPjy9tLleeYJ1cvUzd6x3AAN2A0ZKVwsZhCKECoBJwBOHHIeAhu8G1vzoO+R8dbvxQMrBfLpU+jn0dvOEfpx+/go0ioSF7UUL/gF9+8IYwy5HaIfHxQIElsNbgyVAdYBhtUr0lrHVMKR+Ff3ERoqG4YR4xC3DgcNvw/QDw4HkwgoAyMDDflY9hbnUuUS6xHshvvj+jUCQP62Bw8GexAhE24cDB7GHYYbF/0t+hzbmdrN6W/q2wXdA0EChP08/DP7wf35AvX2J/rnATX9gB/rGtIfpyP5AOUG1fFh8CPuQ+iL3lLcxOlz6xIIEAi0+an1b+p952MT4BYAKEgt4go8CWUPQwmjJxAn4guXEcjr5O68/w/9DAyHCDDrsekF4czg5wTrBSUU0BS49ObyP9lA14nwx/HHHDgeoh1iGyP9pfv39bv5sAXiCdf/Hf5R7jDp3Pzy+m0bhx6nE3oXuPT59Pj1P/NCBUgDzf4E/6Hroeuq5Mzi/AQvBCEl8CZAFYEX3QSHBh0HIgf2AG7+PAFyAI/+lQE75aTlb+Ku3Zb9QvvJ9dD3gONV4l8PIgvhNWA3dwoNEXvjTeVJ/BL3fgm9BILx9/EF4B/iV+Aj4NT0EvTbEu8SKxxUGu8Ljwhy+8j7ZgQOCUYauhu8GN8TUfn29F/eMd8j5zvprv4k/2b7tvt55bvkk+9w7KAXRhadHeYgBgEXBNv+ff3cEwUR6wooCmrvbe+u+Ar4SRNSExMEJQUp2uDZatJ4z9v06/H/D0oQIg7XEFIHNQlnBbEFHAL2ARADKgLgC1oJ6AtnCa/+Sv5z80b0u+jn5xrlCOIx+Yb2XAqHCXL+sP7995H4swjLCfALggz6CBcIFxkOF40TQBFF9Q30/PSq9SYBuAE75y/l/cbBwkTaDtZ4Cy0Jfx0RHrgGxgke8PrygPvc+3wXshUUF0UVovYC9nngvuA57VvtVwNmApAE/wHl/aj6RAmcB/oVzBbLD6URmg80EREUrBSP/pr9R+mj55Htk+zd843zV/fO9239j/5JAfcBegIzAlTz7PGu4C/eLvGW7ksFsANb8hrybvHB8t0jfyUhO4Y6CRUJE2jig+EYx6XG7Nv62hEM0gt8G1sbFROdEasSHBEH/AT8ic7IznLWFdXBFssUqSr+KXEBJQLJ6y3s2vvY+qUDLwIMAH3/xhCiEd4h+SN8DJAOKvCK78/7B/g1DQ4Ky+mZ6gS7QL1p2QjZLjDCLURU0lLhKKUptv5oAR7x6/Nd0YDQTcnHxPn/OPwtKsApeyhoKgQQ1hHS4JLf88R2wQ33LvbhQ4pGrEFqQ8IUrBSD+p76GdFB0ILGDMWm9bP13w7lDoYEPAKJ/m384hS6FsofiiN+9aP2JdRx0mHcxNmr9FLy0w/rD9UVGRneEIwUyRx2HlQr1isEG+AbKewf7afQMtGw15fXdOy46woQtg+5KYUq4hxjHiQC0gNr+bT66v9IAAoHEwc8C5sL8vfH9yLT4tHfzz/PdOyU7I4N/gwzH50etgj7CHDmFOZ35qjkewo2CUkUThSN5zjnJ+f+5sgl5ibkOhM8RhPRE0HojOjo4dPhCvjs9zwDjANo867z7PAc8X4ZkxqmKZkqXgTKAyftWuxZ70bvo+0X7fvomef37//u1wrKCkQb1BrVB0kGy/n1+HYGXAdHDeoNph1yHc0zEDUfFE8WwNU41tXDNcPl7fvuBQwgDsj2yvebBl0ItzpqPkUvDzK/+6r8tt8h4FLhWOGI8NnvNPR084jsRewP/Hn8DTBVMcdElUXQFBMU9+hA6I7gIeAz6ALmdPlh9pf5S/jQ35ffsMYnxQTk7OJ8KBMqvSUVJ8r8bPyuBVwGzfy7/jXSOdMM2tPa5BsHHmdPglJjPUpAOQYZCMX3wfhfHuYeRySbI5/rBelXyfPGrdQB1DXnbead+N72bQ6oDTwbiBt9+E736NfK1d73nPcBEmESyAkICXoL1ApdCVYJL/KD8VrZ2ddB1OjSiuwK7HsY7xjjNK816TEFMycoECrIFDAXR/TV9X3rnOz6AG0C9g/yEBP9rPzb29HaxdXR1KLuG+15EVAPGh9RHb4BQQBd3pncP+BS3vn5M/h9B+YFf/9//v/38veyADsBhh66HwY+2j+cMAkyEgBYAAHc69tdztXN19Nz0ojq7OigBOkDLQw8DOEBSwLLBvEHkB9VIeYrcy3zFsEXbeuE61rL9cq+zCzM3OVx5W8EhwQGJuMmEkRkRaFFkUZ2JaIlBfyS+2Ddf9xV0jfRod0A3RX3gvd2D+cQuRaHGE0KDAzD/k0ANv8VAEkETgRZBfgEjPnq+HPqp+nu7DvsKgOSAkIahRl/IiIikhfsF4H7uPvr9j33jBDoEQgDgQTc2a3aG9qA28339vnECpsMMg/vENkZTBzsKn8tlidVKWgRfhLP/of/5fO/85fifeEgyq3Ij8ZqxdHpIekyHhAepzoEO4czJTT2IHshiAVeBc3clNvnzUfM6umu6N4DAgOsAWwBp/uv/OcO+RDuL90x/DVEN90bBB2++L/5D9tH2yzWOdZB8h3zjRmqGmUqAisUFX0VmvH98S7q8+n/Ce0IoSIxIUsMwgrm6SXo9eP44XvuYeyF+db3aAQoA1AMEQs9CwMK4v9B/xv04/Ot8UzxY/dY9+/6Pfwa+jr8KAROBmIW4hhpHE4f2RXqF1EN3w0dBS4F6+sA7AvNcMwt5j3lMSfXJgo4ojcODxkOmN853jPJ1MeO0pPRVO7T7RQKKAr3GxgdghO2FYn0lvYU9af2uRxrHo0p7iqKDPQMRe1x7bbjQeRi6tHqB/IY8mf/2f+UC6oMggigCd4LAw0IH3UggCazJwoTYRPX9Qz12OMK4o7dINtb1DXRPM61ylPqd+cNFB8SFyBOHmMfZR47HaEdBw3TDe727fdD6V/rwunM7ATy6fR6BqAJ3Bu8H8sYDRx0GLEaZScPKYolFCaaEW0Qbv0T+zfuF+sx33vbC9VD0d7Yl9Xc7Cfqnw/NDQUlzCMaFgMVBvgl9/jmKebR6I3nNO+w7X3tYeyZ5c3kYO7b7XkV9xWZNhw4fz51QDw/yEFlMI4zIwpkDazm6+ng4BDkJvMD9jX+awA28onz8uI14yHoWOdo+rT4AAp2B2QXShThHlAb5BHLDd3sLOiNxoXBLr9nukXWUNL07FDq6/Y+9p79Df9CCt0M3SK9Jes04TcnIrEkIfCa8dnOCtDC5LDm5RIVFc80bzb+RPVGeiQvJuTjEORFzsfNPPFN8YAhxCEUOkQ6ljlqOqgnsShdB/sGj/Ty8njtO+v928PYntLtziLYAdXN3yndrOk+5wz2PvSq+HP3EOvb6U/xs/CUFRYW3Si4KXUkmSUMHAYelRGzE2UM/w1YDt4PggzmDbv+eP/T7N3s3tuw26fUJdSy7Ffs1wr4CicLiwtQAT8C9AZOCHMWGhc2GO4XDwPBAgjglt+7ycnIgeM240sQOxEhIdQh+B/rH9IVfhXJAtIBs/Wc8/z6fPgzDFkK5hCZDz0J/gdVCDUH2gMSA0zskesb2V3YJej359sO/Q/ZK+wtOCmPK5UTDhZt/NH+o+L941rca9y/9En04wjbB74IDgerBqIE9w3dC2wZNRemHD8aChGUDjP9xPoX5I/hYso4x33GCsNC1sTSs90z2tfa1tfL4yHiPgeJBpg0KzSKR1dHlx8ZH/3Nb8yGoMee3rBMsIPdcd7YGBIcMlI8WA102Xsie/9/mXAceHNWSFwVLVIwewi/CXXlKOV1xFLCG8f7w5XfJdzD41Pf8820yLe497Nhvmi6Y9+521MW6RPePII8hyPuI6n0KfXX6f3q9/NL9eX4SvlP9Ar02+2k7SXsAuzt8cDx4gZzB3UjXyU2NBk3rjIcNoAdECFp98X60tBg0667AL0qvWe9qs9az5bn/eYj/MD6nRaVFPM1bDO/PzA8di9pKncSuwwg76Lp+tL6zZzN1Mk84rLgZP+DAB4WXRmNMJM1WUy6Ul1QL1eYNac7yw53EyXwN/N14AnibNuD23TegN2i7ZTsY/16/GYESQNyE10SzSL+IW8WZRV68/7xq9IO0fHFN8QPz9jMkt/q3InoieXb5rXjXeMM4BTrmec+A+T/pRSpEQsDMQAo2rDXBMDTvg7Nuc2a9/D5rCzkMClYSF4JW6lhvj1gQ2Ij8CftEBUUewLWA/j4APnP8ljyh/K28dL6MPlMCMwFmA7QC8n9C/vh3i/cWNxm2o4AJwDxIHohBx5LHon+mf7g3PHcMcZ4xXjKIcnZ9zj3IiMZI10p/ihoEgsSA+HU4Jy2LLZywT7Bhfdg+BkiDiQuJfQnPhi6GzsMVA9eBoII2gVaB0v6+/oP8aPwH/1i/OAN8gz1Dg4NPwU/AkwAF/0L9rPyEOd+43fvn+xABYkDzA2VDPwHFwfq+Gb4/+za7Gzzm/PoCY0KLB5SH4YgACJmEecSof6p/y/31/fC9nn3APPb8370kfU1A9sEbheNGZshcyOkHvQfAxMHFGrxyvFkyvHJg8fgxtfgA+CP9wP2FP9I/fD5Pvgt9jH0VwAn/v8TTxJME9QRjPi29j3ikOBA1CDTes6ezcTghuBNBG0F6yVVKOE5RT3XPt5CMzmUPXcs4jAAHMAfVQ0VEOkB6APx723xSeDY4NDqy+rLCvcKDyOOI7chpiGGGxob9BqFGi/7y/kwx2nEG7M2sOi7hrljzUjLueqP6YsU7hS/OhE8LENVRDAsMy15CG8J3udB6I3dpN1T5BTl4eZV6KjtqO+cBWMI1yBzJPwp3S3NJNkoeCK7JkkdIiEuEQQUJwANAp3hIeIjxDzDncAEv3vW+dTt+cP4iyEsIe1BdUJNSDhJXC79Lr4ECAWI34/fPc45zjXWudb/7qTwHw0GENIleSlbMC80TSvfLlIZBBzTAjkEYvXf9cjr6Ouf24Pb5dS51OXjQORu/Ur++BDZEZ0WfBeLEYoSCATZBEf3ifdA+zL7AAcFB3oDcAPQ8a7xa+d9597xQfLXCDUJWxZeFv8PDBAn+sL6md2A3pDXx9j59yf6QhkFHDoamxywAo4EYuoB7DHmZefY+G75cxcKGB0tJC7pJtsn+RF2EnQGrQZfAoQC0P24/Qj/3f7VCEcJahCSESIHmAhV8q/zqOpI7D3x2PLe9vD3hPxN/dD8wv1e9Of0DvP28ur+ev7cCkoKoAmBCMwBZgBE/wX+n/pS+Xj16vMe+6f5zgCt/6r7wfox8rDxaO+D70H3yfetAFIBTgAbAan1sfa87vXvS/rU+7MQfhI+HRAfqRgqGhgMAg1JApoCw/3R/YX/pf9mDNEM8yS8JQU37jfVK0csawgTCKzlheRk1LnShdWv02Lg3N7R7t/tAf1b/EkFzAToAmEC6vlE+Xj45PfJA4kDeA/HD00OHA/sASkDT/fH+A32wPdQ+x/9OAQCBi8UJhYyIvUjOh4+H6ELsQth8Z/wW9dz1YnKoscVzfbJ4Nbn027hc95j9dPypRISEbAh7iAoIA4gTxsOHL4TGhWSCA0KTPya/azywfMT8kbz9PyV/vML1g1pIaojMTzzPoE99T/zHEweIfLS8iDNes1vvkG+s9Fp0df6GPuwFzYYShR1FDcC4gGo99X2S/3A+0IK8AcQCB0FXPAC7cTSXs+QwxjAnM1+ykbwYe4pF+kWJCsGLAovJjGKI6gm3gYJCkzuzfCE5Y7nQ+X/5h7reuwB/fn90RukHF811zWUNEU0uR1OHHAFRANM8qDvxOOb4JDfK9wj5Tji4+2M64n1nfNhAxsCGRjfF3cdoh1GE1QTRgoyCgX8ePuA5gPl6Nb31EzVsNMs4UnghvWx9aoOLRCiJjUptjOnNg8rvC0gDCsOyeg76vPV1NYd3YHdofYB93oQ9xArGzEbPRZGFUIMnwpx9eXylNbf0ifRTM2x46XgcvVK84UAYf/sCEAJNBJ3E6AYEhqTF+sYcwiwCX/zevQF7/nvVPkr+hEG5AblD+cQHRTkFKkUqxRlEjsSQwlICaf1KvV39MrzaA2DDWoMkwzS82XzJu3r7P/y8PIa+WH4MP/+/d4DsQJ1/sH8s+487NXjGuFo3p3bS99y3JrrKunM+hL5lQWwBBIM5wtGEbERYRU4FqISwBOgAacCuu167i3t4e1L+rH6SwZTBoILyAvfCmALhhK+Eswk4iQLK/IqwQ6kDT7j9uAq0ubPwdsa2u/ute0ABQgE0BJkEpwWBxfhFsgXXROlExsJlghL/Xj8lfHI79vldeIK5Wfhi+sA6ffyG/FBAq8AZxAeD94RIhEdEf8RQR0iIMspnSyIF04YW+6i7fTTgdLK1RLTnehN5bX7svlABJUDzARQBMcC9gH3/aT8B/hg9l7ywfAC8gTw1/2p+zgJAQi2B3MHHgWMBG0KDQrQESQSVBb2FQIZ7xdQFwwYkBH2FDQLPQ+8+0T90eOW4c7YOtWF5SzkcwDyAI4ZShooK8osWzSXNksoCil0/yb/CdIv0grGPsYZ3wnfDvun+y8DQgQcAzkEXg8FEIMiziCcIqEeNQu/CPXxlvLJ5IjmPuIE5knmxe1n7lj11fzL/RsOBgt8FZsTZxP2E0YQrBANDV8KrAe1AhH2VPSU1lHb/MbezRfZL96F88f48AYjDMoeyR6pMA4scSxlKhMbSB0gAmgCSunQ5K7p2+ahAsUIYRRoIegRyhzYBpELMwKtAp0F7gDR/EfyFuYL3SrhUOAL7iHyEe/78uzqJ++K9Yz62gQUCLYLNws5CJEFRf0q/M36n/vIBQAFUAfmBZf5y/uG97v7ewlIDHcWLRtYECUZYQKJCTf3sfZM9MvsIvqc8Nf52vJX7fvr0ukK74D2DwAp/4oI6vhy/g7sHOxN6HLkyPYF89oLGAgWGQUTdRysGA8SBxeNAUkLF/7ABM8EzQeJDWkQoRi2HOASJBZL+Of2CuqU5BLyLO1W/k77BQW6AuH6Hfzg6ZfvEfIO+NkG5QrBBd4HwfqG+Pb5TvS7/m36EwVYAh4I3gXmBMoGEgKrB/b7UQHT8735I/g//O79k/mG8/nqjeqt5eLwAO1m94z0gPnf/d8BOQmvC+MOfgpsDLADvgVPA08DjwaFB04JpAo5DxALNRG8CsoIPQcbBCsG9AY9CkIBGQfK9eP7RPh/+qkI+AaYEEwNoP/I/JvhLd7bz+HIcdU9zpvvzu9HELsV8B/lI0Qbwx7qEeQVYQZ/BeT2cvEg7BrnvuqZ5s/xk+9I+4n9gwDFA/sKPQzwG9odZhv6HS8IAAn2+zP74Pje9Wry/+2b6qTp6uiX6oP0hPJdCjIHaxcYGjgU/RmfC/gNdAN5A6L7cfuZ9gXz6Pa58In81vprAcUESAKWA7kGyQWOEYkUcxe+HBwM4gxw83rwxeUC5Zfx1/JEBJwDIgsjCSMK/AmMCRALOQurC/IEgQPy7krtTd323Efiy+G287XxVAeAB0QTyRhxDDkSKQPUApsDgP9z/lX8ePf99qf4jfbQ9j/1SPi8+xAEcwm8CNQJVw1oDAQdCyAnGwkgev8AAP/mUuJA4NXbGu1c7G8ADP/MAE/8Af11/RQOhhY8G0IhlxE2EpkGRQm5AI4CJPa97gPsEuEw7ZLpLP6lAc8TShhYGOAbIw6rEYIJTgxoCmIKqgTRAu75svio8S3vH+x35VnqdOKv9DDxnAfdCrcPHRcnC74QzAZkB53/Sv639uH1uPfs9M33c/J38R/sv/ip88YFAgKMA7gFyAMlDHwQ6xcwEfkS/gJKAS35V/Z59VvwpfHt6HztweTD7t/rYf/TArkXdB3HHtUkGA67E136o/x79wH18wEq/HMJOAOQEB4OMh24HpMcPByWB8QENfQ99WHtBvOO8E72k/md/C35k/fU9VDw1QbgAf0VxhCwBmb+PfGk6zrpCuxW6VbwHfas+6wDKQfOAowElAcNBzsSGw9WC1IGqAbOAe0Sdw/XELIPiP6tAIX0JPfs7p7vXPA88+4BnAcCC7cLAgCj+fb5w/OQ/dn6tP6a+7gDX/6fCP0FLvszADXnUu6P55TnbPnT9KYJTwgKFBkW4RuHHr4bIB3yDTsKsvoa9E3zuvEC/AL/fgRtB7P+/gI98273dvfg9T0OWAmOGysZpApWCtnxEfOS7x/yB/yw+4wAe/xB+mL4ZPS39wz5av1zBN8D7wcGA30DDAJ9Af4ECf46/tnzEvAY7FHsRfFS9DMH1gaXHx4eIiBoIRUNnA8GAvgDJv+q/8r4zPf+9OL0R/ZZ97j4X/eq/nP6NwGU/iP6D/xW9x77Tf85ACsEUALU/b/7pe8j7Vfi3uAW427mQPer++YSrRFUIJccshP1ErL9xv0/9772YP0GAEwEpgo1EuIXEiECIzQZDRnX/vH/zey07Tzqreap8xDuEAUQBFsJHAyU93j4ZOpB6XPsDe2G7WzwHvF187P9jf3BBP0CPwRYApsCVAAg/ar7fgJiBHAaVh4/JOUm0BT6FiwIdwuRAYcErvda+Rj1z/Qm97HzzvGL7QPvtO2v91T4wAMYBNsLHwyICYMJCPyF+xzxFfJw8jL1+PgC+//5qfgD9LjuCezi5f/j0OGU5ZHnZQQNB8EzpDYiRZxJaS2GMdEOOxCS+Fr4F+RB46rd/ttI8dfv4gymDOwbwxvDHj0e0Rl0GlYOdhCkAXEEjfSN9v3k4+MM3r/Z4Oij5Bb7wPjJCpwKyheWGeYaGxzBCo8IHe8I7CjfA97P6Pno9Pu5/UIAPgPr++P6TQGm+2UJXwfOCWINBwztDSMTmRGqElATyQnVDEsCWwPx/J/7Vvm/+FABmQMfFBcYJxyIHb0MfAna8HXsXNaH01vJxsZV1CHSlO2b7boAEQIzDPsMMRO9E/IPwxC4CkkLqw5nDnEQNQ8uCAEH2P+ZACD/DwI3CzQPQSAOJEklcyfsEHYRp/6A/2L+KADAAl8DAQSHAmsFcgMNCFwHKAtGDLwHogk4+ET5weii6IXm1eUS7bzrjfXC8+j8r/tW/F/7j/Pu8Q7vLO0g90D2XwSSBBcG/gbw+yv9zfq4/DgGZghJCywM4A3bDNMX2hbcFD4VHQEWApr4Ufl//Vn9T/8o/gUArv5r/sn9tvae9mD3dvenBbcFfBEmEUwObw0d/ZX7je226+Tw++86AOIAuAs9DRASgBPBEv4T/AwyDp4JlgoPCzwLhAsJCzkM5guKDLMMggPLAxDy4vFT6N/nWO9D79v67/oo/nf9N/0V/Jf75Poj9CzzxOey5fHeItzv4oDgffbX9QcKmAt8DT0QOgsADhgRfxPHFiwYDxIZEgYG4ARJ+Yz3KPF978byBvIAAKcACA8UEUwQxBLgBKcGVvri+nTzofJh8Svvuvob+KYHeQXlCHQHIwGLACz9y/3//40BuQBrAsL5i/rj9Jr0hPrO+SIEZQPuDDwMQBObEhMQUw/wB1sHNAfMB0oIQgqRABUDJfcb+cT1hPZs+Z34jfo9+AL3rvPU8WLu1O4k7IPxHvDm+hT7AARlBZMENwbX/e/+TfdT9/H1v/Qw+hn4fgIaAH0KhwjPB6gGpvgh+KHv6+/v92X5HgQWBl0K+Qu9C5cMfQZJBv4A9/+6Bp8FcBLKEQoY8xfPFYoWDg+gEF4HiQnjAO4Caftc/ED3i/Z/82vxrvDd7W3xxO4j8grwHPE/7+rzYPJI9yD2MvRE88HwTfBV8nvygPbu9kb+m/71ByYINg4iDsQPqg/rDPMMOgldCTQKlwp5DCMNOAzzDBcLIwwiB3IISwGLAvz+AwDP/jH/4/9W/5MCPQGf/nr8yfT28Szxae5W80Dx2PV89JP6KPpG/qD+Af2W/dn6Ovs6+ez4L/nj9+3/IP7dCkUJPhFPEAoSLxLWERwTDxI6FIEQ/BIvDE4OfwflCCoClgJP+GP38OyV6mvqXufK8yLxDv5+/KT+Mf6D+eP5kPeF+MD5yvor/bD9s/5j/rH7dPrm9yP2pPkf+LUA/f89CrQK6hGWE5YRMRSjC64OiAenCh8HvgmuCksMdRAEEXMQ/g8xCRkIPQNVAoUCVAJdBPsEGAUsBm3/aQDW8i3zI+jD5+/nDOfD8H/vZPrH+HAAs/5IA+cBSgHEAJ77y/t3+UX6I/1R/hACTwOEBtoHwgk9CzEKmgssClELEQuiC0cKVwoXCPUH5AU/Bm0CZQPW/S3/4voR/Db6yfqA+VT5Qfd/9qrzkfJb7zvuue3B7JTzL/Ou/RH+twK4A2MCowPOA08FoQgzCggNgA5hD5oQZxCLERwQUxHjDD8OfQjdCeIGUwhJBr4HeQK5A/n98f7w+6L8+Po3+0/6B/qg+dn4PPci9qj0kvOn9N7zK/bJ9V/5SfmX/sv+iAC/APr79vsn99D2Zffz9sj6UPoL/5j+IAQFBCcJoQmwDOANoAw2Di0IiwmZA2QEjAK5As8BjgHr/37/ggBAACkDOwMLBB0EhwNkA2gCBgJF/8L+Bvt++g73kvan8w/zSvSU8wL7Wfr1AYgBpgRoBMIEzgTHAwUEIANuA58F9AXDCCEJtAbsBm3/XP9J+A34F/fd9u/8+vzVAgcDYgJvAsz+n/7i+5D7OPmv+Kb5/viE/wj/cAU5BaEFnQU4ACMATvn8+JT2//Xu+Er4Tfug+gz7dPp/+hL6EPvN+j/9BP0IAbsA+QOKA8ADSQPTAHoAeP5O/t7/AgDbAxoESwZ9BokFiwXoAuMC9AD9AFoBfwEqA04D8ATeBD0FAQXgAYwBtvxY/Mv6lPp8/Gv8uf+f/zgCFwI/APf/Xfv2+g/6r/nl+5T7jf0G/Yv/0/66/+7+q/zZ+4/65PmS+iv6FPut+jj95Pzx/qP+tvxZ/Mr5ZPl5+i/6sf6B/s0EyAQ7CWMJvQnvCY4HyAd8A5EDWf8l/yr+u/1o/gD+K/7F/Wb/Tv/WAOQA0P+8//L+if4d/5P+rv7+/QP/kf5YACEA6f/O/+3+vf4B/8H+lv5G/qj9U/1x/Tn9Cv7Z/fL/2f+RAogCdQNvA8QCtALbAckBtgCaAF3/KP80/vT9Kf3k/ED89ftJ+wb7zPp6+vv7svv0/bf9E//m/sj/o//j/9T/Df/9/ur/6v9MAnYCMQJZAqMAwgDkARQCmwPpA6UC2wJ/AakB0QH7ATMBTwFQ/0f/Y/0u/bP7QftK+9L65Px1/N79kP0y/eX8+Pyu/Ff9Af2g/Df8DvyX+1j9/fwj//j+YwBrAJ0BvwFmAp4CQwJcAt4B4gFMAj4CygPeA0wFfQUgBWgFgwOwAxYBCgF8/Rr9lfnf+G73jfax99/2Xvq5+QD+lf2s/0z/P//K/mD+zP2D/NL7YPqa+YX72Ppx/xD/CQPcAngFjgV0Bp4GLwVVBSYEOATqBPAELQUnBTIEDgR9A00DaAIrAsIAYQBSANj/GwGOAFkB0QARAZ4ADwC6/+X9hv3C/FH8nP4x/hwBsgABAYMA7P5C/oP9vvwW/kz9oP/c/oIAxP9pAMD/7/+C/1n/Ev9Z/hX+O/3P/BL9dvzQ/Sj9yf0T/SX9bPyr/vz95AFTAQcDdQJwAc8AGv+I/lL98/xf/Un9wf/5/zsCmAIKA00DKgIvAgEBswDVAWQB0gRvBH0GQAbDBaUF9wP1AzEBNAE+/jz+2/zE/HX8UvyD/G78+f0C/t3/8v/9APwAbwEzAXkAGwDH/mj+cv5B/qL/z/8AAsACKwV6BrUFJwc0AnADF//r/zX/yP/FACYBggGeAVgAJgD4/Z79cvsX+6/4RPhU9/32cfmB+fv7ZfyO+yP8s/pU+wr8h/wP/n3+N/+J/7f+2v73/PP8jPzL/K//VAA/BWMGAwq8C1ELYw0hCTcLrQWgB/cClwQxAlIDKQLyAtT/HwDb+ob6kfbV9Wn1mPQl9232cPn6+BP6AfoP+jL6zvo7+xX8vfyc/kv/sQJxA3QFUwZlBTYG2gSVBe4E2QXJBdYGqAcACQ4JrwoiB8kIrAL2A/r+IACX/Yb++vyH/VL8mfw2/DP86vt4+6n50fjq9s31mvZa9Y74nvc0+sb53/qt+gb8CfyL/dH9/P1L/nH+tv6bAB4B9AK0A1IENQX2BRkHxwbzB/0E9QXaAsIDgQJPA+gCpAPUA6wEIAUBBlsEBwWtAAoBjPyB/Iz6GPqG+w379/62/r0CvAIxBGEEEAJSAsv9tP1o+f74S/bJ9XL29fWA+kX6ef++/94CWgP8BGoF0AQyBd0BCAJg/0L/JP8S/zn/N//0/uj+wv6z/p/9cf1//A388/2J/VABGQGMA3EDZQNlA0kBXwEA/tT99Pp4+t75H/k2+1v6r/3O/Fr/tv4yALz/ngFMAY4DdgOQBGoEnQNOAy0BtwA8/qP9FP1k/Bf/pP7NAo8COgUSBWAFSAWhA5UDXAEjAd4AmABVAkMCpAOPA64DlAO9AqkCMgH+AJ8AXABNARkB9gC/ALr/Yv8v/9H+fP7//d79VP0A/5T+yf9r/2H+8v11/RP9bv0a/av8KvxJ/ez8xQC0AC0DQAOjAtYCxwEkAp0B4QFTAZIBzAEgAiEDggPCAiYDfwDeACcAgQCRAvsCsQMNBP4BEgIzAA8AY/9M//z+6/7a/8z/0QHzAXUCngIhAP//bfsN+133vvZm97v20vuU+6kBIwI+BvoGygeOCOwFpwbcAmQD9wA2AWIAtwD5AIABlQI3AywD1gPCAWsC2QAlAY8BdAF1AVMBqf+s/+r97v0+/Gf8GPqV+vn4afkn+h/61vyR/Lb/k//OAcsBUgKYAicCvwIHAr8C7gG1At4BogLCAVUC7ABAAY//EgAd/8n/twAkARQEbwQMB4wH9gY2B6sDXwPj/z7/Qv2l/EP72Pqd+YX5pPmx+Rb8FPzc/hD/vv8CALT/Uv9NAB//tACT/w0AcP/A/2D/EwABAC8AwQCNAIgBowGPAsUCcQP3A3kEYwXjBVkFIAY7Ax0E6wBNAeP+1v7/+6r7avmP+LX5d/jJ/GH8hgCdAfsCxQSIA6MEdAJMAhIAuv5K/Sj7qPxR+jb/tv0LAhwCbAK9A0QBlQLT/4IACP9j/9f/HQAuASIBYgFEAUoCqwL6BPoFngaOB+oFDQbyBEYEkQOnAvj/Xf8Z+9z6avdO95L1VfUY9UD0CPZO9Cj51vbR/dj76QDj/ywABwCa/cT9ivyC/K/9a/3U/zb/dAJkAYQFrwSQCOMItQoiDEIL3wzqCaYLXAdsCcEEGAYSA24CrgO/AWUHCwZEC1ILGAnDCQEAggC+9xz4u/d1+Gb/dACtB2gImgaNBjb4xvdT6YzoAutt6cf8DvrFD2INIRa1Fc0HxAjt6/HrD9sW2j3nvOeLCXwMqitdLhY1RzWlHPYa+fW4857dJ9vq2wPaneiY6B/6Kfx5CGUL5g/0EWsSmBJ2EgcSFhDEEDkI/whz+P/2CeaY4pXacNew3Nba8e4C7vMItAiyFcIVowvkC9n65vpt84nyofOh8RX2APSI+2D6wAMIBOANQBBlHdYh1y/iNKozbze9GiscJfJL8fXWbdX12B7ZQvR09hMZSxugMkE0sDPDNYQbnhzN8FHuAcnYxBnEZMKg4zfkhf/v/jD5nvXM2SbUP7xytlW4tLSF2eTZMhFDFmg+x0ZfSJxP2ir/K5n5Y/R03C3Wv+zL68YVGhzJLK42pyRnLW8WZhzNGMgbkCEcIRYaRRcBAlb/veou6VvdiNyV2w3b5ehu6Pr9D/6ABXUGL/cg95PmpuMq7NfnhAeMBOIdEh2ZFpwX2fig+37kU+go7L/vyAP7BVUVYRZhGIEZchLUE3YKswq1AkABofz7+gb67fnb99r5R/Ef9P/pIuty7Hbqu/xR+aEUOxKgJ68m4iV6JdIHxAba22PZUb/ou6/DR8EP4p/iwQgVDWArjDJsQjFJsEMXRr8qIyiWCN4Etvap9tX4xv27/bME9fqU/kvzSPCQ69zjK+cj4N3pk+YJ9kD2ZAmQC88VbBfdCAsHbObA4EbL3cT2zqLLXPIz9AUkOirERj9NFkRlRs4hsh8X+Qf2Zt6o3L/aUNqr6yHthwH7BasMCxOoDu4TmBOZFdcbGRpyF/USu/yJ9xPaCdYgx+rEJc0dzNfkpePR/5X9qQ+ZDUEQwBAACsANXgWBCj0EFwhFBw0I9gunCSIMhwi2CMoGFQxUDkAb8CG+LRA2+DSxOj8msyYoA7n+fdwi1nTIZ8OJ0JLNK+mz5vb8DvqQADH+6/jY973wRfDj7YXs+u857ZbyDO9a8g7vpvI08Ef6uPlSCqUM/BpzH7AiPyYFHgUfdROOExULtAwbBZ8H7/yx/Zz0I/Oz9BDzpwC4AHoQaRGoFnEWVwxECtP4S/bJ62Xqte3P7fr4vvmlAVsCHQHFAPD5u/cA9ULx3vm59tkGfgaSEEQTLA0SEZH+sQGt8Dryle7c7o75fvhsB8QEfAxjCOwGFwN3/x/+G/26/57+eATc/lgFN/sN/yr2F/Xd9UHwy/2M9kQIQwPNCnMKFQLSBS72Pvty8qr1bflS+UkDvgCDB7cElgRHA2/+kP4Q+Vf5AveA9i75JPg4/pH9DAI9ArcBbQLNAHQBkwXlBSMOUw76EKUR+wnRC8P/vwJG/P3+igIfA6sLjAm9DqYLpAoeCR4ENgUr/osASPnB+k/2CvYp9u/0PPcP9sH1gvRx8SjvAPF27df4SPUWAjUAVwL+AuX4RvsR72nxS+4F76X2KvW9ACP+tgjJBlsPgA+9EqYUGg9+EWsGiwh6/7cBCv61APP/WwKMAYUCOgOCAhEHkQVCCggJagfmBnX/1/8R+oj7I/xb/qABYQMhAy4DNf9e/Yn6z/fB+C72FfkP98H4XveX9/z2zfgp+Uv9bv4WAYUCKgJHAzkDlwPPBDUEPQQHA9kB+QBTAZ0B/QM3BYgGrwdABaYFwACkABn9F/0N/CX82vt5+076Fvl/94v1Kvb/8474ovZ+/ET7Yf/t/kEBVwHhAdMB0/9k/8/8X/xX/Hn8tP9tADcGEwceDcsN/Q+cEOkMdw02BngGTAAoAJX+c/46AbgBKAVBBrcG1AdKBOAEAv/u/k/6u/ly+WD4nfsQ+nn9wPul/Df7z/n2+EX44vdf+mT6cP7d/rcAiwEnAPYA7/40/5P/Pf/9Am0Cjgc+B4AJawkTBv8FQv8x/y36hfoG+v36/v1Q/8oCEAQVBfUF9gNeBFkB/gC2/o/9+/xs+9r9svyEAFkAiQEyAjcAOgFF/3IA5P8OAYkAXAH9/wcA7v0b/br7h/qt+4/6Cv47/R0BogAYAyYDGwPkA6wBHgPIAIAC9gGiA9UERQbJBqwHkASBBAH/9P29+1D62f0B/YMCtgKZBbkGyARVBlf/yADz98f4k/OO89T0D/Ry+lT56wDM//sD8ALfAeYArv30/Dr7DvuU+yb8Gf5s//sBzwNgBV0HeQYHCJAFWwapBLIEuARqBPsEvgQ5BV0FBwa9Bn4GuAfRBDEGzgDRAWv8tPzk+Yj5P/pt+cH7nvqw+0v6Lfq5+Hz5Pvg5+l/5Nvu4+nz8Y/zx/kD/yQFxAjAD2gMcA4ID2wL9ArcCqwKCAnECGQMSA2wElwRyBc0FTAXXBaoDGARKAGsArvx0/Nj6VfqK+tn5pvrU+fH6EfrD++z69/xH/H7+8v35/7j/AAHsADoBZwEYAVoBEgFlAXUB1wF9AvICaAQJBSgH+gecCaYKNgpJCz0IMQmMBDMF/wBXAZL+pf7K/KT8NvvR+gH6dPnZ+Bb4rPfH9pH3h/ak+Iz3eflt+IP5lfhR+X74/fhM+J75CvmV/Df8kACHAP0COAMiBLgE3QXJBvwHPwldCdIKYgnPCowHygiHBHwFmQJgAxQDvgO5BFEFLwWaBW0DkwMJAM//9ftS+3f4efdV9yn2n/h496v5mvjw+MP32Pej9sz3lPZ3+ID3L/qM+Tr9Bv1DAY8BjwVRBrMIwAmsCbAKPgkpCnMJYApiCmoLTApjC1sIUQnVBZgGvgNQBBMBLwFV/er8vvrQ+Xz6WPmQ+mX5Mfnl96H2K/VG9KfyDfNj8Ubzn/Ey9arzsvmG+OT/RP+LBHoEuAXmBUkEkwTDAf8Bxv8PAOr/SwA2AtkCjQV4BisJYQoJDFENogzFDc8KrAtFB8MHmQLLAvz96v1B+xX7Hvvt+n78Pfy//WL9U/7M/W7+0/1C/qv9EP6Q/Qz+tv3U/Zf9vvyF/Dv75PrN+l/6SPzh+1n/G/8BAxMD/gVTBs8GVQcFBXwFggHKAd397v0T/BD8Qv1A/VAAbQATA0MDiATHBEoElQRaAooCMwBQAJz/pf/B/7r/1/6+/vz8rvzt+4D7wPxJ/Oz+jv6TAFAAJADS/6r9Rf1E+8L69vqE+sT8Zvzi/qL+tACMAFYCWQINAxoDWgJ4AsYB2QFNAogCFQN4A3ED7wNwA+0DYwPEA2IDqwOJA7QDWwNxA84C0wJJAkcCgQF6Adv/rv+M/SX9Yvu5+lv6gvni+gL6mvzH+17+tP1i/9H+Lf+u/gv+hf3e/FP8bPzi+w39mvzB/nv+BQHxAP8CDgNPBHkE+AQrBcMEAQW7A+4DUgKCAh0BPwE8AFUAb/9h/+D+qv5M//7+XAAGAOMAmQB9ADUAv/+F//P+u/4Y/tz9W/0H/Vr9AP20/mT+pgB6AL0BqwHkAfEBqwHCAbQA0gBA/0v/lf6X/hb/Ff9LAEwAewF0AcMBuQH+AO4AMgAeANL/u/9+/2L/gf9u/xoAAwDk/8z/Zf45/jn9/vyY/V79cf5J/sz+vf5N/1//vwD+AFoCvwITA4gDlQL8AnEBuAF0AKIA3f/1/6b/sv8CABcA4AD6ANcA/wAZ/zb/1vzi/N/72PvQ/NH8+v4J/+EAAAFhAYEBiACmAE7/Xv9g/mf+/v33/Sf+KP4I/yD/xQDqAG8CrgIJA0oD0wIVAwoCPAJGAGgAP/5Z/lX9Yf22/b792f7s/kkAYQBhAXkBLQEzAYn/jv+j/Zr9q/ya/Av9CP1k/nf+6f8OAM4A/ABxAaYBgAK3AmQDnQPWAggDKgFRAeX/DwCa/8L/tP/f//D/FwBcAHYA1wD2AAcBIQHUAOwAtQDOAA4BJwEwAVYBOABLADv+Of56/GH8Qvwg/N39x/2TAI8A/wIFA7EDxQM/AkcCZv9e/xz9Dv0J/ff8gP6H/rf/xf/3/w8AEQAeAKYAuADyAQoCeAOPA8QD1QMkAjYCa/9y/6n8mfxM+0P7IP0n/XEBmQG2BPUEFgVlBRIEVgT/AjYD4gESAqkAywCY/6n/sv68/hj+Lf6r/sP+vADWAE0DawNcBIME7QILA/v/CQC3/bf9g/2P/cL+z/6M/47/DP/6/nX+YP4Z/wH/9ADqAEkDXwPTBO8E3QMLBIkAjAD1/Or8kPtt+yj9Ff12AHYA7gL6AtsC9gLwAPMAaf5R/nH8PPwH/M771PyU/In9Wv0F/tv9z/66/o//gf/y//D/KQAkABMAHgAtAEUAuwDZACYBTgGWAdEBsALuAnYDsAMNA0UDsQLlAvUCJAMiA1gDYQOUA74D8QM4A1sDJgE6AWz+X/5f/D78KPz5+1z9Kv0//gv+Sf4W/gX+yv2A/UD92fyc/KP8aPwL/dj8w/2g/RH/Bf8CAQoB5gICA68DzgPmAgsDiwGeAWIAaQBo/2r/GP8S/4n/gf/v/+f/KAAiAKIAmADIALYA6f/Y/6r+kv5l/T/9Svwm/DT8D/xF/SX9rf6R/uj/3f+pAKcAgACCAA4AFABEAFcADgErAbUB2gEgAkkC5wIbAy4EaQTYBBwF7AMTBBsCSQKoAK8ACf8W/2b9Uf0C/en8R/4n/m3/VP8n/w3/Nf4M/hP+5P2g/oD+rP6P/uj9zf2w/ZD9pf6N/p7/jf+7/6T/Of8e/w//8v5X/1X/4P/b/w0ADwAQABYAKwA3AGQAbgCtALYADQESAUUBVQEaAScBvQDLAIYAiQCLAI4AagBjAKL/jv+D/m7+Wv5C/hT///52/2X/KP8Z/7/+ov6S/nD+6v7I/sv/qf9vAEIAFQDx/43/X/8E/97+Pv4N/pb9av0j/vr9lv94/94AzwB5AWsBxgHDAUQCPwJjAmQCogGfAeAA0wD+APEAigGFAd4B3gEJAgMCzwHDAeEA1wCb/4P/Qv4U/kr9Df30/Lf8B/3M/D79B/0a/uT9fv9a/2YAUwBZADoAbf9Q/+P+xf7P/8H/eAFwASICLAIgAisCGgIpAnYBeAEuADIAxv/I/5YAmwCuAbgBCAIgAoUBjQFCAD0AFf/1/nT+V/7Q/qP+kv9t/6n/g/8G/+L+kP5s/jT+B/6S/Wz9gP1h/Yf+df4aABcAjgGpAZsCtAKhAsECJAI4AgMCKQI6Ak4C0gH3ATEBVwFKAW4B2gEEAisCVAI4AlkCAgIOAigBNgFLAFMA9P/x/0X/MP+0/Z79w/yo/Az95vwD/u39xv/A/6kBrwHWAd0BFwAWAIz+h/40/hz+jP6E/lH/Uv9UAGAADQEaAUwBXgGQAaIB+wEHAjUCQgIDAgwCNgE8AbX/p//S/bn9xfyc/CP99vxq/kv+n/+G/zEAKQBzAG4AwwDLAOgA7wCfAKoAPgBAAC8ANQBbAG4AGAEvAQ8CMALUAvUCRwN1AxsDQAOeAboBzv/0/4//ov89AGIAoACzAFsAbwCX/4z/fv5u/kz+QP58/3D/fgCAACwAKQCl/qb+Qf02/Sv9I/2F/on+QgBUAG0BjAGNAa4BwQDkAPP/CQDC/9j/DAAjAJ4AxgBRAXoBgQGtASwBVQGrAM4Asv/D/0v+Vf5t/W39XP1a/Zb9nf34/f/9jf6Z/in/Of9M/1r/8v4K/x3/Pf+PALMA9wEsAvUBKwL4ACUB9f8TAJv/vf9xAJ4A7wElAp0C3wI5AoICgwHPAdQADwFOAH0ARABwAJEArwCuAMkAnQCpAGAAZgDx//P/Vf9J/8z+y/7e/tL+Of9D/zr/Pf+5/sD+dP52/rb+uP4V/wz/0P67/vn92v2v/ZT9n/6N/u3/5//VAOQAhwGgAcEB4wFZAXkB5gALAQcBIwEgAToB4AD6AIEAjQA4ADgACwACAJv/iv/b/s3+h/55/tv+0v45/z3/Of8+/wT/C/+//rT+bf5f/qb+k/5h/0j/pv+M/zz/Kf/v/t/+K/8b/4n/j/8dACgAIgFHAaQCygL3AzQEewS1BJEDvgN+AZMBaP9o/0j+Ov4n/hT+jf5z/hr/DP+v/53/9P/l/8D/tP+J/3n/a/9U/9L+tP6u/Yr9wfyU/JL8XvxD/R791v66/m8AYQDyAPUAwADHANcA8QBNAWMBegGbAWUBiAFQAWsBCgEjAZMAogB/AIgAGgEZAZ0BnAFWAVYB0gDSAHIAXQDA/7T/pf6I/lf9Mf10/EH81Pyo/H3+XP4yAB8ABgH4ADEBJgHMAMEAFQAJAJP/h//G/8P/mQCcAKABtgFMAmACUAJnAuEB7AFoAW8BWwFfAZQBlQE8AT0BTABKAIj/d/8d/wj/vv6h/rH+jP7L/qH+p/6E/nz+W/5+/mP+u/6a/kb/M//u/9j/HgATACoAFQBCADUAQwA+ACgAIABPAE4AqgCnAOwA6wCnAKMA7v/d/5//kv9NAEMAAwEGAekA5gDq/+P/ev5i/nL9Uf2W/XD94f7A/rgAqABIAkUClgKeAqMBnwEsACkA/v7u/sX+uP6S/4b/bgBvAOIA6gDyAPkAegB7AOz/8P8bAA8AZgBgAFgAUABsAHEAuAC+AKUArABiAGUABwAEAED/Nv/Y/s/+c/9v/7oAwQDsAfsBRAJbAoMBiwFJAFAAhf+B/yn/IP8v/yv/h/+E/+D/3P9NAFAA7ADkAAwBAgFwAF4Anv+K/87+s/4L/vH92P3F/XP+Wf5X/0v/DQAFAK8AtABoAWoBEAIhAmsCfAIdAi4CMgE7ATsAQwDl/+r/DQAYAFQAVgCJAIwAhQCIAHAAbwCEAIEAegBwAC4ALwDz/+X/iP97/+7+1f7U/sX+Vf8//6//pP8eABwA6wDuAHkBiwF4AYEBOgFJAQsBGAHqAPQAkACgAO//8v+L/5j/6//p/1sAXQBSAEwA4f/V/0H/Nf8E//P+Tf9D/4//g/8d/w7/J/4X/kn9Mv1g/Vr9Bf///gQBFgEMAiACxgHkAeEA8gAXACsAEwAjAJ8AwAABAR0BzADtACQARACS/6v/dP+D/8X/1f9bAGwAygDeAC0ANAC4/rP+B/4C/oT+eP7o/ur+Df8O/5v/rv+IAJwAKAFRAWwBjQENASoBWQB4AOr/BwDk//v/GQAtAJQArgDaAO4ATgBeALr/xf9KAFUAIgEsAf8ADAH1//j/3P7Y/h3+E/7V/cb99f3e/VL+Rv7p/uD+ef98/6X/pP+6/8b///8KACEAMwArAEQA1ADyAJwBvAG5AdwBUAFvARMBKwESAS0BRQFbATkBSwFjAGwA8f7w/gT++/0Y/gP+2v7R/t7/1f8wACUAev9s/8X+s/4J///+kf+B/5n/jv+v/6f/BQD7/wMAAAD5//n/tAC4AKoBrQGzAb0B2ADhAAIAAADI/8r/IgAnAJ8AqADZAOIApAClAAEAAABV/0n/+/7n/uP+yv6m/o3+Vv47/m/+Vf7O/rb+Gv8L/zj/K/9u/1//1P/U/3YAfQD0AP8ABQEUAeYA7wC1AMMARgBKAOL/6P8wADgA/AALAZQBtAHeAfMBwQHiAUUBVAGoALcAJAAkANT/yv+5/6//hP90//3+5f65/qP++v7a/iT/Df8o/w3/Cv/w/sj+tv6o/pn++P7y/lf/Sv99/3n/0f/M/1IAUgAAAQEBvQHNAU0CYgIpAj0CWAFvAWoAeQAAABQAGwAhAEQAVQChAKsAGwEtASYBLgGbAKQA4//f/yn/If+L/n/+Yf5R/qP+nf5d/1T/MwA0AIcAigB2AHYAZABiAA4ACQCK/4P/gP9+/9T/zv/1//f/LgA1AJAAkgDUAOEAPQFJAY8BlgEwATkBpwClAGEAYAAQAAkAoP+Q/1v/Tv8+/yf/Lf8h/27/X//g/9n/TQBGAGMAYADS/8f/Gf8L//L+3/4h/xH/P/8u/37/e/8DAPn/bAB0AK8AtwD+AA0BRwFXAWABfQE3AU0ByQDeAFkAZgBKAFkAlwCdAM8A1QDtAPMA7gDwAHUAfADw/+3/BQAFAGYAYgAtADAAf/94/xb/DP9m/13/RQBBALUArgABAPP//f7r/sD+r/5C/zb/8f/p/4AAgADCAMoAtQC7AGoAdgAeACAAHgAkAFMAVAAsACwA5v/p/+n/3v/N/8X/iv+B/6L/nv8aABkAewCCAKwAvgCBAIwA5//0/4n/lP/K/9P/UwBkAM0A2AAAARMBzADVAGoAeABKAFEAZgBxAJkApQCVAKUANgA/AKX/sv9u/3D/h/+O/8j/y/8ZABcALQAtAP////+W/47/Iv8Z/9/+0v4f/xj/dv9z/7f/uf8hACcA7gD5AGABbwE+AUoBsACyAP7/+/9a/1T/6v7e/qj+n/6//rL+X/9f/yAAHwCEAIUAewB/AFIAVAAFAAUAnf+d/1H/UP9V/1j/dv9y/5j/of8mACkAGQEpAbEBxAGkAbkBNgFMAZwApwDz/wEAd/97/yf/K/9M/0v/6//u/38AgwCUAJQAaQBsAA8ABQBQ/0z/v/6y/pz+jv6z/qX+8f7m/lr/Tv+1/6r/BQD9/zoANwALAAcAvv+3/7P/sf/l/+f/CwALAA8AEwApACMAbgBvAGcAYgDU/8r/gP9x/9n/zf8yAC0ARwBEADwANwASABQA+P/3//b/8f/C/7H/fP9s/4T/cv+D/3D/VP9G/5X/hv8vACkAjwCGAHAAbgApACgAIAAlAEwATAAuADYALgApAGcAZQB3AHYAJwAmABIAGQBxAHcAfwCJAPb/9f9E/zj/5f7O/uT+1P4q/xz/uf+u/0IARABPAEoAuv+7/zb/L/9O/0f/6f/p/5QAlQCtALIAPQBDAOv/6//3/wMAWQBlALgAzQDYAPMAwQDYAKEAsQB0AHgAMgAlAAQA9/8JAPv/JwAjAEkATQB4AIMAeQCLAFEAWAAdAC4AMAAxAG8AdQBlAGkAwv/A//X+9f7Q/s/+cP94/1cAZADgAPQA+QANAZYAoADW/9r/Qf8y/xr/Bf8b///++P7h/vb+3f5H/z//+//1/98A5gB+AY0BfwGSAfQACgE7AEcAqf+z/5b/kv/S/9P/JwAiAH0AigDHANYAwwDeAIoAmAAPAB8Adv9u/wH/+f4q/xb/of+V/+//4P/t/+b/2P/I/+3/6P8jABwAVQBdAIYAnACUALAAcwCXAGIAeABoAHcAOQA6AOD/3v/V/9f/JgA1AKwAwwD8ABgB0gDgAFYAXwDR/8T/df9o/3H/Yf99/2n/bP9h/3H/Xv9+/3j/e/91/6P/rP9AAFIAuADYAKkAxgBlAHwAKAA1ANL/0v+z/7T/CwAJAH8AiwCsAL0AnACwAI4ApgCdAK4AxQDTAOIA5QCMAIMAsf+k/wH/5/7W/sL+Kv8b/8b/xf9TAF8AewCTAHQAhABVAG0AOQA3ABMAGwDc/9P/Wf9Z//H+7/4G/wn/gf+D/18AZAA8AUUBSAFSAc8A2ACGAI8AbgBwADoAMwAAAPL/lf+E/2f/V//P/8z/ggCFAN0A6QDKANQANAA0AGD/XP/y/uT+CP/6/l//Wv/f/9j/JQAtAB0AHQAEAA4A+f/4/8j/zf+g/53/lP+Z/67/rP/E/8X/pv+c/43/hf/S/8T/GgAUABoADQAlACQAHAAXALr/wf+t/6P/GQAiAFsAUwAHAAcA0f/D/9j/1f/q/+L/1v/V/wEAAgBCAEYASwBTADAAMwBJAE8AegB+AIIAgACCAIIAWwBYAOz/4f9l/17/NP8f/1r/UP/p/97/ZgBiAHcAewBIAEwAEQAUAPz//f/y/+r/1f/J/4T/eP9h/1b/iv+F//X/9/90AHcAgwCJAAgABACd/5f/dP9s/3P/Zv+5/6//DgABAAUA+f+4/63/l/+L/8X/vP9EAEQArgCxAHoAgAAHAA0A0f/O/5z/nP+//67////9/wAA9P+//8D/1P/W/xgAHQBwAHQAtgC6AKoApwAfABwA0v/M/+j/4f8YABMARAA7AEcAQgANAAcA3//f/wMAAwBHAEoAWwBkABcAGgDp/+7/8P/w/wgACgAOAA0AHAAiACkAKgAgACQABgAIALn/uv+C/33/mP+W/7f/rv+6/7T/8f/l/ywAKAArACYAEAALACUAJQAhACUABAAJABoAHgBaAF4AhACJAIkAjwBZAGQAGwAcAPv/AwAFAAQA+f/6/9n/2f/K/8n/AwAEAF0AYACPAI4APwA6AMj/uv+g/5D/vf+t//D/5v8DAP7/JQAlAFUAWgCHAIwAcgB2ABMAFwCw/7H/qv+w//T/+P87AEEAQgBAAC0ALwAeABoALgAuAHsAgAC4AL0AZwBxALP/qf9V/0f/Yf9J/2n/T/+C/2n/1f/N/ygAJABZAGYAhQCSAHgAgwAPABoAxP/F/7P/uP+t/7H/rv+u/9H/1P/w//D/5P/m/9f/2f8dACUAoQCpAOsA+ADNAM0AMQAqAHv/Z/8s/xD/cP9Y/97/zf8yACoAcQB3AHkAfwBRAF0AUQBWAFQAWwBPAFcAPQBEAA0AGAAJABEARQBNAGAAaAAtAC4A8v/t//H/8v8MAP3/+P/1/+b/zv+0/6r/jv93/6f/mf8kAB0AegB3AEQAPgDm/+P/xv+3/6z/qf/M/7//MwA4AMEAxwDjAPgAcgCBANX/3v+e/6D/tP+u/7z/tP+U/4f/Qf83/xT/Cf89/zX/ov+c/+z/6f8HAAYA6P/n/6P/o/9f/1v/Xf9R/5//mf8OAAMAWwBhAKIApwDTAOoA4ADxALMAyACAAI4AMAA0ANv/3v/J/8X/x//J/9L/0v8PABYARwBUAEUAUQBcAGsAYQB0AOr/9v9l/2v/bP9u/8D/uf+//7f/kf+K/4L/f/+7/8H/FgAjADwASABcAGgAUwBYAPX/9/+q/6r/1//b/x0AKAAqADMAAwATAMb/zv+R/53/1v/b/08AXwCdAKoAjgCeAFgAZQDx//f/hf+H/23/Yv+c/5j/vP+0/6v/qf+//8H/DwAWAGYAbACDAIwAPABBAJj/of9c/1//2v/p/48AmQC2AMYAYABrAA0AGgARAB8ASQBXAGMAcAA8AEgA8f/4/7P/sv+q/6b/nf+T/5D/f//O/8b/KgAkAPn///+p/7H/CAAUAGsAegBkAHEANQA8AP7/AQDr/+3/MAAuAC0AOgDH/8f/jf+Y/+7/+f9sAHQAmwClAG8AawD4//D/lv+K/5P/gP/C/7X/AQD1/wMAAwDS/9X/sP+7/wcADgCjAK8AFAEXAb0AwQDT/8//Lf8v/zD/Lv/P/9f/xgDOAA4BGgFdAGEAw/+8/8T/v//a/8z/q/+d/3n/Yf9a/03/XP9M/3v/dP/t//D/3wDhAHwBlAEpAS4BQABLAJf/lP8f/yD/PP8w/xIAFgDlAOMA1ADdAFcAWAAnACoAVgBWAHsAeQBNAEQAzf+//0v/N/9L/zb/1f/F/0sAPwBIAEIASgBIAF0AYwAjACsAk/+R/2L/W//J/8H/IwAcAPH/7f/M/8b/NgA4AH8AgwAMAAkAt/+u/8T/t//c/8r/8//i//f/6v/Q/8T//v/0/20AYgA7ADgAtP+j/5n/l//B/7n/+v/6/2UAZQBnAGcA6//q/83/yf9AAEYApQClALwAxACaAJoA/f8CAHb/av+e/5b/BwD5/wIA8//s/93/CAABAO7/7P/A/77/MgAzAMwA0ACfAKAA5P/f/2b/Yv+J/4H/FwAZALAAtQCzAMEAOABIAMf/1v/F/83/8f/5/w4ABADl/+H/pP+S/2n/Y/+W/47/+/8AACYAKgAlACsATwBUACYAKQCz/6//xf/A/2gAaQCEAIoAIQAnABoAIwBVAGcARQBQAEQAUwC2AMAA1ADlACMAKwB4/3P/kv+M/+H/1P+H/3b/Av/3/jv/Nv8uADwAHgExATMBRAFTAFYAPv85/7P+lv4D//n+/P/v/4YAlwCdAK4AwwDgAL4A1AD//wcAsv+p/0MAPwBKAE0AZv9d/yv/K//f/9f/OAA0ABAABAAbABkAMwA1ACsANgBfAGgAXwBnAKD/mv/q/tf+Zv9S/w0ACwDM/83/l/+k/0QAWwDVAOkAhACTAAMA9/+8/7b/hf9q/1H/Qv9O/zj/kf+J/xAADgB2AH4AkACdAIYAkQBnAGgANgAtAMj/uv/6/uf+lP6K/nv/ev+UAKgAjgCfAAwAFAA/AEcAsQCyAJIAlgBXAFYADgARACH/I/8w/hv+k/6E/iEACQBGAUYBjQGWAfEADwH7/xUAaP91/1v/UP9J/yv/Rf8k/0j/O/95/4T/DgEtAV0DlQPsAhMDlP+U/1D9M/2u/ZH9rv6a/pb/kf+wAL0AggGYAaoBtgHBAMAAL/8f/7H+pf6b/6b/SQBZADgASQBZAFkADwAFAG3/Vf+o/5r/nQCrAPgAFgHBAOcAaQCGAKD/qP/T/r3+6f7E/uP/zf/+APwAhgGaAQIBIAGz/77/r/6u/r3+pf6d/4n/WwBMAHsAfwCPAJgA6AAAAd8A6wD6/wEASf8//5T/kv80AEAAcgB5AGMAcgCAAH0AkACOACwAHQBe/1P/LP8p/9z/6/+hALQAjACbANn/0v8P//j+vv6b/gP/5f6s/6D/SQBXALkA0gDeAP0AwADSAC4ALwB3/2r/RP8s/6//qP8iACQAXwBwAL4A0gDgAPgAlQCiAFEAVACNAJEAkwCRAP3/+f96/3D/d/9u/67/pP8MAAMAfwCCAKYArQBSAGEA2P/i/3f/fP9B/zb/ZP9a/6n/mP/S/9L/IAAnAI4AogD2AA4BCAEdAZAAnACt/7H/YP9X/9P/zP/8//X/lP+D/4T/fP/X/8v/7//v//z/9//0//n/u/+4/6T/n//H/7//2v/K//L/6v8bABIABQATAAUADgBbAHcAoACuAJkAqABzAHIADgAPAK7/pv/P/9D/RwBIAJMAlwBvAHIACQD//73/uP/y/+X/BAD+/+n/5f8NAAcAJwArAML/vP9Y/1T/cP9x//r//v+aAKcAxADUAEMAUACj/6n/iP+K/7//wP8VABYAWwBgAGUAagA8AEMAzv/O/2D/V/+Y/4n/8P/h/5f/iP9g/1T//P/+/4sAkgBrAHIASwBRADMAMwDG/8n/kv+Q/7//x/8fACoAXgBpAEQAUwD4//n/4f/r/yEAIABDAE0AYQBkAFIAWgAdABoA/v/4/xYACgAQAAMADgAGACIAIwA7AEIAOwBEAP3///+i/5z/jf+C/6v/n/+L/4T/oP+e/ygAMgB6AIcAJgArAMr/y/+b/4//f/90/43/gv/G/7r/DQARAEUAQQBFAEsA///5/6n/oP+U/5H/7P/k/zoAOwBEAEEADgAIAMT/vf+b/5T/w/+5/+z/7f/s/+v/CQAMAGAAaQBUAFUA5P/j/7b/sP/e/9f//f///x0AGQAVACAAJQApAGYAcQCOAJgAZQBoAD4AQwA4ADcAAQAFAKv/pv9t/2r/m/+V//n/9/87ADsARABLAEEARwAyADkABgALAMn/yP+H/4P/kf+P/wIA/v9ZAGYAYQBlAEoAXABQAFsALgA6AAAACQDo/+j/5v/q/wMABAAYABgAGQAbABgAFAATABYAAQD9//j//P/8//7/BAAKACsAMABoAG8AagBtABIAEgCz/7D/qP+k/8L/yP/p/+7/FgAgAHQAhQCvALUAkQCeAEMAPwDk/+D/p/+e/6H/m//L/8X/FQATAEgASAA8ADkAJwAkAA8ABQDs/+r/2P/R/8b/xv/C/8L/2P/Y/9z/3//m/+P/CwAMAEMARQAyADcAFQAbABkAJADu//f/yf/P/+n/6f8HAAUAAQD6/xYAEQASABAA8P/w//b/9f8LAAwA7P/l/9H/0P/j/9j/3v/g//7/9P8hACYAIAAiABEAEgAQABQACgAHAOf/6v/U/9b//P///y0AOgArAC4AIAAsADAAMQD//wYAsv+v/6j/pf/H/8n/3v/b/9P/1f/c/9r/+f/5/x8AHQAWABMA8P/t/wYAAQAQAA0A0//Q/4j/hP+M/4b/0//W/zkANgBoAHAAcwB3AHAAeQBsAHQADgATAKz/r/+a/5z/2v/d/w4AEAA8AEIAXgBjAGMAZwBIAE0ALQAqAOf/5/+r/6X/nf+V/7X/r//C/7n/xP+8/9v/0v8PAAkAJgAmAA4ACwD5//n/6//u/+L/3f/a/+D/5f/i//n/AQAxADEAgACNAJsApABtAHoAQwBLADAANgAtADEAEgARAO3/7v/w/+n/EwAUADQALQAMAAkA1v/M/7v/t//G/7z/4//g//H/6f/Y/9H/3P/X/+T/4//i/+H/7f/u/y4AOABZAGEAMQA+ACIALAASABsA8P/4//r///8zADgAQgBLABsAGwDp/+3/6f/o//P/8P/e/9b/3v/V/9n/0f/F/7j/uv+1/9j/yv/Z/9j/6P/e/+7/7v/4//b/5v/q/yQAKABcAGUASQBSADYAOwAwAD0AHwAnACEAKwBHAFIAbQB3AGgAbgA/AEUA///+/8//zP/Q/8n/4P/b/+n/4v/y/+z/6f/i/+T/2//y/+z//f/2/9//2f/k/97/+//5//H/9P8BAAEAHgAnAC8ANQAjAC4AIwApAB0AKAARABcAAAAHAPz/AgASABcAHwAjAAEAAgDc/93/7P/m//v/+v/1/+//6P/i/+H/3f/j/9j/1//S/9f/zf/Z/9T/+v/3/y8ALwBDAEcANgA6ABoAIAAQABIACwAVACcAKAA9AEoAQwBLAEUATABPAFsAMwA0APH/+//Z/9H/9P/5/wcAAADY/9b/z//H/+v/5v/e/9b/xf+7/8P/vP/N/8b/6//n/xEADQAXABcA+//5//H/8v8HAAcAFwAeADIANgBHAFIAVgBeAEoAVgAzADYAEQAaAAUABgAVABcAIQAkABgAGADq/+n/zf/I/9n/1P/o/+D/7P/o/xIABwAoACYADAAEANH/yv/a/9b/9//0/9v/1//z//b/MwA1AE0AVQA6AEAALQAwABEAGQDy//f/3v/g/+H/6v8EAAQAIwAqADUANwA1ADcAJQAkABAAEAD7//P/4f/e/9j/0//O/8X/3f/a//f/7f/0//L/+f/x/w0ADwAsACYAGwAkABQADQD9/wgA+//8/wAABgAdACMAPwBIAEIASQBFAFIARwBNACEAKwALABAABwALAAQACQD4//T/6v/p/wQAAAD6//j/4f/c/+n/4P/Z/9f/rf+h/4X/gv+x/6f/4//i//b/8v/n/+n////+/xcAIAAeACIAIgArAC8APAAoAC8AIQAwAC0AMQBDAE8AQgBJAC0AMgAdACMAKgAsABMAFADy/+//5//k//T/8P8EAPr/7//q/+z/4f/0/+//GwAXACAAGQACAAIAAQAAABAAEwAtAC8ANwA+AC8ANQAiACoAKgAwADIAQQAqAC4AHAAuAEEAPgAtAD0ADAAJAOj/6v/d/9n/1v/U/9P/z//O/8n/4f/a/+n/5//V/8v/0P/O//f/7//3//f/1v/Q/9j/1f/r/+z/AgACABQAGQBIAE0AdQB+AGMAZwAdACkAEQAPAAcAFAAOAAsACAARAB8AHgApADIAMwAvAC8ANgAUABEA4v/i//T/7/8NAA0A+P/v/+T/5f8BAPn/EAARAAkAAwDx//H/+P/1/w0ADwANAA8A1P/Q/7//wv/a/9X/2//h/9v/1f/0//z/GwAdABoAIgAIAAgABgALAOn/5v/O/9L/3v/W/+P/6P/p/+T/CQAKACIAIgAVABAA6//u/+f/2/8LAA4AHgAWAO//7f/f/9r/BgAFABMADgD9//7/EAALAC4AMAApACsA+v/7//v//P8PABEAAgACAO//7//k/+j/AAD+/yEAJAAxADMAEAASAO//7//2//T/7f/p/9//3f/w/+v/AwADAP7/+f8CAAAA9P/z/9L/zv/A/7z/2P/V//P/8P/m/+X/DAAJADkAPQA4ADgAEAAQAPr//f/v/+///v///xsAIAAhAB8ACAAMABoAGwAMAAsA1P/Y/9P/zf/7/wAAAwABAPf/9////wAAEgAPAPv/+//l/97/yv/M/8j/wv/l/+n/BAAAAAkADQARABIAIQAfABcAHQAJAAUA/P8AAP//AQAFAAYAIAAlADYAPABAAEEAOwBBADIAMAAUABgAAQD9//H/9P/t/+n/5//n//j/9P8RABAAEwAVAAoABwAKAAsAFAARAPP/9v/N/8j/0//W/woACQAFAAkA/P/9/ysAMgAyADYAEgAXACkALAAuADUADAANAPT/9P8HAAoAAwACAN//3f/7//n/FAAUAPz//P/+//n/9v/3/+T/3f/U/9L/6//m//T/8//u/+v/DQASAC8ALgAsADQANwA3ADAANwAYABsAEQAXAB0AHwARABkACQAHABQAGAAWABsACQAFAB0AIAAiACAAAAD///f/8//5//n/6P/i/9z/2f/8//j/EAAPAPL/7//5//f/GAAZABAAEgAJAAkAAgAFAPf/+//x//H//v8DAA8ADgALABIAAwACAPD/9//5//n//f/+/+b/6f/b/9b/7f/w//n/9v/x//H/8f/u/+7/7f/s/+j/7f/t//D/7P/z//L/GQAYAB8AHgAMAA4AFgATAEAARQA0ADQA+v/7/wkADAAiACMA/P8BAA4ADgAbACEABQAGAPD/8P8EAAkACgALAPP/9v8DAAMAFQAXAPj/+f/o/+P/9f/4//3/9//2//X/+v/5//7/+P/2//j/8P/p/+b/6f/8//P/EQAYAA4ACADy//b/9//2/woACwAlACoAOQA7AD8ARAAhACYACAAIAAsAEwAYABQABQAKAAsACAAYABkAFgAaACgAJQAhACUACwAIANr/2f/S/83/z//N/9v/1v/s/+v/DgAKAA0ADwATABEAFAAVAAMABwANAAkAAwAMAA0ACQD0//3/BQABAA4AEwAWABkACAAIAAAABAAMAA4AHQAgAA0ADwAAAP3/+f/9/wUA/f/////////9//j/9P/9/wEAHgAcACYAJwAJAAoA+f/3/+z/6//W/9X/3P/a/woADQAYABoA+v/7//7/AgAMAA8AFwAXABkAHwAQAA4A9//7//b/9P/4//3/8P/r/+z/8P8MAAoAEwAUAA0ADQALAAsA+f/3/9f/1f/C/7//1f/S/+P/3//w//T/BQD///7/BwAFAAIACQAMAAEAAwDp/+f/4//k//D/8f/3//X/DgARACoAKwAjACQAIwAjACgAKQAdABwA+//7/+7/6v/y/+7/8P/s/+T/4v/u/+j/EgAWAB0AGgAHAAcAAAD+/wUABAAAAAIA5f/j//b/+P8XABcAEAATACEAIQApAC8ADwARAP3//P8NAA8ACQAGAND/z/+3/7H/1f/R//f/8/8DAP3/+f/5//j/8/8BAP//EQAMAPf/9P/i/97/6v/n/w0ADwAdABwAGgAdAC0ALwAyADYAHAAgABoAHgAyADcAMgA1AB0AHwAJAAkACAALAAQAAgDy//P/AwD//xMAFwAIAAEA6P/o/+v/4//k/+P/3v/Y/9r/1f/o/+n/9P/y/wAAAgAFAAUA//8CAPb/9v8AAAUAGQAaABcAHAAFAA0A+f/7/wsAEQAvADQAJgAoAAgADgAgAB0AEAAWAOH/3v/Y/9X/9P/5/wEA+f/0//n/AgD6/wEAAgD2//X/BwAFAPj/+f/X/9X/6P/l/+//9f/q/+n/DAAQAEkATwBcAGEANwA8ADoAPwAdACMA3f/e/+f/7P/+////8//0/wMABgAiACIAHwAkAAMABQAMAAgA+/8AAND/yP/P/87/7//t//7/+v8RABIADgAMAAcACQAKAAcAGQAcABUAFQD3//n/8P/y/wQABgAQABAAAQAHAP7/+v8GAA8AKwAqACoAMQAfACAAKQAuAC8AMgAHAAYA6v/r//L/7//2//j/CgAHACMAIwAeAB8ACgAJAPz//P8IAAUABgAHAPv/+P/2//T/BAAEABoAGQAEAAYA+P/2/woACwAjACUABQAGAOj/6/8gAB4ANgBAAB0AFwD4////4f/e/9r/2//9//3/KQArACIAJQATABMAHgAgAAUABADr/+n/8//y////+//v//D/8//v//f//f////j/+f/8//3/+v/5//j/8P/y//b/8//0//j/AQADAA4ADAAGAAkA+v/7//D/7//5//3/DAALAAgADADt/+z/6f/q/+//7P/T/9X/0P/M/wYABwA2ADQAHwAiAO//6f/u//L/AgD6/+b/6P/x/+r/CgANAA0ACgAIAAoAEAAOAP3//v/0//H/BAADAAkACQD7//7/FwASACQALAAEAP//8v/2/wMAAAAKAAwAFQASAAwAEAAHAAIAAgAFAAgABADU/9L/z//M/wEA///5//j/7//q//f/+P/+//3/4P/e/9z/2f/1//H/5f/n/+P/3f8BAAMABwAHAPj/+P8GAAkADgAPAAoACQD6//v/AwACAAMAAwAMAAwACAAEAPr//P/s/+j/7v/v/wEA+v/8//7/BAD+/xIAFgAnACMABwAHAN//3f/j/9//5v/s/wEA+f8iACoANAAzACwAMQAoACkAFgAaAPL/8//e/9z/7//0/wAA/P8HAAsAEgARABoAGQAZABoACgAGANj/1v/H/8L/2f/Z//T/7//t/+3//v/6/w0ADAD7//7//v/5//n///////z/8P/1/+T/5P8KAA8ANQA4ABkAHAD9//7/EAASABIAFQD6//n/+f/8/wMAAgAOABAAIAAdACMAIgAGAAUACQAFABYAGAD5//X/5f/k//b/9P8HAAgAHwAeACIAJAAXABgADgAPACMAKAApAC4AEwAYAAgADQARABUAFwAXAAQACQD3//X/+/8AABsAHQAGAAkA8P/x//j/9//q/+v/3v/c//b/9P/8//v/6f/m/+r/5//t/+//6v/m/+b/6v8EAAMABwAJAAkADgAHAAUABAAIABcAFwAjACYAHgAjAB4AHwAjACgAGgAdAB4AJAA/AEEAHQAhAOP/4//V/9H/2f/b/+n/5P8BAAIAGgAbABYAGQATABAACAAOAAkAAgDq//H/9//w/wQACAAaABkAEQASABIAEQAgACIALAAvACkALgAZABsADwAPAAIABAAaABwAGAAYAAIABAD1//X//v/+//f//P/t/+r//P/9/xEAEgD8////AQABAAUABgD+//v/+//+/xMAEAARABYADwAQABIAEAANABAABgADAAQABAADAAUADQAKADEANAAzADQAFQAVAPb/9P/+//z/AQACAPv/+/8DAAMAAAAAAP7/AAASABUABgAHAPz/AAAPAAsAEAAZAPD/6f/K/8//9v/v//v//P8CAAMALQAuABwAHgD1//X////9/wgACQD4//P/5f/m/wIA/P8UABgAAgD+/wIAAQALAAoADAAPABMAEwADAAgA+v/1//P/9f/z/+//4//l/+D/4P/4//f/AgAGAAcABgD9/wEA5v/p/+v/5//6/wEADAAGAPn//P////v/FwAYABMAEgD4//f/BwAHAAwADgACAAEACQAJABkAFwAWABYABgAFAAIAAAD7//z/+P/1/w0ADQAZABsABQAGAPz/+//5//r/AAD///L/8P/3//n/BwAFAAsADQD9//v/7P/v//b/8f/9/wEACwAIABgAGgAdAB4AFgAXAAYABAD+/wIA9v/x//L/9f/v/+7//f/6/wUABwAGAAUA//8CAO//7P/o/+n/7f/r//H/8P/p/+r/8f/v/wgACAAHAAkA+v/2//z//P8LAA4AGAAXAAcACgD9//r//P/7/w8AEQAMAAsADQAIAAkADgASAA4A9//9//n/9/8DAAMAFQAYABoAGgAPAA8AEgASABkAGgD+////8f/w//T/8/8NAA8AEgASABEAFAAOAAwABgAHAPv/+v/w/+7/+//5/wgACgAQAA4ADwASAAwACwADAAMA9f/1/+b/6P/g/9z/3f/f/+3/6//8//3/8//0//D/8P8KAAwAEwAVAAIAAwDt/+3/+f/5/wEAAQD1//X//f/8/w4ADwACAAIABwAJABkAGAAVABYADgANABUAFQAaABwABAAAAPz/+v8XABgABAACAOz/7v8RAA4AKgAuABwAHQD7//r/6v/o/+v/6f8AAAEAHAAfAAUAAgDv/+//FwAaACIAIgD9////8P/t//r/+/8HAAkABAADAAAA/f/w//D/BQAEABgAHAD0//H/2f/c//b/7//8/wIADAAIABQAGAAUABMA5//o/93/2v8CAAYA9v/y//D/9P8SAA8AEwAYAAMAAgD5//v/BQAAAAgADQAUAA4ADgAWABsAFQAkACoAJQAiACAAIgAlACQAEwAUAAEAAQAGAAgAJAAlABkAHAAQABAAHAAiAAgAAwD2////AwD///7/AwDy//D//f/+/xMAFwAJAAgA8P/z//n/+P8EAAUA//8CAAAA/P/6//3/BAABABEAFAAUABIA+P/7//T/8P8SABYAHQAcAB4AIAAsACwAFwAYAP3//v8MAA4AFwAXAAYACAD///7/DAASABgAFgAEAAoACQAEAAkADwAKAAkA/f8AAAEA/f8HAAkAFQAUAAwACwAEAAcAEQALAB8AJgAbABUADgATAA4ABgAFAAsACgADAA0AEQAUABMADwANAPX/9f/n/+f//////wEABAD6//n/AwAEAAYACADw/+7/5v/p//L/8P/6//z//f/8/wEAAAD+/wIACgAIAAoADAD//wAA/v/7/wAABAAGAAEAAgADABUAEgAaABwADwAOAPX/9v////v/CwARAA8ADADy//X/4//d//b/+f8MAAoA9P/4/9v/1f/w//X/EwARAAoADwD9//z/AQD+/wcACgAJAAoACAAFAPj/+f8AAPz/BwALAAkACAAFAAYAFwAUABUAGQADAP//8//1/wEA/v8FAAUA9//3/+v/6P/6//3/FAASABEAEQAXABcAFgAXABAAEgAPAA0A/f/+//j/9P8IAAwAHgAcAAoACwAJAAkAFQAVAP7//v/p/+v//v/7/wQABwAEAAIAAwADAP7//f/2//b/9P/y//n//P/y/+//4f/j//D/7v/+//////8AAPT/8//x//H/8P/x//j/9v/9////7//t/+n/6P8WABgAIQAgAAAAAgADAAIAEQATAAAA///j/+P/+//4/wwADgDt/+z/+//5/xwAIAAHAAQA//8CABAADgAMAA4ACgALABIAEgAaABsAFQAUAAMAAwAAAAEABwAFAA8AEgAEAAMACgAMABAADgD//wMA8f/s//r///8JAAEA8v/4/wAA/P8NAA4ABwAJABEAEgALAA0A/P////n/9//7//7//f/9//z//f8FAAQA+f/7/wYABgAKAAsA9f/0//f/+f8IAAgABgAHAP7//f8HAAcAEwASAPj/+f/7//v/DwALAAgADAAJAAUAHQAgACAAIQAZABoADAAMABMAFAAXABcA/f/9//D/8f8EAAIABAAIAPb/9P/0//b/+v/6//j/+f/9//7/AwAFAPr/+P/q/+n/9//2/wYABgD5//j/+P/5/wQAAwATABYAFQATAAcACAD+//v///8BAPr/9//j/+X/5//f//D/9P8DAP//CwAOAA4ADgALAAwA/f////H/8P/u/+7/+//7//v/9//+/wEAEgAQABgAGwANAA8ADAAJAAcADAAOAAwACgANABQAEAAYABsAJAAgAA4AEQAJAAYAAgAAAAMABgARAA8AFgAbAA8ADgD3//f/AgAEABsAFwABAAYA///7/wsAEgAOAAoABAAIAAcABwAJAAoABgAJAA4ADQAGAAoAAwAAAPz/AQD+//n/+/8BAA8ACwAPABQAEQAPABQAFQAeAB8ADAAMAPz//f8KAAsA+f/6/+//7//4//j/AQAEAAAA/f/2//r//P/4//z/AgD6//T/9P/4/wYABAANABAAFAASAA4AEAARABEABwAHAPz//P/6//j/AQABAA8AEAAfACEAHAAdABsAGQAYABwAEgAQAAQABAD8//v/AQAAABAAEQAZABsA/f/7//n/+/8NAAwABgAJAOf/5//s/+n/9P/1/wEA//8FAAYADAALAAIAAQD7//r/BwAKAAMA///y//X//f/5/wIABAAAAPz/8f/0//b/7//w//X////6//f/+v/+//3/DgAPAAUACAD8//j/9f/6//7/+f/9/wEA+v/4/wAAAAD7//z/CgAKABQAFQAQABEADQAOAAkACAASABAAEAASABMADwAHAAsAFQATACAAIQAQAA0AAQAEABYAEQARABcABAD//wMABQAFAAMAAgACAP3//v8BAAAA8P/z//L/7/8CAAUABgAGAPv/+v/1//j/9P/w//L/+P/5//T/+/8AAP3/+P///wQABgAEAPn//P/0//L/AAABAAIAAQABAAIAAQAAAAoACwAEAAMA9//4//v/+P8FAAoAAAD6//n//f8OAAwABQAFAPj/+f////3/DwARAAoACgD///7/AgADABUAFgAPABAADwANAAsADQAGAAYADgANAAgACgAGAAMAAQACABAAEQAJAAgAAgAEAA8ADQAWABgADAAMAP3////5//f/7P/t//L/8P/+//3//v8BAAQAAgD5//n/8v/0//7/9//7/wEA/P/3//r//P8JAAcADQANAAAA/v/+//7/+//7/wUABQADAAQABgAFAAMABQANAAwADQAPAAkACQAJAAcACgAPAAUAAgAKAA4ABgAEAAMABwASABUAEgARAPX/9//v/+z/AQAFAAcABwD+//7/CAAHABwAHAALAA4ADwAOABIAEwD5//f//v/9////AQADAAEA/f/7/wsADAAVABQA+f/8//b/9P8CAAMABgAIAAgABwACAAMAAQACAA4ADAALABIACQAGAPb/+f8BAAEAEAARABUAGQATABIACQANAA0ACwALAAsA/f/+//f/8f8CAAkAHAAXABQAGgAPAAsACQANAAgAAwAJAA8AEgAMAAsAEAANAAoABwAIABIAEgAVABcADQAMAAoACgAWABgAFQAWAAsACwAUABYAIgAfABIAGQAHAAQACAAMAAkACQD///3/GgAeAB0AHwAHAAYACAAOABgAFAAJAAwA8f/y/////P8LAA8ABwAHAAEA//8KAA8AEQAKAAMACgAFAAIA/f////r/+f/5//r/9//0/+7/7//7//f/DAASABEADgD6//z//P/7/wMABwAAAAAA/P/+/wAAAAAJAAgACQAMAA0ADAD6//n/8//0/xcAGQAZABkA/v8BAP7/+v8RABUAEAAOAPf/+P/9//b/+v/+//T/8P/+/wEABgABAPf/+P8HAAQAIAAgAA8AEAD///r/AQAEABIADQD2//j//P/4/wUACAAHAAYACwANABEAEAD6//r/7//u//n/+v8BAAAA7P/r//H/8f8LAAoA+f/5/+7/7//7//f/+//9//r/9//9////BAACAAIAAwD8//j/BwAJAAEA/v/4//f/+f/3/wQAAQAFAAgACwAJAP7////4//b/+v/5//3/AAD4//f/+f/2/wgADAALAAcA9//8//j/9f/6//7/BgADAAAABwAIAAUAAQAFAP/////3//T/+v///wMA/v/5//z//f/4/wYACwAVABEACgAOAP///P/1//X/+v/6//z//P/8//v/8f/w//T/8f8CAAQABgAHAAEA///3//v/AAD9/wQABgAQABEABQADAPb/+f8FAAEAEgAYABYAEwD//wQAAAD8/wQACAAUABQAEwATAAAAAAD3//X/AgADAAUABgD8//r///8BAAoABwAOABIACgAIAAIAAQAGAAYAAgAAAAMABwD9//n//f8AAAIAAQAPABAADgAOAAEABAD6//n/+f/8//v/+P/6//7/DAAJAAAABQD5//T/9//5/wcACQAHAAYA+f/8//b/8v8CAAMABQAJAAIAAQD5//n/AgAEAAIAAAABAAIA+v/6//////8BAAEA/f/9//f/9//4//f/BAAFAAoACgAAAAEAAAD/////AAD///3/AQAFAP7/+/8AAAIAAAD//woACgAEAAYABAADAAkACgD9//3/+P/4//X/8//8//7/AAD//wkACQAJAAoA8v/w/+//7//8//7/AAD9//7///8GAAkADQAIAAYADAAHAAQACwAMAP3//f/5//j/AAAAAAgACgASABEAFAAWAA0ACgAHAAsACgAIAAMABgD7//j/AwAGABwAGwAFAAcA+//4/wkACwAGAAUAAQACAAMAAwAEAAMADgAOAAkACwAIAAYAEgAVABUAEgD2//r////8/w8AEwAGAAUA/f/8//r//P8OAAwADgASAPv/+P/5//b/AwAHAAoABgAAAAUA+v/0//b//P////j//P8EAP7/+v/+//7/AQACAAMAAAADAAYABAADAP/////6//r/AgAAAP7/AgAEAP7//f8CAAkABgABAAMACQAHAPf/+v////r//P8AAAUAAAD7//7/+P/3//j/+P/1//X/+//5/+3/7v/5//f/EgAWAAwACgD5//r/9//2/wIAAwADAAQA/v/9//7/AQANAAoADAAOAAQABAANAAoAAwAJAPr/9P/6/wEAAgD///z//f/7//r/AwADAA0ADwALAAoA/v////3//P/4//f//P/9/wcABwAHAAcAAAABAAAA/v8CAAQAEAAOAAkADAAEAAIABAAGAAMAAgD7//n/+v/9/wUAAQAAAAIA9//3//j/9P8BAAQA/f/6//z//f8FAAUABQACAPn/+/8GAAMAAgADAAQAAwADAAEACAAKAAAA/v/0//X/BgAEAAoACgACAAQABwADAAcACwAHAAMABQAIAAkABgADAAMA9v/3//3//P8GAAUA/v////f/8v/8/wEA+v/3//7///8EAAQAEAAOAAMABgDx/+7//f////7//f/r/+3/9v/z//3/AAD///3/BQAGAAcACQAGAAIA9f/3//X/9f8BAAAA8//3//z/9/8BAAYABwAFAAUABgD8///////5//r/AQAGAP//+P8AAP7/+P8FAAoABgAFAAYABgD//wIAAAD7/wIACAAJAAUABwAIAP3///8CAP7/EQAVAA0ADAD///v///8EAA8ACwADAAYAAQD+/wEAAgAZABYADwATAAwACQAXABkADgANAPD/8P8EAAIAAgAFAP3/+v/7//3/BwADAAMABgD4//T/+//+//z/+P/v//H/8f/u//T/9f/5//j/CAAGAAsADQANAAsABQAEAAwADgAGAAMA9P/3/woABwAPABIACgAIAAsADAAMAA4AEAAOAAUABwAFAAUAAgADAAQAAwD+/wIADAALAAgACQD//wAA/////wAAAAAEAAcAAQD//wgACQADAAMABgAGAA0ADQAVABgAEgAPAAQABQANAA0ACwANAA4ADAACAAUABQACAAgADAD///7/AwADAAwADAAFAAUA/P/+//3//f/+/wAAAgAAAAQABAAHAAoABQADAP3/AQAIAAcABQAGAP7/AQAEAAIABQAHAAwACQALAA8AFAANAAcADgAGAAEAAwAHAAsACAD//wEAAAD//wIABQAMAAsACAAIAAQAAgD6//3/BQACAAIABwD+//r//P/9/wYABwABAP//BgAJABEAEAAQAA8ABQAHAAkABwAPABMADwANAAsADQAIAAgAFQAVABIAEgAbABsAEQAQABEAEQANAA0ACAAJAP3/+f/9/wAA/P/8/wIA//8LABEAEQALAAgACgACAAQABgACAAMACAAJAAUABAAHAP///f/6//n/9f/3/wIAAAAJAAsABAACAPz////9//n/AQAEAPj/9v/s/+z/9v/3/wcABwD4//f/8//z//n/+f/6//n//v/+/wAAAAAAAP//BQAHAAYABAAEAAUACgAKAAMAAwD6//r/DAAMAA8AEAAHAAYAAAD//wEAAAAKAAwA//////v/+v/9////CwAIAAkADAAKAAgAAwAGAAMAAQD//wIAAgABAPv/+//2//b////+/wgACwD8//n/+//8//7//f/8//z/9f/2//7//P/4//r/8v/w/+z/7v8KAAUA+v////X/8f8DAAMA/v////z/+v/9////BgADAP//AQD///3/AwADAAUABQD7//n/AAACAAIAAAD8//3/+//7/wAA//8DAAUACgAHAAcACwAPAAoABAAIAAUA//8IAAwAAwACAP3/+//2//b/AQABAAAAAQAIAAkACwAKAAMABAAEAAIABQAHAAYABAD3//n/+v/5//n/+/8CAAEA+P/5//f/+P/8//n/BgAKAAMAAQAAAAIACgALAAsACQAAAAMABgADAAQACAAKAAcAAAAEAAIA///9//////8AAAgABgAEAAcACgAIAAsADQAQAA8ABgAIAAQAAwABAAIABAAEAAAA/f/8/wEAEwANAAYADgD+//f//v8DAAIAAAD//////P/8/wQAAwAMAA0A+//6//j/+v8AAP3//f///wAA/v8DAAMACQAKAAoACQAFAAYAAAAAAAEA//8FAAYABQAFAAEAAQAOAA8ADwAMAP7/AAD7//v/AgADAAQAAwD7//3/AQD8/xQAGwALAAQA9//8/wAA/f8BAAIA9//3//7//v8KAAoABwAIAAgABQD//wUABgACAP7/AwABAP//AwAFAAcABgAIAAgABQAGAAIAAAD+/wIA+f/2//v//v8BAAAAAgABAAMABQAUABEACAAMAP//+//8//7/AgADAP///P/6////AgD9/wcADAAQAAwABAAFAP////8GAAQACAALAA0ACgD//wIAAQD//wQAAgAFAAgACwAJAAsADQALAAkAAAAAAAcABgALAAwACQAIAP7//v/z//P/+P/3/wcABwD9//7/9//1/wAAAgADAAMA9//1//j/+v/7//r/AgADAP7//v8CAAMACAAIAAIAAQDw//D//v////7//P/7//3////8/wQABgADAAQACAAIAAMABQABAP7/CAALABMAEQABAAUAAQD+/wEABQALAAkACwANAA4ADgAMAAwACAAGABYAGAATABEAAgACAAkADQAHAAQAAgAEAAsADAANAA0ACwAMAP//AAAHAAYABAAGAPz/+v/9//3/+v/7//n/+f8AAAEA9v/2//b/9f/8//3/EAAPAAoADAD9//n//f8CAAAA/P/y//X/9//2//n/+P/5//n///8AAAkABQAFAAgABQACAPT/9v8GAAUA/P/9//b/9f/+/wAACwAKAAcACgAAAPv/AAAEAAkABwAIAAkABgAGAAgABwAEAAMACwAMABIAEQAKAAwABgADAAYACgALAAgABQAHAP///f8MAA0ADQAPAP3//P8EAAQA/v/9//7//v///wEA/P/7//r/+//y//L/CAAIAP//AADx//H/AAABAAYABgD7//7/9f/y//3/AQAAAP7/BQAFAP7//v8DAAUA/f/5//z/AQD4//X/+v/9/wEAAAAEAAQA/f/+//v/+/8EAAMACQAMAAYAAwD0//b/+f/6//7/+//5//z/+v/3//r//v8CAP3/BQAKAAIA/v/5//v/AgAAAAcACQAFAAEAAAAEAAYAAwD8//z//////wIAAAAEAAQA/f/+/wQAAQAIAAoABgADAP//AgAGAAYACQAIAAMABQACAAAABgAHAAYABgACAAEA+v/9/wgABgD//wIABQACAA0ADQAKAAwA/P/4////BQAHAAEA/v8GAPz/9f/6///////8/wQAAgADAAgABgABAPv//f8BAAIABwADAAUACwAJAAUACwAOAAwACwACAAMA9P/1/wkACAATABQAAgABAPz//f/9//3//v/8//3///8FAAMAEwAWAAwACAD6//7/DAAHAAYACwAKAAgA//8AAAEAAQAEAAMAFQAWABYAFQD8//7//P/5/xEAFAABAAAA+P/1/wAABQAHAAQA+//8//r/+//9//z/AQAEAPL/7//0//b/CgAJAAEAAAD6//7/CAAFAAIABAD4//r//f/4//n/AAD+//n/+f/8/wkACQAEAAQA/f/+/wQABgAHAAMA+/8AAPv/+P8AAAIACwAKAA0ADwAFAAMABQAIAAoABwAHAAgACAAIAAsACgAJAAwACQAIAA0ADgAPABEADAAJAAoADgAMAAgADQAQABAADQAFAAcABQADAAUABwAEAAIA/P/8//v/+//+//3//v////z/+/8IAAcAAAD//wAA//8IAAgAAQD+/wMABQD9//n/AQACAAQAAAADAAcACQAEAAMABgAOAAwACQAHAAAAAgAGAAMA//8BAAIAAQD6//r//v8AAAcAAwADAAcAAQD8//r//v8CAAEABgAFAAEAAwAFAAMABwAJAAoACgAIAAYABAAGAAMAAgAAAAAABAAHAAYAAwAFAAcAAAD+/wEAAwD9//3/+f/6//f/9f/6//3//f/7//v//P8AAAEAAAAAAPf/9v/4//z/+v/1//j//v/2//P/9//4///////3//f/9P/0//3//v8DAAMAAQAAAPr//P/+//3/BQAEAP3/AADw/+3/8f/0//3/+v8AAAIA/P/7//3//f/2//b/AwACAP3//v8BAAAA+v/5/wAAAgD5//f/AAADAAEA/v/x//L/+f/4//z///8IAAIA+////wcABQAEAAQAAQACAPb/9P/+//7/AwAEAAcABQACAAQAAwACAAkACAAHAAcAAwADAP3//f8CAAEA/////wQABAAFAAMABAAGAAMA//8CAAUA///8//z//P8DAAIAAgAAAAUACQAGAAMABAAGAAcABQAIAAoACAAGAAIABQAIAAUAAgADAAsACwAJAAgABAAEAPz//f8IAAUA/v8BAAIA/v8DAAgABwACAAQACAAFAAMA///+/wMABgAKAAcA//8DAAcAAwADAAUAAwAEAAIA/v8EAAoACAABAAEABgAIAAUAAQAGAAMA//8CAAUAAwACAP3//v8JAAoABAAFAP7//f/7//3/AwABAAQABQD3//n/+//6/wYABQAEAAcA+v/3//3/AQAPABAADwALAP7/BAAIAAUABgAJAAoACgD8//v/AAADAAIAAQAHAAkADAAKAPj/+f/2//b//////wUABgD+//z//v/+/wkACgAAAP///v8BAAYABAD5//n/+v/8/wIAAAAFAAcABwAEAAcACQAAAP///f/9/wkACAABAAEA/P/8/wAAAQAEAAIABQAHAAgABgAKAAsAAQADAAoABQD//wYABAD8//v/AwAFAP///f8AAAUABQAMAAoABgAIAAgABwAGAAcACwANAA0ADgAHAAUA//8CAAYAAwAMABIACQAFAAwADwAMAAoACwAMAAQAAwAFAAYABQADAPz/AAAMAAcABAAJAAUAAQD//wQACQAFAAUACwAAAPv//f8CAP3/+f8GAAkA///9//7///8HAAcAAAAAAAEA/v/8/wEABAD9//r/AgAGAP7/AgAHAPv/9//5//z/AwABAPv//P/4//j////7/wAABgAAAPz//f8AAP7/+//+///////+/wQAAgAEAAcABwAEAP3///8HAAcAAwACAAgACQD//wAAAwACAAYABgALAA0ACwAIAAMACAAHAAIABAAJAAYAAQAFAAkAAQD//wEAAwAEAAMA//8EAAkAAwD+/wcACgACAAAABgAJAAUAAQAEAAEAAAAAAAMAAwAAAPz/AQD7//b/+/8AAAMAAADy//P/9v/2//3//P/+//7//v/8//j/+f/+//3//P/7//r//P/4//b//f/+//3//f/7//r//P/+/wQAAQD9/wAA/P/5//n//P8EAP7/BAAJAAYAAQD//wMAAQD9/wIABQABAP7/AAAEAAYAAgAFAAgABwAFAP//AAD9//3/CAAIAAYABAADAAMABgAFAAYABwABAAEA/v/8//n/+f/4//n/+f/4/wMABQABAP7/9//5/wYABQAIAAgA/v/9//3//P/8//3//v/+//L/8/8AAP7/+v/7//3//f8CAAIADAAMAP3//v8BAAEAAgACAP3//f/5//r/+v/7/wcACAABAAEAAgABAAIABAAFAAQAAwADAAMABQAGAAMAAwAFAP7//P///wAAAwAFAAgABgAPABAADQALAAUABwAHAAUACAAMAAgABQD//wEABgAEAAMABAAFAAUAEQAQAAoADAD///3/BwAIAAcABwD8//z/AAADAAMAAgAIAAcA//8DAAcAAwAGAAkA/v/9/wUABQD/////AAABAP///f/9////+v/5/////P8DAAcABAABAPv//f/4//j/+v/4//f/+v8BAPz//P8DAAgAAQD9/wMABgACAP3//f8EAAYA///9//3//v/9//z/AgACAAcABgAIAAsADwANABAADwAKAA4ACAAEAPr//v/8//r/CgALABAADgAIAAkABQADAAoADAAMAAsABgAGAAcABgANAA0ABgAGAAIAAgAOAA0ABQAGAAIAAgAKAAkACQAJAAIAAwAAAP7/AQAFAAMA/v/6//3/AwD///v//v8DAAIABgAFAAMABQAGAAIA/f8AAAYAAwD+/wIABwADAAUACQAFAAMA//8BAAIAAgACAAEAAgAEAAIA/v8FAAkADQAJAAYACgAKAAkABwAGAAIABQAJAAYACwAOAAcABwAHAAYABwAJAAkACAAPABAAFgAVAA4ADQD8//3/DgALAA0AEAAFAAEAAAAEAAwACQAJAAoACgANAAkAAwACAAkACQAEAAQABQAEAAcACgAGAAgACgABAP//AwAFAAIAAQAAAAIA+v/3////AwAGAAMA/f/+//z//v8FAP//AAAGAAUAAAABAAUA/v/7/wEAAwADAAAABQAJAAkABQD6///////7/wYACAAGAAYA/v/+/wUABQAJAAwADAAHAAAABQADAP//AAAEAAQAAQD+/wAABwAGAAUABQALAAsABgAHAAgABgACAAQAAgABAPz//P8HAAgADAAKAAIAAwADAAIADwAQAAAA/v/+/wEAAAD9/wMABAD+////BQABAAwAEAD5//b/+P/6/wYABwAHAAUA/P/+//v/+f8DAAQAAwADAAIAAwD3//T/+//+//7/+/8BAAQA///8/wAAAwD8//r/AwAEAAEAAgABAP7/+v/9/wEA/v8CAAQABgADAAAAAAD7//v/+f/4//v//f8CAAAAAAAAAAcABwALAAsACQAJAAEAAAAFAAcAAQAAAP7///8CAAAABQAGAAMABwAGAAMAAAADABAADgAJAAoA/f8AAAsACAAKAA0AAgACAAIAAwAJAAoABwAGAAAAAAAEAAUADQALAAAAAwD///v/DQAQAAcABAD4//v/BgACAAYACwAIAAUA+v/9/wEA//8HAAgAAAABAPv/+v8FAAYAAQABAPv/+v8CAAIABgAGAAAAAQABAAAACAAJAAMAAgD5//f/+P/9/wgABQAKAAsACAAKAAgAAwAGAAsAEAAMAAoADQADAAMAAQD//wUABwD///7//v/9/wYACQAIAAUACAAJAAoACQADAAIAAAABAAEA//8GAAkA/f/7//7/AAAJAAgACgAKAAAA//8BAAAAAgAEAAQAAQD7//7/AQD+/wgACAABAAEAAQD//wQABwAEAAAA/v8BAAEA//8DAAQA/////wIAAQAFAAcAAQD//wYACQAIAAQA+f/9//7/+/8DAAYABgAFAAQAAwAGAAkACAAEAAEABgAGAAIACAAKAAcABQD+/wAADAAJAAQABwAIAAUAAQABAAcACgAKAAYACAAMAAwACgAGAAYAAAABABAADgARABQACAAGAAIABAALAAgABwAKAAkABgD+/wMAAgD+/wMABQALAAsACAAKAAYABQADAAMABQAFAAMAAwABAAEAAgACAAgACgAGAAUA/v/+/////v8IAAkABQAEAAMABQAKAAgABwAIAAcABwAIAAYAAwAGAAYAAwAIAAsAAgD///v///8DAP3/BAAKAAQA/f8EAAwADQAGAAUACAACAAAACQAKAAEAAgABAP//AAABAAEAAAABAAIACQAJAAQAAwAGAAgABAACAAMABAD9//3/AgABAAIAAwD///7/AwAEAAQABAACAAAAAgAEAAkABQACAAUA/v/7//7////8//v/BAADAPj/+P/9//v/AAAAAAYABQD5//r//P/5////AwADAP//8P/z/////v8EAAEA+f/8/wAA/f///wEA/P/6//3//P8DAAUACAAGAPz//f/6//j/BAAFAAEAAgD9//7//P/9/wMAAgD+////AAD+//r/+/8BAAAAAAAAAAAAAgACAP//AAADAAUAAgD8//7//f/9/wEAAQABAAMA+v/2//v//v8MAAkAAwAEAPj/+P8GAAYACAAHAPX/9v/9//3//P/7/wAAAgD9//r///8CAAUAAwAEAAUAAQAAAPz//v/9//n/+f/9/wQA///8/wIA/v/7//T/9v8AAP7/AAACAAMAAQD//wEA+v/5//f/9v8CAAEA/P/9//z/+v/3//r/BAABAP7/AAD+//3//f/+/wkABwACAAUAAgD+//n//f8CAP3/AwAGAAUAAwD9/////f/8/wYABwAGAAMA/v8CAAIA/v/7////BAABAP3/AAABAP7/BwAIAAwADwAJAAYA//8FAAcA///9/wUABgACAAkACgABAAMABwADAAIABgAKAAgABQAHAAUABQD6//n/AgAFAAkABgABAAUA///7/wgADAAIAAUAAQAEAAYAAwAHAAsADAAHAPz/AgACAP3/BQAIAAQAAgD8////AgAAAAAAAQAHAAgAAgD//wEABAAAAP///////wIAAgAIAAoA///7/wgADQAKAAQACQAPAAgAAwAIAAwADQAJAAQABQACAAIABQAFAP7//f8CAAQABAAAAAIABgD7//n/+f/5//z//f8IAAQA//8FAAIA/P8DAAcAAgD9//T/9/8BAP//CAAJAAwACwAEAAMAAAABAAQABAAGAAUAAgADAAYABQAMAAsABgAKAAgABAAFAAcAAAAAAPz//P8BAAAA/f///wYABQANAA4ABwAKAP///P8JAAwACgAJAAQABAACAAMACQAIAAoACgAGAAYABwAGAAUABgACAAQA///+/wMABAAGAAQABwAJAAYABwAHAAYAAwAGAAgABAAAAAIABgAHAAAA/v8BAAEABQAHAAgABQD//wQABgAFAAsABwACAAkABQD+/wEABQAGAAYADAAKAAUACgAGAAEA/P///wYABQAIAAkABQADAAEABAADAAAABwAKAAIA/////wIABgACAAkADgAHAAMABAAGAP7//v8DAAEA//8CAAAA/v/3//f//f/+/wYABQACAAMABQAEAAMAAwAHAAUAAAADAAAA+//4//3/BAAAAP7/AgAEAP//+/8AAAEA+////wMAAgAAAAAAAAD5//v//v/7//7/AQADAAAA/P/+/wUABAACAAMAAwABAAQABwABAP3//f8BAAEA/v8AAAIA/f/8//7//f8CAAUAAQD9////BAAEAP///v8AAPr/+v/9//r//P8BAP7/+//6//v//P/9/wAA/P8AAAYAAAD7//r///8GAP//+P/+/wIA/P/6/wEADAAFAP7/AwAIAAQA+P/9/wQA/f/2//7/BQD+/wAABAAIAAcA/v/+///////6//n/+P/3//f/9v8CAAQABgAEAP//AAD+////AwAAAP//AgD9//r///8CAP3//P8EAAIA+////wQA//8DAAgAAQD+/wIAAgAHAAgADgAMAAEAAgD8//z/+f/4/wEAAgD+//7/AgABAAIABAAJAAcAAgACAAQABAD8//7/AQD+//r/AAAEAPz//f8FAAsABQABAAUA/P/5//7/AAAIAAcA/P/+/wAA/v8GAAgADAALAAoACwABAP7/BgAJAAQAAgAAAAMABAADAAIAAgAFAAQACQAMAA4ACwAEAAUA/////wAA//8CAAUABwAEAAEABAAGAAMAAwAGAAkABwAIAAkABQAFAAUABgAEAAMAAwAEAP7//f/8////CgAIAAkADAAEAP7/AAAHAAgAAAACAAkABQAAAP7/AAD///7/+f/5/wMAAgACAAQA///7/wMABwAIAAQAAQADAP////8HAAcABQAHAP///f8BAAIABgAFAPv//v8BAP3///8DAAQAAQACAAMAAQABAAcABQAFAAYACAAIAAUABAD//wIAAAD8//v//v8FAAMABAAEAPz///8DAAAAAAACAAUAAgD7////AgD9//v///8DAAAABwAHAAEABAABAPv//f8CAAUAAQD8//3/+v/8//7/+/8IAAsABAABAP7/AQACAP7/AwAIAAcAAgD5////CAADAAcACgAHAAUAAAADAAoACQAIAAsAAwAAAAMABQAFAAQAAwAGAAQAAwAEAAUABgAGAAMABAANAAwABgAIAAEAAAADAAQABwAHAAIAAgACAAIAAQACAAgABwD+//7/AgABAAMAAwAEAAUABgAFAAMABAACAAEA/v/+//3//P8BAAAAAwAEAAoACQAFAAYAAwAAAAAAAwAGAAMA/v8DAPr/9//7//3/AwABAPz//v////3//f8AAAYABwAGAAUA/v/+//7///////3/BQAKAAEA/v/3//j/+v/7/////P/7////BQABAP7////9//7/BQACAAYACQADAAIA+P/1//f/+/8CAP//AAAAAP7///8GAAUABQAEAPz//f8FAAIACAAJAAIAAgAAAAEAAgD///v/AAD8//b/+f///wAA+//9/wAAAgABAAIAAgD4//n////+/wEAAwAEAAQA+f/6//v/+//8//z/+//9//3/+v/+/wIABQACAPv//P/9//z//v8AAAEA///+/wIA/v/4//P/+f8CAPz//v8EAAQA///9/wEABAD//wIAAwAFAAQAAQABAP7///////3/CwANAAUAAgD4//r/+v/5//7//v/5//n//v/+/wAA//8DAAMA/P/9/wIAAQD+/wAAAAD9//z//v//////+//6/wEABAACAP//AgAEAP7//v8LAAoABQALAAQA/f/8/wQABAD9/wMACQADAP//AQADAAAAAAAFAAIABAAIAAwACAD8/wEAAAD6//v/AAADAP//AgAGAAIA/v/9/wAABgADAAYACgAJAAYAAQADAP3/+//9//3/AgACAAEAAQD8//z//P/8/wUABQAOAA4AAwAEAAIA/////wQACAACAAEABwD8//j/AgADAAcACgAOAAkA//8FAAEA/P/+/wIA///+/wYABQAFAAcAAgABAAcABwANAA0AAwACAPH/9P/7//f//v8DAP//+//4//n//f///wMA/v/9/wIACAAGAPz/+//0//f/AAD6//7/BAD9//j/+f/8/wMAAAAAAAAA+f/7/wMAAAD6////AAD8////AQD4//j//v/6/wAABAAQAA0ADAAPAAcABAAEAAYAAwD+//z/AAD///7/BQAFAP7/AQAAAP3/AgAEAAcABwAEAAIA/f///wEA//8DAAUAAAACAP//+/8EAAoACAACAPj//f8CAAAACQAIAAIABQABAP7/BAAGAAwACwADAAIAAgACAAIAAwAFAAQA/v///wIAAAAEAAcABwAFAAcACAAAAAAABgAFAAQABQAAAP//AwAFAAoACAAJAAsABQACAAEABAAEAAEA//8DAAUAAQACAAcACgAFAAoAEAAQAAsABwAKAAEAAQAHAAcAAwAFAAEA//8IAA0AFgARAAYADQAGAAAA/f8BAAwACgABAAMAAQAAAAQABQD/////BAADAAQABAADAAQAAAD+/wMABQAIAAQAAwAHAAoABgD9/wEA/f/6//n/+v/+//z//v////v//P/9//v/+f/9/wEA/P8EAAgACQAFAP7/AQD9//v/BQAGAPz/+////wEA/v/7/wAABAD7//n//f/+/wIAAwD9//z//P/9//7//f/+/wAA/v/7//3/AAD///z//f////7//v8BAAEA/f/+/wIAAAAFAAcABwAGAP3//v8CAAEABQAFAAAAAAD9////AgD/////AgD///v/AQACAAEAAAD9//v/9//6//v/+P/7//7/+//4//z///8BAP7//f/+//7/AAAEAAEA/v8BAPr/9//8//v/AAADAPv/+f/2//b//v///wQAAwABAAIAAAAAAP///v8AAAAABQAGAP///v/7//7//f/6/wAABAD+//z//v8AAP///v8DAAMA///+/wIABAAAAP7/+v/8/wIAAQACAAIA/v/8//r//P8EAAIABgAIAAIAAQAEAAQACAAHAAEAAwACAAEABQAEAAgACgAGAAMAAAADAAUAAwACAAMAAgACAAAAAQACAAEABAAEAAkACgD/////AAD///z//v8JAAYA/f8AAAMAAQABAAIABwAHAAMABAAFAAEAAQAHAAYA//8AAAcACAADAP7///8DAAUAAwAAAAIABAD+//3/AgADAAMAAgD9//3//v///wMAAQD9/wAA///8//z//f8BAAIABwAHAAoACAACAAUABQABAP7/AQADAAAA9//6/wQAAwACAAAAAAAEAAMA/v8CAAcAAwAAAP3//v8EAAEA//8CAAQAAQACAAQAAAD///v//P8EAAIAAAADAAIA/v/9/wAA/P/7/wIAAwAEAAIA+f/9/wMA/f8DAAkACAADAAAABAACAP//AgAEAAIAAgADAAIADQAOAP3//P/7//z/DAALAAwADgAEAAIA9P/3/wEA/v8DAAcABQACAAEAAwAAAP//AwADAP//AAAFAAQA/v///wIAAQD7//v//f/+//3//f/8//v/+P/5/wEA//8EAAkACgAGAPz///8EAAAABgALAAkABgAGAAgAAQD+//3//f8DAAUAAgAAAPr/+//7//v/BAADAP//AQACAAAA//8AAP/////4//f/+P/5//z//P8CAAIA/v///wcABAD+/wEABAADAP//AAAAAP//+v/6////AAADAAIAAgAEAAsACAD8/////f/7/wAAAgD8//3/AwABAPf/+/8DAP//AAADAAIAAgACAP3/AQAJAAQA/f/+/wMA/P/5//3//v/+//3//f///wEA//8EAAQA//8AAP///P/9/wAA///8//3////+//3/AQABAAEAAQD+//3//P/9//3//f8BAAEA/f/9/wIAAwACAAEABQAFAP3//f/4//j/+v/6//z//f8AAP///f8AAAMAAgAEAAQAAgACAP///////wAA///+////AAD///7/AAACAAMAAQABAAQAAgD8////BwAHAP7/AAAHAAYA//8AAAYABQD///r//v8BAP///v/9//3/AgD///j//f8CAP///P///wEAAAD///z//P8BAAAA/////wEAAwAAAP7/AAACAAgABQD+/wIAAQD+//3/AAAFAAMAAAAAAP//AAADAAMAAwABAPz////8//n//P////3//P/7//j/9//8/wAA+/8GAAoAAQD+/wAAAwABAP7/BQAGAAEA///+/wAA/////wAA///8//z/BgAGAPv/+//7//v/+v/5/wAAAgD8//r/9v/4/////f8DAAQAAQABAP7//v8EAAMAAQADAAYABAD+/wAAAwABAP//AgD///v//v8CAAMA//8BAAQAAQABAAkABgACAAYAAwD///3/AAAFAAMAAwAEAAUABgACAAMAAgACAAQAAwAHAAkAAQABAP///v8IAAoABwAFAAEABAAFAAMABwAJAAQAAgAEAAQABgAJAAQA///6/wAABwABAAYACgADAAAAAwAHAAkABAAEAAgABAAAAAYACAACAAEAAgAEAAMAAQAJAAsABQACAAIABQAAAP7/AwAFAAQAAQABAAYA/v/7/wEABQABAP7/CAAIAAIABAACAP///v8CAAYAAwAAAAEABgAHAAkABwAKAAwABQAFAAQAAwAEAAQAAQABAPr/+v/+/wAAAQD+//7/AAD6//n/9//2//n/+/8GAAMAAQAEAP///v////3//v8DAAMA+//z//z/AQD5//r//v8EAAEACAAIAAMABQD8//r//f/+/woACAD9/wAABQABAP3/AQACAAAA/v/+//7/AQABAPz//P///wEAAAAGAAgAAAD+//7/AgABAPv/AwAJAAUAAAD6//7/AQD+/wEAAgAFAAgAAgD+//f//f8FAP//AQAEAAAAAAABAAAAAQADAAYAAwACAAQABQAEAAUABgAFAAUA/v/8/wAAAwACAP//+v/8/wAA//8CAAIACgAKAAIAAwALAAgABQAIAAIAAAD9//7/+//6/wEAAgAAAAAABwAGAPz//v8IAAUA/v8BAAEAAAACAAEABwAJAAcABAADAAYACAAGAAkADAD+//z//v8AAP//+//7/wEA/f/3////BAABAAAAAwAAAAUACAADAAEAAQACAP3///8CAP7///8DAAQA//8DAAkA///6/wEABgAIAAMABQAIAPr/+f/9//z//f///wUAAgD9/wAAAAD9/wAAAgADAAAA//8CAAcAAwABAAYAAAD6//7/BQADAPz/AgAHAP///f8EAAQABgAHAAIAAAD8////AQD+//3/AAD///v/AAAEAAQAAgADAAIA/v8BAAIA/v///wIA/f/8/wEAAAD8//7/AgABAP7//f8GAAgAAgAAAP//AAAGAAcAAwACAP///f/1//n/AAD7////AwACAAEABQABAAUACgAFAAEAAQAFAP7//P/9//3//v/9//z//v8DAAAA/v8DAAgAAgD+/wMABwADAPv//v8FAAMA+//9/wQAAwD//wAA/f/9/wIABAABAAEABwAHAAUABQAHAAcACQAIAPz//v////3//f/+/wEAAgACAP//BwAKAAMAAQD+/wAA/v/7/wAAAwABAP7/AQADAPz//f8BAP3//P8CAAQA/v8AAAQAAgAAAAIAAgAGAAgACgAIAAUABQACAAQABwADAAQACQAIAAQAAQADAAUABgD7//r/AQACAP3/+////wIA///9/wQABAD+/wEABAD+/wMACQACAP//AAD///7/AQAFAAMABgAGAAQABwAGAAEA/v8AAAgACQAHAAQAAwAGAP///v8FAAQAAQAEAAMA/v///wQAAwD///z//v8DAAUABQD///r/AgD+//b/+v8BAP3/+f8DAAQABQAFAAIAAgABAAAAAAABAAQAAQD//wIA///9/wUABwAAAP7/AQACAAkABgAAAAMAAQAAAAQAAwD+/wEAAAD8//7/AQAEAAMAAQABAAEAAQAEAAMA//8AAP3//P8EAAcAAgD9////BQACAPv/AAAGAAAA+//+/wMABAABAP7/AAD/////AgAAAP7/AQAEAAAAAgAFAAQAAgAFAAUAAAABAAUAAwD9/wAA///9/wAAAAAGAAYAAQACAAEA//8EAAUABQAHAAkABAD6/wEAAwD9/wAAAwABAAAAAQAAAAMABgADAAEAAgACAP//AAACAP//AAAFAAYAAQD9/wEABAABAAIAAwADAAQAAAD//wMAAwAAAAEAAgAAAAAAAgD+//3////+//z//f8FAAUABAABAAAABAABAPr//f8FAAQA/f/+/wIAAQAAAAAA//8BAAAA+v/9/wQA///9/wEAAQD8//7/AQAFAAEA+//+/wIA///9//3/AAABAAEA//8CAAIABAACAAUABQADAAIAAgAEAAYAAAD9/wMABAD8//r/AQAEAAAA/f/+/wEAAQAAAAAAAwABAAUABwADAP//BAAGAAIAAQAEAAIABgAJAAMA/v8FAAoAAwD9/wIABwAAAP3/BAAEAAMABQAEAAIAAwAFAP///f8BAAIAAQABAAIAAgAAAAAA/v/+/wEAAAD+/wEA///+/wEAAAD//wAAAAABAP3//P/+/wIA///5//3/AgAAAPz//f8BAAEA//////7/AQAEAAEA/f/8/wAA///9//7////8//v/AgADAAAAAAACAAMAAgADAAUAAwAFAAcA//8AAAYABQD8////AwABAP3///8AAAEABAADAAAAAwAEAAEA/P8BAAMAAAACAAMAAgAEAAEAAQABAAIAAwABAAAAAgABAP//AQAFAAEA/v8BAAQAAwAAAAQABwAEAAQABwAEAP7/AwAGAAIAAQADAAIAAgAAAP//AAACAAAA/v///wMABAABAAEABAADAAEAAQACAAIAAQABAAIAAAAAAAQAAwABAAIABQAGAAAAAAAFAAYA///+/wYABgD//wEABQAEAAAAAgAGAAMAAAADAAgABgAHAAgABQAFAAYABgADAAIA//8CAAUAAAD+/wQACQADAP7/AwADAAAAAwAEAAMABAAIAAMA/v8DAAcAAQD+/wMACAACAAEABAADAAAAAgADAAUAAwACAAQAAgAAAAEAAgABAAAABAADAP//AQAFAAMABQAFAAIAAQAGAAYAAgADAAAAAAAFAAMAAgAFAAQAAQAEAAYABAAEAAwACAAEAAYABwACAAIABgADAAAAAgAEAAUAAwAFAAUABwAIAAYABwAFAAMAAgADAAAAAAAAAP///v8AAAcABQABAAAAAwAEAAIAAAAGAAYAAQADAAYAAwD//wIAAAD+/wIAAQAEAAUAAwABAAIABAAEAAQABAACAAIABQAAAPz/AQAFAAIA//8AAAMA///+/wMAAQD+/wIABQABAAEABAAEAAIAAgAEAAUAAgAAAAMABwACAAEABQAGAAQA//8AAAQABQABAP7///8CAAEA/v8DAAcABQACAAAAAwADAP//AwAGAAEAAQAEAAUAAgABAAMABgAEAAAAAwAIAAUAAQAHAAkABQADAAQACAAEAP//AQAEAAUAAwACAAIAAQADAAYABAAAAAEAAwADAAAAAAADAAMABQAEAAIAAwAGAAQABAAFAAQAAwABAAIAAQAAAP7///8BAP///v8BAAIAAQACAAMAAAD/////AQAAAP3/AgADAAAA//8DAAIA//8AAAYABQD8//3/AgABAPv//P8CAP///v8CAAQA//8AAAQAAwAAAAEAAwD//wAABAABAAAAAAAEAAQAAAD9/wUACgADAP7/BAAIAAIA//8FAAUAAQACAAMAAgABAAEAAAACAAMAAAACAAYAAAD8/wMABQAAAP//AAACAAEAAAD//wEAAgD//wEAAwAAAP///f/+/wAAAAAAAP7///8BAP///v8AAAMAAwABAAIAAgABAAEA//////7///8BAAEAAAD+/wEAAwACAAAAAwAFAAIAAgAGAAIA/v8EAAUA///6////AgAAAP7//P///wMA///6//z/AgD9//n//f8DAAEA+//9/wIA/f/5//7/AgD///7/AQACAAAAAgACAAEABQAHAAQAAQACAAUAAwABAAEAAgACAAMAAwADAAEAAQAEAAQAAgACAAMABAAAAP//AQAEAAIA//8EAAUAAQABAAMAAgABAAQABQABAAAABAADAP//AQAEAAEAAAADAAIAAwAFAAUAAwAEAAYABgAEAAMABQADAAAAAgAGAAUAAwAGAAYAAwADAAUABAAEAAYABgAEAAEABQAFAP7/AQAHAAIA//8BAAIAAQABAAIAAgADAAMABQAFAAUABgAEAAEAAgAFAAQABAAFAAMAAgAEAAQAAwAFAAQA/v8AAAQAAwAAAP3/AwAIAAYA//8AAAQAAwABAP7//f8EAAQA/v/+/wIAAQD//wEAAwACAAEAAQADAAMA///+/wMABQACAAAAAAABAAMAAQABAAIABQAEAAEAAwAFAAIABAAGAAAAAQAHAAMA//8FAAUA//8DAAgAAwD//wEABAAEAAMAAQABAAYABwAAAP7/BgAIAP///v8EAAQAAAABAAEA//8EAAUAAQD//wMAAwAAAAEABAAAAP//AwBMSVNULgAAAElORk9JU0ZUIgAAAExhdmY1OS4yNy4xMDAgKGxpYnNuZGZpbGUtMS4wLjMxKQBpZDMgOAAAAElEMwQAQAAAAC0AAAAMASAFDSs7Vj9UWFhYAAAAFwAAAFNvZnR3YXJlAExhdmY1OS4yNy4xMDAA", stopOtherAudio: false });
        }
        if (this.mode.page !== "document")
          throw new Error("Photo cancelled when leaving Document mode.");
        if (announce) {
          this.photoSpeech = speakWithTiming(this.session, "I'm taking a picture.").catch(() => {
            console.warn("[document] photo announcement failed");
          });
        }
        const photo = await this.session.camera.takePhoto({ size: "medium", mode: "photo", transferMethod: "ble", compress: "medium", sound: false });
        if (!photo.photoUrl)
          throw new Error("The camera returned no image. Please try again.");
        entry.photoUrl = photo.photoUrl;
        entry.pending = false;
        this.publish();
        const key = `document/photos/${entry.id}.jpg`;
        await this.session.blob.setFromUrl(key, photo.photoUrl, { mimeType: "image/jpeg", name: `${entry.id}.jpg` });
        this.photoKeys.set(entry.id, key);
      }).catch((error) => {
        entry.error = error instanceof Error ? error.message : "Could not take photo. Please try again.";
        entry.pending = false;
      }).finally(() => {
        this.snapshot.capturing = false;
        this.publish();
      });
    }
    async generate() {
      const records = this.snapshot.entries.filter((entry) => entry.kind !== "report").filter((entry) => entry.kind === "text" || Boolean(entry.photoUrl)).map((entry) => ({ ...entry }));
      if (!records.length)
        return { success: false, error: "Record a note or take a photo first." };
      this.snapshot.generating = true;
      this.snapshot.error = undefined;
      this.publish();
      const abort = new AbortController;
      this.summaryRequest = abort;
      const timer = setTimeout(() => abort.abort(), 60000);
      const current = () => {
        if (this.mode.page !== "document" || abort.signal.aborted)
          throw new Error("Report generation cancelled.");
      };
      try {
        const response = await fetch(`${enterpriseBackendUrl()}/api/document/summary`, {
          method: "POST",
          signal: abort.signal,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ records: records.map((record) => record.kind === "text" ? { at: record.at, text: record.text } : { at: record.at, photo: true }) })
        });
        const data = await response.json();
        if (!response.ok || !data.summary)
          throw new Error(data.error || "Could not create the summary. Please try again.");
        clearTimeout(timer);
        current();
        const materialized = [];
        for (const record of records) {
          current();
          if (record.kind === "text")
            materialized.push({ at: record.at, text: record.text });
          else {
            let key2 = this.photoKeys.get(record.id);
            if (!key2) {
              key2 = `document/photos/${record.id}.jpg`;
              await this.session.blob.setFromUrl(key2, record.photoUrl, { mimeType: "image/jpeg" });
              this.photoKeys.set(record.id, key2);
            }
            const photoBytes = await this.session.blob.bytes(key2);
            if (!photoBytes?.length)
              throw new Error("A photo is unavailable. Please try again.");
            materialized.push({ at: record.at, photoBytes });
          }
        }
        const createdAt = Date.now();
        const pdf = await createDocumentReportPdf({ createdAt, summary: data.summary, records: materialized });
        current();
        const id = this.id();
        const fileName = `acme-document-${new Date(createdAt).toISOString().replace(/[:.]/g, "-")}.pdf`;
        const key = `document/reports/${id}.pdf`;
        await this.session.blob.set(key, pdf, { mimeType: "application/pdf", name: fileName, meta: { kind: "document_report" } });
        current();
        this.reportKeys.set(id, key);
        this.snapshot.entries.push({ id, at: Date.now(), kind: "report", summary: data.summary, fileName, recordCount: records.length });
        return { success: true };
      } catch (error) {
        const message = error instanceof Error ? error.message : "Could not generate report. Please try again.";
        if (this.mode.page === "document")
          this.snapshot.error = message;
        return { success: false, error: message };
      } finally {
        clearTimeout(timer);
        if (this.summaryRequest === abort)
          this.summaryRequest = undefined;
        this.snapshot.generating = false;
        this.publish();
      }
    }
  }

  // src/background/aiSpeechWindow.ts
  function words(text) {
    return Array.from(text.matchAll(/[\p{L}\p{N}]+/gu), (match) => ({ word: match[0].toLowerCase(), start: match.index }));
  }

  class AiSpeechWindow {
    text = "";
    keep = false;
    ignored = [];
    checked = "";
    candidateWords = 40;
    failures = 0;
    attempted = "";
    pending = Promise.resolve();
    timer;
    busy = false;
    closed = false;
    boundary(tokens) {
      let count = 0;
      while (count < this.ignored.length && count < tokens.length && this.ignored[count] === tokens[count].word)
        count++;
      return count;
    }
    candidate() {
      const tokens = words(this.text);
      const boundary = this.boundary(tokens);
      const end = Math.min(tokens.length, boundary + this.candidateWords);
      const start = tokens[boundary]?.start ?? this.text.length;
      return {
        question: this.text.slice(start, tokens[end]?.start ?? this.text.length).trim(),
        ignoredContext: boundary ? this.text.slice(tokens[Math.max(0, boundary - 5)].start, start).trim() : "",
        captured: tokens.slice(0, end).map(({ word }) => word),
        freshWords: end - boundary
      };
    }
    finalText() {
      const tokens = words(this.text);
      const boundary = this.boundary(tokens);
      if (boundary === tokens.length && boundary > 0)
        return "";
      const start = boundary ? tokens[Math.max(0, boundary - 5)]?.start ?? 0 : 0;
      return this.text.slice(start).trim();
    }
    counts() {
      return { originalWords: words(this.text).length, sentWords: words(this.finalText()).length };
    }
  }

  // src/shared/ai.ts
  var AI_INTRO = "Ask me a question. I can answer, look through your glasses, or search the web.";

  // src/background/cerebrasVin.ts
  async function loadVinImage(photoUrl, blob, step = (_stage, run) => run()) {
    const key = `vin-ocr-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    const started = Date.now();
    try {
      await step("photoDownload", () => blob.setFromUrl(key, photoUrl));
      const bytes2 = await step("photoReadBytes", () => blob.bytes(key));
      if (!bytes2?.length)
        throw new Error("VIN photo download returned no image bytes");
      const mime = bytes2[0] === 255 && bytes2[1] === 216 ? "image/jpeg" : bytes2[0] === 137 && bytes2[1] === 80 && bytes2[2] === 78 && bytes2[3] === 71 ? "image/png" : null;
      if (!mime)
        throw new Error("VIN photo download was not a JPEG or PNG image");
      return await step("photoBase64", async () => `data:${mime};base64,${bytesToBase64(bytes2)}`);
    } finally {
      await blob.delete(key).catch(() => {});
      console.log(`[vin] photoLoadMs=${Date.now() - started}`);
    }
  }

  // src/background/controllers/AiController.ts
  class AiController {
    session;
    mode;
    snapshot = { messages: [], phase: "idle", queued: 0 };
    history = [];
    queue = [];
    speechWindow = new AiSpeechWindow;
    interimRequests = new Set;
    speechFinals = Promise.resolve();
    introTask = Promise.resolve();
    processing = false;
    drainTask = Promise.resolve();
    sequence = 0;
    request;
    generation = 0;
    ui;
    constructor(session, mode) {
      this.session = session;
      this.mode = mode;
    }
    start() {
      this.ui = this.session.ui;
      this.ui.onOpen(() => this.publish());
      this.ui.on("ai:request-snapshot", () => this.publish());
      this.ui.on("ai:ask", ({ text }) => this.enqueue(text));
      this.session.transcription.on((event) => {
        if (this.mode.page !== "ai")
          return;
        const window2 = this.speechWindow;
        window2.text = event.text;
        if (!event.isFinal) {
          this.scheduleInterim(window2);
          return;
        }
        window2.closed = true;
        clearTimeout(window2.timer);
        this.speechWindow = new AiSpeechWindow;
        const generation = this.generation;
        this.speechFinals = this.speechFinals.then(async () => {
          await window2.pending;
          if (this.mode.page !== "ai" || generation !== this.generation)
            return;
          const counts = window2.counts();
          console.log(`[generic-ai] final window originalWords=${counts.originalWords} sentWords=${counts.sentWords}`);
          this.enqueue(window2.finalText());
        }).catch((error) => console.warn("[generic-ai] speech final failed", error));
      });
    }
    async deactivate() {
      this.generation++;
      this.request?.abort();
      this.speechWindow.closed = true;
      clearTimeout(this.speechWindow.timer);
      this.speechWindow = new AiSpeechWindow;
      for (const request of this.interimRequests)
        request.abort();
      this.queue = [];
      await Promise.allSettled([this.drainTask, this.introTask, this.speechFinals]);
      this.setPhase("idle");
    }
    async activate() {
      await this.session.mic.setLoudnessGateEnabled(true);
      this.publish();
    }
    speakIntro() {
      if (this.mode.page !== "ai")
        return;
      this.introTask = speakWithTiming(this.session, AI_INTRO).catch((error) => console.warn("[generic-ai] intro speech failed", error));
    }
    publish() {
      this.snapshot.queued = this.queue.length;
      this.ui.send("ai:snapshot", this.snapshot);
    }
    setPhase(phase) {
      this.snapshot.phase = phase;
      this.publish();
    }
    append(message) {
      const id = `ai-${Date.now()}-${++this.sequence}`;
      this.snapshot.messages = [...this.snapshot.messages, { ...message, id }];
      this.publish();
      return id;
    }
    scheduleInterim(window2) {
      if (window2.closed || window2.keep || window2.busy || window2.timer)
        return;
      window2.timer = setTimeout(() => {
        window2.timer = undefined;
        const candidate = window2.candidate();
        if (window2.closed || window2.keep || candidate.freshWords < 3 || !candidate.question || candidate.question === window2.checked)
          return;
        if (window2.attempted !== candidate.question)
          window2.failures = 0;
        window2.attempted = candidate.question;
        window2.checked = candidate.question;
        window2.busy = true;
        const generation = this.generation;
        const abort = new AbortController;
        this.interimRequests.add(abort);
        const timeout = setTimeout(() => abort.abort(), 4000);
        window2.pending = (async () => {
          try {
            const response = await fetch(`${enterpriseBackendUrl()}/api/ai/interim-intent`, {
              method: "POST",
              signal: abort.signal,
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ question: candidate.question, ignoredContext: candidate.ignoredContext, history: this.history.slice(-10) })
            });
            const decision = await response.json();
            if (this.mode.page !== "ai" || generation !== this.generation)
              return;
            if (!response.ok || !["ignore", "keep", "wait"].includes(decision.intent ?? ""))
              throw new Error("Invalid interim classification");
            window2.failures = 0;
            if (decision.intent === "ignore") {
              window2.ignored = candidate.captured;
              window2.candidateWords = 40;
            } else if (decision.intent === "keep")
              window2.keep = true;
            else
              window2.candidateWords += 40;
          } catch {
            window2.failures++;
            if (window2.failures < 2)
              window2.checked = "";
            else
              window2.candidateWords += 40;
            console.warn("[generic-ai] interim classifier unavailable; retaining unclassified speech");
          } finally {
            clearTimeout(timeout);
            this.interimRequests.delete(abort);
            window2.busy = false;
            this.scheduleInterim(window2);
          }
        })();
      }, 600);
    }
    enqueue(raw) {
      const text = raw.trim();
      if (!text || this.mode.page !== "ai")
        return;
      if (text.length > 64000 || this.queue.length >= 5) {
        this.append({ role: "assistant", text: text.length > 64000 ? "Please ask a shorter question." : "Please wait while I finish the queued questions.", error: true });
        return;
      }
      this.queue.push({ text });
      this.publish();
      if (!this.processing)
        this.drainTask = this.drain().catch((error) => {
          console.warn("[generic-ai] queue failed", error);
          this.processing = false;
          this.setPhase("idle");
        });
    }
    async api(path, body) {
      const abort = new AbortController;
      this.request = abort;
      const timer = setTimeout(() => abort.abort(), 60000);
      try {
        const response = await fetch(`${enterpriseBackendUrl()}/api/ai/${path}`, { method: "POST", signal: abort.signal, headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
        const data = await response.json();
        if (!response.ok)
          throw new Error(data.error || "The AI service could not answer. Please try again.");
        return data;
      } finally {
        clearTimeout(timer);
        if (this.request === abort)
          this.request = undefined;
      }
    }
    async drain() {
      if (this.processing)
        return;
      this.processing = true;
      try {
        while (this.queue.length && this.mode.page === "ai") {
          const turn = this.queue.shift();
          if (!turn.text)
            continue;
          if (turn.text.length > 4000) {
            this.append({ role: "assistant", text: "Please ask a shorter question.", error: true });
            continue;
          }
          const generation = this.generation;
          const current = () => this.mode.page === "ai" && generation === this.generation;
          try {
            this.setPhase("routing");
            const input = { question: turn.text, history: this.history.slice(-10) };
            const decision = await this.api("route", input);
            if (!current())
              continue;
            if (decision.route === "ignore") {
              console.log("[generic-ai] ignored ambient speech");
              continue;
            }
            if (decision.focusedQuestion?.trim() && turn.text.includes(decision.focusedQuestion.trim())) {
              turn.text = decision.focusedQuestion.trim();
              input.question = turn.text;
            }
            this.append({ role: "user", text: turn.text });
            let result = decision;
            let photoId;
            if (decision.route !== "none") {
              let image;
              if (decision.route === "camera" || decision.route === "search_camera") {
                this.setPhase("capturing");
                await this.mode.withCamera(async () => {
                  if (!current())
                    return;
                  if ("data:audio/wav;base64,UklGRrqpAABXQVZFZm10IBAAAAABAAIAgLsAAADuAgAEABAAZGF0YSCpAADE9t/2/gADAc0FpQVt9cP0ue4X7vP3evdfBR0FYQyWDN8Ovg9tEn8TjBQ7FSAWkxaCCJgIrvHc8Gj1YfSsCVoJCQQKBPLwwfBQ/ZP9vQxFDfTzgPON4qnhsPfD93gBwAFM9wb37AIzA44QixFC/af9LO0G7Sn8VPzoCOAIXv5N/X/z8/ER9AXz6vV59XH+cv6hFEkVriSSJXsV+xWX7jbuvNax1RntEuw5GMYXWRkRGSz20fXh7dztHwMiAxUGOgUX9a7zqvbF9Z0BzwCC96r1XPCI7lP/7/7TCgILfA1eDcYaRRsdH1ggiwCMAA/oRuY470/tAeoa6NvVSdNa3xLdk/qy+RgHSgdXEAIREB69Hu0keCUQGTIZufOU8orZL9eQ78DtrgUhBdzyEPKR9Nzz2BlPGuIS5RLd7kTtzPaU9acNag1TBJEDWfM78rz3mveMA2MD7fi+9yzb59lP26TapwYGBmgZsxhp/xv/B/sC+5QKQwpn9HzzudhY1xvst+pUAxkCePdq9n3w+O/cCvQKOySHJGAVeBWk9Vf10vOY83YBYQHC/Df80/fC9mL8qvsj8cDw6eb45ZX7j/oiDygPHgT3BN34mfk0BtMGGxYbFwsNqQ3u6Nzn+siwxg3TItLn9VL2cQjmB4kQaBBBF8UZog4REOEC5gAkBJIDXwFqAzL6APolBL4CvQ0pD+r7H/0z4SjflNr/2Lzpf+q8/AX9qAVMBa8KmwsmD+MQhA6pD24NtA1TCxsLewO4A1T5hfl98lXx3vPU8tr5jPrj+jr71/jc9678qvyaAMABLfyJ/JgB0QFcFtUX3BihGvEEAwbT+z/8pfdL99Pg+t8+0cPPa94X3H3pu+e86kfrSgcRCSI3qzgoRYhHYihrK2cCPAPI7ojtL/LF8STxD/HC4VDgveG94H3t8O1U7vvtGfI68awAPwH5DFUOKxpyG1EkMiZqEiUUvvEv8hfq8+ky6onpFtdS1QLVrtNp9ov2QRSvFE8fFiBeJUknEB7KH3UE4wTE877zqvnd+S78QPyh7Vbt/eWS5dzuy+7O9jz3kfpZ+0b9hP6k/Qr/ogZWB1gQbRAG/nr+xeh66YH7tvvWC2MLdPK58YnsfuxSE8oU6x0GIM3/+AB5/+z/jxhGGYAFEwZ54LHg6u+s8PsEawVi5y3mM9153BwF8wZGCg0MlOsh61f49fcbEeURDf9u/0T3pveDCtQLyApoC+EQmxC4JIMlQgytDcjkJuWC8U/wJRAJDvEP5g5U+Fr5ruLB4wLyhvGtGAMYnRTEFGHuO+9D5VbmCfYf9ngBJQCOBngFWxL/EmQoBCuYHxUif+mK6JzUmtCf8EHtvO6S7WXgreBSB1kIYTRGNe4mTCe0/y8Awvb493MFxwYgA2cDlO+T7j/wIe9YBDoEsv/I/w3m7OQR7CnqAwwNC84UdRU6DZ4O4h0WH0M1/DVXDAoMV7i0tmS6irnzCP4JEhN9E9HqEerm/aL+oR2QH5IIegl198P3YgFvATj6gPhZ8djux/0s/V79LP7t9VD27v/V/6MDUgMZDm8O0C8FMoAuwzHQ/RQAjtqJ2mnf09wp+174PgKvAcTp5eqX8fbycBe9FwYQzQ22+uL3PxKBEgMk6Cb7FakYfAzaDYb+7P0B6OXlGeMA4jTiB+OO4H7h1PKb8rQAE/8Q/tX7PA7dDXYhsiPZDdYPEfa09f4EpAMXDvMMyupC6WzVntQr+aH6chP2FIf63vkl+DP4LxxRHmwWIhcl/Uz83gknCpwNhQ0T+6H5DvCX79rc8dyx3MzbdwTGA0EF8QSQ3mHe//S89pEnhSqKGQgb2fpj+8MFOQYdDmENW/kv+Kvrkesg8ffwrfAJ7xvu4utmCW0IUTUXN4gvKDP0+/n+aOkZ63f0DPRP9z70igFK/7UD0gTN8uz0d/rG+9gXOBliGCQYAQp0B20WxRU+FIcW1Oaf50HTn9IV9Kf0bQvfCuMHowUZE6UUASQiKW4YyhpfDaAMURXWFB4JaweF6gLnWujg5nnz4PRY6Fzpzezo7EgQYRD+G3IckQrgCzcHqgg6EBIRyAtxDY8EQwaDB9YF0/u8+NHcedz+2c7ZewhDBj0paClwDlIR+/lv+nYamBksJTInPvfv+dXemd+T8nvzzfnQ+lTrY+rD5aDjkPsL+oMaHRq7FrIXkgJuBDEWXRc+MhAzBBH9ETjca9tU4ljgvfS/9A/cPt3p38Pf9CbgJwBIYkujDdYP7uph6xMQXRGgEDEQ0tb+0iDAn70v5Z7lGhb8FbkjGCQYAacERu4H8g8NjQ1VCmgJ/ORe5Qj2D/dYIc0hlSjsKV8OKxAY6s7pI+b65Pv9X/2d/Ar7uPHp8OMGCQkRF6IY2AI3AvjyafQ6AlgFKhzkHIQV6hV56tXsmuUs5uwIKQYG9/T0dsqHyhHqsemmKTIpvSkCLE8LSw4BAeoAJPjy9tLleeYJ1cvUzd6x3AAN2A0ZKVwsZhCKECoBJwBOHHIeAhu8G1vzoO+R8dbvxQMrBfLpU+jn0dvOEfpx+/go0ioSF7UUL/gF9+8IYwy5HaIfHxQIElsNbgyVAdYBhtUr0lrHVMKR+Ff3ERoqG4YR4xC3DgcNvw/QDw4HkwgoAyMDDflY9hbnUuUS6xHshvvj+jUCQP62Bw8GexAhE24cDB7GHYYbF/0t+hzbmdrN6W/q2wXdA0EChP08/DP7wf35AvX2J/rnATX9gB/rGtIfpyP5AOUG1fFh8CPuQ+iL3lLcxOlz6xIIEAi0+an1b+p952MT4BYAKEgt4go8CWUPQwmjJxAn4guXEcjr5O68/w/9DAyHCDDrsekF4czg5wTrBSUU0BS49ObyP9lA14nwx/HHHDgeoh1iGyP9pfv39bv5sAXiCdf/Hf5R7jDp3Pzy+m0bhx6nE3oXuPT59Pj1P/NCBUgDzf4E/6Hroeuq5Mzi/AQvBCEl8CZAFYEX3QSHBh0HIgf2AG7+PAFyAI/+lQE75aTlb+Ku3Zb9QvvJ9dD3gONV4l8PIgvhNWA3dwoNEXvjTeVJ/BL3fgm9BILx9/EF4B/iV+Aj4NT0EvTbEu8SKxxUGu8Ljwhy+8j7ZgQOCUYauhu8GN8TUfn29F/eMd8j5zvprv4k/2b7tvt55bvkk+9w7KAXRhadHeYgBgEXBNv+ff3cEwUR6wooCmrvbe+u+Ar4SRNSExMEJQUp2uDZatJ4z9v06/H/D0oQIg7XEFIHNQlnBbEFHAL2ARADKgLgC1oJ6AtnCa/+Sv5z80b0u+jn5xrlCOIx+Yb2XAqHCXL+sP7995H4swjLCfALggz6CBcIFxkOF40TQBFF9Q30/PSq9SYBuAE75y/l/cbBwkTaDtZ4Cy0Jfx0RHrgGxgke8PrygPvc+3wXshUUF0UVovYC9nngvuA57VvtVwNmApAE/wHl/aj6RAmcB/oVzBbLD6URmg80EREUrBSP/pr9R+mj55Htk+zd843zV/fO9239j/5JAfcBegIzAlTz7PGu4C/eLvGW7ksFsANb8hrybvHB8t0jfyUhO4Y6CRUJE2jig+EYx6XG7Nv62hEM0gt8G1sbFROdEasSHBEH/AT8ic7IznLWFdXBFssUqSr+KXEBJQLJ6y3s2vvY+qUDLwIMAH3/xhCiEd4h+SN8DJAOKvCK78/7B/g1DQ4Ky+mZ6gS7QL1p2QjZLjDCLURU0lLhKKUptv5oAR7x6/Nd0YDQTcnHxPn/OPwtKsApeyhoKgQQ1hHS4JLf88R2wQ33LvbhQ4pGrEFqQ8IUrBSD+p76GdFB0ILGDMWm9bP13w7lDoYEPAKJ/m384hS6FsofiiN+9aP2JdRx0mHcxNmr9FLy0w/rD9UVGRneEIwUyRx2HlQr1isEG+AbKewf7afQMtGw15fXdOy46woQtg+5KYUq4hxjHiQC0gNr+bT66v9IAAoHEwc8C5sL8vfH9yLT4tHfzz/PdOyU7I4N/gwzH50etgj7CHDmFOZ35qjkewo2CUkUThSN5zjnJ+f+5sgl5ibkOhM8RhPRE0HojOjo4dPhCvjs9zwDjANo867z7PAc8X4ZkxqmKZkqXgTKAyftWuxZ70bvo+0X7fvomef37//u1wrKCkQb1BrVB0kGy/n1+HYGXAdHDeoNph1yHc0zEDUfFE8WwNU41tXDNcPl7fvuBQwgDsj2yvebBl0ItzpqPkUvDzK/+6r8tt8h4FLhWOGI8NnvNPR084jsRewP/Hn8DTBVMcdElUXQFBMU9+hA6I7gIeAz6ALmdPlh9pf5S/jQ35ffsMYnxQTk7OJ8KBMqvSUVJ8r8bPyuBVwGzfy7/jXSOdMM2tPa5BsHHmdPglJjPUpAOQYZCMX3wfhfHuYeRySbI5/rBelXyfPGrdQB1DXnbead+N72bQ6oDTwbiBt9+E736NfK1d73nPcBEmESyAkICXoL1ApdCVYJL/KD8VrZ2ddB1OjSiuwK7HsY7xjjNK816TEFMycoECrIFDAXR/TV9X3rnOz6AG0C9g/yEBP9rPzb29HaxdXR1KLuG+15EVAPGh9RHb4BQQBd3pncP+BS3vn5M/h9B+YFf/9//v/38veyADsBhh66HwY+2j+cMAkyEgBYAAHc69tdztXN19Nz0ojq7OigBOkDLQw8DOEBSwLLBvEHkB9VIeYrcy3zFsEXbeuE61rL9cq+zCzM3OVx5W8EhwQGJuMmEkRkRaFFkUZ2JaIlBfyS+2Ddf9xV0jfRod0A3RX3gvd2D+cQuRaHGE0KDAzD/k0ANv8VAEkETgRZBfgEjPnq+HPqp+nu7DvsKgOSAkIahRl/IiIikhfsF4H7uPvr9j33jBDoEQgDgQTc2a3aG9qA28339vnECpsMMg/vENkZTBzsKn8tlidVKWgRfhLP/of/5fO/85fifeEgyq3Ij8ZqxdHpIekyHhAepzoEO4czJTT2IHshiAVeBc3clNvnzUfM6umu6N4DAgOsAWwBp/uv/OcO+RDuL90x/DVEN90bBB2++L/5D9tH2yzWOdZB8h3zjRmqGmUqAisUFX0VmvH98S7q8+n/Ce0IoSIxIUsMwgrm6SXo9eP44XvuYeyF+db3aAQoA1AMEQs9CwMK4v9B/xv04/Ot8UzxY/dY9+/6Pfwa+jr8KAROBmIW4hhpHE4f2RXqF1EN3w0dBS4F6+sA7AvNcMwt5j3lMSfXJgo4ojcODxkOmN853jPJ1MeO0pPRVO7T7RQKKAr3GxgdghO2FYn0lvYU9af2uRxrHo0p7iqKDPQMRe1x7bbjQeRi6tHqB/IY8mf/2f+UC6oMggigCd4LAw0IH3UggCazJwoTYRPX9Qz12OMK4o7dINtb1DXRPM61ylPqd+cNFB8SFyBOHmMfZR47HaEdBw3TDe727fdD6V/rwunM7ATy6fR6BqAJ3Bu8H8sYDRx0GLEaZScPKYolFCaaEW0Qbv0T+zfuF+sx33vbC9VD0d7Yl9Xc7Cfqnw/NDQUlzCMaFgMVBvgl9/jmKebR6I3nNO+w7X3tYeyZ5c3kYO7b7XkV9xWZNhw4fz51QDw/yEFlMI4zIwpkDazm6+ng4BDkJvMD9jX+awA28onz8uI14yHoWOdo+rT4AAp2B2QXShThHlAb5BHLDd3sLOiNxoXBLr9nukXWUNL07FDq6/Y+9p79Df9CCt0M3SK9Jes04TcnIrEkIfCa8dnOCtDC5LDm5RIVFc80bzb+RPVGeiQvJuTjEORFzsfNPPFN8YAhxCEUOkQ6ljlqOqgnsShdB/sGj/Ty8njtO+v928PYntLtziLYAdXN3yndrOk+5wz2PvSq+HP3EOvb6U/xs/CUFRYW3Si4KXUkmSUMHAYelRGzE2UM/w1YDt4PggzmDbv+eP/T7N3s3tuw26fUJdSy7Ffs1wr4CicLiwtQAT8C9AZOCHMWGhc2GO4XDwPBAgjglt+7ycnIgeM240sQOxEhIdQh+B/rH9IVfhXJAtIBs/Wc8/z6fPgzDFkK5hCZDz0J/gdVCDUH2gMSA0zskesb2V3YJej359sO/Q/ZK+wtOCmPK5UTDhZt/NH+o+L941rca9y/9En04wjbB74IDgerBqIE9w3dC2wZNRemHD8aChGUDjP9xPoX5I/hYso4x33GCsNC1sTSs90z2tfa1tfL4yHiPgeJBpg0KzSKR1dHlx8ZH/3Nb8yGoMee3rBMsIPdcd7YGBIcMlI8WA102Xsie/9/mXAceHNWSFwVLVIwewi/CXXlKOV1xFLCG8f7w5XfJdzD41Pf8820yLe497Nhvmi6Y9+521MW6RPePII8hyPuI6n0KfXX6f3q9/NL9eX4SvlP9Ar02+2k7SXsAuzt8cDx4gZzB3UjXyU2NBk3rjIcNoAdECFp98X60tBg0667AL0qvWe9qs9az5bn/eYj/MD6nRaVFPM1bDO/PzA8di9pKncSuwwg76Lp+tL6zZzN1Mk84rLgZP+DAB4WXRmNMJM1WUy6Ul1QL1eYNac7yw53EyXwN/N14AnibNuD23TegN2i7ZTsY/16/GYESQNyE10SzSL+IW8WZRV68/7xq9IO0fHFN8QPz9jMkt/q3InoieXb5rXjXeMM4BTrmec+A+T/pRSpEQsDMQAo2rDXBMDTvg7Nuc2a9/D5rCzkMClYSF4JW6lhvj1gQ2Ij8CftEBUUewLWA/j4APnP8ljyh/K28dL6MPlMCMwFmA7QC8n9C/vh3i/cWNxm2o4AJwDxIHohBx5LHon+mf7g3PHcMcZ4xXjKIcnZ9zj3IiMZI10p/ihoEgsSA+HU4Jy2LLZywT7Bhfdg+BkiDiQuJfQnPhi6GzsMVA9eBoII2gVaB0v6+/oP8aPwH/1i/OAN8gz1Dg4NPwU/AkwAF/0L9rPyEOd+43fvn+xABYkDzA2VDPwHFwfq+Gb4/+za7Gzzm/PoCY0KLB5SH4YgACJmEecSof6p/y/31/fC9nn3APPb8370kfU1A9sEbheNGZshcyOkHvQfAxMHFGrxyvFkyvHJg8fgxtfgA+CP9wP2FP9I/fD5Pvgt9jH0VwAn/v8TTxJME9QRjPi29j3ikOBA1CDTes6ezcTghuBNBG0F6yVVKOE5RT3XPt5CMzmUPXcs4jAAHMAfVQ0VEOkB6APx723xSeDY4NDqy+rLCvcKDyOOI7chpiGGGxob9BqFGi/7y/kwx2nEG7M2sOi7hrljzUjLueqP6YsU7hS/OhE8LENVRDAsMy15CG8J3udB6I3dpN1T5BTl4eZV6KjtqO+cBWMI1yBzJPwp3S3NJNkoeCK7JkkdIiEuEQQUJwANAp3hIeIjxDzDncAEv3vW+dTt+cP4iyEsIe1BdUJNSDhJXC79Lr4ECAWI34/fPc45zjXWudb/7qTwHw0GENIleSlbMC80TSvfLlIZBBzTAjkEYvXf9cjr6Ouf24Pb5dS51OXjQORu/Ur++BDZEZ0WfBeLEYoSCATZBEf3ifdA+zL7AAcFB3oDcAPQ8a7xa+d9597xQfLXCDUJWxZeFv8PDBAn+sL6md2A3pDXx9j59yf6QhkFHDoamxywAo4EYuoB7DHmZefY+G75cxcKGB0tJC7pJtsn+RF2EnQGrQZfAoQC0P24/Qj/3f7VCEcJahCSESIHmAhV8q/zqOpI7D3x2PLe9vD3hPxN/dD8wv1e9Of0DvP28ur+ev7cCkoKoAmBCMwBZgBE/wX+n/pS+Xj16vMe+6f5zgCt/6r7wfox8rDxaO+D70H3yfetAFIBTgAbAan1sfa87vXvS/rU+7MQfhI+HRAfqRgqGhgMAg1JApoCw/3R/YX/pf9mDNEM8yS8JQU37jfVK0csawgTCKzlheRk1LnShdWv02Lg3N7R7t/tAf1b/EkFzAToAmEC6vlE+Xj45PfJA4kDeA/HD00OHA/sASkDT/fH+A32wPdQ+x/9OAQCBi8UJhYyIvUjOh4+H6ELsQth8Z/wW9dz1YnKoscVzfbJ4Nbn027hc95j9dPypRISEbAh7iAoIA4gTxsOHL4TGhWSCA0KTPya/azywfMT8kbz9PyV/vML1g1pIaojMTzzPoE99T/zHEweIfLS8iDNes1vvkG+s9Fp0df6GPuwFzYYShR1FDcC4gGo99X2S/3A+0IK8AcQCB0FXPAC7cTSXs+QwxjAnM1+ykbwYe4pF+kWJCsGLAovJjGKI6gm3gYJCkzuzfCE5Y7nQ+X/5h7reuwB/fn90RukHF811zWUNEU0uR1OHHAFRANM8qDvxOOb4JDfK9wj5Tji4+2M64n1nfNhAxsCGRjfF3cdoh1GE1QTRgoyCgX8ePuA5gPl6Nb31EzVsNMs4UnghvWx9aoOLRCiJjUptjOnNg8rvC0gDCsOyeg76vPV1NYd3YHdofYB93oQ9xArGzEbPRZGFUIMnwpx9eXylNbf0ifRTM2x46XgcvVK84UAYf/sCEAJNBJ3E6AYEhqTF+sYcwiwCX/zevQF7/nvVPkr+hEG5AblD+cQHRTkFKkUqxRlEjsSQwlICaf1KvV39MrzaA2DDWoMkwzS82XzJu3r7P/y8PIa+WH4MP/+/d4DsQJ1/sH8s+487NXjGuFo3p3bS99y3JrrKunM+hL5lQWwBBIM5wtGEbERYRU4FqISwBOgAacCuu167i3t4e1L+rH6SwZTBoILyAvfCmALhhK+Eswk4iQLK/IqwQ6kDT7j9uAq0ubPwdsa2u/ute0ABQgE0BJkEpwWBxfhFsgXXROlExsJlghL/Xj8lfHI79vldeIK5Wfhi+sA6ffyG/FBAq8AZxAeD94RIhEdEf8RQR0iIMspnSyIF04YW+6i7fTTgdLK1RLTnehN5bX7svlABJUDzARQBMcC9gH3/aT8B/hg9l7ywfAC8gTw1/2p+zgJAQi2B3MHHgWMBG0KDQrQESQSVBb2FQIZ7xdQFwwYkBH2FDQLPQ+8+0T90eOW4c7YOtWF5SzkcwDyAI4ZShooK8osWzSXNksoCil0/yb/CdIv0grGPsYZ3wnfDvun+y8DQgQcAzkEXg8FEIMiziCcIqEeNQu/CPXxlvLJ5IjmPuIE5knmxe1n7lj11fzL/RsOBgt8FZsTZxP2E0YQrBANDV8KrAe1AhH2VPSU1lHb/MbezRfZL96F88f48AYjDMoeyR6pMA4scSxlKhMbSB0gAmgCSunQ5K7p2+ahAsUIYRRoIegRyhzYBpELMwKtAp0F7gDR/EfyFuYL3SrhUOAL7iHyEe/78uzqJ++K9Yz62gQUCLYLNws5CJEFRf0q/M36n/vIBQAFUAfmBZf5y/uG97v7ewlIDHcWLRtYECUZYQKJCTf3sfZM9MvsIvqc8Nf52vJX7fvr0ukK74D2DwAp/4oI6vhy/g7sHOxN6HLkyPYF89oLGAgWGQUTdRysGA8SBxeNAUkLF/7ABM8EzQeJDWkQoRi2HOASJBZL+Of2CuqU5BLyLO1W/k77BQW6AuH6Hfzg6ZfvEfIO+NkG5QrBBd4HwfqG+Pb5TvS7/m36EwVYAh4I3gXmBMoGEgKrB/b7UQHT8735I/g//O79k/mG8/nqjeqt5eLwAO1m94z0gPnf/d8BOQmvC+MOfgpsDLADvgVPA08DjwaFB04JpAo5DxALNRG8CsoIPQcbBCsG9AY9CkIBGQfK9eP7RPh/+qkI+AaYEEwNoP/I/JvhLd7bz+HIcdU9zpvvzu9HELsV8B/lI0Qbwx7qEeQVYQZ/BeT2cvEg7BrnvuqZ5s/xk+9I+4n9gwDFA/sKPQzwG9odZhv6HS8IAAn2+zP74Pje9Wry/+2b6qTp6uiX6oP0hPJdCjIHaxcYGjgU/RmfC/gNdAN5A6L7cfuZ9gXz6Pa58In81vprAcUESAKWA7kGyQWOEYkUcxe+HBwM4gxw83rwxeUC5Zfx1/JEBJwDIgsjCSMK/AmMCRALOQurC/IEgQPy7krtTd323Efiy+G287XxVAeAB0QTyRhxDDkSKQPUApsDgP9z/lX8ePf99qf4jfbQ9j/1SPi8+xAEcwm8CNQJVw1oDAQdCyAnGwkgev8AAP/mUuJA4NXbGu1c7G8ADP/MAE/8Af11/RQOhhY8G0IhlxE2EpkGRQm5AI4CJPa97gPsEuEw7ZLpLP6lAc8TShhYGOAbIw6rEYIJTgxoCmIKqgTRAu75svio8S3vH+x35VnqdOKv9DDxnAfdCrcPHRcnC74QzAZkB53/Sv639uH1uPfs9M33c/J38R/sv/ip88YFAgKMA7gFyAMlDHwQ6xcwEfkS/gJKAS35V/Z59VvwpfHt6HztweTD7t/rYf/TArkXdB3HHtUkGA67E136o/x79wH18wEq/HMJOAOQEB4OMh24HpMcPByWB8QENfQ99WHtBvOO8E72k/md/C35k/fU9VDw1QbgAf0VxhCwBmb+PfGk6zrpCuxW6VbwHfas+6wDKQfOAowElAcNBzsSGw9WC1IGqAbOAe0Sdw/XELIPiP6tAIX0JPfs7p7vXPA88+4BnAcCC7cLAgCj+fb5w/OQ/dn6tP6a+7gDX/6fCP0FLvszADXnUu6P55TnbPnT9KYJTwgKFBkW4RuHHr4bIB3yDTsKsvoa9E3zuvEC/AL/fgRtB7P+/gI98273dvfg9T0OWAmOGysZpApWCtnxEfOS7x/yB/yw+4wAe/xB+mL4ZPS39wz5av1zBN8D7wcGA30DDAJ9Af4ECf46/tnzEvAY7FHsRfFS9DMH1gaXHx4eIiBoIRUNnA8GAvgDJv+q/8r4zPf+9OL0R/ZZ97j4X/eq/nP6NwGU/iP6D/xW9x77Tf85ACsEUALU/b/7pe8j7Vfi3uAW427mQPer++YSrRFUIJccshP1ErL9xv0/9772YP0GAEwEpgo1EuIXEiECIzQZDRnX/vH/zey07Tzqreap8xDuEAUQBFsJHAyU93j4ZOpB6XPsDe2G7WzwHvF187P9jf3BBP0CPwRYApsCVAAg/ar7fgJiBHAaVh4/JOUm0BT6FiwIdwuRAYcErvda+Rj1z/Qm97HzzvGL7QPvtO2v91T4wAMYBNsLHwyICYMJCPyF+xzxFfJw8jL1+PgC+//5qfgD9LjuCezi5f/j0OGU5ZHnZQQNB8EzpDYiRZxJaS2GMdEOOxCS+Fr4F+RB46rd/ttI8dfv4gymDOwbwxvDHj0e0Rl0GlYOdhCkAXEEjfSN9v3k4+MM3r/Z4Oij5Bb7wPjJCpwKyheWGeYaGxzBCo8IHe8I7CjfA97P6Pno9Pu5/UIAPgPr++P6TQGm+2UJXwfOCWINBwztDSMTmRGqElATyQnVDEsCWwPx/J/7Vvm/+FABmQMfFBcYJxyIHb0MfAna8HXsXNaH01vJxsZV1CHSlO2b7boAEQIzDPsMMRO9E/IPwxC4CkkLqw5nDnEQNQ8uCAEH2P+ZACD/DwI3CzQPQSAOJEklcyfsEHYRp/6A/2L+KADAAl8DAQSHAmsFcgMNCFwHKAtGDLwHogk4+ET5weii6IXm1eUS7bzrjfXC8+j8r/tW/F/7j/Pu8Q7vLO0g90D2XwSSBBcG/gbw+yv9zfq4/DgGZghJCywM4A3bDNMX2hbcFD4VHQEWApr4Ufl//Vn9T/8o/gUArv5r/sn9tvae9mD3dvenBbcFfBEmEUwObw0d/ZX7je226+Tw++86AOIAuAs9DRASgBPBEv4T/AwyDp4JlgoPCzwLhAsJCzkM5guKDLMMggPLAxDy4vFT6N/nWO9D79v67/oo/nf9N/0V/Jf75Poj9CzzxOey5fHeItzv4oDgffbX9QcKmAt8DT0QOgsADhgRfxPHFiwYDxIZEgYG4ARJ+Yz3KPF978byBvIAAKcACA8UEUwQxBLgBKcGVvri+nTzofJh8Svvuvob+KYHeQXlCHQHIwGLACz9y/3//40BuQBrAsL5i/rj9Jr0hPrO+SIEZQPuDDwMQBObEhMQUw/wB1sHNAfMB0oIQgqRABUDJfcb+cT1hPZs+Z34jfo9+AL3rvPU8WLu1O4k7IPxHvDm+hT7AARlBZMENwbX/e/+TfdT9/H1v/Qw+hn4fgIaAH0KhwjPB6gGpvgh+KHv6+/v92X5HgQWBl0K+Qu9C5cMfQZJBv4A9/+6Bp8FcBLKEQoY8xfPFYoWDg+gEF4HiQnjAO4Caftc/ED3i/Z/82vxrvDd7W3xxO4j8grwHPE/7+rzYPJI9yD2MvRE88HwTfBV8nvygPbu9kb+m/71ByYINg4iDsQPqg/rDPMMOgldCTQKlwp5DCMNOAzzDBcLIwwiB3IISwGLAvz+AwDP/jH/4/9W/5MCPQGf/nr8yfT28Szxae5W80Dx2PV89JP6KPpG/qD+Af2W/dn6Ovs6+ez4L/nj9+3/IP7dCkUJPhFPEAoSLxLWERwTDxI6FIEQ/BIvDE4OfwflCCoClgJP+GP38OyV6mvqXufK8yLxDv5+/KT+Mf6D+eP5kPeF+MD5yvor/bD9s/5j/rH7dPrm9yP2pPkf+LUA/f89CrQK6hGWE5YRMRSjC64OiAenCh8HvgmuCksMdRAEEXMQ/g8xCRkIPQNVAoUCVAJdBPsEGAUsBm3/aQDW8i3zI+jD5+/nDOfD8H/vZPrH+HAAs/5IA+cBSgHEAJ77y/t3+UX6I/1R/hACTwOEBtoHwgk9CzEKmgssClELEQuiC0cKVwoXCPUH5AU/Bm0CZQPW/S3/4voR/Db6yfqA+VT5Qfd/9qrzkfJb7zvuue3B7JTzL/Ou/RH+twK4A2MCowPOA08FoQgzCggNgA5hD5oQZxCLERwQUxHjDD8OfQjdCeIGUwhJBr4HeQK5A/n98f7w+6L8+Po3+0/6B/qg+dn4PPci9qj0kvOn9N7zK/bJ9V/5SfmX/sv+iAC/APr79vsn99D2Zffz9sj6UPoL/5j+IAQFBCcJoQmwDOANoAw2Di0IiwmZA2QEjAK5As8BjgHr/37/ggBAACkDOwMLBB0EhwNkA2gCBgJF/8L+Bvt++g73kvan8w/zSvSU8wL7Wfr1AYgBpgRoBMIEzgTHAwUEIANuA58F9AXDCCEJtAbsBm3/XP9J+A34F/fd9u/8+vzVAgcDYgJvAsz+n/7i+5D7OPmv+Kb5/viE/wj/cAU5BaEFnQU4ACMATvn8+JT2//Xu+Er4Tfug+gz7dPp/+hL6EPvN+j/9BP0IAbsA+QOKA8ADSQPTAHoAeP5O/t7/AgDbAxoESwZ9BokFiwXoAuMC9AD9AFoBfwEqA04D8ATeBD0FAQXgAYwBtvxY/Mv6lPp8/Gv8uf+f/zgCFwI/APf/Xfv2+g/6r/nl+5T7jf0G/Yv/0/66/+7+q/zZ+4/65PmS+iv6FPut+jj95Pzx/qP+tvxZ/Mr5ZPl5+i/6sf6B/s0EyAQ7CWMJvQnvCY4HyAd8A5EDWf8l/yr+u/1o/gD+K/7F/Wb/Tv/WAOQA0P+8//L+if4d/5P+rv7+/QP/kf5YACEA6f/O/+3+vf4B/8H+lv5G/qj9U/1x/Tn9Cv7Z/fL/2f+RAogCdQNvA8QCtALbAckBtgCaAF3/KP80/vT9Kf3k/ED89ftJ+wb7zPp6+vv7svv0/bf9E//m/sj/o//j/9T/Df/9/ur/6v9MAnYCMQJZAqMAwgDkARQCmwPpA6UC2wJ/AakB0QH7ATMBTwFQ/0f/Y/0u/bP7QftK+9L65Px1/N79kP0y/eX8+Pyu/Ff9Af2g/Df8DvyX+1j9/fwj//j+YwBrAJ0BvwFmAp4CQwJcAt4B4gFMAj4CygPeA0wFfQUgBWgFgwOwAxYBCgF8/Rr9lfnf+G73jfax99/2Xvq5+QD+lf2s/0z/P//K/mD+zP2D/NL7YPqa+YX72Ppx/xD/CQPcAngFjgV0Bp4GLwVVBSYEOATqBPAELQUnBTIEDgR9A00DaAIrAsIAYQBSANj/GwGOAFkB0QARAZ4ADwC6/+X9hv3C/FH8nP4x/hwBsgABAYMA7P5C/oP9vvwW/kz9oP/c/oIAxP9pAMD/7/+C/1n/Ev9Z/hX+O/3P/BL9dvzQ/Sj9yf0T/SX9bPyr/vz95AFTAQcDdQJwAc8AGv+I/lL98/xf/Un9wf/5/zsCmAIKA00DKgIvAgEBswDVAWQB0gRvBH0GQAbDBaUF9wP1AzEBNAE+/jz+2/zE/HX8UvyD/G78+f0C/t3/8v/9APwAbwEzAXkAGwDH/mj+cv5B/qL/z/8AAsACKwV6BrUFJwc0AnADF//r/zX/yP/FACYBggGeAVgAJgD4/Z79cvsX+6/4RPhU9/32cfmB+fv7ZfyO+yP8s/pU+wr8h/wP/n3+N/+J/7f+2v73/PP8jPzL/K//VAA/BWMGAwq8C1ELYw0hCTcLrQWgB/cClwQxAlIDKQLyAtT/HwDb+ob6kfbV9Wn1mPQl9232cPn6+BP6AfoP+jL6zvo7+xX8vfyc/kv/sQJxA3QFUwZlBTYG2gSVBe4E2QXJBdYGqAcACQ4JrwoiB8kIrAL2A/r+IACX/Yb++vyH/VL8mfw2/DP86vt4+6n50fjq9s31mvZa9Y74nvc0+sb53/qt+gb8CfyL/dH9/P1L/nH+tv6bAB4B9AK0A1IENQX2BRkHxwbzB/0E9QXaAsIDgQJPA+gCpAPUA6wEIAUBBlsEBwWtAAoBjPyB/Iz6GPqG+w379/62/r0CvAIxBGEEEAJSAsv9tP1o+f74S/bJ9XL29fWA+kX6ef++/94CWgP8BGoF0AQyBd0BCAJg/0L/JP8S/zn/N//0/uj+wv6z/p/9cf1//A388/2J/VABGQGMA3EDZQNlA0kBXwEA/tT99Pp4+t75H/k2+1v6r/3O/Fr/tv4yALz/ngFMAY4DdgOQBGoEnQNOAy0BtwA8/qP9FP1k/Bf/pP7NAo8COgUSBWAFSAWhA5UDXAEjAd4AmABVAkMCpAOPA64DlAO9AqkCMgH+AJ8AXABNARkB9gC/ALr/Yv8v/9H+fP7//d79VP0A/5T+yf9r/2H+8v11/RP9bv0a/av8KvxJ/ez8xQC0AC0DQAOjAtYCxwEkAp0B4QFTAZIBzAEgAiEDggPCAiYDfwDeACcAgQCRAvsCsQMNBP4BEgIzAA8AY/9M//z+6/7a/8z/0QHzAXUCngIhAP//bfsN+133vvZm97v20vuU+6kBIwI+BvoGygeOCOwFpwbcAmQD9wA2AWIAtwD5AIABlQI3AywD1gPCAWsC2QAlAY8BdAF1AVMBqf+s/+r97v0+/Gf8GPqV+vn4afkn+h/61vyR/Lb/k//OAcsBUgKYAicCvwIHAr8C7gG1At4BogLCAVUC7ABAAY//EgAd/8n/twAkARQEbwQMB4wH9gY2B6sDXwPj/z7/Qv2l/EP72Pqd+YX5pPmx+Rb8FPzc/hD/vv8CALT/Uv9NAB//tACT/w0AcP/A/2D/EwABAC8AwQCNAIgBowGPAsUCcQP3A3kEYwXjBVkFIAY7Ax0E6wBNAeP+1v7/+6r7avmP+LX5d/jJ/GH8hgCdAfsCxQSIA6MEdAJMAhIAuv5K/Sj7qPxR+jb/tv0LAhwCbAK9A0QBlQLT/4IACP9j/9f/HQAuASIBYgFEAUoCqwL6BPoFngaOB+oFDQbyBEYEkQOnAvj/Xf8Z+9z6avdO95L1VfUY9UD0CPZO9Cj51vbR/dj76QDj/ywABwCa/cT9ivyC/K/9a/3U/zb/dAJkAYQFrwSQCOMItQoiDEIL3wzqCaYLXAdsCcEEGAYSA24CrgO/AWUHCwZEC1ILGAnDCQEAggC+9xz4u/d1+Gb/dACtB2gImgaNBjb4xvdT6YzoAutt6cf8DvrFD2INIRa1Fc0HxAjt6/HrD9sW2j3nvOeLCXwMqitdLhY1RzWlHPYa+fW4857dJ9vq2wPaneiY6B/6Kfx5CGUL5g/0EWsSmBJ2EgcSFhDEEDkI/whz+P/2CeaY4pXacNew3Nba8e4C7vMItAiyFcIVowvkC9n65vpt84nyofOh8RX2APSI+2D6wAMIBOANQBBlHdYh1y/iNKozbze9GiscJfJL8fXWbdX12B7ZQvR09hMZSxugMkE0sDPDNYQbnhzN8FHuAcnYxBnEZMKg4zfkhf/v/jD5nvXM2SbUP7xytlW4tLSF2eTZMhFDFmg+x0ZfSJxP2ir/K5n5Y/R03C3Wv+zL68YVGhzJLK42pyRnLW8WZhzNGMgbkCEcIRYaRRcBAlb/veou6VvdiNyV2w3b5ehu6Pr9D/6ABXUGL/cg95PmpuMq7NfnhAeMBOIdEh2ZFpwX2fig+37kU+go7L/vyAP7BVUVYRZhGIEZchLUE3YKswq1AkABofz7+gb67fnb99r5R/Ef9P/pIuty7Hbqu/xR+aEUOxKgJ68m4iV6JdIHxAba22PZUb/ou6/DR8EP4p/iwQgVDWArjDJsQjFJsEMXRr8qIyiWCN4Etvap9tX4xv27/bME9fqU/kvzSPCQ69zjK+cj4N3pk+YJ9kD2ZAmQC88VbBfdCAsHbObA4EbL3cT2zqLLXPIz9AUkOirERj9NFkRlRs4hsh8X+Qf2Zt6o3L/aUNqr6yHthwH7BasMCxOoDu4TmBOZFdcbGRpyF/USu/yJ9xPaCdYgx+rEJc0dzNfkpePR/5X9qQ+ZDUEQwBAACsANXgWBCj0EFwhFBw0I9gunCSIMhwi2CMoGFQxUDkAb8CG+LRA2+DSxOj8msyYoA7n+fdwi1nTIZ8OJ0JLNK+mz5vb8DvqQADH+6/jY973wRfDj7YXs+u857ZbyDO9a8g7vpvI08Ef6uPlSCqUM/BpzH7AiPyYFHgUfdROOExULtAwbBZ8H7/yx/Zz0I/Oz9BDzpwC4AHoQaRGoFnEWVwxECtP4S/bJ62Xqte3P7fr4vvmlAVsCHQHFAPD5u/cA9ULx3vm59tkGfgaSEEQTLA0SEZH+sQGt8Dryle7c7o75fvhsB8QEfAxjCOwGFwN3/x/+G/26/57+eATc/lgFN/sN/yr2F/Xd9UHwy/2M9kQIQwPNCnMKFQLSBS72Pvty8qr1bflS+UkDvgCDB7cElgRHA2/+kP4Q+Vf5AveA9i75JPg4/pH9DAI9ArcBbQLNAHQBkwXlBSMOUw76EKUR+wnRC8P/vwJG/P3+igIfA6sLjAm9DqYLpAoeCR4ENgUr/osASPnB+k/2CvYp9u/0PPcP9sH1gvRx8SjvAPF27df4SPUWAjUAVwL+AuX4RvsR72nxS+4F76X2KvW9ACP+tgjJBlsPgA+9EqYUGg9+EWsGiwh6/7cBCv61APP/WwKMAYUCOgOCAhEHkQVCCggJagfmBnX/1/8R+oj7I/xb/qABYQMhAy4DNf9e/Yn6z/fB+C72FfkP98H4XveX9/z2zfgp+Uv9bv4WAYUCKgJHAzkDlwPPBDUEPQQHA9kB+QBTAZ0B/QM3BYgGrwdABaYFwACkABn9F/0N/CX82vt5+076Fvl/94v1Kvb/8474ovZ+/ET7Yf/t/kEBVwHhAdMB0/9k/8/8X/xX/Hn8tP9tADcGEwceDcsN/Q+cEOkMdw02BngGTAAoAJX+c/46AbgBKAVBBrcG1AdKBOAEAv/u/k/6u/ly+WD4nfsQ+nn9wPul/Df7z/n2+EX44vdf+mT6cP7d/rcAiwEnAPYA7/40/5P/Pf/9Am0Cjgc+B4AJawkTBv8FQv8x/y36hfoG+v36/v1Q/8oCEAQVBfUF9gNeBFkB/gC2/o/9+/xs+9r9svyEAFkAiQEyAjcAOgFF/3IA5P8OAYkAXAH9/wcA7v0b/br7h/qt+4/6Cv47/R0BogAYAyYDGwPkA6wBHgPIAIAC9gGiA9UERQbJBqwHkASBBAH/9P29+1D62f0B/YMCtgKZBbkGyARVBlf/yADz98f4k/OO89T0D/Ry+lT56wDM//sD8ALfAeYArv30/Dr7DvuU+yb8Gf5s//sBzwNgBV0HeQYHCJAFWwapBLIEuARqBPsEvgQ5BV0FBwa9Bn4GuAfRBDEGzgDRAWv8tPzk+Yj5P/pt+cH7nvqw+0v6Lfq5+Hz5Pvg5+l/5Nvu4+nz8Y/zx/kD/yQFxAjAD2gMcA4ID2wL9ArcCqwKCAnECGQMSA2wElwRyBc0FTAXXBaoDGARKAGsArvx0/Nj6VfqK+tn5pvrU+fH6EfrD++z69/xH/H7+8v35/7j/AAHsADoBZwEYAVoBEgFlAXUB1wF9AvICaAQJBSgH+gecCaYKNgpJCz0IMQmMBDMF/wBXAZL+pf7K/KT8NvvR+gH6dPnZ+Bb4rPfH9pH3h/ak+Iz3eflt+IP5lfhR+X74/fhM+J75CvmV/Df8kACHAP0COAMiBLgE3QXJBvwHPwldCdIKYgnPCowHygiHBHwFmQJgAxQDvgO5BFEFLwWaBW0DkwMJAM//9ftS+3f4efdV9yn2n/h496v5mvjw+MP32Pej9sz3lPZ3+ID3L/qM+Tr9Bv1DAY8BjwVRBrMIwAmsCbAKPgkpCnMJYApiCmoLTApjC1sIUQnVBZgGvgNQBBMBLwFV/er8vvrQ+Xz6WPmQ+mX5Mfnl96H2K/VG9KfyDfNj8Ubzn/Ey9arzsvmG+OT/RP+LBHoEuAXmBUkEkwTDAf8Bxv8PAOr/SwA2AtkCjQV4BisJYQoJDFENogzFDc8KrAtFB8MHmQLLAvz96v1B+xX7Hvvt+n78Pfy//WL9U/7M/W7+0/1C/qv9EP6Q/Qz+tv3U/Zf9vvyF/Dv75PrN+l/6SPzh+1n/G/8BAxMD/gVTBs8GVQcFBXwFggHKAd397v0T/BD8Qv1A/VAAbQATA0MDiATHBEoElQRaAooCMwBQAJz/pf/B/7r/1/6+/vz8rvzt+4D7wPxJ/Oz+jv6TAFAAJADS/6r9Rf1E+8L69vqE+sT8Zvzi/qL+tACMAFYCWQINAxoDWgJ4AsYB2QFNAogCFQN4A3ED7wNwA+0DYwPEA2IDqwOJA7QDWwNxA84C0wJJAkcCgQF6Adv/rv+M/SX9Yvu5+lv6gvni+gL6mvzH+17+tP1i/9H+Lf+u/gv+hf3e/FP8bPzi+w39mvzB/nv+BQHxAP8CDgNPBHkE+AQrBcMEAQW7A+4DUgKCAh0BPwE8AFUAb/9h/+D+qv5M//7+XAAGAOMAmQB9ADUAv/+F//P+u/4Y/tz9W/0H/Vr9AP20/mT+pgB6AL0BqwHkAfEBqwHCAbQA0gBA/0v/lf6X/hb/Ff9LAEwAewF0AcMBuQH+AO4AMgAeANL/u/9+/2L/gf9u/xoAAwDk/8z/Zf45/jn9/vyY/V79cf5J/sz+vf5N/1//vwD+AFoCvwITA4gDlQL8AnEBuAF0AKIA3f/1/6b/sv8CABcA4AD6ANcA/wAZ/zb/1vzi/N/72PvQ/NH8+v4J/+EAAAFhAYEBiACmAE7/Xv9g/mf+/v33/Sf+KP4I/yD/xQDqAG8CrgIJA0oD0wIVAwoCPAJGAGgAP/5Z/lX9Yf22/b792f7s/kkAYQBhAXkBLQEzAYn/jv+j/Zr9q/ya/Av9CP1k/nf+6f8OAM4A/ABxAaYBgAK3AmQDnQPWAggDKgFRAeX/DwCa/8L/tP/f//D/FwBcAHYA1wD2AAcBIQHUAOwAtQDOAA4BJwEwAVYBOABLADv+Of56/GH8Qvwg/N39x/2TAI8A/wIFA7EDxQM/AkcCZv9e/xz9Dv0J/ff8gP6H/rf/xf/3/w8AEQAeAKYAuADyAQoCeAOPA8QD1QMkAjYCa/9y/6n8mfxM+0P7IP0n/XEBmQG2BPUEFgVlBRIEVgT/AjYD4gESAqkAywCY/6n/sv68/hj+Lf6r/sP+vADWAE0DawNcBIME7QILA/v/CQC3/bf9g/2P/cL+z/6M/47/DP/6/nX+YP4Z/wH/9ADqAEkDXwPTBO8E3QMLBIkAjAD1/Or8kPtt+yj9Ff12AHYA7gL6AtsC9gLwAPMAaf5R/nH8PPwH/M771PyU/In9Wv0F/tv9z/66/o//gf/y//D/KQAkABMAHgAtAEUAuwDZACYBTgGWAdEBsALuAnYDsAMNA0UDsQLlAvUCJAMiA1gDYQOUA74D8QM4A1sDJgE6AWz+X/5f/D78KPz5+1z9Kv0//gv+Sf4W/gX+yv2A/UD92fyc/KP8aPwL/dj8w/2g/RH/Bf8CAQoB5gICA68DzgPmAgsDiwGeAWIAaQBo/2r/GP8S/4n/gf/v/+f/KAAiAKIAmADIALYA6f/Y/6r+kv5l/T/9Svwm/DT8D/xF/SX9rf6R/uj/3f+pAKcAgACCAA4AFABEAFcADgErAbUB2gEgAkkC5wIbAy4EaQTYBBwF7AMTBBsCSQKoAK8ACf8W/2b9Uf0C/en8R/4n/m3/VP8n/w3/Nf4M/hP+5P2g/oD+rP6P/uj9zf2w/ZD9pf6N/p7/jf+7/6T/Of8e/w//8v5X/1X/4P/b/w0ADwAQABYAKwA3AGQAbgCtALYADQESAUUBVQEaAScBvQDLAIYAiQCLAI4AagBjAKL/jv+D/m7+Wv5C/hT///52/2X/KP8Z/7/+ov6S/nD+6v7I/sv/qf9vAEIAFQDx/43/X/8E/97+Pv4N/pb9av0j/vr9lv94/94AzwB5AWsBxgHDAUQCPwJjAmQCogGfAeAA0wD+APEAigGFAd4B3gEJAgMCzwHDAeEA1wCb/4P/Qv4U/kr9Df30/Lf8B/3M/D79B/0a/uT9fv9a/2YAUwBZADoAbf9Q/+P+xf7P/8H/eAFwASICLAIgAisCGgIpAnYBeAEuADIAxv/I/5YAmwCuAbgBCAIgAoUBjQFCAD0AFf/1/nT+V/7Q/qP+kv9t/6n/g/8G/+L+kP5s/jT+B/6S/Wz9gP1h/Yf+df4aABcAjgGpAZsCtAKhAsECJAI4AgMCKQI6Ak4C0gH3ATEBVwFKAW4B2gEEAisCVAI4AlkCAgIOAigBNgFLAFMA9P/x/0X/MP+0/Z79w/yo/Az95vwD/u39xv/A/6kBrwHWAd0BFwAWAIz+h/40/hz+jP6E/lH/Uv9UAGAADQEaAUwBXgGQAaIB+wEHAjUCQgIDAgwCNgE8AbX/p//S/bn9xfyc/CP99vxq/kv+n/+G/zEAKQBzAG4AwwDLAOgA7wCfAKoAPgBAAC8ANQBbAG4AGAEvAQ8CMALUAvUCRwN1AxsDQAOeAboBzv/0/4//ov89AGIAoACzAFsAbwCX/4z/fv5u/kz+QP58/3D/fgCAACwAKQCl/qb+Qf02/Sv9I/2F/on+QgBUAG0BjAGNAa4BwQDkAPP/CQDC/9j/DAAjAJ4AxgBRAXoBgQGtASwBVQGrAM4Asv/D/0v+Vf5t/W39XP1a/Zb9nf34/f/9jf6Z/in/Of9M/1r/8v4K/x3/Pf+PALMA9wEsAvUBKwL4ACUB9f8TAJv/vf9xAJ4A7wElAp0C3wI5AoICgwHPAdQADwFOAH0ARABwAJEArwCuAMkAnQCpAGAAZgDx//P/Vf9J/8z+y/7e/tL+Of9D/zr/Pf+5/sD+dP52/rb+uP4V/wz/0P67/vn92v2v/ZT9n/6N/u3/5//VAOQAhwGgAcEB4wFZAXkB5gALAQcBIwEgAToB4AD6AIEAjQA4ADgACwACAJv/iv/b/s3+h/55/tv+0v45/z3/Of8+/wT/C/+//rT+bf5f/qb+k/5h/0j/pv+M/zz/Kf/v/t/+K/8b/4n/j/8dACgAIgFHAaQCygL3AzQEewS1BJEDvgN+AZMBaP9o/0j+Ov4n/hT+jf5z/hr/DP+v/53/9P/l/8D/tP+J/3n/a/9U/9L+tP6u/Yr9wfyU/JL8XvxD/R791v66/m8AYQDyAPUAwADHANcA8QBNAWMBegGbAWUBiAFQAWsBCgEjAZMAogB/AIgAGgEZAZ0BnAFWAVYB0gDSAHIAXQDA/7T/pf6I/lf9Mf10/EH81Pyo/H3+XP4yAB8ABgH4ADEBJgHMAMEAFQAJAJP/h//G/8P/mQCcAKABtgFMAmACUAJnAuEB7AFoAW8BWwFfAZQBlQE8AT0BTABKAIj/d/8d/wj/vv6h/rH+jP7L/qH+p/6E/nz+W/5+/mP+u/6a/kb/M//u/9j/HgATACoAFQBCADUAQwA+ACgAIABPAE4AqgCnAOwA6wCnAKMA7v/d/5//kv9NAEMAAwEGAekA5gDq/+P/ev5i/nL9Uf2W/XD94f7A/rgAqABIAkUClgKeAqMBnwEsACkA/v7u/sX+uP6S/4b/bgBvAOIA6gDyAPkAegB7AOz/8P8bAA8AZgBgAFgAUABsAHEAuAC+AKUArABiAGUABwAEAED/Nv/Y/s/+c/9v/7oAwQDsAfsBRAJbAoMBiwFJAFAAhf+B/yn/IP8v/yv/h/+E/+D/3P9NAFAA7ADkAAwBAgFwAF4Anv+K/87+s/4L/vH92P3F/XP+Wf5X/0v/DQAFAK8AtABoAWoBEAIhAmsCfAIdAi4CMgE7ATsAQwDl/+r/DQAYAFQAVgCJAIwAhQCIAHAAbwCEAIEAegBwAC4ALwDz/+X/iP97/+7+1f7U/sX+Vf8//6//pP8eABwA6wDuAHkBiwF4AYEBOgFJAQsBGAHqAPQAkACgAO//8v+L/5j/6//p/1sAXQBSAEwA4f/V/0H/Nf8E//P+Tf9D/4//g/8d/w7/J/4X/kn9Mv1g/Vr9Bf///gQBFgEMAiACxgHkAeEA8gAXACsAEwAjAJ8AwAABAR0BzADtACQARACS/6v/dP+D/8X/1f9bAGwAygDeAC0ANAC4/rP+B/4C/oT+eP7o/ur+Df8O/5v/rv+IAJwAKAFRAWwBjQENASoBWQB4AOr/BwDk//v/GQAtAJQArgDaAO4ATgBeALr/xf9KAFUAIgEsAf8ADAH1//j/3P7Y/h3+E/7V/cb99f3e/VL+Rv7p/uD+ef98/6X/pP+6/8b///8KACEAMwArAEQA1ADyAJwBvAG5AdwBUAFvARMBKwESAS0BRQFbATkBSwFjAGwA8f7w/gT++/0Y/gP+2v7R/t7/1f8wACUAev9s/8X+s/4J///+kf+B/5n/jv+v/6f/BQD7/wMAAAD5//n/tAC4AKoBrQGzAb0B2ADhAAIAAADI/8r/IgAnAJ8AqADZAOIApAClAAEAAABV/0n/+/7n/uP+yv6m/o3+Vv47/m/+Vf7O/rb+Gv8L/zj/K/9u/1//1P/U/3YAfQD0AP8ABQEUAeYA7wC1AMMARgBKAOL/6P8wADgA/AALAZQBtAHeAfMBwQHiAUUBVAGoALcAJAAkANT/yv+5/6//hP90//3+5f65/qP++v7a/iT/Df8o/w3/Cv/w/sj+tv6o/pn++P7y/lf/Sv99/3n/0f/M/1IAUgAAAQEBvQHNAU0CYgIpAj0CWAFvAWoAeQAAABQAGwAhAEQAVQChAKsAGwEtASYBLgGbAKQA4//f/yn/If+L/n/+Yf5R/qP+nf5d/1T/MwA0AIcAigB2AHYAZABiAA4ACQCK/4P/gP9+/9T/zv/1//f/LgA1AJAAkgDUAOEAPQFJAY8BlgEwATkBpwClAGEAYAAQAAkAoP+Q/1v/Tv8+/yf/Lf8h/27/X//g/9n/TQBGAGMAYADS/8f/Gf8L//L+3/4h/xH/P/8u/37/e/8DAPn/bAB0AK8AtwD+AA0BRwFXAWABfQE3AU0ByQDeAFkAZgBKAFkAlwCdAM8A1QDtAPMA7gDwAHUAfADw/+3/BQAFAGYAYgAtADAAf/94/xb/DP9m/13/RQBBALUArgABAPP//f7r/sD+r/5C/zb/8f/p/4AAgADCAMoAtQC7AGoAdgAeACAAHgAkAFMAVAAsACwA5v/p/+n/3v/N/8X/iv+B/6L/nv8aABkAewCCAKwAvgCBAIwA5//0/4n/lP/K/9P/UwBkAM0A2AAAARMBzADVAGoAeABKAFEAZgBxAJkApQCVAKUANgA/AKX/sv9u/3D/h/+O/8j/y/8ZABcALQAtAP////+W/47/Iv8Z/9/+0v4f/xj/dv9z/7f/uf8hACcA7gD5AGABbwE+AUoBsACyAP7/+/9a/1T/6v7e/qj+n/6//rL+X/9f/yAAHwCEAIUAewB/AFIAVAAFAAUAnf+d/1H/UP9V/1j/dv9y/5j/of8mACkAGQEpAbEBxAGkAbkBNgFMAZwApwDz/wEAd/97/yf/K/9M/0v/6//u/38AgwCUAJQAaQBsAA8ABQBQ/0z/v/6y/pz+jv6z/qX+8f7m/lr/Tv+1/6r/BQD9/zoANwALAAcAvv+3/7P/sf/l/+f/CwALAA8AEwApACMAbgBvAGcAYgDU/8r/gP9x/9n/zf8yAC0ARwBEADwANwASABQA+P/3//b/8f/C/7H/fP9s/4T/cv+D/3D/VP9G/5X/hv8vACkAjwCGAHAAbgApACgAIAAlAEwATAAuADYALgApAGcAZQB3AHYAJwAmABIAGQBxAHcAfwCJAPb/9f9E/zj/5f7O/uT+1P4q/xz/uf+u/0IARABPAEoAuv+7/zb/L/9O/0f/6f/p/5QAlQCtALIAPQBDAOv/6//3/wMAWQBlALgAzQDYAPMAwQDYAKEAsQB0AHgAMgAlAAQA9/8JAPv/JwAjAEkATQB4AIMAeQCLAFEAWAAdAC4AMAAxAG8AdQBlAGkAwv/A//X+9f7Q/s/+cP94/1cAZADgAPQA+QANAZYAoADW/9r/Qf8y/xr/Bf8b///++P7h/vb+3f5H/z//+//1/98A5gB+AY0BfwGSAfQACgE7AEcAqf+z/5b/kv/S/9P/JwAiAH0AigDHANYAwwDeAIoAmAAPAB8Adv9u/wH/+f4q/xb/of+V/+//4P/t/+b/2P/I/+3/6P8jABwAVQBdAIYAnACUALAAcwCXAGIAeABoAHcAOQA6AOD/3v/V/9f/JgA1AKwAwwD8ABgB0gDgAFYAXwDR/8T/df9o/3H/Yf99/2n/bP9h/3H/Xv9+/3j/e/91/6P/rP9AAFIAuADYAKkAxgBlAHwAKAA1ANL/0v+z/7T/CwAJAH8AiwCsAL0AnACwAI4ApgCdAK4AxQDTAOIA5QCMAIMAsf+k/wH/5/7W/sL+Kv8b/8b/xf9TAF8AewCTAHQAhABVAG0AOQA3ABMAGwDc/9P/Wf9Z//H+7/4G/wn/gf+D/18AZAA8AUUBSAFSAc8A2ACGAI8AbgBwADoAMwAAAPL/lf+E/2f/V//P/8z/ggCFAN0A6QDKANQANAA0AGD/XP/y/uT+CP/6/l//Wv/f/9j/JQAtAB0AHQAEAA4A+f/4/8j/zf+g/53/lP+Z/67/rP/E/8X/pv+c/43/hf/S/8T/GgAUABoADQAlACQAHAAXALr/wf+t/6P/GQAiAFsAUwAHAAcA0f/D/9j/1f/q/+L/1v/V/wEAAgBCAEYASwBTADAAMwBJAE8AegB+AIIAgACCAIIAWwBYAOz/4f9l/17/NP8f/1r/UP/p/97/ZgBiAHcAewBIAEwAEQAUAPz//f/y/+r/1f/J/4T/eP9h/1b/iv+F//X/9/90AHcAgwCJAAgABACd/5f/dP9s/3P/Zv+5/6//DgABAAUA+f+4/63/l/+L/8X/vP9EAEQArgCxAHoAgAAHAA0A0f/O/5z/nP+//67////9/wAA9P+//8D/1P/W/xgAHQBwAHQAtgC6AKoApwAfABwA0v/M/+j/4f8YABMARAA7AEcAQgANAAcA3//f/wMAAwBHAEoAWwBkABcAGgDp/+7/8P/w/wgACgAOAA0AHAAiACkAKgAgACQABgAIALn/uv+C/33/mP+W/7f/rv+6/7T/8f/l/ywAKAArACYAEAALACUAJQAhACUABAAJABoAHgBaAF4AhACJAIkAjwBZAGQAGwAcAPv/AwAFAAQA+f/6/9n/2f/K/8n/AwAEAF0AYACPAI4APwA6AMj/uv+g/5D/vf+t//D/5v8DAP7/JQAlAFUAWgCHAIwAcgB2ABMAFwCw/7H/qv+w//T/+P87AEEAQgBAAC0ALwAeABoALgAuAHsAgAC4AL0AZwBxALP/qf9V/0f/Yf9J/2n/T/+C/2n/1f/N/ygAJABZAGYAhQCSAHgAgwAPABoAxP/F/7P/uP+t/7H/rv+u/9H/1P/w//D/5P/m/9f/2f8dACUAoQCpAOsA+ADNAM0AMQAqAHv/Z/8s/xD/cP9Y/97/zf8yACoAcQB3AHkAfwBRAF0AUQBWAFQAWwBPAFcAPQBEAA0AGAAJABEARQBNAGAAaAAtAC4A8v/t//H/8v8MAP3/+P/1/+b/zv+0/6r/jv93/6f/mf8kAB0AegB3AEQAPgDm/+P/xv+3/6z/qf/M/7//MwA4AMEAxwDjAPgAcgCBANX/3v+e/6D/tP+u/7z/tP+U/4f/Qf83/xT/Cf89/zX/ov+c/+z/6f8HAAYA6P/n/6P/o/9f/1v/Xf9R/5//mf8OAAMAWwBhAKIApwDTAOoA4ADxALMAyACAAI4AMAA0ANv/3v/J/8X/x//J/9L/0v8PABYARwBUAEUAUQBcAGsAYQB0AOr/9v9l/2v/bP9u/8D/uf+//7f/kf+K/4L/f/+7/8H/FgAjADwASABcAGgAUwBYAPX/9/+q/6r/1//b/x0AKAAqADMAAwATAMb/zv+R/53/1v/b/08AXwCdAKoAjgCeAFgAZQDx//f/hf+H/23/Yv+c/5j/vP+0/6v/qf+//8H/DwAWAGYAbACDAIwAPABBAJj/of9c/1//2v/p/48AmQC2AMYAYABrAA0AGgARAB8ASQBXAGMAcAA8AEgA8f/4/7P/sv+q/6b/nf+T/5D/f//O/8b/KgAkAPn///+p/7H/CAAUAGsAegBkAHEANQA8AP7/AQDr/+3/MAAuAC0AOgDH/8f/jf+Y/+7/+f9sAHQAmwClAG8AawD4//D/lv+K/5P/gP/C/7X/AQD1/wMAAwDS/9X/sP+7/wcADgCjAK8AFAEXAb0AwQDT/8//Lf8v/zD/Lv/P/9f/xgDOAA4BGgFdAGEAw/+8/8T/v//a/8z/q/+d/3n/Yf9a/03/XP9M/3v/dP/t//D/3wDhAHwBlAEpAS4BQABLAJf/lP8f/yD/PP8w/xIAFgDlAOMA1ADdAFcAWAAnACoAVgBWAHsAeQBNAEQAzf+//0v/N/9L/zb/1f/F/0sAPwBIAEIASgBIAF0AYwAjACsAk/+R/2L/W//J/8H/IwAcAPH/7f/M/8b/NgA4AH8AgwAMAAkAt/+u/8T/t//c/8r/8//i//f/6v/Q/8T//v/0/20AYgA7ADgAtP+j/5n/l//B/7n/+v/6/2UAZQBnAGcA6//q/83/yf9AAEYApQClALwAxACaAJoA/f8CAHb/av+e/5b/BwD5/wIA8//s/93/CAABAO7/7P/A/77/MgAzAMwA0ACfAKAA5P/f/2b/Yv+J/4H/FwAZALAAtQCzAMEAOABIAMf/1v/F/83/8f/5/w4ABADl/+H/pP+S/2n/Y/+W/47/+/8AACYAKgAlACsATwBUACYAKQCz/6//xf/A/2gAaQCEAIoAIQAnABoAIwBVAGcARQBQAEQAUwC2AMAA1ADlACMAKwB4/3P/kv+M/+H/1P+H/3b/Av/3/jv/Nv8uADwAHgExATMBRAFTAFYAPv85/7P+lv4D//n+/P/v/4YAlwCdAK4AwwDgAL4A1AD//wcAsv+p/0MAPwBKAE0AZv9d/yv/K//f/9f/OAA0ABAABAAbABkAMwA1ACsANgBfAGgAXwBnAKD/mv/q/tf+Zv9S/w0ACwDM/83/l/+k/0QAWwDVAOkAhACTAAMA9/+8/7b/hf9q/1H/Qv9O/zj/kf+J/xAADgB2AH4AkACdAIYAkQBnAGgANgAtAMj/uv/6/uf+lP6K/nv/ev+UAKgAjgCfAAwAFAA/AEcAsQCyAJIAlgBXAFYADgARACH/I/8w/hv+k/6E/iEACQBGAUYBjQGWAfEADwH7/xUAaP91/1v/UP9J/yv/Rf8k/0j/O/95/4T/DgEtAV0DlQPsAhMDlP+U/1D9M/2u/ZH9rv6a/pb/kf+wAL0AggGYAaoBtgHBAMAAL/8f/7H+pf6b/6b/SQBZADgASQBZAFkADwAFAG3/Vf+o/5r/nQCrAPgAFgHBAOcAaQCGAKD/qP/T/r3+6f7E/uP/zf/+APwAhgGaAQIBIAGz/77/r/6u/r3+pf6d/4n/WwBMAHsAfwCPAJgA6AAAAd8A6wD6/wEASf8//5T/kv80AEAAcgB5AGMAcgCAAH0AkACOACwAHQBe/1P/LP8p/9z/6/+hALQAjACbANn/0v8P//j+vv6b/gP/5f6s/6D/SQBXALkA0gDeAP0AwADSAC4ALwB3/2r/RP8s/6//qP8iACQAXwBwAL4A0gDgAPgAlQCiAFEAVACNAJEAkwCRAP3/+f96/3D/d/9u/67/pP8MAAMAfwCCAKYArQBSAGEA2P/i/3f/fP9B/zb/ZP9a/6n/mP/S/9L/IAAnAI4AogD2AA4BCAEdAZAAnACt/7H/YP9X/9P/zP/8//X/lP+D/4T/fP/X/8v/7//v//z/9//0//n/u/+4/6T/n//H/7//2v/K//L/6v8bABIABQATAAUADgBbAHcAoACuAJkAqABzAHIADgAPAK7/pv/P/9D/RwBIAJMAlwBvAHIACQD//73/uP/y/+X/BAD+/+n/5f8NAAcAJwArAML/vP9Y/1T/cP9x//r//v+aAKcAxADUAEMAUACj/6n/iP+K/7//wP8VABYAWwBgAGUAagA8AEMAzv/O/2D/V/+Y/4n/8P/h/5f/iP9g/1T//P/+/4sAkgBrAHIASwBRADMAMwDG/8n/kv+Q/7//x/8fACoAXgBpAEQAUwD4//n/4f/r/yEAIABDAE0AYQBkAFIAWgAdABoA/v/4/xYACgAQAAMADgAGACIAIwA7AEIAOwBEAP3///+i/5z/jf+C/6v/n/+L/4T/oP+e/ygAMgB6AIcAJgArAMr/y/+b/4//f/90/43/gv/G/7r/DQARAEUAQQBFAEsA///5/6n/oP+U/5H/7P/k/zoAOwBEAEEADgAIAMT/vf+b/5T/w/+5/+z/7f/s/+v/CQAMAGAAaQBUAFUA5P/j/7b/sP/e/9f//f///x0AGQAVACAAJQApAGYAcQCOAJgAZQBoAD4AQwA4ADcAAQAFAKv/pv9t/2r/m/+V//n/9/87ADsARABLAEEARwAyADkABgALAMn/yP+H/4P/kf+P/wIA/v9ZAGYAYQBlAEoAXABQAFsALgA6AAAACQDo/+j/5v/q/wMABAAYABgAGQAbABgAFAATABYAAQD9//j//P/8//7/BAAKACsAMABoAG8AagBtABIAEgCz/7D/qP+k/8L/yP/p/+7/FgAgAHQAhQCvALUAkQCeAEMAPwDk/+D/p/+e/6H/m//L/8X/FQATAEgASAA8ADkAJwAkAA8ABQDs/+r/2P/R/8b/xv/C/8L/2P/Y/9z/3//m/+P/CwAMAEMARQAyADcAFQAbABkAJADu//f/yf/P/+n/6f8HAAUAAQD6/xYAEQASABAA8P/w//b/9f8LAAwA7P/l/9H/0P/j/9j/3v/g//7/9P8hACYAIAAiABEAEgAQABQACgAHAOf/6v/U/9b//P///y0AOgArAC4AIAAsADAAMQD//wYAsv+v/6j/pf/H/8n/3v/b/9P/1f/c/9r/+f/5/x8AHQAWABMA8P/t/wYAAQAQAA0A0//Q/4j/hP+M/4b/0//W/zkANgBoAHAAcwB3AHAAeQBsAHQADgATAKz/r/+a/5z/2v/d/w4AEAA8AEIAXgBjAGMAZwBIAE0ALQAqAOf/5/+r/6X/nf+V/7X/r//C/7n/xP+8/9v/0v8PAAkAJgAmAA4ACwD5//n/6//u/+L/3f/a/+D/5f/i//n/AQAxADEAgACNAJsApABtAHoAQwBLADAANgAtADEAEgARAO3/7v/w/+n/EwAUADQALQAMAAkA1v/M/7v/t//G/7z/4//g//H/6f/Y/9H/3P/X/+T/4//i/+H/7f/u/y4AOABZAGEAMQA+ACIALAASABsA8P/4//r///8zADgAQgBLABsAGwDp/+3/6f/o//P/8P/e/9b/3v/V/9n/0f/F/7j/uv+1/9j/yv/Z/9j/6P/e/+7/7v/4//b/5v/q/yQAKABcAGUASQBSADYAOwAwAD0AHwAnACEAKwBHAFIAbQB3AGgAbgA/AEUA///+/8//zP/Q/8n/4P/b/+n/4v/y/+z/6f/i/+T/2//y/+z//f/2/9//2f/k/97/+//5//H/9P8BAAEAHgAnAC8ANQAjAC4AIwApAB0AKAARABcAAAAHAPz/AgASABcAHwAjAAEAAgDc/93/7P/m//v/+v/1/+//6P/i/+H/3f/j/9j/1//S/9f/zf/Z/9T/+v/3/y8ALwBDAEcANgA6ABoAIAAQABIACwAVACcAKAA9AEoAQwBLAEUATABPAFsAMwA0APH/+//Z/9H/9P/5/wcAAADY/9b/z//H/+v/5v/e/9b/xf+7/8P/vP/N/8b/6//n/xEADQAXABcA+//5//H/8v8HAAcAFwAeADIANgBHAFIAVgBeAEoAVgAzADYAEQAaAAUABgAVABcAIQAkABgAGADq/+n/zf/I/9n/1P/o/+D/7P/o/xIABwAoACYADAAEANH/yv/a/9b/9//0/9v/1//z//b/MwA1AE0AVQA6AEAALQAwABEAGQDy//f/3v/g/+H/6v8EAAQAIwAqADUANwA1ADcAJQAkABAAEAD7//P/4f/e/9j/0//O/8X/3f/a//f/7f/0//L/+f/x/w0ADwAsACYAGwAkABQADQD9/wgA+//8/wAABgAdACMAPwBIAEIASQBFAFIARwBNACEAKwALABAABwALAAQACQD4//T/6v/p/wQAAAD6//j/4f/c/+n/4P/Z/9f/rf+h/4X/gv+x/6f/4//i//b/8v/n/+n////+/xcAIAAeACIAIgArAC8APAAoAC8AIQAwAC0AMQBDAE8AQgBJAC0AMgAdACMAKgAsABMAFADy/+//5//k//T/8P8EAPr/7//q/+z/4f/0/+//GwAXACAAGQACAAIAAQAAABAAEwAtAC8ANwA+AC8ANQAiACoAKgAwADIAQQAqAC4AHAAuAEEAPgAtAD0ADAAJAOj/6v/d/9n/1v/U/9P/z//O/8n/4f/a/+n/5//V/8v/0P/O//f/7//3//f/1v/Q/9j/1f/r/+z/AgACABQAGQBIAE0AdQB+AGMAZwAdACkAEQAPAAcAFAAOAAsACAARAB8AHgApADIAMwAvAC8ANgAUABEA4v/i//T/7/8NAA0A+P/v/+T/5f8BAPn/EAARAAkAAwDx//H/+P/1/w0ADwANAA8A1P/Q/7//wv/a/9X/2//h/9v/1f/0//z/GwAdABoAIgAIAAgABgALAOn/5v/O/9L/3v/W/+P/6P/p/+T/CQAKACIAIgAVABAA6//u/+f/2/8LAA4AHgAWAO//7f/f/9r/BgAFABMADgD9//7/EAALAC4AMAApACsA+v/7//v//P8PABEAAgACAO//7//k/+j/AAD+/yEAJAAxADMAEAASAO//7//2//T/7f/p/9//3f/w/+v/AwADAP7/+f8CAAAA9P/z/9L/zv/A/7z/2P/V//P/8P/m/+X/DAAJADkAPQA4ADgAEAAQAPr//f/v/+///v///xsAIAAhAB8ACAAMABoAGwAMAAsA1P/Y/9P/zf/7/wAAAwABAPf/9////wAAEgAPAPv/+//l/97/yv/M/8j/wv/l/+n/BAAAAAkADQARABIAIQAfABcAHQAJAAUA/P8AAP//AQAFAAYAIAAlADYAPABAAEEAOwBBADIAMAAUABgAAQD9//H/9P/t/+n/5//n//j/9P8RABAAEwAVAAoABwAKAAsAFAARAPP/9v/N/8j/0//W/woACQAFAAkA/P/9/ysAMgAyADYAEgAXACkALAAuADUADAANAPT/9P8HAAoAAwACAN//3f/7//n/FAAUAPz//P/+//n/9v/3/+T/3f/U/9L/6//m//T/8//u/+v/DQASAC8ALgAsADQANwA3ADAANwAYABsAEQAXAB0AHwARABkACQAHABQAGAAWABsACQAFAB0AIAAiACAAAAD///f/8//5//n/6P/i/9z/2f/8//j/EAAPAPL/7//5//f/GAAZABAAEgAJAAkAAgAFAPf/+//x//H//v8DAA8ADgALABIAAwACAPD/9//5//n//f/+/+b/6f/b/9b/7f/w//n/9v/x//H/8f/u/+7/7f/s/+j/7f/t//D/7P/z//L/GQAYAB8AHgAMAA4AFgATAEAARQA0ADQA+v/7/wkADAAiACMA/P8BAA4ADgAbACEABQAGAPD/8P8EAAkACgALAPP/9v8DAAMAFQAXAPj/+f/o/+P/9f/4//3/9//2//X/+v/5//7/+P/2//j/8P/p/+b/6f/8//P/EQAYAA4ACADy//b/9//2/woACwAlACoAOQA7AD8ARAAhACYACAAIAAsAEwAYABQABQAKAAsACAAYABkAFgAaACgAJQAhACUACwAIANr/2f/S/83/z//N/9v/1v/s/+v/DgAKAA0ADwATABEAFAAVAAMABwANAAkAAwAMAA0ACQD0//3/BQABAA4AEwAWABkACAAIAAAABAAMAA4AHQAgAA0ADwAAAP3/+f/9/wUA/f/////////9//j/9P/9/wEAHgAcACYAJwAJAAoA+f/3/+z/6//W/9X/3P/a/woADQAYABoA+v/7//7/AgAMAA8AFwAXABkAHwAQAA4A9//7//b/9P/4//3/8P/r/+z/8P8MAAoAEwAUAA0ADQALAAsA+f/3/9f/1f/C/7//1f/S/+P/3//w//T/BQD///7/BwAFAAIACQAMAAEAAwDp/+f/4//k//D/8f/3//X/DgARACoAKwAjACQAIwAjACgAKQAdABwA+//7/+7/6v/y/+7/8P/s/+T/4v/u/+j/EgAWAB0AGgAHAAcAAAD+/wUABAAAAAIA5f/j//b/+P8XABcAEAATACEAIQApAC8ADwARAP3//P8NAA8ACQAGAND/z/+3/7H/1f/R//f/8/8DAP3/+f/5//j/8/8BAP//EQAMAPf/9P/i/97/6v/n/w0ADwAdABwAGgAdAC0ALwAyADYAHAAgABoAHgAyADcAMgA1AB0AHwAJAAkACAALAAQAAgDy//P/AwD//xMAFwAIAAEA6P/o/+v/4//k/+P/3v/Y/9r/1f/o/+n/9P/y/wAAAgAFAAUA//8CAPb/9v8AAAUAGQAaABcAHAAFAA0A+f/7/wsAEQAvADQAJgAoAAgADgAgAB0AEAAWAOH/3v/Y/9X/9P/5/wEA+f/0//n/AgD6/wEAAgD2//X/BwAFAPj/+f/X/9X/6P/l/+//9f/q/+n/DAAQAEkATwBcAGEANwA8ADoAPwAdACMA3f/e/+f/7P/+////8//0/wMABgAiACIAHwAkAAMABQAMAAgA+/8AAND/yP/P/87/7//t//7/+v8RABIADgAMAAcACQAKAAcAGQAcABUAFQD3//n/8P/y/wQABgAQABAAAQAHAP7/+v8GAA8AKwAqACoAMQAfACAAKQAuAC8AMgAHAAYA6v/r//L/7//2//j/CgAHACMAIwAeAB8ACgAJAPz//P8IAAUABgAHAPv/+P/2//T/BAAEABoAGQAEAAYA+P/2/woACwAjACUABQAGAOj/6/8gAB4ANgBAAB0AFwD4////4f/e/9r/2//9//3/KQArACIAJQATABMAHgAgAAUABADr/+n/8//y////+//v//D/8//v//f//f////j/+f/8//3/+v/5//j/8P/y//b/8//0//j/AQADAA4ADAAGAAkA+v/7//D/7//5//3/DAALAAgADADt/+z/6f/q/+//7P/T/9X/0P/M/wYABwA2ADQAHwAiAO//6f/u//L/AgD6/+b/6P/x/+r/CgANAA0ACgAIAAoAEAAOAP3//v/0//H/BAADAAkACQD7//7/FwASACQALAAEAP//8v/2/wMAAAAKAAwAFQASAAwAEAAHAAIAAgAFAAgABADU/9L/z//M/wEA///5//j/7//q//f/+P/+//3/4P/e/9z/2f/1//H/5f/n/+P/3f8BAAMABwAHAPj/+P8GAAkADgAPAAoACQD6//v/AwACAAMAAwAMAAwACAAEAPr//P/s/+j/7v/v/wEA+v/8//7/BAD+/xIAFgAnACMABwAHAN//3f/j/9//5v/s/wEA+f8iACoANAAzACwAMQAoACkAFgAaAPL/8//e/9z/7//0/wAA/P8HAAsAEgARABoAGQAZABoACgAGANj/1v/H/8L/2f/Z//T/7//t/+3//v/6/w0ADAD7//7//v/5//n///////z/8P/1/+T/5P8KAA8ANQA4ABkAHAD9//7/EAASABIAFQD6//n/+f/8/wMAAgAOABAAIAAdACMAIgAGAAUACQAFABYAGAD5//X/5f/k//b/9P8HAAgAHwAeACIAJAAXABgADgAPACMAKAApAC4AEwAYAAgADQARABUAFwAXAAQACQD3//X/+/8AABsAHQAGAAkA8P/x//j/9//q/+v/3v/c//b/9P/8//v/6f/m/+r/5//t/+//6v/m/+b/6v8EAAMABwAJAAkADgAHAAUABAAIABcAFwAjACYAHgAjAB4AHwAjACgAGgAdAB4AJAA/AEEAHQAhAOP/4//V/9H/2f/b/+n/5P8BAAIAGgAbABYAGQATABAACAAOAAkAAgDq//H/9//w/wQACAAaABkAEQASABIAEQAgACIALAAvACkALgAZABsADwAPAAIABAAaABwAGAAYAAIABAD1//X//v/+//f//P/t/+r//P/9/xEAEgD8////AQABAAUABgD+//v/+//+/xMAEAARABYADwAQABIAEAANABAABgADAAQABAADAAUADQAKADEANAAzADQAFQAVAPb/9P/+//z/AQACAPv/+/8DAAMAAAAAAP7/AAASABUABgAHAPz/AAAPAAsAEAAZAPD/6f/K/8//9v/v//v//P8CAAMALQAuABwAHgD1//X////9/wgACQD4//P/5f/m/wIA/P8UABgAAgD+/wIAAQALAAoADAAPABMAEwADAAgA+v/1//P/9f/z/+//4//l/+D/4P/4//f/AgAGAAcABgD9/wEA5v/p/+v/5//6/wEADAAGAPn//P////v/FwAYABMAEgD4//f/BwAHAAwADgACAAEACQAJABkAFwAWABYABgAFAAIAAAD7//z/+P/1/w0ADQAZABsABQAGAPz/+//5//r/AAD///L/8P/3//n/BwAFAAsADQD9//v/7P/v//b/8f/9/wEACwAIABgAGgAdAB4AFgAXAAYABAD+/wIA9v/x//L/9f/v/+7//f/6/wUABwAGAAUA//8CAO//7P/o/+n/7f/r//H/8P/p/+r/8f/v/wgACAAHAAkA+v/2//z//P8LAA4AGAAXAAcACgD9//r//P/7/w8AEQAMAAsADQAIAAkADgASAA4A9//9//n/9/8DAAMAFQAYABoAGgAPAA8AEgASABkAGgD+////8f/w//T/8/8NAA8AEgASABEAFAAOAAwABgAHAPv/+v/w/+7/+//5/wgACgAQAA4ADwASAAwACwADAAMA9f/1/+b/6P/g/9z/3f/f/+3/6//8//3/8//0//D/8P8KAAwAEwAVAAIAAwDt/+3/+f/5/wEAAQD1//X//f/8/w4ADwACAAIABwAJABkAGAAVABYADgANABUAFQAaABwABAAAAPz/+v8XABgABAACAOz/7v8RAA4AKgAuABwAHQD7//r/6v/o/+v/6f8AAAEAHAAfAAUAAgDv/+//FwAaACIAIgD9////8P/t//r/+/8HAAkABAADAAAA/f/w//D/BQAEABgAHAD0//H/2f/c//b/7//8/wIADAAIABQAGAAUABMA5//o/93/2v8CAAYA9v/y//D/9P8SAA8AEwAYAAMAAgD5//v/BQAAAAgADQAUAA4ADgAWABsAFQAkACoAJQAiACAAIgAlACQAEwAUAAEAAQAGAAgAJAAlABkAHAAQABAAHAAiAAgAAwD2////AwD///7/AwDy//D//f/+/xMAFwAJAAgA8P/z//n/+P8EAAUA//8CAAAA/P/6//3/BAABABEAFAAUABIA+P/7//T/8P8SABYAHQAcAB4AIAAsACwAFwAYAP3//v8MAA4AFwAXAAYACAD///7/DAASABgAFgAEAAoACQAEAAkADwAKAAkA/f8AAAEA/f8HAAkAFQAUAAwACwAEAAcAEQALAB8AJgAbABUADgATAA4ABgAFAAsACgADAA0AEQAUABMADwANAPX/9f/n/+f//////wEABAD6//n/AwAEAAYACADw/+7/5v/p//L/8P/6//z//f/8/wEAAAD+/wIACgAIAAoADAD//wAA/v/7/wAABAAGAAEAAgADABUAEgAaABwADwAOAPX/9v////v/CwARAA8ADADy//X/4//d//b/+f8MAAoA9P/4/9v/1f/w//X/EwARAAoADwD9//z/AQD+/wcACgAJAAoACAAFAPj/+f8AAPz/BwALAAkACAAFAAYAFwAUABUAGQADAP//8//1/wEA/v8FAAUA9//3/+v/6P/6//3/FAASABEAEQAXABcAFgAXABAAEgAPAA0A/f/+//j/9P8IAAwAHgAcAAoACwAJAAkAFQAVAP7//v/p/+v//v/7/wQABwAEAAIAAwADAP7//f/2//b/9P/y//n//P/y/+//4f/j//D/7v/+//////8AAPT/8//x//H/8P/x//j/9v/9////7//t/+n/6P8WABgAIQAgAAAAAgADAAIAEQATAAAA///j/+P/+//4/wwADgDt/+z/+//5/xwAIAAHAAQA//8CABAADgAMAA4ACgALABIAEgAaABsAFQAUAAMAAwAAAAEABwAFAA8AEgAEAAMACgAMABAADgD//wMA8f/s//r///8JAAEA8v/4/wAA/P8NAA4ABwAJABEAEgALAA0A/P////n/9//7//7//f/9//z//f8FAAQA+f/7/wYABgAKAAsA9f/0//f/+f8IAAgABgAHAP7//f8HAAcAEwASAPj/+f/7//v/DwALAAgADAAJAAUAHQAgACAAIQAZABoADAAMABMAFAAXABcA/f/9//D/8f8EAAIABAAIAPb/9P/0//b/+v/6//j/+f/9//7/AwAFAPr/+P/q/+n/9//2/wYABgD5//j/+P/5/wQAAwATABYAFQATAAcACAD+//v///8BAPr/9//j/+X/5//f//D/9P8DAP//CwAOAA4ADgALAAwA/f////H/8P/u/+7/+//7//v/9//+/wEAEgAQABgAGwANAA8ADAAJAAcADAAOAAwACgANABQAEAAYABsAJAAgAA4AEQAJAAYAAgAAAAMABgARAA8AFgAbAA8ADgD3//f/AgAEABsAFwABAAYA///7/wsAEgAOAAoABAAIAAcABwAJAAoABgAJAA4ADQAGAAoAAwAAAPz/AQD+//n/+/8BAA8ACwAPABQAEQAPABQAFQAeAB8ADAAMAPz//f8KAAsA+f/6/+//7//4//j/AQAEAAAA/f/2//r//P/4//z/AgD6//T/9P/4/wYABAANABAAFAASAA4AEAARABEABwAHAPz//P/6//j/AQABAA8AEAAfACEAHAAdABsAGQAYABwAEgAQAAQABAD8//v/AQAAABAAEQAZABsA/f/7//n/+/8NAAwABgAJAOf/5//s/+n/9P/1/wEA//8FAAYADAALAAIAAQD7//r/BwAKAAMA///y//X//f/5/wIABAAAAPz/8f/0//b/7//w//X////6//f/+v/+//3/DgAPAAUACAD8//j/9f/6//7/+f/9/wEA+v/4/wAAAAD7//z/CgAKABQAFQAQABEADQAOAAkACAASABAAEAASABMADwAHAAsAFQATACAAIQAQAA0AAQAEABYAEQARABcABAD//wMABQAFAAMAAgACAP3//v8BAAAA8P/z//L/7/8CAAUABgAGAPv/+v/1//j/9P/w//L/+P/5//T/+/8AAP3/+P///wQABgAEAPn//P/0//L/AAABAAIAAQABAAIAAQAAAAoACwAEAAMA9//4//v/+P8FAAoAAAD6//n//f8OAAwABQAFAPj/+f////3/DwARAAoACgD///7/AgADABUAFgAPABAADwANAAsADQAGAAYADgANAAgACgAGAAMAAQACABAAEQAJAAgAAgAEAA8ADQAWABgADAAMAP3////5//f/7P/t//L/8P/+//3//v8BAAQAAgD5//n/8v/0//7/9//7/wEA/P/3//r//P8JAAcADQANAAAA/v/+//7/+//7/wUABQADAAQABgAFAAMABQANAAwADQAPAAkACQAJAAcACgAPAAUAAgAKAA4ABgAEAAMABwASABUAEgARAPX/9//v/+z/AQAFAAcABwD+//7/CAAHABwAHAALAA4ADwAOABIAEwD5//f//v/9////AQADAAEA/f/7/wsADAAVABQA+f/8//b/9P8CAAMABgAIAAgABwACAAMAAQACAA4ADAALABIACQAGAPb/+f8BAAEAEAARABUAGQATABIACQANAA0ACwALAAsA/f/+//f/8f8CAAkAHAAXABQAGgAPAAsACQANAAgAAwAJAA8AEgAMAAsAEAANAAoABwAIABIAEgAVABcADQAMAAoACgAWABgAFQAWAAsACwAUABYAIgAfABIAGQAHAAQACAAMAAkACQD///3/GgAeAB0AHwAHAAYACAAOABgAFAAJAAwA8f/y/////P8LAA8ABwAHAAEA//8KAA8AEQAKAAMACgAFAAIA/f////r/+f/5//r/9//0/+7/7//7//f/DAASABEADgD6//z//P/7/wMABwAAAAAA/P/+/wAAAAAJAAgACQAMAA0ADAD6//n/8//0/xcAGQAZABkA/v8BAP7/+v8RABUAEAAOAPf/+P/9//b/+v/+//T/8P/+/wEABgABAPf/+P8HAAQAIAAgAA8AEAD///r/AQAEABIADQD2//j//P/4/wUACAAHAAYACwANABEAEAD6//r/7//u//n/+v8BAAAA7P/r//H/8f8LAAoA+f/5/+7/7//7//f/+//9//r/9//9////BAACAAIAAwD8//j/BwAJAAEA/v/4//f/+f/3/wQAAQAFAAgACwAJAP7////4//b/+v/5//3/AAD4//f/+f/2/wgADAALAAcA9//8//j/9f/6//7/BgADAAAABwAIAAUAAQAFAP/////3//T/+v///wMA/v/5//z//f/4/wYACwAVABEACgAOAP///P/1//X/+v/6//z//P/8//v/8f/w//T/8f8CAAQABgAHAAEA///3//v/AAD9/wQABgAQABEABQADAPb/+f8FAAEAEgAYABYAEwD//wQAAAD8/wQACAAUABQAEwATAAAAAAD3//X/AgADAAUABgD8//r///8BAAoABwAOABIACgAIAAIAAQAGAAYAAgAAAAMABwD9//n//f8AAAIAAQAPABAADgAOAAEABAD6//n/+f/8//v/+P/6//7/DAAJAAAABQD5//T/9//5/wcACQAHAAYA+f/8//b/8v8CAAMABQAJAAIAAQD5//n/AgAEAAIAAAABAAIA+v/6//////8BAAEA/f/9//f/9//4//f/BAAFAAoACgAAAAEAAAD/////AAD///3/AQAFAP7/+/8AAAIAAAD//woACgAEAAYABAADAAkACgD9//3/+P/4//X/8//8//7/AAD//wkACQAJAAoA8v/w/+//7//8//7/AAD9//7///8GAAkADQAIAAYADAAHAAQACwAMAP3//f/5//j/AAAAAAgACgASABEAFAAWAA0ACgAHAAsACgAIAAMABgD7//j/AwAGABwAGwAFAAcA+//4/wkACwAGAAUAAQACAAMAAwAEAAMADgAOAAkACwAIAAYAEgAVABUAEgD2//r////8/w8AEwAGAAUA/f/8//r//P8OAAwADgASAPv/+P/5//b/AwAHAAoABgAAAAUA+v/0//b//P////j//P8EAP7/+v/+//7/AQACAAMAAAADAAYABAADAP/////6//r/AgAAAP7/AgAEAP7//f8CAAkABgABAAMACQAHAPf/+v////r//P8AAAUAAAD7//7/+P/3//j/+P/1//X/+//5/+3/7v/5//f/EgAWAAwACgD5//r/9//2/wIAAwADAAQA/v/9//7/AQANAAoADAAOAAQABAANAAoAAwAJAPr/9P/6/wEAAgD///z//f/7//r/AwADAA0ADwALAAoA/v////3//P/4//f//P/9/wcABwAHAAcAAAABAAAA/v8CAAQAEAAOAAkADAAEAAIABAAGAAMAAgD7//n/+v/9/wUAAQAAAAIA9//3//j/9P8BAAQA/f/6//z//f8FAAUABQACAPn/+/8GAAMAAgADAAQAAwADAAEACAAKAAAA/v/0//X/BgAEAAoACgACAAQABwADAAcACwAHAAMABQAIAAkABgADAAMA9v/3//3//P8GAAUA/v////f/8v/8/wEA+v/3//7///8EAAQAEAAOAAMABgDx/+7//f////7//f/r/+3/9v/z//3/AAD///3/BQAGAAcACQAGAAIA9f/3//X/9f8BAAAA8//3//z/9/8BAAYABwAFAAUABgD8///////5//r/AQAGAP//+P8AAP7/+P8FAAoABgAFAAYABgD//wIAAAD7/wIACAAJAAUABwAIAP3///8CAP7/EQAVAA0ADAD///v///8EAA8ACwADAAYAAQD+/wEAAgAZABYADwATAAwACQAXABkADgANAPD/8P8EAAIAAgAFAP3/+v/7//3/BwADAAMABgD4//T/+//+//z/+P/v//H/8f/u//T/9f/5//j/CAAGAAsADQANAAsABQAEAAwADgAGAAMA9P/3/woABwAPABIACgAIAAsADAAMAA4AEAAOAAUABwAFAAUAAgADAAQAAwD+/wIADAALAAgACQD//wAA/////wAAAAAEAAcAAQD//wgACQADAAMABgAGAA0ADQAVABgAEgAPAAQABQANAA0ACwANAA4ADAACAAUABQACAAgADAD///7/AwADAAwADAAFAAUA/P/+//3//f/+/wAAAgAAAAQABAAHAAoABQADAP3/AQAIAAcABQAGAP7/AQAEAAIABQAHAAwACQALAA8AFAANAAcADgAGAAEAAwAHAAsACAD//wEAAAD//wIABQAMAAsACAAIAAQAAgD6//3/BQACAAIABwD+//r//P/9/wYABwABAP//BgAJABEAEAAQAA8ABQAHAAkABwAPABMADwANAAsADQAIAAgAFQAVABIAEgAbABsAEQAQABEAEQANAA0ACAAJAP3/+f/9/wAA/P/8/wIA//8LABEAEQALAAgACgACAAQABgACAAMACAAJAAUABAAHAP///f/6//n/9f/3/wIAAAAJAAsABAACAPz////9//n/AQAEAPj/9v/s/+z/9v/3/wcABwD4//f/8//z//n/+f/6//n//v/+/wAAAAAAAP//BQAHAAYABAAEAAUACgAKAAMAAwD6//r/DAAMAA8AEAAHAAYAAAD//wEAAAAKAAwA//////v/+v/9////CwAIAAkADAAKAAgAAwAGAAMAAQD//wIAAgABAPv/+//2//b////+/wgACwD8//n/+//8//7//f/8//z/9f/2//7//P/4//r/8v/w/+z/7v8KAAUA+v////X/8f8DAAMA/v////z/+v/9////BgADAP//AQD///3/AwADAAUABQD7//n/AAACAAIAAAD8//3/+//7/wAA//8DAAUACgAHAAcACwAPAAoABAAIAAUA//8IAAwAAwACAP3/+//2//b/AQABAAAAAQAIAAkACwAKAAMABAAEAAIABQAHAAYABAD3//n/+v/5//n/+/8CAAEA+P/5//f/+P/8//n/BgAKAAMAAQAAAAIACgALAAsACQAAAAMABgADAAQACAAKAAcAAAAEAAIA///9//////8AAAgABgAEAAcACgAIAAsADQAQAA8ABgAIAAQAAwABAAIABAAEAAAA/f/8/wEAEwANAAYADgD+//f//v8DAAIAAAD//////P/8/wQAAwAMAA0A+//6//j/+v8AAP3//f///wAA/v8DAAMACQAKAAoACQAFAAYAAAAAAAEA//8FAAYABQAFAAEAAQAOAA8ADwAMAP7/AAD7//v/AgADAAQAAwD7//3/AQD8/xQAGwALAAQA9//8/wAA/f8BAAIA9//3//7//v8KAAoABwAIAAgABQD//wUABgACAP7/AwABAP//AwAFAAcABgAIAAgABQAGAAIAAAD+/wIA+f/2//v//v8BAAAAAgABAAMABQAUABEACAAMAP//+//8//7/AgADAP///P/6////AgD9/wcADAAQAAwABAAFAP////8GAAQACAALAA0ACgD//wIAAQD//wQAAgAFAAgACwAJAAsADQALAAkAAAAAAAcABgALAAwACQAIAP7//v/z//P/+P/3/wcABwD9//7/9//1/wAAAgADAAMA9//1//j/+v/7//r/AgADAP7//v8CAAMACAAIAAIAAQDw//D//v////7//P/7//3////8/wQABgADAAQACAAIAAMABQABAP7/CAALABMAEQABAAUAAQD+/wEABQALAAkACwANAA4ADgAMAAwACAAGABYAGAATABEAAgACAAkADQAHAAQAAgAEAAsADAANAA0ACwAMAP//AAAHAAYABAAGAPz/+v/9//3/+v/7//n/+f8AAAEA9v/2//b/9f/8//3/EAAPAAoADAD9//n//f8CAAAA/P/y//X/9//2//n/+P/5//n///8AAAkABQAFAAgABQACAPT/9v8GAAUA/P/9//b/9f/+/wAACwAKAAcACgAAAPv/AAAEAAkABwAIAAkABgAGAAgABwAEAAMACwAMABIAEQAKAAwABgADAAYACgALAAgABQAHAP///f8MAA0ADQAPAP3//P8EAAQA/v/9//7//v///wEA/P/7//r/+//y//L/CAAIAP//AADx//H/AAABAAYABgD7//7/9f/y//3/AQAAAP7/BQAFAP7//v8DAAUA/f/5//z/AQD4//X/+v/9/wEAAAAEAAQA/f/+//v/+/8EAAMACQAMAAYAAwD0//b/+f/6//7/+//5//z/+v/3//r//v8CAP3/BQAKAAIA/v/5//v/AgAAAAcACQAFAAEAAAAEAAYAAwD8//z//////wIAAAAEAAQA/f/+/wQAAQAIAAoABgADAP//AgAGAAYACQAIAAMABQACAAAABgAHAAYABgACAAEA+v/9/wgABgD//wIABQACAA0ADQAKAAwA/P/4////BQAHAAEA/v8GAPz/9f/6///////8/wQAAgADAAgABgABAPv//f8BAAIABwADAAUACwAJAAUACwAOAAwACwACAAMA9P/1/wkACAATABQAAgABAPz//f/9//3//v/8//3///8FAAMAEwAWAAwACAD6//7/DAAHAAYACwAKAAgA//8AAAEAAQAEAAMAFQAWABYAFQD8//7//P/5/xEAFAABAAAA+P/1/wAABQAHAAQA+//8//r/+//9//z/AQAEAPL/7//0//b/CgAJAAEAAAD6//7/CAAFAAIABAD4//r//f/4//n/AAD+//n/+f/8/wkACQAEAAQA/f/+/wQABgAHAAMA+/8AAPv/+P8AAAIACwAKAA0ADwAFAAMABQAIAAoABwAHAAgACAAIAAsACgAJAAwACQAIAA0ADgAPABEADAAJAAoADgAMAAgADQAQABAADQAFAAcABQADAAUABwAEAAIA/P/8//v/+//+//3//v////z/+/8IAAcAAAD//wAA//8IAAgAAQD+/wMABQD9//n/AQACAAQAAAADAAcACQAEAAMABgAOAAwACQAHAAAAAgAGAAMA//8BAAIAAQD6//r//v8AAAcAAwADAAcAAQD8//r//v8CAAEABgAFAAEAAwAFAAMABwAJAAoACgAIAAYABAAGAAMAAgAAAAAABAAHAAYAAwAFAAcAAAD+/wEAAwD9//3/+f/6//f/9f/6//3//f/7//v//P8AAAEAAAAAAPf/9v/4//z/+v/1//j//v/2//P/9//4///////3//f/9P/0//3//v8DAAMAAQAAAPr//P/+//3/BQAEAP3/AADw/+3/8f/0//3/+v8AAAIA/P/7//3//f/2//b/AwACAP3//v8BAAAA+v/5/wAAAgD5//f/AAADAAEA/v/x//L/+f/4//z///8IAAIA+////wcABQAEAAQAAQACAPb/9P/+//7/AwAEAAcABQACAAQAAwACAAkACAAHAAcAAwADAP3//f8CAAEA/////wQABAAFAAMABAAGAAMA//8CAAUA///8//z//P8DAAIAAgAAAAUACQAGAAMABAAGAAcABQAIAAoACAAGAAIABQAIAAUAAgADAAsACwAJAAgABAAEAPz//f8IAAUA/v8BAAIA/v8DAAgABwACAAQACAAFAAMA///+/wMABgAKAAcA//8DAAcAAwADAAUAAwAEAAIA/v8EAAoACAABAAEABgAIAAUAAQAGAAMA//8CAAUAAwACAP3//v8JAAoABAAFAP7//f/7//3/AwABAAQABQD3//n/+//6/wYABQAEAAcA+v/3//3/AQAPABAADwALAP7/BAAIAAUABgAJAAoACgD8//v/AAADAAIAAQAHAAkADAAKAPj/+f/2//b//////wUABgD+//z//v/+/wkACgAAAP///v8BAAYABAD5//n/+v/8/wIAAAAFAAcABwAEAAcACQAAAP///f/9/wkACAABAAEA/P/8/wAAAQAEAAIABQAHAAgABgAKAAsAAQADAAoABQD//wYABAD8//v/AwAFAP///f8AAAUABQAMAAoABgAIAAgABwAGAAcACwANAA0ADgAHAAUA//8CAAYAAwAMABIACQAFAAwADwAMAAoACwAMAAQAAwAFAAYABQADAPz/AAAMAAcABAAJAAUAAQD//wQACQAFAAUACwAAAPv//f8CAP3/+f8GAAkA///9//7///8HAAcAAAAAAAEA/v/8/wEABAD9//r/AgAGAP7/AgAHAPv/9//5//z/AwABAPv//P/4//j////7/wAABgAAAPz//f8AAP7/+//+///////+/wQAAgAEAAcABwAEAP3///8HAAcAAwACAAgACQD//wAAAwACAAYABgALAA0ACwAIAAMACAAHAAIABAAJAAYAAQAFAAkAAQD//wEAAwAEAAMA//8EAAkAAwD+/wcACgACAAAABgAJAAUAAQAEAAEAAAAAAAMAAwAAAPz/AQD7//b/+/8AAAMAAADy//P/9v/2//3//P/+//7//v/8//j/+f/+//3//P/7//r//P/4//b//f/+//3//f/7//r//P/+/wQAAQD9/wAA/P/5//n//P8EAP7/BAAJAAYAAQD//wMAAQD9/wIABQABAP7/AAAEAAYAAgAFAAgABwAFAP//AAD9//3/CAAIAAYABAADAAMABgAFAAYABwABAAEA/v/8//n/+f/4//n/+f/4/wMABQABAP7/9//5/wYABQAIAAgA/v/9//3//P/8//3//v/+//L/8/8AAP7/+v/7//3//f8CAAIADAAMAP3//v8BAAEAAgACAP3//f/5//r/+v/7/wcACAABAAEAAgABAAIABAAFAAQAAwADAAMABQAGAAMAAwAFAP7//P///wAAAwAFAAgABgAPABAADQALAAUABwAHAAUACAAMAAgABQD//wEABgAEAAMABAAFAAUAEQAQAAoADAD///3/BwAIAAcABwD8//z/AAADAAMAAgAIAAcA//8DAAcAAwAGAAkA/v/9/wUABQD/////AAABAP///f/9////+v/5/////P8DAAcABAABAPv//f/4//j/+v/4//f/+v8BAPz//P8DAAgAAQD9/wMABgACAP3//f8EAAYA///9//3//v/9//z/AgACAAcABgAIAAsADwANABAADwAKAA4ACAAEAPr//v/8//r/CgALABAADgAIAAkABQADAAoADAAMAAsABgAGAAcABgANAA0ABgAGAAIAAgAOAA0ABQAGAAIAAgAKAAkACQAJAAIAAwAAAP7/AQAFAAMA/v/6//3/AwD///v//v8DAAIABgAFAAMABQAGAAIA/f8AAAYAAwD+/wIABwADAAUACQAFAAMA//8BAAIAAgACAAEAAgAEAAIA/v8FAAkADQAJAAYACgAKAAkABwAGAAIABQAJAAYACwAOAAcABwAHAAYABwAJAAkACAAPABAAFgAVAA4ADQD8//3/DgALAA0AEAAFAAEAAAAEAAwACQAJAAoACgANAAkAAwACAAkACQAEAAQABQAEAAcACgAGAAgACgABAP//AwAFAAIAAQAAAAIA+v/3////AwAGAAMA/f/+//z//v8FAP//AAAGAAUAAAABAAUA/v/7/wEAAwADAAAABQAJAAkABQD6///////7/wYACAAGAAYA/v/+/wUABQAJAAwADAAHAAAABQADAP//AAAEAAQAAQD+/wAABwAGAAUABQALAAsABgAHAAgABgACAAQAAgABAPz//P8HAAgADAAKAAIAAwADAAIADwAQAAAA/v/+/wEAAAD9/wMABAD+////BQABAAwAEAD5//b/+P/6/wYABwAHAAUA/P/+//v/+f8DAAQAAwADAAIAAwD3//T/+//+//7/+/8BAAQA///8/wAAAwD8//r/AwAEAAEAAgABAP7/+v/9/wEA/v8CAAQABgADAAAAAAD7//v/+f/4//v//f8CAAAAAAAAAAcABwALAAsACQAJAAEAAAAFAAcAAQAAAP7///8CAAAABQAGAAMABwAGAAMAAAADABAADgAJAAoA/f8AAAsACAAKAA0AAgACAAIAAwAJAAoABwAGAAAAAAAEAAUADQALAAAAAwD///v/DQAQAAcABAD4//v/BgACAAYACwAIAAUA+v/9/wEA//8HAAgAAAABAPv/+v8FAAYAAQABAPv/+v8CAAIABgAGAAAAAQABAAAACAAJAAMAAgD5//f/+P/9/wgABQAKAAsACAAKAAgAAwAGAAsAEAAMAAoADQADAAMAAQD//wUABwD///7//v/9/wYACQAIAAUACAAJAAoACQADAAIAAAABAAEA//8GAAkA/f/7//7/AAAJAAgACgAKAAAA//8BAAAAAgAEAAQAAQD7//7/AQD+/wgACAABAAEAAQD//wQABwAEAAAA/v8BAAEA//8DAAQA/////wIAAQAFAAcAAQD//wYACQAIAAQA+f/9//7/+/8DAAYABgAFAAQAAwAGAAkACAAEAAEABgAGAAIACAAKAAcABQD+/wAADAAJAAQABwAIAAUAAQABAAcACgAKAAYACAAMAAwACgAGAAYAAAABABAADgARABQACAAGAAIABAALAAgABwAKAAkABgD+/wMAAgD+/wMABQALAAsACAAKAAYABQADAAMABQAFAAMAAwABAAEAAgACAAgACgAGAAUA/v/+/////v8IAAkABQAEAAMABQAKAAgABwAIAAcABwAIAAYAAwAGAAYAAwAIAAsAAgD///v///8DAP3/BAAKAAQA/f8EAAwADQAGAAUACAACAAAACQAKAAEAAgABAP//AAABAAEAAAABAAIACQAJAAQAAwAGAAgABAACAAMABAD9//3/AgABAAIAAwD///7/AwAEAAQABAACAAAAAgAEAAkABQACAAUA/v/7//7////8//v/BAADAPj/+P/9//v/AAAAAAYABQD5//r//P/5////AwADAP//8P/z/////v8EAAEA+f/8/wAA/f///wEA/P/6//3//P8DAAUACAAGAPz//f/6//j/BAAFAAEAAgD9//7//P/9/wMAAgD+////AAD+//r/+/8BAAAAAAAAAAAAAgACAP//AAADAAUAAgD8//7//f/9/wEAAQABAAMA+v/2//v//v8MAAkAAwAEAPj/+P8GAAYACAAHAPX/9v/9//3//P/7/wAAAgD9//r///8CAAUAAwAEAAUAAQAAAPz//v/9//n/+f/9/wQA///8/wIA/v/7//T/9v8AAP7/AAACAAMAAQD//wEA+v/5//f/9v8CAAEA/P/9//z/+v/3//r/BAABAP7/AAD+//3//f/+/wkABwACAAUAAgD+//n//f8CAP3/AwAGAAUAAwD9/////f/8/wYABwAGAAMA/v8CAAIA/v/7////BAABAP3/AAABAP7/BwAIAAwADwAJAAYA//8FAAcA///9/wUABgACAAkACgABAAMABwADAAIABgAKAAgABQAHAAUABQD6//n/AgAFAAkABgABAAUA///7/wgADAAIAAUAAQAEAAYAAwAHAAsADAAHAPz/AgACAP3/BQAIAAQAAgD8////AgAAAAAAAQAHAAgAAgD//wEABAAAAP///////wIAAgAIAAoA///7/wgADQAKAAQACQAPAAgAAwAIAAwADQAJAAQABQACAAIABQAFAP7//f8CAAQABAAAAAIABgD7//n/+f/5//z//f8IAAQA//8FAAIA/P8DAAcAAgD9//T/9/8BAP//CAAJAAwACwAEAAMAAAABAAQABAAGAAUAAgADAAYABQAMAAsABgAKAAgABAAFAAcAAAAAAPz//P8BAAAA/f///wYABQANAA4ABwAKAP///P8JAAwACgAJAAQABAACAAMACQAIAAoACgAGAAYABwAGAAUABgACAAQA///+/wMABAAGAAQABwAJAAYABwAHAAYAAwAGAAgABAAAAAIABgAHAAAA/v8BAAEABQAHAAgABQD//wQABgAFAAsABwACAAkABQD+/wEABQAGAAYADAAKAAUACgAGAAEA/P///wYABQAIAAkABQADAAEABAADAAAABwAKAAIA/////wIABgACAAkADgAHAAMABAAGAP7//v8DAAEA//8CAAAA/v/3//f//f/+/wYABQACAAMABQAEAAMAAwAHAAUAAAADAAAA+//4//3/BAAAAP7/AgAEAP//+/8AAAEA+////wMAAgAAAAAAAAD5//v//v/7//7/AQADAAAA/P/+/wUABAACAAMAAwABAAQABwABAP3//f8BAAEA/v8AAAIA/f/8//7//f8CAAUAAQD9////BAAEAP///v8AAPr/+v/9//r//P8BAP7/+//6//v//P/9/wAA/P8AAAYAAAD7//r///8GAP//+P/+/wIA/P/6/wEADAAFAP7/AwAIAAQA+P/9/wQA/f/2//7/BQD+/wAABAAIAAcA/v/+///////6//n/+P/3//f/9v8CAAQABgAEAP//AAD+////AwAAAP//AgD9//r///8CAP3//P8EAAIA+////wQA//8DAAgAAQD+/wIAAgAHAAgADgAMAAEAAgD8//z/+f/4/wEAAgD+//7/AgABAAIABAAJAAcAAgACAAQABAD8//7/AQD+//r/AAAEAPz//f8FAAsABQABAAUA/P/5//7/AAAIAAcA/P/+/wAA/v8GAAgADAALAAoACwABAP7/BgAJAAQAAgAAAAMABAADAAIAAgAFAAQACQAMAA4ACwAEAAUA/////wAA//8CAAUABwAEAAEABAAGAAMAAwAGAAkABwAIAAkABQAFAAUABgAEAAMAAwAEAP7//f/8////CgAIAAkADAAEAP7/AAAHAAgAAAACAAkABQAAAP7/AAD///7/+f/5/wMAAgACAAQA///7/wMABwAIAAQAAQADAP////8HAAcABQAHAP///f8BAAIABgAFAPv//v8BAP3///8DAAQAAQACAAMAAQABAAcABQAFAAYACAAIAAUABAD//wIAAAD8//v//v8FAAMABAAEAPz///8DAAAAAAACAAUAAgD7////AgD9//v///8DAAAABwAHAAEABAABAPv//f8CAAUAAQD8//3/+v/8//7/+/8IAAsABAABAP7/AQACAP7/AwAIAAcAAgD5////CAADAAcACgAHAAUAAAADAAoACQAIAAsAAwAAAAMABQAFAAQAAwAGAAQAAwAEAAUABgAGAAMABAANAAwABgAIAAEAAAADAAQABwAHAAIAAgACAAIAAQACAAgABwD+//7/AgABAAMAAwAEAAUABgAFAAMABAACAAEA/v/+//3//P8BAAAAAwAEAAoACQAFAAYAAwAAAAAAAwAGAAMA/v8DAPr/9//7//3/AwABAPz//v////3//f8AAAYABwAGAAUA/v/+//7///////3/BQAKAAEA/v/3//j/+v/7/////P/7////BQABAP7////9//7/BQACAAYACQADAAIA+P/1//f/+/8CAP//AAAAAP7///8GAAUABQAEAPz//f8FAAIACAAJAAIAAgAAAAEAAgD///v/AAD8//b/+f///wAA+//9/wAAAgABAAIAAgD4//n////+/wEAAwAEAAQA+f/6//v/+//8//z/+//9//3/+v/+/wIABQACAPv//P/9//z//v8AAAEA///+/wIA/v/4//P/+f8CAPz//v8EAAQA///9/wEABAD//wIAAwAFAAQAAQABAP7///////3/CwANAAUAAgD4//r/+v/5//7//v/5//n//v/+/wAA//8DAAMA/P/9/wIAAQD+/wAAAAD9//z//v//////+//6/wEABAACAP//AgAEAP7//v8LAAoABQALAAQA/f/8/wQABAD9/wMACQADAP//AQADAAAAAAAFAAIABAAIAAwACAD8/wEAAAD6//v/AAADAP//AgAGAAIA/v/9/wAABgADAAYACgAJAAYAAQADAP3/+//9//3/AgACAAEAAQD8//z//P/8/wUABQAOAA4AAwAEAAIA/////wQACAACAAEABwD8//j/AgADAAcACgAOAAkA//8FAAEA/P/+/wIA///+/wYABQAFAAcAAgABAAcABwANAA0AAwACAPH/9P/7//f//v8DAP//+//4//n//f///wMA/v/9/wIACAAGAPz/+//0//f/AAD6//7/BAD9//j/+f/8/wMAAAAAAAAA+f/7/wMAAAD6////AAD8////AQD4//j//v/6/wAABAAQAA0ADAAPAAcABAAEAAYAAwD+//z/AAD///7/BQAFAP7/AQAAAP3/AgAEAAcABwAEAAIA/f///wEA//8DAAUAAAACAP//+/8EAAoACAACAPj//f8CAAAACQAIAAIABQABAP7/BAAGAAwACwADAAIAAgACAAIAAwAFAAQA/v///wIAAAAEAAcABwAFAAcACAAAAAAABgAFAAQABQAAAP//AwAFAAoACAAJAAsABQACAAEABAAEAAEA//8DAAUAAQACAAcACgAFAAoAEAAQAAsABwAKAAEAAQAHAAcAAwAFAAEA//8IAA0AFgARAAYADQAGAAAA/f8BAAwACgABAAMAAQAAAAQABQD/////BAADAAQABAADAAQAAAD+/wMABQAIAAQAAwAHAAoABgD9/wEA/f/6//n/+v/+//z//v////v//P/9//v/+f/9/wEA/P8EAAgACQAFAP7/AQD9//v/BQAGAPz/+////wEA/v/7/wAABAD7//n//f/+/wIAAwD9//z//P/9//7//f/+/wAA/v/7//3/AAD///z//f////7//v8BAAEA/f/+/wIAAAAFAAcABwAGAP3//v8CAAEABQAFAAAAAAD9////AgD/////AgD///v/AQACAAEAAAD9//v/9//6//v/+P/7//7/+//4//z///8BAP7//f/+//7/AAAEAAEA/v8BAPr/9//8//v/AAADAPv/+f/2//b//v///wQAAwABAAIAAAAAAP///v8AAAAABQAGAP///v/7//7//f/6/wAABAD+//z//v8AAP///v8DAAMA///+/wIABAAAAP7/+v/8/wIAAQACAAIA/v/8//r//P8EAAIABgAIAAIAAQAEAAQACAAHAAEAAwACAAEABQAEAAgACgAGAAMAAAADAAUAAwACAAMAAgACAAAAAQACAAEABAAEAAkACgD/////AAD///z//v8JAAYA/f8AAAMAAQABAAIABwAHAAMABAAFAAEAAQAHAAYA//8AAAcACAADAP7///8DAAUAAwAAAAIABAD+//3/AgADAAMAAgD9//3//v///wMAAQD9/wAA///8//z//f8BAAIABwAHAAoACAACAAUABQABAP7/AQADAAAA9//6/wQAAwACAAAAAAAEAAMA/v8CAAcAAwAAAP3//v8EAAEA//8CAAQAAQACAAQAAAD///v//P8EAAIAAAADAAIA/v/9/wAA/P/7/wIAAwAEAAIA+f/9/wMA/f8DAAkACAADAAAABAACAP//AgAEAAIAAgADAAIADQAOAP3//P/7//z/DAALAAwADgAEAAIA9P/3/wEA/v8DAAcABQACAAEAAwAAAP//AwADAP//AAAFAAQA/v///wIAAQD7//v//f/+//3//f/8//v/+P/5/wEA//8EAAkACgAGAPz///8EAAAABgALAAkABgAGAAgAAQD+//3//f8DAAUAAgAAAPr/+//7//v/BAADAP//AQACAAAA//8AAP/////4//f/+P/5//z//P8CAAIA/v///wcABAD+/wEABAADAP//AAAAAP//+v/6////AAADAAIAAgAEAAsACAD8/////f/7/wAAAgD8//3/AwABAPf/+/8DAP//AAADAAIAAgACAP3/AQAJAAQA/f/+/wMA/P/5//3//v/+//3//f///wEA//8EAAQA//8AAP///P/9/wAA///8//3////+//3/AQABAAEAAQD+//3//P/9//3//f8BAAEA/f/9/wIAAwACAAEABQAFAP3//f/4//j/+v/6//z//f8AAP///f8AAAMAAgAEAAQAAgACAP///////wAA///+////AAD///7/AAACAAMAAQABAAQAAgD8////BwAHAP7/AAAHAAYA//8AAAYABQD///r//v8BAP///v/9//3/AgD///j//f8CAP///P///wEAAAD///z//P8BAAAA/////wEAAwAAAP7/AAACAAgABQD+/wIAAQD+//3/AAAFAAMAAAAAAP//AAADAAMAAwABAPz////8//n//P////3//P/7//j/9//8/wAA+/8GAAoAAQD+/wAAAwABAP7/BQAGAAEA///+/wAA/////wAA///8//z/BgAGAPv/+//7//v/+v/5/wAAAgD8//r/9v/4/////f8DAAQAAQABAP7//v8EAAMAAQADAAYABAD+/wAAAwABAP//AgD///v//v8CAAMA//8BAAQAAQABAAkABgACAAYAAwD///3/AAAFAAMAAwAEAAUABgACAAMAAgACAAQAAwAHAAkAAQABAP///v8IAAoABwAFAAEABAAFAAMABwAJAAQAAgAEAAQABgAJAAQA///6/wAABwABAAYACgADAAAAAwAHAAkABAAEAAgABAAAAAYACAACAAEAAgAEAAMAAQAJAAsABQACAAIABQAAAP7/AwAFAAQAAQABAAYA/v/7/wEABQABAP7/CAAIAAIABAACAP///v8CAAYAAwAAAAEABgAHAAkABwAKAAwABQAFAAQAAwAEAAQAAQABAPr/+v/+/wAAAQD+//7/AAD6//n/9//2//n/+/8GAAMAAQAEAP///v////3//v8DAAMA+//z//z/AQD5//r//v8EAAEACAAIAAMABQD8//r//f/+/woACAD9/wAABQABAP3/AQACAAAA/v/+//7/AQABAPz//P///wEAAAAGAAgAAAD+//7/AgABAPv/AwAJAAUAAAD6//7/AQD+/wEAAgAFAAgAAgD+//f//f8FAP//AQAEAAAAAAABAAAAAQADAAYAAwACAAQABQAEAAUABgAFAAUA/v/8/wAAAwACAP//+v/8/wAA//8CAAIACgAKAAIAAwALAAgABQAIAAIAAAD9//7/+//6/wEAAgAAAAAABwAGAPz//v8IAAUA/v8BAAEAAAACAAEABwAJAAcABAADAAYACAAGAAkADAD+//z//v8AAP//+//7/wEA/f/3////BAABAAAAAwAAAAUACAADAAEAAQACAP3///8CAP7///8DAAQA//8DAAkA///6/wEABgAIAAMABQAIAPr/+f/9//z//f///wUAAgD9/wAAAAD9/wAAAgADAAAA//8CAAcAAwABAAYAAAD6//7/BQADAPz/AgAHAP///f8EAAQABgAHAAIAAAD8////AQD+//3/AAD///v/AAAEAAQAAgADAAIA/v8BAAIA/v///wIA/f/8/wEAAAD8//7/AgABAP7//f8GAAgAAgAAAP//AAAGAAcAAwACAP///f/1//n/AAD7////AwACAAEABQABAAUACgAFAAEAAQAFAP7//P/9//3//v/9//z//v8DAAAA/v8DAAgAAgD+/wMABwADAPv//v8FAAMA+//9/wQAAwD//wAA/f/9/wIABAABAAEABwAHAAUABQAHAAcACQAIAPz//v////3//f/+/wEAAgACAP//BwAKAAMAAQD+/wAA/v/7/wAAAwABAP7/AQADAPz//f8BAP3//P8CAAQA/v8AAAQAAgAAAAIAAgAGAAgACgAIAAUABQACAAQABwADAAQACQAIAAQAAQADAAUABgD7//r/AQACAP3/+////wIA///9/wQABAD+/wEABAD+/wMACQACAP//AAD///7/AQAFAAMABgAGAAQABwAGAAEA/v8AAAgACQAHAAQAAwAGAP///v8FAAQAAQAEAAMA/v///wQAAwD///z//v8DAAUABQD///r/AgD+//b/+v8BAP3/+f8DAAQABQAFAAIAAgABAAAAAAABAAQAAQD//wIA///9/wUABwAAAP7/AQACAAkABgAAAAMAAQAAAAQAAwD+/wEAAAD8//7/AQAEAAMAAQABAAEAAQAEAAMA//8AAP3//P8EAAcAAgD9////BQACAPv/AAAGAAAA+//+/wMABAABAP7/AAD/////AgAAAP7/AQAEAAAAAgAFAAQAAgAFAAUAAAABAAUAAwD9/wAA///9/wAAAAAGAAYAAQACAAEA//8EAAUABQAHAAkABAD6/wEAAwD9/wAAAwABAAAAAQAAAAMABgADAAEAAgACAP//AAACAP//AAAFAAYAAQD9/wEABAABAAIAAwADAAQAAAD//wMAAwAAAAEAAgAAAAAAAgD+//3////+//z//f8FAAUABAABAAAABAABAPr//f8FAAQA/f/+/wIAAQAAAAAA//8BAAAA+v/9/wQA///9/wEAAQD8//7/AQAFAAEA+//+/wIA///9//3/AAABAAEA//8CAAIABAACAAUABQADAAIAAgAEAAYAAAD9/wMABAD8//r/AQAEAAAA/f/+/wEAAQAAAAAAAwABAAUABwADAP//BAAGAAIAAQAEAAIABgAJAAMA/v8FAAoAAwD9/wIABwAAAP3/BAAEAAMABQAEAAIAAwAFAP///f8BAAIAAQABAAIAAgAAAAAA/v/+/wEAAAD+/wEA///+/wEAAAD//wAAAAABAP3//P/+/wIA///5//3/AgAAAPz//f8BAAEA//////7/AQAEAAEA/f/8/wAA///9//7////8//v/AgADAAAAAAACAAMAAgADAAUAAwAFAAcA//8AAAYABQD8////AwABAP3///8AAAEABAADAAAAAwAEAAEA/P8BAAMAAAACAAMAAgAEAAEAAQABAAIAAwABAAAAAgABAP//AQAFAAEA/v8BAAQAAwAAAAQABwAEAAQABwAEAP7/AwAGAAIAAQADAAIAAgAAAP//AAACAAAA/v///wMABAABAAEABAADAAEAAQACAAIAAQABAAIAAAAAAAQAAwABAAIABQAGAAAAAAAFAAYA///+/wYABgD//wEABQAEAAAAAgAGAAMAAAADAAgABgAHAAgABQAFAAYABgADAAIA//8CAAUAAAD+/wQACQADAP7/AwADAAAAAwAEAAMABAAIAAMA/v8DAAcAAQD+/wMACAACAAEABAADAAAAAgADAAUAAwACAAQAAgAAAAEAAgABAAAABAADAP//AQAFAAMABQAFAAIAAQAGAAYAAgADAAAAAAAFAAMAAgAFAAQAAQAEAAYABAAEAAwACAAEAAYABwACAAIABgADAAAAAgAEAAUAAwAFAAUABwAIAAYABwAFAAMAAgADAAAAAAAAAP///v8AAAcABQABAAAAAwAEAAIAAAAGAAYAAQADAAYAAwD//wIAAAD+/wIAAQAEAAUAAwABAAIABAAEAAQABAACAAIABQAAAPz/AQAFAAIA//8AAAMA///+/wMAAQD+/wIABQABAAEABAAEAAIAAgAEAAUAAgAAAAMABwACAAEABQAGAAQA//8AAAQABQABAP7///8CAAEA/v8DAAcABQACAAAAAwADAP//AwAGAAEAAQAEAAUAAgABAAMABgAEAAAAAwAIAAUAAQAHAAkABQADAAQACAAEAP//AQAEAAUAAwACAAIAAQADAAYABAAAAAEAAwADAAAAAAADAAMABQAEAAIAAwAGAAQABAAFAAQAAwABAAIAAQAAAP7///8BAP///v8BAAIAAQACAAMAAAD/////AQAAAP3/AgADAAAA//8DAAIA//8AAAYABQD8//3/AgABAPv//P8CAP///v8CAAQA//8AAAQAAwAAAAEAAwD//wAABAABAAAAAAAEAAQAAAD9/wUACgADAP7/BAAIAAIA//8FAAUAAQACAAMAAgABAAEAAAACAAMAAAACAAYAAAD8/wMABQAAAP//AAACAAEAAAD//wEAAgD//wEAAwAAAP///f/+/wAAAAAAAP7///8BAP///v8AAAMAAwABAAIAAgABAAEA//////7///8BAAEAAAD+/wEAAwACAAAAAwAFAAIAAgAGAAIA/v8EAAUA///6////AgAAAP7//P///wMA///6//z/AgD9//n//f8DAAEA+//9/wIA/f/5//7/AgD///7/AQACAAAAAgACAAEABQAHAAQAAQACAAUAAwABAAEAAgACAAMAAwADAAEAAQAEAAQAAgACAAMABAAAAP//AQAEAAIA//8EAAUAAQABAAMAAgABAAQABQABAAAABAADAP//AQAEAAEAAAADAAIAAwAFAAUAAwAEAAYABgAEAAMABQADAAAAAgAGAAUAAwAGAAYAAwADAAUABAAEAAYABgAEAAEABQAFAP7/AQAHAAIA//8BAAIAAQABAAIAAgADAAMABQAFAAUABgAEAAEAAgAFAAQABAAFAAMAAgAEAAQAAwAFAAQA/v8AAAQAAwAAAP3/AwAIAAYA//8AAAQAAwABAP7//f8EAAQA/v/+/wIAAQD//wEAAwACAAEAAQADAAMA///+/wMABQACAAAAAAABAAMAAQABAAIABQAEAAEAAwAFAAIABAAGAAAAAQAHAAMA//8FAAUA//8DAAgAAwD//wEABAAEAAMAAQABAAYABwAAAP7/BgAIAP///v8EAAQAAAABAAEA//8EAAUAAQD//wMAAwAAAAEABAAAAP//AwBMSVNULgAAAElORk9JU0ZUIgAAAExhdmY1OS4yNy4xMDAgKGxpYnNuZGZpbGUtMS4wLjMxKQBpZDMgOAAAAElEMwQAQAAAAC0AAAAMASAFDSs7Vj9UWFhYAAAAFwAAAFNvZnR3YXJlAExhdmY1OS4yNy4xMDAA") {
                    await this.session.speaker.play({ audioUrl: "data:audio/wav;base64,UklGRrqpAABXQVZFZm10IBAAAAABAAIAgLsAAADuAgAEABAAZGF0YSCpAADE9t/2/gADAc0FpQVt9cP0ue4X7vP3evdfBR0FYQyWDN8Ovg9tEn8TjBQ7FSAWkxaCCJgIrvHc8Gj1YfSsCVoJCQQKBPLwwfBQ/ZP9vQxFDfTzgPON4qnhsPfD93gBwAFM9wb37AIzA44QixFC/af9LO0G7Sn8VPzoCOAIXv5N/X/z8/ER9AXz6vV59XH+cv6hFEkVriSSJXsV+xWX7jbuvNax1RntEuw5GMYXWRkRGSz20fXh7dztHwMiAxUGOgUX9a7zqvbF9Z0BzwCC96r1XPCI7lP/7/7TCgILfA1eDcYaRRsdH1ggiwCMAA/oRuY470/tAeoa6NvVSdNa3xLdk/qy+RgHSgdXEAIREB69Hu0keCUQGTIZufOU8orZL9eQ78DtrgUhBdzyEPKR9Nzz2BlPGuIS5RLd7kTtzPaU9acNag1TBJEDWfM78rz3mveMA2MD7fi+9yzb59lP26TapwYGBmgZsxhp/xv/B/sC+5QKQwpn9HzzudhY1xvst+pUAxkCePdq9n3w+O/cCvQKOySHJGAVeBWk9Vf10vOY83YBYQHC/Df80/fC9mL8qvsj8cDw6eb45ZX7j/oiDygPHgT3BN34mfk0BtMGGxYbFwsNqQ3u6Nzn+siwxg3TItLn9VL2cQjmB4kQaBBBF8UZog4REOEC5gAkBJIDXwFqAzL6APolBL4CvQ0pD+r7H/0z4SjflNr/2Lzpf+q8/AX9qAVMBa8KmwsmD+MQhA6pD24NtA1TCxsLewO4A1T5hfl98lXx3vPU8tr5jPrj+jr71/jc9678qvyaAMABLfyJ/JgB0QFcFtUX3BihGvEEAwbT+z/8pfdL99Pg+t8+0cPPa94X3H3pu+e86kfrSgcRCSI3qzgoRYhHYihrK2cCPAPI7ojtL/LF8STxD/HC4VDgveG94H3t8O1U7vvtGfI68awAPwH5DFUOKxpyG1EkMiZqEiUUvvEv8hfq8+ky6onpFtdS1QLVrtNp9ov2QRSvFE8fFiBeJUknEB7KH3UE4wTE877zqvnd+S78QPyh7Vbt/eWS5dzuy+7O9jz3kfpZ+0b9hP6k/Qr/ogZWB1gQbRAG/nr+xeh66YH7tvvWC2MLdPK58YnsfuxSE8oU6x0GIM3/+AB5/+z/jxhGGYAFEwZ54LHg6u+s8PsEawVi5y3mM9153BwF8wZGCg0MlOsh61f49fcbEeURDf9u/0T3pveDCtQLyApoC+EQmxC4JIMlQgytDcjkJuWC8U/wJRAJDvEP5g5U+Fr5ruLB4wLyhvGtGAMYnRTEFGHuO+9D5VbmCfYf9ngBJQCOBngFWxL/EmQoBCuYHxUif+mK6JzUmtCf8EHtvO6S7WXgreBSB1kIYTRGNe4mTCe0/y8Awvb493MFxwYgA2cDlO+T7j/wIe9YBDoEsv/I/w3m7OQR7CnqAwwNC84UdRU6DZ4O4h0WH0M1/DVXDAoMV7i0tmS6irnzCP4JEhN9E9HqEerm/aL+oR2QH5IIegl198P3YgFvATj6gPhZ8djux/0s/V79LP7t9VD27v/V/6MDUgMZDm8O0C8FMoAuwzHQ/RQAjtqJ2mnf09wp+174PgKvAcTp5eqX8fbycBe9FwYQzQ22+uL3PxKBEgMk6Cb7FakYfAzaDYb+7P0B6OXlGeMA4jTiB+OO4H7h1PKb8rQAE/8Q/tX7PA7dDXYhsiPZDdYPEfa09f4EpAMXDvMMyupC6WzVntQr+aH6chP2FIf63vkl+DP4LxxRHmwWIhcl/Uz83gknCpwNhQ0T+6H5DvCX79rc8dyx3MzbdwTGA0EF8QSQ3mHe//S89pEnhSqKGQgb2fpj+8MFOQYdDmENW/kv+Kvrkesg8ffwrfAJ7xvu4utmCW0IUTUXN4gvKDP0+/n+aOkZ63f0DPRP9z70igFK/7UD0gTN8uz0d/rG+9gXOBliGCQYAQp0B20WxRU+FIcW1Oaf50HTn9IV9Kf0bQvfCuMHowUZE6UUASQiKW4YyhpfDaAMURXWFB4JaweF6gLnWujg5nnz4PRY6Fzpzezo7EgQYRD+G3IckQrgCzcHqgg6EBIRyAtxDY8EQwaDB9YF0/u8+NHcedz+2c7ZewhDBj0paClwDlIR+/lv+nYamBksJTInPvfv+dXemd+T8nvzzfnQ+lTrY+rD5aDjkPsL+oMaHRq7FrIXkgJuBDEWXRc+MhAzBBH9ETjca9tU4ljgvfS/9A/cPt3p38Pf9CbgJwBIYkujDdYP7uph6xMQXRGgEDEQ0tb+0iDAn70v5Z7lGhb8FbkjGCQYAacERu4H8g8NjQ1VCmgJ/ORe5Qj2D/dYIc0hlSjsKV8OKxAY6s7pI+b65Pv9X/2d/Ar7uPHp8OMGCQkRF6IY2AI3AvjyafQ6AlgFKhzkHIQV6hV56tXsmuUs5uwIKQYG9/T0dsqHyhHqsemmKTIpvSkCLE8LSw4BAeoAJPjy9tLleeYJ1cvUzd6x3AAN2A0ZKVwsZhCKECoBJwBOHHIeAhu8G1vzoO+R8dbvxQMrBfLpU+jn0dvOEfpx+/go0ioSF7UUL/gF9+8IYwy5HaIfHxQIElsNbgyVAdYBhtUr0lrHVMKR+Ff3ERoqG4YR4xC3DgcNvw/QDw4HkwgoAyMDDflY9hbnUuUS6xHshvvj+jUCQP62Bw8GexAhE24cDB7GHYYbF/0t+hzbmdrN6W/q2wXdA0EChP08/DP7wf35AvX2J/rnATX9gB/rGtIfpyP5AOUG1fFh8CPuQ+iL3lLcxOlz6xIIEAi0+an1b+p952MT4BYAKEgt4go8CWUPQwmjJxAn4guXEcjr5O68/w/9DAyHCDDrsekF4czg5wTrBSUU0BS49ObyP9lA14nwx/HHHDgeoh1iGyP9pfv39bv5sAXiCdf/Hf5R7jDp3Pzy+m0bhx6nE3oXuPT59Pj1P/NCBUgDzf4E/6Hroeuq5Mzi/AQvBCEl8CZAFYEX3QSHBh0HIgf2AG7+PAFyAI/+lQE75aTlb+Ku3Zb9QvvJ9dD3gONV4l8PIgvhNWA3dwoNEXvjTeVJ/BL3fgm9BILx9/EF4B/iV+Aj4NT0EvTbEu8SKxxUGu8Ljwhy+8j7ZgQOCUYauhu8GN8TUfn29F/eMd8j5zvprv4k/2b7tvt55bvkk+9w7KAXRhadHeYgBgEXBNv+ff3cEwUR6wooCmrvbe+u+Ar4SRNSExMEJQUp2uDZatJ4z9v06/H/D0oQIg7XEFIHNQlnBbEFHAL2ARADKgLgC1oJ6AtnCa/+Sv5z80b0u+jn5xrlCOIx+Yb2XAqHCXL+sP7995H4swjLCfALggz6CBcIFxkOF40TQBFF9Q30/PSq9SYBuAE75y/l/cbBwkTaDtZ4Cy0Jfx0RHrgGxgke8PrygPvc+3wXshUUF0UVovYC9nngvuA57VvtVwNmApAE/wHl/aj6RAmcB/oVzBbLD6URmg80EREUrBSP/pr9R+mj55Htk+zd843zV/fO9239j/5JAfcBegIzAlTz7PGu4C/eLvGW7ksFsANb8hrybvHB8t0jfyUhO4Y6CRUJE2jig+EYx6XG7Nv62hEM0gt8G1sbFROdEasSHBEH/AT8ic7IznLWFdXBFssUqSr+KXEBJQLJ6y3s2vvY+qUDLwIMAH3/xhCiEd4h+SN8DJAOKvCK78/7B/g1DQ4Ky+mZ6gS7QL1p2QjZLjDCLURU0lLhKKUptv5oAR7x6/Nd0YDQTcnHxPn/OPwtKsApeyhoKgQQ1hHS4JLf88R2wQ33LvbhQ4pGrEFqQ8IUrBSD+p76GdFB0ILGDMWm9bP13w7lDoYEPAKJ/m384hS6FsofiiN+9aP2JdRx0mHcxNmr9FLy0w/rD9UVGRneEIwUyRx2HlQr1isEG+AbKewf7afQMtGw15fXdOy46woQtg+5KYUq4hxjHiQC0gNr+bT66v9IAAoHEwc8C5sL8vfH9yLT4tHfzz/PdOyU7I4N/gwzH50etgj7CHDmFOZ35qjkewo2CUkUThSN5zjnJ+f+5sgl5ibkOhM8RhPRE0HojOjo4dPhCvjs9zwDjANo867z7PAc8X4ZkxqmKZkqXgTKAyftWuxZ70bvo+0X7fvomef37//u1wrKCkQb1BrVB0kGy/n1+HYGXAdHDeoNph1yHc0zEDUfFE8WwNU41tXDNcPl7fvuBQwgDsj2yvebBl0ItzpqPkUvDzK/+6r8tt8h4FLhWOGI8NnvNPR084jsRewP/Hn8DTBVMcdElUXQFBMU9+hA6I7gIeAz6ALmdPlh9pf5S/jQ35ffsMYnxQTk7OJ8KBMqvSUVJ8r8bPyuBVwGzfy7/jXSOdMM2tPa5BsHHmdPglJjPUpAOQYZCMX3wfhfHuYeRySbI5/rBelXyfPGrdQB1DXnbead+N72bQ6oDTwbiBt9+E736NfK1d73nPcBEmESyAkICXoL1ApdCVYJL/KD8VrZ2ddB1OjSiuwK7HsY7xjjNK816TEFMycoECrIFDAXR/TV9X3rnOz6AG0C9g/yEBP9rPzb29HaxdXR1KLuG+15EVAPGh9RHb4BQQBd3pncP+BS3vn5M/h9B+YFf/9//v/38veyADsBhh66HwY+2j+cMAkyEgBYAAHc69tdztXN19Nz0ojq7OigBOkDLQw8DOEBSwLLBvEHkB9VIeYrcy3zFsEXbeuE61rL9cq+zCzM3OVx5W8EhwQGJuMmEkRkRaFFkUZ2JaIlBfyS+2Ddf9xV0jfRod0A3RX3gvd2D+cQuRaHGE0KDAzD/k0ANv8VAEkETgRZBfgEjPnq+HPqp+nu7DvsKgOSAkIahRl/IiIikhfsF4H7uPvr9j33jBDoEQgDgQTc2a3aG9qA28339vnECpsMMg/vENkZTBzsKn8tlidVKWgRfhLP/of/5fO/85fifeEgyq3Ij8ZqxdHpIekyHhAepzoEO4czJTT2IHshiAVeBc3clNvnzUfM6umu6N4DAgOsAWwBp/uv/OcO+RDuL90x/DVEN90bBB2++L/5D9tH2yzWOdZB8h3zjRmqGmUqAisUFX0VmvH98S7q8+n/Ce0IoSIxIUsMwgrm6SXo9eP44XvuYeyF+db3aAQoA1AMEQs9CwMK4v9B/xv04/Ot8UzxY/dY9+/6Pfwa+jr8KAROBmIW4hhpHE4f2RXqF1EN3w0dBS4F6+sA7AvNcMwt5j3lMSfXJgo4ojcODxkOmN853jPJ1MeO0pPRVO7T7RQKKAr3GxgdghO2FYn0lvYU9af2uRxrHo0p7iqKDPQMRe1x7bbjQeRi6tHqB/IY8mf/2f+UC6oMggigCd4LAw0IH3UggCazJwoTYRPX9Qz12OMK4o7dINtb1DXRPM61ylPqd+cNFB8SFyBOHmMfZR47HaEdBw3TDe727fdD6V/rwunM7ATy6fR6BqAJ3Bu8H8sYDRx0GLEaZScPKYolFCaaEW0Qbv0T+zfuF+sx33vbC9VD0d7Yl9Xc7Cfqnw/NDQUlzCMaFgMVBvgl9/jmKebR6I3nNO+w7X3tYeyZ5c3kYO7b7XkV9xWZNhw4fz51QDw/yEFlMI4zIwpkDazm6+ng4BDkJvMD9jX+awA28onz8uI14yHoWOdo+rT4AAp2B2QXShThHlAb5BHLDd3sLOiNxoXBLr9nukXWUNL07FDq6/Y+9p79Df9CCt0M3SK9Jes04TcnIrEkIfCa8dnOCtDC5LDm5RIVFc80bzb+RPVGeiQvJuTjEORFzsfNPPFN8YAhxCEUOkQ6ljlqOqgnsShdB/sGj/Ty8njtO+v928PYntLtziLYAdXN3yndrOk+5wz2PvSq+HP3EOvb6U/xs/CUFRYW3Si4KXUkmSUMHAYelRGzE2UM/w1YDt4PggzmDbv+eP/T7N3s3tuw26fUJdSy7Ffs1wr4CicLiwtQAT8C9AZOCHMWGhc2GO4XDwPBAgjglt+7ycnIgeM240sQOxEhIdQh+B/rH9IVfhXJAtIBs/Wc8/z6fPgzDFkK5hCZDz0J/gdVCDUH2gMSA0zskesb2V3YJej359sO/Q/ZK+wtOCmPK5UTDhZt/NH+o+L941rca9y/9En04wjbB74IDgerBqIE9w3dC2wZNRemHD8aChGUDjP9xPoX5I/hYso4x33GCsNC1sTSs90z2tfa1tfL4yHiPgeJBpg0KzSKR1dHlx8ZH/3Nb8yGoMee3rBMsIPdcd7YGBIcMlI8WA102Xsie/9/mXAceHNWSFwVLVIwewi/CXXlKOV1xFLCG8f7w5XfJdzD41Pf8820yLe497Nhvmi6Y9+521MW6RPePII8hyPuI6n0KfXX6f3q9/NL9eX4SvlP9Ar02+2k7SXsAuzt8cDx4gZzB3UjXyU2NBk3rjIcNoAdECFp98X60tBg0667AL0qvWe9qs9az5bn/eYj/MD6nRaVFPM1bDO/PzA8di9pKncSuwwg76Lp+tL6zZzN1Mk84rLgZP+DAB4WXRmNMJM1WUy6Ul1QL1eYNac7yw53EyXwN/N14AnibNuD23TegN2i7ZTsY/16/GYESQNyE10SzSL+IW8WZRV68/7xq9IO0fHFN8QPz9jMkt/q3InoieXb5rXjXeMM4BTrmec+A+T/pRSpEQsDMQAo2rDXBMDTvg7Nuc2a9/D5rCzkMClYSF4JW6lhvj1gQ2Ij8CftEBUUewLWA/j4APnP8ljyh/K28dL6MPlMCMwFmA7QC8n9C/vh3i/cWNxm2o4AJwDxIHohBx5LHon+mf7g3PHcMcZ4xXjKIcnZ9zj3IiMZI10p/ihoEgsSA+HU4Jy2LLZywT7Bhfdg+BkiDiQuJfQnPhi6GzsMVA9eBoII2gVaB0v6+/oP8aPwH/1i/OAN8gz1Dg4NPwU/AkwAF/0L9rPyEOd+43fvn+xABYkDzA2VDPwHFwfq+Gb4/+za7Gzzm/PoCY0KLB5SH4YgACJmEecSof6p/y/31/fC9nn3APPb8370kfU1A9sEbheNGZshcyOkHvQfAxMHFGrxyvFkyvHJg8fgxtfgA+CP9wP2FP9I/fD5Pvgt9jH0VwAn/v8TTxJME9QRjPi29j3ikOBA1CDTes6ezcTghuBNBG0F6yVVKOE5RT3XPt5CMzmUPXcs4jAAHMAfVQ0VEOkB6APx723xSeDY4NDqy+rLCvcKDyOOI7chpiGGGxob9BqFGi/7y/kwx2nEG7M2sOi7hrljzUjLueqP6YsU7hS/OhE8LENVRDAsMy15CG8J3udB6I3dpN1T5BTl4eZV6KjtqO+cBWMI1yBzJPwp3S3NJNkoeCK7JkkdIiEuEQQUJwANAp3hIeIjxDzDncAEv3vW+dTt+cP4iyEsIe1BdUJNSDhJXC79Lr4ECAWI34/fPc45zjXWudb/7qTwHw0GENIleSlbMC80TSvfLlIZBBzTAjkEYvXf9cjr6Ouf24Pb5dS51OXjQORu/Ur++BDZEZ0WfBeLEYoSCATZBEf3ifdA+zL7AAcFB3oDcAPQ8a7xa+d9597xQfLXCDUJWxZeFv8PDBAn+sL6md2A3pDXx9j59yf6QhkFHDoamxywAo4EYuoB7DHmZefY+G75cxcKGB0tJC7pJtsn+RF2EnQGrQZfAoQC0P24/Qj/3f7VCEcJahCSESIHmAhV8q/zqOpI7D3x2PLe9vD3hPxN/dD8wv1e9Of0DvP28ur+ev7cCkoKoAmBCMwBZgBE/wX+n/pS+Xj16vMe+6f5zgCt/6r7wfox8rDxaO+D70H3yfetAFIBTgAbAan1sfa87vXvS/rU+7MQfhI+HRAfqRgqGhgMAg1JApoCw/3R/YX/pf9mDNEM8yS8JQU37jfVK0csawgTCKzlheRk1LnShdWv02Lg3N7R7t/tAf1b/EkFzAToAmEC6vlE+Xj45PfJA4kDeA/HD00OHA/sASkDT/fH+A32wPdQ+x/9OAQCBi8UJhYyIvUjOh4+H6ELsQth8Z/wW9dz1YnKoscVzfbJ4Nbn027hc95j9dPypRISEbAh7iAoIA4gTxsOHL4TGhWSCA0KTPya/azywfMT8kbz9PyV/vML1g1pIaojMTzzPoE99T/zHEweIfLS8iDNes1vvkG+s9Fp0df6GPuwFzYYShR1FDcC4gGo99X2S/3A+0IK8AcQCB0FXPAC7cTSXs+QwxjAnM1+ykbwYe4pF+kWJCsGLAovJjGKI6gm3gYJCkzuzfCE5Y7nQ+X/5h7reuwB/fn90RukHF811zWUNEU0uR1OHHAFRANM8qDvxOOb4JDfK9wj5Tji4+2M64n1nfNhAxsCGRjfF3cdoh1GE1QTRgoyCgX8ePuA5gPl6Nb31EzVsNMs4UnghvWx9aoOLRCiJjUptjOnNg8rvC0gDCsOyeg76vPV1NYd3YHdofYB93oQ9xArGzEbPRZGFUIMnwpx9eXylNbf0ifRTM2x46XgcvVK84UAYf/sCEAJNBJ3E6AYEhqTF+sYcwiwCX/zevQF7/nvVPkr+hEG5AblD+cQHRTkFKkUqxRlEjsSQwlICaf1KvV39MrzaA2DDWoMkwzS82XzJu3r7P/y8PIa+WH4MP/+/d4DsQJ1/sH8s+487NXjGuFo3p3bS99y3JrrKunM+hL5lQWwBBIM5wtGEbERYRU4FqISwBOgAacCuu167i3t4e1L+rH6SwZTBoILyAvfCmALhhK+Eswk4iQLK/IqwQ6kDT7j9uAq0ubPwdsa2u/ute0ABQgE0BJkEpwWBxfhFsgXXROlExsJlghL/Xj8lfHI79vldeIK5Wfhi+sA6ffyG/FBAq8AZxAeD94RIhEdEf8RQR0iIMspnSyIF04YW+6i7fTTgdLK1RLTnehN5bX7svlABJUDzARQBMcC9gH3/aT8B/hg9l7ywfAC8gTw1/2p+zgJAQi2B3MHHgWMBG0KDQrQESQSVBb2FQIZ7xdQFwwYkBH2FDQLPQ+8+0T90eOW4c7YOtWF5SzkcwDyAI4ZShooK8osWzSXNksoCil0/yb/CdIv0grGPsYZ3wnfDvun+y8DQgQcAzkEXg8FEIMiziCcIqEeNQu/CPXxlvLJ5IjmPuIE5knmxe1n7lj11fzL/RsOBgt8FZsTZxP2E0YQrBANDV8KrAe1AhH2VPSU1lHb/MbezRfZL96F88f48AYjDMoeyR6pMA4scSxlKhMbSB0gAmgCSunQ5K7p2+ahAsUIYRRoIegRyhzYBpELMwKtAp0F7gDR/EfyFuYL3SrhUOAL7iHyEe/78uzqJ++K9Yz62gQUCLYLNws5CJEFRf0q/M36n/vIBQAFUAfmBZf5y/uG97v7ewlIDHcWLRtYECUZYQKJCTf3sfZM9MvsIvqc8Nf52vJX7fvr0ukK74D2DwAp/4oI6vhy/g7sHOxN6HLkyPYF89oLGAgWGQUTdRysGA8SBxeNAUkLF/7ABM8EzQeJDWkQoRi2HOASJBZL+Of2CuqU5BLyLO1W/k77BQW6AuH6Hfzg6ZfvEfIO+NkG5QrBBd4HwfqG+Pb5TvS7/m36EwVYAh4I3gXmBMoGEgKrB/b7UQHT8735I/g//O79k/mG8/nqjeqt5eLwAO1m94z0gPnf/d8BOQmvC+MOfgpsDLADvgVPA08DjwaFB04JpAo5DxALNRG8CsoIPQcbBCsG9AY9CkIBGQfK9eP7RPh/+qkI+AaYEEwNoP/I/JvhLd7bz+HIcdU9zpvvzu9HELsV8B/lI0Qbwx7qEeQVYQZ/BeT2cvEg7BrnvuqZ5s/xk+9I+4n9gwDFA/sKPQzwG9odZhv6HS8IAAn2+zP74Pje9Wry/+2b6qTp6uiX6oP0hPJdCjIHaxcYGjgU/RmfC/gNdAN5A6L7cfuZ9gXz6Pa58In81vprAcUESAKWA7kGyQWOEYkUcxe+HBwM4gxw83rwxeUC5Zfx1/JEBJwDIgsjCSMK/AmMCRALOQurC/IEgQPy7krtTd323Efiy+G287XxVAeAB0QTyRhxDDkSKQPUApsDgP9z/lX8ePf99qf4jfbQ9j/1SPi8+xAEcwm8CNQJVw1oDAQdCyAnGwkgev8AAP/mUuJA4NXbGu1c7G8ADP/MAE/8Af11/RQOhhY8G0IhlxE2EpkGRQm5AI4CJPa97gPsEuEw7ZLpLP6lAc8TShhYGOAbIw6rEYIJTgxoCmIKqgTRAu75svio8S3vH+x35VnqdOKv9DDxnAfdCrcPHRcnC74QzAZkB53/Sv639uH1uPfs9M33c/J38R/sv/ip88YFAgKMA7gFyAMlDHwQ6xcwEfkS/gJKAS35V/Z59VvwpfHt6HztweTD7t/rYf/TArkXdB3HHtUkGA67E136o/x79wH18wEq/HMJOAOQEB4OMh24HpMcPByWB8QENfQ99WHtBvOO8E72k/md/C35k/fU9VDw1QbgAf0VxhCwBmb+PfGk6zrpCuxW6VbwHfas+6wDKQfOAowElAcNBzsSGw9WC1IGqAbOAe0Sdw/XELIPiP6tAIX0JPfs7p7vXPA88+4BnAcCC7cLAgCj+fb5w/OQ/dn6tP6a+7gDX/6fCP0FLvszADXnUu6P55TnbPnT9KYJTwgKFBkW4RuHHr4bIB3yDTsKsvoa9E3zuvEC/AL/fgRtB7P+/gI98273dvfg9T0OWAmOGysZpApWCtnxEfOS7x/yB/yw+4wAe/xB+mL4ZPS39wz5av1zBN8D7wcGA30DDAJ9Af4ECf46/tnzEvAY7FHsRfFS9DMH1gaXHx4eIiBoIRUNnA8GAvgDJv+q/8r4zPf+9OL0R/ZZ97j4X/eq/nP6NwGU/iP6D/xW9x77Tf85ACsEUALU/b/7pe8j7Vfi3uAW427mQPer++YSrRFUIJccshP1ErL9xv0/9772YP0GAEwEpgo1EuIXEiECIzQZDRnX/vH/zey07Tzqreap8xDuEAUQBFsJHAyU93j4ZOpB6XPsDe2G7WzwHvF187P9jf3BBP0CPwRYApsCVAAg/ar7fgJiBHAaVh4/JOUm0BT6FiwIdwuRAYcErvda+Rj1z/Qm97HzzvGL7QPvtO2v91T4wAMYBNsLHwyICYMJCPyF+xzxFfJw8jL1+PgC+//5qfgD9LjuCezi5f/j0OGU5ZHnZQQNB8EzpDYiRZxJaS2GMdEOOxCS+Fr4F+RB46rd/ttI8dfv4gymDOwbwxvDHj0e0Rl0GlYOdhCkAXEEjfSN9v3k4+MM3r/Z4Oij5Bb7wPjJCpwKyheWGeYaGxzBCo8IHe8I7CjfA97P6Pno9Pu5/UIAPgPr++P6TQGm+2UJXwfOCWINBwztDSMTmRGqElATyQnVDEsCWwPx/J/7Vvm/+FABmQMfFBcYJxyIHb0MfAna8HXsXNaH01vJxsZV1CHSlO2b7boAEQIzDPsMMRO9E/IPwxC4CkkLqw5nDnEQNQ8uCAEH2P+ZACD/DwI3CzQPQSAOJEklcyfsEHYRp/6A/2L+KADAAl8DAQSHAmsFcgMNCFwHKAtGDLwHogk4+ET5weii6IXm1eUS7bzrjfXC8+j8r/tW/F/7j/Pu8Q7vLO0g90D2XwSSBBcG/gbw+yv9zfq4/DgGZghJCywM4A3bDNMX2hbcFD4VHQEWApr4Ufl//Vn9T/8o/gUArv5r/sn9tvae9mD3dvenBbcFfBEmEUwObw0d/ZX7je226+Tw++86AOIAuAs9DRASgBPBEv4T/AwyDp4JlgoPCzwLhAsJCzkM5guKDLMMggPLAxDy4vFT6N/nWO9D79v67/oo/nf9N/0V/Jf75Poj9CzzxOey5fHeItzv4oDgffbX9QcKmAt8DT0QOgsADhgRfxPHFiwYDxIZEgYG4ARJ+Yz3KPF978byBvIAAKcACA8UEUwQxBLgBKcGVvri+nTzofJh8Svvuvob+KYHeQXlCHQHIwGLACz9y/3//40BuQBrAsL5i/rj9Jr0hPrO+SIEZQPuDDwMQBObEhMQUw/wB1sHNAfMB0oIQgqRABUDJfcb+cT1hPZs+Z34jfo9+AL3rvPU8WLu1O4k7IPxHvDm+hT7AARlBZMENwbX/e/+TfdT9/H1v/Qw+hn4fgIaAH0KhwjPB6gGpvgh+KHv6+/v92X5HgQWBl0K+Qu9C5cMfQZJBv4A9/+6Bp8FcBLKEQoY8xfPFYoWDg+gEF4HiQnjAO4Caftc/ED3i/Z/82vxrvDd7W3xxO4j8grwHPE/7+rzYPJI9yD2MvRE88HwTfBV8nvygPbu9kb+m/71ByYINg4iDsQPqg/rDPMMOgldCTQKlwp5DCMNOAzzDBcLIwwiB3IISwGLAvz+AwDP/jH/4/9W/5MCPQGf/nr8yfT28Szxae5W80Dx2PV89JP6KPpG/qD+Af2W/dn6Ovs6+ez4L/nj9+3/IP7dCkUJPhFPEAoSLxLWERwTDxI6FIEQ/BIvDE4OfwflCCoClgJP+GP38OyV6mvqXufK8yLxDv5+/KT+Mf6D+eP5kPeF+MD5yvor/bD9s/5j/rH7dPrm9yP2pPkf+LUA/f89CrQK6hGWE5YRMRSjC64OiAenCh8HvgmuCksMdRAEEXMQ/g8xCRkIPQNVAoUCVAJdBPsEGAUsBm3/aQDW8i3zI+jD5+/nDOfD8H/vZPrH+HAAs/5IA+cBSgHEAJ77y/t3+UX6I/1R/hACTwOEBtoHwgk9CzEKmgssClELEQuiC0cKVwoXCPUH5AU/Bm0CZQPW/S3/4voR/Db6yfqA+VT5Qfd/9qrzkfJb7zvuue3B7JTzL/Ou/RH+twK4A2MCowPOA08FoQgzCggNgA5hD5oQZxCLERwQUxHjDD8OfQjdCeIGUwhJBr4HeQK5A/n98f7w+6L8+Po3+0/6B/qg+dn4PPci9qj0kvOn9N7zK/bJ9V/5SfmX/sv+iAC/APr79vsn99D2Zffz9sj6UPoL/5j+IAQFBCcJoQmwDOANoAw2Di0IiwmZA2QEjAK5As8BjgHr/37/ggBAACkDOwMLBB0EhwNkA2gCBgJF/8L+Bvt++g73kvan8w/zSvSU8wL7Wfr1AYgBpgRoBMIEzgTHAwUEIANuA58F9AXDCCEJtAbsBm3/XP9J+A34F/fd9u/8+vzVAgcDYgJvAsz+n/7i+5D7OPmv+Kb5/viE/wj/cAU5BaEFnQU4ACMATvn8+JT2//Xu+Er4Tfug+gz7dPp/+hL6EPvN+j/9BP0IAbsA+QOKA8ADSQPTAHoAeP5O/t7/AgDbAxoESwZ9BokFiwXoAuMC9AD9AFoBfwEqA04D8ATeBD0FAQXgAYwBtvxY/Mv6lPp8/Gv8uf+f/zgCFwI/APf/Xfv2+g/6r/nl+5T7jf0G/Yv/0/66/+7+q/zZ+4/65PmS+iv6FPut+jj95Pzx/qP+tvxZ/Mr5ZPl5+i/6sf6B/s0EyAQ7CWMJvQnvCY4HyAd8A5EDWf8l/yr+u/1o/gD+K/7F/Wb/Tv/WAOQA0P+8//L+if4d/5P+rv7+/QP/kf5YACEA6f/O/+3+vf4B/8H+lv5G/qj9U/1x/Tn9Cv7Z/fL/2f+RAogCdQNvA8QCtALbAckBtgCaAF3/KP80/vT9Kf3k/ED89ftJ+wb7zPp6+vv7svv0/bf9E//m/sj/o//j/9T/Df/9/ur/6v9MAnYCMQJZAqMAwgDkARQCmwPpA6UC2wJ/AakB0QH7ATMBTwFQ/0f/Y/0u/bP7QftK+9L65Px1/N79kP0y/eX8+Pyu/Ff9Af2g/Df8DvyX+1j9/fwj//j+YwBrAJ0BvwFmAp4CQwJcAt4B4gFMAj4CygPeA0wFfQUgBWgFgwOwAxYBCgF8/Rr9lfnf+G73jfax99/2Xvq5+QD+lf2s/0z/P//K/mD+zP2D/NL7YPqa+YX72Ppx/xD/CQPcAngFjgV0Bp4GLwVVBSYEOATqBPAELQUnBTIEDgR9A00DaAIrAsIAYQBSANj/GwGOAFkB0QARAZ4ADwC6/+X9hv3C/FH8nP4x/hwBsgABAYMA7P5C/oP9vvwW/kz9oP/c/oIAxP9pAMD/7/+C/1n/Ev9Z/hX+O/3P/BL9dvzQ/Sj9yf0T/SX9bPyr/vz95AFTAQcDdQJwAc8AGv+I/lL98/xf/Un9wf/5/zsCmAIKA00DKgIvAgEBswDVAWQB0gRvBH0GQAbDBaUF9wP1AzEBNAE+/jz+2/zE/HX8UvyD/G78+f0C/t3/8v/9APwAbwEzAXkAGwDH/mj+cv5B/qL/z/8AAsACKwV6BrUFJwc0AnADF//r/zX/yP/FACYBggGeAVgAJgD4/Z79cvsX+6/4RPhU9/32cfmB+fv7ZfyO+yP8s/pU+wr8h/wP/n3+N/+J/7f+2v73/PP8jPzL/K//VAA/BWMGAwq8C1ELYw0hCTcLrQWgB/cClwQxAlIDKQLyAtT/HwDb+ob6kfbV9Wn1mPQl9232cPn6+BP6AfoP+jL6zvo7+xX8vfyc/kv/sQJxA3QFUwZlBTYG2gSVBe4E2QXJBdYGqAcACQ4JrwoiB8kIrAL2A/r+IACX/Yb++vyH/VL8mfw2/DP86vt4+6n50fjq9s31mvZa9Y74nvc0+sb53/qt+gb8CfyL/dH9/P1L/nH+tv6bAB4B9AK0A1IENQX2BRkHxwbzB/0E9QXaAsIDgQJPA+gCpAPUA6wEIAUBBlsEBwWtAAoBjPyB/Iz6GPqG+w379/62/r0CvAIxBGEEEAJSAsv9tP1o+f74S/bJ9XL29fWA+kX6ef++/94CWgP8BGoF0AQyBd0BCAJg/0L/JP8S/zn/N//0/uj+wv6z/p/9cf1//A388/2J/VABGQGMA3EDZQNlA0kBXwEA/tT99Pp4+t75H/k2+1v6r/3O/Fr/tv4yALz/ngFMAY4DdgOQBGoEnQNOAy0BtwA8/qP9FP1k/Bf/pP7NAo8COgUSBWAFSAWhA5UDXAEjAd4AmABVAkMCpAOPA64DlAO9AqkCMgH+AJ8AXABNARkB9gC/ALr/Yv8v/9H+fP7//d79VP0A/5T+yf9r/2H+8v11/RP9bv0a/av8KvxJ/ez8xQC0AC0DQAOjAtYCxwEkAp0B4QFTAZIBzAEgAiEDggPCAiYDfwDeACcAgQCRAvsCsQMNBP4BEgIzAA8AY/9M//z+6/7a/8z/0QHzAXUCngIhAP//bfsN+133vvZm97v20vuU+6kBIwI+BvoGygeOCOwFpwbcAmQD9wA2AWIAtwD5AIABlQI3AywD1gPCAWsC2QAlAY8BdAF1AVMBqf+s/+r97v0+/Gf8GPqV+vn4afkn+h/61vyR/Lb/k//OAcsBUgKYAicCvwIHAr8C7gG1At4BogLCAVUC7ABAAY//EgAd/8n/twAkARQEbwQMB4wH9gY2B6sDXwPj/z7/Qv2l/EP72Pqd+YX5pPmx+Rb8FPzc/hD/vv8CALT/Uv9NAB//tACT/w0AcP/A/2D/EwABAC8AwQCNAIgBowGPAsUCcQP3A3kEYwXjBVkFIAY7Ax0E6wBNAeP+1v7/+6r7avmP+LX5d/jJ/GH8hgCdAfsCxQSIA6MEdAJMAhIAuv5K/Sj7qPxR+jb/tv0LAhwCbAK9A0QBlQLT/4IACP9j/9f/HQAuASIBYgFEAUoCqwL6BPoFngaOB+oFDQbyBEYEkQOnAvj/Xf8Z+9z6avdO95L1VfUY9UD0CPZO9Cj51vbR/dj76QDj/ywABwCa/cT9ivyC/K/9a/3U/zb/dAJkAYQFrwSQCOMItQoiDEIL3wzqCaYLXAdsCcEEGAYSA24CrgO/AWUHCwZEC1ILGAnDCQEAggC+9xz4u/d1+Gb/dACtB2gImgaNBjb4xvdT6YzoAutt6cf8DvrFD2INIRa1Fc0HxAjt6/HrD9sW2j3nvOeLCXwMqitdLhY1RzWlHPYa+fW4857dJ9vq2wPaneiY6B/6Kfx5CGUL5g/0EWsSmBJ2EgcSFhDEEDkI/whz+P/2CeaY4pXacNew3Nba8e4C7vMItAiyFcIVowvkC9n65vpt84nyofOh8RX2APSI+2D6wAMIBOANQBBlHdYh1y/iNKozbze9GiscJfJL8fXWbdX12B7ZQvR09hMZSxugMkE0sDPDNYQbnhzN8FHuAcnYxBnEZMKg4zfkhf/v/jD5nvXM2SbUP7xytlW4tLSF2eTZMhFDFmg+x0ZfSJxP2ir/K5n5Y/R03C3Wv+zL68YVGhzJLK42pyRnLW8WZhzNGMgbkCEcIRYaRRcBAlb/veou6VvdiNyV2w3b5ehu6Pr9D/6ABXUGL/cg95PmpuMq7NfnhAeMBOIdEh2ZFpwX2fig+37kU+go7L/vyAP7BVUVYRZhGIEZchLUE3YKswq1AkABofz7+gb67fnb99r5R/Ef9P/pIuty7Hbqu/xR+aEUOxKgJ68m4iV6JdIHxAba22PZUb/ou6/DR8EP4p/iwQgVDWArjDJsQjFJsEMXRr8qIyiWCN4Etvap9tX4xv27/bME9fqU/kvzSPCQ69zjK+cj4N3pk+YJ9kD2ZAmQC88VbBfdCAsHbObA4EbL3cT2zqLLXPIz9AUkOirERj9NFkRlRs4hsh8X+Qf2Zt6o3L/aUNqr6yHthwH7BasMCxOoDu4TmBOZFdcbGRpyF/USu/yJ9xPaCdYgx+rEJc0dzNfkpePR/5X9qQ+ZDUEQwBAACsANXgWBCj0EFwhFBw0I9gunCSIMhwi2CMoGFQxUDkAb8CG+LRA2+DSxOj8msyYoA7n+fdwi1nTIZ8OJ0JLNK+mz5vb8DvqQADH+6/jY973wRfDj7YXs+u857ZbyDO9a8g7vpvI08Ef6uPlSCqUM/BpzH7AiPyYFHgUfdROOExULtAwbBZ8H7/yx/Zz0I/Oz9BDzpwC4AHoQaRGoFnEWVwxECtP4S/bJ62Xqte3P7fr4vvmlAVsCHQHFAPD5u/cA9ULx3vm59tkGfgaSEEQTLA0SEZH+sQGt8Dryle7c7o75fvhsB8QEfAxjCOwGFwN3/x/+G/26/57+eATc/lgFN/sN/yr2F/Xd9UHwy/2M9kQIQwPNCnMKFQLSBS72Pvty8qr1bflS+UkDvgCDB7cElgRHA2/+kP4Q+Vf5AveA9i75JPg4/pH9DAI9ArcBbQLNAHQBkwXlBSMOUw76EKUR+wnRC8P/vwJG/P3+igIfA6sLjAm9DqYLpAoeCR4ENgUr/osASPnB+k/2CvYp9u/0PPcP9sH1gvRx8SjvAPF27df4SPUWAjUAVwL+AuX4RvsR72nxS+4F76X2KvW9ACP+tgjJBlsPgA+9EqYUGg9+EWsGiwh6/7cBCv61APP/WwKMAYUCOgOCAhEHkQVCCggJagfmBnX/1/8R+oj7I/xb/qABYQMhAy4DNf9e/Yn6z/fB+C72FfkP98H4XveX9/z2zfgp+Uv9bv4WAYUCKgJHAzkDlwPPBDUEPQQHA9kB+QBTAZ0B/QM3BYgGrwdABaYFwACkABn9F/0N/CX82vt5+076Fvl/94v1Kvb/8474ovZ+/ET7Yf/t/kEBVwHhAdMB0/9k/8/8X/xX/Hn8tP9tADcGEwceDcsN/Q+cEOkMdw02BngGTAAoAJX+c/46AbgBKAVBBrcG1AdKBOAEAv/u/k/6u/ly+WD4nfsQ+nn9wPul/Df7z/n2+EX44vdf+mT6cP7d/rcAiwEnAPYA7/40/5P/Pf/9Am0Cjgc+B4AJawkTBv8FQv8x/y36hfoG+v36/v1Q/8oCEAQVBfUF9gNeBFkB/gC2/o/9+/xs+9r9svyEAFkAiQEyAjcAOgFF/3IA5P8OAYkAXAH9/wcA7v0b/br7h/qt+4/6Cv47/R0BogAYAyYDGwPkA6wBHgPIAIAC9gGiA9UERQbJBqwHkASBBAH/9P29+1D62f0B/YMCtgKZBbkGyARVBlf/yADz98f4k/OO89T0D/Ry+lT56wDM//sD8ALfAeYArv30/Dr7DvuU+yb8Gf5s//sBzwNgBV0HeQYHCJAFWwapBLIEuARqBPsEvgQ5BV0FBwa9Bn4GuAfRBDEGzgDRAWv8tPzk+Yj5P/pt+cH7nvqw+0v6Lfq5+Hz5Pvg5+l/5Nvu4+nz8Y/zx/kD/yQFxAjAD2gMcA4ID2wL9ArcCqwKCAnECGQMSA2wElwRyBc0FTAXXBaoDGARKAGsArvx0/Nj6VfqK+tn5pvrU+fH6EfrD++z69/xH/H7+8v35/7j/AAHsADoBZwEYAVoBEgFlAXUB1wF9AvICaAQJBSgH+gecCaYKNgpJCz0IMQmMBDMF/wBXAZL+pf7K/KT8NvvR+gH6dPnZ+Bb4rPfH9pH3h/ak+Iz3eflt+IP5lfhR+X74/fhM+J75CvmV/Df8kACHAP0COAMiBLgE3QXJBvwHPwldCdIKYgnPCowHygiHBHwFmQJgAxQDvgO5BFEFLwWaBW0DkwMJAM//9ftS+3f4efdV9yn2n/h496v5mvjw+MP32Pej9sz3lPZ3+ID3L/qM+Tr9Bv1DAY8BjwVRBrMIwAmsCbAKPgkpCnMJYApiCmoLTApjC1sIUQnVBZgGvgNQBBMBLwFV/er8vvrQ+Xz6WPmQ+mX5Mfnl96H2K/VG9KfyDfNj8Ubzn/Ey9arzsvmG+OT/RP+LBHoEuAXmBUkEkwTDAf8Bxv8PAOr/SwA2AtkCjQV4BisJYQoJDFENogzFDc8KrAtFB8MHmQLLAvz96v1B+xX7Hvvt+n78Pfy//WL9U/7M/W7+0/1C/qv9EP6Q/Qz+tv3U/Zf9vvyF/Dv75PrN+l/6SPzh+1n/G/8BAxMD/gVTBs8GVQcFBXwFggHKAd397v0T/BD8Qv1A/VAAbQATA0MDiATHBEoElQRaAooCMwBQAJz/pf/B/7r/1/6+/vz8rvzt+4D7wPxJ/Oz+jv6TAFAAJADS/6r9Rf1E+8L69vqE+sT8Zvzi/qL+tACMAFYCWQINAxoDWgJ4AsYB2QFNAogCFQN4A3ED7wNwA+0DYwPEA2IDqwOJA7QDWwNxA84C0wJJAkcCgQF6Adv/rv+M/SX9Yvu5+lv6gvni+gL6mvzH+17+tP1i/9H+Lf+u/gv+hf3e/FP8bPzi+w39mvzB/nv+BQHxAP8CDgNPBHkE+AQrBcMEAQW7A+4DUgKCAh0BPwE8AFUAb/9h/+D+qv5M//7+XAAGAOMAmQB9ADUAv/+F//P+u/4Y/tz9W/0H/Vr9AP20/mT+pgB6AL0BqwHkAfEBqwHCAbQA0gBA/0v/lf6X/hb/Ff9LAEwAewF0AcMBuQH+AO4AMgAeANL/u/9+/2L/gf9u/xoAAwDk/8z/Zf45/jn9/vyY/V79cf5J/sz+vf5N/1//vwD+AFoCvwITA4gDlQL8AnEBuAF0AKIA3f/1/6b/sv8CABcA4AD6ANcA/wAZ/zb/1vzi/N/72PvQ/NH8+v4J/+EAAAFhAYEBiACmAE7/Xv9g/mf+/v33/Sf+KP4I/yD/xQDqAG8CrgIJA0oD0wIVAwoCPAJGAGgAP/5Z/lX9Yf22/b792f7s/kkAYQBhAXkBLQEzAYn/jv+j/Zr9q/ya/Av9CP1k/nf+6f8OAM4A/ABxAaYBgAK3AmQDnQPWAggDKgFRAeX/DwCa/8L/tP/f//D/FwBcAHYA1wD2AAcBIQHUAOwAtQDOAA4BJwEwAVYBOABLADv+Of56/GH8Qvwg/N39x/2TAI8A/wIFA7EDxQM/AkcCZv9e/xz9Dv0J/ff8gP6H/rf/xf/3/w8AEQAeAKYAuADyAQoCeAOPA8QD1QMkAjYCa/9y/6n8mfxM+0P7IP0n/XEBmQG2BPUEFgVlBRIEVgT/AjYD4gESAqkAywCY/6n/sv68/hj+Lf6r/sP+vADWAE0DawNcBIME7QILA/v/CQC3/bf9g/2P/cL+z/6M/47/DP/6/nX+YP4Z/wH/9ADqAEkDXwPTBO8E3QMLBIkAjAD1/Or8kPtt+yj9Ff12AHYA7gL6AtsC9gLwAPMAaf5R/nH8PPwH/M771PyU/In9Wv0F/tv9z/66/o//gf/y//D/KQAkABMAHgAtAEUAuwDZACYBTgGWAdEBsALuAnYDsAMNA0UDsQLlAvUCJAMiA1gDYQOUA74D8QM4A1sDJgE6AWz+X/5f/D78KPz5+1z9Kv0//gv+Sf4W/gX+yv2A/UD92fyc/KP8aPwL/dj8w/2g/RH/Bf8CAQoB5gICA68DzgPmAgsDiwGeAWIAaQBo/2r/GP8S/4n/gf/v/+f/KAAiAKIAmADIALYA6f/Y/6r+kv5l/T/9Svwm/DT8D/xF/SX9rf6R/uj/3f+pAKcAgACCAA4AFABEAFcADgErAbUB2gEgAkkC5wIbAy4EaQTYBBwF7AMTBBsCSQKoAK8ACf8W/2b9Uf0C/en8R/4n/m3/VP8n/w3/Nf4M/hP+5P2g/oD+rP6P/uj9zf2w/ZD9pf6N/p7/jf+7/6T/Of8e/w//8v5X/1X/4P/b/w0ADwAQABYAKwA3AGQAbgCtALYADQESAUUBVQEaAScBvQDLAIYAiQCLAI4AagBjAKL/jv+D/m7+Wv5C/hT///52/2X/KP8Z/7/+ov6S/nD+6v7I/sv/qf9vAEIAFQDx/43/X/8E/97+Pv4N/pb9av0j/vr9lv94/94AzwB5AWsBxgHDAUQCPwJjAmQCogGfAeAA0wD+APEAigGFAd4B3gEJAgMCzwHDAeEA1wCb/4P/Qv4U/kr9Df30/Lf8B/3M/D79B/0a/uT9fv9a/2YAUwBZADoAbf9Q/+P+xf7P/8H/eAFwASICLAIgAisCGgIpAnYBeAEuADIAxv/I/5YAmwCuAbgBCAIgAoUBjQFCAD0AFf/1/nT+V/7Q/qP+kv9t/6n/g/8G/+L+kP5s/jT+B/6S/Wz9gP1h/Yf+df4aABcAjgGpAZsCtAKhAsECJAI4AgMCKQI6Ak4C0gH3ATEBVwFKAW4B2gEEAisCVAI4AlkCAgIOAigBNgFLAFMA9P/x/0X/MP+0/Z79w/yo/Az95vwD/u39xv/A/6kBrwHWAd0BFwAWAIz+h/40/hz+jP6E/lH/Uv9UAGAADQEaAUwBXgGQAaIB+wEHAjUCQgIDAgwCNgE8AbX/p//S/bn9xfyc/CP99vxq/kv+n/+G/zEAKQBzAG4AwwDLAOgA7wCfAKoAPgBAAC8ANQBbAG4AGAEvAQ8CMALUAvUCRwN1AxsDQAOeAboBzv/0/4//ov89AGIAoACzAFsAbwCX/4z/fv5u/kz+QP58/3D/fgCAACwAKQCl/qb+Qf02/Sv9I/2F/on+QgBUAG0BjAGNAa4BwQDkAPP/CQDC/9j/DAAjAJ4AxgBRAXoBgQGtASwBVQGrAM4Asv/D/0v+Vf5t/W39XP1a/Zb9nf34/f/9jf6Z/in/Of9M/1r/8v4K/x3/Pf+PALMA9wEsAvUBKwL4ACUB9f8TAJv/vf9xAJ4A7wElAp0C3wI5AoICgwHPAdQADwFOAH0ARABwAJEArwCuAMkAnQCpAGAAZgDx//P/Vf9J/8z+y/7e/tL+Of9D/zr/Pf+5/sD+dP52/rb+uP4V/wz/0P67/vn92v2v/ZT9n/6N/u3/5//VAOQAhwGgAcEB4wFZAXkB5gALAQcBIwEgAToB4AD6AIEAjQA4ADgACwACAJv/iv/b/s3+h/55/tv+0v45/z3/Of8+/wT/C/+//rT+bf5f/qb+k/5h/0j/pv+M/zz/Kf/v/t/+K/8b/4n/j/8dACgAIgFHAaQCygL3AzQEewS1BJEDvgN+AZMBaP9o/0j+Ov4n/hT+jf5z/hr/DP+v/53/9P/l/8D/tP+J/3n/a/9U/9L+tP6u/Yr9wfyU/JL8XvxD/R791v66/m8AYQDyAPUAwADHANcA8QBNAWMBegGbAWUBiAFQAWsBCgEjAZMAogB/AIgAGgEZAZ0BnAFWAVYB0gDSAHIAXQDA/7T/pf6I/lf9Mf10/EH81Pyo/H3+XP4yAB8ABgH4ADEBJgHMAMEAFQAJAJP/h//G/8P/mQCcAKABtgFMAmACUAJnAuEB7AFoAW8BWwFfAZQBlQE8AT0BTABKAIj/d/8d/wj/vv6h/rH+jP7L/qH+p/6E/nz+W/5+/mP+u/6a/kb/M//u/9j/HgATACoAFQBCADUAQwA+ACgAIABPAE4AqgCnAOwA6wCnAKMA7v/d/5//kv9NAEMAAwEGAekA5gDq/+P/ev5i/nL9Uf2W/XD94f7A/rgAqABIAkUClgKeAqMBnwEsACkA/v7u/sX+uP6S/4b/bgBvAOIA6gDyAPkAegB7AOz/8P8bAA8AZgBgAFgAUABsAHEAuAC+AKUArABiAGUABwAEAED/Nv/Y/s/+c/9v/7oAwQDsAfsBRAJbAoMBiwFJAFAAhf+B/yn/IP8v/yv/h/+E/+D/3P9NAFAA7ADkAAwBAgFwAF4Anv+K/87+s/4L/vH92P3F/XP+Wf5X/0v/DQAFAK8AtABoAWoBEAIhAmsCfAIdAi4CMgE7ATsAQwDl/+r/DQAYAFQAVgCJAIwAhQCIAHAAbwCEAIEAegBwAC4ALwDz/+X/iP97/+7+1f7U/sX+Vf8//6//pP8eABwA6wDuAHkBiwF4AYEBOgFJAQsBGAHqAPQAkACgAO//8v+L/5j/6//p/1sAXQBSAEwA4f/V/0H/Nf8E//P+Tf9D/4//g/8d/w7/J/4X/kn9Mv1g/Vr9Bf///gQBFgEMAiACxgHkAeEA8gAXACsAEwAjAJ8AwAABAR0BzADtACQARACS/6v/dP+D/8X/1f9bAGwAygDeAC0ANAC4/rP+B/4C/oT+eP7o/ur+Df8O/5v/rv+IAJwAKAFRAWwBjQENASoBWQB4AOr/BwDk//v/GQAtAJQArgDaAO4ATgBeALr/xf9KAFUAIgEsAf8ADAH1//j/3P7Y/h3+E/7V/cb99f3e/VL+Rv7p/uD+ef98/6X/pP+6/8b///8KACEAMwArAEQA1ADyAJwBvAG5AdwBUAFvARMBKwESAS0BRQFbATkBSwFjAGwA8f7w/gT++/0Y/gP+2v7R/t7/1f8wACUAev9s/8X+s/4J///+kf+B/5n/jv+v/6f/BQD7/wMAAAD5//n/tAC4AKoBrQGzAb0B2ADhAAIAAADI/8r/IgAnAJ8AqADZAOIApAClAAEAAABV/0n/+/7n/uP+yv6m/o3+Vv47/m/+Vf7O/rb+Gv8L/zj/K/9u/1//1P/U/3YAfQD0AP8ABQEUAeYA7wC1AMMARgBKAOL/6P8wADgA/AALAZQBtAHeAfMBwQHiAUUBVAGoALcAJAAkANT/yv+5/6//hP90//3+5f65/qP++v7a/iT/Df8o/w3/Cv/w/sj+tv6o/pn++P7y/lf/Sv99/3n/0f/M/1IAUgAAAQEBvQHNAU0CYgIpAj0CWAFvAWoAeQAAABQAGwAhAEQAVQChAKsAGwEtASYBLgGbAKQA4//f/yn/If+L/n/+Yf5R/qP+nf5d/1T/MwA0AIcAigB2AHYAZABiAA4ACQCK/4P/gP9+/9T/zv/1//f/LgA1AJAAkgDUAOEAPQFJAY8BlgEwATkBpwClAGEAYAAQAAkAoP+Q/1v/Tv8+/yf/Lf8h/27/X//g/9n/TQBGAGMAYADS/8f/Gf8L//L+3/4h/xH/P/8u/37/e/8DAPn/bAB0AK8AtwD+AA0BRwFXAWABfQE3AU0ByQDeAFkAZgBKAFkAlwCdAM8A1QDtAPMA7gDwAHUAfADw/+3/BQAFAGYAYgAtADAAf/94/xb/DP9m/13/RQBBALUArgABAPP//f7r/sD+r/5C/zb/8f/p/4AAgADCAMoAtQC7AGoAdgAeACAAHgAkAFMAVAAsACwA5v/p/+n/3v/N/8X/iv+B/6L/nv8aABkAewCCAKwAvgCBAIwA5//0/4n/lP/K/9P/UwBkAM0A2AAAARMBzADVAGoAeABKAFEAZgBxAJkApQCVAKUANgA/AKX/sv9u/3D/h/+O/8j/y/8ZABcALQAtAP////+W/47/Iv8Z/9/+0v4f/xj/dv9z/7f/uf8hACcA7gD5AGABbwE+AUoBsACyAP7/+/9a/1T/6v7e/qj+n/6//rL+X/9f/yAAHwCEAIUAewB/AFIAVAAFAAUAnf+d/1H/UP9V/1j/dv9y/5j/of8mACkAGQEpAbEBxAGkAbkBNgFMAZwApwDz/wEAd/97/yf/K/9M/0v/6//u/38AgwCUAJQAaQBsAA8ABQBQ/0z/v/6y/pz+jv6z/qX+8f7m/lr/Tv+1/6r/BQD9/zoANwALAAcAvv+3/7P/sf/l/+f/CwALAA8AEwApACMAbgBvAGcAYgDU/8r/gP9x/9n/zf8yAC0ARwBEADwANwASABQA+P/3//b/8f/C/7H/fP9s/4T/cv+D/3D/VP9G/5X/hv8vACkAjwCGAHAAbgApACgAIAAlAEwATAAuADYALgApAGcAZQB3AHYAJwAmABIAGQBxAHcAfwCJAPb/9f9E/zj/5f7O/uT+1P4q/xz/uf+u/0IARABPAEoAuv+7/zb/L/9O/0f/6f/p/5QAlQCtALIAPQBDAOv/6//3/wMAWQBlALgAzQDYAPMAwQDYAKEAsQB0AHgAMgAlAAQA9/8JAPv/JwAjAEkATQB4AIMAeQCLAFEAWAAdAC4AMAAxAG8AdQBlAGkAwv/A//X+9f7Q/s/+cP94/1cAZADgAPQA+QANAZYAoADW/9r/Qf8y/xr/Bf8b///++P7h/vb+3f5H/z//+//1/98A5gB+AY0BfwGSAfQACgE7AEcAqf+z/5b/kv/S/9P/JwAiAH0AigDHANYAwwDeAIoAmAAPAB8Adv9u/wH/+f4q/xb/of+V/+//4P/t/+b/2P/I/+3/6P8jABwAVQBdAIYAnACUALAAcwCXAGIAeABoAHcAOQA6AOD/3v/V/9f/JgA1AKwAwwD8ABgB0gDgAFYAXwDR/8T/df9o/3H/Yf99/2n/bP9h/3H/Xv9+/3j/e/91/6P/rP9AAFIAuADYAKkAxgBlAHwAKAA1ANL/0v+z/7T/CwAJAH8AiwCsAL0AnACwAI4ApgCdAK4AxQDTAOIA5QCMAIMAsf+k/wH/5/7W/sL+Kv8b/8b/xf9TAF8AewCTAHQAhABVAG0AOQA3ABMAGwDc/9P/Wf9Z//H+7/4G/wn/gf+D/18AZAA8AUUBSAFSAc8A2ACGAI8AbgBwADoAMwAAAPL/lf+E/2f/V//P/8z/ggCFAN0A6QDKANQANAA0AGD/XP/y/uT+CP/6/l//Wv/f/9j/JQAtAB0AHQAEAA4A+f/4/8j/zf+g/53/lP+Z/67/rP/E/8X/pv+c/43/hf/S/8T/GgAUABoADQAlACQAHAAXALr/wf+t/6P/GQAiAFsAUwAHAAcA0f/D/9j/1f/q/+L/1v/V/wEAAgBCAEYASwBTADAAMwBJAE8AegB+AIIAgACCAIIAWwBYAOz/4f9l/17/NP8f/1r/UP/p/97/ZgBiAHcAewBIAEwAEQAUAPz//f/y/+r/1f/J/4T/eP9h/1b/iv+F//X/9/90AHcAgwCJAAgABACd/5f/dP9s/3P/Zv+5/6//DgABAAUA+f+4/63/l/+L/8X/vP9EAEQArgCxAHoAgAAHAA0A0f/O/5z/nP+//67////9/wAA9P+//8D/1P/W/xgAHQBwAHQAtgC6AKoApwAfABwA0v/M/+j/4f8YABMARAA7AEcAQgANAAcA3//f/wMAAwBHAEoAWwBkABcAGgDp/+7/8P/w/wgACgAOAA0AHAAiACkAKgAgACQABgAIALn/uv+C/33/mP+W/7f/rv+6/7T/8f/l/ywAKAArACYAEAALACUAJQAhACUABAAJABoAHgBaAF4AhACJAIkAjwBZAGQAGwAcAPv/AwAFAAQA+f/6/9n/2f/K/8n/AwAEAF0AYACPAI4APwA6AMj/uv+g/5D/vf+t//D/5v8DAP7/JQAlAFUAWgCHAIwAcgB2ABMAFwCw/7H/qv+w//T/+P87AEEAQgBAAC0ALwAeABoALgAuAHsAgAC4AL0AZwBxALP/qf9V/0f/Yf9J/2n/T/+C/2n/1f/N/ygAJABZAGYAhQCSAHgAgwAPABoAxP/F/7P/uP+t/7H/rv+u/9H/1P/w//D/5P/m/9f/2f8dACUAoQCpAOsA+ADNAM0AMQAqAHv/Z/8s/xD/cP9Y/97/zf8yACoAcQB3AHkAfwBRAF0AUQBWAFQAWwBPAFcAPQBEAA0AGAAJABEARQBNAGAAaAAtAC4A8v/t//H/8v8MAP3/+P/1/+b/zv+0/6r/jv93/6f/mf8kAB0AegB3AEQAPgDm/+P/xv+3/6z/qf/M/7//MwA4AMEAxwDjAPgAcgCBANX/3v+e/6D/tP+u/7z/tP+U/4f/Qf83/xT/Cf89/zX/ov+c/+z/6f8HAAYA6P/n/6P/o/9f/1v/Xf9R/5//mf8OAAMAWwBhAKIApwDTAOoA4ADxALMAyACAAI4AMAA0ANv/3v/J/8X/x//J/9L/0v8PABYARwBUAEUAUQBcAGsAYQB0AOr/9v9l/2v/bP9u/8D/uf+//7f/kf+K/4L/f/+7/8H/FgAjADwASABcAGgAUwBYAPX/9/+q/6r/1//b/x0AKAAqADMAAwATAMb/zv+R/53/1v/b/08AXwCdAKoAjgCeAFgAZQDx//f/hf+H/23/Yv+c/5j/vP+0/6v/qf+//8H/DwAWAGYAbACDAIwAPABBAJj/of9c/1//2v/p/48AmQC2AMYAYABrAA0AGgARAB8ASQBXAGMAcAA8AEgA8f/4/7P/sv+q/6b/nf+T/5D/f//O/8b/KgAkAPn///+p/7H/CAAUAGsAegBkAHEANQA8AP7/AQDr/+3/MAAuAC0AOgDH/8f/jf+Y/+7/+f9sAHQAmwClAG8AawD4//D/lv+K/5P/gP/C/7X/AQD1/wMAAwDS/9X/sP+7/wcADgCjAK8AFAEXAb0AwQDT/8//Lf8v/zD/Lv/P/9f/xgDOAA4BGgFdAGEAw/+8/8T/v//a/8z/q/+d/3n/Yf9a/03/XP9M/3v/dP/t//D/3wDhAHwBlAEpAS4BQABLAJf/lP8f/yD/PP8w/xIAFgDlAOMA1ADdAFcAWAAnACoAVgBWAHsAeQBNAEQAzf+//0v/N/9L/zb/1f/F/0sAPwBIAEIASgBIAF0AYwAjACsAk/+R/2L/W//J/8H/IwAcAPH/7f/M/8b/NgA4AH8AgwAMAAkAt/+u/8T/t//c/8r/8//i//f/6v/Q/8T//v/0/20AYgA7ADgAtP+j/5n/l//B/7n/+v/6/2UAZQBnAGcA6//q/83/yf9AAEYApQClALwAxACaAJoA/f8CAHb/av+e/5b/BwD5/wIA8//s/93/CAABAO7/7P/A/77/MgAzAMwA0ACfAKAA5P/f/2b/Yv+J/4H/FwAZALAAtQCzAMEAOABIAMf/1v/F/83/8f/5/w4ABADl/+H/pP+S/2n/Y/+W/47/+/8AACYAKgAlACsATwBUACYAKQCz/6//xf/A/2gAaQCEAIoAIQAnABoAIwBVAGcARQBQAEQAUwC2AMAA1ADlACMAKwB4/3P/kv+M/+H/1P+H/3b/Av/3/jv/Nv8uADwAHgExATMBRAFTAFYAPv85/7P+lv4D//n+/P/v/4YAlwCdAK4AwwDgAL4A1AD//wcAsv+p/0MAPwBKAE0AZv9d/yv/K//f/9f/OAA0ABAABAAbABkAMwA1ACsANgBfAGgAXwBnAKD/mv/q/tf+Zv9S/w0ACwDM/83/l/+k/0QAWwDVAOkAhACTAAMA9/+8/7b/hf9q/1H/Qv9O/zj/kf+J/xAADgB2AH4AkACdAIYAkQBnAGgANgAtAMj/uv/6/uf+lP6K/nv/ev+UAKgAjgCfAAwAFAA/AEcAsQCyAJIAlgBXAFYADgARACH/I/8w/hv+k/6E/iEACQBGAUYBjQGWAfEADwH7/xUAaP91/1v/UP9J/yv/Rf8k/0j/O/95/4T/DgEtAV0DlQPsAhMDlP+U/1D9M/2u/ZH9rv6a/pb/kf+wAL0AggGYAaoBtgHBAMAAL/8f/7H+pf6b/6b/SQBZADgASQBZAFkADwAFAG3/Vf+o/5r/nQCrAPgAFgHBAOcAaQCGAKD/qP/T/r3+6f7E/uP/zf/+APwAhgGaAQIBIAGz/77/r/6u/r3+pf6d/4n/WwBMAHsAfwCPAJgA6AAAAd8A6wD6/wEASf8//5T/kv80AEAAcgB5AGMAcgCAAH0AkACOACwAHQBe/1P/LP8p/9z/6/+hALQAjACbANn/0v8P//j+vv6b/gP/5f6s/6D/SQBXALkA0gDeAP0AwADSAC4ALwB3/2r/RP8s/6//qP8iACQAXwBwAL4A0gDgAPgAlQCiAFEAVACNAJEAkwCRAP3/+f96/3D/d/9u/67/pP8MAAMAfwCCAKYArQBSAGEA2P/i/3f/fP9B/zb/ZP9a/6n/mP/S/9L/IAAnAI4AogD2AA4BCAEdAZAAnACt/7H/YP9X/9P/zP/8//X/lP+D/4T/fP/X/8v/7//v//z/9//0//n/u/+4/6T/n//H/7//2v/K//L/6v8bABIABQATAAUADgBbAHcAoACuAJkAqABzAHIADgAPAK7/pv/P/9D/RwBIAJMAlwBvAHIACQD//73/uP/y/+X/BAD+/+n/5f8NAAcAJwArAML/vP9Y/1T/cP9x//r//v+aAKcAxADUAEMAUACj/6n/iP+K/7//wP8VABYAWwBgAGUAagA8AEMAzv/O/2D/V/+Y/4n/8P/h/5f/iP9g/1T//P/+/4sAkgBrAHIASwBRADMAMwDG/8n/kv+Q/7//x/8fACoAXgBpAEQAUwD4//n/4f/r/yEAIABDAE0AYQBkAFIAWgAdABoA/v/4/xYACgAQAAMADgAGACIAIwA7AEIAOwBEAP3///+i/5z/jf+C/6v/n/+L/4T/oP+e/ygAMgB6AIcAJgArAMr/y/+b/4//f/90/43/gv/G/7r/DQARAEUAQQBFAEsA///5/6n/oP+U/5H/7P/k/zoAOwBEAEEADgAIAMT/vf+b/5T/w/+5/+z/7f/s/+v/CQAMAGAAaQBUAFUA5P/j/7b/sP/e/9f//f///x0AGQAVACAAJQApAGYAcQCOAJgAZQBoAD4AQwA4ADcAAQAFAKv/pv9t/2r/m/+V//n/9/87ADsARABLAEEARwAyADkABgALAMn/yP+H/4P/kf+P/wIA/v9ZAGYAYQBlAEoAXABQAFsALgA6AAAACQDo/+j/5v/q/wMABAAYABgAGQAbABgAFAATABYAAQD9//j//P/8//7/BAAKACsAMABoAG8AagBtABIAEgCz/7D/qP+k/8L/yP/p/+7/FgAgAHQAhQCvALUAkQCeAEMAPwDk/+D/p/+e/6H/m//L/8X/FQATAEgASAA8ADkAJwAkAA8ABQDs/+r/2P/R/8b/xv/C/8L/2P/Y/9z/3//m/+P/CwAMAEMARQAyADcAFQAbABkAJADu//f/yf/P/+n/6f8HAAUAAQD6/xYAEQASABAA8P/w//b/9f8LAAwA7P/l/9H/0P/j/9j/3v/g//7/9P8hACYAIAAiABEAEgAQABQACgAHAOf/6v/U/9b//P///y0AOgArAC4AIAAsADAAMQD//wYAsv+v/6j/pf/H/8n/3v/b/9P/1f/c/9r/+f/5/x8AHQAWABMA8P/t/wYAAQAQAA0A0//Q/4j/hP+M/4b/0//W/zkANgBoAHAAcwB3AHAAeQBsAHQADgATAKz/r/+a/5z/2v/d/w4AEAA8AEIAXgBjAGMAZwBIAE0ALQAqAOf/5/+r/6X/nf+V/7X/r//C/7n/xP+8/9v/0v8PAAkAJgAmAA4ACwD5//n/6//u/+L/3f/a/+D/5f/i//n/AQAxADEAgACNAJsApABtAHoAQwBLADAANgAtADEAEgARAO3/7v/w/+n/EwAUADQALQAMAAkA1v/M/7v/t//G/7z/4//g//H/6f/Y/9H/3P/X/+T/4//i/+H/7f/u/y4AOABZAGEAMQA+ACIALAASABsA8P/4//r///8zADgAQgBLABsAGwDp/+3/6f/o//P/8P/e/9b/3v/V/9n/0f/F/7j/uv+1/9j/yv/Z/9j/6P/e/+7/7v/4//b/5v/q/yQAKABcAGUASQBSADYAOwAwAD0AHwAnACEAKwBHAFIAbQB3AGgAbgA/AEUA///+/8//zP/Q/8n/4P/b/+n/4v/y/+z/6f/i/+T/2//y/+z//f/2/9//2f/k/97/+//5//H/9P8BAAEAHgAnAC8ANQAjAC4AIwApAB0AKAARABcAAAAHAPz/AgASABcAHwAjAAEAAgDc/93/7P/m//v/+v/1/+//6P/i/+H/3f/j/9j/1//S/9f/zf/Z/9T/+v/3/y8ALwBDAEcANgA6ABoAIAAQABIACwAVACcAKAA9AEoAQwBLAEUATABPAFsAMwA0APH/+//Z/9H/9P/5/wcAAADY/9b/z//H/+v/5v/e/9b/xf+7/8P/vP/N/8b/6//n/xEADQAXABcA+//5//H/8v8HAAcAFwAeADIANgBHAFIAVgBeAEoAVgAzADYAEQAaAAUABgAVABcAIQAkABgAGADq/+n/zf/I/9n/1P/o/+D/7P/o/xIABwAoACYADAAEANH/yv/a/9b/9//0/9v/1//z//b/MwA1AE0AVQA6AEAALQAwABEAGQDy//f/3v/g/+H/6v8EAAQAIwAqADUANwA1ADcAJQAkABAAEAD7//P/4f/e/9j/0//O/8X/3f/a//f/7f/0//L/+f/x/w0ADwAsACYAGwAkABQADQD9/wgA+//8/wAABgAdACMAPwBIAEIASQBFAFIARwBNACEAKwALABAABwALAAQACQD4//T/6v/p/wQAAAD6//j/4f/c/+n/4P/Z/9f/rf+h/4X/gv+x/6f/4//i//b/8v/n/+n////+/xcAIAAeACIAIgArAC8APAAoAC8AIQAwAC0AMQBDAE8AQgBJAC0AMgAdACMAKgAsABMAFADy/+//5//k//T/8P8EAPr/7//q/+z/4f/0/+//GwAXACAAGQACAAIAAQAAABAAEwAtAC8ANwA+AC8ANQAiACoAKgAwADIAQQAqAC4AHAAuAEEAPgAtAD0ADAAJAOj/6v/d/9n/1v/U/9P/z//O/8n/4f/a/+n/5//V/8v/0P/O//f/7//3//f/1v/Q/9j/1f/r/+z/AgACABQAGQBIAE0AdQB+AGMAZwAdACkAEQAPAAcAFAAOAAsACAARAB8AHgApADIAMwAvAC8ANgAUABEA4v/i//T/7/8NAA0A+P/v/+T/5f8BAPn/EAARAAkAAwDx//H/+P/1/w0ADwANAA8A1P/Q/7//wv/a/9X/2//h/9v/1f/0//z/GwAdABoAIgAIAAgABgALAOn/5v/O/9L/3v/W/+P/6P/p/+T/CQAKACIAIgAVABAA6//u/+f/2/8LAA4AHgAWAO//7f/f/9r/BgAFABMADgD9//7/EAALAC4AMAApACsA+v/7//v//P8PABEAAgACAO//7//k/+j/AAD+/yEAJAAxADMAEAASAO//7//2//T/7f/p/9//3f/w/+v/AwADAP7/+f8CAAAA9P/z/9L/zv/A/7z/2P/V//P/8P/m/+X/DAAJADkAPQA4ADgAEAAQAPr//f/v/+///v///xsAIAAhAB8ACAAMABoAGwAMAAsA1P/Y/9P/zf/7/wAAAwABAPf/9////wAAEgAPAPv/+//l/97/yv/M/8j/wv/l/+n/BAAAAAkADQARABIAIQAfABcAHQAJAAUA/P8AAP//AQAFAAYAIAAlADYAPABAAEEAOwBBADIAMAAUABgAAQD9//H/9P/t/+n/5//n//j/9P8RABAAEwAVAAoABwAKAAsAFAARAPP/9v/N/8j/0//W/woACQAFAAkA/P/9/ysAMgAyADYAEgAXACkALAAuADUADAANAPT/9P8HAAoAAwACAN//3f/7//n/FAAUAPz//P/+//n/9v/3/+T/3f/U/9L/6//m//T/8//u/+v/DQASAC8ALgAsADQANwA3ADAANwAYABsAEQAXAB0AHwARABkACQAHABQAGAAWABsACQAFAB0AIAAiACAAAAD///f/8//5//n/6P/i/9z/2f/8//j/EAAPAPL/7//5//f/GAAZABAAEgAJAAkAAgAFAPf/+//x//H//v8DAA8ADgALABIAAwACAPD/9//5//n//f/+/+b/6f/b/9b/7f/w//n/9v/x//H/8f/u/+7/7f/s/+j/7f/t//D/7P/z//L/GQAYAB8AHgAMAA4AFgATAEAARQA0ADQA+v/7/wkADAAiACMA/P8BAA4ADgAbACEABQAGAPD/8P8EAAkACgALAPP/9v8DAAMAFQAXAPj/+f/o/+P/9f/4//3/9//2//X/+v/5//7/+P/2//j/8P/p/+b/6f/8//P/EQAYAA4ACADy//b/9//2/woACwAlACoAOQA7AD8ARAAhACYACAAIAAsAEwAYABQABQAKAAsACAAYABkAFgAaACgAJQAhACUACwAIANr/2f/S/83/z//N/9v/1v/s/+v/DgAKAA0ADwATABEAFAAVAAMABwANAAkAAwAMAA0ACQD0//3/BQABAA4AEwAWABkACAAIAAAABAAMAA4AHQAgAA0ADwAAAP3/+f/9/wUA/f/////////9//j/9P/9/wEAHgAcACYAJwAJAAoA+f/3/+z/6//W/9X/3P/a/woADQAYABoA+v/7//7/AgAMAA8AFwAXABkAHwAQAA4A9//7//b/9P/4//3/8P/r/+z/8P8MAAoAEwAUAA0ADQALAAsA+f/3/9f/1f/C/7//1f/S/+P/3//w//T/BQD///7/BwAFAAIACQAMAAEAAwDp/+f/4//k//D/8f/3//X/DgARACoAKwAjACQAIwAjACgAKQAdABwA+//7/+7/6v/y/+7/8P/s/+T/4v/u/+j/EgAWAB0AGgAHAAcAAAD+/wUABAAAAAIA5f/j//b/+P8XABcAEAATACEAIQApAC8ADwARAP3//P8NAA8ACQAGAND/z/+3/7H/1f/R//f/8/8DAP3/+f/5//j/8/8BAP//EQAMAPf/9P/i/97/6v/n/w0ADwAdABwAGgAdAC0ALwAyADYAHAAgABoAHgAyADcAMgA1AB0AHwAJAAkACAALAAQAAgDy//P/AwD//xMAFwAIAAEA6P/o/+v/4//k/+P/3v/Y/9r/1f/o/+n/9P/y/wAAAgAFAAUA//8CAPb/9v8AAAUAGQAaABcAHAAFAA0A+f/7/wsAEQAvADQAJgAoAAgADgAgAB0AEAAWAOH/3v/Y/9X/9P/5/wEA+f/0//n/AgD6/wEAAgD2//X/BwAFAPj/+f/X/9X/6P/l/+//9f/q/+n/DAAQAEkATwBcAGEANwA8ADoAPwAdACMA3f/e/+f/7P/+////8//0/wMABgAiACIAHwAkAAMABQAMAAgA+/8AAND/yP/P/87/7//t//7/+v8RABIADgAMAAcACQAKAAcAGQAcABUAFQD3//n/8P/y/wQABgAQABAAAQAHAP7/+v8GAA8AKwAqACoAMQAfACAAKQAuAC8AMgAHAAYA6v/r//L/7//2//j/CgAHACMAIwAeAB8ACgAJAPz//P8IAAUABgAHAPv/+P/2//T/BAAEABoAGQAEAAYA+P/2/woACwAjACUABQAGAOj/6/8gAB4ANgBAAB0AFwD4////4f/e/9r/2//9//3/KQArACIAJQATABMAHgAgAAUABADr/+n/8//y////+//v//D/8//v//f//f////j/+f/8//3/+v/5//j/8P/y//b/8//0//j/AQADAA4ADAAGAAkA+v/7//D/7//5//3/DAALAAgADADt/+z/6f/q/+//7P/T/9X/0P/M/wYABwA2ADQAHwAiAO//6f/u//L/AgD6/+b/6P/x/+r/CgANAA0ACgAIAAoAEAAOAP3//v/0//H/BAADAAkACQD7//7/FwASACQALAAEAP//8v/2/wMAAAAKAAwAFQASAAwAEAAHAAIAAgAFAAgABADU/9L/z//M/wEA///5//j/7//q//f/+P/+//3/4P/e/9z/2f/1//H/5f/n/+P/3f8BAAMABwAHAPj/+P8GAAkADgAPAAoACQD6//v/AwACAAMAAwAMAAwACAAEAPr//P/s/+j/7v/v/wEA+v/8//7/BAD+/xIAFgAnACMABwAHAN//3f/j/9//5v/s/wEA+f8iACoANAAzACwAMQAoACkAFgAaAPL/8//e/9z/7//0/wAA/P8HAAsAEgARABoAGQAZABoACgAGANj/1v/H/8L/2f/Z//T/7//t/+3//v/6/w0ADAD7//7//v/5//n///////z/8P/1/+T/5P8KAA8ANQA4ABkAHAD9//7/EAASABIAFQD6//n/+f/8/wMAAgAOABAAIAAdACMAIgAGAAUACQAFABYAGAD5//X/5f/k//b/9P8HAAgAHwAeACIAJAAXABgADgAPACMAKAApAC4AEwAYAAgADQARABUAFwAXAAQACQD3//X/+/8AABsAHQAGAAkA8P/x//j/9//q/+v/3v/c//b/9P/8//v/6f/m/+r/5//t/+//6v/m/+b/6v8EAAMABwAJAAkADgAHAAUABAAIABcAFwAjACYAHgAjAB4AHwAjACgAGgAdAB4AJAA/AEEAHQAhAOP/4//V/9H/2f/b/+n/5P8BAAIAGgAbABYAGQATABAACAAOAAkAAgDq//H/9//w/wQACAAaABkAEQASABIAEQAgACIALAAvACkALgAZABsADwAPAAIABAAaABwAGAAYAAIABAD1//X//v/+//f//P/t/+r//P/9/xEAEgD8////AQABAAUABgD+//v/+//+/xMAEAARABYADwAQABIAEAANABAABgADAAQABAADAAUADQAKADEANAAzADQAFQAVAPb/9P/+//z/AQACAPv/+/8DAAMAAAAAAP7/AAASABUABgAHAPz/AAAPAAsAEAAZAPD/6f/K/8//9v/v//v//P8CAAMALQAuABwAHgD1//X////9/wgACQD4//P/5f/m/wIA/P8UABgAAgD+/wIAAQALAAoADAAPABMAEwADAAgA+v/1//P/9f/z/+//4//l/+D/4P/4//f/AgAGAAcABgD9/wEA5v/p/+v/5//6/wEADAAGAPn//P////v/FwAYABMAEgD4//f/BwAHAAwADgACAAEACQAJABkAFwAWABYABgAFAAIAAAD7//z/+P/1/w0ADQAZABsABQAGAPz/+//5//r/AAD///L/8P/3//n/BwAFAAsADQD9//v/7P/v//b/8f/9/wEACwAIABgAGgAdAB4AFgAXAAYABAD+/wIA9v/x//L/9f/v/+7//f/6/wUABwAGAAUA//8CAO//7P/o/+n/7f/r//H/8P/p/+r/8f/v/wgACAAHAAkA+v/2//z//P8LAA4AGAAXAAcACgD9//r//P/7/w8AEQAMAAsADQAIAAkADgASAA4A9//9//n/9/8DAAMAFQAYABoAGgAPAA8AEgASABkAGgD+////8f/w//T/8/8NAA8AEgASABEAFAAOAAwABgAHAPv/+v/w/+7/+//5/wgACgAQAA4ADwASAAwACwADAAMA9f/1/+b/6P/g/9z/3f/f/+3/6//8//3/8//0//D/8P8KAAwAEwAVAAIAAwDt/+3/+f/5/wEAAQD1//X//f/8/w4ADwACAAIABwAJABkAGAAVABYADgANABUAFQAaABwABAAAAPz/+v8XABgABAACAOz/7v8RAA4AKgAuABwAHQD7//r/6v/o/+v/6f8AAAEAHAAfAAUAAgDv/+//FwAaACIAIgD9////8P/t//r/+/8HAAkABAADAAAA/f/w//D/BQAEABgAHAD0//H/2f/c//b/7//8/wIADAAIABQAGAAUABMA5//o/93/2v8CAAYA9v/y//D/9P8SAA8AEwAYAAMAAgD5//v/BQAAAAgADQAUAA4ADgAWABsAFQAkACoAJQAiACAAIgAlACQAEwAUAAEAAQAGAAgAJAAlABkAHAAQABAAHAAiAAgAAwD2////AwD///7/AwDy//D//f/+/xMAFwAJAAgA8P/z//n/+P8EAAUA//8CAAAA/P/6//3/BAABABEAFAAUABIA+P/7//T/8P8SABYAHQAcAB4AIAAsACwAFwAYAP3//v8MAA4AFwAXAAYACAD///7/DAASABgAFgAEAAoACQAEAAkADwAKAAkA/f8AAAEA/f8HAAkAFQAUAAwACwAEAAcAEQALAB8AJgAbABUADgATAA4ABgAFAAsACgADAA0AEQAUABMADwANAPX/9f/n/+f//////wEABAD6//n/AwAEAAYACADw/+7/5v/p//L/8P/6//z//f/8/wEAAAD+/wIACgAIAAoADAD//wAA/v/7/wAABAAGAAEAAgADABUAEgAaABwADwAOAPX/9v////v/CwARAA8ADADy//X/4//d//b/+f8MAAoA9P/4/9v/1f/w//X/EwARAAoADwD9//z/AQD+/wcACgAJAAoACAAFAPj/+f8AAPz/BwALAAkACAAFAAYAFwAUABUAGQADAP//8//1/wEA/v8FAAUA9//3/+v/6P/6//3/FAASABEAEQAXABcAFgAXABAAEgAPAA0A/f/+//j/9P8IAAwAHgAcAAoACwAJAAkAFQAVAP7//v/p/+v//v/7/wQABwAEAAIAAwADAP7//f/2//b/9P/y//n//P/y/+//4f/j//D/7v/+//////8AAPT/8//x//H/8P/x//j/9v/9////7//t/+n/6P8WABgAIQAgAAAAAgADAAIAEQATAAAA///j/+P/+//4/wwADgDt/+z/+//5/xwAIAAHAAQA//8CABAADgAMAA4ACgALABIAEgAaABsAFQAUAAMAAwAAAAEABwAFAA8AEgAEAAMACgAMABAADgD//wMA8f/s//r///8JAAEA8v/4/wAA/P8NAA4ABwAJABEAEgALAA0A/P////n/9//7//7//f/9//z//f8FAAQA+f/7/wYABgAKAAsA9f/0//f/+f8IAAgABgAHAP7//f8HAAcAEwASAPj/+f/7//v/DwALAAgADAAJAAUAHQAgACAAIQAZABoADAAMABMAFAAXABcA/f/9//D/8f8EAAIABAAIAPb/9P/0//b/+v/6//j/+f/9//7/AwAFAPr/+P/q/+n/9//2/wYABgD5//j/+P/5/wQAAwATABYAFQATAAcACAD+//v///8BAPr/9//j/+X/5//f//D/9P8DAP//CwAOAA4ADgALAAwA/f////H/8P/u/+7/+//7//v/9//+/wEAEgAQABgAGwANAA8ADAAJAAcADAAOAAwACgANABQAEAAYABsAJAAgAA4AEQAJAAYAAgAAAAMABgARAA8AFgAbAA8ADgD3//f/AgAEABsAFwABAAYA///7/wsAEgAOAAoABAAIAAcABwAJAAoABgAJAA4ADQAGAAoAAwAAAPz/AQD+//n/+/8BAA8ACwAPABQAEQAPABQAFQAeAB8ADAAMAPz//f8KAAsA+f/6/+//7//4//j/AQAEAAAA/f/2//r//P/4//z/AgD6//T/9P/4/wYABAANABAAFAASAA4AEAARABEABwAHAPz//P/6//j/AQABAA8AEAAfACEAHAAdABsAGQAYABwAEgAQAAQABAD8//v/AQAAABAAEQAZABsA/f/7//n/+/8NAAwABgAJAOf/5//s/+n/9P/1/wEA//8FAAYADAALAAIAAQD7//r/BwAKAAMA///y//X//f/5/wIABAAAAPz/8f/0//b/7//w//X////6//f/+v/+//3/DgAPAAUACAD8//j/9f/6//7/+f/9/wEA+v/4/wAAAAD7//z/CgAKABQAFQAQABEADQAOAAkACAASABAAEAASABMADwAHAAsAFQATACAAIQAQAA0AAQAEABYAEQARABcABAD//wMABQAFAAMAAgACAP3//v8BAAAA8P/z//L/7/8CAAUABgAGAPv/+v/1//j/9P/w//L/+P/5//T/+/8AAP3/+P///wQABgAEAPn//P/0//L/AAABAAIAAQABAAIAAQAAAAoACwAEAAMA9//4//v/+P8FAAoAAAD6//n//f8OAAwABQAFAPj/+f////3/DwARAAoACgD///7/AgADABUAFgAPABAADwANAAsADQAGAAYADgANAAgACgAGAAMAAQACABAAEQAJAAgAAgAEAA8ADQAWABgADAAMAP3////5//f/7P/t//L/8P/+//3//v8BAAQAAgD5//n/8v/0//7/9//7/wEA/P/3//r//P8JAAcADQANAAAA/v/+//7/+//7/wUABQADAAQABgAFAAMABQANAAwADQAPAAkACQAJAAcACgAPAAUAAgAKAA4ABgAEAAMABwASABUAEgARAPX/9//v/+z/AQAFAAcABwD+//7/CAAHABwAHAALAA4ADwAOABIAEwD5//f//v/9////AQADAAEA/f/7/wsADAAVABQA+f/8//b/9P8CAAMABgAIAAgABwACAAMAAQACAA4ADAALABIACQAGAPb/+f8BAAEAEAARABUAGQATABIACQANAA0ACwALAAsA/f/+//f/8f8CAAkAHAAXABQAGgAPAAsACQANAAgAAwAJAA8AEgAMAAsAEAANAAoABwAIABIAEgAVABcADQAMAAoACgAWABgAFQAWAAsACwAUABYAIgAfABIAGQAHAAQACAAMAAkACQD///3/GgAeAB0AHwAHAAYACAAOABgAFAAJAAwA8f/y/////P8LAA8ABwAHAAEA//8KAA8AEQAKAAMACgAFAAIA/f////r/+f/5//r/9//0/+7/7//7//f/DAASABEADgD6//z//P/7/wMABwAAAAAA/P/+/wAAAAAJAAgACQAMAA0ADAD6//n/8//0/xcAGQAZABkA/v8BAP7/+v8RABUAEAAOAPf/+P/9//b/+v/+//T/8P/+/wEABgABAPf/+P8HAAQAIAAgAA8AEAD///r/AQAEABIADQD2//j//P/4/wUACAAHAAYACwANABEAEAD6//r/7//u//n/+v8BAAAA7P/r//H/8f8LAAoA+f/5/+7/7//7//f/+//9//r/9//9////BAACAAIAAwD8//j/BwAJAAEA/v/4//f/+f/3/wQAAQAFAAgACwAJAP7////4//b/+v/5//3/AAD4//f/+f/2/wgADAALAAcA9//8//j/9f/6//7/BgADAAAABwAIAAUAAQAFAP/////3//T/+v///wMA/v/5//z//f/4/wYACwAVABEACgAOAP///P/1//X/+v/6//z//P/8//v/8f/w//T/8f8CAAQABgAHAAEA///3//v/AAD9/wQABgAQABEABQADAPb/+f8FAAEAEgAYABYAEwD//wQAAAD8/wQACAAUABQAEwATAAAAAAD3//X/AgADAAUABgD8//r///8BAAoABwAOABIACgAIAAIAAQAGAAYAAgAAAAMABwD9//n//f8AAAIAAQAPABAADgAOAAEABAD6//n/+f/8//v/+P/6//7/DAAJAAAABQD5//T/9//5/wcACQAHAAYA+f/8//b/8v8CAAMABQAJAAIAAQD5//n/AgAEAAIAAAABAAIA+v/6//////8BAAEA/f/9//f/9//4//f/BAAFAAoACgAAAAEAAAD/////AAD///3/AQAFAP7/+/8AAAIAAAD//woACgAEAAYABAADAAkACgD9//3/+P/4//X/8//8//7/AAD//wkACQAJAAoA8v/w/+//7//8//7/AAD9//7///8GAAkADQAIAAYADAAHAAQACwAMAP3//f/5//j/AAAAAAgACgASABEAFAAWAA0ACgAHAAsACgAIAAMABgD7//j/AwAGABwAGwAFAAcA+//4/wkACwAGAAUAAQACAAMAAwAEAAMADgAOAAkACwAIAAYAEgAVABUAEgD2//r////8/w8AEwAGAAUA/f/8//r//P8OAAwADgASAPv/+P/5//b/AwAHAAoABgAAAAUA+v/0//b//P////j//P8EAP7/+v/+//7/AQACAAMAAAADAAYABAADAP/////6//r/AgAAAP7/AgAEAP7//f8CAAkABgABAAMACQAHAPf/+v////r//P8AAAUAAAD7//7/+P/3//j/+P/1//X/+//5/+3/7v/5//f/EgAWAAwACgD5//r/9//2/wIAAwADAAQA/v/9//7/AQANAAoADAAOAAQABAANAAoAAwAJAPr/9P/6/wEAAgD///z//f/7//r/AwADAA0ADwALAAoA/v////3//P/4//f//P/9/wcABwAHAAcAAAABAAAA/v8CAAQAEAAOAAkADAAEAAIABAAGAAMAAgD7//n/+v/9/wUAAQAAAAIA9//3//j/9P8BAAQA/f/6//z//f8FAAUABQACAPn/+/8GAAMAAgADAAQAAwADAAEACAAKAAAA/v/0//X/BgAEAAoACgACAAQABwADAAcACwAHAAMABQAIAAkABgADAAMA9v/3//3//P8GAAUA/v////f/8v/8/wEA+v/3//7///8EAAQAEAAOAAMABgDx/+7//f////7//f/r/+3/9v/z//3/AAD///3/BQAGAAcACQAGAAIA9f/3//X/9f8BAAAA8//3//z/9/8BAAYABwAFAAUABgD8///////5//r/AQAGAP//+P8AAP7/+P8FAAoABgAFAAYABgD//wIAAAD7/wIACAAJAAUABwAIAP3///8CAP7/EQAVAA0ADAD///v///8EAA8ACwADAAYAAQD+/wEAAgAZABYADwATAAwACQAXABkADgANAPD/8P8EAAIAAgAFAP3/+v/7//3/BwADAAMABgD4//T/+//+//z/+P/v//H/8f/u//T/9f/5//j/CAAGAAsADQANAAsABQAEAAwADgAGAAMA9P/3/woABwAPABIACgAIAAsADAAMAA4AEAAOAAUABwAFAAUAAgADAAQAAwD+/wIADAALAAgACQD//wAA/////wAAAAAEAAcAAQD//wgACQADAAMABgAGAA0ADQAVABgAEgAPAAQABQANAA0ACwANAA4ADAACAAUABQACAAgADAD///7/AwADAAwADAAFAAUA/P/+//3//f/+/wAAAgAAAAQABAAHAAoABQADAP3/AQAIAAcABQAGAP7/AQAEAAIABQAHAAwACQALAA8AFAANAAcADgAGAAEAAwAHAAsACAD//wEAAAD//wIABQAMAAsACAAIAAQAAgD6//3/BQACAAIABwD+//r//P/9/wYABwABAP//BgAJABEAEAAQAA8ABQAHAAkABwAPABMADwANAAsADQAIAAgAFQAVABIAEgAbABsAEQAQABEAEQANAA0ACAAJAP3/+f/9/wAA/P/8/wIA//8LABEAEQALAAgACgACAAQABgACAAMACAAJAAUABAAHAP///f/6//n/9f/3/wIAAAAJAAsABAACAPz////9//n/AQAEAPj/9v/s/+z/9v/3/wcABwD4//f/8//z//n/+f/6//n//v/+/wAAAAAAAP//BQAHAAYABAAEAAUACgAKAAMAAwD6//r/DAAMAA8AEAAHAAYAAAD//wEAAAAKAAwA//////v/+v/9////CwAIAAkADAAKAAgAAwAGAAMAAQD//wIAAgABAPv/+//2//b////+/wgACwD8//n/+//8//7//f/8//z/9f/2//7//P/4//r/8v/w/+z/7v8KAAUA+v////X/8f8DAAMA/v////z/+v/9////BgADAP//AQD///3/AwADAAUABQD7//n/AAACAAIAAAD8//3/+//7/wAA//8DAAUACgAHAAcACwAPAAoABAAIAAUA//8IAAwAAwACAP3/+//2//b/AQABAAAAAQAIAAkACwAKAAMABAAEAAIABQAHAAYABAD3//n/+v/5//n/+/8CAAEA+P/5//f/+P/8//n/BgAKAAMAAQAAAAIACgALAAsACQAAAAMABgADAAQACAAKAAcAAAAEAAIA///9//////8AAAgABgAEAAcACgAIAAsADQAQAA8ABgAIAAQAAwABAAIABAAEAAAA/f/8/wEAEwANAAYADgD+//f//v8DAAIAAAD//////P/8/wQAAwAMAA0A+//6//j/+v8AAP3//f///wAA/v8DAAMACQAKAAoACQAFAAYAAAAAAAEA//8FAAYABQAFAAEAAQAOAA8ADwAMAP7/AAD7//v/AgADAAQAAwD7//3/AQD8/xQAGwALAAQA9//8/wAA/f8BAAIA9//3//7//v8KAAoABwAIAAgABQD//wUABgACAP7/AwABAP//AwAFAAcABgAIAAgABQAGAAIAAAD+/wIA+f/2//v//v8BAAAAAgABAAMABQAUABEACAAMAP//+//8//7/AgADAP///P/6////AgD9/wcADAAQAAwABAAFAP////8GAAQACAALAA0ACgD//wIAAQD//wQAAgAFAAgACwAJAAsADQALAAkAAAAAAAcABgALAAwACQAIAP7//v/z//P/+P/3/wcABwD9//7/9//1/wAAAgADAAMA9//1//j/+v/7//r/AgADAP7//v8CAAMACAAIAAIAAQDw//D//v////7//P/7//3////8/wQABgADAAQACAAIAAMABQABAP7/CAALABMAEQABAAUAAQD+/wEABQALAAkACwANAA4ADgAMAAwACAAGABYAGAATABEAAgACAAkADQAHAAQAAgAEAAsADAANAA0ACwAMAP//AAAHAAYABAAGAPz/+v/9//3/+v/7//n/+f8AAAEA9v/2//b/9f/8//3/EAAPAAoADAD9//n//f8CAAAA/P/y//X/9//2//n/+P/5//n///8AAAkABQAFAAgABQACAPT/9v8GAAUA/P/9//b/9f/+/wAACwAKAAcACgAAAPv/AAAEAAkABwAIAAkABgAGAAgABwAEAAMACwAMABIAEQAKAAwABgADAAYACgALAAgABQAHAP///f8MAA0ADQAPAP3//P8EAAQA/v/9//7//v///wEA/P/7//r/+//y//L/CAAIAP//AADx//H/AAABAAYABgD7//7/9f/y//3/AQAAAP7/BQAFAP7//v8DAAUA/f/5//z/AQD4//X/+v/9/wEAAAAEAAQA/f/+//v/+/8EAAMACQAMAAYAAwD0//b/+f/6//7/+//5//z/+v/3//r//v8CAP3/BQAKAAIA/v/5//v/AgAAAAcACQAFAAEAAAAEAAYAAwD8//z//////wIAAAAEAAQA/f/+/wQAAQAIAAoABgADAP//AgAGAAYACQAIAAMABQACAAAABgAHAAYABgACAAEA+v/9/wgABgD//wIABQACAA0ADQAKAAwA/P/4////BQAHAAEA/v8GAPz/9f/6///////8/wQAAgADAAgABgABAPv//f8BAAIABwADAAUACwAJAAUACwAOAAwACwACAAMA9P/1/wkACAATABQAAgABAPz//f/9//3//v/8//3///8FAAMAEwAWAAwACAD6//7/DAAHAAYACwAKAAgA//8AAAEAAQAEAAMAFQAWABYAFQD8//7//P/5/xEAFAABAAAA+P/1/wAABQAHAAQA+//8//r/+//9//z/AQAEAPL/7//0//b/CgAJAAEAAAD6//7/CAAFAAIABAD4//r//f/4//n/AAD+//n/+f/8/wkACQAEAAQA/f/+/wQABgAHAAMA+/8AAPv/+P8AAAIACwAKAA0ADwAFAAMABQAIAAoABwAHAAgACAAIAAsACgAJAAwACQAIAA0ADgAPABEADAAJAAoADgAMAAgADQAQABAADQAFAAcABQADAAUABwAEAAIA/P/8//v/+//+//3//v////z/+/8IAAcAAAD//wAA//8IAAgAAQD+/wMABQD9//n/AQACAAQAAAADAAcACQAEAAMABgAOAAwACQAHAAAAAgAGAAMA//8BAAIAAQD6//r//v8AAAcAAwADAAcAAQD8//r//v8CAAEABgAFAAEAAwAFAAMABwAJAAoACgAIAAYABAAGAAMAAgAAAAAABAAHAAYAAwAFAAcAAAD+/wEAAwD9//3/+f/6//f/9f/6//3//f/7//v//P8AAAEAAAAAAPf/9v/4//z/+v/1//j//v/2//P/9//4///////3//f/9P/0//3//v8DAAMAAQAAAPr//P/+//3/BQAEAP3/AADw/+3/8f/0//3/+v8AAAIA/P/7//3//f/2//b/AwACAP3//v8BAAAA+v/5/wAAAgD5//f/AAADAAEA/v/x//L/+f/4//z///8IAAIA+////wcABQAEAAQAAQACAPb/9P/+//7/AwAEAAcABQACAAQAAwACAAkACAAHAAcAAwADAP3//f8CAAEA/////wQABAAFAAMABAAGAAMA//8CAAUA///8//z//P8DAAIAAgAAAAUACQAGAAMABAAGAAcABQAIAAoACAAGAAIABQAIAAUAAgADAAsACwAJAAgABAAEAPz//f8IAAUA/v8BAAIA/v8DAAgABwACAAQACAAFAAMA///+/wMABgAKAAcA//8DAAcAAwADAAUAAwAEAAIA/v8EAAoACAABAAEABgAIAAUAAQAGAAMA//8CAAUAAwACAP3//v8JAAoABAAFAP7//f/7//3/AwABAAQABQD3//n/+//6/wYABQAEAAcA+v/3//3/AQAPABAADwALAP7/BAAIAAUABgAJAAoACgD8//v/AAADAAIAAQAHAAkADAAKAPj/+f/2//b//////wUABgD+//z//v/+/wkACgAAAP///v8BAAYABAD5//n/+v/8/wIAAAAFAAcABwAEAAcACQAAAP///f/9/wkACAABAAEA/P/8/wAAAQAEAAIABQAHAAgABgAKAAsAAQADAAoABQD//wYABAD8//v/AwAFAP///f8AAAUABQAMAAoABgAIAAgABwAGAAcACwANAA0ADgAHAAUA//8CAAYAAwAMABIACQAFAAwADwAMAAoACwAMAAQAAwAFAAYABQADAPz/AAAMAAcABAAJAAUAAQD//wQACQAFAAUACwAAAPv//f8CAP3/+f8GAAkA///9//7///8HAAcAAAAAAAEA/v/8/wEABAD9//r/AgAGAP7/AgAHAPv/9//5//z/AwABAPv//P/4//j////7/wAABgAAAPz//f8AAP7/+//+///////+/wQAAgAEAAcABwAEAP3///8HAAcAAwACAAgACQD//wAAAwACAAYABgALAA0ACwAIAAMACAAHAAIABAAJAAYAAQAFAAkAAQD//wEAAwAEAAMA//8EAAkAAwD+/wcACgACAAAABgAJAAUAAQAEAAEAAAAAAAMAAwAAAPz/AQD7//b/+/8AAAMAAADy//P/9v/2//3//P/+//7//v/8//j/+f/+//3//P/7//r//P/4//b//f/+//3//f/7//r//P/+/wQAAQD9/wAA/P/5//n//P8EAP7/BAAJAAYAAQD//wMAAQD9/wIABQABAP7/AAAEAAYAAgAFAAgABwAFAP//AAD9//3/CAAIAAYABAADAAMABgAFAAYABwABAAEA/v/8//n/+f/4//n/+f/4/wMABQABAP7/9//5/wYABQAIAAgA/v/9//3//P/8//3//v/+//L/8/8AAP7/+v/7//3//f8CAAIADAAMAP3//v8BAAEAAgACAP3//f/5//r/+v/7/wcACAABAAEAAgABAAIABAAFAAQAAwADAAMABQAGAAMAAwAFAP7//P///wAAAwAFAAgABgAPABAADQALAAUABwAHAAUACAAMAAgABQD//wEABgAEAAMABAAFAAUAEQAQAAoADAD///3/BwAIAAcABwD8//z/AAADAAMAAgAIAAcA//8DAAcAAwAGAAkA/v/9/wUABQD/////AAABAP///f/9////+v/5/////P8DAAcABAABAPv//f/4//j/+v/4//f/+v8BAPz//P8DAAgAAQD9/wMABgACAP3//f8EAAYA///9//3//v/9//z/AgACAAcABgAIAAsADwANABAADwAKAA4ACAAEAPr//v/8//r/CgALABAADgAIAAkABQADAAoADAAMAAsABgAGAAcABgANAA0ABgAGAAIAAgAOAA0ABQAGAAIAAgAKAAkACQAJAAIAAwAAAP7/AQAFAAMA/v/6//3/AwD///v//v8DAAIABgAFAAMABQAGAAIA/f8AAAYAAwD+/wIABwADAAUACQAFAAMA//8BAAIAAgACAAEAAgAEAAIA/v8FAAkADQAJAAYACgAKAAkABwAGAAIABQAJAAYACwAOAAcABwAHAAYABwAJAAkACAAPABAAFgAVAA4ADQD8//3/DgALAA0AEAAFAAEAAAAEAAwACQAJAAoACgANAAkAAwACAAkACQAEAAQABQAEAAcACgAGAAgACgABAP//AwAFAAIAAQAAAAIA+v/3////AwAGAAMA/f/+//z//v8FAP//AAAGAAUAAAABAAUA/v/7/wEAAwADAAAABQAJAAkABQD6///////7/wYACAAGAAYA/v/+/wUABQAJAAwADAAHAAAABQADAP//AAAEAAQAAQD+/wAABwAGAAUABQALAAsABgAHAAgABgACAAQAAgABAPz//P8HAAgADAAKAAIAAwADAAIADwAQAAAA/v/+/wEAAAD9/wMABAD+////BQABAAwAEAD5//b/+P/6/wYABwAHAAUA/P/+//v/+f8DAAQAAwADAAIAAwD3//T/+//+//7/+/8BAAQA///8/wAAAwD8//r/AwAEAAEAAgABAP7/+v/9/wEA/v8CAAQABgADAAAAAAD7//v/+f/4//v//f8CAAAAAAAAAAcABwALAAsACQAJAAEAAAAFAAcAAQAAAP7///8CAAAABQAGAAMABwAGAAMAAAADABAADgAJAAoA/f8AAAsACAAKAA0AAgACAAIAAwAJAAoABwAGAAAAAAAEAAUADQALAAAAAwD///v/DQAQAAcABAD4//v/BgACAAYACwAIAAUA+v/9/wEA//8HAAgAAAABAPv/+v8FAAYAAQABAPv/+v8CAAIABgAGAAAAAQABAAAACAAJAAMAAgD5//f/+P/9/wgABQAKAAsACAAKAAgAAwAGAAsAEAAMAAoADQADAAMAAQD//wUABwD///7//v/9/wYACQAIAAUACAAJAAoACQADAAIAAAABAAEA//8GAAkA/f/7//7/AAAJAAgACgAKAAAA//8BAAAAAgAEAAQAAQD7//7/AQD+/wgACAABAAEAAQD//wQABwAEAAAA/v8BAAEA//8DAAQA/////wIAAQAFAAcAAQD//wYACQAIAAQA+f/9//7/+/8DAAYABgAFAAQAAwAGAAkACAAEAAEABgAGAAIACAAKAAcABQD+/wAADAAJAAQABwAIAAUAAQABAAcACgAKAAYACAAMAAwACgAGAAYAAAABABAADgARABQACAAGAAIABAALAAgABwAKAAkABgD+/wMAAgD+/wMABQALAAsACAAKAAYABQADAAMABQAFAAMAAwABAAEAAgACAAgACgAGAAUA/v/+/////v8IAAkABQAEAAMABQAKAAgABwAIAAcABwAIAAYAAwAGAAYAAwAIAAsAAgD///v///8DAP3/BAAKAAQA/f8EAAwADQAGAAUACAACAAAACQAKAAEAAgABAP//AAABAAEAAAABAAIACQAJAAQAAwAGAAgABAACAAMABAD9//3/AgABAAIAAwD///7/AwAEAAQABAACAAAAAgAEAAkABQACAAUA/v/7//7////8//v/BAADAPj/+P/9//v/AAAAAAYABQD5//r//P/5////AwADAP//8P/z/////v8EAAEA+f/8/wAA/f///wEA/P/6//3//P8DAAUACAAGAPz//f/6//j/BAAFAAEAAgD9//7//P/9/wMAAgD+////AAD+//r/+/8BAAAAAAAAAAAAAgACAP//AAADAAUAAgD8//7//f/9/wEAAQABAAMA+v/2//v//v8MAAkAAwAEAPj/+P8GAAYACAAHAPX/9v/9//3//P/7/wAAAgD9//r///8CAAUAAwAEAAUAAQAAAPz//v/9//n/+f/9/wQA///8/wIA/v/7//T/9v8AAP7/AAACAAMAAQD//wEA+v/5//f/9v8CAAEA/P/9//z/+v/3//r/BAABAP7/AAD+//3//f/+/wkABwACAAUAAgD+//n//f8CAP3/AwAGAAUAAwD9/////f/8/wYABwAGAAMA/v8CAAIA/v/7////BAABAP3/AAABAP7/BwAIAAwADwAJAAYA//8FAAcA///9/wUABgACAAkACgABAAMABwADAAIABgAKAAgABQAHAAUABQD6//n/AgAFAAkABgABAAUA///7/wgADAAIAAUAAQAEAAYAAwAHAAsADAAHAPz/AgACAP3/BQAIAAQAAgD8////AgAAAAAAAQAHAAgAAgD//wEABAAAAP///////wIAAgAIAAoA///7/wgADQAKAAQACQAPAAgAAwAIAAwADQAJAAQABQACAAIABQAFAP7//f8CAAQABAAAAAIABgD7//n/+f/5//z//f8IAAQA//8FAAIA/P8DAAcAAgD9//T/9/8BAP//CAAJAAwACwAEAAMAAAABAAQABAAGAAUAAgADAAYABQAMAAsABgAKAAgABAAFAAcAAAAAAPz//P8BAAAA/f///wYABQANAA4ABwAKAP///P8JAAwACgAJAAQABAACAAMACQAIAAoACgAGAAYABwAGAAUABgACAAQA///+/wMABAAGAAQABwAJAAYABwAHAAYAAwAGAAgABAAAAAIABgAHAAAA/v8BAAEABQAHAAgABQD//wQABgAFAAsABwACAAkABQD+/wEABQAGAAYADAAKAAUACgAGAAEA/P///wYABQAIAAkABQADAAEABAADAAAABwAKAAIA/////wIABgACAAkADgAHAAMABAAGAP7//v8DAAEA//8CAAAA/v/3//f//f/+/wYABQACAAMABQAEAAMAAwAHAAUAAAADAAAA+//4//3/BAAAAP7/AgAEAP//+/8AAAEA+////wMAAgAAAAAAAAD5//v//v/7//7/AQADAAAA/P/+/wUABAACAAMAAwABAAQABwABAP3//f8BAAEA/v8AAAIA/f/8//7//f8CAAUAAQD9////BAAEAP///v8AAPr/+v/9//r//P8BAP7/+//6//v//P/9/wAA/P8AAAYAAAD7//r///8GAP//+P/+/wIA/P/6/wEADAAFAP7/AwAIAAQA+P/9/wQA/f/2//7/BQD+/wAABAAIAAcA/v/+///////6//n/+P/3//f/9v8CAAQABgAEAP//AAD+////AwAAAP//AgD9//r///8CAP3//P8EAAIA+////wQA//8DAAgAAQD+/wIAAgAHAAgADgAMAAEAAgD8//z/+f/4/wEAAgD+//7/AgABAAIABAAJAAcAAgACAAQABAD8//7/AQD+//r/AAAEAPz//f8FAAsABQABAAUA/P/5//7/AAAIAAcA/P/+/wAA/v8GAAgADAALAAoACwABAP7/BgAJAAQAAgAAAAMABAADAAIAAgAFAAQACQAMAA4ACwAEAAUA/////wAA//8CAAUABwAEAAEABAAGAAMAAwAGAAkABwAIAAkABQAFAAUABgAEAAMAAwAEAP7//f/8////CgAIAAkADAAEAP7/AAAHAAgAAAACAAkABQAAAP7/AAD///7/+f/5/wMAAgACAAQA///7/wMABwAIAAQAAQADAP////8HAAcABQAHAP///f8BAAIABgAFAPv//v8BAP3///8DAAQAAQACAAMAAQABAAcABQAFAAYACAAIAAUABAD//wIAAAD8//v//v8FAAMABAAEAPz///8DAAAAAAACAAUAAgD7////AgD9//v///8DAAAABwAHAAEABAABAPv//f8CAAUAAQD8//3/+v/8//7/+/8IAAsABAABAP7/AQACAP7/AwAIAAcAAgD5////CAADAAcACgAHAAUAAAADAAoACQAIAAsAAwAAAAMABQAFAAQAAwAGAAQAAwAEAAUABgAGAAMABAANAAwABgAIAAEAAAADAAQABwAHAAIAAgACAAIAAQACAAgABwD+//7/AgABAAMAAwAEAAUABgAFAAMABAACAAEA/v/+//3//P8BAAAAAwAEAAoACQAFAAYAAwAAAAAAAwAGAAMA/v8DAPr/9//7//3/AwABAPz//v////3//f8AAAYABwAGAAUA/v/+//7///////3/BQAKAAEA/v/3//j/+v/7/////P/7////BQABAP7////9//7/BQACAAYACQADAAIA+P/1//f/+/8CAP//AAAAAP7///8GAAUABQAEAPz//f8FAAIACAAJAAIAAgAAAAEAAgD///v/AAD8//b/+f///wAA+//9/wAAAgABAAIAAgD4//n////+/wEAAwAEAAQA+f/6//v/+//8//z/+//9//3/+v/+/wIABQACAPv//P/9//z//v8AAAEA///+/wIA/v/4//P/+f8CAPz//v8EAAQA///9/wEABAD//wIAAwAFAAQAAQABAP7///////3/CwANAAUAAgD4//r/+v/5//7//v/5//n//v/+/wAA//8DAAMA/P/9/wIAAQD+/wAAAAD9//z//v//////+//6/wEABAACAP//AgAEAP7//v8LAAoABQALAAQA/f/8/wQABAD9/wMACQADAP//AQADAAAAAAAFAAIABAAIAAwACAD8/wEAAAD6//v/AAADAP//AgAGAAIA/v/9/wAABgADAAYACgAJAAYAAQADAP3/+//9//3/AgACAAEAAQD8//z//P/8/wUABQAOAA4AAwAEAAIA/////wQACAACAAEABwD8//j/AgADAAcACgAOAAkA//8FAAEA/P/+/wIA///+/wYABQAFAAcAAgABAAcABwANAA0AAwACAPH/9P/7//f//v8DAP//+//4//n//f///wMA/v/9/wIACAAGAPz/+//0//f/AAD6//7/BAD9//j/+f/8/wMAAAAAAAAA+f/7/wMAAAD6////AAD8////AQD4//j//v/6/wAABAAQAA0ADAAPAAcABAAEAAYAAwD+//z/AAD///7/BQAFAP7/AQAAAP3/AgAEAAcABwAEAAIA/f///wEA//8DAAUAAAACAP//+/8EAAoACAACAPj//f8CAAAACQAIAAIABQABAP7/BAAGAAwACwADAAIAAgACAAIAAwAFAAQA/v///wIAAAAEAAcABwAFAAcACAAAAAAABgAFAAQABQAAAP//AwAFAAoACAAJAAsABQACAAEABAAEAAEA//8DAAUAAQACAAcACgAFAAoAEAAQAAsABwAKAAEAAQAHAAcAAwAFAAEA//8IAA0AFgARAAYADQAGAAAA/f8BAAwACgABAAMAAQAAAAQABQD/////BAADAAQABAADAAQAAAD+/wMABQAIAAQAAwAHAAoABgD9/wEA/f/6//n/+v/+//z//v////v//P/9//v/+f/9/wEA/P8EAAgACQAFAP7/AQD9//v/BQAGAPz/+////wEA/v/7/wAABAD7//n//f/+/wIAAwD9//z//P/9//7//f/+/wAA/v/7//3/AAD///z//f////7//v8BAAEA/f/+/wIAAAAFAAcABwAGAP3//v8CAAEABQAFAAAAAAD9////AgD/////AgD///v/AQACAAEAAAD9//v/9//6//v/+P/7//7/+//4//z///8BAP7//f/+//7/AAAEAAEA/v8BAPr/9//8//v/AAADAPv/+f/2//b//v///wQAAwABAAIAAAAAAP///v8AAAAABQAGAP///v/7//7//f/6/wAABAD+//z//v8AAP///v8DAAMA///+/wIABAAAAP7/+v/8/wIAAQACAAIA/v/8//r//P8EAAIABgAIAAIAAQAEAAQACAAHAAEAAwACAAEABQAEAAgACgAGAAMAAAADAAUAAwACAAMAAgACAAAAAQACAAEABAAEAAkACgD/////AAD///z//v8JAAYA/f8AAAMAAQABAAIABwAHAAMABAAFAAEAAQAHAAYA//8AAAcACAADAP7///8DAAUAAwAAAAIABAD+//3/AgADAAMAAgD9//3//v///wMAAQD9/wAA///8//z//f8BAAIABwAHAAoACAACAAUABQABAP7/AQADAAAA9//6/wQAAwACAAAAAAAEAAMA/v8CAAcAAwAAAP3//v8EAAEA//8CAAQAAQACAAQAAAD///v//P8EAAIAAAADAAIA/v/9/wAA/P/7/wIAAwAEAAIA+f/9/wMA/f8DAAkACAADAAAABAACAP//AgAEAAIAAgADAAIADQAOAP3//P/7//z/DAALAAwADgAEAAIA9P/3/wEA/v8DAAcABQACAAEAAwAAAP//AwADAP//AAAFAAQA/v///wIAAQD7//v//f/+//3//f/8//v/+P/5/wEA//8EAAkACgAGAPz///8EAAAABgALAAkABgAGAAgAAQD+//3//f8DAAUAAgAAAPr/+//7//v/BAADAP//AQACAAAA//8AAP/////4//f/+P/5//z//P8CAAIA/v///wcABAD+/wEABAADAP//AAAAAP//+v/6////AAADAAIAAgAEAAsACAD8/////f/7/wAAAgD8//3/AwABAPf/+/8DAP//AAADAAIAAgACAP3/AQAJAAQA/f/+/wMA/P/5//3//v/+//3//f///wEA//8EAAQA//8AAP///P/9/wAA///8//3////+//3/AQABAAEAAQD+//3//P/9//3//f8BAAEA/f/9/wIAAwACAAEABQAFAP3//f/4//j/+v/6//z//f8AAP///f8AAAMAAgAEAAQAAgACAP///////wAA///+////AAD///7/AAACAAMAAQABAAQAAgD8////BwAHAP7/AAAHAAYA//8AAAYABQD///r//v8BAP///v/9//3/AgD///j//f8CAP///P///wEAAAD///z//P8BAAAA/////wEAAwAAAP7/AAACAAgABQD+/wIAAQD+//3/AAAFAAMAAAAAAP//AAADAAMAAwABAPz////8//n//P////3//P/7//j/9//8/wAA+/8GAAoAAQD+/wAAAwABAP7/BQAGAAEA///+/wAA/////wAA///8//z/BgAGAPv/+//7//v/+v/5/wAAAgD8//r/9v/4/////f8DAAQAAQABAP7//v8EAAMAAQADAAYABAD+/wAAAwABAP//AgD///v//v8CAAMA//8BAAQAAQABAAkABgACAAYAAwD///3/AAAFAAMAAwAEAAUABgACAAMAAgACAAQAAwAHAAkAAQABAP///v8IAAoABwAFAAEABAAFAAMABwAJAAQAAgAEAAQABgAJAAQA///6/wAABwABAAYACgADAAAAAwAHAAkABAAEAAgABAAAAAYACAACAAEAAgAEAAMAAQAJAAsABQACAAIABQAAAP7/AwAFAAQAAQABAAYA/v/7/wEABQABAP7/CAAIAAIABAACAP///v8CAAYAAwAAAAEABgAHAAkABwAKAAwABQAFAAQAAwAEAAQAAQABAPr/+v/+/wAAAQD+//7/AAD6//n/9//2//n/+/8GAAMAAQAEAP///v////3//v8DAAMA+//z//z/AQD5//r//v8EAAEACAAIAAMABQD8//r//f/+/woACAD9/wAABQABAP3/AQACAAAA/v/+//7/AQABAPz//P///wEAAAAGAAgAAAD+//7/AgABAPv/AwAJAAUAAAD6//7/AQD+/wEAAgAFAAgAAgD+//f//f8FAP//AQAEAAAAAAABAAAAAQADAAYAAwACAAQABQAEAAUABgAFAAUA/v/8/wAAAwACAP//+v/8/wAA//8CAAIACgAKAAIAAwALAAgABQAIAAIAAAD9//7/+//6/wEAAgAAAAAABwAGAPz//v8IAAUA/v8BAAEAAAACAAEABwAJAAcABAADAAYACAAGAAkADAD+//z//v8AAP//+//7/wEA/f/3////BAABAAAAAwAAAAUACAADAAEAAQACAP3///8CAP7///8DAAQA//8DAAkA///6/wEABgAIAAMABQAIAPr/+f/9//z//f///wUAAgD9/wAAAAD9/wAAAgADAAAA//8CAAcAAwABAAYAAAD6//7/BQADAPz/AgAHAP///f8EAAQABgAHAAIAAAD8////AQD+//3/AAD///v/AAAEAAQAAgADAAIA/v8BAAIA/v///wIA/f/8/wEAAAD8//7/AgABAP7//f8GAAgAAgAAAP//AAAGAAcAAwACAP///f/1//n/AAD7////AwACAAEABQABAAUACgAFAAEAAQAFAP7//P/9//3//v/9//z//v8DAAAA/v8DAAgAAgD+/wMABwADAPv//v8FAAMA+//9/wQAAwD//wAA/f/9/wIABAABAAEABwAHAAUABQAHAAcACQAIAPz//v////3//f/+/wEAAgACAP//BwAKAAMAAQD+/wAA/v/7/wAAAwABAP7/AQADAPz//f8BAP3//P8CAAQA/v8AAAQAAgAAAAIAAgAGAAgACgAIAAUABQACAAQABwADAAQACQAIAAQAAQADAAUABgD7//r/AQACAP3/+////wIA///9/wQABAD+/wEABAD+/wMACQACAP//AAD///7/AQAFAAMABgAGAAQABwAGAAEA/v8AAAgACQAHAAQAAwAGAP///v8FAAQAAQAEAAMA/v///wQAAwD///z//v8DAAUABQD///r/AgD+//b/+v8BAP3/+f8DAAQABQAFAAIAAgABAAAAAAABAAQAAQD//wIA///9/wUABwAAAP7/AQACAAkABgAAAAMAAQAAAAQAAwD+/wEAAAD8//7/AQAEAAMAAQABAAEAAQAEAAMA//8AAP3//P8EAAcAAgD9////BQACAPv/AAAGAAAA+//+/wMABAABAP7/AAD/////AgAAAP7/AQAEAAAAAgAFAAQAAgAFAAUAAAABAAUAAwD9/wAA///9/wAAAAAGAAYAAQACAAEA//8EAAUABQAHAAkABAD6/wEAAwD9/wAAAwABAAAAAQAAAAMABgADAAEAAgACAP//AAACAP//AAAFAAYAAQD9/wEABAABAAIAAwADAAQAAAD//wMAAwAAAAEAAgAAAAAAAgD+//3////+//z//f8FAAUABAABAAAABAABAPr//f8FAAQA/f/+/wIAAQAAAAAA//8BAAAA+v/9/wQA///9/wEAAQD8//7/AQAFAAEA+//+/wIA///9//3/AAABAAEA//8CAAIABAACAAUABQADAAIAAgAEAAYAAAD9/wMABAD8//r/AQAEAAAA/f/+/wEAAQAAAAAAAwABAAUABwADAP//BAAGAAIAAQAEAAIABgAJAAMA/v8FAAoAAwD9/wIABwAAAP3/BAAEAAMABQAEAAIAAwAFAP///f8BAAIAAQABAAIAAgAAAAAA/v/+/wEAAAD+/wEA///+/wEAAAD//wAAAAABAP3//P/+/wIA///5//3/AgAAAPz//f8BAAEA//////7/AQAEAAEA/f/8/wAA///9//7////8//v/AgADAAAAAAACAAMAAgADAAUAAwAFAAcA//8AAAYABQD8////AwABAP3///8AAAEABAADAAAAAwAEAAEA/P8BAAMAAAACAAMAAgAEAAEAAQABAAIAAwABAAAAAgABAP//AQAFAAEA/v8BAAQAAwAAAAQABwAEAAQABwAEAP7/AwAGAAIAAQADAAIAAgAAAP//AAACAAAA/v///wMABAABAAEABAADAAEAAQACAAIAAQABAAIAAAAAAAQAAwABAAIABQAGAAAAAAAFAAYA///+/wYABgD//wEABQAEAAAAAgAGAAMAAAADAAgABgAHAAgABQAFAAYABgADAAIA//8CAAUAAAD+/wQACQADAP7/AwADAAAAAwAEAAMABAAIAAMA/v8DAAcAAQD+/wMACAACAAEABAADAAAAAgADAAUAAwACAAQAAgAAAAEAAgABAAAABAADAP//AQAFAAMABQAFAAIAAQAGAAYAAgADAAAAAAAFAAMAAgAFAAQAAQAEAAYABAAEAAwACAAEAAYABwACAAIABgADAAAAAgAEAAUAAwAFAAUABwAIAAYABwAFAAMAAgADAAAAAAAAAP///v8AAAcABQABAAAAAwAEAAIAAAAGAAYAAQADAAYAAwD//wIAAAD+/wIAAQAEAAUAAwABAAIABAAEAAQABAACAAIABQAAAPz/AQAFAAIA//8AAAMA///+/wMAAQD+/wIABQABAAEABAAEAAIAAgAEAAUAAgAAAAMABwACAAEABQAGAAQA//8AAAQABQABAP7///8CAAEA/v8DAAcABQACAAAAAwADAP//AwAGAAEAAQAEAAUAAgABAAMABgAEAAAAAwAIAAUAAQAHAAkABQADAAQACAAEAP//AQAEAAUAAwACAAIAAQADAAYABAAAAAEAAwADAAAAAAADAAMABQAEAAIAAwAGAAQABAAFAAQAAwABAAIAAQAAAP7///8BAP///v8BAAIAAQACAAMAAAD/////AQAAAP3/AgADAAAA//8DAAIA//8AAAYABQD8//3/AgABAPv//P8CAP///v8CAAQA//8AAAQAAwAAAAEAAwD//wAABAABAAAAAAAEAAQAAAD9/wUACgADAP7/BAAIAAIA//8FAAUAAQACAAMAAgABAAEAAAACAAMAAAACAAYAAAD8/wMABQAAAP//AAACAAEAAAD//wEAAgD//wEAAwAAAP///f/+/wAAAAAAAP7///8BAP///v8AAAMAAwABAAIAAgABAAEA//////7///8BAAEAAAD+/wEAAwACAAAAAwAFAAIAAgAGAAIA/v8EAAUA///6////AgAAAP7//P///wMA///6//z/AgD9//n//f8DAAEA+//9/wIA/f/5//7/AgD///7/AQACAAAAAgACAAEABQAHAAQAAQACAAUAAwABAAEAAgACAAMAAwADAAEAAQAEAAQAAgACAAMABAAAAP//AQAEAAIA//8EAAUAAQABAAMAAgABAAQABQABAAAABAADAP//AQAEAAEAAAADAAIAAwAFAAUAAwAEAAYABgAEAAMABQADAAAAAgAGAAUAAwAGAAYAAwADAAUABAAEAAYABgAEAAEABQAFAP7/AQAHAAIA//8BAAIAAQABAAIAAgADAAMABQAFAAUABgAEAAEAAgAFAAQABAAFAAMAAgAEAAQAAwAFAAQA/v8AAAQAAwAAAP3/AwAIAAYA//8AAAQAAwABAP7//f8EAAQA/v/+/wIAAQD//wEAAwACAAEAAQADAAMA///+/wMABQACAAAAAAABAAMAAQABAAIABQAEAAEAAwAFAAIABAAGAAAAAQAHAAMA//8FAAUA//8DAAgAAwD//wEABAAEAAMAAQABAAYABwAAAP7/BgAIAP///v8EAAQAAAABAAEA//8EAAUAAQD//wMAAwAAAAEABAAAAP//AwBMSVNULgAAAElORk9JU0ZUIgAAAExhdmY1OS4yNy4xMDAgKGxpYnNuZGZpbGUtMS4wLjMxKQBpZDMgOAAAAElEMwQAQAAAAC0AAAAMASAFDSs7Vj9UWFhYAAAAFwAAAFNvZnR3YXJlAExhdmY1OS4yNy4xMDAA", stopOtherAudio: false });
                  }
                  if (!current())
                    return;
                  this.append({ role: "assistant", text: "I’m taking a picture." });
                  const announcement = speakWithTiming(this.session, "I’m taking a picture.").catch((error) => console.warn("[generic-ai] photo announcement failed", error));
                  const photo = await this.session.camera.takePhoto({ size: "medium", mode: "photo", transferMethod: "ble", compress: "medium", sound: false });
                  if (!current())
                    return;
                  if (!photo.photoUrl)
                    throw new Error("The camera returned no image");
                  photoId = this.append({ role: "user", photoUrl: photo.photoUrl });
                  image = await loadVinImage(photo.photoUrl, this.session.blob);
                  await announcement;
                });
                if (!current())
                  continue;
              }
              this.setPhase(decision.route === "camera" ? "answering" : "searching");
              result = await this.api("answer", { ...input, route: decision.route, image });
              if (!current())
                continue;
            }
            if (!result.answer?.trim() || !result.spokenAnswer?.trim())
              throw new Error("The AI returned an empty answer. Please try again.");
            this.append({ role: "assistant", text: result.answer, sources: result.sources, afterPhotoId: photoId });
            this.history = [...this.history, { role: "user", text: turn.text }, { role: "assistant", text: result.answer }].slice(-10);
            this.setPhase("idle");
            await speakWithTiming(this.session, result.spokenAnswer).catch((error) => console.warn("[generic-ai] answer speech failed", error));
          } catch (error) {
            if (current())
              this.append({ role: "assistant", text: error instanceof Error ? error.message : "Something went wrong. Please try again.", error: true });
          } finally {
            this.setPhase("idle");
          }
        }
      } finally {
        this.processing = false;
        this.setPhase("idle");
      }
    }
  }

  // src/background/workflowMode.ts
  class WorkflowMode {
    page = "none";
    cameraTail = Promise.resolve();
    withCamera(run) {
      const task = this.cameraTail.then(run);
      this.cameraTail = task.catch(() => {});
      return task;
    }
  }

  // src/background/controllers/GlassesController.ts
  class GlassesController {
    session;
    unsubs = [];
    subscribed = false;
    liveTranscript = "";
    history = [];
    lastButton = "";
    mirrorToGlasses = false;
    logScanTranscripts = false;
    awaitingScanConfirmation = false;
    sttStartedAt = null;
    sttFirstEventLogged = false;
    confirmationEchoDrainUntil = 0;
    confirmationSession = 0;
    confirmationRequestSequence = 0;
    pendingConfirmationRequests = new Map;
    activeQuestionVin = null;
    awaitingVehicleQuestion = false;
    questionRequestSequence = 0;
    pendingQuestionRequests = new Map;
    connected = false;
    constructor(session) {
      this.session = session;
    }
    start() {
      if (this.subscribed)
        return;
      this.subscribed = true;
      const ui = this.session.ui;
      debugLog("[stt] registering transcription subscription");
      this.unsubs.push(this.session.transcription.on((data) => {
        if (this.awaitingScanConfirmation && !this.sttFirstEventLogged) {
          this.sttFirstEventLogged = true;
          const elapsed = this.sttStartedAt == null ? "?" : `${Date.now() - this.sttStartedAt}ms`;
          debugLog(`[stt] first event after start ${elapsed} final=${data.isFinal}`);
        }
        if (this.logScanTranscripts) {
          debugLog(`[stt] ${data.isFinal ? "final" : "partial"} "${data.text}"`);
        }
        if (this.awaitingScanConfirmation && data.isFinal && data.text.trim()) {
          const transcript = data.text.trim();
          const normalized = transcript.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
          const isPromptEcho = normalized.startsWith("successfully scanned vin") || normalized.startsWith("the vehicle is") || normalized.includes("is that correct");
          if (isPromptEcho && Date.now() < this.confirmationEchoDrainUntil) {
            debugLog(`[stt] ignored prompt echo: "${transcript}"`);
            return;
          }
          const requestId = `${this.confirmationSession}:${++this.confirmationRequestSequence}`;
          this.pendingConfirmationRequests.set(requestId, transcript);
          debugLog(`[stt] classify request ${requestId}: "${transcript}"`);
          ui.send("scan:classify-transcript", { requestId, text: transcript });
        } else if (this.awaitingVehicleQuestion && this.activeQuestionVin && data.isFinal && data.text.trim()) {
          const transcript = data.text.trim();
          const requestId = `q${this.confirmationSession}:${++this.questionRequestSequence}`;
          this.awaitingVehicleQuestion = false;
          this.pendingQuestionRequests.set(requestId, transcript);
          debugLog(`[questions] request ${requestId}: "${transcript}"`);
          ui.send("scan:question-request", { requestId, vin: this.activeQuestionVin, text: transcript });
        }
        this.liveTranscript = data.text;
        if (this.mirrorToGlasses) {
          const d = this.session.capabilities?.display;
          this.session.display.render([
            { type: "text", id: "mirror", box: { x: 0, y: 0, w: d?.width ?? 576, h: d?.height ?? 288 }, text: data.text }
          ]);
        }
        if (data.isFinal && data.text.trim()) {
          this.history.push(data.text.trim());
          this.liveTranscript = "";
          ui.send("captions:history-update", { history: [...this.history] });
        }
        ui.send("captions:live-transcript", { text: this.liveTranscript });
      }));
      this.unsubs.push(ui.handle("scan:start-stt", async (payload) => {
        const { vin } = payload;
        debugLog("[stt] start request received by background");
        if (typeof vin !== "string" || !/^[A-HJ-NPR-Z0-9]{17}$/.test(vin))
          throw new Error("invalid VIN");
        this.logScanTranscripts = true;
        this.awaitingScanConfirmation = true;
        this.awaitingVehicleQuestion = false;
        this.activeQuestionVin = vin;
        this.confirmationSession += 1;
        this.confirmationRequestSequence = 0;
        this.questionRequestSequence = 0;
        this.pendingConfirmationRequests.clear();
        this.pendingQuestionRequests.clear();
        this.sttStartedAt = Date.now();
        this.confirmationEchoDrainUntil = this.sttStartedAt + 2000;
        this.sttFirstEventLogged = false;
        debugLog("[stt] listening; waiting for transcription event");
        return true;
      }));
      this.unsubs.push(this.session.input.onButtonPress((data) => {
        this.lastButton = `${data.buttonId} (${data.pressType})`;
        ui.send("captions:last-button", { label: this.lastButton });
      }));
      this.unsubs.push(this.session.glasses.onConnection((data) => {
        this.connected = data.connected;
        ui.send("captions:connection-update", { connected: data.connected });
      }));
      this.unsubs.push(ui.onOpen(() => {
        const caps = this.session.capabilities;
        ui.send("captions:snapshot", {
          capabilities: {
            hasCamera: !!(caps && caps.hasCamera),
            hasMicrophone: !!(caps && caps.hasMicrophone),
            hasDisplay: !!(caps && caps.hasDisplay),
            hasSpeaker: !!(caps && caps.hasSpeaker),
            hasWifi: !!(caps && caps.hasWifi),
            modelName: caps?.modelName
          },
          connection: { connected: this.connected },
          settings: { mirrorToGlasses: this.mirrorToGlasses },
          liveTranscript: this.liveTranscript,
          history: [...this.history],
          lastButton: this.lastButton
        });
      }));
      this.unsubs.push(ui.on("captions:clear", () => {
        this.history = [];
        this.liveTranscript = "";
        this.session.display.render([]);
        ui.send("captions:history-update", { history: [] });
        ui.send("captions:live-transcript", { text: "" });
      }));
      this.unsubs.push(ui.on("captions:speak-summary", async () => {
        const last3 = this.history.slice(-3).join(". ");
        const phrase = last3 ? `Here's what was said: ${last3}` : "Nothing to summarize yet.";
        try {
          await speakWithTiming(this.session, phrase);
        } catch {}
      }));
      this.unsubs.push(ui.on("captions:set-mirror", ({ mirrorToGlasses }) => {
        this.mirrorToGlasses = mirrorToGlasses;
        ui.send("captions:settings-update", { mirrorToGlasses });
      }));
      this.unsubs.push(ui.on("scan:begin", () => {
        this.confirmationSession += 1;
        this.awaitingScanConfirmation = false;
        this.awaitingVehicleQuestion = false;
        this.activeQuestionVin = null;
        this.pendingConfirmationRequests.clear();
        this.pendingQuestionRequests.clear();
        this.sttStartedAt = null;
        this.confirmationEchoDrainUntil = 0;
        this.sttFirstEventLogged = false;
        debugLog("[scan] new capture; cleared confirmation and question state");
      }));
      this.unsubs.push(ui.on("scan:classification", ({ requestId, intent, classifierMs, error }) => {
        const transcript = this.pendingConfirmationRequests.get(requestId);
        if (transcript == null) {
          debugLog(`[stt] ignoring stale classification ${requestId}`);
          return;
        }
        this.pendingConfirmationRequests.delete(requestId);
        debugLog(`[stt] classification ${requestId} intent=${intent} model=${classifierMs ?? "?"}ms${error ? ` error=${error}` : ""}`);
        if (!this.awaitingScanConfirmation || intent === "UNCLEAR")
          return;
        this.awaitingScanConfirmation = false;
        this.pendingConfirmationRequests.clear();
        const status = intent === "YES" ? "locked" : "cancelled";
        ui.send("scan:confirmation", { status, text: transcript });
        const session = this.confirmationSession;
        if (intent === "YES") {
          ui.send("scan:data-store-log", {
            operation: "repair_order.audit",
            status: "Data store successful",
            successful: true
          });
          speakWithTiming(this.session, "OK, V I N locked, let's continue.").then(() => speakWithTiming(this.session, "Do you have any questions?")).finally(() => {
            if (this.confirmationSession === session && this.activeQuestionVin) {
              this.awaitingVehicleQuestion = true;
              debugLog(`[questions] listening VIN=${this.activeQuestionVin}`);
            }
          });
        } else {
          this.activeQuestionVin = null;
          speakWithTiming(this.session, "Ok, cancelling, please try again.").catch(() => {});
        }
        debugLog(`[stt] confirmation ${status} from model request ${requestId}`);
      }));
      this.unsubs.push(ui.on("scan:question-result", ({ requestId, kind, spokenAnswer, operation, status, successful }) => {
        const transcript = this.pendingQuestionRequests.get(requestId);
        if (transcript == null) {
          debugLog(`[questions] ignoring stale result ${requestId}`);
          return;
        }
        this.pendingQuestionRequests.delete(requestId);
        debugLog(`[questions] result ${requestId} kind=${kind}`);
        if (operation && status) {
          ui.send("scan:data-store-log", { operation, status, successful: successful === true });
        }
        if (kind === "no_questions") {
          speakWithTiming(this.session, "Okay, let's continue.").catch(() => {});
          return;
        }
        if (kind === "unclear") {
          this.awaitingVehicleQuestion = true;
          return;
        }
        const session = this.confirmationSession;
        speakWithTiming(this.session, spokenAnswer ?? "I don't have a sourced record for that on this VIN. I will not guess.").then(() => speakWithTiming(this.session, "Do you have any other questions?")).finally(() => {
          if (this.confirmationSession === session && this.activeQuestionVin) {
            this.awaitingVehicleQuestion = true;
            debugLog(`[questions] listening for another question VIN=${this.activeQuestionVin}`);
          }
        });
      }));
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs = [];
      this.subscribed = false;
    }
  }

  // src/background/controllers/TesterController.ts
  class TesterController {
    session;
    subscriptions = new Map;
    unsubs = [];
    subscribed = false;
    constructor(session) {
      this.session = session;
    }
    start() {
      if (this.subscribed)
        return;
      this.subscribed = true;
      const ui = this.session.ui;
      this.unsubs.push(ui.on("tester:start", ({ iface }) => {
        if (this.subscriptions.has(iface))
          return;
        const unsub = this.openSubscription(iface, ui.send);
        if (unsub)
          this.subscriptions.set(iface, unsub);
      }));
      this.unsubs.push(ui.on("tester:stop", ({ iface }) => {
        const unsub = this.subscriptions.get(iface);
        if (!unsub)
          return;
        try {
          unsub();
        } catch {}
        this.subscriptions.delete(iface);
      }));
      this.unsubs.push(ui.handle("scan:play-click", async (payload) => {
        const { audioUrl } = payload;
        if (typeof audioUrl !== "string" || !audioUrl)
          return false;
        this.session.speaker.play({ audioUrl, stopOtherAudio: false }).catch(() => {});
        new Promise((resolve) => setTimeout(resolve, 300)).then(() => speakWithTiming(this.session, "Scanning V I N now.")).catch(() => {});
        return true;
      }));
      this.unsubs.push(ui.handle("tester:invoke", async (payload) => {
        const { iface, method, args } = payload;
        const module = this.session[iface];
        if (!module)
          throw new Error(`unknown iface "${iface}"`);
        const fn = module[method];
        if (typeof fn !== "function")
          throw new Error(`unknown method "${iface}.${method}"`);
        if (iface === "speaker" && method === "speak" && (typeof args?.[0] === "string" || Array.isArray(args?.[0]))) {
          return speakWithTiming(this.session, typeof args[0] === "string" ? args[0] : args[0].filter((sentence) => typeof sentence === "string"), args?.[1]);
        }
        const isCameraTiming = iface === "camera" && (method === "warmUp" || method === "takePhoto");
        const startedAt = isCameraTiming ? Date.now() : 0;
        if (isCameraTiming)
          console.log(`[camera] ${method} start`);
        try {
          const result = await Promise.resolve(fn.apply(module, args ?? []));
          if (isCameraTiming)
            console.log(`[camera] ${method} done ${Date.now() - startedAt}ms`);
          return result;
        } catch (error) {
          if (isCameraTiming)
            console.error(`[camera] ${method} failed ${Date.now() - startedAt}ms`, error);
          throw error;
        }
      }));
      this.unsubs.push(ui.handle("tester:calendar-list", async (payload) => {
        const { startsAt, endsAt, limit } = payload;
        return await this.session.phone.calendar.listEvents({ startsAt, endsAt, limit });
      }));
      this.unsubs.push(ui.handle("tester:speaker-stream-tone", async (payload) => {
        const {
          seconds = 5,
          freqHz = 440,
          sampleRate = 16000
        } = payload ?? {};
        const writer = await this.session.speaker.createStream({ sampleRate });
        try {
          const chunkFrames = Math.floor(sampleRate / 10);
          const totalChunks = Math.max(1, Math.round(seconds * 10));
          let phase = 0;
          const phaseStep = 2 * Math.PI * freqHz / sampleRate;
          let last = { bufferedMs: 0 };
          for (let i = 0;i < totalChunks; i++) {
            const buf = new Uint8Array(chunkFrames * 2);
            const view = new DataView(buf.buffer);
            for (let f = 0;f < chunkFrames; f++) {
              view.setInt16(f * 2, Math.round(Math.sin(phase) * 8192), true);
              phase += phaseStep;
            }
            last = await writer.write(buf);
          }
          const { durationMs } = await writer.close();
          return { streamId: writer.streamId, durationMs, chunks: totalChunks, lastBufferedMs: last.bufferedMs };
        } catch (err) {
          await writer.abort().catch(() => {});
          throw err;
        }
      }));
    }
    stop() {
      for (const [, unsub] of this.subscriptions) {
        try {
          unsub();
        } catch {}
      }
      this.subscriptions.clear();
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs = [];
      this.subscribed = false;
    }
    openSubscription(iface, send) {
      const emit = (kind, payload) => {
        send("tester:event", { iface, kind, payload });
      };
      switch (iface) {
        case "transcription":
          return this.session.transcription.on((data) => emit(data.isFinal ? "final" : "partial", data));
        case "translation":
          return this.session.translation.to("es-ES", (data) => emit("event", data));
        case "input": {
          const b = this.session.input.onButtonPress((data) => emit("button", data));
          const t = this.session.input.onTouch((data) => emit("touch", data));
          return () => {
            b();
            t();
          };
        }
        case "stream": {
          const s = this.session.events.subscribe("stream_status", (data) => emit("status", data));
          return () => s();
        }
        case "camera": {
          return () => {};
        }
        case "imu": {
          const h = this.session.imu.onHeadPosition((data) => emit("head", data));
          const a = this.session.imu.onAccel((data) => emit("accel", data));
          return () => {
            h();
            a();
          };
        }
        case "location":
          return this.session.location.onUpdate((data) => emit("update", data));
        case "mic": {
          const a = this.session.mic.onAudioChunk((data) => emit("audio", { data }));
          const v = this.session.mic.onVoiceActivity((data) => emit("vad", data));
          return () => {
            a();
            v();
          };
        }
        case "storage":
          return () => {};
        case "system":
          emit("opened", { note: "session.system has no event surface yet" });
          return () => {};
        case "glasses": {
          const b = this.session.glasses.onBattery((data) => emit("battery", data));
          const c = this.session.glasses.onConnection((data) => emit("connection", data));
          return () => {
            b();
            c();
          };
        }
        case "phone": {
          const n = this.session.phone.notifications.on((data) => emit("notification", data));
          const b = this.session.phone.onBattery((data) => emit("battery", data));
          return () => {
            n();
            b();
          };
        }
        default:
          return null;
      }
    }
  }

  // src/shared/vehicleText.ts
  function vinDisplayText(vin, info) {
    const vehicle = [info?.ModelYear, info?.Make, info?.Model].filter(Boolean).join(" ");
    const details = [info?.EngineModel || info?.EngineConfiguration, info?.DriveType].filter(Boolean).join(", ");
    const description = vehicle ? `a ${vehicle}${details ? ` (${details})` : ""}` : "the vehicle described by the NHTSA source";
    return `Successfully scanned VIN ending in ${vin.slice(-3)}. The vehicle is ${description}, according to NHTSA. Is that correct?`;
  }

  // src/background/scanTiming.ts
  class ScanTiming {
    timings;
    started = Date.now();
    id = `vin-${this.started}`;
    constructor(timings) {
      this.timings = timings;
      this.mark("button");
    }
    mark(stage) {
      const elapsedMs = Date.now() - this.started;
      this.timings[`${stage}AtMs`] = elapsedMs;
      debugLog(`[vin-timing] id=${this.id} stage=${stage} epochMs=${Date.now()} elapsedMs=${elapsedMs}`);
    }
    async step(stage, run) {
      const started = Date.now();
      this.mark(`${stage}.start`);
      try {
        return await run();
      } finally {
        this.timings[`${stage}Ms`] = Date.now() - started;
        this.mark(`${stage}.end`);
      }
    }
    finish() {
      this.mark("done");
      debugLog(`[vin-timing] id=${this.id} summary=${JSON.stringify(this.timings)}`);
    }
  }

  // src/background/controllers/VinWorkflowController.ts
  var INSPECTION_ITEMS = [
    { label: "Left-front tire tread depth", value: "", status: "pending" },
    { label: "Left-front tire condition", value: "", status: "pending" },
    { label: "Windshield condition", value: "", status: "pending" },
    { label: "Front exterior lights", value: "", status: "pending" }
  ];
  var SCAN_OPTIONS = {
    size: "low",
    mode: "photo",
    transferMethod: "ble",
    compress: "high",
    aeExposureDivisor: 12,
    sound: false,
    noiseReduction: false,
    edgeEnhancement: true,
    mfnr: false,
    zsl: false
  };
  function digits(value) {
    const words2 = ["zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"];
    return [...value].map((digit) => words2[Number(digit)] ?? digit).join(" ");
  }
  function auditHash(value) {
    let hash = 2166136261;
    for (let index = 0;index < value.length; index++) {
      hash ^= value.charCodeAt(index);
      hash = Math.imul(hash, 16777619);
    }
    return (hash >>> 0).toString(16).toUpperCase().padStart(8, "0");
  }
  function inspectionPrompt(index, afterPhoto = false) {
    switch (index) {
      case 0:
        return afterPhoto ? "Now tell me the exact left-front tread depth in millimetres." : "Please take a photo of the left-front tire tread with the depth gauge visible. Then tell me the exact tread depth in millimetres.";
      case 1:
        return "Inspect the left-front tire condition. Say good, or describe any cuts, bulges, uneven wear, or exposed cords.";
      case 2:
        return afterPhoto ? "Now say clear, or describe any chips, cracks, or obstruction in the driver view." : "Please take a photo of the windshield. Then say clear, or describe any chips, cracks, or obstruction in the driver view.";
      case 3:
        return afterPhoto ? "Now say clear, or identify any light that is out, damaged, or dim." : "Please take a photo of the front exterior lights. Then say clear, or identify any light that is out, damaged, or dim.";
      default:
        return INSPECTION_ITEMS[index]?.label ?? "Inspection item.";
    }
  }
  function inspectionItemRequiresPhoto(index) {
    return index === 0 || index === 2 || index === 3;
  }
  function userFacingWorkflowError(step, error) {
    const code = typeof error?.code === "string" ? error.code : "";
    const message = error instanceof Error ? error.message : String(error);
    if (code === "BATTERY_LOW" || /battery\s+(?:level\s+)?(?:is\s+)?(?:too\s+)?low/i.test(message)) {
      return "Camera unavailable — Mentra Live battery is below 10%. Charge the glasses, then try again.";
    }
    return `${step}: ${message}`;
  }

  class VinWorkflowController {
    session;
    mode;
    unsubs = [];
    running = false;
    routingTurn = false;
    generation = 0;
    pendingInspectionValue;
    classifyingConfirmation = false;
    accepting = "none";
    backendUrl = enterpriseBackendUrl();
    backendSessionId = `vin-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    pending = new Set;
    requests = new Set;
    chatTime = 0;
    nextChatTime() {
      return this.chatTime = Math.max(Date.now(), this.chatTime + 1);
    }
    inspectionSequence = 0;
    completedInspections = new Map;
    snapshot = { phase: "booting", workLoading: false, timings: {}, dataStore: [], questions: [], audit: [] };
    ui;
    constructor(session, mode = new WorkflowMode) {
      this.session = session;
      this.mode = mode;
    }
    start() {
      this.ui = this.session.ui;
      const sendSettings = () => this.ui.send("vin:settings", { provider: "backend" });
      this.unsubs.push(this.ui.on("vin:request-settings", sendSettings));
      this.unsubs.push(this.ui.on("vin:set-provider", sendSettings));
      this.unsubs.push(this.ui.onOpen(() => {
        this.publish();
        sendSettings();
      }));
      this.unsubs.push(this.ui.on("vin:scan", () => this.run(() => this.scan())));
      this.unsubs.push(this.ui.handle("inspection:share-report", (payload) => this.shareInspectionReport(payload.inspectionId)));
      this.unsubs.push(this.ui.handle("inspection:share-sample-report", (payload) => this.shareSampleInspectionReport(payload)));
      this.unsubs.push(this.ui.on("vin:configure", ({ backendUrl }) => {
        if (/^https?:\/\//.test(backendUrl))
          this.backendUrl = backendUrl.replace(/\/+$/, "");
        debugLog(`[vin] configured backend=${this.backendUrl}`);
        this.publish();
      }));
      this.unsubs.push(this.session.input.onButtonPress((data) => {
        if (this.mode.page !== "automotive")
          return;
        debugLog(`[vin] hardware button ${data.buttonId} ${data.pressType}`);
        if (this.snapshot.inspection?.active)
          this.run(() => this.captureInspectionPhoto());
        else
          this.run(() => this.scan());
      }));
      this.unsubs.push(this.session.transcription.on((data) => this.onTranscript(data)));
    }
    run(action) {
      const task = action().catch((error) => {
        if (this.mode.page === "automotive")
          this.fail("workflow", error);
      });
      this.pending.add(task);
      task.finally(() => this.pending.delete(task));
    }
    activate() {
      this.update({ phase: "booting", error: undefined, workLoading: false, vin: undefined, vinLocked: false, validation: null, vehicleInfo: null, photoUrl: undefined, vinSpeech: undefined, vinText: undefined, inspection: undefined });
      this.run(() => this.boot());
    }
    async deactivate() {
      this.generation++;
      for (const request of this.requests)
        request.abort();
      await Promise.allSettled([...this.pending]);
      if (this.snapshot.inspection?.active)
        this.completeInspection(this.snapshot.inspection, "INSPECTION STOPPED");
      this.running = false;
      this.routingTurn = false;
      this.classifyingConfirmation = false;
      this.accepting = "none";
      this.update({ workLoading: false });
    }
    requireActive() {
      if (this.mode.page !== "automotive")
        throw new Error("Automotive mode stopped");
    }
    update(patch) {
      const previousPhase = this.snapshot.phase;
      this.snapshot = { ...this.snapshot, ...patch };
      if (patch.photoUrl && patch.phase === "scanning") {
        const at = this.nextChatTime();
        this.snapshot.scanHistory = [...this.snapshot.scanHistory ?? [], { id: `${at}-${this.generation}`, at, photoUrl: patch.photoUrl }];
      }
      if (patch.vinSpeech && this.snapshot.photoUrl) {
        const history = [...this.snapshot.scanHistory ?? []];
        const last = history[history.length - 1];
        if (last?.photoUrl === this.snapshot.photoUrl)
          history[history.length - 1] = { ...last, vin: this.snapshot.vin, vehicleInfo: this.snapshot.vehicleInfo, vinSpeech: patch.vinSpeech, vinText: patch.vinText };
        this.snapshot.scanHistory = history;
      }
      if (patch.phase === "locked" && previousPhase !== "locked" && patch.vinLocked) {
        const at = this.nextChatTime();
        this.snapshot.chatNotices = [...this.snapshot.chatNotices ?? [], { id: `locked-${at}`, at, text: "OK, VIN locked, let’s continue.", locked: true }];
      }
      if (patch.phase === "cancelled" && previousPhase !== "cancelled") {
        const at = this.nextChatTime();
        this.snapshot.chatNotices = [...this.snapshot.chatNotices ?? [], { id: `cancel-${at}`, at, text: "OK, cancelling, please try again." }];
      }
      this.publish();
    }
    publish() {
      this.ui.send("vin:snapshot", this.snapshot);
    }
    audit(app, event, detail, photoUrl) {
      const now = Date.now();
      const row = { time: now, app, event, detail, photoUrl, inspectionId: app === "VOICE DVI" ? this.snapshot.inspection?.id : undefined, hash: auditHash(`${now}|${app}|${event}|${detail}`) };
      this.snapshot.audit = [...this.snapshot.audit, row];
      this.publish();
    }
    async boot() {
      try {
        await this.speakChat("Welcome to Acme Field Service.");
        await new Promise((resolve) => setTimeout(resolve, 350));
        this.update({ workLoading: true });
        await this.speakChat("Booting Acme Field Service, please wait…");
        this.requireActive();
        debugLog("[mic] loudness gate enable start");
        await this.session.mic.setLoudnessGateEnabled(true);
        debugLog("[mic] loudness gate enabled");
        debugLog("[camera] setFov start fov=62 roi=center");
        const fov = await this.mode.withCamera(() => {
          this.requireActive();
          return this.session.camera.setFov({ fov: 62, roiPosition: "center" });
        });
        debugLog(`[camera] setFov confirmed fov=${fov.fov} roi=${fov.roiPosition}`);
        debugLog("[camera] boot warmUp start");
        await this.mode.withCamera(() => {
          this.requireActive();
          return this.session.camera.warmUp({ ...SCAN_OPTIONS, durationMs: 600000 });
        });
        debugLog("[camera] boot warmUp confirmed");
        this.update({ startupReadyAt: Date.now(), workLoading: false });
        await this.speakChat("Acme Field Service is ready, press the action button to scan a V I N.");
        this.update({ phase: "ready" });
      } catch (error) {
        this.fail("startup", error);
      }
    }
    async api(path, body) {
      const url = `${this.backendUrl}/api/scan_vin${path}`;
      debugLog(`[vin] api ${path || "/"} session=${this.backendSessionId}`);
      this.requireActive();
      const controller = new AbortController;
      this.requests.add(controller);
      const timeout = setTimeout(() => controller.abort(), 45000);
      try {
        return await fetch(url, {
          signal: controller.signal,
          method: "POST",
          headers: { "Content-Type": "application/json", "X-Session-Id": this.backendSessionId },
          body: JSON.stringify(body)
        });
      } finally {
        clearTimeout(timeout);
        this.requests.delete(controller);
      }
    }
    async playClick() {
      this.requireActive();
      if (false)
        ;
      return this.session.speaker.play({ audioUrl: "data:audio/wav;base64,UklGRrqpAABXQVZFZm10IBAAAAABAAIAgLsAAADuAgAEABAAZGF0YSCpAADE9t/2/gADAc0FpQVt9cP0ue4X7vP3evdfBR0FYQyWDN8Ovg9tEn8TjBQ7FSAWkxaCCJgIrvHc8Gj1YfSsCVoJCQQKBPLwwfBQ/ZP9vQxFDfTzgPON4qnhsPfD93gBwAFM9wb37AIzA44QixFC/af9LO0G7Sn8VPzoCOAIXv5N/X/z8/ER9AXz6vV59XH+cv6hFEkVriSSJXsV+xWX7jbuvNax1RntEuw5GMYXWRkRGSz20fXh7dztHwMiAxUGOgUX9a7zqvbF9Z0BzwCC96r1XPCI7lP/7/7TCgILfA1eDcYaRRsdH1ggiwCMAA/oRuY470/tAeoa6NvVSdNa3xLdk/qy+RgHSgdXEAIREB69Hu0keCUQGTIZufOU8orZL9eQ78DtrgUhBdzyEPKR9Nzz2BlPGuIS5RLd7kTtzPaU9acNag1TBJEDWfM78rz3mveMA2MD7fi+9yzb59lP26TapwYGBmgZsxhp/xv/B/sC+5QKQwpn9HzzudhY1xvst+pUAxkCePdq9n3w+O/cCvQKOySHJGAVeBWk9Vf10vOY83YBYQHC/Df80/fC9mL8qvsj8cDw6eb45ZX7j/oiDygPHgT3BN34mfk0BtMGGxYbFwsNqQ3u6Nzn+siwxg3TItLn9VL2cQjmB4kQaBBBF8UZog4REOEC5gAkBJIDXwFqAzL6APolBL4CvQ0pD+r7H/0z4SjflNr/2Lzpf+q8/AX9qAVMBa8KmwsmD+MQhA6pD24NtA1TCxsLewO4A1T5hfl98lXx3vPU8tr5jPrj+jr71/jc9678qvyaAMABLfyJ/JgB0QFcFtUX3BihGvEEAwbT+z/8pfdL99Pg+t8+0cPPa94X3H3pu+e86kfrSgcRCSI3qzgoRYhHYihrK2cCPAPI7ojtL/LF8STxD/HC4VDgveG94H3t8O1U7vvtGfI68awAPwH5DFUOKxpyG1EkMiZqEiUUvvEv8hfq8+ky6onpFtdS1QLVrtNp9ov2QRSvFE8fFiBeJUknEB7KH3UE4wTE877zqvnd+S78QPyh7Vbt/eWS5dzuy+7O9jz3kfpZ+0b9hP6k/Qr/ogZWB1gQbRAG/nr+xeh66YH7tvvWC2MLdPK58YnsfuxSE8oU6x0GIM3/+AB5/+z/jxhGGYAFEwZ54LHg6u+s8PsEawVi5y3mM9153BwF8wZGCg0MlOsh61f49fcbEeURDf9u/0T3pveDCtQLyApoC+EQmxC4JIMlQgytDcjkJuWC8U/wJRAJDvEP5g5U+Fr5ruLB4wLyhvGtGAMYnRTEFGHuO+9D5VbmCfYf9ngBJQCOBngFWxL/EmQoBCuYHxUif+mK6JzUmtCf8EHtvO6S7WXgreBSB1kIYTRGNe4mTCe0/y8Awvb493MFxwYgA2cDlO+T7j/wIe9YBDoEsv/I/w3m7OQR7CnqAwwNC84UdRU6DZ4O4h0WH0M1/DVXDAoMV7i0tmS6irnzCP4JEhN9E9HqEerm/aL+oR2QH5IIegl198P3YgFvATj6gPhZ8djux/0s/V79LP7t9VD27v/V/6MDUgMZDm8O0C8FMoAuwzHQ/RQAjtqJ2mnf09wp+174PgKvAcTp5eqX8fbycBe9FwYQzQ22+uL3PxKBEgMk6Cb7FakYfAzaDYb+7P0B6OXlGeMA4jTiB+OO4H7h1PKb8rQAE/8Q/tX7PA7dDXYhsiPZDdYPEfa09f4EpAMXDvMMyupC6WzVntQr+aH6chP2FIf63vkl+DP4LxxRHmwWIhcl/Uz83gknCpwNhQ0T+6H5DvCX79rc8dyx3MzbdwTGA0EF8QSQ3mHe//S89pEnhSqKGQgb2fpj+8MFOQYdDmENW/kv+Kvrkesg8ffwrfAJ7xvu4utmCW0IUTUXN4gvKDP0+/n+aOkZ63f0DPRP9z70igFK/7UD0gTN8uz0d/rG+9gXOBliGCQYAQp0B20WxRU+FIcW1Oaf50HTn9IV9Kf0bQvfCuMHowUZE6UUASQiKW4YyhpfDaAMURXWFB4JaweF6gLnWujg5nnz4PRY6Fzpzezo7EgQYRD+G3IckQrgCzcHqgg6EBIRyAtxDY8EQwaDB9YF0/u8+NHcedz+2c7ZewhDBj0paClwDlIR+/lv+nYamBksJTInPvfv+dXemd+T8nvzzfnQ+lTrY+rD5aDjkPsL+oMaHRq7FrIXkgJuBDEWXRc+MhAzBBH9ETjca9tU4ljgvfS/9A/cPt3p38Pf9CbgJwBIYkujDdYP7uph6xMQXRGgEDEQ0tb+0iDAn70v5Z7lGhb8FbkjGCQYAacERu4H8g8NjQ1VCmgJ/ORe5Qj2D/dYIc0hlSjsKV8OKxAY6s7pI+b65Pv9X/2d/Ar7uPHp8OMGCQkRF6IY2AI3AvjyafQ6AlgFKhzkHIQV6hV56tXsmuUs5uwIKQYG9/T0dsqHyhHqsemmKTIpvSkCLE8LSw4BAeoAJPjy9tLleeYJ1cvUzd6x3AAN2A0ZKVwsZhCKECoBJwBOHHIeAhu8G1vzoO+R8dbvxQMrBfLpU+jn0dvOEfpx+/go0ioSF7UUL/gF9+8IYwy5HaIfHxQIElsNbgyVAdYBhtUr0lrHVMKR+Ff3ERoqG4YR4xC3DgcNvw/QDw4HkwgoAyMDDflY9hbnUuUS6xHshvvj+jUCQP62Bw8GexAhE24cDB7GHYYbF/0t+hzbmdrN6W/q2wXdA0EChP08/DP7wf35AvX2J/rnATX9gB/rGtIfpyP5AOUG1fFh8CPuQ+iL3lLcxOlz6xIIEAi0+an1b+p952MT4BYAKEgt4go8CWUPQwmjJxAn4guXEcjr5O68/w/9DAyHCDDrsekF4czg5wTrBSUU0BS49ObyP9lA14nwx/HHHDgeoh1iGyP9pfv39bv5sAXiCdf/Hf5R7jDp3Pzy+m0bhx6nE3oXuPT59Pj1P/NCBUgDzf4E/6Hroeuq5Mzi/AQvBCEl8CZAFYEX3QSHBh0HIgf2AG7+PAFyAI/+lQE75aTlb+Ku3Zb9QvvJ9dD3gONV4l8PIgvhNWA3dwoNEXvjTeVJ/BL3fgm9BILx9/EF4B/iV+Aj4NT0EvTbEu8SKxxUGu8Ljwhy+8j7ZgQOCUYauhu8GN8TUfn29F/eMd8j5zvprv4k/2b7tvt55bvkk+9w7KAXRhadHeYgBgEXBNv+ff3cEwUR6wooCmrvbe+u+Ar4SRNSExMEJQUp2uDZatJ4z9v06/H/D0oQIg7XEFIHNQlnBbEFHAL2ARADKgLgC1oJ6AtnCa/+Sv5z80b0u+jn5xrlCOIx+Yb2XAqHCXL+sP7995H4swjLCfALggz6CBcIFxkOF40TQBFF9Q30/PSq9SYBuAE75y/l/cbBwkTaDtZ4Cy0Jfx0RHrgGxgke8PrygPvc+3wXshUUF0UVovYC9nngvuA57VvtVwNmApAE/wHl/aj6RAmcB/oVzBbLD6URmg80EREUrBSP/pr9R+mj55Htk+zd843zV/fO9239j/5JAfcBegIzAlTz7PGu4C/eLvGW7ksFsANb8hrybvHB8t0jfyUhO4Y6CRUJE2jig+EYx6XG7Nv62hEM0gt8G1sbFROdEasSHBEH/AT8ic7IznLWFdXBFssUqSr+KXEBJQLJ6y3s2vvY+qUDLwIMAH3/xhCiEd4h+SN8DJAOKvCK78/7B/g1DQ4Ky+mZ6gS7QL1p2QjZLjDCLURU0lLhKKUptv5oAR7x6/Nd0YDQTcnHxPn/OPwtKsApeyhoKgQQ1hHS4JLf88R2wQ33LvbhQ4pGrEFqQ8IUrBSD+p76GdFB0ILGDMWm9bP13w7lDoYEPAKJ/m384hS6FsofiiN+9aP2JdRx0mHcxNmr9FLy0w/rD9UVGRneEIwUyRx2HlQr1isEG+AbKewf7afQMtGw15fXdOy46woQtg+5KYUq4hxjHiQC0gNr+bT66v9IAAoHEwc8C5sL8vfH9yLT4tHfzz/PdOyU7I4N/gwzH50etgj7CHDmFOZ35qjkewo2CUkUThSN5zjnJ+f+5sgl5ibkOhM8RhPRE0HojOjo4dPhCvjs9zwDjANo867z7PAc8X4ZkxqmKZkqXgTKAyftWuxZ70bvo+0X7fvomef37//u1wrKCkQb1BrVB0kGy/n1+HYGXAdHDeoNph1yHc0zEDUfFE8WwNU41tXDNcPl7fvuBQwgDsj2yvebBl0ItzpqPkUvDzK/+6r8tt8h4FLhWOGI8NnvNPR084jsRewP/Hn8DTBVMcdElUXQFBMU9+hA6I7gIeAz6ALmdPlh9pf5S/jQ35ffsMYnxQTk7OJ8KBMqvSUVJ8r8bPyuBVwGzfy7/jXSOdMM2tPa5BsHHmdPglJjPUpAOQYZCMX3wfhfHuYeRySbI5/rBelXyfPGrdQB1DXnbead+N72bQ6oDTwbiBt9+E736NfK1d73nPcBEmESyAkICXoL1ApdCVYJL/KD8VrZ2ddB1OjSiuwK7HsY7xjjNK816TEFMycoECrIFDAXR/TV9X3rnOz6AG0C9g/yEBP9rPzb29HaxdXR1KLuG+15EVAPGh9RHb4BQQBd3pncP+BS3vn5M/h9B+YFf/9//v/38veyADsBhh66HwY+2j+cMAkyEgBYAAHc69tdztXN19Nz0ojq7OigBOkDLQw8DOEBSwLLBvEHkB9VIeYrcy3zFsEXbeuE61rL9cq+zCzM3OVx5W8EhwQGJuMmEkRkRaFFkUZ2JaIlBfyS+2Ddf9xV0jfRod0A3RX3gvd2D+cQuRaHGE0KDAzD/k0ANv8VAEkETgRZBfgEjPnq+HPqp+nu7DvsKgOSAkIahRl/IiIikhfsF4H7uPvr9j33jBDoEQgDgQTc2a3aG9qA28339vnECpsMMg/vENkZTBzsKn8tlidVKWgRfhLP/of/5fO/85fifeEgyq3Ij8ZqxdHpIekyHhAepzoEO4czJTT2IHshiAVeBc3clNvnzUfM6umu6N4DAgOsAWwBp/uv/OcO+RDuL90x/DVEN90bBB2++L/5D9tH2yzWOdZB8h3zjRmqGmUqAisUFX0VmvH98S7q8+n/Ce0IoSIxIUsMwgrm6SXo9eP44XvuYeyF+db3aAQoA1AMEQs9CwMK4v9B/xv04/Ot8UzxY/dY9+/6Pfwa+jr8KAROBmIW4hhpHE4f2RXqF1EN3w0dBS4F6+sA7AvNcMwt5j3lMSfXJgo4ojcODxkOmN853jPJ1MeO0pPRVO7T7RQKKAr3GxgdghO2FYn0lvYU9af2uRxrHo0p7iqKDPQMRe1x7bbjQeRi6tHqB/IY8mf/2f+UC6oMggigCd4LAw0IH3UggCazJwoTYRPX9Qz12OMK4o7dINtb1DXRPM61ylPqd+cNFB8SFyBOHmMfZR47HaEdBw3TDe727fdD6V/rwunM7ATy6fR6BqAJ3Bu8H8sYDRx0GLEaZScPKYolFCaaEW0Qbv0T+zfuF+sx33vbC9VD0d7Yl9Xc7Cfqnw/NDQUlzCMaFgMVBvgl9/jmKebR6I3nNO+w7X3tYeyZ5c3kYO7b7XkV9xWZNhw4fz51QDw/yEFlMI4zIwpkDazm6+ng4BDkJvMD9jX+awA28onz8uI14yHoWOdo+rT4AAp2B2QXShThHlAb5BHLDd3sLOiNxoXBLr9nukXWUNL07FDq6/Y+9p79Df9CCt0M3SK9Jes04TcnIrEkIfCa8dnOCtDC5LDm5RIVFc80bzb+RPVGeiQvJuTjEORFzsfNPPFN8YAhxCEUOkQ6ljlqOqgnsShdB/sGj/Ty8njtO+v928PYntLtziLYAdXN3yndrOk+5wz2PvSq+HP3EOvb6U/xs/CUFRYW3Si4KXUkmSUMHAYelRGzE2UM/w1YDt4PggzmDbv+eP/T7N3s3tuw26fUJdSy7Ffs1wr4CicLiwtQAT8C9AZOCHMWGhc2GO4XDwPBAgjglt+7ycnIgeM240sQOxEhIdQh+B/rH9IVfhXJAtIBs/Wc8/z6fPgzDFkK5hCZDz0J/gdVCDUH2gMSA0zskesb2V3YJej359sO/Q/ZK+wtOCmPK5UTDhZt/NH+o+L941rca9y/9En04wjbB74IDgerBqIE9w3dC2wZNRemHD8aChGUDjP9xPoX5I/hYso4x33GCsNC1sTSs90z2tfa1tfL4yHiPgeJBpg0KzSKR1dHlx8ZH/3Nb8yGoMee3rBMsIPdcd7YGBIcMlI8WA102Xsie/9/mXAceHNWSFwVLVIwewi/CXXlKOV1xFLCG8f7w5XfJdzD41Pf8820yLe497Nhvmi6Y9+521MW6RPePII8hyPuI6n0KfXX6f3q9/NL9eX4SvlP9Ar02+2k7SXsAuzt8cDx4gZzB3UjXyU2NBk3rjIcNoAdECFp98X60tBg0667AL0qvWe9qs9az5bn/eYj/MD6nRaVFPM1bDO/PzA8di9pKncSuwwg76Lp+tL6zZzN1Mk84rLgZP+DAB4WXRmNMJM1WUy6Ul1QL1eYNac7yw53EyXwN/N14AnibNuD23TegN2i7ZTsY/16/GYESQNyE10SzSL+IW8WZRV68/7xq9IO0fHFN8QPz9jMkt/q3InoieXb5rXjXeMM4BTrmec+A+T/pRSpEQsDMQAo2rDXBMDTvg7Nuc2a9/D5rCzkMClYSF4JW6lhvj1gQ2Ij8CftEBUUewLWA/j4APnP8ljyh/K28dL6MPlMCMwFmA7QC8n9C/vh3i/cWNxm2o4AJwDxIHohBx5LHon+mf7g3PHcMcZ4xXjKIcnZ9zj3IiMZI10p/ihoEgsSA+HU4Jy2LLZywT7Bhfdg+BkiDiQuJfQnPhi6GzsMVA9eBoII2gVaB0v6+/oP8aPwH/1i/OAN8gz1Dg4NPwU/AkwAF/0L9rPyEOd+43fvn+xABYkDzA2VDPwHFwfq+Gb4/+za7Gzzm/PoCY0KLB5SH4YgACJmEecSof6p/y/31/fC9nn3APPb8370kfU1A9sEbheNGZshcyOkHvQfAxMHFGrxyvFkyvHJg8fgxtfgA+CP9wP2FP9I/fD5Pvgt9jH0VwAn/v8TTxJME9QRjPi29j3ikOBA1CDTes6ezcTghuBNBG0F6yVVKOE5RT3XPt5CMzmUPXcs4jAAHMAfVQ0VEOkB6APx723xSeDY4NDqy+rLCvcKDyOOI7chpiGGGxob9BqFGi/7y/kwx2nEG7M2sOi7hrljzUjLueqP6YsU7hS/OhE8LENVRDAsMy15CG8J3udB6I3dpN1T5BTl4eZV6KjtqO+cBWMI1yBzJPwp3S3NJNkoeCK7JkkdIiEuEQQUJwANAp3hIeIjxDzDncAEv3vW+dTt+cP4iyEsIe1BdUJNSDhJXC79Lr4ECAWI34/fPc45zjXWudb/7qTwHw0GENIleSlbMC80TSvfLlIZBBzTAjkEYvXf9cjr6Ouf24Pb5dS51OXjQORu/Ur++BDZEZ0WfBeLEYoSCATZBEf3ifdA+zL7AAcFB3oDcAPQ8a7xa+d9597xQfLXCDUJWxZeFv8PDBAn+sL6md2A3pDXx9j59yf6QhkFHDoamxywAo4EYuoB7DHmZefY+G75cxcKGB0tJC7pJtsn+RF2EnQGrQZfAoQC0P24/Qj/3f7VCEcJahCSESIHmAhV8q/zqOpI7D3x2PLe9vD3hPxN/dD8wv1e9Of0DvP28ur+ev7cCkoKoAmBCMwBZgBE/wX+n/pS+Xj16vMe+6f5zgCt/6r7wfox8rDxaO+D70H3yfetAFIBTgAbAan1sfa87vXvS/rU+7MQfhI+HRAfqRgqGhgMAg1JApoCw/3R/YX/pf9mDNEM8yS8JQU37jfVK0csawgTCKzlheRk1LnShdWv02Lg3N7R7t/tAf1b/EkFzAToAmEC6vlE+Xj45PfJA4kDeA/HD00OHA/sASkDT/fH+A32wPdQ+x/9OAQCBi8UJhYyIvUjOh4+H6ELsQth8Z/wW9dz1YnKoscVzfbJ4Nbn027hc95j9dPypRISEbAh7iAoIA4gTxsOHL4TGhWSCA0KTPya/azywfMT8kbz9PyV/vML1g1pIaojMTzzPoE99T/zHEweIfLS8iDNes1vvkG+s9Fp0df6GPuwFzYYShR1FDcC4gGo99X2S/3A+0IK8AcQCB0FXPAC7cTSXs+QwxjAnM1+ykbwYe4pF+kWJCsGLAovJjGKI6gm3gYJCkzuzfCE5Y7nQ+X/5h7reuwB/fn90RukHF811zWUNEU0uR1OHHAFRANM8qDvxOOb4JDfK9wj5Tji4+2M64n1nfNhAxsCGRjfF3cdoh1GE1QTRgoyCgX8ePuA5gPl6Nb31EzVsNMs4UnghvWx9aoOLRCiJjUptjOnNg8rvC0gDCsOyeg76vPV1NYd3YHdofYB93oQ9xArGzEbPRZGFUIMnwpx9eXylNbf0ifRTM2x46XgcvVK84UAYf/sCEAJNBJ3E6AYEhqTF+sYcwiwCX/zevQF7/nvVPkr+hEG5AblD+cQHRTkFKkUqxRlEjsSQwlICaf1KvV39MrzaA2DDWoMkwzS82XzJu3r7P/y8PIa+WH4MP/+/d4DsQJ1/sH8s+487NXjGuFo3p3bS99y3JrrKunM+hL5lQWwBBIM5wtGEbERYRU4FqISwBOgAacCuu167i3t4e1L+rH6SwZTBoILyAvfCmALhhK+Eswk4iQLK/IqwQ6kDT7j9uAq0ubPwdsa2u/ute0ABQgE0BJkEpwWBxfhFsgXXROlExsJlghL/Xj8lfHI79vldeIK5Wfhi+sA6ffyG/FBAq8AZxAeD94RIhEdEf8RQR0iIMspnSyIF04YW+6i7fTTgdLK1RLTnehN5bX7svlABJUDzARQBMcC9gH3/aT8B/hg9l7ywfAC8gTw1/2p+zgJAQi2B3MHHgWMBG0KDQrQESQSVBb2FQIZ7xdQFwwYkBH2FDQLPQ+8+0T90eOW4c7YOtWF5SzkcwDyAI4ZShooK8osWzSXNksoCil0/yb/CdIv0grGPsYZ3wnfDvun+y8DQgQcAzkEXg8FEIMiziCcIqEeNQu/CPXxlvLJ5IjmPuIE5knmxe1n7lj11fzL/RsOBgt8FZsTZxP2E0YQrBANDV8KrAe1AhH2VPSU1lHb/MbezRfZL96F88f48AYjDMoeyR6pMA4scSxlKhMbSB0gAmgCSunQ5K7p2+ahAsUIYRRoIegRyhzYBpELMwKtAp0F7gDR/EfyFuYL3SrhUOAL7iHyEe/78uzqJ++K9Yz62gQUCLYLNws5CJEFRf0q/M36n/vIBQAFUAfmBZf5y/uG97v7ewlIDHcWLRtYECUZYQKJCTf3sfZM9MvsIvqc8Nf52vJX7fvr0ukK74D2DwAp/4oI6vhy/g7sHOxN6HLkyPYF89oLGAgWGQUTdRysGA8SBxeNAUkLF/7ABM8EzQeJDWkQoRi2HOASJBZL+Of2CuqU5BLyLO1W/k77BQW6AuH6Hfzg6ZfvEfIO+NkG5QrBBd4HwfqG+Pb5TvS7/m36EwVYAh4I3gXmBMoGEgKrB/b7UQHT8735I/g//O79k/mG8/nqjeqt5eLwAO1m94z0gPnf/d8BOQmvC+MOfgpsDLADvgVPA08DjwaFB04JpAo5DxALNRG8CsoIPQcbBCsG9AY9CkIBGQfK9eP7RPh/+qkI+AaYEEwNoP/I/JvhLd7bz+HIcdU9zpvvzu9HELsV8B/lI0Qbwx7qEeQVYQZ/BeT2cvEg7BrnvuqZ5s/xk+9I+4n9gwDFA/sKPQzwG9odZhv6HS8IAAn2+zP74Pje9Wry/+2b6qTp6uiX6oP0hPJdCjIHaxcYGjgU/RmfC/gNdAN5A6L7cfuZ9gXz6Pa58In81vprAcUESAKWA7kGyQWOEYkUcxe+HBwM4gxw83rwxeUC5Zfx1/JEBJwDIgsjCSMK/AmMCRALOQurC/IEgQPy7krtTd323Efiy+G287XxVAeAB0QTyRhxDDkSKQPUApsDgP9z/lX8ePf99qf4jfbQ9j/1SPi8+xAEcwm8CNQJVw1oDAQdCyAnGwkgev8AAP/mUuJA4NXbGu1c7G8ADP/MAE/8Af11/RQOhhY8G0IhlxE2EpkGRQm5AI4CJPa97gPsEuEw7ZLpLP6lAc8TShhYGOAbIw6rEYIJTgxoCmIKqgTRAu75svio8S3vH+x35VnqdOKv9DDxnAfdCrcPHRcnC74QzAZkB53/Sv639uH1uPfs9M33c/J38R/sv/ip88YFAgKMA7gFyAMlDHwQ6xcwEfkS/gJKAS35V/Z59VvwpfHt6HztweTD7t/rYf/TArkXdB3HHtUkGA67E136o/x79wH18wEq/HMJOAOQEB4OMh24HpMcPByWB8QENfQ99WHtBvOO8E72k/md/C35k/fU9VDw1QbgAf0VxhCwBmb+PfGk6zrpCuxW6VbwHfas+6wDKQfOAowElAcNBzsSGw9WC1IGqAbOAe0Sdw/XELIPiP6tAIX0JPfs7p7vXPA88+4BnAcCC7cLAgCj+fb5w/OQ/dn6tP6a+7gDX/6fCP0FLvszADXnUu6P55TnbPnT9KYJTwgKFBkW4RuHHr4bIB3yDTsKsvoa9E3zuvEC/AL/fgRtB7P+/gI98273dvfg9T0OWAmOGysZpApWCtnxEfOS7x/yB/yw+4wAe/xB+mL4ZPS39wz5av1zBN8D7wcGA30DDAJ9Af4ECf46/tnzEvAY7FHsRfFS9DMH1gaXHx4eIiBoIRUNnA8GAvgDJv+q/8r4zPf+9OL0R/ZZ97j4X/eq/nP6NwGU/iP6D/xW9x77Tf85ACsEUALU/b/7pe8j7Vfi3uAW427mQPer++YSrRFUIJccshP1ErL9xv0/9772YP0GAEwEpgo1EuIXEiECIzQZDRnX/vH/zey07Tzqreap8xDuEAUQBFsJHAyU93j4ZOpB6XPsDe2G7WzwHvF187P9jf3BBP0CPwRYApsCVAAg/ar7fgJiBHAaVh4/JOUm0BT6FiwIdwuRAYcErvda+Rj1z/Qm97HzzvGL7QPvtO2v91T4wAMYBNsLHwyICYMJCPyF+xzxFfJw8jL1+PgC+//5qfgD9LjuCezi5f/j0OGU5ZHnZQQNB8EzpDYiRZxJaS2GMdEOOxCS+Fr4F+RB46rd/ttI8dfv4gymDOwbwxvDHj0e0Rl0GlYOdhCkAXEEjfSN9v3k4+MM3r/Z4Oij5Bb7wPjJCpwKyheWGeYaGxzBCo8IHe8I7CjfA97P6Pno9Pu5/UIAPgPr++P6TQGm+2UJXwfOCWINBwztDSMTmRGqElATyQnVDEsCWwPx/J/7Vvm/+FABmQMfFBcYJxyIHb0MfAna8HXsXNaH01vJxsZV1CHSlO2b7boAEQIzDPsMMRO9E/IPwxC4CkkLqw5nDnEQNQ8uCAEH2P+ZACD/DwI3CzQPQSAOJEklcyfsEHYRp/6A/2L+KADAAl8DAQSHAmsFcgMNCFwHKAtGDLwHogk4+ET5weii6IXm1eUS7bzrjfXC8+j8r/tW/F/7j/Pu8Q7vLO0g90D2XwSSBBcG/gbw+yv9zfq4/DgGZghJCywM4A3bDNMX2hbcFD4VHQEWApr4Ufl//Vn9T/8o/gUArv5r/sn9tvae9mD3dvenBbcFfBEmEUwObw0d/ZX7je226+Tw++86AOIAuAs9DRASgBPBEv4T/AwyDp4JlgoPCzwLhAsJCzkM5guKDLMMggPLAxDy4vFT6N/nWO9D79v67/oo/nf9N/0V/Jf75Poj9CzzxOey5fHeItzv4oDgffbX9QcKmAt8DT0QOgsADhgRfxPHFiwYDxIZEgYG4ARJ+Yz3KPF978byBvIAAKcACA8UEUwQxBLgBKcGVvri+nTzofJh8Svvuvob+KYHeQXlCHQHIwGLACz9y/3//40BuQBrAsL5i/rj9Jr0hPrO+SIEZQPuDDwMQBObEhMQUw/wB1sHNAfMB0oIQgqRABUDJfcb+cT1hPZs+Z34jfo9+AL3rvPU8WLu1O4k7IPxHvDm+hT7AARlBZMENwbX/e/+TfdT9/H1v/Qw+hn4fgIaAH0KhwjPB6gGpvgh+KHv6+/v92X5HgQWBl0K+Qu9C5cMfQZJBv4A9/+6Bp8FcBLKEQoY8xfPFYoWDg+gEF4HiQnjAO4Caftc/ED3i/Z/82vxrvDd7W3xxO4j8grwHPE/7+rzYPJI9yD2MvRE88HwTfBV8nvygPbu9kb+m/71ByYINg4iDsQPqg/rDPMMOgldCTQKlwp5DCMNOAzzDBcLIwwiB3IISwGLAvz+AwDP/jH/4/9W/5MCPQGf/nr8yfT28Szxae5W80Dx2PV89JP6KPpG/qD+Af2W/dn6Ovs6+ez4L/nj9+3/IP7dCkUJPhFPEAoSLxLWERwTDxI6FIEQ/BIvDE4OfwflCCoClgJP+GP38OyV6mvqXufK8yLxDv5+/KT+Mf6D+eP5kPeF+MD5yvor/bD9s/5j/rH7dPrm9yP2pPkf+LUA/f89CrQK6hGWE5YRMRSjC64OiAenCh8HvgmuCksMdRAEEXMQ/g8xCRkIPQNVAoUCVAJdBPsEGAUsBm3/aQDW8i3zI+jD5+/nDOfD8H/vZPrH+HAAs/5IA+cBSgHEAJ77y/t3+UX6I/1R/hACTwOEBtoHwgk9CzEKmgssClELEQuiC0cKVwoXCPUH5AU/Bm0CZQPW/S3/4voR/Db6yfqA+VT5Qfd/9qrzkfJb7zvuue3B7JTzL/Ou/RH+twK4A2MCowPOA08FoQgzCggNgA5hD5oQZxCLERwQUxHjDD8OfQjdCeIGUwhJBr4HeQK5A/n98f7w+6L8+Po3+0/6B/qg+dn4PPci9qj0kvOn9N7zK/bJ9V/5SfmX/sv+iAC/APr79vsn99D2Zffz9sj6UPoL/5j+IAQFBCcJoQmwDOANoAw2Di0IiwmZA2QEjAK5As8BjgHr/37/ggBAACkDOwMLBB0EhwNkA2gCBgJF/8L+Bvt++g73kvan8w/zSvSU8wL7Wfr1AYgBpgRoBMIEzgTHAwUEIANuA58F9AXDCCEJtAbsBm3/XP9J+A34F/fd9u/8+vzVAgcDYgJvAsz+n/7i+5D7OPmv+Kb5/viE/wj/cAU5BaEFnQU4ACMATvn8+JT2//Xu+Er4Tfug+gz7dPp/+hL6EPvN+j/9BP0IAbsA+QOKA8ADSQPTAHoAeP5O/t7/AgDbAxoESwZ9BokFiwXoAuMC9AD9AFoBfwEqA04D8ATeBD0FAQXgAYwBtvxY/Mv6lPp8/Gv8uf+f/zgCFwI/APf/Xfv2+g/6r/nl+5T7jf0G/Yv/0/66/+7+q/zZ+4/65PmS+iv6FPut+jj95Pzx/qP+tvxZ/Mr5ZPl5+i/6sf6B/s0EyAQ7CWMJvQnvCY4HyAd8A5EDWf8l/yr+u/1o/gD+K/7F/Wb/Tv/WAOQA0P+8//L+if4d/5P+rv7+/QP/kf5YACEA6f/O/+3+vf4B/8H+lv5G/qj9U/1x/Tn9Cv7Z/fL/2f+RAogCdQNvA8QCtALbAckBtgCaAF3/KP80/vT9Kf3k/ED89ftJ+wb7zPp6+vv7svv0/bf9E//m/sj/o//j/9T/Df/9/ur/6v9MAnYCMQJZAqMAwgDkARQCmwPpA6UC2wJ/AakB0QH7ATMBTwFQ/0f/Y/0u/bP7QftK+9L65Px1/N79kP0y/eX8+Pyu/Ff9Af2g/Df8DvyX+1j9/fwj//j+YwBrAJ0BvwFmAp4CQwJcAt4B4gFMAj4CygPeA0wFfQUgBWgFgwOwAxYBCgF8/Rr9lfnf+G73jfax99/2Xvq5+QD+lf2s/0z/P//K/mD+zP2D/NL7YPqa+YX72Ppx/xD/CQPcAngFjgV0Bp4GLwVVBSYEOATqBPAELQUnBTIEDgR9A00DaAIrAsIAYQBSANj/GwGOAFkB0QARAZ4ADwC6/+X9hv3C/FH8nP4x/hwBsgABAYMA7P5C/oP9vvwW/kz9oP/c/oIAxP9pAMD/7/+C/1n/Ev9Z/hX+O/3P/BL9dvzQ/Sj9yf0T/SX9bPyr/vz95AFTAQcDdQJwAc8AGv+I/lL98/xf/Un9wf/5/zsCmAIKA00DKgIvAgEBswDVAWQB0gRvBH0GQAbDBaUF9wP1AzEBNAE+/jz+2/zE/HX8UvyD/G78+f0C/t3/8v/9APwAbwEzAXkAGwDH/mj+cv5B/qL/z/8AAsACKwV6BrUFJwc0AnADF//r/zX/yP/FACYBggGeAVgAJgD4/Z79cvsX+6/4RPhU9/32cfmB+fv7ZfyO+yP8s/pU+wr8h/wP/n3+N/+J/7f+2v73/PP8jPzL/K//VAA/BWMGAwq8C1ELYw0hCTcLrQWgB/cClwQxAlIDKQLyAtT/HwDb+ob6kfbV9Wn1mPQl9232cPn6+BP6AfoP+jL6zvo7+xX8vfyc/kv/sQJxA3QFUwZlBTYG2gSVBe4E2QXJBdYGqAcACQ4JrwoiB8kIrAL2A/r+IACX/Yb++vyH/VL8mfw2/DP86vt4+6n50fjq9s31mvZa9Y74nvc0+sb53/qt+gb8CfyL/dH9/P1L/nH+tv6bAB4B9AK0A1IENQX2BRkHxwbzB/0E9QXaAsIDgQJPA+gCpAPUA6wEIAUBBlsEBwWtAAoBjPyB/Iz6GPqG+w379/62/r0CvAIxBGEEEAJSAsv9tP1o+f74S/bJ9XL29fWA+kX6ef++/94CWgP8BGoF0AQyBd0BCAJg/0L/JP8S/zn/N//0/uj+wv6z/p/9cf1//A388/2J/VABGQGMA3EDZQNlA0kBXwEA/tT99Pp4+t75H/k2+1v6r/3O/Fr/tv4yALz/ngFMAY4DdgOQBGoEnQNOAy0BtwA8/qP9FP1k/Bf/pP7NAo8COgUSBWAFSAWhA5UDXAEjAd4AmABVAkMCpAOPA64DlAO9AqkCMgH+AJ8AXABNARkB9gC/ALr/Yv8v/9H+fP7//d79VP0A/5T+yf9r/2H+8v11/RP9bv0a/av8KvxJ/ez8xQC0AC0DQAOjAtYCxwEkAp0B4QFTAZIBzAEgAiEDggPCAiYDfwDeACcAgQCRAvsCsQMNBP4BEgIzAA8AY/9M//z+6/7a/8z/0QHzAXUCngIhAP//bfsN+133vvZm97v20vuU+6kBIwI+BvoGygeOCOwFpwbcAmQD9wA2AWIAtwD5AIABlQI3AywD1gPCAWsC2QAlAY8BdAF1AVMBqf+s/+r97v0+/Gf8GPqV+vn4afkn+h/61vyR/Lb/k//OAcsBUgKYAicCvwIHAr8C7gG1At4BogLCAVUC7ABAAY//EgAd/8n/twAkARQEbwQMB4wH9gY2B6sDXwPj/z7/Qv2l/EP72Pqd+YX5pPmx+Rb8FPzc/hD/vv8CALT/Uv9NAB//tACT/w0AcP/A/2D/EwABAC8AwQCNAIgBowGPAsUCcQP3A3kEYwXjBVkFIAY7Ax0E6wBNAeP+1v7/+6r7avmP+LX5d/jJ/GH8hgCdAfsCxQSIA6MEdAJMAhIAuv5K/Sj7qPxR+jb/tv0LAhwCbAK9A0QBlQLT/4IACP9j/9f/HQAuASIBYgFEAUoCqwL6BPoFngaOB+oFDQbyBEYEkQOnAvj/Xf8Z+9z6avdO95L1VfUY9UD0CPZO9Cj51vbR/dj76QDj/ywABwCa/cT9ivyC/K/9a/3U/zb/dAJkAYQFrwSQCOMItQoiDEIL3wzqCaYLXAdsCcEEGAYSA24CrgO/AWUHCwZEC1ILGAnDCQEAggC+9xz4u/d1+Gb/dACtB2gImgaNBjb4xvdT6YzoAutt6cf8DvrFD2INIRa1Fc0HxAjt6/HrD9sW2j3nvOeLCXwMqitdLhY1RzWlHPYa+fW4857dJ9vq2wPaneiY6B/6Kfx5CGUL5g/0EWsSmBJ2EgcSFhDEEDkI/whz+P/2CeaY4pXacNew3Nba8e4C7vMItAiyFcIVowvkC9n65vpt84nyofOh8RX2APSI+2D6wAMIBOANQBBlHdYh1y/iNKozbze9GiscJfJL8fXWbdX12B7ZQvR09hMZSxugMkE0sDPDNYQbnhzN8FHuAcnYxBnEZMKg4zfkhf/v/jD5nvXM2SbUP7xytlW4tLSF2eTZMhFDFmg+x0ZfSJxP2ir/K5n5Y/R03C3Wv+zL68YVGhzJLK42pyRnLW8WZhzNGMgbkCEcIRYaRRcBAlb/veou6VvdiNyV2w3b5ehu6Pr9D/6ABXUGL/cg95PmpuMq7NfnhAeMBOIdEh2ZFpwX2fig+37kU+go7L/vyAP7BVUVYRZhGIEZchLUE3YKswq1AkABofz7+gb67fnb99r5R/Ef9P/pIuty7Hbqu/xR+aEUOxKgJ68m4iV6JdIHxAba22PZUb/ou6/DR8EP4p/iwQgVDWArjDJsQjFJsEMXRr8qIyiWCN4Etvap9tX4xv27/bME9fqU/kvzSPCQ69zjK+cj4N3pk+YJ9kD2ZAmQC88VbBfdCAsHbObA4EbL3cT2zqLLXPIz9AUkOirERj9NFkRlRs4hsh8X+Qf2Zt6o3L/aUNqr6yHthwH7BasMCxOoDu4TmBOZFdcbGRpyF/USu/yJ9xPaCdYgx+rEJc0dzNfkpePR/5X9qQ+ZDUEQwBAACsANXgWBCj0EFwhFBw0I9gunCSIMhwi2CMoGFQxUDkAb8CG+LRA2+DSxOj8msyYoA7n+fdwi1nTIZ8OJ0JLNK+mz5vb8DvqQADH+6/jY973wRfDj7YXs+u857ZbyDO9a8g7vpvI08Ef6uPlSCqUM/BpzH7AiPyYFHgUfdROOExULtAwbBZ8H7/yx/Zz0I/Oz9BDzpwC4AHoQaRGoFnEWVwxECtP4S/bJ62Xqte3P7fr4vvmlAVsCHQHFAPD5u/cA9ULx3vm59tkGfgaSEEQTLA0SEZH+sQGt8Dryle7c7o75fvhsB8QEfAxjCOwGFwN3/x/+G/26/57+eATc/lgFN/sN/yr2F/Xd9UHwy/2M9kQIQwPNCnMKFQLSBS72Pvty8qr1bflS+UkDvgCDB7cElgRHA2/+kP4Q+Vf5AveA9i75JPg4/pH9DAI9ArcBbQLNAHQBkwXlBSMOUw76EKUR+wnRC8P/vwJG/P3+igIfA6sLjAm9DqYLpAoeCR4ENgUr/osASPnB+k/2CvYp9u/0PPcP9sH1gvRx8SjvAPF27df4SPUWAjUAVwL+AuX4RvsR72nxS+4F76X2KvW9ACP+tgjJBlsPgA+9EqYUGg9+EWsGiwh6/7cBCv61APP/WwKMAYUCOgOCAhEHkQVCCggJagfmBnX/1/8R+oj7I/xb/qABYQMhAy4DNf9e/Yn6z/fB+C72FfkP98H4XveX9/z2zfgp+Uv9bv4WAYUCKgJHAzkDlwPPBDUEPQQHA9kB+QBTAZ0B/QM3BYgGrwdABaYFwACkABn9F/0N/CX82vt5+076Fvl/94v1Kvb/8474ovZ+/ET7Yf/t/kEBVwHhAdMB0/9k/8/8X/xX/Hn8tP9tADcGEwceDcsN/Q+cEOkMdw02BngGTAAoAJX+c/46AbgBKAVBBrcG1AdKBOAEAv/u/k/6u/ly+WD4nfsQ+nn9wPul/Df7z/n2+EX44vdf+mT6cP7d/rcAiwEnAPYA7/40/5P/Pf/9Am0Cjgc+B4AJawkTBv8FQv8x/y36hfoG+v36/v1Q/8oCEAQVBfUF9gNeBFkB/gC2/o/9+/xs+9r9svyEAFkAiQEyAjcAOgFF/3IA5P8OAYkAXAH9/wcA7v0b/br7h/qt+4/6Cv47/R0BogAYAyYDGwPkA6wBHgPIAIAC9gGiA9UERQbJBqwHkASBBAH/9P29+1D62f0B/YMCtgKZBbkGyARVBlf/yADz98f4k/OO89T0D/Ry+lT56wDM//sD8ALfAeYArv30/Dr7DvuU+yb8Gf5s//sBzwNgBV0HeQYHCJAFWwapBLIEuARqBPsEvgQ5BV0FBwa9Bn4GuAfRBDEGzgDRAWv8tPzk+Yj5P/pt+cH7nvqw+0v6Lfq5+Hz5Pvg5+l/5Nvu4+nz8Y/zx/kD/yQFxAjAD2gMcA4ID2wL9ArcCqwKCAnECGQMSA2wElwRyBc0FTAXXBaoDGARKAGsArvx0/Nj6VfqK+tn5pvrU+fH6EfrD++z69/xH/H7+8v35/7j/AAHsADoBZwEYAVoBEgFlAXUB1wF9AvICaAQJBSgH+gecCaYKNgpJCz0IMQmMBDMF/wBXAZL+pf7K/KT8NvvR+gH6dPnZ+Bb4rPfH9pH3h/ak+Iz3eflt+IP5lfhR+X74/fhM+J75CvmV/Df8kACHAP0COAMiBLgE3QXJBvwHPwldCdIKYgnPCowHygiHBHwFmQJgAxQDvgO5BFEFLwWaBW0DkwMJAM//9ftS+3f4efdV9yn2n/h496v5mvjw+MP32Pej9sz3lPZ3+ID3L/qM+Tr9Bv1DAY8BjwVRBrMIwAmsCbAKPgkpCnMJYApiCmoLTApjC1sIUQnVBZgGvgNQBBMBLwFV/er8vvrQ+Xz6WPmQ+mX5Mfnl96H2K/VG9KfyDfNj8Ubzn/Ey9arzsvmG+OT/RP+LBHoEuAXmBUkEkwTDAf8Bxv8PAOr/SwA2AtkCjQV4BisJYQoJDFENogzFDc8KrAtFB8MHmQLLAvz96v1B+xX7Hvvt+n78Pfy//WL9U/7M/W7+0/1C/qv9EP6Q/Qz+tv3U/Zf9vvyF/Dv75PrN+l/6SPzh+1n/G/8BAxMD/gVTBs8GVQcFBXwFggHKAd397v0T/BD8Qv1A/VAAbQATA0MDiATHBEoElQRaAooCMwBQAJz/pf/B/7r/1/6+/vz8rvzt+4D7wPxJ/Oz+jv6TAFAAJADS/6r9Rf1E+8L69vqE+sT8Zvzi/qL+tACMAFYCWQINAxoDWgJ4AsYB2QFNAogCFQN4A3ED7wNwA+0DYwPEA2IDqwOJA7QDWwNxA84C0wJJAkcCgQF6Adv/rv+M/SX9Yvu5+lv6gvni+gL6mvzH+17+tP1i/9H+Lf+u/gv+hf3e/FP8bPzi+w39mvzB/nv+BQHxAP8CDgNPBHkE+AQrBcMEAQW7A+4DUgKCAh0BPwE8AFUAb/9h/+D+qv5M//7+XAAGAOMAmQB9ADUAv/+F//P+u/4Y/tz9W/0H/Vr9AP20/mT+pgB6AL0BqwHkAfEBqwHCAbQA0gBA/0v/lf6X/hb/Ff9LAEwAewF0AcMBuQH+AO4AMgAeANL/u/9+/2L/gf9u/xoAAwDk/8z/Zf45/jn9/vyY/V79cf5J/sz+vf5N/1//vwD+AFoCvwITA4gDlQL8AnEBuAF0AKIA3f/1/6b/sv8CABcA4AD6ANcA/wAZ/zb/1vzi/N/72PvQ/NH8+v4J/+EAAAFhAYEBiACmAE7/Xv9g/mf+/v33/Sf+KP4I/yD/xQDqAG8CrgIJA0oD0wIVAwoCPAJGAGgAP/5Z/lX9Yf22/b792f7s/kkAYQBhAXkBLQEzAYn/jv+j/Zr9q/ya/Av9CP1k/nf+6f8OAM4A/ABxAaYBgAK3AmQDnQPWAggDKgFRAeX/DwCa/8L/tP/f//D/FwBcAHYA1wD2AAcBIQHUAOwAtQDOAA4BJwEwAVYBOABLADv+Of56/GH8Qvwg/N39x/2TAI8A/wIFA7EDxQM/AkcCZv9e/xz9Dv0J/ff8gP6H/rf/xf/3/w8AEQAeAKYAuADyAQoCeAOPA8QD1QMkAjYCa/9y/6n8mfxM+0P7IP0n/XEBmQG2BPUEFgVlBRIEVgT/AjYD4gESAqkAywCY/6n/sv68/hj+Lf6r/sP+vADWAE0DawNcBIME7QILA/v/CQC3/bf9g/2P/cL+z/6M/47/DP/6/nX+YP4Z/wH/9ADqAEkDXwPTBO8E3QMLBIkAjAD1/Or8kPtt+yj9Ff12AHYA7gL6AtsC9gLwAPMAaf5R/nH8PPwH/M771PyU/In9Wv0F/tv9z/66/o//gf/y//D/KQAkABMAHgAtAEUAuwDZACYBTgGWAdEBsALuAnYDsAMNA0UDsQLlAvUCJAMiA1gDYQOUA74D8QM4A1sDJgE6AWz+X/5f/D78KPz5+1z9Kv0//gv+Sf4W/gX+yv2A/UD92fyc/KP8aPwL/dj8w/2g/RH/Bf8CAQoB5gICA68DzgPmAgsDiwGeAWIAaQBo/2r/GP8S/4n/gf/v/+f/KAAiAKIAmADIALYA6f/Y/6r+kv5l/T/9Svwm/DT8D/xF/SX9rf6R/uj/3f+pAKcAgACCAA4AFABEAFcADgErAbUB2gEgAkkC5wIbAy4EaQTYBBwF7AMTBBsCSQKoAK8ACf8W/2b9Uf0C/en8R/4n/m3/VP8n/w3/Nf4M/hP+5P2g/oD+rP6P/uj9zf2w/ZD9pf6N/p7/jf+7/6T/Of8e/w//8v5X/1X/4P/b/w0ADwAQABYAKwA3AGQAbgCtALYADQESAUUBVQEaAScBvQDLAIYAiQCLAI4AagBjAKL/jv+D/m7+Wv5C/hT///52/2X/KP8Z/7/+ov6S/nD+6v7I/sv/qf9vAEIAFQDx/43/X/8E/97+Pv4N/pb9av0j/vr9lv94/94AzwB5AWsBxgHDAUQCPwJjAmQCogGfAeAA0wD+APEAigGFAd4B3gEJAgMCzwHDAeEA1wCb/4P/Qv4U/kr9Df30/Lf8B/3M/D79B/0a/uT9fv9a/2YAUwBZADoAbf9Q/+P+xf7P/8H/eAFwASICLAIgAisCGgIpAnYBeAEuADIAxv/I/5YAmwCuAbgBCAIgAoUBjQFCAD0AFf/1/nT+V/7Q/qP+kv9t/6n/g/8G/+L+kP5s/jT+B/6S/Wz9gP1h/Yf+df4aABcAjgGpAZsCtAKhAsECJAI4AgMCKQI6Ak4C0gH3ATEBVwFKAW4B2gEEAisCVAI4AlkCAgIOAigBNgFLAFMA9P/x/0X/MP+0/Z79w/yo/Az95vwD/u39xv/A/6kBrwHWAd0BFwAWAIz+h/40/hz+jP6E/lH/Uv9UAGAADQEaAUwBXgGQAaIB+wEHAjUCQgIDAgwCNgE8AbX/p//S/bn9xfyc/CP99vxq/kv+n/+G/zEAKQBzAG4AwwDLAOgA7wCfAKoAPgBAAC8ANQBbAG4AGAEvAQ8CMALUAvUCRwN1AxsDQAOeAboBzv/0/4//ov89AGIAoACzAFsAbwCX/4z/fv5u/kz+QP58/3D/fgCAACwAKQCl/qb+Qf02/Sv9I/2F/on+QgBUAG0BjAGNAa4BwQDkAPP/CQDC/9j/DAAjAJ4AxgBRAXoBgQGtASwBVQGrAM4Asv/D/0v+Vf5t/W39XP1a/Zb9nf34/f/9jf6Z/in/Of9M/1r/8v4K/x3/Pf+PALMA9wEsAvUBKwL4ACUB9f8TAJv/vf9xAJ4A7wElAp0C3wI5AoICgwHPAdQADwFOAH0ARABwAJEArwCuAMkAnQCpAGAAZgDx//P/Vf9J/8z+y/7e/tL+Of9D/zr/Pf+5/sD+dP52/rb+uP4V/wz/0P67/vn92v2v/ZT9n/6N/u3/5//VAOQAhwGgAcEB4wFZAXkB5gALAQcBIwEgAToB4AD6AIEAjQA4ADgACwACAJv/iv/b/s3+h/55/tv+0v45/z3/Of8+/wT/C/+//rT+bf5f/qb+k/5h/0j/pv+M/zz/Kf/v/t/+K/8b/4n/j/8dACgAIgFHAaQCygL3AzQEewS1BJEDvgN+AZMBaP9o/0j+Ov4n/hT+jf5z/hr/DP+v/53/9P/l/8D/tP+J/3n/a/9U/9L+tP6u/Yr9wfyU/JL8XvxD/R791v66/m8AYQDyAPUAwADHANcA8QBNAWMBegGbAWUBiAFQAWsBCgEjAZMAogB/AIgAGgEZAZ0BnAFWAVYB0gDSAHIAXQDA/7T/pf6I/lf9Mf10/EH81Pyo/H3+XP4yAB8ABgH4ADEBJgHMAMEAFQAJAJP/h//G/8P/mQCcAKABtgFMAmACUAJnAuEB7AFoAW8BWwFfAZQBlQE8AT0BTABKAIj/d/8d/wj/vv6h/rH+jP7L/qH+p/6E/nz+W/5+/mP+u/6a/kb/M//u/9j/HgATACoAFQBCADUAQwA+ACgAIABPAE4AqgCnAOwA6wCnAKMA7v/d/5//kv9NAEMAAwEGAekA5gDq/+P/ev5i/nL9Uf2W/XD94f7A/rgAqABIAkUClgKeAqMBnwEsACkA/v7u/sX+uP6S/4b/bgBvAOIA6gDyAPkAegB7AOz/8P8bAA8AZgBgAFgAUABsAHEAuAC+AKUArABiAGUABwAEAED/Nv/Y/s/+c/9v/7oAwQDsAfsBRAJbAoMBiwFJAFAAhf+B/yn/IP8v/yv/h/+E/+D/3P9NAFAA7ADkAAwBAgFwAF4Anv+K/87+s/4L/vH92P3F/XP+Wf5X/0v/DQAFAK8AtABoAWoBEAIhAmsCfAIdAi4CMgE7ATsAQwDl/+r/DQAYAFQAVgCJAIwAhQCIAHAAbwCEAIEAegBwAC4ALwDz/+X/iP97/+7+1f7U/sX+Vf8//6//pP8eABwA6wDuAHkBiwF4AYEBOgFJAQsBGAHqAPQAkACgAO//8v+L/5j/6//p/1sAXQBSAEwA4f/V/0H/Nf8E//P+Tf9D/4//g/8d/w7/J/4X/kn9Mv1g/Vr9Bf///gQBFgEMAiACxgHkAeEA8gAXACsAEwAjAJ8AwAABAR0BzADtACQARACS/6v/dP+D/8X/1f9bAGwAygDeAC0ANAC4/rP+B/4C/oT+eP7o/ur+Df8O/5v/rv+IAJwAKAFRAWwBjQENASoBWQB4AOr/BwDk//v/GQAtAJQArgDaAO4ATgBeALr/xf9KAFUAIgEsAf8ADAH1//j/3P7Y/h3+E/7V/cb99f3e/VL+Rv7p/uD+ef98/6X/pP+6/8b///8KACEAMwArAEQA1ADyAJwBvAG5AdwBUAFvARMBKwESAS0BRQFbATkBSwFjAGwA8f7w/gT++/0Y/gP+2v7R/t7/1f8wACUAev9s/8X+s/4J///+kf+B/5n/jv+v/6f/BQD7/wMAAAD5//n/tAC4AKoBrQGzAb0B2ADhAAIAAADI/8r/IgAnAJ8AqADZAOIApAClAAEAAABV/0n/+/7n/uP+yv6m/o3+Vv47/m/+Vf7O/rb+Gv8L/zj/K/9u/1//1P/U/3YAfQD0AP8ABQEUAeYA7wC1AMMARgBKAOL/6P8wADgA/AALAZQBtAHeAfMBwQHiAUUBVAGoALcAJAAkANT/yv+5/6//hP90//3+5f65/qP++v7a/iT/Df8o/w3/Cv/w/sj+tv6o/pn++P7y/lf/Sv99/3n/0f/M/1IAUgAAAQEBvQHNAU0CYgIpAj0CWAFvAWoAeQAAABQAGwAhAEQAVQChAKsAGwEtASYBLgGbAKQA4//f/yn/If+L/n/+Yf5R/qP+nf5d/1T/MwA0AIcAigB2AHYAZABiAA4ACQCK/4P/gP9+/9T/zv/1//f/LgA1AJAAkgDUAOEAPQFJAY8BlgEwATkBpwClAGEAYAAQAAkAoP+Q/1v/Tv8+/yf/Lf8h/27/X//g/9n/TQBGAGMAYADS/8f/Gf8L//L+3/4h/xH/P/8u/37/e/8DAPn/bAB0AK8AtwD+AA0BRwFXAWABfQE3AU0ByQDeAFkAZgBKAFkAlwCdAM8A1QDtAPMA7gDwAHUAfADw/+3/BQAFAGYAYgAtADAAf/94/xb/DP9m/13/RQBBALUArgABAPP//f7r/sD+r/5C/zb/8f/p/4AAgADCAMoAtQC7AGoAdgAeACAAHgAkAFMAVAAsACwA5v/p/+n/3v/N/8X/iv+B/6L/nv8aABkAewCCAKwAvgCBAIwA5//0/4n/lP/K/9P/UwBkAM0A2AAAARMBzADVAGoAeABKAFEAZgBxAJkApQCVAKUANgA/AKX/sv9u/3D/h/+O/8j/y/8ZABcALQAtAP////+W/47/Iv8Z/9/+0v4f/xj/dv9z/7f/uf8hACcA7gD5AGABbwE+AUoBsACyAP7/+/9a/1T/6v7e/qj+n/6//rL+X/9f/yAAHwCEAIUAewB/AFIAVAAFAAUAnf+d/1H/UP9V/1j/dv9y/5j/of8mACkAGQEpAbEBxAGkAbkBNgFMAZwApwDz/wEAd/97/yf/K/9M/0v/6//u/38AgwCUAJQAaQBsAA8ABQBQ/0z/v/6y/pz+jv6z/qX+8f7m/lr/Tv+1/6r/BQD9/zoANwALAAcAvv+3/7P/sf/l/+f/CwALAA8AEwApACMAbgBvAGcAYgDU/8r/gP9x/9n/zf8yAC0ARwBEADwANwASABQA+P/3//b/8f/C/7H/fP9s/4T/cv+D/3D/VP9G/5X/hv8vACkAjwCGAHAAbgApACgAIAAlAEwATAAuADYALgApAGcAZQB3AHYAJwAmABIAGQBxAHcAfwCJAPb/9f9E/zj/5f7O/uT+1P4q/xz/uf+u/0IARABPAEoAuv+7/zb/L/9O/0f/6f/p/5QAlQCtALIAPQBDAOv/6//3/wMAWQBlALgAzQDYAPMAwQDYAKEAsQB0AHgAMgAlAAQA9/8JAPv/JwAjAEkATQB4AIMAeQCLAFEAWAAdAC4AMAAxAG8AdQBlAGkAwv/A//X+9f7Q/s/+cP94/1cAZADgAPQA+QANAZYAoADW/9r/Qf8y/xr/Bf8b///++P7h/vb+3f5H/z//+//1/98A5gB+AY0BfwGSAfQACgE7AEcAqf+z/5b/kv/S/9P/JwAiAH0AigDHANYAwwDeAIoAmAAPAB8Adv9u/wH/+f4q/xb/of+V/+//4P/t/+b/2P/I/+3/6P8jABwAVQBdAIYAnACUALAAcwCXAGIAeABoAHcAOQA6AOD/3v/V/9f/JgA1AKwAwwD8ABgB0gDgAFYAXwDR/8T/df9o/3H/Yf99/2n/bP9h/3H/Xv9+/3j/e/91/6P/rP9AAFIAuADYAKkAxgBlAHwAKAA1ANL/0v+z/7T/CwAJAH8AiwCsAL0AnACwAI4ApgCdAK4AxQDTAOIA5QCMAIMAsf+k/wH/5/7W/sL+Kv8b/8b/xf9TAF8AewCTAHQAhABVAG0AOQA3ABMAGwDc/9P/Wf9Z//H+7/4G/wn/gf+D/18AZAA8AUUBSAFSAc8A2ACGAI8AbgBwADoAMwAAAPL/lf+E/2f/V//P/8z/ggCFAN0A6QDKANQANAA0AGD/XP/y/uT+CP/6/l//Wv/f/9j/JQAtAB0AHQAEAA4A+f/4/8j/zf+g/53/lP+Z/67/rP/E/8X/pv+c/43/hf/S/8T/GgAUABoADQAlACQAHAAXALr/wf+t/6P/GQAiAFsAUwAHAAcA0f/D/9j/1f/q/+L/1v/V/wEAAgBCAEYASwBTADAAMwBJAE8AegB+AIIAgACCAIIAWwBYAOz/4f9l/17/NP8f/1r/UP/p/97/ZgBiAHcAewBIAEwAEQAUAPz//f/y/+r/1f/J/4T/eP9h/1b/iv+F//X/9/90AHcAgwCJAAgABACd/5f/dP9s/3P/Zv+5/6//DgABAAUA+f+4/63/l/+L/8X/vP9EAEQArgCxAHoAgAAHAA0A0f/O/5z/nP+//67////9/wAA9P+//8D/1P/W/xgAHQBwAHQAtgC6AKoApwAfABwA0v/M/+j/4f8YABMARAA7AEcAQgANAAcA3//f/wMAAwBHAEoAWwBkABcAGgDp/+7/8P/w/wgACgAOAA0AHAAiACkAKgAgACQABgAIALn/uv+C/33/mP+W/7f/rv+6/7T/8f/l/ywAKAArACYAEAALACUAJQAhACUABAAJABoAHgBaAF4AhACJAIkAjwBZAGQAGwAcAPv/AwAFAAQA+f/6/9n/2f/K/8n/AwAEAF0AYACPAI4APwA6AMj/uv+g/5D/vf+t//D/5v8DAP7/JQAlAFUAWgCHAIwAcgB2ABMAFwCw/7H/qv+w//T/+P87AEEAQgBAAC0ALwAeABoALgAuAHsAgAC4AL0AZwBxALP/qf9V/0f/Yf9J/2n/T/+C/2n/1f/N/ygAJABZAGYAhQCSAHgAgwAPABoAxP/F/7P/uP+t/7H/rv+u/9H/1P/w//D/5P/m/9f/2f8dACUAoQCpAOsA+ADNAM0AMQAqAHv/Z/8s/xD/cP9Y/97/zf8yACoAcQB3AHkAfwBRAF0AUQBWAFQAWwBPAFcAPQBEAA0AGAAJABEARQBNAGAAaAAtAC4A8v/t//H/8v8MAP3/+P/1/+b/zv+0/6r/jv93/6f/mf8kAB0AegB3AEQAPgDm/+P/xv+3/6z/qf/M/7//MwA4AMEAxwDjAPgAcgCBANX/3v+e/6D/tP+u/7z/tP+U/4f/Qf83/xT/Cf89/zX/ov+c/+z/6f8HAAYA6P/n/6P/o/9f/1v/Xf9R/5//mf8OAAMAWwBhAKIApwDTAOoA4ADxALMAyACAAI4AMAA0ANv/3v/J/8X/x//J/9L/0v8PABYARwBUAEUAUQBcAGsAYQB0AOr/9v9l/2v/bP9u/8D/uf+//7f/kf+K/4L/f/+7/8H/FgAjADwASABcAGgAUwBYAPX/9/+q/6r/1//b/x0AKAAqADMAAwATAMb/zv+R/53/1v/b/08AXwCdAKoAjgCeAFgAZQDx//f/hf+H/23/Yv+c/5j/vP+0/6v/qf+//8H/DwAWAGYAbACDAIwAPABBAJj/of9c/1//2v/p/48AmQC2AMYAYABrAA0AGgARAB8ASQBXAGMAcAA8AEgA8f/4/7P/sv+q/6b/nf+T/5D/f//O/8b/KgAkAPn///+p/7H/CAAUAGsAegBkAHEANQA8AP7/AQDr/+3/MAAuAC0AOgDH/8f/jf+Y/+7/+f9sAHQAmwClAG8AawD4//D/lv+K/5P/gP/C/7X/AQD1/wMAAwDS/9X/sP+7/wcADgCjAK8AFAEXAb0AwQDT/8//Lf8v/zD/Lv/P/9f/xgDOAA4BGgFdAGEAw/+8/8T/v//a/8z/q/+d/3n/Yf9a/03/XP9M/3v/dP/t//D/3wDhAHwBlAEpAS4BQABLAJf/lP8f/yD/PP8w/xIAFgDlAOMA1ADdAFcAWAAnACoAVgBWAHsAeQBNAEQAzf+//0v/N/9L/zb/1f/F/0sAPwBIAEIASgBIAF0AYwAjACsAk/+R/2L/W//J/8H/IwAcAPH/7f/M/8b/NgA4AH8AgwAMAAkAt/+u/8T/t//c/8r/8//i//f/6v/Q/8T//v/0/20AYgA7ADgAtP+j/5n/l//B/7n/+v/6/2UAZQBnAGcA6//q/83/yf9AAEYApQClALwAxACaAJoA/f8CAHb/av+e/5b/BwD5/wIA8//s/93/CAABAO7/7P/A/77/MgAzAMwA0ACfAKAA5P/f/2b/Yv+J/4H/FwAZALAAtQCzAMEAOABIAMf/1v/F/83/8f/5/w4ABADl/+H/pP+S/2n/Y/+W/47/+/8AACYAKgAlACsATwBUACYAKQCz/6//xf/A/2gAaQCEAIoAIQAnABoAIwBVAGcARQBQAEQAUwC2AMAA1ADlACMAKwB4/3P/kv+M/+H/1P+H/3b/Av/3/jv/Nv8uADwAHgExATMBRAFTAFYAPv85/7P+lv4D//n+/P/v/4YAlwCdAK4AwwDgAL4A1AD//wcAsv+p/0MAPwBKAE0AZv9d/yv/K//f/9f/OAA0ABAABAAbABkAMwA1ACsANgBfAGgAXwBnAKD/mv/q/tf+Zv9S/w0ACwDM/83/l/+k/0QAWwDVAOkAhACTAAMA9/+8/7b/hf9q/1H/Qv9O/zj/kf+J/xAADgB2AH4AkACdAIYAkQBnAGgANgAtAMj/uv/6/uf+lP6K/nv/ev+UAKgAjgCfAAwAFAA/AEcAsQCyAJIAlgBXAFYADgARACH/I/8w/hv+k/6E/iEACQBGAUYBjQGWAfEADwH7/xUAaP91/1v/UP9J/yv/Rf8k/0j/O/95/4T/DgEtAV0DlQPsAhMDlP+U/1D9M/2u/ZH9rv6a/pb/kf+wAL0AggGYAaoBtgHBAMAAL/8f/7H+pf6b/6b/SQBZADgASQBZAFkADwAFAG3/Vf+o/5r/nQCrAPgAFgHBAOcAaQCGAKD/qP/T/r3+6f7E/uP/zf/+APwAhgGaAQIBIAGz/77/r/6u/r3+pf6d/4n/WwBMAHsAfwCPAJgA6AAAAd8A6wD6/wEASf8//5T/kv80AEAAcgB5AGMAcgCAAH0AkACOACwAHQBe/1P/LP8p/9z/6/+hALQAjACbANn/0v8P//j+vv6b/gP/5f6s/6D/SQBXALkA0gDeAP0AwADSAC4ALwB3/2r/RP8s/6//qP8iACQAXwBwAL4A0gDgAPgAlQCiAFEAVACNAJEAkwCRAP3/+f96/3D/d/9u/67/pP8MAAMAfwCCAKYArQBSAGEA2P/i/3f/fP9B/zb/ZP9a/6n/mP/S/9L/IAAnAI4AogD2AA4BCAEdAZAAnACt/7H/YP9X/9P/zP/8//X/lP+D/4T/fP/X/8v/7//v//z/9//0//n/u/+4/6T/n//H/7//2v/K//L/6v8bABIABQATAAUADgBbAHcAoACuAJkAqABzAHIADgAPAK7/pv/P/9D/RwBIAJMAlwBvAHIACQD//73/uP/y/+X/BAD+/+n/5f8NAAcAJwArAML/vP9Y/1T/cP9x//r//v+aAKcAxADUAEMAUACj/6n/iP+K/7//wP8VABYAWwBgAGUAagA8AEMAzv/O/2D/V/+Y/4n/8P/h/5f/iP9g/1T//P/+/4sAkgBrAHIASwBRADMAMwDG/8n/kv+Q/7//x/8fACoAXgBpAEQAUwD4//n/4f/r/yEAIABDAE0AYQBkAFIAWgAdABoA/v/4/xYACgAQAAMADgAGACIAIwA7AEIAOwBEAP3///+i/5z/jf+C/6v/n/+L/4T/oP+e/ygAMgB6AIcAJgArAMr/y/+b/4//f/90/43/gv/G/7r/DQARAEUAQQBFAEsA///5/6n/oP+U/5H/7P/k/zoAOwBEAEEADgAIAMT/vf+b/5T/w/+5/+z/7f/s/+v/CQAMAGAAaQBUAFUA5P/j/7b/sP/e/9f//f///x0AGQAVACAAJQApAGYAcQCOAJgAZQBoAD4AQwA4ADcAAQAFAKv/pv9t/2r/m/+V//n/9/87ADsARABLAEEARwAyADkABgALAMn/yP+H/4P/kf+P/wIA/v9ZAGYAYQBlAEoAXABQAFsALgA6AAAACQDo/+j/5v/q/wMABAAYABgAGQAbABgAFAATABYAAQD9//j//P/8//7/BAAKACsAMABoAG8AagBtABIAEgCz/7D/qP+k/8L/yP/p/+7/FgAgAHQAhQCvALUAkQCeAEMAPwDk/+D/p/+e/6H/m//L/8X/FQATAEgASAA8ADkAJwAkAA8ABQDs/+r/2P/R/8b/xv/C/8L/2P/Y/9z/3//m/+P/CwAMAEMARQAyADcAFQAbABkAJADu//f/yf/P/+n/6f8HAAUAAQD6/xYAEQASABAA8P/w//b/9f8LAAwA7P/l/9H/0P/j/9j/3v/g//7/9P8hACYAIAAiABEAEgAQABQACgAHAOf/6v/U/9b//P///y0AOgArAC4AIAAsADAAMQD//wYAsv+v/6j/pf/H/8n/3v/b/9P/1f/c/9r/+f/5/x8AHQAWABMA8P/t/wYAAQAQAA0A0//Q/4j/hP+M/4b/0//W/zkANgBoAHAAcwB3AHAAeQBsAHQADgATAKz/r/+a/5z/2v/d/w4AEAA8AEIAXgBjAGMAZwBIAE0ALQAqAOf/5/+r/6X/nf+V/7X/r//C/7n/xP+8/9v/0v8PAAkAJgAmAA4ACwD5//n/6//u/+L/3f/a/+D/5f/i//n/AQAxADEAgACNAJsApABtAHoAQwBLADAANgAtADEAEgARAO3/7v/w/+n/EwAUADQALQAMAAkA1v/M/7v/t//G/7z/4//g//H/6f/Y/9H/3P/X/+T/4//i/+H/7f/u/y4AOABZAGEAMQA+ACIALAASABsA8P/4//r///8zADgAQgBLABsAGwDp/+3/6f/o//P/8P/e/9b/3v/V/9n/0f/F/7j/uv+1/9j/yv/Z/9j/6P/e/+7/7v/4//b/5v/q/yQAKABcAGUASQBSADYAOwAwAD0AHwAnACEAKwBHAFIAbQB3AGgAbgA/AEUA///+/8//zP/Q/8n/4P/b/+n/4v/y/+z/6f/i/+T/2//y/+z//f/2/9//2f/k/97/+//5//H/9P8BAAEAHgAnAC8ANQAjAC4AIwApAB0AKAARABcAAAAHAPz/AgASABcAHwAjAAEAAgDc/93/7P/m//v/+v/1/+//6P/i/+H/3f/j/9j/1//S/9f/zf/Z/9T/+v/3/y8ALwBDAEcANgA6ABoAIAAQABIACwAVACcAKAA9AEoAQwBLAEUATABPAFsAMwA0APH/+//Z/9H/9P/5/wcAAADY/9b/z//H/+v/5v/e/9b/xf+7/8P/vP/N/8b/6//n/xEADQAXABcA+//5//H/8v8HAAcAFwAeADIANgBHAFIAVgBeAEoAVgAzADYAEQAaAAUABgAVABcAIQAkABgAGADq/+n/zf/I/9n/1P/o/+D/7P/o/xIABwAoACYADAAEANH/yv/a/9b/9//0/9v/1//z//b/MwA1AE0AVQA6AEAALQAwABEAGQDy//f/3v/g/+H/6v8EAAQAIwAqADUANwA1ADcAJQAkABAAEAD7//P/4f/e/9j/0//O/8X/3f/a//f/7f/0//L/+f/x/w0ADwAsACYAGwAkABQADQD9/wgA+//8/wAABgAdACMAPwBIAEIASQBFAFIARwBNACEAKwALABAABwALAAQACQD4//T/6v/p/wQAAAD6//j/4f/c/+n/4P/Z/9f/rf+h/4X/gv+x/6f/4//i//b/8v/n/+n////+/xcAIAAeACIAIgArAC8APAAoAC8AIQAwAC0AMQBDAE8AQgBJAC0AMgAdACMAKgAsABMAFADy/+//5//k//T/8P8EAPr/7//q/+z/4f/0/+//GwAXACAAGQACAAIAAQAAABAAEwAtAC8ANwA+AC8ANQAiACoAKgAwADIAQQAqAC4AHAAuAEEAPgAtAD0ADAAJAOj/6v/d/9n/1v/U/9P/z//O/8n/4f/a/+n/5//V/8v/0P/O//f/7//3//f/1v/Q/9j/1f/r/+z/AgACABQAGQBIAE0AdQB+AGMAZwAdACkAEQAPAAcAFAAOAAsACAARAB8AHgApADIAMwAvAC8ANgAUABEA4v/i//T/7/8NAA0A+P/v/+T/5f8BAPn/EAARAAkAAwDx//H/+P/1/w0ADwANAA8A1P/Q/7//wv/a/9X/2//h/9v/1f/0//z/GwAdABoAIgAIAAgABgALAOn/5v/O/9L/3v/W/+P/6P/p/+T/CQAKACIAIgAVABAA6//u/+f/2/8LAA4AHgAWAO//7f/f/9r/BgAFABMADgD9//7/EAALAC4AMAApACsA+v/7//v//P8PABEAAgACAO//7//k/+j/AAD+/yEAJAAxADMAEAASAO//7//2//T/7f/p/9//3f/w/+v/AwADAP7/+f8CAAAA9P/z/9L/zv/A/7z/2P/V//P/8P/m/+X/DAAJADkAPQA4ADgAEAAQAPr//f/v/+///v///xsAIAAhAB8ACAAMABoAGwAMAAsA1P/Y/9P/zf/7/wAAAwABAPf/9////wAAEgAPAPv/+//l/97/yv/M/8j/wv/l/+n/BAAAAAkADQARABIAIQAfABcAHQAJAAUA/P8AAP//AQAFAAYAIAAlADYAPABAAEEAOwBBADIAMAAUABgAAQD9//H/9P/t/+n/5//n//j/9P8RABAAEwAVAAoABwAKAAsAFAARAPP/9v/N/8j/0//W/woACQAFAAkA/P/9/ysAMgAyADYAEgAXACkALAAuADUADAANAPT/9P8HAAoAAwACAN//3f/7//n/FAAUAPz//P/+//n/9v/3/+T/3f/U/9L/6//m//T/8//u/+v/DQASAC8ALgAsADQANwA3ADAANwAYABsAEQAXAB0AHwARABkACQAHABQAGAAWABsACQAFAB0AIAAiACAAAAD///f/8//5//n/6P/i/9z/2f/8//j/EAAPAPL/7//5//f/GAAZABAAEgAJAAkAAgAFAPf/+//x//H//v8DAA8ADgALABIAAwACAPD/9//5//n//f/+/+b/6f/b/9b/7f/w//n/9v/x//H/8f/u/+7/7f/s/+j/7f/t//D/7P/z//L/GQAYAB8AHgAMAA4AFgATAEAARQA0ADQA+v/7/wkADAAiACMA/P8BAA4ADgAbACEABQAGAPD/8P8EAAkACgALAPP/9v8DAAMAFQAXAPj/+f/o/+P/9f/4//3/9//2//X/+v/5//7/+P/2//j/8P/p/+b/6f/8//P/EQAYAA4ACADy//b/9//2/woACwAlACoAOQA7AD8ARAAhACYACAAIAAsAEwAYABQABQAKAAsACAAYABkAFgAaACgAJQAhACUACwAIANr/2f/S/83/z//N/9v/1v/s/+v/DgAKAA0ADwATABEAFAAVAAMABwANAAkAAwAMAA0ACQD0//3/BQABAA4AEwAWABkACAAIAAAABAAMAA4AHQAgAA0ADwAAAP3/+f/9/wUA/f/////////9//j/9P/9/wEAHgAcACYAJwAJAAoA+f/3/+z/6//W/9X/3P/a/woADQAYABoA+v/7//7/AgAMAA8AFwAXABkAHwAQAA4A9//7//b/9P/4//3/8P/r/+z/8P8MAAoAEwAUAA0ADQALAAsA+f/3/9f/1f/C/7//1f/S/+P/3//w//T/BQD///7/BwAFAAIACQAMAAEAAwDp/+f/4//k//D/8f/3//X/DgARACoAKwAjACQAIwAjACgAKQAdABwA+//7/+7/6v/y/+7/8P/s/+T/4v/u/+j/EgAWAB0AGgAHAAcAAAD+/wUABAAAAAIA5f/j//b/+P8XABcAEAATACEAIQApAC8ADwARAP3//P8NAA8ACQAGAND/z/+3/7H/1f/R//f/8/8DAP3/+f/5//j/8/8BAP//EQAMAPf/9P/i/97/6v/n/w0ADwAdABwAGgAdAC0ALwAyADYAHAAgABoAHgAyADcAMgA1AB0AHwAJAAkACAALAAQAAgDy//P/AwD//xMAFwAIAAEA6P/o/+v/4//k/+P/3v/Y/9r/1f/o/+n/9P/y/wAAAgAFAAUA//8CAPb/9v8AAAUAGQAaABcAHAAFAA0A+f/7/wsAEQAvADQAJgAoAAgADgAgAB0AEAAWAOH/3v/Y/9X/9P/5/wEA+f/0//n/AgD6/wEAAgD2//X/BwAFAPj/+f/X/9X/6P/l/+//9f/q/+n/DAAQAEkATwBcAGEANwA8ADoAPwAdACMA3f/e/+f/7P/+////8//0/wMABgAiACIAHwAkAAMABQAMAAgA+/8AAND/yP/P/87/7//t//7/+v8RABIADgAMAAcACQAKAAcAGQAcABUAFQD3//n/8P/y/wQABgAQABAAAQAHAP7/+v8GAA8AKwAqACoAMQAfACAAKQAuAC8AMgAHAAYA6v/r//L/7//2//j/CgAHACMAIwAeAB8ACgAJAPz//P8IAAUABgAHAPv/+P/2//T/BAAEABoAGQAEAAYA+P/2/woACwAjACUABQAGAOj/6/8gAB4ANgBAAB0AFwD4////4f/e/9r/2//9//3/KQArACIAJQATABMAHgAgAAUABADr/+n/8//y////+//v//D/8//v//f//f////j/+f/8//3/+v/5//j/8P/y//b/8//0//j/AQADAA4ADAAGAAkA+v/7//D/7//5//3/DAALAAgADADt/+z/6f/q/+//7P/T/9X/0P/M/wYABwA2ADQAHwAiAO//6f/u//L/AgD6/+b/6P/x/+r/CgANAA0ACgAIAAoAEAAOAP3//v/0//H/BAADAAkACQD7//7/FwASACQALAAEAP//8v/2/wMAAAAKAAwAFQASAAwAEAAHAAIAAgAFAAgABADU/9L/z//M/wEA///5//j/7//q//f/+P/+//3/4P/e/9z/2f/1//H/5f/n/+P/3f8BAAMABwAHAPj/+P8GAAkADgAPAAoACQD6//v/AwACAAMAAwAMAAwACAAEAPr//P/s/+j/7v/v/wEA+v/8//7/BAD+/xIAFgAnACMABwAHAN//3f/j/9//5v/s/wEA+f8iACoANAAzACwAMQAoACkAFgAaAPL/8//e/9z/7//0/wAA/P8HAAsAEgARABoAGQAZABoACgAGANj/1v/H/8L/2f/Z//T/7//t/+3//v/6/w0ADAD7//7//v/5//n///////z/8P/1/+T/5P8KAA8ANQA4ABkAHAD9//7/EAASABIAFQD6//n/+f/8/wMAAgAOABAAIAAdACMAIgAGAAUACQAFABYAGAD5//X/5f/k//b/9P8HAAgAHwAeACIAJAAXABgADgAPACMAKAApAC4AEwAYAAgADQARABUAFwAXAAQACQD3//X/+/8AABsAHQAGAAkA8P/x//j/9//q/+v/3v/c//b/9P/8//v/6f/m/+r/5//t/+//6v/m/+b/6v8EAAMABwAJAAkADgAHAAUABAAIABcAFwAjACYAHgAjAB4AHwAjACgAGgAdAB4AJAA/AEEAHQAhAOP/4//V/9H/2f/b/+n/5P8BAAIAGgAbABYAGQATABAACAAOAAkAAgDq//H/9//w/wQACAAaABkAEQASABIAEQAgACIALAAvACkALgAZABsADwAPAAIABAAaABwAGAAYAAIABAD1//X//v/+//f//P/t/+r//P/9/xEAEgD8////AQABAAUABgD+//v/+//+/xMAEAARABYADwAQABIAEAANABAABgADAAQABAADAAUADQAKADEANAAzADQAFQAVAPb/9P/+//z/AQACAPv/+/8DAAMAAAAAAP7/AAASABUABgAHAPz/AAAPAAsAEAAZAPD/6f/K/8//9v/v//v//P8CAAMALQAuABwAHgD1//X////9/wgACQD4//P/5f/m/wIA/P8UABgAAgD+/wIAAQALAAoADAAPABMAEwADAAgA+v/1//P/9f/z/+//4//l/+D/4P/4//f/AgAGAAcABgD9/wEA5v/p/+v/5//6/wEADAAGAPn//P////v/FwAYABMAEgD4//f/BwAHAAwADgACAAEACQAJABkAFwAWABYABgAFAAIAAAD7//z/+P/1/w0ADQAZABsABQAGAPz/+//5//r/AAD///L/8P/3//n/BwAFAAsADQD9//v/7P/v//b/8f/9/wEACwAIABgAGgAdAB4AFgAXAAYABAD+/wIA9v/x//L/9f/v/+7//f/6/wUABwAGAAUA//8CAO//7P/o/+n/7f/r//H/8P/p/+r/8f/v/wgACAAHAAkA+v/2//z//P8LAA4AGAAXAAcACgD9//r//P/7/w8AEQAMAAsADQAIAAkADgASAA4A9//9//n/9/8DAAMAFQAYABoAGgAPAA8AEgASABkAGgD+////8f/w//T/8/8NAA8AEgASABEAFAAOAAwABgAHAPv/+v/w/+7/+//5/wgACgAQAA4ADwASAAwACwADAAMA9f/1/+b/6P/g/9z/3f/f/+3/6//8//3/8//0//D/8P8KAAwAEwAVAAIAAwDt/+3/+f/5/wEAAQD1//X//f/8/w4ADwACAAIABwAJABkAGAAVABYADgANABUAFQAaABwABAAAAPz/+v8XABgABAACAOz/7v8RAA4AKgAuABwAHQD7//r/6v/o/+v/6f8AAAEAHAAfAAUAAgDv/+//FwAaACIAIgD9////8P/t//r/+/8HAAkABAADAAAA/f/w//D/BQAEABgAHAD0//H/2f/c//b/7//8/wIADAAIABQAGAAUABMA5//o/93/2v8CAAYA9v/y//D/9P8SAA8AEwAYAAMAAgD5//v/BQAAAAgADQAUAA4ADgAWABsAFQAkACoAJQAiACAAIgAlACQAEwAUAAEAAQAGAAgAJAAlABkAHAAQABAAHAAiAAgAAwD2////AwD///7/AwDy//D//f/+/xMAFwAJAAgA8P/z//n/+P8EAAUA//8CAAAA/P/6//3/BAABABEAFAAUABIA+P/7//T/8P8SABYAHQAcAB4AIAAsACwAFwAYAP3//v8MAA4AFwAXAAYACAD///7/DAASABgAFgAEAAoACQAEAAkADwAKAAkA/f8AAAEA/f8HAAkAFQAUAAwACwAEAAcAEQALAB8AJgAbABUADgATAA4ABgAFAAsACgADAA0AEQAUABMADwANAPX/9f/n/+f//////wEABAD6//n/AwAEAAYACADw/+7/5v/p//L/8P/6//z//f/8/wEAAAD+/wIACgAIAAoADAD//wAA/v/7/wAABAAGAAEAAgADABUAEgAaABwADwAOAPX/9v////v/CwARAA8ADADy//X/4//d//b/+f8MAAoA9P/4/9v/1f/w//X/EwARAAoADwD9//z/AQD+/wcACgAJAAoACAAFAPj/+f8AAPz/BwALAAkACAAFAAYAFwAUABUAGQADAP//8//1/wEA/v8FAAUA9//3/+v/6P/6//3/FAASABEAEQAXABcAFgAXABAAEgAPAA0A/f/+//j/9P8IAAwAHgAcAAoACwAJAAkAFQAVAP7//v/p/+v//v/7/wQABwAEAAIAAwADAP7//f/2//b/9P/y//n//P/y/+//4f/j//D/7v/+//////8AAPT/8//x//H/8P/x//j/9v/9////7//t/+n/6P8WABgAIQAgAAAAAgADAAIAEQATAAAA///j/+P/+//4/wwADgDt/+z/+//5/xwAIAAHAAQA//8CABAADgAMAA4ACgALABIAEgAaABsAFQAUAAMAAwAAAAEABwAFAA8AEgAEAAMACgAMABAADgD//wMA8f/s//r///8JAAEA8v/4/wAA/P8NAA4ABwAJABEAEgALAA0A/P////n/9//7//7//f/9//z//f8FAAQA+f/7/wYABgAKAAsA9f/0//f/+f8IAAgABgAHAP7//f8HAAcAEwASAPj/+f/7//v/DwALAAgADAAJAAUAHQAgACAAIQAZABoADAAMABMAFAAXABcA/f/9//D/8f8EAAIABAAIAPb/9P/0//b/+v/6//j/+f/9//7/AwAFAPr/+P/q/+n/9//2/wYABgD5//j/+P/5/wQAAwATABYAFQATAAcACAD+//v///8BAPr/9//j/+X/5//f//D/9P8DAP//CwAOAA4ADgALAAwA/f////H/8P/u/+7/+//7//v/9//+/wEAEgAQABgAGwANAA8ADAAJAAcADAAOAAwACgANABQAEAAYABsAJAAgAA4AEQAJAAYAAgAAAAMABgARAA8AFgAbAA8ADgD3//f/AgAEABsAFwABAAYA///7/wsAEgAOAAoABAAIAAcABwAJAAoABgAJAA4ADQAGAAoAAwAAAPz/AQD+//n/+/8BAA8ACwAPABQAEQAPABQAFQAeAB8ADAAMAPz//f8KAAsA+f/6/+//7//4//j/AQAEAAAA/f/2//r//P/4//z/AgD6//T/9P/4/wYABAANABAAFAASAA4AEAARABEABwAHAPz//P/6//j/AQABAA8AEAAfACEAHAAdABsAGQAYABwAEgAQAAQABAD8//v/AQAAABAAEQAZABsA/f/7//n/+/8NAAwABgAJAOf/5//s/+n/9P/1/wEA//8FAAYADAALAAIAAQD7//r/BwAKAAMA///y//X//f/5/wIABAAAAPz/8f/0//b/7//w//X////6//f/+v/+//3/DgAPAAUACAD8//j/9f/6//7/+f/9/wEA+v/4/wAAAAD7//z/CgAKABQAFQAQABEADQAOAAkACAASABAAEAASABMADwAHAAsAFQATACAAIQAQAA0AAQAEABYAEQARABcABAD//wMABQAFAAMAAgACAP3//v8BAAAA8P/z//L/7/8CAAUABgAGAPv/+v/1//j/9P/w//L/+P/5//T/+/8AAP3/+P///wQABgAEAPn//P/0//L/AAABAAIAAQABAAIAAQAAAAoACwAEAAMA9//4//v/+P8FAAoAAAD6//n//f8OAAwABQAFAPj/+f////3/DwARAAoACgD///7/AgADABUAFgAPABAADwANAAsADQAGAAYADgANAAgACgAGAAMAAQACABAAEQAJAAgAAgAEAA8ADQAWABgADAAMAP3////5//f/7P/t//L/8P/+//3//v8BAAQAAgD5//n/8v/0//7/9//7/wEA/P/3//r//P8JAAcADQANAAAA/v/+//7/+//7/wUABQADAAQABgAFAAMABQANAAwADQAPAAkACQAJAAcACgAPAAUAAgAKAA4ABgAEAAMABwASABUAEgARAPX/9//v/+z/AQAFAAcABwD+//7/CAAHABwAHAALAA4ADwAOABIAEwD5//f//v/9////AQADAAEA/f/7/wsADAAVABQA+f/8//b/9P8CAAMABgAIAAgABwACAAMAAQACAA4ADAALABIACQAGAPb/+f8BAAEAEAARABUAGQATABIACQANAA0ACwALAAsA/f/+//f/8f8CAAkAHAAXABQAGgAPAAsACQANAAgAAwAJAA8AEgAMAAsAEAANAAoABwAIABIAEgAVABcADQAMAAoACgAWABgAFQAWAAsACwAUABYAIgAfABIAGQAHAAQACAAMAAkACQD///3/GgAeAB0AHwAHAAYACAAOABgAFAAJAAwA8f/y/////P8LAA8ABwAHAAEA//8KAA8AEQAKAAMACgAFAAIA/f////r/+f/5//r/9//0/+7/7//7//f/DAASABEADgD6//z//P/7/wMABwAAAAAA/P/+/wAAAAAJAAgACQAMAA0ADAD6//n/8//0/xcAGQAZABkA/v8BAP7/+v8RABUAEAAOAPf/+P/9//b/+v/+//T/8P/+/wEABgABAPf/+P8HAAQAIAAgAA8AEAD///r/AQAEABIADQD2//j//P/4/wUACAAHAAYACwANABEAEAD6//r/7//u//n/+v8BAAAA7P/r//H/8f8LAAoA+f/5/+7/7//7//f/+//9//r/9//9////BAACAAIAAwD8//j/BwAJAAEA/v/4//f/+f/3/wQAAQAFAAgACwAJAP7////4//b/+v/5//3/AAD4//f/+f/2/wgADAALAAcA9//8//j/9f/6//7/BgADAAAABwAIAAUAAQAFAP/////3//T/+v///wMA/v/5//z//f/4/wYACwAVABEACgAOAP///P/1//X/+v/6//z//P/8//v/8f/w//T/8f8CAAQABgAHAAEA///3//v/AAD9/wQABgAQABEABQADAPb/+f8FAAEAEgAYABYAEwD//wQAAAD8/wQACAAUABQAEwATAAAAAAD3//X/AgADAAUABgD8//r///8BAAoABwAOABIACgAIAAIAAQAGAAYAAgAAAAMABwD9//n//f8AAAIAAQAPABAADgAOAAEABAD6//n/+f/8//v/+P/6//7/DAAJAAAABQD5//T/9//5/wcACQAHAAYA+f/8//b/8v8CAAMABQAJAAIAAQD5//n/AgAEAAIAAAABAAIA+v/6//////8BAAEA/f/9//f/9//4//f/BAAFAAoACgAAAAEAAAD/////AAD///3/AQAFAP7/+/8AAAIAAAD//woACgAEAAYABAADAAkACgD9//3/+P/4//X/8//8//7/AAD//wkACQAJAAoA8v/w/+//7//8//7/AAD9//7///8GAAkADQAIAAYADAAHAAQACwAMAP3//f/5//j/AAAAAAgACgASABEAFAAWAA0ACgAHAAsACgAIAAMABgD7//j/AwAGABwAGwAFAAcA+//4/wkACwAGAAUAAQACAAMAAwAEAAMADgAOAAkACwAIAAYAEgAVABUAEgD2//r////8/w8AEwAGAAUA/f/8//r//P8OAAwADgASAPv/+P/5//b/AwAHAAoABgAAAAUA+v/0//b//P////j//P8EAP7/+v/+//7/AQACAAMAAAADAAYABAADAP/////6//r/AgAAAP7/AgAEAP7//f8CAAkABgABAAMACQAHAPf/+v////r//P8AAAUAAAD7//7/+P/3//j/+P/1//X/+//5/+3/7v/5//f/EgAWAAwACgD5//r/9//2/wIAAwADAAQA/v/9//7/AQANAAoADAAOAAQABAANAAoAAwAJAPr/9P/6/wEAAgD///z//f/7//r/AwADAA0ADwALAAoA/v////3//P/4//f//P/9/wcABwAHAAcAAAABAAAA/v8CAAQAEAAOAAkADAAEAAIABAAGAAMAAgD7//n/+v/9/wUAAQAAAAIA9//3//j/9P8BAAQA/f/6//z//f8FAAUABQACAPn/+/8GAAMAAgADAAQAAwADAAEACAAKAAAA/v/0//X/BgAEAAoACgACAAQABwADAAcACwAHAAMABQAIAAkABgADAAMA9v/3//3//P8GAAUA/v////f/8v/8/wEA+v/3//7///8EAAQAEAAOAAMABgDx/+7//f////7//f/r/+3/9v/z//3/AAD///3/BQAGAAcACQAGAAIA9f/3//X/9f8BAAAA8//3//z/9/8BAAYABwAFAAUABgD8///////5//r/AQAGAP//+P8AAP7/+P8FAAoABgAFAAYABgD//wIAAAD7/wIACAAJAAUABwAIAP3///8CAP7/EQAVAA0ADAD///v///8EAA8ACwADAAYAAQD+/wEAAgAZABYADwATAAwACQAXABkADgANAPD/8P8EAAIAAgAFAP3/+v/7//3/BwADAAMABgD4//T/+//+//z/+P/v//H/8f/u//T/9f/5//j/CAAGAAsADQANAAsABQAEAAwADgAGAAMA9P/3/woABwAPABIACgAIAAsADAAMAA4AEAAOAAUABwAFAAUAAgADAAQAAwD+/wIADAALAAgACQD//wAA/////wAAAAAEAAcAAQD//wgACQADAAMABgAGAA0ADQAVABgAEgAPAAQABQANAA0ACwANAA4ADAACAAUABQACAAgADAD///7/AwADAAwADAAFAAUA/P/+//3//f/+/wAAAgAAAAQABAAHAAoABQADAP3/AQAIAAcABQAGAP7/AQAEAAIABQAHAAwACQALAA8AFAANAAcADgAGAAEAAwAHAAsACAD//wEAAAD//wIABQAMAAsACAAIAAQAAgD6//3/BQACAAIABwD+//r//P/9/wYABwABAP//BgAJABEAEAAQAA8ABQAHAAkABwAPABMADwANAAsADQAIAAgAFQAVABIAEgAbABsAEQAQABEAEQANAA0ACAAJAP3/+f/9/wAA/P/8/wIA//8LABEAEQALAAgACgACAAQABgACAAMACAAJAAUABAAHAP///f/6//n/9f/3/wIAAAAJAAsABAACAPz////9//n/AQAEAPj/9v/s/+z/9v/3/wcABwD4//f/8//z//n/+f/6//n//v/+/wAAAAAAAP//BQAHAAYABAAEAAUACgAKAAMAAwD6//r/DAAMAA8AEAAHAAYAAAD//wEAAAAKAAwA//////v/+v/9////CwAIAAkADAAKAAgAAwAGAAMAAQD//wIAAgABAPv/+//2//b////+/wgACwD8//n/+//8//7//f/8//z/9f/2//7//P/4//r/8v/w/+z/7v8KAAUA+v////X/8f8DAAMA/v////z/+v/9////BgADAP//AQD///3/AwADAAUABQD7//n/AAACAAIAAAD8//3/+//7/wAA//8DAAUACgAHAAcACwAPAAoABAAIAAUA//8IAAwAAwACAP3/+//2//b/AQABAAAAAQAIAAkACwAKAAMABAAEAAIABQAHAAYABAD3//n/+v/5//n/+/8CAAEA+P/5//f/+P/8//n/BgAKAAMAAQAAAAIACgALAAsACQAAAAMABgADAAQACAAKAAcAAAAEAAIA///9//////8AAAgABgAEAAcACgAIAAsADQAQAA8ABgAIAAQAAwABAAIABAAEAAAA/f/8/wEAEwANAAYADgD+//f//v8DAAIAAAD//////P/8/wQAAwAMAA0A+//6//j/+v8AAP3//f///wAA/v8DAAMACQAKAAoACQAFAAYAAAAAAAEA//8FAAYABQAFAAEAAQAOAA8ADwAMAP7/AAD7//v/AgADAAQAAwD7//3/AQD8/xQAGwALAAQA9//8/wAA/f8BAAIA9//3//7//v8KAAoABwAIAAgABQD//wUABgACAP7/AwABAP//AwAFAAcABgAIAAgABQAGAAIAAAD+/wIA+f/2//v//v8BAAAAAgABAAMABQAUABEACAAMAP//+//8//7/AgADAP///P/6////AgD9/wcADAAQAAwABAAFAP////8GAAQACAALAA0ACgD//wIAAQD//wQAAgAFAAgACwAJAAsADQALAAkAAAAAAAcABgALAAwACQAIAP7//v/z//P/+P/3/wcABwD9//7/9//1/wAAAgADAAMA9//1//j/+v/7//r/AgADAP7//v8CAAMACAAIAAIAAQDw//D//v////7//P/7//3////8/wQABgADAAQACAAIAAMABQABAP7/CAALABMAEQABAAUAAQD+/wEABQALAAkACwANAA4ADgAMAAwACAAGABYAGAATABEAAgACAAkADQAHAAQAAgAEAAsADAANAA0ACwAMAP//AAAHAAYABAAGAPz/+v/9//3/+v/7//n/+f8AAAEA9v/2//b/9f/8//3/EAAPAAoADAD9//n//f8CAAAA/P/y//X/9//2//n/+P/5//n///8AAAkABQAFAAgABQACAPT/9v8GAAUA/P/9//b/9f/+/wAACwAKAAcACgAAAPv/AAAEAAkABwAIAAkABgAGAAgABwAEAAMACwAMABIAEQAKAAwABgADAAYACgALAAgABQAHAP///f8MAA0ADQAPAP3//P8EAAQA/v/9//7//v///wEA/P/7//r/+//y//L/CAAIAP//AADx//H/AAABAAYABgD7//7/9f/y//3/AQAAAP7/BQAFAP7//v8DAAUA/f/5//z/AQD4//X/+v/9/wEAAAAEAAQA/f/+//v/+/8EAAMACQAMAAYAAwD0//b/+f/6//7/+//5//z/+v/3//r//v8CAP3/BQAKAAIA/v/5//v/AgAAAAcACQAFAAEAAAAEAAYAAwD8//z//////wIAAAAEAAQA/f/+/wQAAQAIAAoABgADAP//AgAGAAYACQAIAAMABQACAAAABgAHAAYABgACAAEA+v/9/wgABgD//wIABQACAA0ADQAKAAwA/P/4////BQAHAAEA/v8GAPz/9f/6///////8/wQAAgADAAgABgABAPv//f8BAAIABwADAAUACwAJAAUACwAOAAwACwACAAMA9P/1/wkACAATABQAAgABAPz//f/9//3//v/8//3///8FAAMAEwAWAAwACAD6//7/DAAHAAYACwAKAAgA//8AAAEAAQAEAAMAFQAWABYAFQD8//7//P/5/xEAFAABAAAA+P/1/wAABQAHAAQA+//8//r/+//9//z/AQAEAPL/7//0//b/CgAJAAEAAAD6//7/CAAFAAIABAD4//r//f/4//n/AAD+//n/+f/8/wkACQAEAAQA/f/+/wQABgAHAAMA+/8AAPv/+P8AAAIACwAKAA0ADwAFAAMABQAIAAoABwAHAAgACAAIAAsACgAJAAwACQAIAA0ADgAPABEADAAJAAoADgAMAAgADQAQABAADQAFAAcABQADAAUABwAEAAIA/P/8//v/+//+//3//v////z/+/8IAAcAAAD//wAA//8IAAgAAQD+/wMABQD9//n/AQACAAQAAAADAAcACQAEAAMABgAOAAwACQAHAAAAAgAGAAMA//8BAAIAAQD6//r//v8AAAcAAwADAAcAAQD8//r//v8CAAEABgAFAAEAAwAFAAMABwAJAAoACgAIAAYABAAGAAMAAgAAAAAABAAHAAYAAwAFAAcAAAD+/wEAAwD9//3/+f/6//f/9f/6//3//f/7//v//P8AAAEAAAAAAPf/9v/4//z/+v/1//j//v/2//P/9//4///////3//f/9P/0//3//v8DAAMAAQAAAPr//P/+//3/BQAEAP3/AADw/+3/8f/0//3/+v8AAAIA/P/7//3//f/2//b/AwACAP3//v8BAAAA+v/5/wAAAgD5//f/AAADAAEA/v/x//L/+f/4//z///8IAAIA+////wcABQAEAAQAAQACAPb/9P/+//7/AwAEAAcABQACAAQAAwACAAkACAAHAAcAAwADAP3//f8CAAEA/////wQABAAFAAMABAAGAAMA//8CAAUA///8//z//P8DAAIAAgAAAAUACQAGAAMABAAGAAcABQAIAAoACAAGAAIABQAIAAUAAgADAAsACwAJAAgABAAEAPz//f8IAAUA/v8BAAIA/v8DAAgABwACAAQACAAFAAMA///+/wMABgAKAAcA//8DAAcAAwADAAUAAwAEAAIA/v8EAAoACAABAAEABgAIAAUAAQAGAAMA//8CAAUAAwACAP3//v8JAAoABAAFAP7//f/7//3/AwABAAQABQD3//n/+//6/wYABQAEAAcA+v/3//3/AQAPABAADwALAP7/BAAIAAUABgAJAAoACgD8//v/AAADAAIAAQAHAAkADAAKAPj/+f/2//b//////wUABgD+//z//v/+/wkACgAAAP///v8BAAYABAD5//n/+v/8/wIAAAAFAAcABwAEAAcACQAAAP///f/9/wkACAABAAEA/P/8/wAAAQAEAAIABQAHAAgABgAKAAsAAQADAAoABQD//wYABAD8//v/AwAFAP///f8AAAUABQAMAAoABgAIAAgABwAGAAcACwANAA0ADgAHAAUA//8CAAYAAwAMABIACQAFAAwADwAMAAoACwAMAAQAAwAFAAYABQADAPz/AAAMAAcABAAJAAUAAQD//wQACQAFAAUACwAAAPv//f8CAP3/+f8GAAkA///9//7///8HAAcAAAAAAAEA/v/8/wEABAD9//r/AgAGAP7/AgAHAPv/9//5//z/AwABAPv//P/4//j////7/wAABgAAAPz//f8AAP7/+//+///////+/wQAAgAEAAcABwAEAP3///8HAAcAAwACAAgACQD//wAAAwACAAYABgALAA0ACwAIAAMACAAHAAIABAAJAAYAAQAFAAkAAQD//wEAAwAEAAMA//8EAAkAAwD+/wcACgACAAAABgAJAAUAAQAEAAEAAAAAAAMAAwAAAPz/AQD7//b/+/8AAAMAAADy//P/9v/2//3//P/+//7//v/8//j/+f/+//3//P/7//r//P/4//b//f/+//3//f/7//r//P/+/wQAAQD9/wAA/P/5//n//P8EAP7/BAAJAAYAAQD//wMAAQD9/wIABQABAP7/AAAEAAYAAgAFAAgABwAFAP//AAD9//3/CAAIAAYABAADAAMABgAFAAYABwABAAEA/v/8//n/+f/4//n/+f/4/wMABQABAP7/9//5/wYABQAIAAgA/v/9//3//P/8//3//v/+//L/8/8AAP7/+v/7//3//f8CAAIADAAMAP3//v8BAAEAAgACAP3//f/5//r/+v/7/wcACAABAAEAAgABAAIABAAFAAQAAwADAAMABQAGAAMAAwAFAP7//P///wAAAwAFAAgABgAPABAADQALAAUABwAHAAUACAAMAAgABQD//wEABgAEAAMABAAFAAUAEQAQAAoADAD///3/BwAIAAcABwD8//z/AAADAAMAAgAIAAcA//8DAAcAAwAGAAkA/v/9/wUABQD/////AAABAP///f/9////+v/5/////P8DAAcABAABAPv//f/4//j/+v/4//f/+v8BAPz//P8DAAgAAQD9/wMABgACAP3//f8EAAYA///9//3//v/9//z/AgACAAcABgAIAAsADwANABAADwAKAA4ACAAEAPr//v/8//r/CgALABAADgAIAAkABQADAAoADAAMAAsABgAGAAcABgANAA0ABgAGAAIAAgAOAA0ABQAGAAIAAgAKAAkACQAJAAIAAwAAAP7/AQAFAAMA/v/6//3/AwD///v//v8DAAIABgAFAAMABQAGAAIA/f8AAAYAAwD+/wIABwADAAUACQAFAAMA//8BAAIAAgACAAEAAgAEAAIA/v8FAAkADQAJAAYACgAKAAkABwAGAAIABQAJAAYACwAOAAcABwAHAAYABwAJAAkACAAPABAAFgAVAA4ADQD8//3/DgALAA0AEAAFAAEAAAAEAAwACQAJAAoACgANAAkAAwACAAkACQAEAAQABQAEAAcACgAGAAgACgABAP//AwAFAAIAAQAAAAIA+v/3////AwAGAAMA/f/+//z//v8FAP//AAAGAAUAAAABAAUA/v/7/wEAAwADAAAABQAJAAkABQD6///////7/wYACAAGAAYA/v/+/wUABQAJAAwADAAHAAAABQADAP//AAAEAAQAAQD+/wAABwAGAAUABQALAAsABgAHAAgABgACAAQAAgABAPz//P8HAAgADAAKAAIAAwADAAIADwAQAAAA/v/+/wEAAAD9/wMABAD+////BQABAAwAEAD5//b/+P/6/wYABwAHAAUA/P/+//v/+f8DAAQAAwADAAIAAwD3//T/+//+//7/+/8BAAQA///8/wAAAwD8//r/AwAEAAEAAgABAP7/+v/9/wEA/v8CAAQABgADAAAAAAD7//v/+f/4//v//f8CAAAAAAAAAAcABwALAAsACQAJAAEAAAAFAAcAAQAAAP7///8CAAAABQAGAAMABwAGAAMAAAADABAADgAJAAoA/f8AAAsACAAKAA0AAgACAAIAAwAJAAoABwAGAAAAAAAEAAUADQALAAAAAwD///v/DQAQAAcABAD4//v/BgACAAYACwAIAAUA+v/9/wEA//8HAAgAAAABAPv/+v8FAAYAAQABAPv/+v8CAAIABgAGAAAAAQABAAAACAAJAAMAAgD5//f/+P/9/wgABQAKAAsACAAKAAgAAwAGAAsAEAAMAAoADQADAAMAAQD//wUABwD///7//v/9/wYACQAIAAUACAAJAAoACQADAAIAAAABAAEA//8GAAkA/f/7//7/AAAJAAgACgAKAAAA//8BAAAAAgAEAAQAAQD7//7/AQD+/wgACAABAAEAAQD//wQABwAEAAAA/v8BAAEA//8DAAQA/////wIAAQAFAAcAAQD//wYACQAIAAQA+f/9//7/+/8DAAYABgAFAAQAAwAGAAkACAAEAAEABgAGAAIACAAKAAcABQD+/wAADAAJAAQABwAIAAUAAQABAAcACgAKAAYACAAMAAwACgAGAAYAAAABABAADgARABQACAAGAAIABAALAAgABwAKAAkABgD+/wMAAgD+/wMABQALAAsACAAKAAYABQADAAMABQAFAAMAAwABAAEAAgACAAgACgAGAAUA/v/+/////v8IAAkABQAEAAMABQAKAAgABwAIAAcABwAIAAYAAwAGAAYAAwAIAAsAAgD///v///8DAP3/BAAKAAQA/f8EAAwADQAGAAUACAACAAAACQAKAAEAAgABAP//AAABAAEAAAABAAIACQAJAAQAAwAGAAgABAACAAMABAD9//3/AgABAAIAAwD///7/AwAEAAQABAACAAAAAgAEAAkABQACAAUA/v/7//7////8//v/BAADAPj/+P/9//v/AAAAAAYABQD5//r//P/5////AwADAP//8P/z/////v8EAAEA+f/8/wAA/f///wEA/P/6//3//P8DAAUACAAGAPz//f/6//j/BAAFAAEAAgD9//7//P/9/wMAAgD+////AAD+//r/+/8BAAAAAAAAAAAAAgACAP//AAADAAUAAgD8//7//f/9/wEAAQABAAMA+v/2//v//v8MAAkAAwAEAPj/+P8GAAYACAAHAPX/9v/9//3//P/7/wAAAgD9//r///8CAAUAAwAEAAUAAQAAAPz//v/9//n/+f/9/wQA///8/wIA/v/7//T/9v8AAP7/AAACAAMAAQD//wEA+v/5//f/9v8CAAEA/P/9//z/+v/3//r/BAABAP7/AAD+//3//f/+/wkABwACAAUAAgD+//n//f8CAP3/AwAGAAUAAwD9/////f/8/wYABwAGAAMA/v8CAAIA/v/7////BAABAP3/AAABAP7/BwAIAAwADwAJAAYA//8FAAcA///9/wUABgACAAkACgABAAMABwADAAIABgAKAAgABQAHAAUABQD6//n/AgAFAAkABgABAAUA///7/wgADAAIAAUAAQAEAAYAAwAHAAsADAAHAPz/AgACAP3/BQAIAAQAAgD8////AgAAAAAAAQAHAAgAAgD//wEABAAAAP///////wIAAgAIAAoA///7/wgADQAKAAQACQAPAAgAAwAIAAwADQAJAAQABQACAAIABQAFAP7//f8CAAQABAAAAAIABgD7//n/+f/5//z//f8IAAQA//8FAAIA/P8DAAcAAgD9//T/9/8BAP//CAAJAAwACwAEAAMAAAABAAQABAAGAAUAAgADAAYABQAMAAsABgAKAAgABAAFAAcAAAAAAPz//P8BAAAA/f///wYABQANAA4ABwAKAP///P8JAAwACgAJAAQABAACAAMACQAIAAoACgAGAAYABwAGAAUABgACAAQA///+/wMABAAGAAQABwAJAAYABwAHAAYAAwAGAAgABAAAAAIABgAHAAAA/v8BAAEABQAHAAgABQD//wQABgAFAAsABwACAAkABQD+/wEABQAGAAYADAAKAAUACgAGAAEA/P///wYABQAIAAkABQADAAEABAADAAAABwAKAAIA/////wIABgACAAkADgAHAAMABAAGAP7//v8DAAEA//8CAAAA/v/3//f//f/+/wYABQACAAMABQAEAAMAAwAHAAUAAAADAAAA+//4//3/BAAAAP7/AgAEAP//+/8AAAEA+////wMAAgAAAAAAAAD5//v//v/7//7/AQADAAAA/P/+/wUABAACAAMAAwABAAQABwABAP3//f8BAAEA/v8AAAIA/f/8//7//f8CAAUAAQD9////BAAEAP///v8AAPr/+v/9//r//P8BAP7/+//6//v//P/9/wAA/P8AAAYAAAD7//r///8GAP//+P/+/wIA/P/6/wEADAAFAP7/AwAIAAQA+P/9/wQA/f/2//7/BQD+/wAABAAIAAcA/v/+///////6//n/+P/3//f/9v8CAAQABgAEAP//AAD+////AwAAAP//AgD9//r///8CAP3//P8EAAIA+////wQA//8DAAgAAQD+/wIAAgAHAAgADgAMAAEAAgD8//z/+f/4/wEAAgD+//7/AgABAAIABAAJAAcAAgACAAQABAD8//7/AQD+//r/AAAEAPz//f8FAAsABQABAAUA/P/5//7/AAAIAAcA/P/+/wAA/v8GAAgADAALAAoACwABAP7/BgAJAAQAAgAAAAMABAADAAIAAgAFAAQACQAMAA4ACwAEAAUA/////wAA//8CAAUABwAEAAEABAAGAAMAAwAGAAkABwAIAAkABQAFAAUABgAEAAMAAwAEAP7//f/8////CgAIAAkADAAEAP7/AAAHAAgAAAACAAkABQAAAP7/AAD///7/+f/5/wMAAgACAAQA///7/wMABwAIAAQAAQADAP////8HAAcABQAHAP///f8BAAIABgAFAPv//v8BAP3///8DAAQAAQACAAMAAQABAAcABQAFAAYACAAIAAUABAD//wIAAAD8//v//v8FAAMABAAEAPz///8DAAAAAAACAAUAAgD7////AgD9//v///8DAAAABwAHAAEABAABAPv//f8CAAUAAQD8//3/+v/8//7/+/8IAAsABAABAP7/AQACAP7/AwAIAAcAAgD5////CAADAAcACgAHAAUAAAADAAoACQAIAAsAAwAAAAMABQAFAAQAAwAGAAQAAwAEAAUABgAGAAMABAANAAwABgAIAAEAAAADAAQABwAHAAIAAgACAAIAAQACAAgABwD+//7/AgABAAMAAwAEAAUABgAFAAMABAACAAEA/v/+//3//P8BAAAAAwAEAAoACQAFAAYAAwAAAAAAAwAGAAMA/v8DAPr/9//7//3/AwABAPz//v////3//f8AAAYABwAGAAUA/v/+//7///////3/BQAKAAEA/v/3//j/+v/7/////P/7////BQABAP7////9//7/BQACAAYACQADAAIA+P/1//f/+/8CAP//AAAAAP7///8GAAUABQAEAPz//f8FAAIACAAJAAIAAgAAAAEAAgD///v/AAD8//b/+f///wAA+//9/wAAAgABAAIAAgD4//n////+/wEAAwAEAAQA+f/6//v/+//8//z/+//9//3/+v/+/wIABQACAPv//P/9//z//v8AAAEA///+/wIA/v/4//P/+f8CAPz//v8EAAQA///9/wEABAD//wIAAwAFAAQAAQABAP7///////3/CwANAAUAAgD4//r/+v/5//7//v/5//n//v/+/wAA//8DAAMA/P/9/wIAAQD+/wAAAAD9//z//v//////+//6/wEABAACAP//AgAEAP7//v8LAAoABQALAAQA/f/8/wQABAD9/wMACQADAP//AQADAAAAAAAFAAIABAAIAAwACAD8/wEAAAD6//v/AAADAP//AgAGAAIA/v/9/wAABgADAAYACgAJAAYAAQADAP3/+//9//3/AgACAAEAAQD8//z//P/8/wUABQAOAA4AAwAEAAIA/////wQACAACAAEABwD8//j/AgADAAcACgAOAAkA//8FAAEA/P/+/wIA///+/wYABQAFAAcAAgABAAcABwANAA0AAwACAPH/9P/7//f//v8DAP//+//4//n//f///wMA/v/9/wIACAAGAPz/+//0//f/AAD6//7/BAD9//j/+f/8/wMAAAAAAAAA+f/7/wMAAAD6////AAD8////AQD4//j//v/6/wAABAAQAA0ADAAPAAcABAAEAAYAAwD+//z/AAD///7/BQAFAP7/AQAAAP3/AgAEAAcABwAEAAIA/f///wEA//8DAAUAAAACAP//+/8EAAoACAACAPj//f8CAAAACQAIAAIABQABAP7/BAAGAAwACwADAAIAAgACAAIAAwAFAAQA/v///wIAAAAEAAcABwAFAAcACAAAAAAABgAFAAQABQAAAP//AwAFAAoACAAJAAsABQACAAEABAAEAAEA//8DAAUAAQACAAcACgAFAAoAEAAQAAsABwAKAAEAAQAHAAcAAwAFAAEA//8IAA0AFgARAAYADQAGAAAA/f8BAAwACgABAAMAAQAAAAQABQD/////BAADAAQABAADAAQAAAD+/wMABQAIAAQAAwAHAAoABgD9/wEA/f/6//n/+v/+//z//v////v//P/9//v/+f/9/wEA/P8EAAgACQAFAP7/AQD9//v/BQAGAPz/+////wEA/v/7/wAABAD7//n//f/+/wIAAwD9//z//P/9//7//f/+/wAA/v/7//3/AAD///z//f////7//v8BAAEA/f/+/wIAAAAFAAcABwAGAP3//v8CAAEABQAFAAAAAAD9////AgD/////AgD///v/AQACAAEAAAD9//v/9//6//v/+P/7//7/+//4//z///8BAP7//f/+//7/AAAEAAEA/v8BAPr/9//8//v/AAADAPv/+f/2//b//v///wQAAwABAAIAAAAAAP///v8AAAAABQAGAP///v/7//7//f/6/wAABAD+//z//v8AAP///v8DAAMA///+/wIABAAAAP7/+v/8/wIAAQACAAIA/v/8//r//P8EAAIABgAIAAIAAQAEAAQACAAHAAEAAwACAAEABQAEAAgACgAGAAMAAAADAAUAAwACAAMAAgACAAAAAQACAAEABAAEAAkACgD/////AAD///z//v8JAAYA/f8AAAMAAQABAAIABwAHAAMABAAFAAEAAQAHAAYA//8AAAcACAADAP7///8DAAUAAwAAAAIABAD+//3/AgADAAMAAgD9//3//v///wMAAQD9/wAA///8//z//f8BAAIABwAHAAoACAACAAUABQABAP7/AQADAAAA9//6/wQAAwACAAAAAAAEAAMA/v8CAAcAAwAAAP3//v8EAAEA//8CAAQAAQACAAQAAAD///v//P8EAAIAAAADAAIA/v/9/wAA/P/7/wIAAwAEAAIA+f/9/wMA/f8DAAkACAADAAAABAACAP//AgAEAAIAAgADAAIADQAOAP3//P/7//z/DAALAAwADgAEAAIA9P/3/wEA/v8DAAcABQACAAEAAwAAAP//AwADAP//AAAFAAQA/v///wIAAQD7//v//f/+//3//f/8//v/+P/5/wEA//8EAAkACgAGAPz///8EAAAABgALAAkABgAGAAgAAQD+//3//f8DAAUAAgAAAPr/+//7//v/BAADAP//AQACAAAA//8AAP/////4//f/+P/5//z//P8CAAIA/v///wcABAD+/wEABAADAP//AAAAAP//+v/6////AAADAAIAAgAEAAsACAD8/////f/7/wAAAgD8//3/AwABAPf/+/8DAP//AAADAAIAAgACAP3/AQAJAAQA/f/+/wMA/P/5//3//v/+//3//f///wEA//8EAAQA//8AAP///P/9/wAA///8//3////+//3/AQABAAEAAQD+//3//P/9//3//f8BAAEA/f/9/wIAAwACAAEABQAFAP3//f/4//j/+v/6//z//f8AAP///f8AAAMAAgAEAAQAAgACAP///////wAA///+////AAD///7/AAACAAMAAQABAAQAAgD8////BwAHAP7/AAAHAAYA//8AAAYABQD///r//v8BAP///v/9//3/AgD///j//f8CAP///P///wEAAAD///z//P8BAAAA/////wEAAwAAAP7/AAACAAgABQD+/wIAAQD+//3/AAAFAAMAAAAAAP//AAADAAMAAwABAPz////8//n//P////3//P/7//j/9//8/wAA+/8GAAoAAQD+/wAAAwABAP7/BQAGAAEA///+/wAA/////wAA///8//z/BgAGAPv/+//7//v/+v/5/wAAAgD8//r/9v/4/////f8DAAQAAQABAP7//v8EAAMAAQADAAYABAD+/wAAAwABAP//AgD///v//v8CAAMA//8BAAQAAQABAAkABgACAAYAAwD///3/AAAFAAMAAwAEAAUABgACAAMAAgACAAQAAwAHAAkAAQABAP///v8IAAoABwAFAAEABAAFAAMABwAJAAQAAgAEAAQABgAJAAQA///6/wAABwABAAYACgADAAAAAwAHAAkABAAEAAgABAAAAAYACAACAAEAAgAEAAMAAQAJAAsABQACAAIABQAAAP7/AwAFAAQAAQABAAYA/v/7/wEABQABAP7/CAAIAAIABAACAP///v8CAAYAAwAAAAEABgAHAAkABwAKAAwABQAFAAQAAwAEAAQAAQABAPr/+v/+/wAAAQD+//7/AAD6//n/9//2//n/+/8GAAMAAQAEAP///v////3//v8DAAMA+//z//z/AQD5//r//v8EAAEACAAIAAMABQD8//r//f/+/woACAD9/wAABQABAP3/AQACAAAA/v/+//7/AQABAPz//P///wEAAAAGAAgAAAD+//7/AgABAPv/AwAJAAUAAAD6//7/AQD+/wEAAgAFAAgAAgD+//f//f8FAP//AQAEAAAAAAABAAAAAQADAAYAAwACAAQABQAEAAUABgAFAAUA/v/8/wAAAwACAP//+v/8/wAA//8CAAIACgAKAAIAAwALAAgABQAIAAIAAAD9//7/+//6/wEAAgAAAAAABwAGAPz//v8IAAUA/v8BAAEAAAACAAEABwAJAAcABAADAAYACAAGAAkADAD+//z//v8AAP//+//7/wEA/f/3////BAABAAAAAwAAAAUACAADAAEAAQACAP3///8CAP7///8DAAQA//8DAAkA///6/wEABgAIAAMABQAIAPr/+f/9//z//f///wUAAgD9/wAAAAD9/wAAAgADAAAA//8CAAcAAwABAAYAAAD6//7/BQADAPz/AgAHAP///f8EAAQABgAHAAIAAAD8////AQD+//3/AAD///v/AAAEAAQAAgADAAIA/v8BAAIA/v///wIA/f/8/wEAAAD8//7/AgABAP7//f8GAAgAAgAAAP//AAAGAAcAAwACAP///f/1//n/AAD7////AwACAAEABQABAAUACgAFAAEAAQAFAP7//P/9//3//v/9//z//v8DAAAA/v8DAAgAAgD+/wMABwADAPv//v8FAAMA+//9/wQAAwD//wAA/f/9/wIABAABAAEABwAHAAUABQAHAAcACQAIAPz//v////3//f/+/wEAAgACAP//BwAKAAMAAQD+/wAA/v/7/wAAAwABAP7/AQADAPz//f8BAP3//P8CAAQA/v8AAAQAAgAAAAIAAgAGAAgACgAIAAUABQACAAQABwADAAQACQAIAAQAAQADAAUABgD7//r/AQACAP3/+////wIA///9/wQABAD+/wEABAD+/wMACQACAP//AAD///7/AQAFAAMABgAGAAQABwAGAAEA/v8AAAgACQAHAAQAAwAGAP///v8FAAQAAQAEAAMA/v///wQAAwD///z//v8DAAUABQD///r/AgD+//b/+v8BAP3/+f8DAAQABQAFAAIAAgABAAAAAAABAAQAAQD//wIA///9/wUABwAAAP7/AQACAAkABgAAAAMAAQAAAAQAAwD+/wEAAAD8//7/AQAEAAMAAQABAAEAAQAEAAMA//8AAP3//P8EAAcAAgD9////BQACAPv/AAAGAAAA+//+/wMABAABAP7/AAD/////AgAAAP7/AQAEAAAAAgAFAAQAAgAFAAUAAAABAAUAAwD9/wAA///9/wAAAAAGAAYAAQACAAEA//8EAAUABQAHAAkABAD6/wEAAwD9/wAAAwABAAAAAQAAAAMABgADAAEAAgACAP//AAACAP//AAAFAAYAAQD9/wEABAABAAIAAwADAAQAAAD//wMAAwAAAAEAAgAAAAAAAgD+//3////+//z//f8FAAUABAABAAAABAABAPr//f8FAAQA/f/+/wIAAQAAAAAA//8BAAAA+v/9/wQA///9/wEAAQD8//7/AQAFAAEA+//+/wIA///9//3/AAABAAEA//8CAAIABAACAAUABQADAAIAAgAEAAYAAAD9/wMABAD8//r/AQAEAAAA/f/+/wEAAQAAAAAAAwABAAUABwADAP//BAAGAAIAAQAEAAIABgAJAAMA/v8FAAoAAwD9/wIABwAAAP3/BAAEAAMABQAEAAIAAwAFAP///f8BAAIAAQABAAIAAgAAAAAA/v/+/wEAAAD+/wEA///+/wEAAAD//wAAAAABAP3//P/+/wIA///5//3/AgAAAPz//f8BAAEA//////7/AQAEAAEA/f/8/wAA///9//7////8//v/AgADAAAAAAACAAMAAgADAAUAAwAFAAcA//8AAAYABQD8////AwABAP3///8AAAEABAADAAAAAwAEAAEA/P8BAAMAAAACAAMAAgAEAAEAAQABAAIAAwABAAAAAgABAP//AQAFAAEA/v8BAAQAAwAAAAQABwAEAAQABwAEAP7/AwAGAAIAAQADAAIAAgAAAP//AAACAAAA/v///wMABAABAAEABAADAAEAAQACAAIAAQABAAIAAAAAAAQAAwABAAIABQAGAAAAAAAFAAYA///+/wYABgD//wEABQAEAAAAAgAGAAMAAAADAAgABgAHAAgABQAFAAYABgADAAIA//8CAAUAAAD+/wQACQADAP7/AwADAAAAAwAEAAMABAAIAAMA/v8DAAcAAQD+/wMACAACAAEABAADAAAAAgADAAUAAwACAAQAAgAAAAEAAgABAAAABAADAP//AQAFAAMABQAFAAIAAQAGAAYAAgADAAAAAAAFAAMAAgAFAAQAAQAEAAYABAAEAAwACAAEAAYABwACAAIABgADAAAAAgAEAAUAAwAFAAUABwAIAAYABwAFAAMAAgADAAAAAAAAAP///v8AAAcABQABAAAAAwAEAAIAAAAGAAYAAQADAAYAAwD//wIAAAD+/wIAAQAEAAUAAwABAAIABAAEAAQABAACAAIABQAAAPz/AQAFAAIA//8AAAMA///+/wMAAQD+/wIABQABAAEABAAEAAIAAgAEAAUAAgAAAAMABwACAAEABQAGAAQA//8AAAQABQABAP7///8CAAEA/v8DAAcABQACAAAAAwADAP//AwAGAAEAAQAEAAUAAgABAAMABgAEAAAAAwAIAAUAAQAHAAkABQADAAQACAAEAP//AQAEAAUAAwACAAIAAQADAAYABAAAAAEAAwADAAAAAAADAAMABQAEAAIAAwAGAAQABAAFAAQAAwABAAIAAQAAAP7///8BAP///v8BAAIAAQACAAMAAAD/////AQAAAP3/AgADAAAA//8DAAIA//8AAAYABQD8//3/AgABAPv//P8CAP///v8CAAQA//8AAAQAAwAAAAEAAwD//wAABAABAAAAAAAEAAQAAAD9/wUACgADAP7/BAAIAAIA//8FAAUAAQACAAMAAgABAAEAAAACAAMAAAACAAYAAAD8/wMABQAAAP//AAACAAEAAAD//wEAAgD//wEAAwAAAP///f/+/wAAAAAAAP7///8BAP///v8AAAMAAwABAAIAAgABAAEA//////7///8BAAEAAAD+/wEAAwACAAAAAwAFAAIAAgAGAAIA/v8EAAUA///6////AgAAAP7//P///wMA///6//z/AgD9//n//f8DAAEA+//9/wIA/f/5//7/AgD///7/AQACAAAAAgACAAEABQAHAAQAAQACAAUAAwABAAEAAgACAAMAAwADAAEAAQAEAAQAAgACAAMABAAAAP//AQAEAAIA//8EAAUAAQABAAMAAgABAAQABQABAAAABAADAP//AQAEAAEAAAADAAIAAwAFAAUAAwAEAAYABgAEAAMABQADAAAAAgAGAAUAAwAGAAYAAwADAAUABAAEAAYABgAEAAEABQAFAP7/AQAHAAIA//8BAAIAAQABAAIAAgADAAMABQAFAAUABgAEAAEAAgAFAAQABAAFAAMAAgAEAAQAAwAFAAQA/v8AAAQAAwAAAP3/AwAIAAYA//8AAAQAAwABAP7//f8EAAQA/v/+/wIAAQD//wEAAwACAAEAAQADAAMA///+/wMABQACAAAAAAABAAMAAQABAAIABQAEAAEAAwAFAAIABAAGAAAAAQAHAAMA//8FAAUA//8DAAgAAwD//wEABAAEAAMAAQABAAYABwAAAP7/BgAIAP///v8EAAQAAAABAAEA//8EAAUAAQD//wMAAwAAAAEABAAAAP//AwBMSVNULgAAAElORk9JU0ZUIgAAAExhdmY1OS4yNy4xMDAgKGxpYnNuZGZpbGUtMS4wLjMxKQBpZDMgOAAAAElEMwQAQAAAAC0AAAAMASAFDSs7Vj9UWFhYAAAAFwAAAFNvZnR3YXJlAExhdmY1OS4yNy4xMDAA", stopOtherAudio: false }).catch((error) => console.warn("[camera] custom click failed", error));
    }
    async captureVinPhoto(trace) {
      const step = (name, run) => trace ? trace.step(name, run) : run();
      try {
        return await step("captureBleUpload", () => this.mode.withCamera(() => {
          this.requireActive();
          return this.session.camera.takePhoto(SCAN_OPTIONS);
        }));
      } catch (error) {
        const detail = error;
        if (detail.code !== "CAMERA_CAPTURE_FAILED" || !/camera disconnected/i.test(detail.message ?? ""))
          throw error;
        console.warn("[camera] disconnected during capture; reopening and retrying once");
        return await step("captureBleUpload", () => this.mode.withCamera(() => {
          this.requireActive();
          return this.session.camera.takePhoto(SCAN_OPTIONS);
        }));
      }
    }
    async scan() {
      if (this.mode.page !== "automotive")
        return;
      if (this.running || this.snapshot.phase === "booting" || this.snapshot.phase === "warming")
        return;
      this.snapshot.timings = {};
      const trace = new ScanTiming(this.snapshot.timings);
      this.running = true;
      const generation = ++this.generation;
      this.accepting = "none";
      this.update({ phase: "capturing", workLoading: true, vinLocked: false, photoUrl: undefined, vinSpeech: undefined, vinText: undefined, scanCompletedAt: undefined, vin: undefined, validation: null, vehicleInfo: null, error: undefined, dataStore: [] });
      const speak = (stage, text) => {
        this.requireActive();
        if (stage === "scanAnnouncementTts" || stage === "noVinTts")
          this.chatNotice((Array.isArray(text) ? text.join(" ") : text).replace(/\bV I N\b/g, "VIN"));
        return trace.step(stage, () => speakWithTiming(this.session, text, undefined, (event) => trace.mark(`${stage}.${event}`)));
      };
      const announcement = trace.step("customClick", () => this.playClick()).then(() => speak("scanAnnouncementTts", "Scanning V I N now.")).catch(() => {});
      try {
        const captureStarted = Date.now();
        debugLog("[camera] takePhoto start");
        const photo = await this.captureVinPhoto(trace);
        this.snapshot.timings.captureMs = Date.now() - captureStarted;
        debugLog(`[camera] takePhoto done ${this.snapshot.timings.captureMs}ms`);
        const photoUrl = photo.photoUrl;
        if (!photoUrl)
          throw new Error("camera returned no photo URL");
        trace.mark(`photoReady.${photo.requestId}`);
        this.audit("VIN GATE", "OCR CAPTURE", "VIN image captured");
        let photoHost = "invalid";
        try {
          photoHost = new URL(photoUrl).host;
        } catch {}
        debugLog(`[camera] photo result request=${photo.requestId ?? "none"} reportedBytes=${photo.size ?? "none"} host=${photoHost}`);
        this.update({ phase: "scanning", photoUrl });
        const scanStarted = Date.now();
        const { response, data } = await trace.step("vinValidationNhtsa", async () => {
          const response2 = await this.api("", { photoUrl });
          return { response: response2, data: await response2.json() };
        });
        if (!response.ok) {
          const detail = data.error ?? "unknown error";
          throw new Error(`VIN backend returned ${response.status}: ${detail}`);
        }
        this.snapshot.timings.scanRoundTripMs = Date.now() - scanStarted;
        debugLog(`[vin] scan provider=backend roundTripMs=${this.snapshot.timings.scanRoundTripMs}`);
        Object.assign(this.snapshot.timings, data.timings ?? {});
        this.update({ photoSize: data.size, vin: data.vin, validation: data.validation, vehicleInfo: data.vehicleInfo });
        if (data.vin && data.validation?.valid) {
          const vehicle = [data.vehicleInfo?.ModelYear, data.vehicleInfo?.Make, data.vehicleInfo?.Model].filter(Boolean).join(" ");
          this.audit("VIN GATE", "DECODE", `${vehicle || "Vehicle decoded"} - NHTSA vPIC live`);
        }
        if (generation !== this.generation)
          return;
        if (!data.vin || !data.validation?.valid) {
          this.update({ workLoading: false });
          await announcement;
          await speak("noVinTts", "No valid V I N detected. Please try again.");
          this.update({ phase: "ready" });
          return;
        }
        this.api("/owner_manual/prefetch", { vin: data.vin }).catch(() => {});
        const rewritePromise = trace.step("vehicleRewrite", () => this.api("/rewrite_vehicle", { vehicleInfo: data.vehicleInfo }).then((r) => r.ok ? r.json() : null).catch(() => null)).then((rewritten) => {
          const confirmation = [
            `The vehicle is ${rewritten?.vehicleSpeech ?? "described by the N H T S A source"}, according to N H T S A.`,
            "Is that correct?"
          ];
          if (generation === this.generation)
            this.update({
              workLoading: false,
              scanCompletedAt: Date.now(),
              vinText: vinDisplayText(data.vin, data.vehicleInfo),
              vinSpeech: `Successfully scanned V I N ending in ${digits(data.vin.slice(-3))}. ${confirmation.join(" ")}`
            });
          return confirmation;
        });
        await announcement;
        await speak("vinResultTts", `Successfully scanned V I N ending in ${digits(data.vin.slice(-3))}.`);
        const vehicleConfirmation = await rewritePromise;
        if (generation !== this.generation)
          return;
        this.update({ phase: "confirming" });
        await speak("vehicleConfirmationTts", vehicleConfirmation);
        if (generation !== this.generation || this.snapshot.phase !== "confirming")
          return;
        this.accepting = "confirmation";
        debugLog("[vin] listening for confirmation");
      } catch (error) {
        trace.mark("error");
        this.fail("scan", error);
      } finally {
        await announcement;
        trace.finish();
        this.publish();
        this.running = false;
      }
    }
    onTranscript(data) {
      if (this.mode.page !== "automotive")
        return;
      if (data.text.trim()) {
        debugLog(`[stt] ${data.isFinal ? "final" : "partial"} "${data.text.trim()}"`);
      }
      if (!data.isFinal || !data.text.trim() || this.routingTurn || this.classifyingConfirmation)
        return;
      const mode = this.snapshot.phase === "confirming" ? "confirmation" : this.snapshot.inspection?.active ? "inspection" : this.snapshot.phase === "locked" ? "ambient" : null;
      if (!mode || this.snapshot.phase === "error")
        return;
      const text = data.text.trim();
      if (mode === "confirmation")
        this.run(() => this.confirm(text));
      else
        this.run(() => this.routeTurn(text, mode));
    }
    async confirm(text) {
      this.classifyingConfirmation = true;
      this.chatNotice(text, "user");
      try {
        const response = await this.api("/classify_confirmation", { text });
        const result = await response.json();
        if (!response.ok || !["YES", "NO", "UNCLEAR"].includes(result.intent ?? ""))
          throw new Error("Confirmation classification failed");
        this.classifyingConfirmation = false;
        if (result.intent === "UNCLEAR") {
          this.accepting = "confirmation";
          return;
        }
        if (result.intent === "NO") {
          this.update({ phase: "cancelled", vinLocked: false, workLoading: false, vin: undefined, validation: null, vehicleInfo: null });
          this.requireActive();
          await speakWithTiming(this.session, "Ok, cancelling, please try again.");
          return;
        }
        this.snapshot.dataStore = [{ operation: "repair_order.audit", status: "Data store successful", successful: true }];
        this.update({ phase: "locked", vinLocked: true });
        this.audit("VIN GATE", "HUMAN CONFIRM", "VIN bound to this inspection session");
        this.requireActive();
        await speakWithTiming(this.session, "OK, V I N locked, let's continue.");
        this.accepting = "ambient";
      } catch (error) {
        this.classifyingConfirmation = false;
        if (this.snapshot.phase !== "confirming") {
          this.fail("confirmation", error);
          return;
        }
        console.warn("[vin] confirmation request failed; keeping scanned VIN for retry", error);
        try {
          await this.speakChat("Confirmation failed. Please say yes or no again.");
        } finally {
          this.accepting = "confirmation";
        }
      }
    }
    chatNotice(text, role = "assistant", reportId) {
      const at = this.nextChatTime();
      const notices = this.snapshot.chatNotices ?? [];
      this.update({ chatNotices: [...notices, { id: `voice-${at}-${notices.length}`, at, text, role, reportId }] });
    }
    async speakChat(text, reportId) {
      this.requireActive();
      this.chatNotice(text.replace(/\bD V I\b/g, "DVI").replace(/\bV I N\b/g, "VIN"), "assistant", reportId);
      await speakWithTiming(this.session, text);
    }
    async routeTurn(text, mode) {
      this.routingTurn = true;
      try {
        const currentItem = this.snapshot.inspection?.items[this.snapshot.inspection.currentIndex]?.label ?? "";
        const turn = await (async () => {
          const response = await this.api("/route_turn", { text, mode: mode === "inspection" ? "inspection" : "post_lock", currentItem });
          if (!response.ok)
            throw new Error(`Voice router returned ${response.status}`);
          return await response.json();
        })().finally(() => {
          this.routingTurn = false;
        });
        if (turn.tool && turn.tool !== "IGNORE" && turn.tool !== "VEHICLE_QUESTION")
          this.chatNotice(text, "user");
        if (turn.tool === "START_INSPECTION" && mode === "ambient")
          return await this.startInspection();
        if (turn.tool === "STOP_INSPECTION" && mode === "inspection")
          return await this.stopInspection();
        if (turn.tool === "FINISH_REPAIR")
          return await this.finishRepair();
        debugLog(`[voice] routed tool=${turn.tool ?? "missing"} mode=${mode}`);
        if (turn.tool === "ARBITRARY") {
          await this.speakChat(turn.spokenAnswer?.trim() || "I can't help with that, but I can do DVI inspections, scan VINs, and answer questions about vehicles.");
          return;
        }
        if (turn.tool === "PHONE_ACTION") {
          await this.speakChat("Please use the Mentra app on your phone to do that.");
          return;
        }
        if (turn.tool === "UNSUPPORTED_REQUEST") {
          await this.speakChat("I can't help with that, but I can do DVI inspections, scan VINs, and answer questions about vehicles.");
          return;
        }
        if (turn.tool === "GENERAL_HELP")
          return await this.provideGeneralHelp();
        if (turn.tool === "VEHICLE_QUESTION")
          return await this.question(text, turn.question);
        if (turn.tool === "CAPTURE_LINE_ITEM" && mode === "inspection")
          return await this.captureInspectionPhoto();
        if (turn.tool === "NEXT_ITEM" && mode === "inspection")
          return await this.advanceInspection();
        if (turn.tool === "RECORD_INSPECTION_VALUE" && mode === "inspection") {
          return await this.recordInspectionValue(turn.value || text, turn.measurementMm);
        }
        this.accepting = mode;
      } catch (error) {
        console.warn("[voice] turn failed", error);
        this.accepting = mode;
        await this.speakChat("I couldn't process that request. Please try again.").catch(() => {});
      }
    }
    async startInspection() {
      this.pendingInspectionValue = undefined;
      const items = INSPECTION_ITEMS.map((item) => ({ ...item }));
      this.update({ phase: "inspecting", inspection: { id: `inspection-${Date.now()}-${++this.inspectionSequence}`, active: true, currentIndex: 0, items } });
      this.audit("VOICE DVI", "CHECKLIST STARTED", "4-point exterior inspection");
      this.accepting = "none";
      await this.speakChat("Starting D V I inspection now.");
      await this.speakChat(inspectionPrompt(0));
      this.accepting = "inspection";
    }
    async stopInspection() {
      const inspection = this.snapshot.inspection;
      if (inspection)
        this.completeInspection(inspection, "INSPECTION STOPPED");
      this.accepting = "none";
      await this.speakChat("Inspection stopped.", inspection?.id);
      this.accepting = "ambient";
    }
    async finishRepair() {
      const inspection = this.snapshot.inspection;
      if (inspection?.active)
        this.completeInspection(inspection, "REPAIR FINISHED");
      this.accepting = "none";
      await this.speakChat("OK, repair complete, you can press the action button to scan a V I N for the next repair.", inspection?.id);
      this.update({
        phase: "ready",
        vinLocked: false,
        vin: undefined,
        validation: null,
        vehicleInfo: null,
        error: undefined,
        dataStore: [],
        inspection: undefined
      });
    }
    async provideGeneralHelp() {
      await this.speakChat("You can ask a question about the scanned vehicle, or say start inspection to begin a D V I inspection.");
      this.accepting = this.snapshot.inspection?.active ? "inspection" : "ambient";
    }
    async recordInspectionValue(value, measurementMm) {
      const inspection = this.snapshot.inspection;
      if (!inspection?.active)
        return;
      const index = inspection.currentIndex;
      const current = inspection.items[index];
      if (inspectionItemRequiresPhoto(index) && !current.photoUrl) {
        this.pendingInspectionValue = { item: current, value, measurementMm };
        debugLog(`[inspection] retained value pending photo item=${index} value=${JSON.stringify(value)} measurementMm=${measurementMm ?? "none"}`);
        if (!this.running)
          await this.speakChat("Got it. Please take the photo for this item.");
        return;
      }
      let status = "review";
      if (index === 0 && measurementMm != null) {
        status = measurementMm >= 6 ? "pass" : measurementMm >= 3 ? "advise" : "fail";
      }
      const items = inspection.items.map((item, itemIndex) => itemIndex === index ? { ...item, value, status } : item);
      this.update({ inspection: { ...inspection, items } });
      this.audit("VOICE DVI", status === "fail" ? "FINDING FAIL" : "FINDING RECORDED", `${current.label}: ${value || "not recorded"}`);
      if (status === "pass")
        await this.speakChat("Tread depth passes.");
      else if (status === "advise")
        await this.speakChat("Tread depth is in the advise range.");
      else if (status === "fail")
        await this.speakChat("Tread depth fails. Tire service is recommended.");
      else
        await this.speakChat("Recorded for review.");
      await this.advanceInspection();
    }
    async advanceInspection() {
      const inspection = this.snapshot.inspection;
      if (!inspection?.active)
        return;
      const nextIndex = inspection.currentIndex + 1;
      if (nextIndex >= inspection.items.length) {
        const complete = this.completeInspection(inspection, "TECH SIGNATURE");
        const findings = complete.items.filter((item) => item.status === "advise" || item.status === "fail").length;
        const photos = complete.items.filter((item) => item.photoUrl).length;
        this.accepting = "ambient";
        await this.speakChat(`Inspection complete. ${findings} findings. ${photos} photos.`, complete.id);
        return;
      }
      this.update({ inspection: { ...inspection, currentIndex: nextIndex } });
      this.accepting = "none";
      await this.speakChat(inspectionPrompt(nextIndex));
      this.accepting = "inspection";
    }
    async captureInspectionPhoto() {
      const inspection = this.snapshot.inspection;
      if (!inspection?.active || this.running)
        return;
      const currentItem = inspection.items[inspection.currentIndex];
      if (currentItem.photoUrl) {
        debugLog(`[inspection] photo already attached for ${currentItem.label}; skipping capture`);
        this.accepting = "inspection";
        return;
      }
      this.running = true;
      this.accepting = "none";
      this.playClick();
      try {
        const photo = await this.mode.withCamera(() => {
          this.requireActive();
          return this.session.camera.takePhoto(SCAN_OPTIONS);
        });
        const photoUrl = photo.photoUrl;
        if (!photoUrl)
          throw new Error("camera returned no photo URL");
        const live = this.snapshot.inspection;
        if (!live?.active || live.currentIndex !== inspection.currentIndex || live.items[live.currentIndex] !== currentItem)
          return;
        const items = live.items.map((item, index) => index === live.currentIndex ? { ...item, photoUrl } : item);
        this.update({ inspection: { ...live, items } });
        this.audit("VOICE DVI", "PHOTO ATTACHED", currentItem.label, photoUrl);
        const pending = this.pendingInspectionValue;
        if (pending?.item === currentItem) {
          this.pendingInspectionValue = undefined;
          await this.recordInspectionValue(pending.value, pending.measurementMm);
        } else {
          await this.speakChat(`Photo attached. ${inspectionPrompt(live.currentIndex, true)}`);
        }
        this.accepting = "inspection";
      } catch (error) {
        this.fail("inspection photo", error);
      } finally {
        this.running = false;
      }
    }
    completeInspection(inspection, event) {
      this.pendingInspectionValue = undefined;
      const hasRecordedWork = inspection.items.some((item) => item.status !== "pending" || !!item.value.trim() || !!item.photoUrl);
      const complete = { ...inspection, active: false, report: { ready: hasRecordedWork } };
      const findings = complete.items.filter((item) => item.status === "advise" || item.status === "fail").length;
      const photos = complete.items.filter((item) => item.photoUrl).length;
      this.update({ phase: "locked", inspection: complete });
      this.audit("VOICE DVI", hasRecordedWork ? event : "INSPECTION CANCELLED", hasRecordedWork ? `${findings} findings - ${photos} photos` : "Inspection cancelled. No findings or photos were recorded.");
      if (complete.id) {
        this.completedInspections.set(complete.id, {
          inspection: { ...complete, items: complete.items.map((item) => ({ ...item })) },
          vin: this.snapshot.vin,
          vehicleInfo: this.snapshot.vehicleInfo ? { ...this.snapshot.vehicleInfo } : null,
          audit: this.snapshot.audit.filter((row) => row.inspectionId === complete.id)
        });
        this.update({ inspectionReports: { ...this.snapshot.inspectionReports, [complete.id]: complete.report } });
      }
      return complete;
    }
    async shareInspectionReport(inspectionId = this.snapshot.inspection?.id) {
      const archived = inspectionId ? this.completedInspections.get(inspectionId) : undefined;
      if (!inspectionId || !archived?.inspection.report?.ready)
        return { success: false, error: "No completed report is available for this inspection." };
      if (this.snapshot.inspectionReports?.[inspectionId]?.generating)
        return { success: false, error: "This report is already being prepared." };
      const updateReport = (report) => {
        this.update({
          inspectionReports: { ...this.snapshot.inspectionReports, [inspectionId]: report },
          ...this.snapshot.inspection?.id === inspectionId ? { inspection: { ...this.snapshot.inspection, report } } : {}
        });
      };
      try {
        updateReport({ ready: true, generating: true });
        const fileName = `dvi-inspection-report-${archived.vin ?? "vehicle"}.pdf`;
        const items = await this.materializeReportImages(archived.inspection.items);
        const pdf = await createInspectionReportPdf({ vin: archived.vin, vehicleInfo: archived.vehicleInfo, audit: archived.audit, items });
        const key = `reports/${Date.now()}-${fileName}`;
        await this.session.blob.set(key, pdf, { mimeType: "application/pdf", name: fileName, meta: { kind: "dvi_inspection_report" } });
        const result = await this.session.blob.share(key);
        updateReport({ ready: true, generating: false, fileName });
        return { success: result.success };
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        updateReport({ ready: true, generating: false, error: message });
        return { success: false, error: message };
      }
    }
    async shareSampleInspectionReport(photos = {}) {
      const now = Date.now();
      const vin = this.snapshot.vin ?? "1C6SRFFT0KN512088";
      const treadPhoto = photos.treadPhotoUrl ?? this.snapshot.photoUrl;
      const windshieldPhoto = photos.windshieldPhotoUrl ?? this.snapshot.photoUrl;
      const rows = [
        { time: now - 300000, app: "VIN GATE", event: "OCR CAPTURE", detail: vin, hash: "A7F2C918" },
        { time: now - 298000, app: "VIN GATE", event: "DECODE", detail: "2019 RAM 1500 - vPIC live", hash: "3E91B04D" },
        { time: now - 286000, app: "VIN GATE", event: "HUMAN CONFIRM", detail: "bound to RO-24817", hash: "C204FA71" },
        { time: now - 45000, app: "VOICE DVI", event: "FINDING FAIL", detail: "LF pad = 2mm - photo", hash: "88D31E5C" },
        { time: now - 43000, app: "VOICE DVI", event: "OPERATION STAGED", detail: "Front pads + rotors, 1.8hr", hash: "1B7C90A2" },
        { time: now - 20000, app: "SPEC RECALL", event: "SOURCED LOOKUP", detail: "Caliper bracket - Rev 2024-03", hash: "F5A2D63B" },
        { time: now - 8000, app: "PART IDENT", event: "FITMENT GATE", detail: "3 candidates, 2 rejected", hash: "6C48E017" },
        { time: now, app: "VOICE DVI", event: "TECH SIGNATURE", detail: "2 findings - 3 photos", hash: "90AE23D4" }
      ];
      const items = [
        { label: "Left-front tire tread depth", value: "2 mm", status: "fail", photoUrl: treadPhoto },
        { label: "Left-front tire condition", value: "Outer shoulder wear", status: "advise", photoUrl: treadPhoto },
        { label: "Windshield condition", value: "Stone chip", status: "advise", photoUrl: windshieldPhoto },
        { label: "Front exterior lights", value: "Right DRL out", status: "fail", photoUrl: treadPhoto }
      ];
      try {
        const fileName = "sample-dvi-inspection-report.pdf";
        const itemsWithImages = await this.materializeReportImages(items);
        const pdf = await createInspectionReportPdf({ vin, vehicleInfo: { ModelYear: "2019", Make: "RAM", Model: "1500" }, audit: rows, items: itemsWithImages });
        const key = `reports/${Date.now()}-${fileName}`;
        await this.session.blob.set(key, pdf, { mimeType: "application/pdf", name: fileName, meta: { kind: "sample_dvi_inspection_report" } });
        const result = await this.session.blob.share(key);
        return { success: result.success };
      } catch (error) {
        return { success: false, error: error instanceof Error ? error.message : String(error) };
      }
    }
    async materializeReportImages(items) {
      const downloads = new Map;
      const load = (url) => {
        const cached = downloads.get(url);
        if (cached)
          return cached;
        const pending = (async () => {
          const key = `report-evidence/${Date.now()}-${auditHash(url)}.jpg`;
          try {
            debugLog(`[report] native image download start ${url}`);
            await this.session.blob.setFromUrl(key, url, { mimeType: "image/jpeg", name: "inspection-evidence.jpg" });
            const imageBytes = await this.session.blob.bytes(key);
            if (!imageBytes?.length)
              throw new Error("native blob download returned no bytes");
            debugLog(`[report] native image download done ${imageBytes.length} bytes`);
            return imageBytes;
          } catch (error) {
            console.error(`[report] native image download failed ${url}`, error);
            return;
          } finally {
            await this.session.blob.delete(key).catch(() => {});
          }
        })();
        downloads.set(url, pending);
        return pending;
      };
      return Promise.all(items.map(async (item) => ({
        ...item,
        photoBytes: item.photoUrl ? await load(item.photoUrl) : undefined
      })));
    }
    async question(text, questionOverride) {
      const vin = this.snapshot.vin;
      if (!vin)
        return;
      const questionId = `question-${Date.now()}-${this.snapshot.questions.length}`;
      try {
        const classified = questionOverride ? { intent: "QUESTION", question: questionOverride } : await this.api("/classify_question_turn", { text }).then((response) => response.json());
        if (classified.intent !== "QUESTION") {
          this.accepting = this.snapshot.inspection?.active ? "inspection" : "ambient";
          return;
        }
        this.update({ workLoading: true, questions: [...this.snapshot.questions, {
          id: questionId,
          at: this.nextChatTime(),
          question: text,
          pending: true,
          answer: "",
          source: "No sourced record",
          provenance: "",
          found: false
        }] });
        const checkPromise = this.speakChat("Let me check.").catch((error) => {
          console.warn("[questions] acknowledgement TTS failed", error);
        });
        const answerResponse = await this.api("/owner_manual/ask", { vin, question: classified.question });
        const answer = await answerResponse.json();
        const operation = answer.source?.type === "nhtsa_vpic" ? "nhtsa.consult" : "owner_manual.consult";
        const spokenAnswer = answer.spokenAnswer ?? "I don't have a sourced record for that on this VIN. I will not guess.";
        const displayAnswer = answer.found === true ? answer.answer ?? spokenAnswer : spokenAnswer;
        const source = answer.found !== true ? "No sourced record" : answer.source?.type === "nhtsa_vpic" ? "NHTSA" : "Owner's manual";
        const provenance = answer.found !== true ? "No sourced record" : answer.source?.type === "nhtsa_vpic" ? "NHTSA vPIC VIN decode" : ["This vehicle's owner's manual", answer.source?.section, answer.source?.page ? `page ${answer.source.page}` : ""].filter(Boolean).join(", ");
        this.snapshot.dataStore = [...this.snapshot.dataStore, {
          operation,
          status: answer.found ? "Data store successful" : "No sourced record",
          successful: answer.found === true
        }];
        this.update({ workLoading: false, questions: this.snapshot.questions.map((entry) => entry.id === questionId ? {
          ...entry,
          pending: false,
          answerAt: this.nextChatTime(),
          answer: displayAnswer,
          source,
          provenance,
          found: answer.found === true
        } : entry) });
        await checkPromise;
        this.requireActive();
        await speakWithTiming(this.session, spokenAnswer);
        this.accepting = this.snapshot.inspection?.active ? "inspection" : "ambient";
      } catch (error) {
        this.snapshot.questions = this.snapshot.questions.map((entry) => entry.id === questionId ? { ...entry, pending: false } : entry);
        this.fail("question", error);
      }
    }
    fail(step, error) {
      if (this.mode.page !== "automotive")
        return;
      console.error(`[vin] ${step} failed`, error);
      this.accepting = "none";
      this.running = false;
      this.update({ phase: "error", workLoading: false, error: userFacingWorkflowError(step, error) });
    }
  }

  // src/background/index.ts
  registerMiniapp((session) => {
    const mode = new WorkflowMode;
    const ai = new AiController(session, mode);
    const automotive = new VinWorkflowController(session, mode);
    const document2 = new DocumentController(session, mode);
    document2.start();
    ai.start();
    automotive.start();
    const ui = session.ui;
    let switching = false;
    const publishMode = () => ui.send("app:mode", { active: mode.page === "none" ? null : mode.page, switching });
    ui.onOpen(publishMode);
    ui.on("app:request-mode", publishMode);
    ui.handle("app:start-mode", async ({ mode: next }) => {
      if (!["automotive", "ai", "document"].includes(next))
        return { success: false, error: "Unknown mode" };
      if (switching)
        return { success: false, error: "A mode switch is already in progress." };
      if (mode.page === next)
        return { success: true };
      switching = true;
      mode.page = "none";
      publishMode();
      try {
        session.speaker.stop();
        await Promise.all([ai.deactivate(), automotive.deactivate(), document2.deactivate()]);
        session.speaker.stop();
        mode.page = next;
        if (next === "automotive")
          automotive.activate();
        else if (next === "ai")
          await ai.activate();
        else if (next === "document")
          await document2.activate();
        return { success: true };
      } catch {
        mode.page = "none";
        return { success: false, error: "Could not switch modes. Please try again." };
      } finally {
        switching = false;
        publishMode();
        if (mode.page === "ai")
          ai.speakIntro();
        else if (mode.page === "document")
          document2.speakIntro();
      }
    });
    try {
      new GlassesController(session).start();
    } catch (err) {
      console.error("[example-miniapp] GlassesController failed to start", err);
    }
    try {
      new TesterController(session).start();
    } catch (err) {
      console.error("[example-miniapp] TesterController failed to start", err);
    }
  });
})();
