import {
  existsSync,
  mkdirSync,
  readFileSync,
  copyFileSync,
  lstatSync,
  realpathSync,
  renameSync,
  rmSync,
  writeFileSync,
} from 'fs';
import { createHash } from 'node:crypto';
import { isAbsolute, resolve, join, relative, sep } from 'path';
import { buildProduction } from './build.js';
import { signBundleArchive, verifySignedBundleArchive } from './bundle-signing.js';
import { warnIfPlaceholderIcon } from './icon.js';
import { validateManifest } from './manifest.js';
import { missingSigningKeyError, resolvePackageSigningKey, type PackageSigningKey } from './package-signing-key.js';

export interface PackOptions {
  /** Miniapp project root. Defaults to the current working directory. */
  cwd?: string;
  /** Run the production build before zipping. Defaults to false. */
  build?: boolean;
  /** Where to write the resulting zip. Defaults to build/. */
  outDir?: string;
  /** Quiet stdout. The `release` command swallows pack output and prints
   * its own progress; standalone `pack` calls leave it on. */
  silent?: boolean;
  /** Command used to create the ZIP. Intended for tests and embedders. */
  zipCommand?: string;
  /**
   * Sign the bundle with the package's publisher key.
   *
   * Off by default. Publisher identity is opt-in on the host and sticky: the
   * first signed bundle a package installs pins that key for every later
   * update, and the envelope has no rotation chain. Signing is therefore a
   * one-way door per package — take it deliberately, once the key has somewhere
   * durable to live, not as a side effect of repacking.
   *
   * Passing `signingKey` or `signingKeyPath` is itself that intent and implies
   * this.
   */
  sign?: boolean;
  /** Explicit package signing key. Implies `sign`. */
  signingKey?: PackageSigningKey;
  /** Read a package signing key without importing it into persistent storage. Implies `sign`. */
  signingKeyPath?: string;
}

/**
 * Validate manifest, copy manifest+icon into dist/, zip dist/ into
 * `build/<packageName>-<version>.zip`. Returns the absolute path of the zip.
 *
 * `build/` is self-ignoring: a `.gitignore` containing `*` is written into
 * it on creation (the Cargo `target/` trick), so packed zips stay out of
 * version control no matter which repo the miniapp lives in — no root
 * .gitignore coordination needed.
 */
export async function pack(opts: PackOptions = {}): Promise<string> {
  const cwd = resolve(opts.cwd ?? process.cwd());
  if (opts.build) {
    await buildProduction(cwd, { silent: opts.silent });
  }

  const distDir = resolve(cwd, 'dist');
  const manifestSrc = resolve(cwd, 'miniapp.json');
  const iconSrc = resolve(cwd, 'icon.png');

  // Verify dist/ exists
  if (!existsSync(distDir)) {
    console.error('Error: dist/ directory not found. Build your miniapp first.');
    process.exit(1);
  }

  // Verify miniapp.json exists
  if (!existsSync(manifestSrc)) {
    console.error('Error: miniapp.json not found in current directory');
    process.exit(1);
  }

  // Read and validate manifest
  const manifestRaw = readFileSync(manifestSrc, 'utf-8');
  let manifest: Record<string, unknown>;
  let publisherFingerprint = '';
  let bundleSha256 = '';
  try {
    manifest = JSON.parse(manifestRaw);
  } catch {
    console.error('Error: miniapp.json is not valid JSON');
    process.exit(1);
  }

  const { valid, errors } = validateManifest(manifest);
  if (!valid) {
    console.error('Manifest validation failed:');
    for (const err of errors) {
      console.error(`  - ${err}`);
    }
    process.exit(1);
  }

  // Enforce two-layer bundle contract when manifest.entry is set.
  // `entry.background` (required for two-layer) must resolve to a file in the
  // bundle. `entry.ui` (optional, for UI-bearing miniapps) likewise. Legacy
  // single-bundle manifests without an `entry` object skip this check —
  // pack still zips dist/ verbatim.
  //
  // Entry paths are relative to the *bundle root*, which is dist/'s contents
  // (we zip from inside dist/ below), so `background/index.js` in the manifest
  // is `dist/background/index.js` on disk — resolve against distDir.
  const entry = manifest.entry as { background?: string; ui?: string } | undefined;
  const realDistDir = realpathSync(distDir);
  if (entry) {
    const checkRelative = (label: string, rel: string | undefined, required: boolean) => {
      if (!rel) {
        if (required) {
          console.error(`Error: manifest.entry.${label} is required for two-layer bundles`);
          process.exit(1);
        }
        return;
      }
      if (
        rel.includes('\\') ||
        isAbsolute(rel) ||
        rel.split('/').some(segment => segment === '' || segment === '.' || segment === '..')
      ) {
        console.error(`Error: manifest.entry.${label} must be a safe relative path inside dist/`);
        process.exit(1);
      }
      const abs = resolve(distDir, rel);
      const relativePath = relative(distDir, abs);
      if (!relativePath || relativePath.split(sep).includes('..')) {
        console.error(`Error: manifest.entry.${label} must be a safe relative path inside dist/`);
        process.exit(1);
      }
      if (
        !existsSync(abs) ||
        !lstatSync(abs).isFile() ||
        relative(realDistDir, realpathSync(abs)).split(sep).includes('..')
      ) {
        console.error(`Error: manifest.entry.${label} points at "${rel}" but dist/${rel} does not exist`);
        process.exit(1);
      }
    };
    checkRelative('background', entry.background, true);
    checkRelative('ui', entry.ui, false);
  }

  // Copy miniapp.json into dist/
  copyFileSync(manifestSrc, join(distDir, 'miniapp.json'));

  // Copy icon.png into dist/ if it exists
  if (existsSync(iconSrc)) {
    if (!opts.silent) warnIfPlaceholderIcon(cwd);
    copyFileSync(iconSrc, join(distDir, 'icon.png'));
  } else if (!opts.silent) {
    console.warn('Warning: icon.png not found in project root, skipping');
  }

  const packageName = manifest.packageName as string;
  const version = manifest.version as string;
  const outputName = `${packageName}-${version}.zip`;
  const outDir = resolve(cwd, opts.outDir ?? 'build');
  if (!existsSync(outDir)) {
    mkdirSync(outDir, { recursive: true });
  }
  const selfIgnore = join(outDir, '.gitignore');
  if (!existsSync(selfIgnore)) {
    writeFileSync(selfIgnore, '*\n');
  }
  const outputPath = resolve(outDir, outputName);
  const temporaryPath = resolve(outDir, `.${outputName}.${process.pid}.${Date.now()}.tmp`);

  // Build beside the destination and atomically replace it only after zip
  // succeeds. A failed pack must never destroy the last publishable artifact.
  const zipProc = Bun.spawn([opts.zipCommand ?? 'zip', '-r', temporaryPath, '.'], {
    cwd: distDir,
    stdout: opts.silent ? 'ignore' : 'inherit',
    stderr: opts.silent ? 'ignore' : 'inherit',
  });

  try {
    const exitCode = await zipProc.exited;
    if (exitCode !== 0) throw new Error('zip command failed');
    const wantsSignature = opts.sign === true || Boolean(opts.signingKey) || Boolean(opts.signingKeyPath);
    if (wantsSignature) {
      const signingKey =
        opts.signingKey ?? (await resolvePackageSigningKey(packageName, { inputPath: opts.signingKeyPath }));
      if (!signingKey) throw missingSigningKeyError(packageName);
      const signedArchive = await signBundleArchive(readFileSync(temporaryPath), signingKey);
      const verified = await verifySignedBundleArchive(signedArchive);
      if (verified.packageName !== packageName || verified.version !== version) {
        throw new Error('Signed bundle identity does not match miniapp.json');
      }
      publisherFingerprint = verified.publisherKeyFingerprint;
      bundleSha256 = createHash('sha256').update(signedArchive).digest('hex');
      writeFileSync(temporaryPath, signedArchive);
    } else {
      bundleSha256 = createHash('sha256').update(readFileSync(temporaryPath)).digest('hex');
    }
    renameSync(temporaryPath, outputPath);
  } catch (error) {
    rmSync(temporaryPath, { force: true });
    throw error;
  }

  if (!opts.silent) {
    console.log(`\nPacked: ${outputPath}`);
    console.log(publisherFingerprint ? `Publisher key: ${publisherFingerprint}` : 'Publisher key: unsigned');
    console.log(`SHA-256: ${bundleSha256}`);
  }
  return outputPath;
}
