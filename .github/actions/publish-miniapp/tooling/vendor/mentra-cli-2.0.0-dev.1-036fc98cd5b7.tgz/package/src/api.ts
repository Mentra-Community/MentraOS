import type { CliConfig } from "./config";
import type { CliCredentials } from "./credentials";

const DEVICE_AUTH_GRANT_TYPE = "urn:ietf:params:oauth:grant-type:device_code";

export type CliJwk = Record<string, unknown> & {
  kty?: string;
  crv?: string;
  x?: string;
  d?: string;
};

export interface DeviceAuthorizationResponse {
  device_code: string;
  user_code: string;
  verification_uri: string;
  verification_uri_complete: string;
  expires_in: number;
  interval: number;
}

export interface LoginTokenResponse {
  access_token: string;
  refresh_token?: string;
  token_type?: "Bearer";
  expires_in?: number;
  authentication_method?: string;
  organization_id?: string | null;
  user: {
    id: string;
    email: string;
    first_name?: string | null;
    last_name?: string | null;
  };
}

export interface PendingDeviceAuthorization {
  status: "pending";
  interval?: number;
}

export interface SlowDownDeviceAuthorization {
  status: "slow_down";
  interval?: number;
}

export interface DeveloperApp {
  id: string;
  packageName: string;
  name: string;
  description: string | null;
  status: "active" | "archived" | "suspended";
  activeRelease: DeveloperRelease | null;
  activeBetaRelease?: DeveloperRelease | null;
  latestRelease: DeveloperRelease | null;
  releaseCount: number;
  createdAt: string | null;
  updatedAt: string | null;
}

export interface DeveloperRelease {
  id: string;
  version: string;
  releaseTrack: "stable" | "beta";
  status: "draft" | "submitted" | "in_review" | "accepted" | "rejected" | "published" | "suspended";
  releaseBundleAssetId: string | null;
  bundleSha256: string | null;
  bundleSizeBytes: number | null;
  manifestSha256?: string | null;
  publisherKeyFingerprint?: string | null;
  signedAt?: string | null;
  reviewedBy?: string | null;
  reviewNotes?: string | null;
  createdAt: string | null;
  updatedAt: string | null;
}

export interface DeveloperOrg {
  id: string;
  ownerUserId: string;
  workosOrgId: string | null;
  name: string;
  packagePrefix: string;
  packagePrefixStatus: "unverified" | "verified" | "rejected";
  createdAt: string | null;
  updatedAt: string | null;
}

export interface ConsoleSessionResponse {
  organizationId: string | null;
  organizations: DeveloperOrg[];
}

export interface DeveloperSigningKey {
  id: string;
  orgId: string;
  workosUserId: string;
  publicKeyJwk: CliJwk;
  status: "active" | "revoked";
  lastUsedAt: string | null;
  createdAt: string | null;
  updatedAt: string | null;
}

export interface AdminUser {
  developerId: string;
  email: string;
}

export interface StoreAsset {
  id: string;
  role: "store_icon" | "store_cover" | "gallery_screenshot";
  fileName: string;
  sha256: string;
}

export interface StoreListingInput {
  subtitle?: string | null;
  longDescription?: string | null;
  categories?: string[];
  privacyPolicyUrl?: string | null;
  supportUrl?: string | null;
  websiteUrl?: string | null;
}

export interface StoreListing extends StoreListingInput {
  iconAssetId: string | null;
  coverAssetId: string | null;
  screenshotAssetIds: string[];
  assets: StoreAsset[];
}

export function getListing(credentials: CliCredentials, packageName: string): Promise<{listing: StoreListing}> {
  return storeRequest(credentials, `/api/console/apps/${encodeURIComponent(packageName)}/listing`);
}

export function updateListing(credentials: CliCredentials, packageName: string, input: StoreListingInput): Promise<{listing: StoreListing}> {
  return storeRequest(credentials, `/api/console/apps/${encodeURIComponent(packageName)}/listing`, {method: "PUT", body: JSON.stringify(input)});
}

export function uploadListingAsset(credentials: CliCredentials, packageName: string, input: {role: StoreAsset["role"]; fileName: string; contentType: string; base64: string}): Promise<{asset: StoreAsset}> {
  return storeRequest(credentials, `/api/console/apps/${encodeURIComponent(packageName)}/listing/assets`, {method: "POST", body: JSON.stringify(input)});
}

export function deleteListingAsset(credentials: CliCredentials, packageName: string, assetId: string): Promise<{ok: true}> {
  return storeRequest(credentials, `/api/console/apps/${encodeURIComponent(packageName)}/listing/assets/${encodeURIComponent(assetId)}`, {method: "DELETE"});
}

export function publishRelease(credentials: CliCredentials, packageName: string, releaseId: string): Promise<{release: DeveloperRelease}> {
  return storeRequest(credentials, `/api/console/apps/${encodeURIComponent(packageName)}/releases/${encodeURIComponent(releaseId)}/publish`, {method: "POST"});
}

export function reviewRelease(credentials: CliCredentials, releaseId: string, action: "approve" | "reject" | "publish", notes?: string): Promise<{release: DeveloperRelease}> {
  return storeRequest(credentials, `/api/admin/submissions/${encodeURIComponent(releaseId)}/${action}`, {method: "POST", body: JSON.stringify({notes})});
}

export function createPublishingToken(credentials: CliCredentials, packageName: string, name: string): Promise<{token: {id: string; value: string; permissions: string[]}}> {
  return storeRequest(credentials, `/api/admin/apps/${encodeURIComponent(packageName)}/publishing-tokens`, {method: "POST", body: JSON.stringify({name})});
}

export function listApiTokens(credentials: CliCredentials): Promise<{tokens: Array<{id: string; name: string; permissions: string[]}>}> {
  return storeRequest(credentials, "/api/console/tokens");
}

export function createApiToken(credentials: CliCredentials, name: string): Promise<{token: {id: string; value: string}}> {
  return storeRequest(credentials, "/api/console/tokens", {method: "POST", body: JSON.stringify({name})});
}

export function revokeApiToken(credentials: CliCredentials, tokenId: string): Promise<{ok: true}> {
  return storeRequest(credentials, `/api/console/tokens/${encodeURIComponent(tokenId)}`, {method: "DELETE"});
}

export async function startLogin(config: CliConfig): Promise<DeviceAuthorizationResponse> {
  await ensureWorkosClientId(config);
  const body = new URLSearchParams({ client_id: config.workosClientId });
  const response = await fetch(`${config.workosApiBaseUrl}/user_management/authorize/device`, {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded", "accept": "application/json" },
    body,
  });
  if (!response.ok) throw new Error(await errorMessage(response));
  return (await response.json()) as DeviceAuthorizationResponse;
}

export async function pollLoginToken(
  config: CliConfig,
  deviceCode: string,
): Promise<LoginTokenResponse | PendingDeviceAuthorization | SlowDownDeviceAuthorization> {
  await ensureWorkosClientId(config);
  const body = new URLSearchParams({
    grant_type: DEVICE_AUTH_GRANT_TYPE,
    device_code: deviceCode,
    client_id: config.workosClientId,
  });
  const response = await fetch(`${config.workosApiBaseUrl}/user_management/authenticate`, {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded", "accept": "application/json" },
    body,
  });
  if (response.status === 400 || response.status === 403) {
    const result = (await response.json().catch(() => ({}))) as { error?: string; error_description?: string };
    if (result.error === "authorization_pending") return { status: "pending" };
    if (result.error === "slow_down") return { status: "slow_down" };
    throw new Error(result.error_description || result.error || `HTTP ${response.status}`);
  }
  if (!response.ok) throw new Error(await errorMessage(response));
  return (await response.json()) as LoginTokenResponse;
}

export async function refreshLoginToken(
  config: CliConfig,
  refreshToken: string,
  organizationId?: string | null,
): Promise<LoginTokenResponse> {
  await ensureWorkosClientId(config);
  const body: Record<string, string> = {
    client_id: config.workosClientId,
    grant_type: "refresh_token",
    refresh_token: refreshToken,
  };
  if (organizationId) body.organization_id = organizationId;

  const response = await fetch(`${config.workosApiBaseUrl}/user_management/authenticate`, {
    method: "POST",
    headers: { "content-type": "application/json", "accept": "application/json" },
    body: JSON.stringify(body),
  });
  if (!response.ok) throw new Error(await errorMessage(response));
  return (await response.json()) as LoginTokenResponse;
}

export async function listApps(credentials: CliCredentials): Promise<{ apps: DeveloperApp[] }> {
  return storeRequest(credentials, "/api/console/apps");
}

export async function getAdminMe(
  credentials: CliCredentials,
): Promise<{ authenticated: true; admin: true; user: AdminUser | null }> {
  return storeRequest(credentials, "/api/admin/me");
}

export async function getOrg(credentials: CliCredentials): Promise<{ org: DeveloperOrg | null }> {
  return storeRequest(credentials, "/api/console/org");
}

export async function getConsoleSession(credentials: CliCredentials): Promise<ConsoleSessionResponse> {
  return storeRequest(credentials, "/api/console/auth/me");
}

export async function upsertOrg(
  credentials: CliCredentials,
  input: { displayName: string; packagePrefix: string; createNew?: boolean },
): Promise<{ org: DeveloperOrg }> {
  return storeRequest(credentials, "/api/console/org", {
    method: "PUT",
    body: JSON.stringify(input),
  });
}

export async function createApp(
  credentials: CliCredentials,
  input: { packageName: string; displayName: string; description?: string | null },
): Promise<{ app: DeveloperApp }> {
  return storeRequest(credentials, "/api/console/apps", {
    method: "POST",
    body: JSON.stringify(input),
  });
}

export async function deleteApp(credentials: CliCredentials, packageName: string): Promise<{ ok: true }> {
  return storeRequest(credentials, `/api/console/apps/${encodeURIComponent(packageName)}`, {
    method: "DELETE",
  });
}

export async function listReleases(
  credentials: CliCredentials,
  packageName: string,
): Promise<{ releases: DeveloperRelease[] }> {
  return storeRequest(credentials, `/api/console/apps/${encodeURIComponent(packageName)}/releases`);
}

export async function createRelease(
  credentials: CliCredentials,
  input: {
    packageName: string;
    version: string;
    releaseTrack: "stable" | "beta";
    manifest: Record<string, unknown>;
    bundle: Uint8Array;
    fileName?: string;
  },
): Promise<{ release: DeveloperRelease }> {
  const form = new FormData();
  form.set("packageName", input.packageName);
  form.set("version", input.version);
  form.set("releaseTrack", input.releaseTrack);
  form.set("manifest", JSON.stringify(input.manifest));
  form.set("fileName", input.fileName ?? "bundle.zip");
  form.set("bundle", new Blob([input.bundle], { type: "application/zip" }), input.fileName ?? "bundle.zip");
  return storeRequest(credentials, `/api/console/apps/${encodeURIComponent(input.packageName)}/releases`, {
    method: "POST",
    body: form,
  });
}

export async function listSigningKeys(credentials: CliCredentials): Promise<{ keys: DeveloperSigningKey[] }> {
  return storeRequest(credentials, "/api/console/signing-keys");
}

export async function registerSigningKey(
  credentials: CliCredentials,
  input: { publicKeyJwk: CliJwk },
): Promise<{ key: DeveloperSigningKey }> {
  return storeRequest(credentials, "/api/console/signing-keys", {
    method: "POST",
    body: JSON.stringify(input),
  });
}

export async function submitRelease(
  credentials: CliCredentials,
  input: {
    packageName: string;
    releaseId: string;
  },
): Promise<{ release: DeveloperRelease }> {
  return storeRequest(
    credentials,
    `/api/console/apps/${encodeURIComponent(input.packageName)}/releases/${encodeURIComponent(input.releaseId)}/submit`,
    { method: "POST" },
  );
}

async function storeRequest<T>(credentials: CliCredentials, path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(`${credentials.storeUrl}${path}`, {
    ...init,
    headers: {
      accept: "application/json",
      authorization: `Bearer ${credentials.token}`,
      ...(credentials.developerOrgId ? { "x-mentra-developer-org-id": credentials.developerOrgId } : {}),
      ...(typeof init?.body === "string" ? { "content-type": "application/json" } : {}),
      ...init?.headers,
    },
  });
  if (!response.ok) throw new Error(await errorMessage(response));
  return (await response.json()) as T;
}

async function ensureWorkosClientId(config: CliConfig): Promise<void> {
  if (config.workosClientId) return;

  const response = await fetch(`${config.storeUrl}/api/console/auth/cli-config`, {
    headers: { accept: "application/json" },
  });
  if (!response.ok) throw new Error(await errorMessage(response));
  const body = (await response.json()) as { workosClientId?: unknown };
  if (typeof body.workosClientId !== "string" || !body.workosClientId.trim()) {
    throw new Error("The Mentra Miniapp Store did not provide a WorkOS client id for CLI login");
  }
  // Cache the public client id on this command's config so polling does not
  // refetch the Store every interval. Environment overrides still win for local or
  // non-Mentra deployments.
  config.workosClientId = body.workosClientId.trim();
}

async function errorMessage(response: Response): Promise<string> {
  try {
    const body = (await response.json()) as { error?: string; error_description?: string };
    return body.error_description || body.error || `HTTP ${response.status}`;
  } catch {
    return `HTTP ${response.status}`;
  }
}
