(() => {
  var __create = Object.create;
  var __getProtoOf = Object.getPrototypeOf;
  var __defProp = Object.defineProperty;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  function __accessProp(key) {
    return this[key];
  }
  var __toESMCache_node;
  var __toESMCache_esm;
  var __toESM = (mod, isNodeMode, target) => {
    var canCache = mod != null && typeof mod === "object";
    if (canCache) {
      var cache = isNodeMode ? __toESMCache_node ??= new WeakMap : __toESMCache_esm ??= new WeakMap;
      var cached = cache.get(mod);
      if (cached)
        return cached;
    }
    target = mod != null ? __create(__getProtoOf(mod)) : {};
    const to = isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target;
    for (let key of __getOwnPropNames(mod))
      if (!__hasOwnProp.call(to, key))
        __defProp(to, key, {
          get: __accessProp.bind(mod, key),
          enumerable: true
        });
    if (canCache)
      cache.set(mod, to);
    return to;
  };
  var __commonJS = (cb, mod) => () => (mod || cb((mod = { exports: {} }).exports, mod), mod.exports);
  var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
    get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
  }) : x)(function(x) {
    if (typeof require !== "undefined")
      return require.apply(this, arguments);
    throw Error('Dynamic require of "' + x + '" is not supported');
  });

  // ../node_modules/.bun/eventemitter3@5.0.4/node_modules/eventemitter3/index.js
  var require_eventemitter3 = __commonJS((exports, module) => {
    var has = Object.prototype.hasOwnProperty;
    var prefix = "~";
    function Events() {}
    if (Object.create) {
      Events.prototype = Object.create(null);
      if (!new Events().__proto__)
        prefix = false;
    }
    function EE(fn, context, once) {
      this.fn = fn;
      this.context = context;
      this.once = once || false;
    }
    function addListener(emitter, event, fn, context, once) {
      if (typeof fn !== "function") {
        throw new TypeError("The listener must be a function");
      }
      var listener = new EE(fn, context || emitter, once), evt = prefix ? prefix + event : event;
      if (!emitter._events[evt])
        emitter._events[evt] = listener, emitter._eventsCount++;
      else if (!emitter._events[evt].fn)
        emitter._events[evt].push(listener);
      else
        emitter._events[evt] = [emitter._events[evt], listener];
      return emitter;
    }
    function clearEvent(emitter, evt) {
      if (--emitter._eventsCount === 0)
        emitter._events = new Events;
      else
        delete emitter._events[evt];
    }
    function EventEmitter() {
      this._events = new Events;
      this._eventsCount = 0;
    }
    EventEmitter.prototype.eventNames = function eventNames() {
      var names = [], events, name;
      if (this._eventsCount === 0)
        return names;
      for (name in events = this._events) {
        if (has.call(events, name))
          names.push(prefix ? name.slice(1) : name);
      }
      if (Object.getOwnPropertySymbols) {
        return names.concat(Object.getOwnPropertySymbols(events));
      }
      return names;
    };
    EventEmitter.prototype.listeners = function listeners(event) {
      var evt = prefix ? prefix + event : event, handlers = this._events[evt];
      if (!handlers)
        return [];
      if (handlers.fn)
        return [handlers.fn];
      for (var i = 0, l = handlers.length, ee = new Array(l);i < l; i++) {
        ee[i] = handlers[i].fn;
      }
      return ee;
    };
    EventEmitter.prototype.listenerCount = function listenerCount(event) {
      var evt = prefix ? prefix + event : event, listeners = this._events[evt];
      if (!listeners)
        return 0;
      if (listeners.fn)
        return 1;
      return listeners.length;
    };
    EventEmitter.prototype.emit = function emit(event, a1, a2, a3, a4, a5) {
      var evt = prefix ? prefix + event : event;
      if (!this._events[evt])
        return false;
      var listeners = this._events[evt], len = arguments.length, args, i;
      if (listeners.fn) {
        if (listeners.once)
          this.removeListener(event, listeners.fn, undefined, true);
        switch (len) {
          case 1:
            return listeners.fn.call(listeners.context), true;
          case 2:
            return listeners.fn.call(listeners.context, a1), true;
          case 3:
            return listeners.fn.call(listeners.context, a1, a2), true;
          case 4:
            return listeners.fn.call(listeners.context, a1, a2, a3), true;
          case 5:
            return listeners.fn.call(listeners.context, a1, a2, a3, a4), true;
          case 6:
            return listeners.fn.call(listeners.context, a1, a2, a3, a4, a5), true;
        }
        for (i = 1, args = new Array(len - 1);i < len; i++) {
          args[i - 1] = arguments[i];
        }
        listeners.fn.apply(listeners.context, args);
      } else {
        var length = listeners.length, j;
        for (i = 0;i < length; i++) {
          if (listeners[i].once)
            this.removeListener(event, listeners[i].fn, undefined, true);
          switch (len) {
            case 1:
              listeners[i].fn.call(listeners[i].context);
              break;
            case 2:
              listeners[i].fn.call(listeners[i].context, a1);
              break;
            case 3:
              listeners[i].fn.call(listeners[i].context, a1, a2);
              break;
            case 4:
              listeners[i].fn.call(listeners[i].context, a1, a2, a3);
              break;
            default:
              if (!args)
                for (j = 1, args = new Array(len - 1);j < len; j++) {
                  args[j - 1] = arguments[j];
                }
              listeners[i].fn.apply(listeners[i].context, args);
          }
        }
      }
      return true;
    };
    EventEmitter.prototype.on = function on(event, fn, context) {
      return addListener(this, event, fn, context, false);
    };
    EventEmitter.prototype.once = function once(event, fn, context) {
      return addListener(this, event, fn, context, true);
    };
    EventEmitter.prototype.removeListener = function removeListener(event, fn, context, once) {
      var evt = prefix ? prefix + event : event;
      if (!this._events[evt])
        return this;
      if (!fn) {
        clearEvent(this, evt);
        return this;
      }
      var listeners = this._events[evt];
      if (listeners.fn) {
        if (listeners.fn === fn && (!once || listeners.once) && (!context || listeners.context === context)) {
          clearEvent(this, evt);
        }
      } else {
        for (var i = 0, events = [], length = listeners.length;i < length; i++) {
          if (listeners[i].fn !== fn || once && !listeners[i].once || context && listeners[i].context !== context) {
            events.push(listeners[i]);
          }
        }
        if (events.length)
          this._events[evt] = events.length === 1 ? events[0] : events;
        else
          clearEvent(this, evt);
      }
      return this;
    };
    EventEmitter.prototype.removeAllListeners = function removeAllListeners(event) {
      var evt;
      if (event) {
        evt = prefix ? prefix + event : event;
        if (this._events[evt])
          clearEvent(this, evt);
      } else {
        this._events = new Events;
        this._eventsCount = 0;
      }
      return this;
    };
    EventEmitter.prototype.off = EventEmitter.prototype.removeListener;
    EventEmitter.prototype.addListener = EventEmitter.prototype.on;
    EventEmitter.prefixed = prefix;
    EventEmitter.EventEmitter = EventEmitter;
    if (typeof module !== "undefined") {
      module.exports = EventEmitter;
    }
  });
  // ../node_modules/.bun/eventemitter3@5.0.4/node_modules/eventemitter3/index.mjs
  var import__ = __toESM(require_eventemitter3(), 1);

  // ../vendor/miniapp/dist/envelope.js
  function serializeEnvelope(envelope) {
    return JSON.stringify(envelope);
  }
  function parseEnvelope(raw) {
    if (typeof raw !== "string")
      return null;
    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch {
      return null;
    }
    if (typeof parsed !== "object" || parsed === null)
      return null;
    const obj = parsed;
    if (typeof obj.payload !== "object" || obj.payload === null)
      return null;
    if (obj.requestId !== undefined && typeof obj.requestId !== "string")
      return null;
    return {
      payload: obj.payload,
      requestId: obj.requestId
    };
  }
  function makeRequestId() {
    if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
      return crypto.randomUUID();
    }
    return `req_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
  }

  // ../vendor/miniapp/dist/globals.js
  function getMentraOSGlobals() {
    if (typeof window === "undefined")
      return {};
    return window.MentraOS ?? {};
  }

  // ../vendor/miniapp/dist/protocol.js
  var MiniappRequestType;
  (function(MiniappRequestType2) {
    MiniappRequestType2["CONNECT"] = "miniapp_connect";
    MiniappRequestType2["AUTH_REFRESH"] = "miniapp_auth_refresh";
    MiniappRequestType2["SUBSCRIBE"] = "miniapp_subscribe";
    MiniappRequestType2["DISPLAY"] = "miniapp_display";
    MiniappRequestType2["RENDER"] = "miniapp_render";
    MiniappRequestType2["PLAY_AUDIO"] = "miniapp_play_audio";
    MiniappRequestType2["STOP_AUDIO"] = "miniapp_stop_audio";
    MiniappRequestType2["SPEAK"] = "miniapp_speak";
    MiniappRequestType2["SPEAKER_STREAM_OPEN"] = "miniapp_speaker_stream_open";
    MiniappRequestType2["SPEAKER_STREAM_WRITE"] = "miniapp_speaker_stream_write";
    MiniappRequestType2["SPEAKER_STREAM_CLOSE"] = "miniapp_speaker_stream_close";
    MiniappRequestType2["SPEAKER_STREAM_ABORT"] = "miniapp_speaker_stream_abort";
    MiniappRequestType2["RGB_LED"] = "miniapp_rgb_led";
    MiniappRequestType2["LOCATION_POLL"] = "miniapp_location_poll";
    MiniappRequestType2["CALENDAR_LIST_EVENTS"] = "miniapp_calendar_list_events";
    MiniappRequestType2["NAVIGATION_START"] = "miniapp_navigation_start";
    MiniappRequestType2["NAVIGATION_STOP"] = "miniapp_navigation_stop";
    MiniappRequestType2["NAVIGATION_DEVIATE"] = "miniapp_navigation_deviate";
    MiniappRequestType2["NAVIGATION_SET_WRONG_SIDEWALK"] = "miniapp_navigation_set_wrong_sidewalk";
    MiniappRequestType2["NAVIGATION_SET_SKIP_CROSSINGS"] = "miniapp_navigation_set_skip_crossings";
    MiniappRequestType2["NAVIGATION_GET_STATE"] = "miniapp_navigation_get_state";
    MiniappRequestType2["NAVIGATION_COMPUTE_ROUTE"] = "miniapp_navigation_compute_route";
    MiniappRequestType2["NAVIGATION_REVERSE_GEOCODE"] = "miniapp_navigation_reverse_geocode";
    MiniappRequestType2["NAVIGATION_PLACE_AUTOCOMPLETE"] = "miniapp_navigation_place_autocomplete";
    MiniappRequestType2["NAVIGATION_PLACE_DETAILS"] = "miniapp_navigation_place_details";
    MiniappRequestType2["NAVIGATION_REQUEST_PERMISSION"] = "miniapp_navigation_request_permission";
    MiniappRequestType2["STORAGE_GET"] = "miniapp_storage_get";
    MiniappRequestType2["STORAGE_SET"] = "miniapp_storage_set";
    MiniappRequestType2["STORAGE_DELETE"] = "miniapp_storage_delete";
    MiniappRequestType2["STORAGE_LIST"] = "miniapp_storage_list";
    MiniappRequestType2["STORAGE_CLEAR"] = "miniapp_storage_clear";
    MiniappRequestType2["STORAGE_HAS"] = "miniapp_storage_has";
    MiniappRequestType2["STORAGE_GET_ALL"] = "miniapp_storage_get_all";
    MiniappRequestType2["STORAGE_SET_MULTIPLE"] = "miniapp_storage_set_multiple";
    MiniappRequestType2["STORAGE_FLUSH"] = "miniapp_storage_flush";
    MiniappRequestType2["CAMERA_FOV"] = "miniapp_camera_fov";
    MiniappRequestType2["CAMERA_WARM_UP"] = "miniapp_camera_warm_up";
    MiniappRequestType2["IMU_SET_ENABLED"] = "miniapp_imu_set_enabled";
    MiniappRequestType2["MIC_SET_VAD_ENABLED"] = "miniapp_mic_set_vad_enabled";
    MiniappRequestType2["MIC_SET_LOUDNESS_GATE_ENABLED"] = "miniapp_mic_set_loudness_gate_enabled";
    MiniappRequestType2["MIC_ACQUIRE"] = "miniapp_mic_acquire";
    MiniappRequestType2["MIC_RELEASE"] = "miniapp_mic_release";
    MiniappRequestType2["SET_WIFI_ADB_STATE"] = "miniapp_set_wifi_adb_state";
    MiniappRequestType2["SHARE"] = "miniapp_share";
    MiniappRequestType2["OPEN_URL"] = "miniapp_open_url";
    MiniappRequestType2["COPY_CLIPBOARD"] = "miniapp_copy_clipboard";
    MiniappRequestType2["DOWNLOAD"] = "miniapp_download";
    MiniappRequestType2["SCAN_QR"] = "miniapp_scan_qr";
    MiniappRequestType2["BLOB_CREATE"] = "miniapp_blob_create";
    MiniappRequestType2["BLOB_WRITE"] = "miniapp_blob_write";
    MiniappRequestType2["BLOB_COMMIT"] = "miniapp_blob_commit";
    MiniappRequestType2["BLOB_ABORT"] = "miniapp_blob_abort";
    MiniappRequestType2["BLOB_GET"] = "miniapp_blob_get";
    MiniappRequestType2["BLOB_LIST"] = "miniapp_blob_list";
    MiniappRequestType2["BLOB_DELETE"] = "miniapp_blob_delete";
    MiniappRequestType2["BLOB_CLEAR"] = "miniapp_blob_clear";
    MiniappRequestType2["BLOB_USAGE"] = "miniapp_blob_usage";
    MiniappRequestType2["BLOB_OPEN_READ"] = "miniapp_blob_open_read";
    MiniappRequestType2["BLOB_READ"] = "miniapp_blob_read";
    MiniappRequestType2["BLOB_CLOSE_READ"] = "miniapp_blob_close_read";
    MiniappRequestType2["BLOB_SET_FROM_URL"] = "miniapp_blob_set_from_url";
    MiniappRequestType2["BLOB_IMPORT"] = "miniapp_blob_import";
    MiniappRequestType2["BLOB_SHARE"] = "miniapp_blob_share";
    MiniappRequestType2["PING"] = "miniapp_ping";
    MiniappRequestType2["TRANSCRIPTION_CONFIG"] = "miniapp_transcription_config";
    MiniappRequestType2["DASHBOARD_CONTENT_UPDATE"] = "miniapp_dashboard_content_update";
    MiniappRequestType2["PHOTO"] = "miniapp_photo";
    MiniappRequestType2["VIDEO_RECORDING_START"] = "miniapp_video_recording_start";
    MiniappRequestType2["VIDEO_RECORDING_STOP"] = "miniapp_video_recording_stop";
    MiniappRequestType2["STREAM_START"] = "miniapp_stream_start";
    MiniappRequestType2["STREAM_STOP"] = "miniapp_stream_stop";
    MiniappRequestType2["MANAGED_STREAM_START"] = "miniapp_managed_stream_start";
    MiniappRequestType2["MANAGED_STREAM_STOP"] = "miniapp_managed_stream_stop";
    MiniappRequestType2["STREAM_PREVIEW_START"] = "miniapp_stream_preview_start";
    MiniappRequestType2["STREAM_PREVIEW_STOP"] = "miniapp_stream_preview_stop";
    MiniappRequestType2["REQUEST_WIFI_SETUP"] = "miniapp_request_wifi_setup";
    MiniappRequestType2["PHONE_IS_WIFI_ENABLED"] = "miniapp_phone_is_wifi_enabled";
    MiniappRequestType2["PHONE_REQUEST_WIFI_ENABLE"] = "miniapp_phone_request_wifi_enable";
    MiniappRequestType2["MINIAPPS_LIST"] = "miniapp_apps_list";
    MiniappRequestType2["MINIAPPS_START"] = "miniapp_apps_start";
    MiniappRequestType2["MINIAPPS_STOP"] = "miniapp_apps_stop";
    MiniappRequestType2["ACTION_INVOKE"] = "miniapp_action_invoke";
    MiniappRequestType2["ACTION_RESULT"] = "miniapp_action_result";
    MiniappRequestType2["MEETING_GET_IDENTITY"] = "miniapp_meeting_get_identity";
    MiniappRequestType2["MEETING_GET_CONFIGURATION"] = "miniapp_meeting_get_configuration";
    MiniappRequestType2["MEETING_CREATE"] = "miniapp_meeting_create";
    MiniappRequestType2["MEETING_RETIRE"] = "miniapp_meeting_retire";
    MiniappRequestType2["MEETING_JOIN"] = "miniapp_meeting_join";
    MiniappRequestType2["MEETING_LEAVE"] = "miniapp_meeting_leave";
    MiniappRequestType2["MEETING_END"] = "miniapp_meeting_end";
    MiniappRequestType2["MEETING_ADMIT"] = "miniapp_meeting_admit";
    MiniappRequestType2["MEETING_SET_MUTED"] = "miniapp_meeting_set_muted";
    MiniappRequestType2["MEETING_SET_VIDEO_ENABLED"] = "miniapp_meeting_set_video_enabled";
    MiniappRequestType2["MEETING_UPDATE_VIDEO_SOURCE"] = "miniapp_meeting_update_video_source";
    MiniappRequestType2["MEETING_GET_STATE"] = "miniapp_meeting_get_state";
    MiniappRequestType2["MEETING_PAUSE_VIDEO_PUBLISHER"] = "miniapp_meeting_pause_video_publisher";
    MiniappRequestType2["MEETING_RESUME_VIDEO_PUBLISHER"] = "miniapp_meeting_resume_video_publisher";
    MiniappRequestType2["MEETING_SHOW_CARD"] = "miniapp_meeting_show_card";
    MiniappRequestType2["MEETING_SHOW_IMAGE"] = "miniapp_meeting_show_image";
    MiniappRequestType2["MEETING_SHOW_LIVE"] = "miniapp_meeting_show_live";
    MiniappRequestType2["MEETING_CAPTURE_STILL"] = "miniapp_meeting_capture_still";
  })(MiniappRequestType || (MiniappRequestType = {}));
  var MiniappResponseType;
  (function(MiniappResponseType2) {
    MiniappResponseType2["CONNECT_ACK"] = "miniapp_connect_ack";
    MiniappResponseType2["EVENT"] = "miniapp_event";
    MiniappResponseType2["REQUEST_RESULT"] = "miniapp_request_result";
    MiniappResponseType2["CAPABILITIES_UPDATE"] = "miniapp_capabilities_update";
    MiniappResponseType2["VISIBILITY_CHANGE"] = "miniapp_visibility_change";
    MiniappResponseType2["COLOR_SCHEME_CHANGE"] = "miniapp_color_scheme_change";
    MiniappResponseType2["SPEAKER_STATE"] = "miniapp_speaker_state";
    MiniappResponseType2["PERMISSIONS_UPDATE"] = "miniapp_permissions_update";
    MiniappResponseType2["AUTH_UPDATE"] = "miniapp_auth_update";
    MiniappResponseType2["PONG"] = "miniapp_pong";
    MiniappResponseType2["ACTION_CALL"] = "miniapp_action_call";
    MiniappResponseType2["MEETING_STATE"] = "miniapp_meeting_state";
    MiniappResponseType2["MEETING_VIDEO_PUBLISHER"] = "miniapp_meeting_video_publisher";
    MiniappResponseType2["MEETING_STILL"] = "miniapp_meeting_still";
    MiniappResponseType2["STREAM_PREVIEW_STATUS"] = "miniapp_stream_preview_status";
    MiniappResponseType2["WILL_DISCONNECT"] = "miniapp_will_disconnect";
    MiniappResponseType2["ERROR"] = "miniapp_error";
  })(MiniappResponseType || (MiniappResponseType = {}));
  var MiniappStreamType;
  (function(MiniappStreamType2) {
    MiniappStreamType2["BUTTON_PRESS"] = "button_press";
    MiniappStreamType2["TOUCH_EVENT"] = "touch_event";
    MiniappStreamType2["HEAD_POSITION"] = "head_position";
    MiniappStreamType2["ACCEL_DATA"] = "accel_data";
    MiniappStreamType2["GLASSES_BATTERY"] = "glasses_battery";
    MiniappStreamType2["PHONE_BATTERY"] = "phone_battery";
    MiniappStreamType2["GLASSES_CONNECTION"] = "glasses_connection";
    MiniappStreamType2["GLASSES_WIFI"] = "glasses_wifi";
    MiniappStreamType2["TRANSCRIPTION"] = "transcription";
    MiniappStreamType2["TRANSLATION"] = "translation";
    MiniappStreamType2["AUDIO_CHUNK"] = "audio_chunk";
    MiniappStreamType2["VAD"] = "vad";
    MiniappStreamType2["LOCATION_UPDATE"] = "location_update";
    MiniappStreamType2["HEADING_UPDATE"] = "heading_update";
    MiniappStreamType2["NAVIGATION_UPDATE"] = "navigation_update";
    MiniappStreamType2["NAVIGATION_ROUTE"] = "navigation_route";
    MiniappStreamType2["PHONE_NOTIFICATION"] = "phone_notification";
    MiniappStreamType2["PHONE_NOTIFICATION_DISMISSED"] = "phone_notification_dismissed";
    MiniappStreamType2["PHOTO_TAKEN"] = "photo_taken";
    MiniappStreamType2["STREAM_STATUS"] = "stream_status";
  })(MiniappStreamType || (MiniappStreamType = {}));
  var MiniappErrorCode;
  (function(MiniappErrorCode2) {
    MiniappErrorCode2["INVALID_ARGUMENT"] = "INVALID_ARGUMENT";
    MiniappErrorCode2["PERMISSION_NOT_DECLARED"] = "PERMISSION_NOT_DECLARED";
    MiniappErrorCode2["PERMISSION_DENIED"] = "PERMISSION_DENIED";
    MiniappErrorCode2["NOT_IMPLEMENTED"] = "NOT_IMPLEMENTED";
    MiniappErrorCode2["REQUEST_ABORTED"] = "REQUEST_ABORTED";
    MiniappErrorCode2["INTERNAL"] = "INTERNAL";
    MiniappErrorCode2["TTS_TEXT_TOO_LONG"] = "TTS_TEXT_TOO_LONG";
    MiniappErrorCode2["TTS_INVALID_VOICE"] = "TTS_INVALID_VOICE";
    MiniappErrorCode2["TTS_UPSTREAM_ERROR"] = "TTS_UPSTREAM_ERROR";
    MiniappErrorCode2["TTS_LOCAL_UNAVAILABLE"] = "TTS_LOCAL_UNAVAILABLE";
    MiniappErrorCode2["NOT_CONNECTED"] = "NOT_CONNECTED";
    MiniappErrorCode2["MIC_SESSION_REQUIRED"] = "MIC_SESSION_REQUIRED";
    MiniappErrorCode2["MIC_SOURCE_CONFLICT"] = "MIC_SOURCE_CONFLICT";
    MiniappErrorCode2["NOT_PERMITTED"] = "NOT_PERMITTED";
    MiniappErrorCode2["APP_NOT_FOUND"] = "APP_NOT_FOUND";
    MiniappErrorCode2["APP_NOT_COMPATIBLE"] = "APP_NOT_COMPATIBLE";
    MiniappErrorCode2["ACTION_NOT_FOUND"] = "ACTION_NOT_FOUND";
    MiniappErrorCode2["NO_ACTION_HANDLER"] = "NO_ACTION_HANDLER";
    MiniappErrorCode2["WAKE_FAILED"] = "WAKE_FAILED";
    MiniappErrorCode2["ACTION_TIMEOUT"] = "ACTION_TIMEOUT";
    MiniappErrorCode2["PAYLOAD_TOO_LARGE"] = "PAYLOAD_TOO_LARGE";
    MiniappErrorCode2["BLOB_NOT_FOUND"] = "BLOB_NOT_FOUND";
    MiniappErrorCode2["BLOB_QUOTA_EXCEEDED"] = "BLOB_QUOTA_EXCEEDED";
    MiniappErrorCode2["BLOB_TOO_LARGE"] = "BLOB_TOO_LARGE";
    MiniappErrorCode2["BLOB_HANDLE_INVALID"] = "BLOB_HANDLE_INVALID";
    MiniappErrorCode2["BLOB_WRITE_FAILED"] = "BLOB_WRITE_FAILED";
    MiniappErrorCode2["BLOB_DOWNLOAD_FAILED"] = "BLOB_DOWNLOAD_FAILED";
    MiniappErrorCode2["BLOB_IMPORT_FAILED"] = "BLOB_IMPORT_FAILED";
  })(MiniappErrorCode || (MiniappErrorCode = {}));

  // ../vendor/miniapp/dist/transport/dispatch.js
  class DispatchTransport {
    constructor() {
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.open_ = false;
    }
    static isAvailable() {
      return typeof globalThis.__dispatch === "function";
    }
    async open() {
      if (!DispatchTransport.isAvailable()) {
        throw new Error("DispatchTransport: __dispatch is not installed on globalThis");
      }
      const g = globalThis;
      g.__mentraDeliverBridgeRaw = (raw) => {
        if (this.messageHandler)
          this.messageHandler(raw);
      };
      this.open_ = true;
    }
    send(raw) {
      if (!this.open_) {
        throw new Error("DispatchTransport: send() before open()");
      }
      const g = globalThis;
      if (typeof g.__dispatch !== "function") {
        this.open_ = false;
        this.disconnectHandler?.("DispatchTransport: __dispatch disappeared");
        return;
      }
      try {
        g.__dispatch("__bridge", "send", JSON.stringify([raw]));
      } catch (e) {
        this.disconnectHandler?.(`DispatchTransport: __dispatch threw: ${String(e)}`);
      }
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      this.open_ = false;
      const g = globalThis;
      if (g.__mentraDeliverBridgeRaw) {
        delete g.__mentraDeliverBridgeRaw;
      }
    }
    isOpen() {
      return this.open_;
    }
  }

  // ../vendor/miniapp/dist/transport/local-socket.js
  var DEFAULT_URL = "ws://127.0.0.1:8765";

  class LocalSocketTransport {
    constructor(options = {}) {
      this.ws = null;
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.url = options.url ?? DEFAULT_URL;
    }
    async open() {
      if (this.ws && this.ws.readyState === WebSocket.OPEN)
        return;
      if (typeof WebSocket === "undefined") {
        throw new Error("LocalSocketTransport: browser WebSocket global not available");
      }
      await new Promise((resolve, reject) => {
        const ws = new WebSocket(this.url);
        let settled = false;
        const settle = (fn) => {
          if (settled)
            return;
          settled = true;
          fn();
        };
        ws.onopen = () => {
          this.ws = ws;
          settle(() => resolve());
        };
        ws.onerror = (ev) => {
          settle(() => reject(new Error(`LocalSocketTransport: failed to connect to ${this.url}: ${String(ev)}`)));
        };
        ws.onmessage = (ev) => {
          const data = ev.data;
          if (typeof data === "string")
            this.messageHandler?.(data);
        };
        ws.onclose = (ev) => {
          if (this.ws === ws)
            this.ws = null;
          this.disconnectHandler?.(`closed: ${ev.code} ${ev.reason}`);
        };
      });
    }
    send(raw) {
      if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
        throw new Error("LocalSocketTransport: not connected");
      }
      this.ws.send(raw);
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      if (!this.ws)
        return;
      try {
        this.ws.close();
      } catch {}
      this.ws = null;
    }
    isOpen() {
      return !!this.ws && this.ws.readyState === WebSocket.OPEN;
    }
  }

  // ../vendor/miniapp/dist/transport/mock.js
  var LOG_PREFIX = "[mock-transport]";
  function isMockExplicitlyRequested() {
    if (typeof window === "undefined")
      return false;
    try {
      if (typeof window.location !== "undefined" && window.location.search) {
        const params = new URLSearchParams(window.location.search);
        if (params.get("mentra") === "mock")
          return true;
      }
    } catch {}
    try {
      if (typeof localStorage !== "undefined" && localStorage.getItem("MENTRA_MOCK") === "1") {
        return true;
      }
    } catch {}
    return false;
  }

  class MockTransport {
    constructor(options = {}) {
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.open_ = false;
      this.userId = options.userId ?? "mock-user";
      this.authToken = options.authToken ?? "mock-miniapp-token";
      this.packageName = options.packageName ?? null;
      this.silent = options.silent === true;
      this.configuration = { ...options.configuration ?? {} };
    }
    async open() {
      if (this.open_)
        return;
      this.open_ = true;
      this.log("transport opened (no real host; synthetic responses only)");
    }
    send(raw) {
      if (!this.open_) {
        throw new Error("MockTransport: send() before open()");
      }
      const envelope = parseEnvelope(raw);
      if (!envelope) {
        this.log("dropped unparseable envelope:", raw.slice(0, 200));
        return;
      }
      const payload = envelope.payload;
      const type = payload?.type;
      this.log(`recv ${type ?? "<unknown>"}${envelope.requestId ? ` (rid=${envelope.requestId})` : ""}`);
      switch (type) {
        case MiniappRequestType.CONNECT:
          this.deliverConnectAck(payload);
          return;
        case MiniappRequestType.PING:
          return;
        case MiniappRequestType.SUBSCRIBE:
          return;
        default:
          if (envelope.requestId) {
            this.deliverSyntheticResult(envelope.requestId, type ?? "<unknown>", payload);
          }
          return;
      }
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      if (!this.open_)
        return;
      this.open_ = false;
      this.disconnectHandler?.("MockTransport.close()");
    }
    isOpen() {
      return this.open_;
    }
    deliverConnectAck(connectPayload) {
      const incomingPackage = connectPayload.packageName ?? this.packageName ?? "com.mock.app";
      const ackPayload = {
        type: MiniappResponseType.CONNECT_ACK,
        userId: this.userId,
        packageName: incomingPackage,
        capabilities: null,
        visibility: "foreground",
        colorScheme: "light",
        configuration: { ...this.configuration },
        auth: {
          mentraUserId: this.userId,
          oemId: "mock",
          token: this.authToken,
          expiresAt: Date.now() + 60 * 60 * 1000
        }
      };
      const envelope = { payload: ackPayload };
      this.log(`-> CONNECT_ACK userId=${this.userId} pkg=${incomingPackage}`);
      queueMicrotask(() => this.messageHandler?.(serializeEnvelope(envelope)));
    }
    deliverSyntheticResult(requestId, requestType, requestPayload) {
      const data = syntheticDataFor(requestId, requestType, requestPayload);
      const responsePayload = {
        type: MiniappResponseType.REQUEST_RESULT,
        ok: true,
        data
      };
      const envelope = { payload: responsePayload, requestId };
      this.log(`-> REQUEST_RESULT (rid=${requestId}) synthetic ${requestType}`);
      queueMicrotask(() => this.messageHandler?.(serializeEnvelope(envelope)));
    }
    log(...args) {
      if (this.silent)
        return;
      console.log(LOG_PREFIX, ...args);
    }
  }
  function syntheticDataFor(requestId, requestType, requestPayload) {
    switch (requestType) {
      case MiniappRequestType.CAMERA_FOV: {
        const presetFov = requestPayload.preset === "narrow" ? 82 : requestPayload.preset === "wide" ? 118 : requestPayload.preset === "standard" ? 102 : undefined;
        const fov = typeof requestPayload.fov === "number" ? requestPayload.fov : presetFov ?? 102;
        const roi = requestPayload.roiPosition;
        const roiPosition = roi === "bottom" ? "bottom" : roi === "top" ? "top" : "center";
        return {
          requestId,
          fov,
          roiPosition,
          timestamp: Date.now()
        };
      }
      case MiniappRequestType.PHOTO:
        return {
          photoUrl: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkAAIAAAoAAv/lxKUAAAAASUVORK5CYII=",
          requestId: "mock-photo"
        };
      case MiniappRequestType.RGB_LED:
        return { type: "rgb_led_control_response", state: "success", requestId };
      case MiniappRequestType.LOCATION_POLL:
        return { lat: 37.7956, lng: -122.3933, accuracy: 0, timestamp: Date.now() };
      case MiniappRequestType.CALENDAR_LIST_EVENTS:
        return { events: [], truncated: false };
      case MiniappRequestType.STORAGE_GET:
        return { value: null };
      case MiniappRequestType.STORAGE_LIST:
        return { keys: [] };
      case MiniappRequestType.SPEAK:
        return { audioUrl: null, durationMs: 0 };
      case MiniappRequestType.SHARE:
      case MiniappRequestType.OPEN_URL:
      case MiniappRequestType.COPY_CLIPBOARD:
      case MiniappRequestType.DOWNLOAD:
      case MiniappRequestType.REQUEST_WIFI_SETUP:
      case MiniappRequestType.SET_WIFI_ADB_STATE:
        return { ok: true };
      case MiniappRequestType.SCAN_QR:
        return { cancelled: true };
      default:
        return null;
    }
  }

  // ../vendor/miniapp/dist/transport/postmessage.js
  class PostMessageTransport {
    constructor() {
      this.messageHandler = null;
      this.disconnectHandler = null;
      this.open_ = false;
      this.windowListener = null;
    }
    async open() {
      if (this.open_)
        return;
      if (typeof window === "undefined" || !window.ReactNativeWebView) {
        throw new Error("PostMessageTransport: not running inside a React Native WebView");
      }
      this.windowListener = (ev) => {
        const data = ev.data;
        if (typeof data !== "string")
          return;
        this.messageHandler?.(data);
      };
      window.addEventListener("message", this.windowListener);
      if (typeof document !== "undefined") {
        document.addEventListener("message", this.windowListener);
      }
      window.receiveNativeMessage = (raw) => {
        this.messageHandler?.(raw);
      };
      this.open_ = true;
    }
    send(raw) {
      if (typeof window === "undefined" || !window.ReactNativeWebView) {
        throw new Error("PostMessageTransport: not running inside a React Native WebView");
      }
      window.ReactNativeWebView.postMessage(raw);
    }
    onMessage(handler) {
      this.messageHandler = handler;
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
    }
    close() {
      if (!this.open_)
        return;
      this.open_ = false;
      if (this.windowListener) {
        window.removeEventListener("message", this.windowListener);
        if (typeof document !== "undefined") {
          document.removeEventListener("message", this.windowListener);
        }
        this.windowListener = null;
      }
      if (typeof window !== "undefined" && window.receiveNativeMessage) {
        window.receiveNativeMessage = undefined;
      }
      this.disconnectHandler?.("closed");
    }
    isOpen() {
      return this.open_;
    }
  }

  // ../vendor/miniapp/dist/transport/auto.js
  var LOCAL_SOCKET_OPEN_TIMEOUT_MS = 500;
  function createTransport(options = {}) {
    if (options.transport)
      return options.transport;
    if (DispatchTransport.isAvailable()) {
      return new DispatchTransport;
    }
    if (typeof window !== "undefined" && window.ReactNativeWebView) {
      return new PostMessageTransport;
    }
    if (isMockExplicitlyRequested()) {
      return new MockTransport;
    }
    if (typeof WebSocket !== "undefined") {
      const localSocketOptions = {};
      if (options.localSocketUrl)
        localSocketOptions.url = options.localSocketUrl;
      return new LocalSocketWithMockFallback(localSocketOptions);
    }
    return new MockTransport;
  }

  class LocalSocketWithMockFallback {
    constructor(options) {
      this.options = options;
      this.active = null;
      this.messageHandler = null;
      this.disconnectHandler = null;
    }
    async open() {
      const local = new LocalSocketTransport(this.options);
      let timedOut = false;
      const timeout = new Promise((_, reject) => {
        setTimeout(() => {
          timedOut = true;
          reject(new Error("LocalSocketTransport open timed out"));
        }, LOCAL_SOCKET_OPEN_TIMEOUT_MS);
      });
      try {
        await Promise.race([local.open(), timeout]);
        this.active = local;
      } catch {
        try {
          local.close();
        } catch {}
        const mock = new MockTransport;
        await mock.open();
        this.active = mock;
        console.log(timedOut ? "[mentra-miniapp] No phone WebSocket reachable; using MockTransport so the page can render." : "[mentra-miniapp] LocalSocketTransport failed; using MockTransport.");
      }
      if (this.messageHandler)
        this.active.onMessage(this.messageHandler);
      if (this.disconnectHandler)
        this.active.onDisconnect(this.disconnectHandler);
    }
    send(raw) {
      if (!this.active)
        throw new Error("LocalSocketWithMockFallback: send() before open()");
      this.active.send(raw);
    }
    onMessage(handler) {
      this.messageHandler = handler;
      this.active?.onMessage(handler);
    }
    onDisconnect(handler) {
      this.disconnectHandler = handler;
      this.active?.onDisconnect(handler);
    }
    close() {
      this.active?.close();
    }
    isOpen() {
      return this.active?.isOpen() === true;
    }
  }

  // ../vendor/cloud-protocol/src/photo-compression.ts
  var photoCompressionValues = ["none", "low", "medium", "high"];
  function parsePhotoCompression(value = "none") {
    if (typeof value === "string" && photoCompressionValues.includes(value)) {
      return value;
    }
    throw new TypeError(`Invalid photo compression ${JSON.stringify(value)}. Expected none, low, medium, or high.`);
  }

  // ../vendor/miniapp/dist/modules/camera.js
  class CameraModule {
    constructor(session) {
      this.session = session;
    }
    get hasPermission() {
      return this.session._hasManifestPermission("CAMERA");
    }
    async setFov(request) {
      return this.session.sendRequest({
        type: MiniappRequestType.CAMERA_FOV,
        ...request
      });
    }
    async takePhoto(options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.PHOTO,
        size: options.size ?? "medium",
        mode: options.mode ?? "photo",
        ...options.transferMethod !== undefined ? { transferMethod: options.transferMethod } : {},
        compress: parsePhotoCompression(options.compress),
        sound: options.sound ?? true,
        saveToGallery: options.saveToGallery ?? false,
        exposureTimeNs: options.exposureTimeNs,
        iso: options.iso,
        aeExposureDivisor: options.aeExposureDivisor,
        isoCap: options.isoCap,
        noiseReduction: options.noiseReduction,
        edgeEnhancement: options.edgeEnhancement,
        zsl: options.zsl,
        mfnr: options.mfnr,
        ispDigitalGain: options.ispDigitalGain,
        ispAnalogGain: options.ispAnalogGain
      }, options.timeoutMs != null ? { timeoutMs: options.timeoutMs } : undefined);
    }
    async warmUp(options = {}) {
      await this.session.sendRequest({
        type: MiniappRequestType.CAMERA_WARM_UP,
        size: options.size ?? "medium",
        mode: options.mode ?? "photo",
        exposureTimeNs: options.exposureTimeNs,
        durationMs: options.durationMs ?? 15000,
        zsl: options.zsl,
        mfnr: options.mfnr
      });
    }
    async startVideoRecording(options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.VIDEO_RECORDING_START,
        width: options.width,
        height: options.height,
        fps: options.fps,
        sound: options.sound ?? true,
        save: options.save ?? false
      });
    }
    async stopVideoRecording(recordingId, options = {}) {
      await this.session.sendRequest({
        type: MiniappRequestType.VIDEO_RECORDING_STOP,
        recordingId,
        uploadUrl: options.uploadUrl,
        uploadAuthToken: options.uploadAuthToken
      });
    }
  }

  // ../vendor/miniapp/dist/modules/auth.js
  var DEFAULT_MIN_TTL_MS = 30000;

  class AuthModule {
    constructor(session) {
      this.session = session;
    }
    get current() {
      return this.session._getAuth();
    }
    get mentraUserId() {
      return this.current?.mentraUserId ?? null;
    }
    get oemId() {
      return this.current?.oemId ?? null;
    }
    async getToken(options = {}) {
      const auth = await this.session._waitForAuth(options.minTtlMs ?? DEFAULT_MIN_TTL_MS);
      return auth.token;
    }
    async getAuthHeader(options = {}) {
      return `Bearer ${await this.getToken(options)}`;
    }
    async fetch(input, init = {}) {
      const { minTtlMs, ...requestInit } = init;
      const token = await this.getToken({ minTtlMs });
      const headers = mergeHeaders(requestInit.headers, { Authorization: `Bearer ${token}` });
      return fetch(input, { ...requestInit, headers });
    }
    onUpdate(handler) {
      return this.session.on("auth", handler);
    }
  }
  function mergeHeaders(base, next) {
    const headers = {};
    if (Array.isArray(base)) {
      for (const [key, value] of base) {
        headers[key] = value;
      }
    } else if (typeof Headers !== "undefined" && base instanceof Headers) {
      base.forEach((value, key) => {
        headers[key] = value;
      });
    } else if (base && typeof base === "object") {
      for (const [key, value] of Object.entries(base)) {
        if (typeof value === "string")
          headers[key] = value;
      }
    }
    return { ...headers, ...next };
  }

  // ../vendor/miniapp/dist/modules/cloud.js
  var CLOUD_STATUS_STREAM = "_cloud_status";
  var DEFAULT_STATUS = {
    status: "disconnected",
    audioTransport: "none"
  };
  function normalizeCloudStatus(data) {
    if (!data || typeof data !== "object")
      return null;
    const raw = data;
    const status = raw.status;
    const audioTransport = raw.audioTransport;
    if (status !== "connected" && status !== "connecting" && status !== "reconnecting" && status !== "disconnected") {
      return null;
    }
    if (audioTransport !== "udp" && audioTransport !== "ws" && audioTransport !== "offline" && audioTransport !== "none") {
      return null;
    }
    return { status, audioTransport };
  }

  class CloudModule {
    constructor(session) {
      this.session = session;
      this.emitter = new import__.default;
      this.current = { ...DEFAULT_STATUS };
      this.session._subscribe(CLOUD_STATUS_STREAM, (data) => {
        const next = normalizeCloudStatus(data);
        if (!next)
          return;
        if (next.status === this.current.status && next.audioTransport === this.current.audioTransport)
          return;
        this.current = next;
        this.emitter.emit("status", { ...this.current });
      });
    }
    get status() {
      return { ...this.current };
    }
    get connected() {
      return this.current.status === "connected";
    }
    isConnected() {
      return this.connected;
    }
    onStatusChanged(handler) {
      handler({ ...this.current });
      this.emitter.on("status", handler);
      return () => {
        this.emitter.off("status", handler);
      };
    }
  }

  // ../vendor/miniapp/dist/modules/configuration.js
  class MiniappConfigurationError extends Error {
    constructor(key) {
      super(`Required miniapp configuration is missing: ${key}`);
      this.key = key;
      this.name = "MiniappConfigurationError";
    }
  }

  class ConfigurationModule {
    constructor(session) {
      this.session = session;
    }
    async get(key) {
      await this.session.waitForReady();
      const configuration = this.session._getConfiguration();
      return Object.prototype.hasOwnProperty.call(configuration, key) ? configuration[key] : undefined;
    }
    async require(key) {
      const value = await this.get(key);
      if (value === undefined)
        throw new MiniappConfigurationError(key);
      return value;
    }
    async getAll() {
      await this.session.waitForReady();
      return Object.assign(Object.create(null), this.session._getConfiguration());
    }
  }

  // ../vendor/miniapp/dist/modules/dashboard.js
  class DashboardAPI {
    constructor(session) {
      this.session = session;
      this.warned = false;
    }
    setContent(mode, content) {
      if (!this.warned) {
        console.warn("[@mentra/miniapp] dashboard.setContent() is deferred in v1.");
        this.warned = true;
      }
      this.session.sendOneShot({
        type: MiniappRequestType.DASHBOARD_CONTENT_UPDATE,
        mode,
        content
      });
    }
  }

  // ../vendor/miniapp/dist/modules/display.js
  class DisplayManager {
    constructor(session) {
      this.session = session;
    }
    render(elements, options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.RENDER,
        view: options.view ?? "main",
        elements,
        durationMs: options.durationMs,
        includeTextLayout: options.includeTextLayout,
        ifDisplayToken: options.ifDisplayToken
      }).catch((err) => ({
        status: "blocked",
        reason: typeof err === "object" && err !== null && "message" in err ? String(err.message) : String(err)
      }));
    }
  }

  // ../vendor/miniapp/dist/modules/events.js
  class EventManager {
    constructor(session) {
      this.session = session;
      this.emitter = new import__.default;
      this.refCounts = new Map;
      this.forceLocalRefCounts = new Map;
    }
    subscribe(stream, handler, options = {}) {
      const isInternal = stream.startsWith("_");
      const forceLocal = options.forceLocal === true && stream.startsWith(`${MiniappStreamType.TRANSCRIPTION}:`);
      const listener = (data, route) => {
        if (stream.startsWith(`${MiniappStreamType.TRANSCRIPTION}:`)) {
          if (forceLocal ? route !== "forceLocal" && route !== "all" : route === "forceLocal")
            return;
        }
        handler(data);
      };
      this.emitter.on(stream, listener);
      if (!isInternal) {
        const before = this.refCounts.get(stream) ?? 0;
        this.refCounts.set(stream, before + 1);
        const forceLocalBefore = this.forceLocalRefCounts.get(stream) ?? 0;
        const defaultBefore = before - forceLocalBefore;
        if (forceLocal)
          this.forceLocalRefCounts.set(stream, forceLocalBefore + 1);
        if (before === 0 || forceLocal && forceLocalBefore === 0 || !forceLocal && defaultBefore === 0) {
          this.sendSubscriptionUpdate();
        }
      }
      return () => {
        this.emitter.off(stream, listener);
        if (isInternal)
          return;
        const current = this.refCounts.get(stream) ?? 0;
        const forceLocalCurrent = this.forceLocalRefCounts.get(stream) ?? 0;
        let subscriptionChanged = current <= 1;
        if (current <= 1) {
          this.refCounts.delete(stream);
        } else {
          this.refCounts.set(stream, current - 1);
        }
        if (forceLocal) {
          if (forceLocalCurrent <= 1) {
            this.forceLocalRefCounts.delete(stream);
            subscriptionChanged = true;
          } else {
            this.forceLocalRefCounts.set(stream, forceLocalCurrent - 1);
          }
        } else if (current - forceLocalCurrent <= 1) {
          subscriptionChanged = true;
        }
        if (subscriptionChanged)
          this.sendSubscriptionUpdate();
      };
    }
    unsubscribeAll() {
      this.emitter.removeAllListeners();
      this.refCounts.clear();
      this.forceLocalRefCounts.clear();
      this.sendSubscriptionUpdate();
    }
    _forwardEvent(stream, data, transcriptionRoute) {
      this.emitter.emit(stream, data, transcriptionRoute);
      if (stream.startsWith("transcription:") && stream !== "transcription:auto") {
        this.emitter.emit("transcription:auto", data, transcriptionRoute);
      } else if (stream.startsWith("translation:")) {
        const parts = stream.split(":");
        const patterns = new Set(["translation:auto"]);
        if (parts.length === 3) {
          const [, source, target] = parts;
          patterns.add("translation:*:*");
          patterns.add(`translation:*:${target}`);
          patterns.add(`translation:${source}:*`);
        }
        patterns.delete(stream);
        for (const pattern of patterns) {
          this.emitter.emit(pattern, data);
        }
      }
    }
    sendSubscriptionUpdate() {
      const subscriptions = Array.from(this.refCounts.keys()).map((stream) => {
        if (stream === MiniappStreamType.LOCATION_UPDATE)
          return { stream: "location_stream", rate: "realtime" };
        const forceLocalRefs = this.forceLocalRefCounts.get(stream) ?? 0;
        if (forceLocalRefs === 0)
          return stream;
        const totalRefs = this.refCounts.get(stream) ?? 0;
        return {
          stream,
          forceLocal: true,
          ...totalRefs > forceLocalRefs ? { includeCloud: true } : {}
        };
      });
      this.session.sendOneShot({
        type: MiniappRequestType.SUBSCRIBE,
        subscriptions
      });
    }
  }

  // ../vendor/miniapp/dist/modules/glasses.js
  class GlassesModule {
    constructor(session) {
      this.session = session;
    }
    onBattery(handler) {
      return this.session._subscribe(MiniappStreamType.GLASSES_BATTERY, handler);
    }
    onConnection(handler) {
      return this.session._subscribe(MiniappStreamType.GLASSES_CONNECTION, handler);
    }
    onWifi(handler) {
      return this.session._subscribe(MiniappStreamType.GLASSES_WIFI, handler);
    }
    async requestWifiSetup(reason) {
      await this.session.sendRequest({
        type: MiniappRequestType.REQUEST_WIFI_SETUP,
        reason
      });
    }
    async setWifiAdbState(enabled) {
      await this.session.sendRequest({
        type: MiniappRequestType.SET_WIFI_ADB_STATE,
        enabled
      });
    }
  }

  // ../vendor/miniapp/dist/modules/heading.js
  class HeadingModule {
    constructor(session) {
      this.session = session;
    }
    get hasPermission() {
      return this.session._hasManifestPermission("LOCATION");
    }
    onUpdate(handler) {
      return this.session._subscribe(MiniappStreamType.HEADING_UPDATE, handler);
    }
  }

  // ../vendor/miniapp/dist/modules/imu.js
  class ImuModule {
    constructor(session) {
      this.session = session;
    }
    onHeadPosition(handler) {
      return this.session._subscribe(MiniappStreamType.HEAD_POSITION, handler);
    }
    onAccel(handler) {
      return this.session._subscribe(MiniappStreamType.ACCEL_DATA, handler);
    }
    setEnabled(enabled) {
      return this.session.sendRequest({
        type: MiniappRequestType.IMU_SET_ENABLED,
        enabled
      });
    }
  }

  // ../vendor/miniapp/dist/modules/input.js
  class InputModule {
    constructor(session) {
      this.session = session;
    }
    onButtonPress(handler) {
      return this.session._subscribe(MiniappStreamType.BUTTON_PRESS, handler);
    }
    onTouch(gestureOrHandler, maybeHandler) {
      if (typeof gestureOrHandler === "function") {
        return this.session._subscribe(MiniappStreamType.TOUCH_EVENT, gestureOrHandler);
      }
      const handler = maybeHandler;
      const gestures = Array.isArray(gestureOrHandler) ? gestureOrHandler : [gestureOrHandler];
      if (gestures.length === 0)
        return () => {};
      const unsubs = [];
      for (const g of gestures) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TOUCH_EVENT}:${g}`, handler));
      }
      return () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
    }
  }

  // ../vendor/miniapp/dist/modules/led.js
  class LedModule {
    constructor(session) {
      this.session = session;
    }
    async turnOn(options = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.RGB_LED,
        action: "on",
        color: options.color ?? "red",
        ontime: options.ontime ?? 1000,
        offtime: options.offtime ?? 0,
        count: options.count ?? 1
      });
    }
    async turnOff() {
      return this.session.sendRequest({
        type: MiniappRequestType.RGB_LED,
        action: "off"
      });
    }
    async blink(color, ontime, offtime, count) {
      return this.turnOn({ color, ontime, offtime, count });
    }
    async solid(color, duration) {
      return this.turnOn({ color, ontime: duration, offtime: 0, count: 1 });
    }
  }

  // ../vendor/miniapp/dist/modules/location.js
  class LocationModule {
    constructor(session) {
      this.session = session;
    }
    get hasPermission() {
      return this.session._hasManifestPermission("LOCATION");
    }
    onUpdate(handler) {
      return this.session._subscribe(MiniappStreamType.LOCATION_UPDATE, handler);
    }
    getOnce() {
      return this.session.sendRequest({
        type: MiniappRequestType.LOCATION_POLL
      });
    }
  }

  // ../vendor/miniapp/dist/modules/mic.js
  class MicModule {
    constructor(session) {
      this.session = session;
      this.unsubs = new Set;
    }
    onVoiceActivity(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.VAD, handler));
    }
    onAudioChunk(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.AUDIO_CHUNK, handler));
    }
    setVoiceActivityDetectionEnabled(enabled) {
      return this.session.sendRequest({
        type: MiniappRequestType.MIC_SET_VAD_ENABLED,
        enabled
      });
    }
    setLoudnessGateEnabled(enabled) {
      return this.session.sendRequest({
        type: MiniappRequestType.MIC_SET_LOUDNESS_GATE_ENABLED,
        enabled
      });
    }
    async acquire(options) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.MIC_ACQUIRE,
        source: options.source,
        useCase: options.useCase
      });
      if (typeof result?.sessionId !== "number") {
        throw new Error("This version of the Mentra App does not support microphone sessions");
      }
      const { sessionId } = result;
      let released = false;
      return {
        sessionId,
        release: async () => {
          if (released)
            return;
          released = true;
          await this.session.sendRequest({
            type: MiniappRequestType.MIC_RELEASE,
            sessionId
          });
        }
      };
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
    get hasPermission() {
      return this.session._hasManifestPermission("MICROPHONE");
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
  }

  // ../vendor/miniapp/dist/modules/pivots/geometry.js
  var TURN_THRESHOLD_DEG = 15;
  var SAME_DIR_MERGE_M = 25;
  var RDP_EPSILON_M = 5;
  var MIN_BEND_PER_POINT_DEG = 10;
  var STRAIGHT_SEGMENT_BREAK_M = 1;
  var INTERSECTION_CLUSTER_M = 30;
  function haversineMeters(a, b) {
    const R = 6371000;
    const toRad = (d) => d * Math.PI / 180;
    const dLat = toRad(b.lat - a.lat);
    const dLng = toRad(b.lng - a.lng);
    const lat1 = toRad(a.lat);
    const lat2 = toRad(b.lat);
    const x = Math.sin(dLat / 2) ** 2 + Math.sin(dLng / 2) ** 2 * Math.cos(lat1) * Math.cos(lat2);
    return 2 * R * Math.asin(Math.sqrt(x));
  }
  function bearingDeg(a, b) {
    const toRad = (d) => d * Math.PI / 180;
    const toDeg = (r) => r * 180 / Math.PI;
    const lat1 = toRad(a.lat);
    const lat2 = toRad(b.lat);
    const dLng = toRad(b.lng - a.lng);
    const y = Math.sin(dLng) * Math.cos(lat2);
    const x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLng);
    return (toDeg(Math.atan2(y, x)) + 360) % 360;
  }
  function signedAngleDiff(target, actual) {
    return (target - actual + 540) % 360 - 180;
  }
  function rdpSimplify(points, epsilonMeters) {
    if (points.length < 3)
      return points.map((_, i) => i);
    const keep = new Array(points.length).fill(false);
    keep[0] = true;
    keep[points.length - 1] = true;
    const stack = [[0, points.length - 1]];
    while (stack.length) {
      const [lo, hi] = stack.pop();
      let maxDist = 0;
      let maxIdx = -1;
      for (let i = lo + 1;i < hi; i++) {
        const d = perpDistMeters(points[i], points[lo], points[hi]);
        if (d > maxDist) {
          maxDist = d;
          maxIdx = i;
        }
      }
      if (maxIdx !== -1 && maxDist > epsilonMeters) {
        keep[maxIdx] = true;
        stack.push([lo, maxIdx], [maxIdx, hi]);
      }
    }
    const out = [];
    for (let i = 0;i < keep.length; i++)
      if (keep[i])
        out.push(i);
    return out;
  }
  function perpDistMeters(p, a, b) {
    const mPerDegLat = 111320;
    const mPerDegLng = 111320 * Math.cos(a.lat * Math.PI / 180);
    const bx = (b.lng - a.lng) * mPerDegLng;
    const by = (b.lat - a.lat) * mPerDegLat;
    const px = (p.lng - a.lng) * mPerDegLng;
    const py = (p.lat - a.lat) * mPerDegLat;
    const dx = bx;
    const dy = by;
    const len = Math.sqrt(dx * dx + dy * dy);
    if (len === 0)
      return Math.sqrt(px * px + py * py);
    return Math.abs(dx * -py - -px * dy) / len;
  }
  function extractPivots(rawPoints) {
    if (rawPoints.length < 3)
      return [];
    const keptIdx = rdpSimplify(rawPoints, RDP_EPSILON_M);
    const simplified = keptIdx.map((i) => rawPoints[i]);
    if (simplified.length < 3)
      return [];
    const deltas = [];
    for (let i = 1;i < simplified.length - 1; i++) {
      const inBearing = bearingDeg(simplified[i - 1], simplified[i]);
      const outBearing = bearingDeg(simplified[i], simplified[i + 1]);
      deltas.push(signedAngleDiff(outBearing, inBearing));
    }
    const candidates = [];
    let runStart = -1;
    let runSum = 0;
    let runSign = 0;
    const flushRun = (endExclusive) => {
      if (runStart === -1)
        return;
      if (Math.abs(runSum) >= TURN_THRESHOLD_DEG) {
        let bestIdx = runStart;
        let bestAbs = 0;
        for (let k = runStart;k < endExclusive; k++) {
          const a = Math.abs(deltas[k]);
          if (a > bestAbs) {
            bestAbs = a;
            bestIdx = k;
          }
        }
        const simplifiedIdx = bestIdx + 1;
        candidates.push({
          lat: simplified[simplifiedIdx].lat,
          lng: simplified[simplifiedIdx].lng,
          direction: runSum > 0 ? "right" : "left",
          simplifiedRouteIndex: simplifiedIdx,
          rawRouteIndex: keptIdx[simplifiedIdx],
          headingDelta: runSum
        });
      }
      runStart = -1;
      runSum = 0;
      runSign = 0;
    };
    let metersSinceLastBend = 0;
    for (let k = 0;k < deltas.length; k++) {
      const d = deltas[k];
      const sign = d > 0 ? 1 : d < 0 ? -1 : 0;
      const segLen = haversineMeters(simplified[k + 1], simplified[k + 2]);
      if (sign === 0 || Math.abs(d) < MIN_BEND_PER_POINT_DEG) {
        if (runStart !== -1) {
          if (sign === runSign || sign === 0)
            runSum += d;
          metersSinceLastBend += segLen;
          if (metersSinceLastBend >= STRAIGHT_SEGMENT_BREAK_M) {
            flushRun(k + 1);
          }
        }
        continue;
      }
      if (runStart === -1) {
        runStart = k;
        runSum = d;
        runSign = sign;
        metersSinceLastBend = segLen;
      } else if (sign === runSign) {
        if (metersSinceLastBend >= STRAIGHT_SEGMENT_BREAK_M) {
          flushRun(k);
          runStart = k;
          runSum = d;
          runSign = sign;
        } else {
          runSum += d;
        }
        metersSinceLastBend = segLen;
      } else {
        flushRun(k);
        runStart = k;
        runSum = d;
        runSign = sign;
        metersSinceLastBend = segLen;
      }
    }
    flushRun(deltas.length);
    const merged = [];
    for (const p of candidates) {
      const last = merged[merged.length - 1];
      if (last && last.direction === p.direction && haversineMeters({ lat: last.lat, lng: last.lng }, { lat: p.lat, lng: p.lng }) < SAME_DIR_MERGE_M) {
        if (Math.abs(p.headingDelta) > Math.abs(last.headingDelta)) {
          merged[merged.length - 1] = p;
        }
        continue;
      }
      merged.push(p);
    }
    const clustered = [];
    for (const p of merged) {
      const last = clustered[clustered.length - 1];
      if (last && haversineMeters({ lat: last.lat, lng: last.lng }, { lat: p.lat, lng: p.lng }) < INTERSECTION_CLUSTER_M) {
        const netDelta = last.headingDelta + p.headingDelta;
        const anchor = Math.abs(p.headingDelta) > Math.abs(last.headingDelta) ? p : last;
        clustered[clustered.length - 1] = {
          ...anchor,
          direction: netDelta > 0 ? "right" : "left",
          headingDelta: netDelta
        };
        continue;
      }
      clustered.push(p);
    }
    return clustered.filter((p) => Math.abs(p.headingDelta) >= TURN_THRESHOLD_DEG);
  }
  function cumulativeDistances(points) {
    const out = new Array(points.length);
    out[0] = 0;
    for (let i = 1;i < points.length; i++) {
      out[i] = out[i - 1] + haversineMeters(points[i - 1], points[i]);
    }
    return out;
  }

  // ../vendor/miniapp/dist/modules/pivots/instructions.js
  var DIRECTION_WORDS = new Set(["right", "left", "the right", "the left", "north", "south", "east", "west"]);
  var MANEUVER_VERBS = /\b(turn|slight|sharp|continue|head|merge|exit|uturn|u-turn|then|keep)\b/i;
  function roadNameFromInstruction(instruction) {
    if (!instruction)
      return null;
    const firstLine = instruction.split(`
`)[0] ?? "";
    const m = firstLine.match(/\bonto\s+(.+)$/i);
    let raw = (m ? m[1] : "").trim();
    if (!raw)
      return null;
    if (raw.includes(","))
      return null;
    raw = raw.split(/\s+(?:toward|towards|to|and|then|for)\b/i)[0]?.trim() ?? "";
    raw = raw.replace(/\s+#.*$/, "").trim();
    if (!raw)
      return null;
    if (DIRECTION_WORDS.has(raw.toLowerCase()))
      return null;
    if (MANEUVER_VERBS.test(raw))
      return null;
    return raw;
  }
  var ROAD_SUFFIXES = /\b(st|street|ave|avenue|blvd|boulevard|rd|road|dr|drive|ln|lane|way|ct|court|pl|place|ter|terrace|hwy|highway)\b\.?/g;
  function normalizeRoad(road) {
    return road.toLowerCase().replace(ROAD_SUFFIXES, "").replace(/[^a-z0-9 ]/g, "").replace(/\s+/g, " ").trim();
  }
  function sameRoad(a, b) {
    return normalizeRoad(a) === normalizeRoad(b);
  }
  function turnDirection(maneuver) {
    if (!maneuver)
      return null;
    const m = maneuver.toUpperCase();
    if (m.includes("LEFT"))
      return "left";
    if (m.includes("RIGHT"))
      return "right";
    return null;
  }
  var PROBE_METERS = 22;
  function signedBendAt(points, junction) {
    if (points.length < 3)
      return null;
    let mid = 0;
    let bestDist = Infinity;
    for (let i = 0;i < points.length; i++) {
      const d = haversineMeters(points[i], junction);
      if (d < bestDist) {
        bestDist = d;
        mid = i;
      }
    }
    let before = mid;
    while (before > 0 && haversineMeters(points[before], points[mid]) < PROBE_METERS)
      before--;
    let after = mid;
    while (after < points.length - 1 && haversineMeters(points[after], points[mid]) < PROBE_METERS)
      after++;
    if (before === mid || after === mid)
      return null;
    const incoming = bearingDeg(points[before], points[mid]);
    const outgoing = bearingDeg(points[mid], points[after]);
    return signedAngleDiff(outgoing, incoming);
  }
  var MIN_TURN_ANGLE_DEG = 30;
  function extractPivotsFromComputedSteps(steps, polyline) {
    if (!steps || steps.length < 2)
      return [];
    const initial = steps.map((s, i) => ({
      stepIdx: i,
      name: s.road ?? roadNameFromInstruction(s.instruction)
    }));
    let annotated = initial;
    for (let pass = 0;pass < 4; pass++) {
      const collapsed = [];
      for (let i = 0;i < annotated.length; i++) {
        const prev = collapsed[collapsed.length - 1];
        const here = annotated[i];
        const next = annotated[i + 1];
        if (prev?.name && next?.name && here.name && !sameRoad(prev.name, here.name) && sameRoad(prev.name, next.name)) {
          continue;
        }
        collapsed.push(here);
      }
      if (collapsed.length === annotated.length)
        break;
      annotated = collapsed;
    }
    const out = [];
    for (let i = 0;i < annotated.length - 1; i++) {
      const here = annotated[i];
      const nextAnn = annotated[i + 1];
      const s = steps[here.stepIdx];
      const next = steps[nextAnn.stepIdx];
      const fromRoad = here.name;
      const toRoad = nextAnn.name;
      if (!fromRoad)
        continue;
      if (toRoad && sameRoad(fromRoad, toRoad))
        continue;
      if (!Number.isFinite(s.endLat) || !Number.isFinite(s.endLng))
        continue;
      const junction = { lat: s.endLat, lng: s.endLng };
      const signedBend = signedBendAt(polyline, junction);
      if (signedBend != null && Math.abs(signedBend) < MIN_TURN_ANGLE_DEG)
        continue;
      const geomDir = signedBend == null ? null : signedBend > 0 ? "right" : "left";
      const direction = geomDir ?? turnDirection(next.maneuver);
      out.push({
        lat: s.endLat,
        lng: s.endLng,
        fromRoad,
        toRoad,
        direction,
        maneuver: next.maneuver ?? (direction === "left" ? "TURN_LEFT" : "TURN_RIGHT")
      });
    }
    return out;
  }

  // ../vendor/miniapp/dist/modules/pivots/engine.js
  var RADIUS_DEFAULTS_M = {
    walking: 7,
    cycling: 15,
    driving: 40,
    two_wheeler: 25
  };
  var APPROACH_DEFAULTS_M = {
    walking: 100,
    cycling: 300,
    driving: 800,
    two_wheeler: 500
  };
  var NON_TURN_MANEUVERS = new Set(["STRAIGHT", "NAME_CHANGE", "DEPART", "ARRIVE"]);
  var STEP_MATCH_MAX_INDEX_DELTA = 8;
  var ON_ROUTE_PERP_TOLERANCE_M = 50;

  class PivotEngine {
    constructor(mode, opts) {
      this.pivots = [];
      this.states = [];
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = [];
      this.cumulative = [];
      this.roadNameResolver = null;
      this.routeGeneration = 0;
      this.subscribers = new Set;
      this.opts = resolveOptions(mode, opts);
    }
    updateOptions(mode, opts) {
      this.opts = resolveOptions(mode, opts);
      for (const p of this.pivots) {
        p.radiusMeters = this.opts.radiusMeters;
      }
    }
    setRoadNameResolver(resolver) {
      this.roadNameResolver = resolver;
    }
    reset() {
      if (this.activePivotIndex !== null) {
        const active = this.pivots[this.activePivotIndex];
        if (active)
          this.emit({ kind: "exited", pivot: active });
      }
      this.pivots = [];
      this.states = [];
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = [];
      this.cumulative = [];
    }
    setRouteFromComputedSteps(route, computedSteps) {
      const points = route.points ?? [];
      if (this.activePivotIndex !== null) {
        const active = this.pivots[this.activePivotIndex];
        if (active)
          this.emit({ kind: "exited", pivot: active });
      }
      if (points.length < 3 || !computedSteps || computedSteps.length < 2) {
        this.setRoute(route, null);
        return;
      }
      const cumulative = cumulativeDistances(points);
      const instructionPivots = extractPivotsFromComputedSteps(computedSteps, points);
      console.log(`[PivotEngine] setRouteFromComputedSteps: steps=${computedSteps.length} instructionPivots=${instructionPivots.length}` + (instructionPivots.length > 0 ? `
` + instructionPivots.map((p, i) => `  pivot[${i}] ${p.fromRoad ?? "—"} → ${p.toRoad ?? "—"} dir=${p.direction} @ (${p.lat.toFixed(5)}, ${p.lng.toFixed(5)})`).join(`
`) : ""));
      if (instructionPivots.length === 0) {
        console.log(`[PivotEngine] falling back to setRoute (geometry) — input steps:
` + computedSteps.map((s, i) => `  step[${i}] road=${s.road ?? "—"} maneuver=${s.maneuver ?? "—"} @ (${s.lat.toFixed(5)}, ${s.lng.toFixed(5)}) → (${s.endLat.toFixed(5)}, ${s.endLng.toFixed(5)})`).join(`
`));
        this.setRoute(route, null);
        return;
      }
      const pivots = instructionPivots.map((p, i) => ({
        index: i,
        lat: p.lat,
        lng: p.lng,
        direction: p.direction === "left" ? "left" : "right",
        fromRoad: p.fromRoad,
        toRoad: p.toRoad,
        maneuver: p.maneuver,
        distanceAlongRouteMeters: alongRouteAtCoord(points, cumulative, { lat: p.lat, lng: p.lng }),
        radiusMeters: this.opts.radiusMeters
      }));
      pivots.sort((a, b) => a.distanceAlongRouteMeters - b.distanceAlongRouteMeters);
      for (let i = 0;i < pivots.length; i++)
        pivots[i].index = i;
      this.pivots = pivots;
      this.states = pivots.map(() => ({ approachingFired: false, entered: false, exited: false }));
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = points;
      this.cumulative = cumulative;
      this.routeGeneration++;
      this._resolveMissingRoadNames(this.routeGeneration);
    }
    setRoute(route, _userPosition) {
      const points = route.points ?? [];
      const steps = route.steps ?? [];
      if (this.activePivotIndex !== null) {
        const active = this.pivots[this.activePivotIndex];
        if (active)
          this.emit({ kind: "exited", pivot: active });
      }
      if (points.length < 3) {
        this.pivots = [];
        this.states = [];
        this.cursor = 0;
        this.activePivotIndex = null;
        this.points = [];
        this.cumulative = [];
        return;
      }
      const cumulative = cumulativeDistances(points);
      const raw = extractPivots(points);
      const stepIndex = buildStepIndex(steps);
      const pivots = [];
      for (let i = 0;i < raw.length; i++) {
        const r = raw[i];
        const matched = matchStep(r, stepIndex);
        if (matched && NON_TURN_MANEUVERS.has(matched.maneuver)) {
          continue;
        }
        pivots.push({
          index: pivots.length,
          lat: r.lat,
          lng: r.lng,
          direction: r.direction,
          fromRoad: matched?.fromRoad ?? null,
          toRoad: matched?.toRoad ?? null,
          maneuver: matched?.maneuver ?? (r.direction === "left" ? "TURN_LEFT" : "TURN_RIGHT"),
          distanceAlongRouteMeters: distanceAtIndex(cumulative, r.rawRouteIndex),
          radiusMeters: this.opts.radiusMeters
        });
      }
      pivots.sort((a, b) => a.distanceAlongRouteMeters - b.distanceAlongRouteMeters);
      for (let i = 0;i < pivots.length; i++)
        pivots[i].index = i;
      this.pivots = pivots;
      this.states = pivots.map(() => ({ approachingFired: false, entered: false, exited: false }));
      this.cursor = 0;
      this.activePivotIndex = null;
      this.points = points;
      this.cumulative = cumulative;
      this.routeGeneration++;
      this._resolveMissingRoadNames(this.routeGeneration);
    }
    async _resolveMissingRoadNames(generation) {
      const pivots = this.pivots;
      if (pivots.length === 0)
        return;
      for (let i = 0;i < pivots.length - 1; i++) {
        const here = pivots[i];
        const next = pivots[i + 1];
        if (!here.toRoad && next.fromRoad)
          here.toRoad = next.fromRoad;
        if (!next.fromRoad && here.toRoad)
          next.fromRoad = here.toRoad;
      }
      for (let i = pivots.length - 1;i > 0; i--) {
        const here = pivots[i];
        const prev = pivots[i - 1];
        if (!prev.toRoad && here.fromRoad)
          prev.toRoad = here.fromRoad;
        if (!here.fromRoad && prev.toRoad)
          here.fromRoad = prev.toRoad;
      }
      const resolver = this.roadNameResolver;
      if (!resolver)
        return;
      if (this.points.length < 2)
        return;
      const SAMPLE_OFFSETS_M = [18, 30, 50, 80];
      const points = this.points;
      const cumulative = this.cumulative;
      const geocodeWithExpansion = async (pivotAlong, direction) => {
        for (const offset of SAMPLE_OFFSETS_M) {
          const sample = sampleAlongRoute(points, cumulative, pivotAlong + direction * offset);
          if (!sample)
            continue;
          try {
            const road = await resolver(sample);
            if (generation !== this.routeGeneration)
              return null;
            if (road)
              return road;
          } catch {}
        }
        return null;
      };
      const tasks = [];
      for (const pivot of pivots) {
        if (pivot.fromRoad && pivot.toRoad)
          continue;
        const along = pivot.distanceAlongRouteMeters;
        if (!pivot.fromRoad) {
          tasks.push(geocodeWithExpansion(along, -1).then((road) => {
            if (generation !== this.routeGeneration)
              return;
            if (road && !pivot.fromRoad)
              pivot.fromRoad = road;
          }));
        }
        if (!pivot.toRoad) {
          tasks.push(geocodeWithExpansion(along, 1).then((road) => {
            if (generation !== this.routeGeneration)
              return;
            if (road && !pivot.toRoad)
              pivot.toRoad = road;
          }));
        }
      }
      await Promise.all(tasks);
      if (generation !== this.routeGeneration)
        return;
      for (let i = 0;i < pivots.length - 1; i++) {
        const here = pivots[i];
        const next = pivots[i + 1];
        if (!here.toRoad && next.fromRoad)
          here.toRoad = next.fromRoad;
        if (!next.fromRoad && here.toRoad)
          next.fromRoad = here.toRoad;
      }
    }
    onLocationUpdate(coords) {
      if (this.pivots.length === 0)
        return;
      const projection = projectOntoPolyline(this.points, this.cumulative, coords);
      const useAlongPath = projection !== null && projection.perpMeters <= ON_ROUTE_PERP_TOLERANCE_M;
      const userAlong = projection?.alongMeters ?? 0;
      for (let i = this.cursor;i < this.pivots.length; i++) {
        const pivot = this.pivots[i];
        const state = this.states[i];
        if (state.exited)
          continue;
        const aheadDelta = pivot.distanceAlongRouteMeters - userAlong;
        const distanceToPivot = useAlongPath ? Math.abs(aheadDelta) : haversineMeters(coords, { lat: pivot.lat, lng: pivot.lng });
        const approaching = !state.approachingFired && distanceToPivot <= this.opts.approachThresholdMeters && (!useAlongPath || aheadDelta >= -this.opts.radiusMeters);
        if (approaching) {
          state.approachingFired = true;
          this.emit({ kind: "approaching", pivot, distanceMeters: distanceToPivot });
        }
        if (!state.entered && distanceToPivot <= pivot.radiusMeters) {
          state.entered = true;
          this.activePivotIndex = i;
          this.emit({ kind: "entered", pivot });
        }
        const movedPastOnPath = useAlongPath && aheadDelta < -pivot.radiusMeters;
        if ((state.entered && distanceToPivot > pivot.radiusMeters || !state.entered && movedPastOnPath) && !state.exited) {
          if (!state.entered) {
            state.entered = true;
            this.activePivotIndex = i;
            this.emit({ kind: "entered", pivot });
          }
          state.exited = true;
          if (this.activePivotIndex === i)
            this.activePivotIndex = null;
          this.emit({ kind: "exited", pivot });
          if (this.cursor <= i)
            this.cursor = i + 1;
        }
        if (!state.approachingFired && distanceToPivot > this.opts.approachThresholdMeters * 2) {
          break;
        }
      }
    }
    subscribe(fn) {
      this.subscribers.add(fn);
      return () => {
        this.subscribers.delete(fn);
      };
    }
    getPivots() {
      return this.pivots.slice();
    }
    getActivePivot() {
      if (this.activePivotIndex === null)
        return null;
      return this.pivots[this.activePivotIndex] ?? null;
    }
    getUpcomingPivot() {
      for (let i = this.cursor;i < this.pivots.length; i++) {
        if (!this.states[i].exited)
          return this.pivots[i];
      }
      return null;
    }
    emit(event) {
      for (const fn of this.subscribers) {
        try {
          fn(event);
        } catch (err) {
          console.error("[PivotEngine] subscriber threw:", err);
        }
      }
    }
  }
  function resolveOptions(mode, opts) {
    return {
      radiusMeters: opts?.radiusMeters ?? RADIUS_DEFAULTS_M[mode] ?? RADIUS_DEFAULTS_M.walking,
      approachThresholdMeters: opts?.approachThresholdMeters ?? APPROACH_DEFAULTS_M[mode] ?? APPROACH_DEFAULTS_M.walking
    };
  }
  function projectOntoPolyline(points, cumulative, user) {
    if (points.length < 2 || cumulative.length !== points.length)
      return null;
    const mPerDegLat = 111320;
    const mPerDegLng = 111320 * Math.cos(user.lat * Math.PI / 180);
    const ux = user.lng * mPerDegLng;
    const uy = user.lat * mPerDegLat;
    let bestPerp = Number.POSITIVE_INFINITY;
    let bestAlong = 0;
    for (let i = 0;i < points.length - 1; i++) {
      const a = points[i];
      const b = points[i + 1];
      const ax = a.lng * mPerDegLng;
      const ay = a.lat * mPerDegLat;
      const bx = b.lng * mPerDegLng;
      const by = b.lat * mPerDegLat;
      const dx = bx - ax;
      const dy = by - ay;
      const segLen2 = dx * dx + dy * dy;
      const t = segLen2 > 0 ? Math.max(0, Math.min(1, ((ux - ax) * dx + (uy - ay) * dy) / segLen2)) : 0;
      const px = ax + t * dx;
      const py = ay + t * dy;
      const perp = Math.hypot(ux - px, uy - py);
      if (perp < bestPerp) {
        bestPerp = perp;
        const segLen = Math.sqrt(segLen2);
        bestAlong = cumulative[i] + t * segLen;
      }
    }
    if (!Number.isFinite(bestPerp))
      return null;
    return { perpMeters: bestPerp, alongMeters: bestAlong };
  }
  function alongRouteAtCoord(points, cumulative, coord) {
    const projection = projectOntoPolyline(points, cumulative, coord);
    return projection?.alongMeters ?? 0;
  }
  function sampleAlongRoute(points, cumulative, targetMeters) {
    if (points.length < 2 || cumulative.length !== points.length)
      return null;
    const total = cumulative[cumulative.length - 1];
    if (!Number.isFinite(targetMeters))
      return null;
    if (targetMeters <= 0)
      return { lat: points[0].lat, lng: points[0].lng };
    if (targetMeters >= total) {
      const last = points[points.length - 1];
      return { lat: last.lat, lng: last.lng };
    }
    let lo = 0;
    let hi = cumulative.length - 1;
    while (lo + 1 < hi) {
      const mid = lo + hi >>> 1;
      if (cumulative[mid] <= targetMeters)
        lo = mid;
      else
        hi = mid;
    }
    const segStart = cumulative[lo];
    const segEnd = cumulative[hi];
    const segLen = segEnd - segStart;
    const t = segLen > 0 ? (targetMeters - segStart) / segLen : 0;
    const a = points[lo];
    const b = points[hi];
    return { lat: a.lat + (b.lat - a.lat) * t, lng: a.lng + (b.lng - a.lng) * t };
  }
  function distanceAtIndex(cumulative, idx) {
    if (cumulative.length === 0)
      return 0;
    if (idx < 0)
      return 0;
    if (idx >= cumulative.length)
      return cumulative[cumulative.length - 1];
    return cumulative[idx];
  }
  function buildStepIndex(steps) {
    if (!steps.length)
      return [];
    return steps.slice().sort((a, b) => a.routeIndex - b.routeIndex);
  }
  function matchStep(raw, stepIndex) {
    if (stepIndex.length < 2)
      return null;
    let bestJ = -1;
    let bestDelta = Number.POSITIVE_INFINITY;
    for (let i = 1;i < stepIndex.length; i++) {
      const delta = Math.abs(stepIndex[i].routeIndex - raw.rawRouteIndex);
      if (delta <= bestDelta) {
        bestDelta = delta;
        bestJ = i;
      }
    }
    if (bestJ < 1)
      return null;
    if (bestDelta > STEP_MATCH_MAX_INDEX_DELTA)
      return null;
    const SHORT_TRANSIT_METERS = 25;
    const finalIndex = stepIndex.length - 1;
    let j = bestJ;
    while (j < finalIndex - 1 && stepIndex[j].distanceMeters > 0 && stepIndex[j].distanceMeters < SHORT_TRANSIT_METERS) {
      j++;
    }
    if (j >= finalIndex)
      j = finalIndex - 1;
    const fromStep = stepIndex[bestJ - 1];
    const toStep = stepIndex[j];
    return {
      fromRoad: fromStep.road ?? null,
      toRoad: toStep.road ?? null,
      maneuver: fromStep.maneuver
    };
  }

  // ../vendor/miniapp/dist/modules/navigation.js
  class NavigationModule {
    constructor(session) {
      this.session = session;
      this._pivots = new PivotEngine("walking", undefined);
      this._tripUnsubs = [];
      this._tripStops = null;
      this._tripMode = "walking";
      this._tripAvoid = undefined;
      this._computeRouteSeq = 0;
      this._lastUserPosition = null;
      this._pivots.setRoadNameResolver(async (coord) => {
        try {
          const result = await this.reverseGeocodeRoad(coord);
          if (!result.ok)
            return null;
          return result.road ?? null;
        } catch {
          return null;
        }
      });
    }
    get hasPermission() {
      return this.session._hasManifestPermission("LOCATION");
    }
    requestPermission() {
      if (!this.hasPermission) {
        return Promise.resolve({
          ok: false,
          accepted: false,
          error: "LOCATION permission not declared in miniapp.json (required for navigation.requestPermission)."
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_REQUEST_PERMISSION
      });
    }
    async start(opts) {
      if (!this.hasPermission) {
        return {
          ok: false,
          error: "LOCATION permission not declared in miniapp.json (required for navigation.start)."
        };
      }
      const stops = normalizeStops(opts);
      const mode = opts.mode ?? "driving";
      this._tripStops = stops.length > 0 ? stops : null;
      this._tripMode = mode;
      this._tripAvoid = opts.avoid;
      this._attachPivotTrackingForTrip(mode, opts.pivots);
      const failStart = (error) => {
        this._detachPivotTracking();
        return { ok: false, error };
      };
      if (stops.length === 0) {
        return failStart("navigation.start: no stops");
      }
      let origin = this._lastUserPosition;
      if (!origin) {
        try {
          const fix = await this.session.location.getOnce();
          origin = { lat: fix.lat, lng: fix.lng };
          this._lastUserPosition = origin;
        } catch (err) {
          return failStart(`navigation.start: no GPS fix (${err instanceof Error ? err.message : String(err)})`);
        }
      }
      const restResult = await this.computeRoute({ origin, stops, mode, avoid: opts.avoid });
      if (!restResult.ok || !restResult.routes || restResult.routes.length === 0) {
        return failStart(restResult.error ?? "computeRoute failed");
      }
      const restRoute = restResult.routes[0];
      const nativeResult = await this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_START,
        lat: stops[0]?.lat,
        lng: stops[0]?.lng,
        stops,
        mode,
        avoid: opts.avoid,
        simulate: opts.simulate ?? false,
        speedMultiplier: opts.speedMultiplier ?? 1,
        missedTurnRerouteMeters: opts.missedTurnRerouteMeters
      });
      if (!nativeResult.ok) {
        this._detachPivotTracking();
        return nativeResult;
      }
      const syntheticRoute = buildNavRouteFromComputed(restRoute);
      this.session.events._forwardEvent(MiniappStreamType.NAVIGATION_ROUTE, syntheticRoute);
      return nativeResult;
    }
    stop() {
      this._detachPivotTracking();
      this.session.sendOneShot({ type: MiniappRequestType.NAVIGATION_STOP });
    }
    get dev() {
      return {
        deviate: (offsetMeters = 20) => {
          this.session.sendOneShot({ type: MiniappRequestType.NAVIGATION_DEVIATE, offsetMeters });
        },
        setWrongSidewalkOffset: (enabled) => {
          this.session.sendOneShot({ type: MiniappRequestType.NAVIGATION_SET_WRONG_SIDEWALK, enabled });
        },
        setSkipCrossings: (enabled) => {
          this.session.sendOneShot({ type: MiniappRequestType.NAVIGATION_SET_SKIP_CROSSINGS, enabled });
        }
      };
    }
    onUpdate(handler) {
      return this.session._subscribe(MiniappStreamType.NAVIGATION_UPDATE, handler);
    }
    onRoute(handler) {
      return this.session._subscribe(MiniappStreamType.NAVIGATION_ROUTE, handler);
    }
    async getState() {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_GET_STATE
      });
      return result.ok ? result.state ?? null : null;
    }
    computeRoute(opts) {
      if (!this.hasPermission) {
        return Promise.resolve({
          ok: false,
          error: "LOCATION permission not declared in miniapp.json (required for navigation.computeRoute)."
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_COMPUTE_ROUTE,
        origin: opts.origin,
        stops: opts.stops,
        mode: opts.mode ?? "driving",
        avoid: opts.avoid,
        alternatives: opts.alternatives ?? 1
      });
    }
    reverseGeocodeRoad(coord) {
      if (!this.hasPermission) {
        return Promise.resolve({
          ok: false,
          error: "LOCATION permission not declared in miniapp.json (required for reverseGeocodeRoad)."
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_REVERSE_GEOCODE,
        lat: coord.lat,
        lng: coord.lng
      });
    }
    placeAutocomplete(opts) {
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_PLACE_AUTOCOMPLETE,
        query: opts.query,
        near: opts.near ?? null,
        sessionToken: opts.sessionToken
      });
    }
    placeDetails(opts) {
      return this.session.sendRequest({
        type: MiniappRequestType.NAVIGATION_PLACE_DETAILS,
        placeId: opts.placeId,
        sessionToken: opts.sessionToken
      });
    }
    onPivot(handler) {
      return this._pivots.subscribe(handler);
    }
    getPivots() {
      return this._pivots.getPivots();
    }
    getActivePivot() {
      return this._pivots.getActivePivot();
    }
    getUpcomingPivot() {
      return this._pivots.getUpcomingPivot();
    }
    _attachPivotTrackingForTrip(mode, opts) {
      this._detachPivotTracking();
      this._pivots.reset();
      this._pivots.updateOptions(mode, opts);
      this._tripUnsubs.push(this.onRoute((route) => {
        if (route.steps && route.steps.length > 0) {
          const tail = route.points[route.points.length - 1];
          const computedSteps = route.steps.map((s, i) => {
            const next = route.steps?.[i + 1];
            const endLat = next ? next.lat : tail?.lat ?? s.lat;
            const endLng = next ? next.lng : tail?.lng ?? s.lng;
            return {
              lat: s.lat,
              lng: s.lng,
              endLat,
              endLng,
              distanceMeters: s.distanceMeters,
              maneuver: s.maneuver,
              road: s.road ?? undefined
            };
          });
          this._pivots.setRouteFromComputedSteps(route, computedSteps);
          return;
        }
        this._pivots.setRoute(route, null);
        const seq = ++this._computeRouteSeq;
        this._issueComputeRouteForTrip(route).then((result) => {
          if (seq !== this._computeRouteSeq)
            return;
          const computedSteps = result?.routes?.[0]?.steps;
          if (computedSteps && computedSteps.length > 0) {
            this._pivots.setRouteFromComputedSteps(route, computedSteps);
          }
        }).catch((err) => {
          console.warn("[NavigationModule] computeRoute for pivots failed:", err);
        });
      }));
      this._tripUnsubs.push(this.onUpdate((update) => {
        if (update.kind === "arrived") {
          this._pivots.reset();
          return;
        }
      }));
      this._tripUnsubs.push(this.session.location.onUpdate((loc) => {
        this._lastUserPosition = { lat: loc.lat, lng: loc.lng };
        this._pivots.onLocationUpdate({ lat: loc.lat, lng: loc.lng });
      }));
    }
    async _issueComputeRouteForTrip(route) {
      if (!this._tripStops || this._tripStops.length === 0)
        return null;
      const origin = this._lastUserPosition ?? (route?.points && route.points[0] ? { lat: route.points[0].lat, lng: route.points[0].lng } : null);
      if (!origin)
        return null;
      return this.computeRoute({
        origin,
        stops: this._tripStops,
        mode: this._tripMode,
        avoid: this._tripAvoid
      });
    }
    _detachPivotTracking() {
      for (const unsub of this._tripUnsubs) {
        try {
          unsub();
        } catch (err) {
          console.warn("[NavigationModule] pivot-tracking unsubscribe threw:", err);
        }
      }
      this._tripUnsubs = [];
      this._pivots.reset();
      this._tripStops = null;
      this._tripAvoid = undefined;
      this._computeRouteSeq++;
      this._lastUserPosition = null;
    }
  }
  function normalizeStops(opts) {
    if (opts.stops && opts.stops.length > 0) {
      return opts.stops;
    }
    if (typeof opts.lat === "number" && typeof opts.lng === "number") {
      return [{ lat: opts.lat, lng: opts.lng }];
    }
    return [];
  }
  function buildNavRouteFromComputed(computed) {
    const points = computed.points ?? [];
    const steps = (computed.steps ?? []).map((s) => {
      let routeIndex = 0;
      let best = Infinity;
      for (let i = 0;i < points.length; i++) {
        const dLat = points[i].lat - s.lat;
        const dLng = points[i].lng - s.lng;
        const d = dLat * dLat + dLng * dLng;
        if (d < best) {
          best = d;
          routeIndex = i;
        }
      }
      return {
        lat: s.lat,
        lng: s.lng,
        routeIndex,
        road: s.road ?? null,
        maneuver: s.maneuver ?? "STRAIGHT",
        distanceMeters: s.distanceMeters
      };
    });
    return {
      points,
      totalDistanceMeters: computed.totalDistanceMeters,
      totalDurationSeconds: computed.totalDurationSeconds,
      steps: steps.length > 0 ? steps : undefined
    };
  }

  // ../vendor/miniapp/dist/modules/permissions.js
  class PermissionsModule {
    constructor(session) {
      this.session = session;
    }
    has(type) {
      return this.session._getPermissions()[type] === true;
    }
    getAll() {
      return this.session._getPermissions();
    }
    onUpdate(handler) {
      return this.session.on("permissions", handler);
    }
    onPermissionError(handler) {
      return this.session.on("error", (e) => {
        const maybe = e;
        if (maybe?.code === MiniappErrorCode.PERMISSION_NOT_DECLARED) {
          handler({
            code: String(maybe.code),
            message: String(maybe.message ?? ""),
            permission: maybe.permission,
            subscription: maybe.subscription,
            operation: maybe.operation
          });
        }
      });
    }
  }

  // ../vendor/miniapp/dist/modules/phone.js
  class TrackedSubs {
    constructor() {
      this.unsubs = new Set;
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
  }

  class PhoneNotificationsModule extends TrackedSubs {
    constructor(session) {
      super();
      this.session = session;
    }
    on(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.PHONE_NOTIFICATION, handler));
    }
    onDismissed(handler) {
      return this.track(this.session._subscribe(MiniappStreamType.PHONE_NOTIFICATION_DISMISSED, handler));
    }
    get hasPermission() {
      return this.session._hasManifestPermission("READ_NOTIFICATIONS");
    }
  }

  class PhoneCalendarModule {
    constructor(session) {
      this.session = session;
    }
    listEvents(options) {
      const startsAt = normalizeCalendarDate(options?.startsAt, "startsAt");
      const endsAt = normalizeCalendarDate(options?.endsAt, "endsAt");
      return this.session.sendRequest({
        type: MiniappRequestType.CALENDAR_LIST_EVENTS,
        startsAt,
        endsAt,
        ...options.limit === undefined ? {} : { limit: options.limit }
      });
    }
    get hasPermission() {
      return this.session._hasManifestPermission("CALENDAR");
    }
  }
  function normalizeCalendarDate(value, field) {
    const date = value instanceof Date ? value : new Date(value ?? "");
    if (Number.isNaN(date.getTime()))
      throw new TypeError(`${field} must be a valid Date or ISO 8601 string`);
    return date.toISOString();
  }

  class PhoneModule {
    constructor(session) {
      this.session = session;
      this.notifications = new PhoneNotificationsModule(session);
      this.calendar = new PhoneCalendarModule(session);
    }
    isWifiEnabled() {
      return this.session.sendRequest({ type: MiniappRequestType.PHONE_IS_WIFI_ENABLED });
    }
    requestWifiEnable(reason) {
      return this.session.sendRequest({ type: MiniappRequestType.PHONE_REQUEST_WIFI_ENABLE, reason }, { timeoutMs: 0 });
    }
    onBattery(handler) {
      return this.session._subscribe(MiniappStreamType.PHONE_BATTERY, handler);
    }
  }

  // ../vendor/cloud-protocol/src/languages.ts
  var CANONICAL_TAG_BY_CODE = {
    af: "af-ZA",
    am: "am-ET",
    ar: "ar-AE",
    az: "az-AZ",
    be: "be-BY",
    bg: "bg-BG",
    bn: "bn-IN",
    bs: "bs-BA",
    ca: "ca-ES",
    cs: "cs-CZ",
    cy: "cy-GB",
    da: "da-DK",
    de: "de-DE",
    el: "el-GR",
    en: "en-US",
    es: "es-ES",
    et: "et-EE",
    eu: "eu-ES",
    fa: "fa-IR",
    fi: "fi-FI",
    fr: "fr-FR",
    gl: "gl-ES",
    gu: "gu-IN",
    he: "he-IL",
    hi: "hi-IN",
    hr: "hr-HR",
    hu: "hu-HU",
    hy: "hy-AM",
    id: "id-ID",
    it: "it-IT",
    ja: "ja-JP",
    ka: "ka-GE",
    kk: "kk-KZ",
    kn: "kn-IN",
    ko: "ko-KR",
    lt: "lt-LT",
    lv: "lv-LV",
    mk: "mk-MK",
    ml: "ml-IN",
    mr: "mr-IN",
    ms: "ms-MY",
    nb: "nb-NO",
    ne: "ne-NP",
    nl: "nl-NL",
    no: "nb-NO",
    pa: "pa-IN",
    pl: "pl-PL",
    pt: "pt-BR",
    ro: "ro-RO",
    ru: "ru-RU",
    sk: "sk-SK",
    sl: "sl-SI",
    sq: "sq-AL",
    sr: "sr-RS",
    sv: "sv-SE",
    sw: "sw-KE",
    ta: "ta-IN",
    te: "te-IN",
    th: "th-TH",
    tl: "fil-PH",
    tr: "tr-TR",
    uk: "uk-UA",
    ur: "ur-IN",
    vi: "vi-VN",
    zh: "zh-CN"
  };
  var EXTRA_REGIONAL_TAGS = [
    "ar-EG",
    "ar-SA",
    "de-AT",
    "de-CH",
    "en-AU",
    "en-CA",
    "en-GB",
    "en-IN",
    "es-419",
    "es-MX",
    "es-US",
    "fr-CA",
    "nl-BE",
    "pt-PT",
    "zh-HK",
    "zh-TW"
  ];
  var SUPPORTED_LANGUAGE_HINTS = Object.freeze([...new Set(Object.keys(CANONICAL_TAG_BY_CODE))].sort());
  var SUPPORTED_TRANSCRIPTION_LANGUAGES = Object.freeze([
    ...new Set([
      ...Object.values(CANONICAL_TAG_BY_CODE),
      ...EXTRA_REGIONAL_TAGS
    ])
  ].sort());
  var TAG_SET = new Set(SUPPORTED_TRANSCRIPTION_LANGUAGES);
  var HINT_SET = new Set(SUPPORTED_LANGUAGE_HINTS);
  function toTranscriptionLanguage(value) {
    if (TAG_SET.has(value))
      return value;
    const canonical = CANONICAL_TAG_BY_CODE[value.toLowerCase()];
    return canonical ?? null;
  }
  function toLanguageHint(value) {
    const primary = value.split("-")[0].toLowerCase();
    return HINT_SET.has(primary) ? primary : null;
  }
  function suggestTranscriptionLanguage(value) {
    const normalized = value.replace(/_/g, "-");
    const parts = normalized.split("-");
    const recased = parts.length >= 2 ? `${parts[0].toLowerCase()}-${parts[1].toUpperCase()}` : normalized.toLowerCase();
    return toTranscriptionLanguage(recased);
  }

  // ../vendor/miniapp/dist/modules/languages.js
  class MiniappValidationError extends Error {
    constructor(message) {
      super(message);
      this.name = "MiniappValidationError";
    }
  }
  function requireTranscriptionLanguage(value, param) {
    const canonical = toTranscriptionLanguage(value);
    if (canonical)
      return canonical;
    const suggestion = suggestTranscriptionLanguage(value);
    throw new MiniappValidationError(`${param}: unknown language ${JSON.stringify(value)}` + (suggestion ? ` — did you mean ${JSON.stringify(suggestion)}?` : "") + ` Supported values are BCP-47 tags from SUPPORTED_TRANSCRIPTION_LANGUAGES (e.g. "en-US", "fr-FR").`);
  }
  function requireLanguageHint(value, param) {
    const hint = toLanguageHint(value);
    if (hint)
      return hint;
    throw new MiniappValidationError(`${param}: unknown language hint ${JSON.stringify(value)}. ` + `Hints are bare ISO 639-1 codes from SUPPORTED_LANGUAGE_HINTS (e.g. "en", "fr").`);
  }

  // ../vendor/miniapp/dist/modules/transcription.js
  class TranscriptionModule {
    constructor(session) {
      this.session = session;
      this.unsubs = new Set;
      this.currentConfig = null;
    }
    on(handler, options = {}) {
      return this.track(this.session._subscribe(`${MiniappStreamType.TRANSCRIPTION}:auto`, handler, options));
    }
    forLanguage(language, handler, options = {}) {
      const langs = (Array.isArray(language) ? language : [language]).map((lang) => requireTranscriptionLanguage(lang, "transcription.forLanguage(language)"));
      if (langs.length === 0)
        return () => {};
      const unsubs = [];
      for (const lang of langs) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TRANSCRIPTION}:${lang}`, handler, options));
      }
      const combined = () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
      return this.track(combined);
    }
    configure(config) {
      const normalized = {
        ...config,
        languageHints: config.languageHints?.map((hint) => requireLanguageHint(hint, "transcription.configure(languageHints)"))
      };
      this.currentConfig = { ...normalized };
      return this.session.sendRequest({
        type: MiniappRequestType.TRANSCRIPTION_CONFIG,
        config: { ...normalized }
      }).then(() => {
        return;
      });
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
    get hasPermission() {
      return this.session._hasManifestPermission("MICROPHONE");
    }
    _getConfig() {
      return this.currentConfig ? { ...this.currentConfig } : null;
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
  }

  // ../vendor/miniapp/dist/modules/translation.js
  class TranslationModule {
    constructor(session) {
      this.session = session;
      this.unsubs = new Set;
    }
    on(handler) {
      return this.track(this.session._subscribe(`${MiniappStreamType.TRANSLATION}:*:*`, handler));
    }
    to(target, handler) {
      const targets = (Array.isArray(target) ? target : [target]).map((t) => requireTranscriptionLanguage(t, "translation.to(target)"));
      if (targets.length === 0)
        return () => {};
      const unsubs = [];
      for (const t of targets) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TRANSLATION}:*:${t}`, handler));
      }
      const composite = () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
      return this.track(composite);
    }
    fromTo(source, target, handler) {
      const validSource = source === "auto" ? "auto" : requireTranscriptionLanguage(source, "translation.fromTo(source)");
      const targets = (Array.isArray(target) ? target : [target]).map((t) => requireTranscriptionLanguage(t, "translation.fromTo(target)"));
      if (targets.length === 0)
        return () => {};
      const unsubs = [];
      for (const t of targets) {
        unsubs.push(this.session._subscribe(`${MiniappStreamType.TRANSLATION}:${validSource}:${t}`, handler));
      }
      const composite = () => {
        for (const u of unsubs) {
          try {
            u();
          } catch {}
        }
      };
      return this.track(composite);
    }
    forLanguagePair(fromLang, toLang, handler) {
      return this.fromTo(fromLang, toLang, handler);
    }
    stop() {
      for (const u of this.unsubs) {
        try {
          u();
        } catch {}
      }
      this.unsubs.clear();
    }
    get hasPermission() {
      return this.session._hasManifestPermission("MICROPHONE");
    }
    track(unsub) {
      this.unsubs.add(unsub);
      return () => {
        this.unsubs.delete(unsub);
        unsub();
      };
    }
  }

  // ../vendor/miniapp/dist/modules/ui.js
  function rpcErrorFromUnknown(e) {
    if (e instanceof Error) {
      const own = e;
      const cause = own.cause;
      return compactEnvelope({
        message: e.message,
        code: own.code ?? cause?.code,
        stage: own.stage,
        transport: own.transport
      });
    }
    if (e && typeof e === "object") {
      const o = e;
      return compactEnvelope({
        message: typeof o.message === "string" ? o.message : JSON.stringify(e),
        code: typeof o.code === "string" ? o.code : undefined,
        stage: typeof o.stage === "string" ? o.stage : undefined,
        transport: typeof o.transport === "string" ? o.transport : undefined
      });
    }
    return { message: String(e) };
  }
  function compactEnvelope(env) {
    const out = { message: env.message };
    if (env.code)
      out.code = env.code;
    if (env.stage)
      out.stage = env.stage;
    if (env.transport)
      out.transport = env.transport;
    return out;
  }

  class UIModuleImpl {
    constructor(session) {
      this.session = session;
      this.bound = false;
      this.nextSeq = 1;
      this.openHandlers = new Set;
      this.closeHandlers = new Set;
      this.channelHandlers = new Map;
      this.rpcHandlers = new Map;
      this.inflightRpc = new Map;
      this.isOpen = () => {
        return this.bound;
      };
      this.onOpen = (cb) => {
        this.openHandlers.add(cb);
        if (this.bound) {
          if (this.session.ready) {
            try {
              cb();
            } catch (e) {
              console.warn("session.ui.onOpen late-fire threw:", e);
            }
          }
        }
        return () => {
          this.openHandlers.delete(cb);
        };
      };
      this.onClose = (cb) => {
        this.closeHandlers.add(cb);
        return () => {
          this.closeHandlers.delete(cb);
        };
      };
      this.send = (channel, payload) => {
        if (!this.bound) {
          return;
        }
        const seq = this.nextSeq++;
        const envelope = { type: "UI_SEND", channel, payload, seq };
        this.session.sendOneShot(envelope);
      };
      this.on = (channel, cb) => {
        let set = this.channelHandlers.get(channel);
        if (!set) {
          set = new Set;
          this.channelHandlers.set(channel, set);
        }
        set.add(cb);
        return () => {
          set.delete(cb);
        };
      };
      this.handle = (channel, handler) => {
        const key = channel;
        if (this.rpcHandlers.has(key)) {
          throw new Error(`session.ui.handle: a handler is already registered for "${key}"`);
        }
        this.rpcHandlers.set(key, handler);
        return () => {
          this.rpcHandlers.delete(key);
        };
      };
      this.session._subscribe("_ui", (env) => this.handleInbound(env));
    }
    fireOpenHandlers() {
      for (const h of this.openHandlers) {
        try {
          h();
        } catch (e) {
          console.warn("session.ui.onOpen handler threw", e);
        }
      }
    }
    handleInbound(env) {
      if (env.type === "UI_OPEN") {
        this.bound = true;
        this.nextSeq = 1;
        if (this.session.ready) {
          this.fireOpenHandlers();
        } else {
          const off = this.session.on("ready", () => {
            off();
            if (this.bound)
              this.fireOpenHandlers();
          });
        }
        return;
      }
      if (env.type === "UI_CLOSE") {
        this.bound = false;
        for (const h of this.closeHandlers) {
          try {
            h();
          } catch (e) {
            console.warn("session.ui.onClose handler threw", e);
          }
        }
        return;
      }
      if (env.type === "UI_MESSAGE") {
        if (typeof env.requestId === "string") {
          this.dispatchRpcCall(env.channel, env.payload, env.requestId);
          return;
        }
        const set = this.channelHandlers.get(env.channel);
        if (!set || set.size === 0)
          return;
        for (const h of set) {
          try {
            h(env.payload);
          } catch (e) {
            console.warn(`session.ui.on(${env.channel}) threw`, e);
          }
        }
        return;
      }
      if (env.type === "UI_CANCEL") {
        const ctrl = this.inflightRpc.get(env.requestId);
        if (ctrl) {
          try {
            ctrl.abort();
          } catch {}
        }
        return;
      }
    }
    dispatchRpcCall(channel, payload, requestId) {
      const handler = this.rpcHandlers.get(channel);
      if (!handler) {
        this.sendRpcReply(channel, requestId, {
          ok: false,
          error: { message: `no handler registered for "${channel}"` }
        });
        return;
      }
      const ctrl = new AbortController;
      this.inflightRpc.set(requestId, ctrl);
      const ctx = { signal: ctrl.signal };
      const finish = (envelope) => {
        this.inflightRpc.delete(requestId);
        if (ctrl.signal.aborted)
          return;
        this.sendRpcReply(channel, requestId, envelope);
      };
      let result;
      try {
        result = handler(payload, ctx);
      } catch (e) {
        finish({ ok: false, error: rpcErrorFromUnknown(e) });
        return;
      }
      if (result && typeof result.then === "function") {
        result.then((v) => finish({ ok: true, result: v }), (e) => finish({ ok: false, error: rpcErrorFromUnknown(e) }));
      } else {
        finish({ ok: true, result });
      }
    }
    sendRpcReply(channel, requestId, payload) {
      if (!this.bound)
        return;
      const seq = this.nextSeq++;
      const envelope = { type: "UI_SEND", channel, payload, seq, requestId };
      this.session.sendOneShot(envelope);
    }
  }

  // ../vendor/miniapp/dist/modules/storage.js
  class SimpleStorage {
    constructor(session) {
      this.session = session;
    }
    async get(key) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_GET,
        key
      });
      return result?.value ?? null;
    }
    async set(key, value) {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_SET,
        key,
        value
      });
    }
    async delete(key) {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_DELETE,
        key
      });
    }
    async keys() {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_LIST
      });
      return result?.keys ?? [];
    }
    async list() {
      return this.keys();
    }
    async clear() {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_CLEAR
      });
    }
    async has(key) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_HAS,
        key
      });
      return !!result?.has;
    }
    async getAll() {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_GET_ALL
      });
      return result?.values ?? {};
    }
    async setMultiple(values) {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_SET_MULTIPLE,
        values
      });
    }
    async flush() {
      await this.session.sendRequest({
        type: MiniappRequestType.STORAGE_FLUSH
      });
    }
  }

  // ../vendor/miniapp/dist/modules/base64.js
  var ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  var LOOKUP = (() => {
    const t = new Int16Array(256).fill(-1);
    for (let i = 0;i < ALPHABET.length; i++)
      t[ALPHABET.charCodeAt(i)] = i;
    t[61] = 0;
    return t;
  })();
  function toUint8Array(input) {
    if (input instanceof Uint8Array)
      return input;
    if (input instanceof ArrayBuffer)
      return new Uint8Array(input);
    return new Uint8Array(input.buffer, input.byteOffset, input.byteLength);
  }
  function bytesToBase64(input) {
    const bytes = input instanceof Uint8Array ? input : new Uint8Array(input);
    const len = bytes.length;
    let out = "";
    let i = 0;
    for (;i + 2 < len; i += 3) {
      const n = bytes[i] << 16 | bytes[i + 1] << 8 | bytes[i + 2];
      out += ALPHABET[n >> 18 & 63] + ALPHABET[n >> 12 & 63] + ALPHABET[n >> 6 & 63] + ALPHABET[n & 63];
    }
    const rem = len - i;
    if (rem === 1) {
      const n = bytes[i] << 16;
      out += ALPHABET[n >> 18 & 63] + ALPHABET[n >> 12 & 63] + "==";
    } else if (rem === 2) {
      const n = bytes[i] << 16 | bytes[i + 1] << 8;
      out += ALPHABET[n >> 18 & 63] + ALPHABET[n >> 12 & 63] + ALPHABET[n >> 6 & 63] + "=";
    }
    return out;
  }
  function base64ToBytes(b64) {
    let validChars = 0;
    let pad = 0;
    for (let i = 0;i < b64.length; i++) {
      const c = b64.charCodeAt(i);
      if (c === 61) {
        pad++;
        validChars++;
      } else if (LOOKUP[c] !== -1) {
        validChars++;
      }
    }
    const fullGroups = Math.floor(validChars / 4);
    const remChars = validChars - fullGroups * 4;
    let outLen = fullGroups * 3 - (pad > 0 && remChars === 0 ? pad : 0);
    if (remChars === 2)
      outLen += 1;
    else if (remChars === 3)
      outLen += 2;
    if (outLen < 0)
      outLen = 0;
    const out = new Uint8Array(outLen);
    let acc = 0;
    let bits = 0;
    let o = 0;
    for (let i = 0;i < b64.length && o < outLen; i++) {
      const c = b64.charCodeAt(i);
      if (c === 61)
        break;
      const v = LOOKUP[c];
      if (v === -1)
        continue;
      acc = acc << 6 | v;
      bits += 6;
      if (bits >= 8) {
        bits -= 8;
        out[o++] = acc >> bits & 255;
      }
    }
    return out;
  }

  // ../vendor/miniapp/dist/modules/speaker.js
  var SPEAKER_WRITE_CHUNK_BYTES = 256 * 1024;
  var SPEAKER_WRITE_CHUNK_B64 = Math.floor(SPEAKER_WRITE_CHUNK_BYTES / 6) * 8;
  class SpeakerStreamWriter {
    constructor(session, streamId) {
      this.session = session;
      this.streamId = streamId;
      this.settled = false;
      this.writeChain = Promise.resolve();
    }
    async write(chunk) {
      this.assertOpen();
      const bytes = toUint8Array(chunk);
      if (bytes.byteLength === 0)
        throw new Error("PCM chunk cannot be empty");
      if (bytes.byteLength % 2 !== 0)
        throw new Error("PCM chunk must contain complete 16-bit samples");
      return this.enqueueWrite(async () => {
        let last = { bufferedMs: 0 };
        for (let off = 0;off < bytes.length; off += SPEAKER_WRITE_CHUNK_BYTES) {
          last = await this.send(bytesToBase64(bytes.subarray(off, off + SPEAKER_WRITE_CHUNK_BYTES)));
        }
        return last;
      });
    }
    async writeBase64(b64) {
      this.assertOpen();
      if (b64.length === 0 || b64.length % 4 !== 0)
        throw new Error("PCM base64 must be non-empty and padded");
      const padding = b64.endsWith("==") ? 2 : b64.endsWith("=") ? 1 : 0;
      const decodedBytes = b64.length / 4 * 3 - padding;
      if (decodedBytes % 2 !== 0)
        throw new Error("PCM base64 must contain complete 16-bit samples");
      return this.enqueueWrite(async () => {
        let last = { bufferedMs: 0 };
        for (let off = 0;off < b64.length; off += SPEAKER_WRITE_CHUNK_B64) {
          last = await this.send(b64.slice(off, off + SPEAKER_WRITE_CHUNK_B64));
        }
        return last;
      });
    }
    async close() {
      this.assertOpen();
      this.settled = true;
      await this.writeChain;
      const res = await this.session.sendRequest({ type: MiniappRequestType.SPEAKER_STREAM_CLOSE, streamId: this.streamId }, { timeoutMs: 0 });
      return res ?? {};
    }
    async abort() {
      if (this.settled)
        return;
      this.settled = true;
      await this.session.sendRequest({
        type: MiniappRequestType.SPEAKER_STREAM_ABORT,
        streamId: this.streamId
      });
    }
    assertOpen() {
      if (this.settled)
        throw new Error("SpeakerStreamWriter is already closed/aborted");
    }
    async send(base64) {
      const res = await this.session.sendRequest({
        type: MiniappRequestType.SPEAKER_STREAM_WRITE,
        streamId: this.streamId,
        base64
      });
      return res ?? { bufferedMs: 0 };
    }
    enqueueWrite(operation) {
      const result = this.writeChain.then(operation);
      this.writeChain = result.then(() => {
        return;
      }, () => {
        return;
      });
      return result;
    }
  }

  class SpeakerModule {
    constructor(session) {
      this.session = session;
      this._state = "idle";
      this._lastEvent = { state: "idle" };
    }
    get state() {
      return this._state;
    }
    get isPlaying() {
      return this._state === "playing";
    }
    async play(options) {
      await this.session.sendRequest({
        type: MiniappRequestType.PLAY_AUDIO,
        audioUrl: options.audioUrl,
        volume: options.volume,
        stopOtherAudio: options.stopOtherAudio ?? false
      }, { timeoutMs: 0 });
    }
    async speak(text, options = {}) {
      const normalized = Array.isArray(text) ? text.map((sentence) => sentence.trim()).filter(Boolean) : text.trim();
      if (Array.isArray(normalized) && normalized.length === 0 || normalized === "") {
        throw { code: MiniappErrorCode.INTERNAL, message: "speak requires at least one non-empty sentence" };
      }
      try {
        const result = await this.session.sendRequest({
          type: MiniappRequestType.SPEAK,
          text: normalized,
          voice_id: options.voice_id,
          voice_settings: options.voice_settings,
          volume: options.volume,
          stopOtherAudio: options.stopOtherAudio ?? false,
          enableSanitization: options.enableSanitization ?? true,
          forceLocal: options.forceLocal ?? false
        }, { timeoutMs: 0 });
        return result ?? { completed: true };
      } catch (err) {
        if (err && typeof err === "object" && "code" in err) {
          throw err;
        }
        throw { code: MiniappErrorCode.INTERNAL, message: String(err) };
      }
    }
    async createStream(options = {}) {
      if (options.volume !== undefined && (!Number.isFinite(options.volume) || options.volume < 0 || options.volume > 1)) {
        throw new RangeError("speaker stream volume must be between 0 and 1");
      }
      const res = await this.session.sendRequest({
        type: MiniappRequestType.SPEAKER_STREAM_OPEN,
        sampleRate: options.sampleRate ?? 16000,
        channels: options.channels ?? 1,
        volume: options.volume,
        stopOtherAudio: options.stopOtherAudio ?? true
      });
      return new SpeakerStreamWriter(this.session, res.streamId);
    }
    stop() {
      this.session.sendOneShot({ type: MiniappRequestType.STOP_AUDIO });
    }
    onStateChange(handler) {
      return this.session.on("speakerState", handler);
    }
    _applyState(event) {
      if (event.state === this._state && event.state !== "error")
        return;
      this._state = event.state;
      this._lastEvent = event;
    }
    _getLastEvent() {
      return { ...this._lastEvent };
    }
  }

  // ../vendor/miniapp/dist/modules/stream.js
  class PreviewError extends Error {
    constructor(code, message) {
      super(message ?? code);
      this.name = "PreviewError";
      this.code = code;
    }
  }
  function toPreviewError(error) {
    if (error instanceof PreviewError)
      return error;
    const value = error ?? {};
    const code = typeof value.code === "string" ? value.code : "unsupported";
    const message = typeof value.message === "string" ? value.message : undefined;
    return new PreviewError(code, message);
  }

  class PreviewHandleImpl {
    constructor(source, handleId, previewTraceId, release) {
      this.source = source;
      this.handleId = handleId;
      this.previewTraceId = previewTraceId;
      this.release = release;
      this.state = "held";
      this.listeners = new Set;
    }
    async stop() {
      if (this.state === "ended")
        return;
      this.end("stopped");
      await this.release(this);
    }
    onStatus(cb) {
      this.listeners.add(cb);
      return () => this.listeners.delete(cb);
    }
    end(reason) {
      if (this.state === "ended")
        return;
      this.state = "ended";
      this.emit({ state: "ended", reason });
    }
    emit(status) {
      for (const listener of [...this.listeners]) {
        try {
          listener(status);
        } catch {}
      }
    }
  }

  class StreamModule {
    constructor(session) {
      this.session = session;
      this.previewHandles = new Map;
    }
    async preview(options = {}) {
      const source = options.source ?? "call";
      if (source !== "call") {
        throw new PreviewError("unsupported", `Preview source "${String(source)}" is not supported yet`);
      }
      let result;
      try {
        result = await this.session.sendRequest({
          type: MiniappRequestType.STREAM_PREVIEW_START,
          source
        });
      } catch (error) {
        throw toPreviewError(error);
      }
      const handle = new PreviewHandleImpl(result.source ?? source, result.handleId, result.previewTraceId, (h) => this.releasePreview(h));
      this.previewHandles.set(handle.handleId, handle);
      handle.onStatus((status) => {
        if (status.state === "ended")
          this.previewHandles.delete(handle.handleId);
      });
      return handle;
    }
    async releasePreview(handle) {
      this.previewHandles.delete(handle.handleId);
      try {
        await this.session.sendRequest({
          type: MiniappRequestType.STREAM_PREVIEW_STOP,
          handleId: handle.handleId
        });
      } catch (error) {
        throw toPreviewError(error);
      }
    }
    _applyPreviewStatus(payload) {
      if (typeof payload.handleId !== "string")
        return;
      const handle = this.previewHandles.get(payload.handleId);
      if (!handle)
        return;
      if (payload.state === "ended") {
        handle.end(typeof payload.reason === "string" ? payload.reason : "ended");
      }
    }
    async startStream(options = {}) {
      if (options.direct !== undefined) {
        return this.session.sendRequest({
          type: MiniappRequestType.STREAM_START,
          streamUrl: options.direct,
          video: options.video,
          audio: options.audio,
          sound: options.sound ?? true,
          ...options.authToken ? { authToken: options.authToken } : {},
          ...typeof options.captureAudio === "boolean" ? { captureAudio: options.captureAudio } : {}
        });
      }
      return this.session.sendRequest({
        type: MiniappRequestType.MANAGED_STREAM_START,
        restreamDestinations: options.destinations,
        video: options.video,
        audio: options.audio,
        sound: options.sound ?? true,
        ingest: options.ingest,
        ...typeof options.captureAudio === "boolean" ? { captureAudio: options.captureAudio } : {}
      });
    }
    async stop(streamId) {
      await this.session.sendRequest({
        type: MiniappRequestType.STREAM_STOP,
        streamId
      });
    }
  }

  // ../vendor/miniapp/dist/modules/system.js
  class SystemModule {
    constructor(session) {
      this.session = session;
    }
    async share(options) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.SHARE,
        ...options
      });
      return result ?? { success: false };
    }
    openUrl(url) {
      this.session.sendOneShot({
        type: MiniappRequestType.OPEN_URL,
        url
      });
    }
    async copyToClipboard(text) {
      await this.session.sendRequest({
        type: MiniappRequestType.COPY_CLIPBOARD,
        text
      });
    }
    async download(options) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.DOWNLOAD,
        ...options
      });
      return result ?? { success: false };
    }
    async scanQr(options = {}) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.SCAN_QR,
        ...options
      }, { timeoutMs: 0 });
      return result ?? { cancelled: true };
    }
  }

  // ../vendor/miniapp/dist/modules/miniapps.js
  class MiniappsModule {
    constructor(session) {
      this.session = session;
    }
    async list(opts) {
      const result = await this.session.sendRequest({
        type: MiniappRequestType.MINIAPPS_LIST,
        includeIncompatible: opts?.includeIncompatible ?? false
      });
      return result ?? [];
    }
    async start(packageName) {
      await this.session.sendRequest({
        type: MiniappRequestType.MINIAPPS_START,
        packageName
      });
    }
    async stop(packageName) {
      await this.session.sendRequest({
        type: MiniappRequestType.MINIAPPS_STOP,
        packageName
      });
    }
  }

  // ../vendor/miniapp/dist/modules/actions.js
  var HANDLER_WAIT_MS = 5000;

  class ActionsModule {
    constructor(session) {
      this.session = session;
      this.handlers = new Map;
      this.buffered = new Map;
    }
    invoke(packageName, actionId, params, opts) {
      return this.session.sendRequest({
        type: MiniappRequestType.ACTION_INVOKE,
        targetPackageName: packageName,
        actionId,
        params: params ?? {},
        ...opts?.timeoutMs != null ? { timeoutMs: opts.timeoutMs } : {}
      });
    }
    handle(actionId, handler) {
      if (this.handlers.has(actionId)) {
        throw new Error(`session.actions.handle: a handler is already registered for "${actionId}"`);
      }
      this.handlers.set(actionId, handler);
      const waiting = this.buffered.get(actionId);
      if (waiting) {
        this.buffered.delete(actionId);
        for (const call of waiting) {
          clearTimeout(call.timer);
          this.dispatch(call.callId, actionId, call.params, call.ctx);
        }
      }
      return () => {
        if (this.handlers.get(actionId) === handler)
          this.handlers.delete(actionId);
      };
    }
    _deliver(callId, actionId, params, ctx) {
      if (this.handlers.has(actionId)) {
        this.dispatch(callId, actionId, params, ctx);
        return;
      }
      const timer = setTimeout(() => {
        const arr2 = this.buffered.get(actionId);
        if (arr2) {
          const idx = arr2.findIndex((c) => c.callId === callId);
          if (idx >= 0)
            arr2.splice(idx, 1);
          if (arr2.length === 0)
            this.buffered.delete(actionId);
        }
        this.sendResult(callId, false, undefined, {
          code: MiniappErrorCode.NO_ACTION_HANDLER,
          message: `No handler registered for action "${actionId}"`
        });
      }, HANDLER_WAIT_MS);
      const arr = this.buffered.get(actionId) ?? [];
      arr.push({ callId, params, ctx, timer });
      this.buffered.set(actionId, arr);
    }
    async dispatch(callId, actionId, params, ctx) {
      const handler = this.handlers.get(actionId);
      if (!handler)
        return;
      try {
        const result = await handler(params, ctx);
        this.sendResult(callId, true, result ?? null);
      } catch (e) {
        this.sendResult(callId, false, undefined, {
          code: MiniappErrorCode.INTERNAL,
          message: e?.message ?? "action handler threw"
        });
      }
    }
    sendResult(callId, ok, result, error) {
      this.session.sendOneShot({
        type: MiniappRequestType.ACTION_RESULT,
        callId,
        ok,
        ...ok ? { result } : { error }
      });
    }
  }

  // ../vendor/miniapp/dist/modules/blob.js
  var BLOB_WRITE_CHUNK_BYTES = 1024 * 1024;
  var BLOB_WRITE_CHUNK_B64 = Math.floor(BLOB_WRITE_CHUNK_BYTES / 3) * 4;
  var BLOB_READ_ALL_MAX_BYTES = 32 * 1024 * 1024;

  class BlobWriter {
    constructor(session, key) {
      this.session = session;
      this.key = key;
      this.settled = false;
    }
    async write(chunk) {
      this.assertOpen();
      const bytes = toUint8Array(chunk);
      for (let off = 0;off < bytes.length; off += BLOB_WRITE_CHUNK_BYTES) {
        await this.send(bytesToBase64(bytes.subarray(off, off + BLOB_WRITE_CHUNK_BYTES)));
      }
    }
    async writeBase64(b64) {
      this.assertOpen();
      for (let off = 0;off < b64.length; off += BLOB_WRITE_CHUNK_B64) {
        await this.send(b64.slice(off, off + BLOB_WRITE_CHUNK_B64));
      }
    }
    async writeAt(offset, chunk) {
      this.assertOpen();
      await this.session.sendRequest({
        type: MiniappRequestType.BLOB_WRITE,
        key: this.key,
        offset,
        base64: bytesToBase64(toUint8Array(chunk))
      });
    }
    async close(meta) {
      this.assertOpen();
      this.settled = true;
      return this.session.sendRequest({ type: MiniappRequestType.BLOB_COMMIT, key: this.key, meta });
    }
    async abort() {
      if (this.settled)
        return;
      this.settled = true;
      await this.session.sendRequest({ type: MiniappRequestType.BLOB_ABORT, key: this.key });
    }
    assertOpen() {
      if (this.settled)
        throw new Error("BlobWriter is already closed/aborted");
    }
    send(base64) {
      return this.session.sendRequest({
        type: MiniappRequestType.BLOB_WRITE,
        key: this.key,
        base64
      });
    }
  }

  class BlobReader {
    constructor(session, handle, meta) {
      this.session = session;
      this.handle = handle;
      this.meta = meta;
      this.closed = false;
    }
    async read(maxBytes = BLOB_WRITE_CHUNK_BYTES) {
      if (this.closed)
        throw new Error("BlobReader is closed");
      const res = await this.session.sendRequest({
        type: MiniappRequestType.BLOB_READ,
        handle: this.handle,
        maxBytes
      });
      return { bytes: base64ToBytes(res?.base64 ?? ""), done: !!res?.done };
    }
    async close() {
      if (this.closed)
        return;
      this.closed = true;
      await this.session.sendRequest({ type: MiniappRequestType.BLOB_CLOSE_READ, handle: this.handle });
    }
  }

  class BlobModule {
    constructor(session) {
      this.session = session;
    }
    async set(key, data, opts = {}) {
      const writer = await this.createWriteStream(key, opts);
      try {
        if (typeof data === "string")
          await writer.writeBase64(data);
        else
          await writer.write(data);
        return await writer.close();
      } catch (err) {
        await writer.abort().catch(() => {});
        throw err;
      }
    }
    setFromUrl(key, url, opts = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.BLOB_SET_FROM_URL,
        key,
        url,
        mimeType: opts.mimeType,
        name: opts.name,
        headers: opts.headers,
        meta: opts.meta
      });
    }
    importFile(opts = {}) {
      return this.session.sendRequest({
        type: MiniappRequestType.BLOB_IMPORT,
        key: opts.key,
        mimeType: opts.mimeType,
        meta: opts.meta
      });
    }
    async createWriteStream(key, opts = {}) {
      const res = await this.session.sendRequest({
        type: MiniappRequestType.BLOB_CREATE,
        key,
        mimeType: opts.mimeType,
        name: opts.name,
        meta: opts.meta
      });
      return new BlobWriter(this.session, res.key);
    }
    get(key) {
      return this.session.sendRequest({ type: MiniappRequestType.BLOB_GET, key });
    }
    stat(key) {
      return this.get(key);
    }
    async has(key) {
      return await this.get(key) !== null;
    }
    async keys() {
      return (await this.list()).map((m) => m.key);
    }
    async list() {
      const res = await this.session.sendRequest({ type: MiniappRequestType.BLOB_LIST });
      return res?.blobs ?? [];
    }
    async createReadStream(key) {
      const res = await this.session.sendRequest({
        type: MiniappRequestType.BLOB_OPEN_READ,
        key
      });
      return new BlobReader(this.session, res.handle, res.meta);
    }
    async bytes(key) {
      let reader;
      try {
        reader = await this.createReadStream(key);
      } catch {
        return null;
      }
      const parts = [];
      let total = 0;
      try {
        for (;; ) {
          const { bytes, done } = await reader.read();
          if (bytes.length) {
            total += bytes.length;
            if (total > BLOB_READ_ALL_MAX_BYTES) {
              throw new Error(`Blob "${key}" exceeds the in-memory read cap — stream it with createReadStream()`);
            }
            parts.push(bytes);
          }
          if (done)
            break;
        }
      } finally {
        await reader.close().catch(() => {});
      }
      const out = new Uint8Array(total);
      let at = 0;
      for (const p of parts) {
        out.set(p, at);
        at += p.length;
      }
      return out;
    }
    usage() {
      return this.session.sendRequest({
        type: MiniappRequestType.BLOB_USAGE
      });
    }
    async delete(key) {
      await this.session.sendRequest({ type: MiniappRequestType.BLOB_DELETE, key });
    }
    async clear() {
      await this.session.sendRequest({ type: MiniappRequestType.BLOB_CLEAR });
    }
    async share(key) {
      const res = await this.session.sendRequest({
        type: MiniappRequestType.BLOB_SHARE,
        key
      });
      return res ?? { success: false };
    }
  }

  // ../vendor/miniapp/dist/modules/meeting.js
  var MEETING_HOST_UPDATE_MESSAGE = "Update the Mentra App to use Teams calling";
  function validateMeetingVideoSource(source) {
    const value = source ?? {};
    if (value.type === "whep") {
      const url = typeof value.url === "string" ? value.url.trim() : "";
      if (!url) {
        throw { code: MiniappErrorCode.INVALID_ARGUMENT, message: "videoSource.url is required for a WHEP source" };
      }
      return { type: "whep", url };
    }
    if (value.type === "softap") {
      const ssid = typeof value.ssid === "string" ? value.ssid.trim() : "";
      const passphrase = typeof value.passphrase === "string" ? value.passphrase : "";
      if (Boolean(ssid) !== Boolean(passphrase)) {
        throw {
          code: MiniappErrorCode.INVALID_ARGUMENT,
          message: "videoSource.ssid and videoSource.passphrase must be provided together"
        };
      }
      return ssid ? { type: "softap", ssid, passphrase } : { type: "softap" };
    }
    throw {
      code: MiniappErrorCode.INVALID_ARGUMENT,
      message: `videoSource must be {type: "whep", url} or {type: "softap"}`
    };
  }
  function parseMeetingEndReason(raw) {
    if (!raw || typeof raw !== "object")
      return;
    const value = raw;
    const number = (field) => typeof field === "number" && Number.isFinite(field) ? field : undefined;
    const code = number(value.code);
    const subcode = number(value.subcode);
    const message = typeof value.message === "string" && value.message ? value.message : undefined;
    if (code === undefined && subcode === undefined && message === undefined)
      return;
    return {
      ...code !== undefined ? { code } : {},
      ...subcode !== undefined ? { subcode } : {},
      ...message !== undefined ? { message } : {}
    };
  }
  function parseMeetingCapabilities(raw) {
    if (!raw || typeof raw !== "object")
      return;
    const value = raw.hangUpForEveryone;
    if (!value || typeof value !== "object")
      return;
    const capability = value;
    const rawLobby = raw.manageLobby;
    const lobby = rawLobby && typeof rawLobby === "object" ? rawLobby : undefined;
    return {
      ...lobby ? {
        manageLobby: {
          allowed: typeof lobby.allowed === "boolean" ? lobby.allowed : null,
          reason: typeof lobby.reason === "string" && lobby.reason ? lobby.reason : null
        }
      } : {},
      hangUpForEveryone: {
        allowed: typeof capability.allowed === "boolean" ? capability.allowed : null,
        reason: typeof capability.reason === "string" && capability.reason ? capability.reason : null
      }
    };
  }
  var SOFTAP_STEPS = new Set(["hotspot", "scopedJoin", "acsJoin", "publish", "live"]);
  var SOFTAP_STEP_STATUSES = new Set(["pending", "running", "done", "failed"]);
  var SOFTAP_PHASES = new Set(["idle", "starting", "recovering", "live", "stopping", "failed"]);
  function parseMeetingSoftApProgress(raw) {
    if (!raw || typeof raw !== "object")
      return;
    const value = raw;
    if (!SOFTAP_PHASES.has(String(value.phase)) || !Array.isArray(value.steps))
      return;
    const steps = [];
    for (const entry of value.steps) {
      if (!entry || typeof entry !== "object")
        continue;
      const step = entry;
      if (!SOFTAP_STEPS.has(String(step.step)) || !SOFTAP_STEP_STATUSES.has(String(step.status)))
        continue;
      steps.push({
        step: step.step,
        status: step.status,
        detail: typeof step.detail === "string" && step.detail ? step.detail : undefined,
        error: typeof step.error === "string" && step.error ? step.error : undefined,
        durationMs: typeof step.durationMs === "number" && Number.isFinite(step.durationMs) ? step.durationMs : undefined
      });
    }
    return {
      traceId: typeof value.traceId === "string" && value.traceId ? value.traceId : undefined,
      phase: value.phase,
      steps,
      elapsedMs: typeof value.elapsedMs === "number" && Number.isFinite(value.elapsedMs) ? value.elapsedMs : 0
    };
  }
  function parseMeetingRecovery(raw) {
    if (!raw || typeof raw !== "object")
      return;
    const value = raw;
    if (typeof value.active !== "boolean")
      return;
    const generation = typeof value.generation === "number" && Number.isFinite(value.generation) ? value.generation : undefined;
    const deadlineAt = typeof value.deadlineAt === "number" && Number.isFinite(value.deadlineAt) ? value.deadlineAt : undefined;
    const phase = typeof value.phase === "string" && value.phase ? value.phase : undefined;
    return {
      active: value.active,
      ...generation !== undefined ? { generation } : {},
      ...deadlineAt !== undefined ? { deadlineAt } : {},
      ...phase ? { phase } : {}
    };
  }
  var PARTICIPANT_STATES = new Set([
    "idle",
    "connecting",
    "connected",
    "lobby",
    "hold",
    "disconnected"
  ]);
  var MEDIA_SOURCES = new Set(["idle", "connecting", "live", "failed"]);
  function parseMeetingMediaSource(raw) {
    return MEDIA_SOURCES.has(String(raw)) ? raw : undefined;
  }
  function parseMeetingParticipants(raw) {
    if (!Array.isArray(raw))
      return;
    const result = [];
    for (const entry of raw) {
      if (!entry || typeof entry !== "object")
        continue;
      const value = entry;
      if (typeof value.id !== "string" || !value.id)
        continue;
      result.push({
        id: value.id,
        displayName: typeof value.displayName === "string" && value.displayName ? value.displayName : null,
        state: PARTICIPANT_STATES.has(String(value.state)) ? value.state : "idle",
        isMuted: Boolean(value.isMuted),
        isSpeaking: Boolean(value.isSpeaking)
      });
    }
    return result;
  }
  var stillSeq = 0;
  function mintStillId() {
    stillSeq = (stillSeq + 1) % 65535;
    return `still-${Date.now().toString(36)}-${stillSeq.toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
  }
  var STILL_FAILURES = new Set([
    "unsupported",
    "not_live",
    "busy",
    "glasses_rejected",
    "upload_timeout",
    "hold_failed",
    "cancelled"
  ]);
  function toStillError(error) {
    const raw = error && typeof error === "object" ? error : {};
    const code = typeof raw.code === "string" ? raw.code : MiniappErrorCode.INTERNAL;
    const message = typeof raw.message === "string" ? raw.message : String(error);
    let reason;
    if (typeof raw.reason === "string" && STILL_FAILURES.has(raw.reason))
      reason = raw.reason;
    else if (code === MiniappErrorCode.NOT_IMPLEMENTED)
      reason = "unsupported";
    else if (code === MiniappErrorCode.REQUEST_ABORTED)
      reason = "cancelled";
    else
      reason = "glasses_rejected";
    return { code, message, reason };
  }
  function isMiniappRequestError(error) {
    return Boolean(error && typeof error === "object" && "code" in error);
  }
  function mapHostError(error) {
    if (isMiniappRequestError(error) && error.code === MiniappErrorCode.NOT_IMPLEMENTED) {
      throw { code: MiniappErrorCode.NOT_IMPLEMENTED, message: MEETING_HOST_UPDATE_MESSAGE };
    }
    throw error;
  }

  class MeetingModule {
    constructor(session) {
      this.session = session;
      this._state = { state: "idle", muted: false };
    }
    get state() {
      return { ...this._state };
    }
    async join(options) {
      if (options.provider !== "acs-teams") {
        throw { code: MiniappErrorCode.INVALID_ARGUMENT, message: `Unsupported meeting provider: ${options.provider}` };
      }
      if (!options.meetingUrl?.trim()) {
        throw { code: MiniappErrorCode.INVALID_ARGUMENT, message: "meetingUrl is required" };
      }
      const videoSource = validateMeetingVideoSource(options.videoSource);
      try {
        const result = await this.session.sendRequest({
          type: MiniappRequestType.MEETING_JOIN,
          provider: options.provider,
          meetingUrl: options.meetingUrl,
          videoSource,
          ...options.token ? { token: options.token } : {},
          displayName: options.displayName,
          ...options.origin ? { origin: options.origin } : {},
          ...options.video ? { video: options.video } : {}
        }, { timeoutMs: 0 });
        if (result)
          this._applyState(result);
        return this.state;
      } catch (error) {
        mapHostError(error);
      }
    }
    async getConfiguration() {
      return this.session.sendRequest({ type: MiniappRequestType.MEETING_GET_CONFIGURATION });
    }
    async getIdentity() {
      try {
        return await this.session.sendRequest({ type: MiniappRequestType.MEETING_GET_IDENTITY }, { timeoutMs: 30000 });
      } catch (error) {
        mapHostError(error);
      }
    }
    async create(options) {
      if (options.provider !== "acs-teams") {
        throw { code: MiniappErrorCode.INVALID_ARGUMENT, message: "Unsupported meeting provider" };
      }
      try {
        return await this.session.sendRequest({
          type: MiniappRequestType.MEETING_CREATE,
          provider: options.provider,
          subject: options.subject,
          durationMinutes: options.durationMinutes
        }, { timeoutMs: 0 });
      } catch (error) {
        mapHostError(error);
      }
    }
    async retire(meetingRef) {
      try {
        await this.session.sendRequest({ type: MiniappRequestType.MEETING_RETIRE, meetingRef }, { timeoutMs: 0 });
      } catch (error) {
        mapHostError(error);
      }
    }
    async leave() {
      try {
        await this.session.sendRequest({ type: MiniappRequestType.MEETING_LEAVE });
      } catch (error) {
        mapHostError(error);
      }
    }
    async pauseVideoPublisher(options) {
      try {
        return await this.session.sendRequest({
          type: MiniappRequestType.MEETING_PAUSE_VIDEO_PUBLISHER,
          reason: options.reason
        });
      } catch (error) {
        mapHostError(error);
      }
    }
    async resumeVideoPublisher(pauseId) {
      try {
        await this.session.sendRequest({
          type: MiniappRequestType.MEETING_RESUME_VIDEO_PUBLISHER,
          pauseId
        });
      } catch (error) {
        mapHostError(error);
      }
    }
    async showCard(options) {
      try {
        await this.session.sendRequest({
          type: MiniappRequestType.MEETING_SHOW_CARD,
          kind: options.kind
        });
      } catch (error) {
        mapHostError(error);
      }
    }
    async showImage(options) {
      try {
        return await this.session.sendRequest({
          type: MiniappRequestType.MEETING_SHOW_IMAGE,
          imageUrl: options.imageUrl,
          durationMs: options.durationMs
        });
      } catch (error) {
        mapHostError(error);
      }
    }
    async showLive() {
      try {
        await this.session.sendRequest({ type: MiniappRequestType.MEETING_SHOW_LIVE });
      } catch (error) {
        mapHostError(error);
      }
    }
    async captureStill(options) {
      const stillId = mintStillId();
      const onProgress = options.onProgress;
      const unsubscribe = onProgress ? this.session.on("meetingStill", (event) => {
        if (event.stillId === stillId)
          onProgress(event.phase);
      }) : undefined;
      try {
        return await this.session.sendRequest({ type: MiniappRequestType.MEETING_CAPTURE_STILL, durationMs: options.durationMs, stillId }, { timeoutMs: options.durationMs + 75000 });
      } catch (error) {
        throw toStillError(error);
      } finally {
        unsubscribe?.();
      }
    }
    async end() {
      try {
        await this.session.sendRequest({ type: MiniappRequestType.MEETING_END }, { timeoutMs: 0 });
      } catch (error) {
        mapHostError(error);
      }
    }
    async admit(participantId) {
      if (!participantId.trim())
        throw new Error("A participant ID is required");
      try {
        await this.session.sendRequest({ type: MiniappRequestType.MEETING_ADMIT, participantId });
      } catch (error) {
        mapHostError(error);
      }
    }
    async setMuted(muted) {
      try {
        const result = await this.session.sendRequest({
          type: MiniappRequestType.MEETING_SET_MUTED,
          muted
        });
        if (result)
          this._applyState(result);
      } catch (error) {
        mapHostError(error);
      }
    }
    async setVideoEnabled(enabled) {
      try {
        const result = await this.session.sendRequest({
          type: MiniappRequestType.MEETING_SET_VIDEO_ENABLED,
          enabled
        });
        if (result)
          this._applyState(result);
      } catch (error) {
        mapHostError(error);
      }
    }
    async updateVideoSource(source) {
      const validated = validateMeetingVideoSource(source);
      if (validated.type !== "whep") {
        throw {
          code: MiniappErrorCode.INVALID_ARGUMENT,
          message: "updateVideoSource accepts a WHEP source; a SoftAP call recovers by rejoining"
        };
      }
      try {
        await this.session.sendRequest({
          type: MiniappRequestType.MEETING_UPDATE_VIDEO_SOURCE,
          videoSource: validated
        });
      } catch (error) {
        mapHostError(error);
      }
    }
    async getState() {
      try {
        const result = await this.session.sendRequest({
          type: MiniappRequestType.MEETING_GET_STATE
        });
        if (result)
          this._applyState(result);
        return this.state;
      } catch (error) {
        mapHostError(error);
      }
    }
    onState(handler) {
      return this.session.on("meetingState", handler);
    }
    onVideoPublisher(handler) {
      return this.session.on("meetingVideoPublisher", handler);
    }
    _applyState(event) {
      this._state = {
        identityMode: event.identityMode === "guest" || event.identityMode === "teams-user" ? event.identityMode : this._state.identityMode,
        guestReason: event.identityMode === "guest" ? event.guestReason : event.identityMode === "teams-user" ? undefined : this._state.guestReason,
        state: event.state,
        muted: Boolean(event.muted),
        videoEnabled: typeof event.videoEnabled === "boolean" ? event.videoEnabled : undefined,
        error: event.error,
        endReason: parseMeetingEndReason(event.endReason),
        meetingUrl: event.meetingUrl,
        provider: event.provider,
        audioSource: event.audioSource,
        audioSourceReason: event.audioSourceReason,
        activeStream: event.activeStream,
        audioSafety: event.audioSafety,
        mediaSource: parseMeetingMediaSource(event.mediaSource),
        participants: parseMeetingParticipants(event.participants),
        capabilities: parseMeetingCapabilities(event.capabilities) ?? this._state.capabilities,
        softap: parseMeetingSoftApProgress(event.softap),
        recovery: parseMeetingRecovery(event.recovery) ?? this._state.recovery
      };
    }
  }

  // ../vendor/miniapp/dist/session.js
  var ALL_PERMISSION_TYPES = [
    "location",
    "microphone",
    "camera",
    "notifications",
    "calendar"
  ];

  class NotConnectedError extends Error {
    constructor(message = "MiniappSession is not connected") {
      super(message);
      this.code = MiniappErrorCode.NOT_CONNECTED;
      this.name = "NotConnectedError";
    }
  }
  var DEFAULT_CONNECT_TIMEOUT_MS = 1e4;
  var DEFAULT_REQUEST_TIMEOUT_MS = 60000;

  class MiniappSession {
    constructor(options = {}) {
      this.capabilities = null;
      this.hostFeatures = null;
      this.userId = "";
      this.packageName = "";
      this.visibility = "foreground";
      this.colorScheme = "light";
      this.ready = false;
      this.emitter = new import__.default;
      this.authState = null;
      this.configurationState = {};
      this.authWaiters = new Set;
      this.authRefreshPromise = null;
      this.outboundQueue = [];
      this.pendingRequests = new Map;
      this.connectPromise = null;
      this.disposed = false;
      this._permissions = {
        location: false,
        microphone: false,
        camera: false,
        notifications: false,
        calendar: false
      };
      this.transport = createTransport(options);
      this.connectTimeoutMs = options.connectTimeoutMs ?? DEFAULT_CONNECT_TIMEOUT_MS;
      const injected = getMentraOSGlobals();
      this.packageName = options.packageName ?? injected.packageName ?? "";
      if (injected.colorScheme === "light" || injected.colorScheme === "dark") {
        this.colorScheme = injected.colorScheme;
      }
      this.auth = new AuthModule(this);
      this.configuration = new ConfigurationModule(this);
      this.events = new EventManager(this);
      this.speaker = new SpeakerModule(this);
      this.meeting = new MeetingModule(this);
      this.camera = new CameraModule(this);
      this.cloud = new CloudModule(this);
      this.dashboard = new DashboardAPI(this);
      this.display = new DisplayManager(this);
      this.glasses = new GlassesModule(this);
      this.heading = new HeadingModule(this);
      this.imu = new ImuModule(this);
      this.input = new InputModule(this);
      this.led = new LedModule(this);
      this.location = new LocationModule(this);
      this.mic = new MicModule(this);
      this.navigation = new NavigationModule(this);
      this.permissions = new PermissionsModule(this);
      this.phone = new PhoneModule(this);
      this.storage = new SimpleStorage(this);
      this.blob = new BlobModule(this);
      this.stream = new StreamModule(this);
      this.system = new SystemModule(this);
      this.transcription = new TranscriptionModule(this);
      this.translation = new TranslationModule(this);
      this.ui = new UIModuleImpl(this);
      this.miniapps = new MiniappsModule(this);
      this.actions = new ActionsModule(this);
    }
    _hasManifestPermission(manifestKey) {
      const canonical = manifestKeyToCanonical(manifestKey);
      if (!canonical)
        return false;
      return this._permissions[canonical] === true;
    }
    _getPermissions() {
      return { ...this._permissions };
    }
    _getAuth() {
      return this.authState ? { ...this.authState } : null;
    }
    _getConfiguration() {
      return { ...this.configurationState };
    }
    _waitForAuth(minTtlMs, timeoutMs = 1e4) {
      const current = this.authState;
      if (current && this.authHasTtl(current, minTtlMs)) {
        return Promise.resolve({ ...current });
      }
      this.requestAuthRefresh(minTtlMs);
      return new Promise((resolve, reject) => {
        const waiter = {
          minTtlMs,
          resolve,
          reject,
          timer: setTimeout(() => {
            this.authWaiters.delete(waiter);
            reject(new NotConnectedError("Miniapp auth token is not available"));
          }, timeoutMs)
        };
        this.authWaiters.add(waiter);
      });
    }
    _subscribe(streamType, handler, options = {}) {
      return this.events.subscribe(streamType, handler, options);
    }
    connect() {
      if (this.disposed) {
        return Promise.reject(new NotConnectedError("MiniappSession was disposed"));
      }
      if (this.connectPromise)
        return this.connectPromise;
      const readyPromise = new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
          const err = new Error("MiniappSession: CONNECT_ACK timeout");
          this.failAllPending({ code: MiniappErrorCode.NOT_CONNECTED, message: err.message });
          this.emitter.emit("error", err);
          reject(err);
        }, this.connectTimeoutMs);
        this.emitter.once("ready", () => {
          clearTimeout(timer);
          resolve();
        });
        this.emitter.once("error", (err) => {
          clearTimeout(timer);
          reject(err);
        });
      });
      this.connectPromise = (async () => {
        this.transport.onMessage((raw) => this.handleIncoming(raw));
        this.transport.onDisconnect((reason) => this.handleTransportDisconnect(reason));
        await this.transport.open();
        const requestId = makeRequestId();
        const connectPayload = {
          type: MiniappRequestType.CONNECT,
          packageName: this.packageName
        };
        this.transport.send(serializeEnvelope({ payload: connectPayload, requestId }));
        await readyPromise;
      })();
      return this.connectPromise;
    }
    waitForReady() {
      if (this.ready)
        return Promise.resolve();
      return this.connect();
    }
    isConnected() {
      return this.ready && this.transport.isOpen();
    }
    disconnect() {
      if (this.disposed)
        return;
      this.disposed = true;
      try {
        this.emitter.emit("beforeDisconnect", "disconnect called");
      } catch (err) {
        console.warn("[MiniappSession] beforeDisconnect handler threw:", err);
      }
      this.failAllPending({ code: MiniappErrorCode.REQUEST_ABORTED, message: "Session disconnected" });
      try {
        this.transport.close();
      } catch {}
      this.ready = false;
      this.emitter.emit("disconnect", "disconnect called");
    }
    sendOneShot(payload) {
      const envelope = { payload };
      this.enqueueOrSend(serializeEnvelope(envelope));
    }
    sendRequest(payload, opts) {
      if (this.disposed) {
        return Promise.reject(new NotConnectedError);
      }
      const requestId = makeRequestId();
      const envelope = { payload, requestId };
      const timeoutMs = opts?.timeoutMs ?? DEFAULT_REQUEST_TIMEOUT_MS;
      return new Promise((resolve, reject) => {
        const timer = timeoutMs > 0 ? setTimeout(() => {
          const pending = this.pendingRequests.get(requestId);
          if (!pending)
            return;
          this.pendingRequests.delete(requestId);
          pending.reject({
            code: MiniappErrorCode.ACTION_TIMEOUT,
            message: "Request timed out waiting for a response from the host"
          });
        }, timeoutMs) : undefined;
        this.pendingRequests.set(requestId, {
          requestId,
          resolve,
          reject,
          timer
        });
        this.enqueueOrSend(serializeEnvelope(envelope));
      });
    }
    on(event, handler) {
      this.emitter.on(event, handler);
      return () => this.emitter.off(event, handler);
    }
    off(event, handler) {
      this.emitter.off(event, handler);
    }
    onBeforeDisconnect(handler) {
      return this.on("beforeDisconnect", handler);
    }
    onVisibilityChange(handler) {
      return this.on("visibility", handler);
    }
    onCapabilitiesChange(handler) {
      return this.on("capabilities", handler);
    }
    onColorSchemeChange(handler) {
      return this.on("colorScheme", handler);
    }
    enqueueOrSend(raw) {
      if (this.ready) {
        try {
          this.transport.send(raw);
        } catch (err) {
          this.emitter.emit("error", err);
        }
        return;
      }
      this.outboundQueue.push(raw);
    }
    flushQueue() {
      const queue = this.outboundQueue.splice(0);
      for (const raw of queue) {
        try {
          this.transport.send(raw);
        } catch (err) {
          this.emitter.emit("error", err);
        }
      }
    }
    handleIncoming(raw) {
      const envelope = parseEnvelope(raw);
      if (!envelope)
        return;
      const payload = envelope.payload;
      const type = payload?.type;
      switch (type) {
        case MiniappResponseType.CONNECT_ACK: {
          const ack = payload;
          this.userId = ack.userId ?? "";
          if (ack.packageName)
            this.packageName = ack.packageName;
          this.capabilities = ack.capabilities ?? null;
          this.hostFeatures = ack.hostFeatures ?? null;
          if (ack.visibility)
            this.visibility = ack.visibility;
          if (ack.colorScheme === "light" || ack.colorScheme === "dark") {
            this.colorScheme = ack.colorScheme;
          }
          if (ack.auth) {
            this.applyAuth(ack.auth);
            if (!this.userId)
              this.userId = ack.auth.mentraUserId;
          }
          this.configurationState = Object.freeze({ ...ack.configuration });
          if (ack.permissions)
            this.applyPermissions(ack.permissions);
          this.ready = true;
          this.flushQueue();
          this.emitter.emit("ready");
          return;
        }
        case MiniappResponseType.AUTH_UPDATE: {
          const next = payload.auth;
          if (next) {
            this.applyAuth(next);
            if (!this.userId)
              this.userId = next.mentraUserId;
          }
          return;
        }
        case MiniappResponseType.PERMISSIONS_UPDATE: {
          const next = payload.permissions;
          if (next)
            this.applyPermissions(next);
          return;
        }
        case MiniappResponseType.SPEAKER_STATE: {
          const state = payload.state;
          if (!state)
            return;
          const event = {
            state,
            errorCode: payload.errorCode,
            errorMessage: payload.errorMessage,
            durationMs: payload.durationMs
          };
          this.speaker._applyState(event);
          this.emitter.emit("speakerState", event);
          return;
        }
        case MiniappResponseType.MEETING_STATE: {
          const state = payload.state;
          if (!state)
            return;
          const identityMode = payload.identityMode === "guest" || payload.identityMode === "teams-user" ? payload.identityMode : undefined;
          const event = {
            state,
            identityMode,
            guestReason: identityMode === "guest" ? payload.guestReason : undefined,
            muted: Boolean(payload.muted),
            videoEnabled: typeof payload.videoEnabled === "boolean" ? payload.videoEnabled : undefined,
            error: payload.error,
            meetingUrl: payload.meetingUrl,
            provider: payload.provider,
            audioSource: payload.audioSource,
            audioSourceReason: payload.audioSourceReason,
            activeStream: payload.activeStream,
            audioSafety: payload.audioSafety,
            mediaSource: parseMeetingMediaSource(payload.mediaSource),
            endReason: parseMeetingEndReason(payload.endReason),
            participants: parseMeetingParticipants(payload.participants),
            capabilities: parseMeetingCapabilities(payload.capabilities),
            softap: parseMeetingSoftApProgress(payload.softap),
            recovery: parseMeetingRecovery(payload.recovery)
          };
          this.meeting._applyState(event);
          this.emitter.emit("meetingState", event);
          return;
        }
        case MiniappResponseType.MEETING_VIDEO_PUBLISHER: {
          const pauseId = typeof payload.pauseId === "string" ? payload.pauseId : "";
          if (!pauseId || payload.status !== "expired")
            return;
          const event = { pauseId, status: "expired" };
          this.emitter.emit("meetingVideoPublisher", event);
          return;
        }
        case MiniappResponseType.MEETING_STILL: {
          const stillId = typeof payload.stillId === "string" ? payload.stillId : "";
          const phase = payload.phase;
          if (!stillId || phase !== "card" && phase !== "uploading" && phase !== "shown")
            return;
          this.emitter.emit("meetingStill", { stillId, phase });
          return;
        }
        case MiniappResponseType.STREAM_PREVIEW_STATUS: {
          this.stream._applyPreviewStatus(payload);
          return;
        }
        case MiniappRequestType.PING: {
          const pong = { type: MiniappResponseType.PONG };
          const env = {
            payload: pong,
            ...envelope.requestId ? { requestId: envelope.requestId } : {}
          };
          try {
            this.transport.send(serializeEnvelope(env));
          } catch {}
          return;
        }
        case MiniappResponseType.EVENT: {
          const streamType = payload.streamType;
          if (!streamType)
            return;
          this.events._forwardEvent(streamType, payload.data, payload.transcriptionRoute);
          return;
        }
        case MiniappResponseType.ACTION_CALL: {
          const callId = payload.callId;
          const actionId = payload.actionId;
          if (!callId || !actionId)
            return;
          const params = payload.params ?? {};
          const callerPackageName = payload.callerPackageName ?? "";
          this.actions._deliver(callId, actionId, params, { callerPackageName });
          return;
        }
        case MiniappResponseType.CAPABILITIES_UPDATE: {
          const cap = payload.capabilities ?? null;
          this.capabilities = cap;
          this.emitter.emit("capabilities", cap);
          return;
        }
        case MiniappResponseType.VISIBILITY_CHANGE: {
          const next = payload.visibility;
          if (next === "foreground" || next === "background") {
            this.visibility = next;
            this.emitter.emit("visibility", next);
          }
          return;
        }
        case MiniappResponseType.COLOR_SCHEME_CHANGE: {
          const next = payload.colorScheme;
          if (next === "light" || next === "dark") {
            this.colorScheme = next;
            this.emitter.emit("colorScheme", next);
          }
          return;
        }
        case MiniappResponseType.REQUEST_RESULT: {
          const requestId = envelope.requestId;
          if (!requestId)
            return;
          const pending = this.pendingRequests.get(requestId);
          if (!pending)
            return;
          this.pendingRequests.delete(requestId);
          if (pending.timer)
            clearTimeout(pending.timer);
          if (payload.ok === false) {
            const err = payload.error ?? {
              code: MiniappErrorCode.INTERNAL,
              message: "Unknown error"
            };
            pending.reject(err);
          } else {
            pending.resolve(payload.data ?? null);
          }
          return;
        }
        case MiniappResponseType.WILL_DISCONNECT: {
          const reason = payload.reason ?? "phone unregistering";
          try {
            this.emitter.emit("beforeDisconnect", reason);
          } catch (err) {
            console.warn("[MiniappSession] beforeDisconnect handler threw:", err);
          }
          return;
        }
        case MiniappResponseType.ERROR: {
          const err = new Error(payload.message ?? "MiniappSession error");
          this.emitter.emit("error", err);
          return;
        }
        default:
          return;
      }
    }
    handleTransportDisconnect(reason) {
      this.ready = false;
      this.failAllPending({ code: MiniappErrorCode.NOT_CONNECTED, message: `Transport disconnected: ${reason}` });
      this.emitter.emit("disconnect", reason);
    }
    failAllPending(error) {
      for (const pending of this.pendingRequests.values()) {
        if (pending.timer)
          clearTimeout(pending.timer);
        pending.reject(error);
      }
      this.pendingRequests.clear();
      for (const waiter of Array.from(this.authWaiters)) {
        clearTimeout(waiter.timer);
        this.authWaiters.delete(waiter);
        waiter.reject(new NotConnectedError(error.message));
      }
    }
    authHasTtl(auth, minTtlMs) {
      return auth.expiresAt - Date.now() > minTtlMs;
    }
    requestAuthRefresh(minTtlMs) {
      if (this.authRefreshPromise)
        return this.authRefreshPromise;
      if (!this.ready || !this.transport.isOpen())
        return Promise.resolve(null);
      this.authRefreshPromise = this.sendRequest({
        type: MiniappRequestType.AUTH_REFRESH,
        minTtlMs
      }).then((result) => {
        const auth = result?.auth;
        if (auth)
          this.applyAuth(auth);
        return auth ?? null;
      }).catch((err) => {
        console.warn("[MiniappSession] auth refresh failed:", err);
        return null;
      }).finally(() => {
        this.authRefreshPromise = null;
      });
      return this.authRefreshPromise;
    }
    applyAuth(next) {
      this.authState = { ...next };
      for (const waiter of Array.from(this.authWaiters)) {
        if (!this.authHasTtl(next, waiter.minTtlMs))
          continue;
        clearTimeout(waiter.timer);
        this.authWaiters.delete(waiter);
        waiter.resolve({ ...next });
      }
      this.emitter.emit("auth", { ...next });
    }
    applyPermissions(next) {
      let changed = false;
      const updated = { ...this._permissions };
      for (const k of ALL_PERMISSION_TYPES) {
        const v = next[k] === true;
        if (updated[k] !== v) {
          updated[k] = v;
          changed = true;
        }
      }
      if (changed) {
        this._permissions = updated;
        this.emitter.emit("permissions", { ...updated });
      }
    }
  }
  function manifestKeyToCanonical(manifestKey) {
    switch (manifestKey.toUpperCase()) {
      case "MICROPHONE":
        return "microphone";
      case "CAMERA":
        return "camera";
      case "LOCATION":
      case "BACKGROUND_LOCATION":
        return "location";
      case "READ_NOTIFICATIONS":
      case "POST_NOTIFICATIONS":
        return "notifications";
      case "CALENDAR":
        return "calendar";
      default:
        return null;
    }
  }

  // ../vendor/miniapp/dist/background/register.js
  function registerMiniapp(handler, options = {}) {
    const g = globalThis;
    g.__mentraInitCallback = (_sessionId) => {
      const session = new MiniappSession(options);
      try {
        const result = handler(session);
        if (result && typeof result.then === "function") {
          result.catch((err) => {
            console.error("[mentra-miniapp] registerMiniapp handler rejected:", err);
          });
        }
      } catch (err) {
        console.error("[mentra-miniapp] registerMiniapp handler threw:", err);
      }
      session.connect().catch((err) => {
        console.error("[mentra-miniapp] session.connect() rejected:", err);
        try {
          const message = err instanceof Error ? err.message : String(err);
          const stack = err instanceof Error && err.stack ? err.stack : "";
          g.__hostError?.(JSON.stringify({ message: `session.connect() failed: ${message}`, stack }));
        } catch {}
      });
    };
  }
  // src/shared/log.ts
  function summarizeStream(stream) {
    if (!stream?.streamId)
      return { present: false };
    return {
      present: true,
      streamId: stream.streamId,
      mode: stream.mode,
      webrtc: Boolean(stream.webrtcUrl),
      hls: Boolean(stream.hlsUrl),
      dash: Boolean(stream.dashUrl)
    };
  }
  function logCall(scope, message, data) {
    if (data)
      console.log(`[mentra-call] [${scope}] ${message}`, data);
    else
      console.log(`[mentra-call] [${scope}] ${message}`);
  }
  function warnCall(scope, message, data) {
    if (data)
      console.warn(`[mentra-call] [${scope}] ${message}`, data);
    else
      console.warn(`[mentra-call] [${scope}] ${message}`);
  }
  var rpcSequence = 0;
  function nextRpcId() {
    return ++rpcSequence;
  }
  function logRpcStart(channel, id, data) {
    logCall("rpc", `→ ${channel} #${id}`, data ? sanitizeSoftapData(data) : undefined);
  }
  function logRpcEnd(channel, id, outcome, ms, data) {
    const payload = { ms: Math.round(ms), ...data ? sanitizeSoftapData(data) : {} };
    if (outcome === "ok")
      logCall("rpc", `← ${channel} #${id} ok`, payload);
    else
      warnCall("rpc", `← ${channel} #${id} ${outcome}`, payload);
  }
  async function tracedRpc(channel, run, describe) {
    const id = nextRpcId();
    const startedAt = Date.now();
    logRpcStart(channel, id, describe?.request);
    try {
      const value = await run();
      logRpcEnd(channel, id, "ok", Date.now() - startedAt, describe?.response?.(value));
      return value;
    } catch (error) {
      const aborted = error instanceof Error && (error.name === "AbortError" || /abort/i.test(error.message));
      logRpcEnd(channel, id, aborted ? "aborted" : "error", Date.now() - startedAt, {
        error: error instanceof Error ? error.message : String(error)
      });
      throw error;
    }
  }
  var lastSeen = new Map;
  function logChange(scope, label, value, data) {
    const encoded = JSON.stringify(value) ?? "undefined";
    const previous = lastSeen.get(label);
    if (previous === encoded)
      return false;
    lastSeen.set(label, encoded);
    const arrow = previous === undefined ? "=" : `${previous} →`;
    logCall(scope, `${label} ${arrow} ${encoded}`, data);
    return true;
  }
  function logJoin(joinId, stage, data) {
    const head = joinId ? `[mentra-call] [join] joinId=${joinId} stage=${stage}` : `[mentra-call] [join] stage=${stage}`;
    if (data)
      console.log(head, data);
    else
      console.log(head);
  }
  var SOFTAP_TRACE_ENABLED = true;
  var SOFTAP_TRACE_MARKER = "SOFTAP_TRACE";
  var SOFTAP_REDACTED = "<redacted>";
  var SOFTAP_SENSITIVE_KEYS = [
    "password",
    "passwd",
    "passphrase",
    "psk",
    "token",
    "secret",
    "credential",
    "authorization",
    "bearer",
    "meetingurl"
  ];
  function stripSoftapUrlSecrets(text) {
    const schemeIndex = text.indexOf("://");
    if (schemeIndex < 0)
      return text;
    let result = text;
    const query = result.indexOf("?");
    if (query >= 0)
      result = `${result.slice(0, query)}?${SOFTAP_REDACTED}`;
    const fragment = result.indexOf("#");
    if (fragment >= 0)
      result = result.slice(0, fragment);
    const at = result.indexOf("@", schemeIndex + 3);
    if (at >= 0) {
      result = `${result.slice(0, schemeIndex + 3)}${SOFTAP_REDACTED}@${result.slice(at + 1)}`;
    }
    return result;
  }
  function sanitizeSoftapField(key, value) {
    const lower = key.toLowerCase();
    if (SOFTAP_SENSITIVE_KEYS.some((sensitive) => lower.includes(sensitive)))
      return SOFTAP_REDACTED;
    if (typeof value === "string")
      return stripSoftapUrlSecrets(value);
    return value;
  }
  function sanitizeSoftapData(data) {
    const result = {};
    for (const [key, value] of Object.entries(data)) {
      result[key] = sanitizeSoftapField(key, value);
    }
    return result;
  }
  function logSoftap(traceId, stage, data) {
    if (!SOFTAP_TRACE_ENABLED)
      return;
    const head = traceId ? `[mentra-call] [${SOFTAP_TRACE_MARKER}] traceId=${traceId} stage=${stage}` : `[mentra-call] [${SOFTAP_TRACE_MARKER}] stage=${stage}`;
    if (data)
      console.log(head, sanitizeSoftapData(data));
    else
      console.log(head);
  }
  var PREVIEW_TRACE_MARKER = "PREVIEW_TRACE";
  function formatPreviewTrace(phase, fields = {}) {
    const parts = [`[mentra-call] [${PREVIEW_TRACE_MARKER}]`, "layer=call", `phase=${phase}`];
    for (const [key, value] of Object.entries(fields)) {
      if (value === undefined)
        continue;
      parts.push(`${key}=${String(sanitizeSoftapField(key, value)).replace(/\s+/g, "_")}`);
    }
    return parts.join(" ");
  }
  function logPreviewTrace(phase, fields) {
    console.log(formatPreviewTrace(phase, fields));
  }
  function warnPreviewTrace(phase, fields) {
    console.warn(formatPreviewTrace(phase, fields));
  }
  function warnSoftap(traceId, stage, data) {
    if (!SOFTAP_TRACE_ENABLED)
      return;
    const head = traceId ? `[mentra-call] [${SOFTAP_TRACE_MARKER}] traceId=${traceId} stage=${stage}` : `[mentra-call] [${SOFTAP_TRACE_MARKER}] stage=${stage}`;
    if (data)
      console.warn(head, sanitizeSoftapData(data));
    else
      console.warn(head);
  }

  // src/background/lib/meeting-identity-cache.ts
  class MeetingIdentityCache {
    load;
    result;
    pending = false;
    constructor(load) {
      this.load = load;
    }
    get(refresh = false) {
      if (!this.result || refresh && !this.pending) {
        this.pending = true;
        this.result = Promise.resolve().then(this.load).finally(() => {
          this.pending = false;
        });
      }
      return this.result;
    }
  }

  // src/background/lib/phone-wifi.ts
  async function preparePhoneWifi(phone) {
    try {
      if (await phone.isWifiEnabled() !== false)
        return true;
      const result = await phone.requestWifiEnable("Wi-Fi is required to join the call. After you turn it on and return, the call continues.");
      if (result.cancelled)
        return false;
      if (result.enabled === false)
        throw new Error("SOFTAP_WIFI_DISABLED: Phone Wi-Fi is off");
      return true;
    } catch (error) {
      if (error?.code === "NOT_IMPLEMENTED")
        return true;
      throw error;
    }
  }

  // src/shared/acs-mic.ts
  var ACS_CALL_MIC = "glasses";
  function describeAcsMic() {
    return { acsMic: ACS_CALL_MIC, glassesCaptureAudio: ACS_CALL_MIC === "glasses" };
  }

  // src/shared/call-transport.ts
  var ACS_CALL_TRANSPORT = "softap";
  function resolveCallTransport(usesAcs, override, directLink = true) {
    if (override)
      return noteTransport(override, "explicit override");
    const pinned = pinnedCallTransport();
    if (pinned)
      return noteTransport(pinned, "MENTRA_PUBLIC_CALL_TRANSPORT pin");
    if (usesAcs && directLink)
      return noteTransport(ACS_CALL_TRANSPORT, "ACS join, Direct link on");
    return noteTransport("cloudflare", usesAcs ? "ACS join, Direct link off" : "not an ACS join");
  }
  function noteTransport(transport, reason) {
    logChange("call", "transport", `${transport} (${reason})`);
    return transport;
  }
  function pinnedCallTransport() {
    const fromEnv = ""?.trim();
    if (fromEnv === "cloudflare" || fromEnv === "softap")
      return fromEnv;
    return null;
  }
  function usesCloudflare(transport) {
    return transport === "cloudflare";
  }
  function callStartCue(origin) {
    return origin === "created" ? "Starting call" : "Joining call";
  }
  var SOFTAP_HOST_STEPS = ["hotspot", "scopedJoin", "acsJoin", "publish", "live"];
  var SOFTAP_STEPS2 = [...SOFTAP_HOST_STEPS, "teams"];
  function initialSoftapProgress() {
    return { phase: "starting", elapsedMs: 0, steps: SOFTAP_STEPS2.map((step) => ({ step, status: "pending" })) };
  }
  var SOFTAP_PREFLIGHT_TOKEN_COPY = "Getting a Teams pass…";
  var SOFTAP_PREFLIGHT_WAIT_COPY = "Preparing the call…";
  var SOFTAP_PREFLIGHT_WIFI_ON_COPY = "Phone Wi-Fi is on";
  function softapAdvanceScore(progress) {
    return progress.steps.reduce((score, step) => {
      if (step.step === "teams")
        return score;
      if (step.status === "done" || step.status === "failed")
        return score + 2;
      if (step.status === "running")
        return score + 1;
      return score;
    }, 0);
  }
  function teamsStepStatus(acsState) {
    if (acsState === "connected")
      return "done";
    if (acsState === "error")
      return "failed";
    if (acsState === "connecting" || acsState === "lobby")
      return "running";
    return "pending";
  }
  function hostChecklistComplete(progress) {
    return SOFTAP_HOST_STEPS.every((name) => progress.steps.some((step) => step.step === name && step.status === "done"));
  }
  function decideTeamsStep(progress, acsState) {
    const raw = teamsStepStatus(acsState);
    const hostComplete = hostChecklistComplete(progress);
    const status = raw === "failed" || raw !== "pending" && hostComplete ? raw : "pending";
    return { raw, status, hostComplete };
  }
  function applyTeamsStep(progress, acsState, origin) {
    const { status } = decideTeamsStep(progress, acsState);
    const waiting = origin === "created" ? "Teams is connecting the meeting." : "Waiting for Teams to admit you.";
    const detail = status === "done" ? "You are in the meeting." : status === "failed" ? undefined : waiting;
    const row = { step: "teams", status, ...detail ? { detail } : {} };
    const others = progress.steps.filter((step) => step.step !== "teams");
    return { ...progress, steps: [...others, row] };
  }
  function isSoftapChecklistRegression(prev, next, recovery) {
    if (!prev)
      return false;
    if (next.traceId && prev.traceId && next.traceId !== prev.traceId)
      return false;
    if (recovery?.generation != null)
      return false;
    return softapAdvanceScore(next) < softapAdvanceScore(prev);
  }
  function isSoftapRecoveryActive(recovery) {
    return Boolean(recovery?.active);
  }
  function softapPreflightProgress(detail) {
    const initial = initialSoftapProgress();
    logSoftap(undefined, "preflight", { detail });
    return { ...initial, steps: initial.steps.map((step) => step.step === "hotspot" ? { ...step, detail } : step) };
  }
  function softapStepChanges(prev, next) {
    return next.steps.filter((step) => {
      const before = prev?.steps.find((entry) => entry.step === step.step);
      return !before || before.status !== step.status || before.detail !== step.detail || before.error !== step.error;
    });
  }
  var PHONE_WIFI_OFF_COPY = "Turn on Wi-Fi on this phone. Stay on cellular for internet — Mentra joins the glasses hotspot itself.";
  function isPhoneWifiOffError(message) {
    return /SOFTAP_WIFI_DISABLED|WifiDisabled|Phone'?s? Wi-Fi is off/i.test(message) || message === PHONE_WIFI_OFF_COPY;
  }
  function isSoftapUnavailableError(message) {
    return /SOFTAP_UNAVAILABLE|ScopedNetworkError\$Unavailable|SSID not in scan, Wi-Fi off, or the system join prompt/i.test(message);
  }
  var SOFTAP_UNAVAILABLE_COPY = "This phone saw the glasses hotspot but couldn't join it. The glasses may still be resetting from the last attempt — wait a few seconds and try again.";
  function isPhoneVpnError(message) {
    return /SOFTAP_VPN_ACTIVE|VpnCapturesApp|VPN is routing this app|VPN is capturing this app/i.test(message);
  }
  function stripHostErrorFraming(message) {
    const parts = message.split(/\s*→\s*Caused by:\s*/i);
    const innermost = parts[parts.length - 1]?.trim() ?? message;
    return innermost.replace(/^Call to function '[^']*' has been rejected\.?\s*/i, "").trim() || message;
  }
  function isSoftapNetworkLost(message) {
    return Boolean(message) && /SOFTAP_NETWORK_LOST/i.test(message);
  }
  function softapLostCopy(message) {
    const detail = stripHostErrorFraming((message ?? "").replace(/^SOFTAP_NETWORK_LOST:\s*/i, "")).trim();
    const base = "The glasses hotspot dropped, so the video link is gone. Rejoin to start a new one.";
    return detail ? `${base} (${detail})` : base;
  }
  function isSoftapNoCandidatesError(message) {
    return /no_candidates_gathered/i.test(message ?? "");
  }
  function isSoftapOffHotspotError(message) {
    return /only_non_hotspot_candidates/i.test(message ?? "");
  }
  function isLegacySoftapCandidateError(message) {
    return /no_softap_host_candidate/i.test(message ?? "");
  }
  var SOFTAP_NO_CANDIDATES_COPY = "This phone joined the glasses hotspot but couldn't open a video port on it. Restart the glasses and try again.";
  var SOFTAP_OFF_HOTSPOT_COPY = "This phone answered on its cellular network instead of the glasses hotspot, so the video has nowhere to go. Turn phone Wi-Fi off and on, then try again.";
  var SOFTAP_CANDIDATE_COPY = "The video link between this phone and the glasses couldn't be set up. Restart the glasses and try again.";
  function isPhoneNoCellularError(message) {
    return /SOFTAP_NO_CELLULAR_INTERNET/i.test(message ?? "");
  }
  var PHONE_NO_CELLULAR_COPY = "Turn on mobile data. Joining the glasses hotspot takes this phone off Wi-Fi, so the call needs cellular for internet.";
  function humanizeSoftapJoinError(message) {
    const classified = (kind, copy) => {
      warnCall("call", "softap join failure classified", { kind });
      return copy;
    };
    if (isPhoneWifiOffError(message)) {
      return classified("phone-wifi-off", PHONE_WIFI_OFF_COPY);
    }
    if (isSoftapUnavailableError(message))
      return classified("softap-unavailable", SOFTAP_UNAVAILABLE_COPY);
    if (isPhoneVpnError(message))
      return classified("phone-vpn", "");
    if (isPhoneNoCellularError(message))
      return classified("phone-no-cellular", PHONE_NO_CELLULAR_COPY);
    if (isSoftapNoCandidatesError(message))
      return classified("no-candidates", SOFTAP_NO_CANDIDATES_COPY);
    if (isSoftapOffHotspotError(message))
      return classified("off-hotspot", SOFTAP_OFF_HOTSPOT_COPY);
    if (isLegacySoftapCandidateError(message))
      return classified("legacy-candidate", SOFTAP_CANDIDATE_COPY);
    if (isSoftapNetworkLost(message))
      return classified("network-lost", softapLostCopy(message));
    if (message.includes("hotspot dropped"))
      return classified("network-lost", message);
    return classified("unclassified", stripHostErrorFraming(message));
  }

  // src/shared/meeting-api.ts
  function hasMeetingApi(session) {
    return typeof session.meeting?.join === "function";
  }
  function describeMeetingApi(session) {
    const meeting = session.meeting;
    if (meeting == null) {
      return { present: false, type: String(meeting), join: "missing", getState: "missing", keys: [] };
    }
    const record = meeting;
    return {
      present: true,
      type: typeof meeting,
      join: typeof record.join,
      getState: typeof record.getState,
      keys: Object.keys(meeting)
    };
  }
  function logMeetingHostSelection(session) {
    const present = hasMeetingApi(session);
    const detail = describeMeetingApi(session);
    if (present)
      logCall("boot", "meeting host: native session.meeting.join", detail);
    else
      warnCall("boot", "meeting host: none — bundled SDK has no session.meeting.join", detail);
    return present;
  }

  // src/shared/meeting-hosts.ts
  var JOIN_PATH_BUILD = "acs-path-v3";
  function explainJoinRoute(meetingUrl, teamsProvider) {
    const hostname = hostnameFromMeetingUrl(meetingUrl);
    const platform = platformFromUrl(meetingUrl);
    const urlCtor = typeof URL === "function";
    const usesAcs = teamsProvider === "acs" && platform === "microsoft-teams" && Boolean(hostname && isAcsTeamsHost(hostname));
    let reason;
    if (usesAcs) {
      reason = "ACS: TEAMS_PROVIDER=acs and work Teams host";
    } else if (teamsProvider !== "acs") {
      reason = `Recall: TEAMS_PROVIDER=${teamsProvider}`;
    } else if (!hostname) {
      reason = "Recall: could not parse hostname from meeting URL";
    } else if (hostname === "teams.live.com" || hostname.endsWith(".teams.live.com")) {
      reason = "Recall: teams.live.com is Teams for Home; ACS only joins Microsoft 365 work meetings";
    } else if (platform !== "microsoft-teams") {
      reason = `Recall: platform=${platform ?? "null"} host=${hostname}`;
    } else {
      reason = "Recall: unexpected (provider is acs and platform is Teams)";
    }
    const decision = {
      build: JOIN_PATH_BUILD,
      teamsProvider,
      hostname,
      platform,
      urlCtor,
      usesAcs,
      route: usesAcs ? "acs" : "recall",
      reason
    };
    logChange("meeting", "join route", `${decision.route} — ${reason}`, {
      build: JOIN_PATH_BUILD,
      host: hostname ?? "unparseable",
      platform: platform ?? "unrecognised",
      urlCtor
    });
    return decision;
  }
  function isTeamsHost(host) {
    const h = host.toLowerCase();
    return isAcsTeamsHost(h) || h === "teams.live.com" || h.endsWith(".teams.live.com");
  }
  function isAcsTeamsHost(host) {
    const h = host.toLowerCase();
    return h === "teams.microsoft.com" || h.endsWith(".teams.microsoft.com") || h === "teams.cloud.microsoft" || h.endsWith(".teams.cloud.microsoft");
  }
  function hostnameFromMeetingUrl(url) {
    const match = url.trim().match(/^https?:\/\/([^/?#]+)/i);
    if (!match)
      return null;
    let host = match[1];
    const at = host.lastIndexOf("@");
    if (at >= 0)
      host = host.slice(at + 1);
    if (host.startsWith("[")) {
      const end = host.indexOf("]");
      if (end < 0)
        return null;
      return host.slice(1, end).toLowerCase();
    }
    const colon = host.indexOf(":");
    if (colon >= 0)
      host = host.slice(0, colon);
    return host.toLowerCase() || null;
  }
  function platformFromUrl(url) {
    const host = hostnameFromMeetingUrl(url);
    if (!host)
      return null;
    if (host === "meet.google.com")
      return "google-meet";
    if (isTeamsHost(host))
      return "microsoft-teams";
    if (host === "zoom.us" || host.endsWith(".zoom.us") || host === "zoomgov.com" || host.endsWith(".zoomgov.com")) {
      return "zoom";
    }
    return null;
  }

  // src/shared/quota.ts
  function shouldSkipCallQuota(input) {
    return input.credentialSource === "runtime" || input.privateDeployment === true;
  }

  // src/shared/video-profile.ts
  var VIDEO_HEIGHTS = [720, 540, 480];
  var VIDEO_FPS_OPTIONS = [15, 24, 30];
  var VIDEO_ROI_OPTIONS = ["none", "crop102"];
  var WIDTH_FOR_HEIGHT = {
    720: 1280,
    540: 960,
    480: 854
  };
  var ACS_AUTO_BITRATE_BPS = 3000000;
  var BITRATE_FOR_HEIGHT = {
    720: ACS_AUTO_BITRATE_BPS,
    540: ACS_AUTO_BITRATE_BPS,
    480: 1e6
  };
  var PRESET_ALIASES = {
    "540p15": "540p15-crop102",
    "540p30": "540p30-crop102",
    "720p15-tight": "720p15-crop102",
    "720p24": "720p15",
    "720p30": "720p15",
    "720p24-crop102": "720p15-crop102",
    "720p30-crop102": "720p15-crop102",
    "360p15": "480p15",
    "360p24": "480p24",
    "360p30": "480p30",
    "360p15-crop102": "480p15-crop102",
    "360p24-crop102": "480p24-crop102",
    "360p30-crop102": "480p30-crop102"
  };
  function fpsOptionsForHeight(height) {
    if (height >= 720)
      return [15];
    return VIDEO_FPS_OPTIONS;
  }
  function composeVideoPreset(height, fps, roi) {
    const safeHeight = VIDEO_HEIGHTS.includes(height) ? height : 540;
    const allowed = fpsOptionsForHeight(safeHeight);
    const safeFps = allowed.includes(fps) ? fps : 15;
    return roi === "crop102" ? `${safeHeight}p${safeFps}-crop102` : `${safeHeight}p${safeFps}`;
  }
  function makeProfile(height, fps, roi) {
    const id = composeVideoPreset(height, fps, roi);
    const crop = roi === "crop102";
    return {
      id,
      width: WIDTH_FOR_HEIGHT[height],
      height,
      fps,
      bitrateBps: BITRATE_FOR_HEIGHT[height],
      fov: crop ? 102 : 118,
      roiPosition: crop ? "bottom" : "center",
      roi,
      label: crop ? `${height}p · ${fps} fps · 102°` : `${height}p · ${fps} fps`
    };
  }
  function buildPresets() {
    const presets = {};
    for (const height of VIDEO_HEIGHTS) {
      for (const fps of fpsOptionsForHeight(height)) {
        for (const roi of VIDEO_ROI_OPTIONS) {
          const profile = makeProfile(height, fps, roi);
          presets[profile.id] = profile;
        }
      }
    }
    return presets;
  }
  var VIDEO_PRESETS = buildPresets();
  var VIDEO_PRESET_IDS = Object.keys(VIDEO_PRESETS);
  var DEFAULT_VIDEO_PRESET = "540p15-crop102";
  var DEFAULT_VIDEO_BITRATE_BPS = null;
  var VIDEO_BITRATE_OPTIONS_BPS = [
    1e6,
    1500000,
    2000000,
    2500000,
    3000000,
    4000000,
    5000000
  ];
  function presetBitrateForHeight(height) {
    return BITRATE_FOR_HEIGHT[height] ?? BITRATE_FOR_HEIGHT[540];
  }
  function parseVideoPreset(value) {
    if (typeof value !== "string")
      return DEFAULT_VIDEO_PRESET;
    const aliased = PRESET_ALIASES[value];
    if (aliased)
      return aliased;
    return VIDEO_PRESET_IDS.includes(value) ? value : DEFAULT_VIDEO_PRESET;
  }
  function parseVideoBitrate(value) {
    if (value == null || value === "auto")
      return null;
    const bits = typeof value === "number" ? value : Number(value);
    return VIDEO_BITRATE_OPTIONS_BPS.includes(bits) ? bits : null;
  }
  function resolveVideoPreset(id) {
    return VIDEO_PRESETS[parseVideoPreset(id)];
  }
  function resolveConfiguredVideo(preset, bitrateBps) {
    const profile = resolveVideoPreset(preset);
    const override = parseVideoBitrate(bitrateBps);
    return { ...profile, bitrateBps: override };
  }
  var CLOUD_WHIP_MIN_BITRATE_BPS = 1e6;
  var CLOUD_WHIP_START_BITRATE_BPS = 1500000;
  function toWhipVideo(profile) {
    const video = { width: profile.width, height: profile.height, fps: profile.fps };
    if (profile.bitrateBps == null)
      return video;
    const max = profile.bitrateBps;
    return {
      ...video,
      bitrate: max,
      minBitrateBps: Math.min(CLOUD_WHIP_MIN_BITRATE_BPS, max),
      initialBitrateBps: Math.min(CLOUD_WHIP_START_BITRATE_BPS, max)
    };
  }
  function toAcsVideo(profile) {
    return {
      width: profile.height === 480 ? 858 : profile.width,
      height: profile.height,
      fps: profile.fps,
      maxBitrateBps: profile.bitrateBps ?? Math.max(presetBitrateForHeight(profile.height), ACS_AUTO_BITRATE_BPS)
    };
  }
  function isAcsFormatJoinError(error) {
    const message = error instanceof Error ? error.message : String(error);
    return /unsupported ACS video/i.test(message);
  }

  // src/shared/watch-mode.ts
  var INVESTIGATION_ARM = "off";

  // src/shared/errors.ts
  function requestErrorMessage(error, fallback) {
    if (error instanceof Error && error.message.trim() && error.message !== "[object Object]")
      return error.message;
    if (typeof error === "string" && error.trim() && error !== "[object Object]")
      return error;
    if (error && typeof error === "object") {
      const message = error.message;
      if (typeof message === "string" && message.trim() && message !== "[object Object]")
        return message;
      if (message && typeof message === "object") {
        const nested = requestErrorMessage(message, "");
        if (nested)
          return nested;
      }
    }
    return fallback;
  }
  function requestErrorCode(error) {
    if (error && typeof error === "object" && "code" in error && typeof error.code === "string") {
      return error.code;
    }
    const cause = error instanceof Error ? error.cause : undefined;
    if (cause && typeof cause.code === "string")
      return cause.code;
    return;
  }
  var NO_CAMERA_COPY = "These glasses do not have a camera";
  function isCallLimitError(message) {
    return Boolean(message && /Mentra Call limit[:\s(]+10 calls/i.test(message));
  }
  var TEAMS_CREATE_REACHABILITY_COPY = "Couldn’t reach Mentra Call. Check this phone’s internet connection and try again.";
  function classifyBackendFailure(args) {
    if (args.cfRay || /cloudflare/i.test(args.server ?? ""))
      return "cloudflare";
    if (/<!doctype html|<html[\s>]|error 1\d{3}|attention required/i.test(args.body))
      return "cloudflare";
    try {
      const parsed = JSON.parse(args.body);
      if (parsed && typeof parsed === "object")
        return "backend";
    } catch {}
    return "unknown";
  }
  function humanizeTeamsCreateError(message) {
    if (/\b503\b/.test(message) || /request failed \(503\)/i.test(message))
      return TEAMS_CREATE_REACHABILITY_COPY;
    if (/your-stable-domain\.example/i.test(message)) {
      return "Mentra Call is pointed at a placeholder server. Restart with bun run dev so it uses the hosted backend.";
    }
    if (/unable to resolve host|no address associated with hostname|rpc timed out|did not respond in time|the mentra call backend did not respond|network request failed|failed to fetch|load failed|err_internet|enotfound|\[object object\]/i.test(message)) {
      return TEAMS_CREATE_REACHABILITY_COPY;
    }
    return message;
  }
  function isTeamsCreateReachabilityFailure(error) {
    if (error && typeof error === "object" && "status" in error && error.status === 503) {
      return true;
    }
    const message = requestErrorMessage(error, "");
    return Boolean(message) && humanizeTeamsCreateError(message) === TEAMS_CREATE_REACHABILITY_COPY;
  }
  function isAcsMintTransientFailure(error) {
    if (error && typeof error === "object" && "status" in error) {
      const status = error.status;
      if (status === 502)
        return true;
      if (status === 404 || status === 429 || status === 401 || status === 403)
        return false;
    }
    return isTeamsCreateReachabilityFailure(error);
  }
  var DEAD_LINK_SUBCODES = new Set([8526, 8527, 8543, 8561]);
  var DEAD_LINK_CODE = 404;
  function isDeadMeetingLink(reason) {
    if (!reason)
      return false;
    if (reason.code === DEAD_LINK_CODE)
      return true;
    return reason.subcode !== undefined && DEAD_LINK_SUBCODES.has(reason.subcode);
  }
  function isGlassesLinkError(error, message = requestErrorMessage(error, "")) {
    if (requestErrorCode(error) === "GLASSES_NOT_CONNECTED") {
      logCall("device", "error classified as a glasses link drop", { by: "code" });
      return true;
    }
    if (/GLASSES_NOT_CONNECTED|Glasses are not connected|glasses disconnected|did not reconnect/i.test(message)) {
      logCall("device", "error classified as a glasses link drop", { by: "message" });
      return true;
    }
    return false;
  }

  // src/shared/backend-url.ts
  var HOSTED_DEV_BACKEND_URL = "https://mentra-call-miniapp-dev.mentraglass.com";
  function isPlaceholderBackendUrl(url) {
    return /your-stable-domain\.example/i.test(url);
  }
  function resolvePublicBackendUrl(raw) {
    const url = (raw ?? "").trim().replace(/\/+$/, "");
    if (!url || isPlaceholderBackendUrl(url))
      return HOSTED_DEV_BACKEND_URL;
    return url;
  }

  // src/shared/pipeline-telemetry.ts
  var ENABLE_PIPELINE_FPS_TELEMETRY = false;

  // src/background/constants/config.ts
  var BACKEND_URL = resolvePublicBackendUrl("https://mentra-call-miniapp-prod.mentraglass.com");
  var AUTH_DISABLED = false;
  var TEAMS_PROVIDER = "acs";
  var STREAM_START_ATTEMPTS = 3;
  var STREAM_RETRY_DELAY_MS = 2000;

  // src/background/lib/active-call-store.ts
  var STORAGE_KEY = "active-call-v1";

  class MemoryActiveCallStorage {
    values = new Map;
    async get(key) {
      return this.values.get(key) ?? null;
    }
    async set(key, value) {
      this.values.set(key, value);
    }
    async delete(key) {
      this.values.delete(key);
    }
  }

  class ActiveCallStore {
    session;
    constructor(session) {
      this.session = session;
    }
    async get() {
      try {
        const raw = await this.session.storage.get(STORAGE_KEY);
        if (!raw) {
          logCall("call", "active-call read: nothing stored");
          return null;
        }
        const value = JSON.parse(raw);
        if (typeof value.meetingUrl !== "string" || value.transport !== "softap" && value.transport !== "cloudflare") {
          warnCall("call", "active-call read: stored record is not usable", {
            hasMeetingUrl: typeof value.meetingUrl === "string",
            transport: String(value.transport)
          });
          return null;
        }
        const record = {
          meetingUrl: value.meetingUrl,
          transport: value.transport,
          operation: typeof value.operation === "number" ? value.operation : 0,
          startedAt: typeof value.startedAt === "number" ? value.startedAt : 0
        };
        logCall("call", "active-call read: found a record", {
          transport: record.transport,
          operation: record.operation,
          ageMs: record.startedAt ? Date.now() - record.startedAt : null
        });
        return record;
      } catch (error) {
        warnCall("call", "active-call read failed", { error: error instanceof Error ? error.message : String(error) });
        return null;
      }
    }
    async set(record) {
      const value = { ...record, startedAt: record.startedAt ?? Date.now() };
      try {
        await this.session.storage.set(STORAGE_KEY, JSON.stringify(value));
        logCall("call", "active-call recorded", { transport: value.transport, operation: value.operation });
      } catch (error) {
        warnCall("call", "active-call write failed", { error: error instanceof Error ? error.message : String(error) });
      }
    }
    async clear(ifOperation) {
      try {
        if (ifOperation !== undefined) {
          const current = await this.get();
          if (current && current.operation !== ifOperation) {
            logCall("call", "active-call clear declined — a newer join owns the record", {
              asked: ifOperation,
              owner: current.operation
            });
            return;
          }
        }
        await this.session.storage.delete(STORAGE_KEY);
        logCall("call", "active-call cleared", { ifOperation: ifOperation ?? null });
      } catch (error) {
        warnCall("call", "active-call clear failed", { error: error instanceof Error ? error.message : String(error) });
      }
    }
  }

  // src/background/lib/backend.ts
  var REQUEST_TIMEOUT_MS = 25000;
  var createTeamsRetryMs = 4000;
  var acsMintRetryMs = 2000;
  var POLLED_ROUTES = new Set(["/api/meet/audio", "/api/meet/participants", "/api/meet/chat", "/api/meet/status"]);
  var POLL_TALLY_EVERY = 30;
  var pollTallies = new Map;
  function notePolled(route, ms) {
    const tally = pollTallies.get(route) ?? { calls: 0, totalMs: 0 };
    tally.calls += 1;
    tally.totalMs += ms;
    if (tally.calls >= POLL_TALLY_EVERY) {
      logCall("rpc", `backend poll ${route}`, { ok: tally.calls, avgMs: Math.round(tally.totalMs / tally.calls) });
      pollTallies.set(route, { calls: 0, totalMs: 0 });
      return;
    }
    pollTallies.set(route, tally);
  }

  class BackendRequestError extends Error {
    status;
    notConnected;
    origin;
    cfRay;
    constructor(message, status, notConnected = false, origin = "unknown", cfRay) {
      super(message);
      this.status = status;
      this.notConnected = notConnected;
      this.origin = origin;
      this.cfRay = cfRay;
    }
  }

  class BackendClient {
    session;
    allowed;
    constructor(session, allowed = () => true) {
      this.session = session;
      this.allowed = allowed;
      if (!BACKEND_URL)
        warnCall("boot", "MENTRA_PUBLIC_MENTRA_CALL_BACKEND_URL is missing — every request will fail");
      if (AUTH_DISABLED)
        warnCall("boot", "request verification is disabled for this local build");
    }
    fetch(url, init) {
      return AUTH_DISABLED ? fetch(url, init) : this.session.auth.fetch(url, init);
    }
    async request(path, init = {}, timeoutMs = REQUEST_TIMEOUT_MS) {
      if (!this.allowed())
        throw new Error("This workspace supports joining Teams meeting links only");
      if (!BACKEND_URL)
        throw new Error("Mentra Call backend URL is not configured");
      const method = (init.method ?? "GET").toUpperCase();
      const route = path.split("?")[0] ?? path;
      const label = `backend ${method} ${route}`;
      const polled = POLLED_ROUTES.has(route);
      const id = nextRpcId();
      const startedAt = Date.now();
      let status = 0;
      if (!polled)
        logRpcStart(label, id);
      const controller = new AbortController;
      let timedOut = false;
      const timer = setTimeout(() => {
        timedOut = true;
        controller.abort();
      }, timeoutMs);
      const callerSignal = init.signal;
      const abortFromCaller = () => controller.abort();
      if (callerSignal?.aborted)
        controller.abort();
      else
        callerSignal?.addEventListener("abort", abortFromCaller, { once: true });
      const failOnAbort = () => void abortGateReject?.(Object.assign(new Error("aborted"), { name: "AbortError" }));
      let abortGateReject;
      const abortGate = new Promise((_, reject) => {
        abortGateReject = reject;
        if (controller.signal.aborted) {
          failOnAbort();
          return;
        }
        controller.signal.addEventListener("abort", failOnAbort, { once: true });
      });
      try {
        const response = await Promise.race([
          this.fetch(`${BACKEND_URL}${path}`, {
            ...init,
            signal: controller.signal,
            headers: { "Content-Type": "application/json", ...init.headers ?? {} }
          }),
          abortGate
        ]);
        status = response.status;
        if (!response.ok) {
          const body = (await response.text().catch(() => "")).slice(0, 1000);
          const cfRay = response.headers.get("cf-ray") ?? undefined;
          const origin = classifyBackendFailure({
            body,
            cfRay,
            server: response.headers.get("server")
          });
          let message = `Request failed (${response.status})`;
          let notConnected = false;
          try {
            const parsed = JSON.parse(body);
            if (parsed.error)
              message = parsed.error;
            notConnected = Boolean(parsed.notConnected);
          } catch {}
          if (response.status === 429 && isCallLimitError(message)) {
            logCall("call", "call quota blocked", { route, status: 429, message });
          }
          throw new BackendRequestError(message, response.status, notConnected, origin, cfRay);
        }
        const value = await response.json();
        if (polled)
          notePolled(route, Date.now() - startedAt);
        else
          logRpcEnd(label, id, "ok", Date.now() - startedAt, { status });
        return value;
      } catch (error) {
        const abortedByCaller = !timedOut && Boolean(callerSignal?.aborted);
        const requestError = error instanceof BackendRequestError ? error : undefined;
        const detail = {
          status,
          ...timedOut ? { timeout: true, timeoutMs } : {},
          error: requestErrorMessage(error, "request failed"),
          errorCode: requestErrorCode(error),
          ...requestError ? { origin: requestError.origin } : {},
          ...requestError?.cfRay ? { cfRay: requestError.cfRay } : {}
        };
        if (polled) {
          const outcome = abortedByCaller ? "aborted" : "failed";
          warnCall("rpc", `${label} ${outcome}`, { ...detail, ms: Date.now() - startedAt });
        } else {
          logRpcEnd(label, id, abortedByCaller ? "aborted" : "error", Date.now() - startedAt, detail);
        }
        if (timedOut)
          throw new Error("The Mentra Call backend did not respond in time");
        throw error;
      } finally {
        clearTimeout(timer);
        callerSignal?.removeEventListener("abort", abortFromCaller);
        controller.signal.removeEventListener("abort", failOnAbort);
      }
    }
    joinMeet(args) {
      return this.request("/api/meet/join", { method: "POST", body: JSON.stringify(args) });
    }
    getQuota() {
      return this.request("/api/meet/quota");
    }
    leaveMeet() {
      return this.request("/api/meet/leave", { method: "POST", body: "{}" });
    }
    sharePhoto(args) {
      return this.request("/api/meet/photo", { method: "POST", body: JSON.stringify(args) });
    }
    getCallStatus(refresh = false) {
      return this.request(`/api/meet/status?refresh=${refresh}`);
    }
    updateStream(args) {
      return this.request("/api/meet/stream", {
        method: "POST",
        body: JSON.stringify(args)
      });
    }
    reportStats(args) {
      return this.request("/api/meet/telemetry", {
        method: "POST",
        body: JSON.stringify(args)
      });
    }
    getParticipants() {
      return this.request("/api/meet/participants");
    }
    getChatMessages() {
      return this.request("/api/meet/chat");
    }
    sendChatMessage(text) {
      return this.request("/api/meet/chat", {
        method: "POST",
        body: JSON.stringify({ text })
      });
    }
    pollMeetingAudio(cursor, signal) {
      return this.request(`/api/meet/audio?cursor=${cursor}`, { signal }, 30000);
    }
    async createTeamsMeeting(args) {
      const body = JSON.stringify(args);
      try {
        return await this.requestTeamsCreate(body);
      } catch (error) {
        if (!isTeamsCreateReachabilityFailure(error))
          throw error;
        const backendError = error instanceof BackendRequestError ? error : undefined;
        warnCall("rpc", "create-teams unreachable; retrying once", {
          error: requestErrorMessage(error, "request failed"),
          waitMs: createTeamsRetryMs,
          ...backendError ? { status: backendError.status, origin: backendError.origin } : {},
          ...backendError?.cfRay ? { cfRay: backendError.cfRay } : {}
        });
        await new Promise((resolve) => setTimeout(resolve, createTeamsRetryMs));
        return this.requestTeamsCreate(body);
      }
    }
    requestTeamsCreate(body) {
      return this.request("/api/meet/create-teams", { method: "POST", body }, 12000);
    }
    endMeet(target) {
      return this.request("/api/meet/end", {
        method: "POST",
        body: JSON.stringify({
          ...target.meetingRef ? { meetingRef: target.meetingRef } : {},
          ...target.meetingId ? { meetingId: target.meetingId } : {}
        })
      });
    }
    googleConnectUrl() {
      return this.request("/api/meet/google/connect-url", { method: "POST", body: "{}" });
    }
    googleStatus() {
      return this.request("/api/meet/google/status");
    }
    googleDisconnect() {
      return this.request("/api/meet/google/disconnect", { method: "POST", body: "{}" });
    }
    createGoogleMeeting() {
      return this.request("/api/meet/google/create", {
        method: "POST",
        body: "{}"
      });
    }
    mute() {
      return this.request("/api/meet/mute", { method: "POST", body: "{}" });
    }
    unmute() {
      return this.request("/api/meet/unmute", { method: "POST", body: "{}" });
    }
    muteStatus() {
      return this.request("/api/meet/mute-status");
    }
    async getAcsToken(attemptId = crypto.randomUUID()) {
      try {
        return await this.requestAcsToken(attemptId);
      } catch (error) {
        if (!isAcsMintTransientFailure(error))
          throw error;
        const backendError = error instanceof BackendRequestError ? error : undefined;
        warnCall("rpc", "acs-token failed transiently; retrying once", {
          error: requestErrorMessage(error, "request failed"),
          waitMs: acsMintRetryMs,
          ...backendError ? { status: backendError.status, origin: backendError.origin } : {},
          ...backendError?.cfRay ? { cfRay: backendError.cfRay } : {}
        });
        await new Promise((resolve) => setTimeout(resolve, acsMintRetryMs));
        return this.requestAcsToken(attemptId);
      }
    }
    requestAcsToken(attemptId) {
      return this.request("/api/meet/acs-token", {
        method: "POST",
        body: JSON.stringify({ attemptId })
      });
    }
  }

  // src/shared/last-call.ts
  var REJOIN_WINDOW_MS = 5 * 60000;
  function offersRejoin(reason) {
    return reason !== "ended";
  }
  function rejoinRemainingMs(lastCall, now = Date.now()) {
    return Math.max(0, lastCall.endedAt + REJOIN_WINDOW_MS - now);
  }
  function isRejoinWindowOpen(lastCall, now = Date.now()) {
    return Boolean(lastCall) && rejoinRemainingMs(lastCall, now) > 0;
  }
  var REJOIN_IDLE_PHASES = new Set(["idle", "ended", "error"]);

  // src/background/lib/last-call-store.ts
  var STORAGE_KEY2 = "last-call-v1";

  class LastCallStore {
    session;
    onChange;
    constructor(session, onChange = () => {}) {
      this.session = session;
      this.onChange = onChange;
    }
    async get(now = Date.now()) {
      try {
        const raw = await this.session.storage.get(STORAGE_KEY2);
        if (!raw)
          return null;
        const value = JSON.parse(raw);
        if (typeof value.meetingUrl !== "string" || typeof value.endedAt !== "number" || typeof value.endReason !== "string") {
          warnCall("call", "last-call read: stored record is not usable");
          await this.session.storage.delete(STORAGE_KEY2);
          return null;
        }
        const lastCall = {
          meetingUrl: value.meetingUrl,
          origin: value.origin === "created" ? "created" : "joined",
          platform: value.platform,
          endedAt: value.endedAt,
          endReason: value.endReason
        };
        if (!isRejoinWindowOpen(lastCall, now)) {
          logCall("call", "last-call expired", { ageMs: now - lastCall.endedAt });
          await this.session.storage.delete(STORAGE_KEY2);
          return null;
        }
        return lastCall;
      } catch (error) {
        warnCall("call", "last-call read failed", { error: error instanceof Error ? error.message : String(error) });
        return null;
      }
    }
    async record(lastCall) {
      try {
        await this.session.storage.set(STORAGE_KEY2, JSON.stringify(lastCall));
        logCall("call", "last-call recorded", {
          host: hostnameFromMeetingUrl(lastCall.meetingUrl) ?? "unparseable",
          endReason: lastCall.endReason,
          origin: lastCall.origin
        });
      } catch (error) {
        warnCall("call", "last-call write failed", { error: error instanceof Error ? error.message : String(error) });
      }
      this.onChange(lastCall);
    }
    async clear(reason) {
      try {
        await this.session.storage.delete(STORAGE_KEY2);
        logCall("call", "last-call cleared", { reason });
      } catch (error) {
        warnCall("call", "last-call clear failed", { error: error instanceof Error ? error.message : String(error) });
      }
      this.onChange(null);
    }
  }

  // src/background/lib/scan-qr.ts
  var SCAN_QR_OPTIONS = {
    title: "Scan meeting QR",
    hint: "Point the camera at a Microsoft Teams QR code"
  };
  async function requestHostQrScan(scanQr) {
    try {
      const result = await scanQr(SCAN_QR_OPTIONS);
      if (result.cancelled)
        logCall("meeting", "QR scan cancelled by the wearer");
      else if (result.data) {
        logCall("meeting", "QR scan decoded", {
          host: hostnameFromMeetingUrl(result.data) ?? "not a URL",
          platform: platformFromUrl(result.data) ?? "unrecognised"
        });
      } else
        logCall("meeting", "QR scan returned no data and no cancel");
      return result;
    } catch (error) {
      const message = requestErrorMessage(error, "Could not open the QR scanner");
      warnCall("meeting", "QR scan failed", { error: message });
      return { error: message };
    }
  }

  // src/background/managers/CalendarManager.ts
  var LIST_LIMIT = 20;
  function meetingFromEvent(event) {
    const meeting = event.links.map((url) => ({ url, platform: platformFromUrl(url) })).find((candidate) => candidate.platform);
    return {
      eventId: event.id,
      title: event.title || "Untitled meeting",
      startsAt: event.startsAt,
      endsAt: event.endsAt,
      meetingUrl: meeting?.url ?? null,
      platform: meeting?.platform ?? null,
      location: event.location ?? ""
    };
  }

  class CalendarManager {
    session;
    constructor(session) {
      this.session = session;
    }
    async list() {
      const now = Date.now();
      const { events, truncated } = await tracedRpc("phone.calendar.listEvents", () => this.session.phone.calendar.listEvents({
        startsAt: new Date(now - 2 * 60 * 60 * 1000),
        endsAt: new Date(now + 7 * 24 * 60 * 60 * 1000),
        limit: 100
      }), {
        request: { windowHoursBack: 2, windowDaysAhead: 7, limit: 100 },
        response: (value) => ({ events: value.events.length, truncated: value.truncated })
      });
      const parsed = events.map(meetingFromEvent);
      const joinable = parsed.filter((meeting) => meeting.meetingUrl !== null);
      const rejectedHosts = new Set;
      for (const event of events) {
        if (event.links.some((url) => platformFromUrl(url)))
          continue;
        for (const url of event.links)
          rejectedHosts.add(hostnameFromMeetingUrl(url) ?? "unparseable");
      }
      if (rejectedHosts.size) {
        warnCall("meeting", "calendar links rejected: unsupported host", { hosts: [...rejectedHosts] });
      }
      const sorted = joinable.sort((a, b) => Date.parse(a.startsAt) - Date.parse(b.startsAt));
      if (sorted.length > LIST_LIMIT) {
        logCall("meeting", "calendar list capped", { joinable: sorted.length, limit: LIST_LIMIT });
      }
      logCall("meeting", "calendar refreshed", {
        events: events.length,
        joinable: joinable.length,
        linkless: parsed.length - joinable.length,
        truncated,
        platforms: [...new Set(joinable.map((meeting) => meeting.platform))]
      });
      return sorted.slice(0, LIST_LIMIT);
    }
  }

  // src/shared/end-call.ts
  var END_UNCONFIRMED_COPY = "You left the call, but the meeting may still be active.";
  var END_GUEST_IDENTITY_REASON = "You created this meeting here. The phone still joined Teams as a guest, and guests cannot end it for everyone.";
  var END_GUEST_IDENTITY_COPY = `You left. Teams still has the others. ${END_GUEST_IDENTITY_REASON}`;
  var END_BLOCKED_COPY = {
    notOrganizer: "Only a Teams organizer or presenter can end this meeting for everyone.",
    guestIdentity: END_GUEST_IDENTITY_REASON,
    notSupported: "Update the Mentra App to end meetings for everyone.",
    checking: "Checking…",
    unknown: "Checking whether you can end this meeting…"
  };
  var END_PRESENTER_DENIED_COPY = `You left the call. ${END_BLOCKED_COPY.notOrganizer}`;
  var ROLE_RESTRICTED = /role_restricted|hang_up_for_everyone_not_allowed/i;
  function isGuestEndDenial(reason, identityMode) {
    if (identityMode !== "guest")
      return false;
    const guest = ROLE_RESTRICTED.test(reason ?? "");
    if (reason)
      logCall("call", "end denial classified", { guest, identityMode });
    return guest;
  }
  function endFailureMessage(reason, identityMode) {
    if (isGuestEndDenial(reason, identityMode))
      return END_GUEST_IDENTITY_COPY;
    if (identityMode === "teams-user" && ROLE_RESTRICTED.test(reason)) {
      logCall("call", "end denial classified", { guest: false, identityMode });
      return END_PRESENTER_DENIED_COPY;
    }
    return reason;
  }
  var TRANSIENT_END_DENIAL = new Set(["NotInitialized", "not_initialized", "capabilities_unavailable"]);
  function isTransientEndDenial(reason) {
    return Boolean(reason && TRANSIENT_END_DENIAL.has(reason));
  }

  // src/background/managers/CallManager.ts
  function toCallParticipants(participants) {
    if (!participants)
      return;
    return participants.filter((participant) => participant.state !== "disconnected").map((participant) => ({
      id: participant.id,
      name: participant.displayName,
      is_host: null,
      platform: "microsoft-teams",
      state: participant.state,
      isSpeaking: participant.isSpeaking,
      isMuted: participant.isMuted
    }));
  }
  function sameMeetingUrl(a, b) {
    const canonical = (value) => {
      const trimmed = value.trim().replace(/\/+$/, "");
      try {
        return new URL(trimmed).href.replace(/\/+$/, "");
      } catch {
        return trimmed;
      }
    };
    return canonical(a) === canonical(b);
  }
  function phaseForMeeting(state, origin) {
    if (state === "connecting")
      return "joining";
    if (state === "lobby")
      return origin === "created" ? "joining" : "waiting-room";
    if (state === "connected")
      return "in-call";
    if (state === "disconnected")
      return "ended";
    if (state === "error")
      return "error";
    return "idle";
  }
  var SYNTHETIC_PLACEHOLDER_WHEP = "https://customer.cloudflarestream.com/synthetic/webRTC/play";
  var STATUS_POLL_MS = 1500;
  var JOIN_TIMEOUT_MS = 2 * 60 * 1000;
  var RESTORE_LINK_WAIT_MS = 60000;
  var HOST_END_TIMEOUT_MS = 20000;
  var HOST_LEAVE_TIMEOUT_MS = 25000;
  var delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  function beginRpc(channel, request) {
    const id = nextRpcId();
    const startedAt = Date.now();
    logRpcStart(channel, id, request);
    return {
      ok: (data) => logRpcEnd(channel, id, "ok", Date.now() - startedAt, data),
      failed: (error) => logRpcEnd(channel, id, "error", Date.now() - startedAt, {
        error: error instanceof Error ? error.message : String(error)
      })
    };
  }
  function meetingHostLabel(meetingUrl) {
    if (!meetingUrl)
      return "none";
    return hostnameFromMeetingUrl(meetingUrl) ?? "unparseable";
  }
  function withDeadline(promise, ms, message) {
    let timer;
    const deadline = new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error(message)), ms);
    });
    return Promise.race([promise, deadline]).finally(() => {
      if (timer !== undefined)
        clearTimeout(timer);
    });
  }
  var LINK_COPY = {
    joinBlocked: "Reconnect your glasses to join a call. Mentra Call streams from their camera and microphone.",
    wifiBlocked: "Turn on Wi-Fi for your glasses in the Mentra App. This call streams the camera over it; only a work Teams call on the direct link can do without it.",
    restoreWaiting: "Your meeting is still active. Waiting for your glasses to reconnect…",
    restoreTimeout: "Your glasses have not reconnected. Your meeting is still active — bring your glasses closer to your phone, or end the call."
  };
  var ACS_VIDEO_WAIT_COPY = "Camera is back — restoring video to the meeting…";
  var ACS_VIDEO_GATE_MS = 20000;
  function classifyJoinError(error, failedStage) {
    if (error instanceof BackendRequestError)
      return { errorType: "http", statusCode: error.status };
    if (error instanceof Error && /did not respond in time|not admitted within|timed out/i.test(error.message)) {
      return { errorType: "timeout" };
    }
    if (failedStage === "path" || failedStage === "tap" || failedStage === "checking-device" || failedStage === "starting-stream") {
      return { errorType: "device" };
    }
    const text = error instanceof Error ? `${error.message} ${error.cause ?? ""}` : String(error);
    if (isPhoneWifiOffError(text))
      return { errorType: "phone-wifi" };
    if (isPhoneVpnError(text))
      return { errorType: "phone-vpn" };
    return { errorType: "unknown" };
  }
  function phaseForBackend(status) {
    if (status === "creating")
      return "creating-bot";
    if (status === "waiting-room")
      return "waiting-room";
    if (status === "in-call")
      return "in-call";
    if (status === "reconnecting")
      return "reconnecting";
    if (status === "leaving")
      return "leaving";
    if (status === "ended")
      return "ended";
    if (status === "error")
      return "error";
    return "joining";
  }
  function liveSoftapProgress() {
    return {
      phase: "live",
      elapsedMs: 0,
      steps: SOFTAP_STEPS2.map((step) => ({ step, status: "done" }))
    };
  }

  class CallManager {
    backend;
    streams;
    meetingAudio;
    onEvent;
    meetingHost;
    state = { phase: "idle", streamPhase: "offline", audioStatus: "off" };
    operation = 0;
    joinInFlight = null;
    streamUpdateQueue = Promise.resolve();
    statusMonitor = null;
    statusMonitorOperation = -1;
    handlingStreamFailure = false;
    terminal = null;
    terminalRequests = 0;
    lastOutcome = null;
    createdMeeting = null;
    callCreatedMeeting = null;
    meetingUnsub = null;
    linkUnsub = null;
    acsWhepUrl = null;
    lastAcsEndReason;
    lastAcsNativeState;
    acsLobbyEnteredAt = 0;
    acsLobbyDwellMs;
    lastTeamsRowLog;
    startCuePlayed = false;
    hostReportsMediaSource = false;
    acsVideoGate = null;
    acsVideoGateTimer = null;
    activeCall;
    lastCall;
    admittedCall = null;
    joinRequest = null;
    linkRecovering = false;
    micLease = null;
    constructor(backend, streams, meetingAudio, onEvent, meetingHost, transport = {}) {
      this.backend = backend;
      this.streams = streams;
      this.meetingAudio = meetingAudio;
      this.onEvent = onEvent;
      this.meetingHost = meetingHost;
      this.transport = typeof transport === "string" ? { override: transport } : transport;
      this.activeCall = this.transport.activeCall ?? new ActiveCallStore({ storage: new MemoryActiveCallStorage });
      this.lastCall = this.transport.lastCall ?? new LastCallStore({ storage: new MemoryActiveCallStorage });
    }
    transport;
    usesAcs(meetingUrl) {
      return explainJoinRoute(meetingUrl, this.transport.meetingConfiguration?.().credentialSource === "runtime" ? "acs" : TEAMS_PROVIDER).usesAcs;
    }
    transportFor(meetingUrl) {
      if (this.transport.meetingConfiguration?.().externalBackendAllowed === false)
        return "softap";
      return resolveCallTransport(this.usesAcs(meetingUrl), this.transport.override, this.transport.directLink?.() ?? true);
    }
    currentTransport() {
      return this.state.transport ?? this.transportFor(this.state.meetingUrl ?? "");
    }
    getState() {
      return { ...this.state, stream: this.streams.info };
    }
    setPhoto(photo) {
      if (this.state.photo === photo)
        return;
      this.setState({ ...this.state, photo });
    }
    async restore() {
      const operation = ++this.operation;
      logCall("call", "restore", { operation, meetingHost: Boolean(this.meetingHost) });
      try {
        if (!this.meetingHost)
          logCall("call", "restore: no meeting host on this build, so no ACS call to adopt");
        const stateRpc = this.meetingHost ? beginRpc("meeting.getState", { operation }) : null;
        const native = await this.meetingHost?.getState().then((value) => {
          stateRpc?.ok({ nativeState: value.state, mediaSource: value.mediaSource, softap: Boolean(value.softap) });
          return value;
        }, (error) => {
          stateRpc?.failed(error);
          return null;
        });
        if (operation !== this.operation) {
          logCall("call", "restore stood down: something newer owns the call", {
            operation,
            active: this.operation,
            at: "after meeting.getState"
          });
          return;
        }
        const recovering = isSoftapRecoveryActive(native?.recovery);
        const finished = native && (native.state === "idle" || native.state === "disconnected" || native.state === "error" && !recovering);
        if (finished) {
          logCall("call", "restore: the host is holding nothing adoptable", {
            nativeState: native.state,
            error: native.error
          });
        }
        if (native && !finished) {
          this.acsWhepUrl = null;
          this.hostReportsMediaSource ||= Boolean(native.mediaSource);
          await this.acquireMic().catch((error) => {
            warnCall("call", "glasses microphone re-acquire failed during restore", {
              error: error instanceof Error ? error.message : String(error)
            });
          });
          const transport = await this.restoredTransport(native);
          if (operation !== this.operation) {
            logCall("call", "restore stood down: something newer owns the call", {
              operation,
              active: this.operation,
              at: "after transport resolution"
            });
            return;
          }
          const base = {
            identityMode: native.identityMode,
            guestReason: native.guestReason,
            phase: phaseForMeeting(native.state, this.state.origin),
            streamPhase: "connecting",
            transport,
            meetingUrl: native.meetingUrl,
            platform: "microsoft-teams",
            provider: "acs",
            muted: native.muted,
            videoEnabled: native.videoEnabled,
            audioStatus: "off",
            error: native.error,
            startedAt: this.state.startedAt ?? Date.now()
          };
          if (transport === "softap") {
            const live = native.mediaSource === "live" && !recovering;
            this.syncLinkRecovery(recovering);
            this.setState({
              ...base,
              phase: recovering ? "in-call" : base.phase,
              streamPhase: recovering ? "reconnecting" : live ? "active" : native.mediaSource === "failed" ? "reconnecting" : "connecting",
              streamReason: recovering || native.mediaSource === "failed" ? "ingest" : undefined,
              recovery: native.recovery,
              softap: native.softap ?? (live ? liveSoftapProgress() : initialSoftapProgress())
            });
            logCall("call", "restore softap adopt", {
              mediaSource: native.mediaSource,
              hostProgress: Boolean(native.softap),
              recoveryActive: recovering
            });
            this.subscribeMeeting(operation);
            return;
          }
          this.setState(base);
          this.subscribeMeeting(operation);
          this.streams.setCaptureAudio(ACS_CALL_MIC === "glasses");
          await this.attachRestoredStream(operation, async (stream) => {
            if (!stream.webrtcUrl) {
              warnCall("call", "restore refused: the adopted glasses stream has no WHEP URL", {
                streamId: stream.streamId,
                mode: stream.mode
              });
              throw new Error("ACS restore needs a live glasses WHEP stream");
            }
            const videoRpc = beginRpc("meeting.updateVideoSource", { type: "whep", at: "restore" });
            try {
              await this.meetingHost?.updateVideoSource({ type: "whep", url: stream.webrtcUrl });
              videoRpc.ok();
            } catch (error) {
              videoRpc.failed(error);
              throw error;
            }
          });
          return;
        }
        if (this.transport.meetingConfiguration?.().externalBackendAllowed === false)
          return;
        let call;
        const statusRpc = beginRpc("backend.getCallStatus", { refresh: false, at: "restore" });
        try {
          call = (await this.backend.getCallStatus(false)).call;
          statusRpc.ok({ status: call?.status, recallStatus: call?.recallStatus, present: Boolean(call) });
        } catch (error) {
          statusRpc.failed(error);
          warnCall("call", "restore status read failed", {
            error: error instanceof Error ? error.message : String(error)
          });
          return;
        }
        if (operation !== this.operation) {
          logCall("call", "restore stood down: something newer owns the call", {
            operation,
            active: this.operation,
            at: "after backend status read"
          });
          return;
        }
        if (!call || ["ended", "error"].includes(call.status)) {
          logCall("call", "restore: nothing to adopt on either side", {
            backendStatus: call?.status,
            clearingRecord: true
          });
          await this.activeCall.clear();
          return;
        }
        this.setState({
          phase: phaseForBackend(call.status),
          streamPhase: "connecting",
          callId: call.callId,
          botId: call.botId,
          meetingUrl: call.meetingUrl,
          platform: call.platform,
          provider: "recall",
          recallStatus: call.recallStatus,
          startedAt: call.startedAt ? Date.parse(call.startedAt) : undefined,
          audioStatus: "off"
        });
        await this.attachRestoredStream(operation, async (stream) => {
          const updateRpc = beginRpc("backend.updateStream", { at: "restore", joinId: stream.streamId });
          try {
            await this.backend.updateStream({
              webrtcUrl: stream.webrtcUrl,
              reconnecting: false,
              joinId: stream.streamId
            });
            updateRpc.ok();
          } catch (error) {
            updateRpc.failed(error);
            throw error;
          }
        });
        if (operation !== this.operation) {
          logCall("call", "restore stood down: something newer owns the call", {
            operation,
            active: this.operation,
            at: "after republishing the stream"
          });
          return;
        }
        const refreshRpc = beginRpc("backend.getCallStatus", { refresh: true, at: "restore" });
        let refreshed;
        try {
          refreshed = await this.backend.getCallStatus(true);
          refreshRpc.ok({ status: refreshed.call?.status, recallStatus: refreshed.call?.recallStatus });
        } catch (error) {
          refreshRpc.failed(error);
          throw error;
        }
        if (refreshed.call)
          this.applyBackendCall(refreshed.call);
        if (refreshed.call && !["ended", "error"].includes(refreshed.call.status)) {
          if (refreshed.call.status === "in-call")
            this.startMeetingAudio();
          this.startStatusMonitor(operation);
        } else {
          logCall("call", "restore: the refreshed call is already over", { status: refreshed.call?.status });
        }
      } catch (error) {
        const message = requestErrorMessage(error, "unknown error");
        await this.handleFatalFailure(`Could not restore the active call: ${message}`, "restore");
      }
    }
    async restoredTransport(native) {
      if (this.transport.meetingConfiguration?.().externalBackendAllowed === false)
        return "softap";
      if (native.softap) {
        logCall("call", "restore transport from the host's own checklist", { transport: "softap" });
        return "softap";
      }
      const record = await this.activeCall.get();
      if (record && (!native.meetingUrl || sameMeetingUrl(record.meetingUrl, native.meetingUrl))) {
        logCall("call", "restore transport from the join record", {
          transport: record.transport,
          host: meetingHostLabel(record.meetingUrl),
          hostReportedUrl: Boolean(native.meetingUrl)
        });
        return record.transport;
      }
      if (record) {
        warnCall("call", "restore record rejected: it describes a different meeting", {
          recordHost: meetingHostLabel(record.meetingUrl),
          hostHost: meetingHostLabel(native.meetingUrl)
        });
      }
      const guess = resolveCallTransport(true, this.transport.override, true);
      logCall("call", "restore transport guessed", {
        transport: guess,
        hadRecord: Boolean(record),
        hadUrl: Boolean(native.meetingUrl)
      });
      return guess;
    }
    async attachRestoredStream(operation, publish) {
      if (INVESTIGATION_ARM === "cheap-synthetic") {
        logCall("call", "restore stream skipped: the synthetic investigation arm has no glasses stream");
        return;
      }
      if (this.streams.linkConnected === false) {
        logCall("call", "restore: waiting for Bluetooth link", { timeoutMs: RESTORE_LINK_WAIT_MS });
        this.setState({
          ...this.state,
          streamPhase: "reconnecting",
          streamReason: "glasses",
          streamError: LINK_COPY.restoreWaiting
        });
        const linked = await this.streams.waitForLink(RESTORE_LINK_WAIT_MS, () => operation !== this.operation);
        if (operation !== this.operation) {
          logCall("call", "restore stream stood down: something newer owns the call", {
            operation,
            active: this.operation,
            at: "waiting for the Bluetooth link"
          });
          return;
        }
        if (!linked) {
          warnCall("call", "restore: Bluetooth link did not return; leaving the call to the user");
          this.setState({
            ...this.state,
            streamPhase: "error",
            streamReason: "glasses",
            streamError: LINK_COPY.restoreTimeout
          });
          this.reattachWhenLinked(operation, publish);
          return;
        }
      }
      this.setState({ ...this.state, streamPhase: "connecting", streamReason: undefined, streamError: undefined });
      const stream = await this.streams.ensureStarted();
      if (operation !== this.operation) {
        logCall("call", "restore stream discarded: something newer owns the call", {
          operation,
          active: this.operation,
          streamId: stream.streamId
        });
        return;
      }
      logCall("call", "restore stream live; handing it to the provider", { streamId: stream.streamId, mode: stream.mode });
      await publish(stream);
    }
    reattachWhenLinked(operation, publish) {
      this.linkUnsub?.();
      logCall("call", "restore: armed to re-attach the stream on the next link event", { operation });
      const unsub = this.streams.onLink((snapshot) => {
        if (operation !== this.operation) {
          logCall("call", "restore re-attach released: something newer owns the call", {
            operation,
            active: this.operation
          });
          release();
          return;
        }
        if (snapshot.state !== "connected") {
          logChange("call", "call.restoreWaitingLink", snapshot.state);
          return;
        }
        release();
        logCall("call", "restore: Bluetooth link back; attaching stream");
        this.attachRestoredStream(operation, publish).catch(async (error) => {
          const message = requestErrorMessage(error, "unknown error");
          await this.handleFatalFailure(`Could not restore the active call: ${message}`, "restore");
        });
      });
      const release = () => {
        unsub();
        if (this.linkUnsub === unsub)
          this.linkUnsub = null;
      };
      this.linkUnsub = unsub;
    }
    async join(meetingUrl, botName, paint = "track", options) {
      if (this.joinInFlight) {
        if (["ended", "error"].includes(this.state.phase)) {
          const requestsBeforeWait = this.terminalRequests;
          await this.joinInFlight;
          if (this.terminalRequests !== requestsBeforeWait)
            return { error: "Join cancelled" };
          return this.admitJoin(meetingUrl, botName, paint, options);
        }
        logCall("call", "join folded into the one already in flight", {
          host: meetingHostLabel(meetingUrl),
          phase: this.state.phase
        });
        return this.joinInFlight;
      }
      const terminal = this.terminal;
      if (terminal && this.state.phase === "leaving") {
        logCall("call", "join waiting for the teardown in flight", { reason: terminal.reason });
        const requestsBeforeWait = this.terminalRequests;
        await terminal.promise.catch(() => {
          return;
        });
        if (this.terminalRequests !== requestsBeforeWait) {
          logCall("call", "queued join stood down: cancelled while it waited");
          return { error: "Join cancelled" };
        }
      }
      return this.admitJoin(meetingUrl, botName, paint, options);
    }
    admitJoin(meetingUrl, botName, paint = "track", options) {
      const configuration = this.transport.meetingConfiguration?.();
      if (configuration?.enabled === false)
        return Promise.resolve({ error: "Native meetings are disabled by this workspace" });
      if (configuration?.externalBackendAllowed === false && !this.usesAcs(meetingUrl)) {
        return Promise.resolve({ error: "This workspace supports Microsoft Teams work or school meeting links" });
      }
      if (this.joinInFlight) {
        logCall("call", "queued join folded into the one that won the teardown race", {
          host: meetingHostLabel(meetingUrl),
          phase: this.state.phase
        });
        return this.joinInFlight;
      }
      if (["in-call", "waiting-room", "reconnecting", "leaving", "joining"].includes(this.state.phase)) {
        warnCall("call", "join refused: a call is already in progress", {
          phase: this.state.phase,
          provider: this.state.provider,
          requestedHost: meetingHostLabel(meetingUrl),
          currentHost: meetingHostLabel(this.state.meetingUrl)
        });
        return Promise.resolve({ error: "End the current call before joining another meeting" });
      }
      if (this.streams.linkConnected === false) {
        logCall("call", "join refused: Bluetooth link down", { host: meetingHostLabel(meetingUrl) });
        return Promise.resolve({ error: LINK_COPY.joinBlocked, blocked: "glasses-disconnected" });
      }
      if (usesCloudflare(this.transportFor(meetingUrl)) && this.streams.linkConnected === true && this.streams.wifiReady === false) {
        logCall("call", "join refused: glasses Wi-Fi down", {
          host: meetingHostLabel(meetingUrl),
          transport: this.transportFor(meetingUrl)
        });
        return Promise.resolve({ error: LINK_COPY.wifiBlocked, blocked: "glasses-wifi" });
      }
      const origin = options?.origin === "created" ? "created" : "joined";
      const resolvedPaint = INVESTIGATION_ARM === "cheap-synthetic" ? "synthetic" : INVESTIGATION_ARM === "raw-video" ? "video" : paint;
      const path = explainJoinRoute(meetingUrl, TEAMS_PROVIDER);
      logCall("call", "join", {
        botName,
        paint: resolvedPaint,
        phase: this.state.phase,
        origin,
        meetingHost: Boolean(this.meetingHost),
        transport: this.transportFor(meetingUrl),
        ...path
      });
      const operation = ++this.operation;
      this.joinRequest = { operation, meetingUrl };
      this.lastOutcome = null;
      this.callCreatedMeeting = origin === "created" ? this.createdMeeting : null;
      this.joinInFlight = this.runJoin(operation, meetingUrl, botName, resolvedPaint, origin).finally(() => {
        if (operation === this.operation)
          this.joinInFlight = null;
      });
      return this.joinInFlight;
    }
    leave() {
      return this.finishCall({ reason: "left", sessionId: this.operation });
    }
    endCall() {
      const joinFailed = this.state.phase === "error" && this.state.errorKind === "join";
      if (this.state.provider !== "acs" || this.state.phase === "idle" || joinFailed) {
        logCall("call", "end downgraded to leave: no ACS call to end", {
          phase: this.state.phase,
          provider: this.state.provider
        });
        return this.leave();
      }
      return this.finishCall({ reason: "ended", sessionId: this.operation });
    }
    leaveIfActive() {
      if (["idle", "ended", "leaving"].includes(this.state.phase) && !this.terminal) {
        logCall("call", "leave-if-active did nothing: no call to hang up", { phase: this.state.phase });
        return Promise.resolve(undefined);
      }
      return this.leave();
    }
    noteCreatedMeeting(joinUrl, ownership) {
      const parsed = typeof ownership === "string" ? { ref: ownership } : ownership;
      logCall("call", "created meeting noted", {
        host: meetingHostLabel(joinUrl),
        hasRef: Boolean(parsed.ref),
        hasMeetingId: Boolean(parsed.meetingId),
        replacing: this.createdMeeting ? meetingHostLabel(this.createdMeeting.joinUrl) : "none"
      });
      this.createdMeeting = { joinUrl, ref: parsed.ref, meetingId: parsed.meetingId, source: parsed.source };
    }
    ownedMeeting() {
      if (this.state.origin === "created")
        return this.callCreatedMeeting;
      if (this.createdMeeting && this.createdMeeting.joinUrl === this.state.meetingUrl)
        return this.createdMeeting;
      return null;
    }
    finishCall(request) {
      if (request.sessionId !== this.operation) {
        logCall("call", "terminal callback dropped", {
          reason: request.reason,
          sessionId: request.sessionId,
          active: this.operation
        });
        return Promise.resolve(this.lastOutcome ?? { success: true });
      }
      this.terminalRequests += 1;
      if (this.terminal) {
        logCall("call", "terminal already running", { reason: request.reason, running: this.terminal.reason });
        return this.terminal.promise;
      }
      if (this.lastOutcome?.success && ["idle", "ended", "error"].includes(this.state.phase)) {
        logCall("call", "terminal already concluded", { reason: request.reason, outcome: this.lastOutcome.reason });
        return Promise.resolve(this.lastOutcome);
      }
      const promise = this.runFinishCall(request).finally(() => {
        this.terminal = null;
      });
      this.terminal = { reason: request.reason, promise };
      return promise;
    }
    async runFinishCall(request) {
      const ending = request.reason === "ended";
      const admitted = this.admittedCall?.operation === this.operation ? this.admittedCall : null;
      this.admittedCall = null;
      ++this.operation;
      this.joinInFlight = null;
      logCall("call", ending ? "end" : "finish", {
        reason: request.reason,
        phase: this.state.phase,
        provider: this.state.provider,
        botId: this.state.botId
      });
      const wearerInitiated = request.reason === "left" || request.reason === "ended";
      this.setState({
        ...this.state,
        phase: "leaving",
        error: undefined,
        errorKind: undefined,
        endReason: undefined,
        streamReason: wearerInitiated ? undefined : this.state.streamReason,
        streamError: wearerInitiated ? undefined : this.state.streamError
      });
      this.meetingUnsub?.();
      this.meetingUnsub = null;
      this.linkUnsub?.();
      this.linkUnsub = null;
      this.clearAcsVideoGate();
      this.acsWhepUrl = null;
      await this.meetingAudio.stop().catch((error) => {
        warnCall("call", "meeting audio stop failed during teardown", {
          error: error instanceof Error ? error.message : String(error)
        });
      });
      let releaseError;
      try {
        releaseError = await this.releaseMeeting(request.reason);
      } finally {
        await this.streams.stop().catch((error) => {
          warnCall("call", "stream stop failed during teardown", {
            error: error instanceof Error ? error.message : String(error)
          });
        });
        await this.releaseMic();
      }
      const outcome = this.settleTerminalState(request, releaseError);
      this.lastOutcome = outcome;
      if (admitted && outcome.reason && offersRejoin(outcome.reason)) {
        await this.lastCall.record({
          meetingUrl: admitted.meetingUrl,
          origin: admitted.origin,
          platform: admitted.platform,
          endedAt: Date.now(),
          endReason: outcome.reason
        });
      }
      logCall("call", "terminal settled", {
        requested: request.reason,
        outcome: outcome.reason,
        success: outcome.success,
        phase: this.state.phase
      });
      return outcome;
    }
    async acquireMic() {
      if (!this.transport.micHost)
        return;
      await this.releaseMic();
      try {
        const lease = await this.transport.micHost.acquire({ source: "glasses", useCase: "voice_call" });
        if (!lease || typeof lease.release !== "function") {
          warnCall("call", "this host does not support microphone sessions; joining without one");
          return;
        }
        this.micLease = lease;
        logCall("call", "glasses microphone acquired");
      } catch (error) {
        warnCall("call", "glasses microphone acquire failed; joining without one", {
          error: requestErrorMessage(error, "unknown")
        });
      }
    }
    async releaseMic() {
      const lease = this.micLease;
      if (!lease)
        return;
      this.micLease = null;
      try {
        await lease.release();
        logCall("call", "glasses microphone released");
      } catch (error) {
        warnCall("call", "glasses microphone release failed", {
          error: error instanceof Error ? error.message : String(error)
        });
      }
    }
    async leaveMeetingHost() {
      if (!this.meetingHost)
        return;
      await withDeadline(this.meetingHost.leave(), this.transport.hostLeaveTimeoutMs ?? HOST_LEAVE_TIMEOUT_MS, "The meeting host did not finish leaving");
    }
    async releaseMeeting(reason) {
      if (this.state.provider === "acs") {
        const releaseRpc = beginRpc(reason === "ended" ? "meeting.end" : "meeting.leave", { reason });
        try {
          if (reason === "ended")
            await this.endMeetingEverywhere();
          else
            await this.leaveMeetingHost();
          releaseRpc.ok();
        } catch (error) {
          releaseRpc.failed(error);
          return requestErrorMessage(error, "The meeting host refused the release");
        }
        return;
      }
      if (reason === "remote-ended") {
        logCall("call", "release skipped: Recall's bot ended itself", { reason });
        return;
      }
      const leaveRpc = beginRpc("backend.leaveMeet", { reason });
      try {
        await this.backend.leaveMeet();
        leaveRpc.ok();
      } catch (error) {
        leaveRpc.failed(error);
        return error instanceof Error ? error.message : String(error);
      }
      return;
    }
    async endMeetingEverywhere() {
      const failures = [];
      if (!this.meetingHost?.end) {
        warnCall("call", "end refused: this host has no end verb, so only a Leave is possible", {
          meetingHost: Boolean(this.meetingHost)
        });
        failures.push(END_BLOCKED_COPY.notSupported);
        const fallbackRpc = beginRpc("meeting.leave", { reason: "end-not-supported" });
        await this.leaveMeetingHost().then(() => fallbackRpc.ok(), (error) => fallbackRpc.failed(error));
      } else {
        const endRpc = beginRpc("meeting.end", { timeoutMs: this.transport.hostEndTimeoutMs ?? HOST_END_TIMEOUT_MS });
        try {
          await withDeadline(this.meetingHost.end(), this.transport.hostEndTimeoutMs ?? HOST_END_TIMEOUT_MS, "The meeting host did not answer the end request");
          endRpc.ok();
        } catch (error) {
          endRpc.failed(error);
          failures.push(requestErrorMessage(error, "The meeting host refused to end the meeting"));
        }
      }
      const created = this.ownedMeeting();
      if (created?.ref || created?.meetingId) {
        const retireRpc = beginRpc("backend.endMeet", { hasRef: Boolean(created.ref), hasId: Boolean(created.meetingId) });
        try {
          if (created.source === "runtime") {
            if (!created.ref || !this.meetingHost?.retire)
              throw new Error("Update the Mentra App to retire this meeting");
            await this.meetingHost.retire(created.ref);
          } else {
            await this.backend.endMeet({ meetingRef: created.ref, meetingId: created.meetingId });
          }
          retireRpc.ok();
          this.callCreatedMeeting = null;
          if (this.createdMeeting === created)
            this.createdMeeting = null;
        } catch (error) {
          retireRpc.failed(error);
          failures.push(requestErrorMessage(error, "The meeting could not be retired"));
        }
      } else {
        logCall("call", "retire skipped: this session does not own the current meeting", {
          origin: this.state.origin,
          hadCreated: Boolean(this.createdMeeting),
          hadCallCreated: Boolean(this.callCreatedMeeting)
        });
      }
      if (failures.length) {
        throw new Error(endFailureMessage(failures.join("; "), this.state.identityMode));
      }
    }
    settleTerminalState(request, releaseError) {
      this.activeCall.clear();
      const base = {
        ...this.state,
        ...request.finalState,
        streamPhase: request.finalState?.streamPhase === "error" ? "error" : "offline",
        audioStatus: "off",
        softap: undefined,
        recovery: undefined,
        transport: undefined
      };
      this.syncLinkRecovery(false);
      if (!releaseError) {
        const reason = request.reason;
        const failed = reason === "error" || reason === "softap-lost" || base.phase === "error";
        this.setState({
          ...base,
          phase: failed ? "error" : request.finalState?.phase ?? "ended",
          endReason: reason,
          error: request.message ?? (failed ? base.error : undefined),
          errorKind: failed ? request.errorKind ?? base.errorKind : undefined
        });
        return { success: true, reason };
      }
      if (request.reason === "ended") {
        warnCall("call", "end unconfirmed", { error: releaseError });
        this.setState({
          ...base,
          phase: "ended",
          endReason: "ended-unconfirmed",
          error: releaseError === END_GUEST_IDENTITY_COPY || releaseError === END_PRESENTER_DENIED_COPY ? releaseError : `${END_UNCONFIRMED_COPY} (${releaseError})`,
          errorKind: "end"
        });
        return { success: false, reason: "ended-unconfirmed", error: END_UNCONFIRMED_COPY };
      }
      const message = request.message ? `${request.message}. The meeting bot may still be present: ${releaseError}` : `The camera stopped, but the meeting bot may still be present: ${releaseError}`;
      this.setState({
        ...base,
        phase: "error",
        endReason: "error",
        error: message,
        errorKind: request.errorKind ?? "leave"
      });
      return { success: false, reason: "error", error: message };
    }
    handleStreamStatus(event) {
      if (!usesCloudflare(this.currentTransport())) {
        logChange("call", "call.streamEventOffTransport", event.phase, { transport: this.currentTransport() });
        return;
      }
      if (this.state.phase === "starting-stream" && event.phase === "connecting") {
        this.setState({ ...this.state, streamPhase: "connecting", streamReason: event.reason });
        return;
      }
      if (!["preparing-playback", "creating-bot", "joining", "waiting-room", "in-call", "reconnecting"].includes(this.state.phase)) {
        logChange("call", "call.streamEventIgnored", `${this.state.phase}/${event.phase}`, {
          reason: event.reason,
          error: event.error
        });
        return;
      }
      if (event.phase === "reconnecting") {
        this.clearAcsVideoGate();
        this.setState({
          ...this.state,
          streamPhase: "reconnecting",
          streamReason: event.reason,
          streamError: event.error,
          error: undefined,
          errorKind: undefined
        });
        if (this.state.provider !== "acs" && event.reason !== "glasses")
          this.queueStreamUpdate({ reconnecting: true });
        else {
          logCall("call", "provider not told about the interruption", {
            provider: this.state.provider,
            reason: event.reason
          });
        }
      } else if (event.phase === "active" && event.stream) {
        if (this.state.provider === "acs") {
          this.publishAcsVideo(event.stream.webrtcUrl);
        } else {
          this.setState({
            ...this.state,
            streamPhase: "active",
            streamReason: undefined,
            streamError: undefined,
            error: undefined,
            errorKind: undefined
          });
          this.queueStreamUpdate({
            webrtcUrl: event.stream.webrtcUrl,
            reconnecting: false,
            joinId: event.stream.streamId
          });
        }
      } else if (event.phase === "error") {
        this.clearAcsVideoGate();
        this.setState({ ...this.state, streamReason: event.reason, streamError: event.error });
        this.handleStreamFailure(event.error || "The glasses stream disconnected");
      } else {
        this.clearAcsVideoGate();
        this.setState({ ...this.state, streamPhase: event.phase, streamReason: event.reason });
      }
    }
    publishAcsVideo(whepUrl) {
      const rebuilding = Boolean(whepUrl) && whepUrl !== this.acsWhepUrl;
      const gated = rebuilding && this.hostReportsMediaSource;
      logCall("call", "publishing glasses video to ACS", {
        hasUrl: Boolean(whepUrl),
        rebuilding,
        gated,
        hostReportsMediaSource: this.hostReportsMediaSource
      });
      this.clearAcsVideoGate();
      if (gated && whepUrl)
        this.armAcsVideoGate(whepUrl);
      this.setState({
        ...this.state,
        streamPhase: gated ? "reconnecting" : "active",
        streamReason: gated ? "acs-video" : undefined,
        streamError: gated ? ACS_VIDEO_WAIT_COPY : undefined,
        error: undefined,
        errorKind: undefined
      });
      if (!whepUrl) {
        warnCall("call", "nothing handed to ACS: the active stream reported no WHEP URL");
        return;
      }
      this.acsWhepUrl = whepUrl;
      const videoRpc = beginRpc("meeting.updateVideoSource", { type: "whep", gated });
      this.meetingHost?.updateVideoSource({ type: "whep", url: whepUrl }).then(() => videoRpc.ok(), (error) => {
        videoRpc.failed(error);
        warnCall("call", "ACS video source update failed", {
          error: error instanceof Error ? error.message : String(error)
        });
        if (this.acsVideoGate?.url === whepUrl) {
          logCall("call", "acs video gate released: the rebuild never started");
          this.clearAcsVideoGate();
          this.setState({ ...this.state, streamPhase: "active", streamReason: undefined, streamError: undefined });
        }
      });
    }
    armAcsVideoGate(whepUrl) {
      logCall("call", "acs video gate armed", { reason: "whep rebuild", timeoutMs: ACS_VIDEO_GATE_MS });
      this.acsVideoGate = { url: whepUrl, rebuildSeen: false };
      this.acsVideoGateTimer = setTimeout(() => {
        this.acsVideoGateTimer = null;
        if (this.acsVideoGate?.url !== whepUrl) {
          logCall("call", "acs video gate timer fired for a gate that had already gone");
          return;
        }
        warnCall("call", "acs video gate expired without a live mediaSource", { timeoutMs: ACS_VIDEO_GATE_MS });
        this.clearAcsVideoGate();
        this.setState({ ...this.state, streamPhase: "active", streamReason: undefined, streamError: undefined });
      }, ACS_VIDEO_GATE_MS);
    }
    clearAcsVideoGate() {
      if (this.acsVideoGateTimer)
        clearTimeout(this.acsVideoGateTimer);
      this.acsVideoGateTimer = null;
      this.acsVideoGate = null;
    }
    trackAcsVideo(mediaSource, incomingSoftap) {
      if (!mediaSource) {
        logChange("call", "call.hostMediaSource", "unreported");
        return {};
      }
      logChange("call", "call.hostMediaSource", mediaSource, { transport: this.currentTransport() });
      this.hostReportsMediaSource = true;
      if (!usesCloudflare(this.currentTransport())) {
        if (mediaSource === "live")
          return { streamPhase: "active", streamReason: undefined, streamError: undefined };
        if (mediaSource === "failed") {
          const softapPhase = incomingSoftap?.phase ?? this.state.softap?.phase;
          if (softapPhase && softapPhase !== "live" && softapPhase !== "failed") {
            return { streamPhase: "connecting", streamReason: "ingest" };
          }
          return { streamPhase: "reconnecting", streamReason: "ingest" };
        }
        return { streamPhase: "connecting" };
      }
      const gate = this.acsVideoGate;
      if (!gate)
        return {};
      if (mediaSource !== "live") {
        if (!gate.rebuildSeen)
          logCall("call", "acs video gate saw the rebuild start", { mediaSource });
        gate.rebuildSeen = true;
        return {};
      }
      if (!gate.rebuildSeen) {
        logCall("call", "acs video gate held: this `live` still describes the old subscription");
        return {};
      }
      logCall("call", "acs video live; stream restored");
      this.clearAcsVideoGate();
      return { streamPhase: "active", streamReason: undefined, streamError: undefined };
    }
    async setMuted(muted) {
      if (this.state.provider === "acs") {
        logCall("call", "mute", { provider: "acs", sendMic: !muted, was: this.state.muted });
        const muteRpc2 = beginRpc("meeting.setMuted", { muted });
        try {
          await this.meetingHost?.setMuted(muted);
          muteRpc2.ok();
        } catch (error) {
          muteRpc2.failed(error);
          throw error;
        }
        this.setState({ ...this.state, muted });
        return { muted };
      }
      const muteRpc = beginRpc(muted ? "backend.mute" : "backend.unmute", { provider: this.state.provider });
      return (muted ? this.backend.mute() : this.backend.unmute()).then((value) => {
        muteRpc.ok({ muted: value.muted });
        return value;
      }, (error) => {
        muteRpc.failed(error);
        throw error;
      });
    }
    async setVideoEnabled(enabled) {
      if (this.state.provider !== "acs")
        throw new Error("The camera toggle is only available on Teams calls");
      if (typeof this.meetingHost?.setVideoEnabled !== "function") {
        throw new Error("Update the Mentra App to turn the camera off during a call");
      }
      logCall("call", "camera", { provider: "acs", sendVideo: enabled, was: this.state.videoEnabled });
      const videoRpc = beginRpc("meeting.setVideoEnabled", { enabled });
      try {
        await this.meetingHost.setVideoEnabled(enabled);
        videoRpc.ok();
      } catch (error) {
        videoRpc.failed(error);
        throw error;
      }
      this.setState({ ...this.state, videoEnabled: enabled });
      return { videoEnabled: enabled };
    }
    muteStatus() {
      if (this.state.provider === "acs") {
        logCall("call", "mute status answered from the host's last report", { muted: Boolean(this.state.muted) });
        return Promise.resolve({ muted: Boolean(this.state.muted) });
      }
      const statusRpc = beginRpc("backend.muteStatus");
      return this.backend.muteStatus().then((value) => {
        statusRpc.ok({ muted: value.muted });
        return value;
      }, (error) => {
        statusRpc.failed(error);
        throw error;
      });
    }
    handleAudioStatus(status, error) {
      logChange("call", "call.audioStatus", status, { error });
      this.setState({ ...this.state, audioStatus: status, audioError: error });
    }
    async dispose() {
      logCall("call", "dispose", { phase: this.state.phase, provider: this.state.provider });
      this.linkUnsub?.();
      this.linkUnsub = null;
      this.clearAcsVideoGate();
      if (!["idle", "ended"].includes(this.state.phase)) {
        await this.leave();
      } else {
        logCall("call", "dispose: no call to hang up", { phase: this.state.phase });
      }
      await this.meetingAudio.stop();
      await this.streams.dispose();
    }
    async runJoin(operation, meetingUrl, botName, paint, origin) {
      let botCreated = false;
      let acsJoined = false;
      const tapAtMs = Date.now();
      let lastStageAtMs = tapAtMs;
      let joinId;
      let currentStage = "path";
      let lastRecallStatus;
      const stage = (name, data) => {
        const now = Date.now();
        logJoin(joinId, name, { totalElapsedMs: now - tapAtMs, durationMs: now - lastStageAtMs, ...data });
        lastStageAtMs = now;
        currentStage = name;
      };
      const path = explainJoinRoute(meetingUrl, TEAMS_PROVIDER);
      stage("path", {
        ...path,
        meetingHost: Boolean(this.meetingHost),
        paint
      });
      this.clearAcsVideoGate();
      this.acsWhepUrl = null;
      this.setState({ ...this.state, identityMode: undefined, guestReason: undefined });
      this.lastAcsEndReason = undefined;
      this.lastAcsNativeState = undefined;
      this.acsLobbyEnteredAt = 0;
      this.acsLobbyDwellMs = undefined;
      this.lastTeamsRowLog = undefined;
      this.startCuePlayed = false;
      const transport = this.transportFor(meetingUrl);
      const softap = !usesCloudflare(transport);
      this.setState({
        phase: "checking-device",
        streamPhase: "offline",
        transport,
        meetingUrl,
        origin,
        audioStatus: "off",
        endReason: undefined,
        canEnd: false,
        endBlockedReason: undefined,
        softap: softap ? softapPreflightProgress(SOFTAP_PREFLIGHT_WAIT_COPY) : undefined
      });
      try {
        this.assertCurrent(operation);
        stage("checking-device");
        let webrtcUrl;
        if (softap) {
          if (!this.usesAcs(meetingUrl)) {
            warnCall("call", "join refused: SoftAP was selected for a link the ACS path cannot take", {
              host: meetingHostLabel(meetingUrl),
              transport
            });
            throw new Error("SoftAP calling is only available on the Teams ACS path");
          }
          if (this.streams.hasCamera === false) {
            warnCall("call", "join refused: these glasses have no camera", { transport });
            throw new Error(NO_CAMERA_COPY);
          }
          if (paint === "synthetic" || INVESTIGATION_ARM === "cheap-synthetic") {
            warnCall("call", "join refused: synthetic paint has no WHEP stream for ACS", { paint, transport });
            throw new Error("ACS Teams calling needs a live glasses WHEP stream. Synthetic paint is Recall-only.");
          }
          if (this.transport.preparePhoneWifi) {
            const wifiReady = await this.transport.preparePhoneWifi();
            this.assertCurrent(operation);
            if (wifiReady === false) {
              this.setState({
                ...this.state,
                phase: "ended",
                endReason: "cancelled",
                softap: undefined,
                transport: undefined
              });
              return { error: "Join cancelled" };
            }
            this.setState({ ...this.state, softap: softapPreflightProgress(SOFTAP_PREFLIGHT_WIFI_ON_COPY) });
          }
          stage("softap-host-owned", { transport });
          logSoftap(undefined, "join_requested", { host: meetingHostLabel(meetingUrl), origin });
          this.setState({
            phase: "preparing-playback",
            streamPhase: "connecting",
            transport,
            meetingUrl,
            origin,
            stream: null,
            audioStatus: "off",
            softap: softapPreflightProgress(SOFTAP_PREFLIGHT_TOKEN_COPY)
          });
        } else if (paint === "synthetic") {
          joinId = `synth-${crypto.randomUUID()}`;
          webrtcUrl = SYNTHETIC_PLACEHOLDER_WHEP;
          stage("stream-live", { mode: "synthetic", webrtc: false });
          this.setState({
            phase: "preparing-playback",
            streamPhase: "offline",
            transport,
            meetingUrl,
            origin,
            stream: null,
            audioStatus: "off"
          });
        } else {
          this.setState({
            phase: "starting-stream",
            streamPhase: "connecting",
            transport,
            meetingUrl,
            origin,
            audioStatus: "off"
          });
          stage("starting-stream");
          if (this.usesAcs(meetingUrl)) {
            this.streams.setCaptureAudio(ACS_CALL_MIC === "glasses");
          }
          const stream = await this.streams.ensureStarted();
          this.assertCurrent(operation);
          joinId = stream.streamId;
          webrtcUrl = stream.webrtcUrl;
          stage("stream-live", { mode: stream.mode, webrtc: Boolean(stream.webrtcUrl) });
          this.setState({
            phase: "preparing-playback",
            streamPhase: "active",
            transport,
            meetingUrl,
            origin,
            stream: this.streams.info,
            audioStatus: "off"
          });
        }
        if (this.usesAcs(meetingUrl)) {
          stage("route-acs", {
            ...path,
            meetingHost: Boolean(this.meetingHost),
            webrtc: Boolean(webrtcUrl),
            paint
          });
          if (!softap && (paint === "synthetic" || INVESTIGATION_ARM === "cheap-synthetic" || !webrtcUrl)) {
            warnCall("call", "join refused: the ACS route has no glasses WHEP stream to hand over", {
              paint,
              webrtc: Boolean(webrtcUrl)
            });
            throw new Error("ACS Teams calling needs a live glasses WHEP stream. Synthetic paint is Recall-only.");
          }
          if (!this.meetingHost) {
            warnCall("call", "join refused: this build's SDK has no meeting host", { route: path.route });
            throw new Error("Update the Mentra App to use Teams calling");
          }
          this.setState({
            ...this.state,
            phase: "joining",
            platform: "microsoft-teams",
            provider: "acs"
          });
          stage("acs-mint");
          let minted;
          if (this.transport.meetingConfiguration?.().credentialSource !== "runtime") {
            const mintRpc = beginRpc("backend.getAcsToken");
            try {
              minted = await this.backend.getAcsToken(crypto.randomUUID());
              mintRpc.ok({ acsUserId: minted.acsUserId, expiresOn: minted.expiresOn });
            } catch (error) {
              mintRpc.failed(error);
              if (error instanceof BackendRequestError && error.status === 404) {
                throw new Error("ACS token mint 404: Porter is still origin/dev, which has no POST /api/meet/acs-token. Deploy the ACS backend, then retry.");
              }
              if (error instanceof BackendRequestError && error.status === 429 && isCallLimitError(error.message)) {
                logCall("call", "acs-mint blocked by call quota", { status: 429, message: error.message });
              }
              throw error;
            }
            this.assertCurrent(operation);
            stage("acs-mint-ok", { acsUserId: minted.acsUserId, expiresOn: minted.expiresOn });
          }
          const profile = this.streams.currentProfile();
          const whip = toWhipVideo(profile);
          const acs = toAcsVideo(profile);
          stage("acs-join", {
            joinId,
            preset: profile.id,
            origin,
            requestedWhip: `${whip.width}×${whip.height} @${whip.fps} ${whip.bitrate ?? "auto"}`,
            requestedAcs: `${acs.width}×${acs.height} @${acs.fps} max ${acs.maxBitrateBps}`
          });
          const admission = this.waitForAcsAdmission(operation);
          const admitted = admission.promise;
          admitted.catch(() => {});
          await this.acquireMic();
          const joinRpc = beginRpc("meeting.join", {
            joinId,
            host: meetingHostLabel(meetingUrl),
            videoSource: softap ? "softap" : "whep",
            preset: profile.id
          });
          try {
            const joinedState = await this.meetingHost.join({
              provider: "acs-teams",
              meetingUrl,
              videoSource: softap ? { type: "softap" } : { type: "whep", url: webrtcUrl },
              ...minted ? { token: minted.token } : {},
              displayName: botName,
              video: acs,
              origin
            });
            if (operation === this.operation && joinedState.identityMode) {
              this.setState({
                ...this.state,
                identityMode: joinedState.identityMode,
                guestReason: joinedState.guestReason,
                ...this.trackEndCapability(joinedState.capabilities, joinedState.identityMode)
              });
            }
            admission.startTimeout();
            joinRpc.ok();
          } catch (error) {
            admission.cancel();
            joinRpc.failed(error);
            throw error;
          }
          acsJoined = true;
          this.activeCall.set({ meetingUrl, transport, operation });
          this.acsWhepUrl = softap ? null : webrtcUrl;
          this.assertCurrent(operation);
          stage("acs-join-ok");
          await admitted;
          stage("in-call", { provider: "acs" });
          return { botId: undefined };
        }
        stage("route-recall", {
          ...path,
          meetingHost: Boolean(this.meetingHost),
          webrtc: Boolean(webrtcUrl),
          paint
        });
        this.setState({ ...this.state, phase: "creating-bot", provider: "recall" });
        stage("join-post", { paint, reason: path.reason });
        const joinPostRpc = beginRpc("backend.joinMeet", { joinId, host: meetingHostLabel(meetingUrl), paint });
        let call;
        try {
          call = await this.backend.joinMeet({
            meetingUrl,
            botName,
            webrtcUrl,
            joinId,
            paint,
            attemptId: crypto.randomUUID()
          });
          joinPostRpc.ok({ callId: call.callId, botId: call.botId, status: call.status });
        } catch (error) {
          joinPostRpc.failed(error);
          throw error;
        }
        botCreated = true;
        this.activeCall.set({ meetingUrl, transport, operation });
        this.assertCurrent(operation);
        this.applyBackendCall(call);
        stage("join-accepted", { callId: call.callId, botId: call.botId, platform: call.platform });
        const current = this.streams.info;
        if (paint !== "synthetic" && current && current.webrtcUrl !== webrtcUrl) {
          const updateRpc = beginRpc("backend.updateStream", { at: "join", joinId: current.streamId });
          try {
            await this.backend.updateStream({
              webrtcUrl: current.webrtcUrl,
              reconnecting: false,
              joinId: current.streamId
            });
            updateRpc.ok();
          } catch (error) {
            updateRpc.failed(error);
            throw error;
          }
        }
        const deadline = Date.now() + JOIN_TIMEOUT_MS;
        let consecutiveFailures = 0;
        while (Date.now() < deadline) {
          this.assertCurrent(operation);
          let response;
          try {
            response = await this.backend.getCallStatus(false);
            consecutiveFailures = 0;
            logChange("call", "call.joinPoll", response.call?.status ?? "missing", { joinId });
          } catch (error) {
            consecutiveFailures += 1;
            if (consecutiveFailures >= 5) {
              warnCall("call", "join abandoned: five consecutive status polls failed", {
                failures: consecutiveFailures,
                error: error instanceof Error ? error.message : String(error)
              });
              throw error;
            }
            warnCall("call", "status poll failed", {
              failures: consecutiveFailures,
              error: error instanceof Error ? error.message : String(error)
            });
            await delay(STATUS_POLL_MS);
            continue;
          }
          if (!response.call) {
            warnCall("call", "join abandoned: the backend no longer has a call record", { joinId });
            throw new Error("The meeting bot disappeared while joining");
          }
          this.applyBackendCall(response.call);
          if (response.call.recallStatus !== lastRecallStatus) {
            lastRecallStatus = response.call.recallStatus;
            stage("bot-status", {
              recallStatus: response.call.recallStatus,
              phase: phaseForBackend(response.call.status)
            });
          }
          if (response.call.status === "in-call") {
            this.startMeetingAudio();
            this.startStatusMonitor(operation);
            stage("in-call");
            return { botId: response.call.botId };
          }
          if (response.call.status === "error" || response.call.status === "ended") {
            warnCall("call", "join abandoned: the bot reached a terminal status", {
              status: response.call.status,
              lastError: response.call.lastError
            });
            throw new Error(response.call.lastError || "The meeting bot could not join");
          }
          await delay(STATUS_POLL_MS);
        }
        warnCall("call", "join abandoned: the admission deadline passed", {
          timeoutMs: JOIN_TIMEOUT_MS,
          recallStatus: lastRecallStatus
        });
        throw new Error("The meeting bot was not admitted within two minutes");
      } catch (error) {
        let message = humanizeSoftapJoinError(requestErrorMessage(error, "Could not join the meeting"));
        const cancelled = operation !== this.operation;
        const failedStage = currentStage;
        const { errorType, statusCode } = classifyJoinError(error, failedStage);
        const supersededByNewJoin = cancelled && this.joinInFlight !== null;
        if (supersededByNewJoin && (botCreated || acsJoined)) {
          warnCall("call", "failed join left its own cleanup to the newer join that owns the host", {
            botCreated,
            acsJoined,
            failedStage
          });
        }
        if (botCreated && !supersededByNewJoin) {
          const cleanupRpc = beginRpc("backend.leaveMeet", { at: "join cleanup" });
          try {
            await this.backend.leaveMeet();
            cleanupRpc.ok();
          } catch (leaveError) {
            cleanupRpc.failed(leaveError);
            warnCall("call", "cleanup leave failed; the bot may still be in the meeting", {
              error: leaveError instanceof Error ? leaveError.message : String(leaveError)
            });
            const detail = leaveError instanceof Error ? leaveError.message : String(leaveError);
            message = `${message}. The meeting bot may still be present: ${detail}`;
          }
        }
        if (acsJoined && !supersededByNewJoin) {
          const cleanupRpc = beginRpc("meeting.leave", { at: "join cleanup" });
          try {
            await this.leaveMeetingHost();
            cleanupRpc.ok();
          } catch (leaveError) {
            cleanupRpc.failed(leaveError);
            warnCall("call", "ACS cleanup leave failed; this device may still be in the meeting", {
              error: leaveError instanceof Error ? leaveError.message : String(leaveError)
            });
          }
        }
        if (!supersededByNewJoin)
          await this.releaseMic();
        if (cancelled || operation !== this.operation) {
          stage("join-cancelled", { failedStage, botCreated, acsJoined });
          if (!supersededByNewJoin)
            this.activeCall.clear(operation);
          return { error: this.state.phase === "error" ? this.state.error ?? "Join cancelled" : "Join cancelled" };
        }
        await this.meetingAudio.stop();
        await this.streams.stop();
        stage("join-failed", { failedStage, errorType, statusCode, message, route: path.route, reason: path.reason });
        this.activeCall.clear(operation);
        const lost = this.state.endReason === "softap-lost" || isSoftapNetworkLost(message) || isSoftapNetworkLost(requestErrorMessage(error, ""));
        this.setState({
          ...this.state,
          phase: "error",
          streamPhase: "offline",
          transport: undefined,
          meetingUrl,
          error: message,
          errorKind: isDeadMeetingLink(this.lastAcsEndReason) ? "link" : lost ? "stream" : "join",
          endReason: lost ? "softap-lost" : this.state.endReason,
          streamReason: isGlassesLinkError(error, message) ? "glasses" : this.state.streamReason,
          audioStatus: "off"
        });
        return { error: message };
      }
    }
    trackSoftapProgress(progress, recovery) {
      if (!progress) {
        logChange("call", "call.softapChecklist", "absent", { transport: this.currentTransport() });
        return {};
      }
      if (isSoftapChecklistRegression(this.state.softap, progress, recovery)) {
        logCall("call", "softap checklist ignored a rewind", {
          from: this.state.softap?.steps.map((step) => `${step.step}:${step.status}`).join(" "),
          to: progress.steps.map((step) => `${step.step}:${step.status}`).join(" "),
          traceId: progress.traceId
        });
        return {};
      }
      logChange("call", "call.softapChecklist", progress.phase, { elapsedMs: progress.elapsedMs });
      for (const step of softapStepChanges(this.state.softap, progress)) {
        const line = {
          step: step.step,
          status: step.status,
          detail: step.detail,
          error: step.error,
          durationMs: step.durationMs,
          elapsedMs: progress.elapsedMs
        };
        if (step.status === "failed")
          warnSoftap(progress.traceId, "step_failed", line);
        else
          logSoftap(progress.traceId, `step_${step.status}`, line);
      }
      if (progress.phase !== this.state.softap?.phase) {
        logSoftap(progress.traceId, `sequence_${progress.phase}`, { elapsedMs: progress.elapsedMs });
      }
      this.maybeSpeakStartCue(progress);
      if (progress.phase === "live") {
        return { softap: progress, streamPhase: "active", streamReason: undefined, streamError: undefined };
      }
      return { softap: progress };
    }
    maybeSpeakStartCue(progress) {
      if (this.startCuePlayed)
        return;
      const hotspot = progress.steps.find((step) => step.step === "hotspot");
      if (hotspot?.status !== "running" && hotspot?.status !== "done")
        return;
      this.startCuePlayed = true;
      this.meetingAudio.speakCue(callStartCue(this.state.origin));
    }
    withTeamsStep(patch, acsState) {
      const base = patch.softap ?? this.state.softap;
      if (!base)
        return patch;
      const decided = decideTeamsStep(base, acsState);
      const host = base.steps.filter((step) => step.step !== "teams").map((step) => `${step.step}:${step.status}`).join(" ");
      const signature = `${acsState}|${decided.raw}|${decided.status}|${decided.hostComplete}`;
      if (signature !== this.lastTeamsRowLog) {
        this.lastTeamsRowLog = signature;
        logCall("call", decided.raw !== decided.status ? "teams row held" : "teams row", {
          acsState,
          raw: decided.raw,
          shown: decided.status,
          hostComplete: decided.hostComplete,
          origin: this.state.origin ?? "unknown",
          host
        });
      }
      return { ...patch, softap: applyTeamsStep(base, acsState, this.state.origin) };
    }
    async admitParticipant(participantId) {
      if (this.state.phase !== "in-call" || !this.state.canAdmit || !this.meetingHost?.admit) {
        throw new Error("This meeting does not allow you to admit guests");
      }
      const guest = this.state.participants?.find((participant) => participant.id === participantId);
      if (guest?.state !== "lobby")
        throw new Error("This guest is no longer waiting in the lobby");
      await this.meetingHost.admit(participantId);
    }
    trackEndCapability(capabilities, identityMode = this.state.identityMode) {
      const cap = capabilities?.hangUpForEveryone;
      const teamsUser = identityMode === "teams-user";
      logChange("call", "call.hostEndCapability", cap?.allowed ?? "unreported", {
        hostReason: cap?.reason,
        identityMode: identityMode ?? "unset",
        applied: teamsUser
      });
      if (!teamsUser)
        return { canEnd: false, endBlockedReason: undefined };
      if (cap?.allowed === true)
        return { canEnd: true, endBlockedReason: undefined };
      if (cap?.allowed == null || isTransientEndDenial(cap.reason)) {
        return { canEnd: false, endBlockedReason: END_BLOCKED_COPY.checking };
      }
      return { canEnd: false, endBlockedReason: END_BLOCKED_COPY.notOrganizer };
    }
    acsErrorKind(state) {
      if (state.state !== "error")
        return;
      if (isDeadMeetingLink(state.endReason)) {
        logCall("call", "acs error classified as a dead meeting link", {
          code: state.endReason?.code,
          subcode: state.endReason?.subcode
        });
        return "link";
      }
      if (isSoftapNetworkLost(state.error))
        return "stream";
      return this.joinInFlight || state.error?.startsWith("ACS_CONNECTION_LOST:") ? "join" : "remote";
    }
    echoAcsTransition(state) {
      if (state.state === this.lastAcsNativeState)
        return;
      const previous = this.lastAcsNativeState;
      this.lastAcsNativeState = state.state;
      if (state.state === "lobby" && this.acsLobbyEnteredAt === 0)
        this.acsLobbyEnteredAt = Date.now();
      if (state.state === "connected" && this.acsLobbyDwellMs === undefined) {
        this.acsLobbyDwellMs = this.acsLobbyEnteredAt === 0 ? 0 : Date.now() - this.acsLobbyEnteredAt;
      }
      logCall("call", "acs state", {
        origin: this.state.origin ?? "unknown",
        from: previous ?? "none",
        to: state.state,
        lobbyDwellMs: this.acsLobbyDwellMs ?? (this.acsLobbyEnteredAt === 0 ? undefined : Date.now() - this.acsLobbyEnteredAt),
        mediaSource: state.mediaSource
      });
    }
    applyMeetingState(state) {
      if (state.endReason)
        this.lastAcsEndReason = state.endReason;
      this.echoAcsTransition(state);
      const recoveredLive = state.state === "connected" && state.mediaSource === "live";
      const recovery = state.recovery ?? (recoveredLive && this.state.recovery?.active ? { ...this.state.recovery, active: false } : this.state.recovery);
      const recovering = isSoftapRecoveryActive(recovery);
      const lost = isSoftapNetworkLost(state.error);
      const phase = phaseForMeeting(state.state, this.state.origin);
      const holdInCall = recovering && (this.state.phase === "in-call" || this.state.phase === "reconnecting" || state.state === "connected");
      const video = this.trackAcsVideo(state.mediaSource, state.softap);
      const softap = this.withTeamsStep(this.trackSoftapProgress(state.softap, recovering ? recovery : undefined), state.state);
      const identityMode = state.identityMode ?? this.state.identityMode;
      const endable = this.trackEndCapability(state.capabilities, identityMode);
      this.syncLinkRecovery(recovering && this.currentTransport() === "softap");
      this.setState({
        ...this.state,
        ...softap,
        ...video,
        ...endable,
        ...state.identityMode ? { identityMode: state.identityMode, guestReason: state.guestReason } : {},
        ...recovering ? { streamPhase: "reconnecting", streamReason: "ingest", streamError: undefined } : {},
        phase: holdInCall ? "in-call" : phase,
        provider: "acs",
        platform: "microsoft-teams",
        muted: state.muted,
        videoEnabled: state.videoEnabled ?? this.state.videoEnabled,
        meetingUrl: state.meetingUrl ?? this.state.meetingUrl,
        recovery,
        error: recovering && lost ? undefined : lost ? softapLostCopy(state.error) : state.error,
        errorKind: holdInCall ? undefined : this.acsErrorKind(state),
        ...lost && !recovering ? { endReason: "softap-lost" } : {},
        audioStatus: "off",
        audioSource: state.audioSource,
        audioSourceReason: state.audioSourceReason,
        activeStream: state.activeStream,
        audioSafety: state.audioSafety,
        participants: toCallParticipants(state.participants) ?? this.state.participants,
        canAdmit: typeof this.meetingHost?.admit === "function" && (state.capabilities?.manageLobby?.allowed ?? this.state.canAdmit ?? false),
        startedAt: this.state.startedAt ?? (phase === "in-call" || phase === "reconnecting" || holdInCall ? Date.now() : undefined)
      });
    }
    syncLinkRecovery(active) {
      if (this.linkRecovering === active)
        return;
      this.linkRecovering = active;
      logCall("call", active ? "SoftAP recovery holding the call" : "SoftAP recovery no longer holding the call");
      this.transport.onSoftapRecovery?.(active);
    }
    subscribeMeeting(operation) {
      this.meetingUnsub?.();
      logCall("call", "subscribed to host state", { operation });
      this.meetingUnsub = this.meetingHost?.onState((state) => {
        if (operation !== this.operation) {
          logChange("call", "call.staleHostEvent", `${operation}/${this.operation}`, { nativeState: state.state });
          return;
        }
        logCall("call", "acs native", {
          nativeState: state.state,
          muted: state.muted,
          error: state.error,
          audioSource: state.audioSource,
          audioSourceReason: state.audioSourceReason,
          activeStream: state.activeStream,
          audioSafety: state.audioSafety,
          mediaSource: state.mediaSource,
          participants: state.participants?.length,
          recoveryActive: state.recovery?.active,
          recoveryGeneration: state.recovery?.generation
        });
        this.applyMeetingState(state);
        if (isSoftapRecoveryActive(this.state.recovery) && state.state === "error") {
          logCall("call", "SoftAP loss held: host is recovering the media path", {
            generation: this.state.recovery?.generation,
            deadlineAt: this.state.recovery?.deadlineAt,
            phase: this.state.recovery?.phase
          });
          return;
        }
        if (state.state === "error" && isSoftapNetworkLost(state.error)) {
          this.finishCall({
            reason: "softap-lost",
            sessionId: operation,
            message: softapLostCopy(state.error),
            errorKind: "stream",
            finalState: { streamPhase: "error", streamReason: "ingest", provider: "acs" }
          });
          return;
        }
        if (state.state === "disconnected" || state.state === "error") {
          this.finishRemoteCall({
            ...this.state,
            phase: state.state === "error" ? "error" : "ended",
            error: state.error,
            errorKind: this.acsErrorKind(state),
            audioStatus: "off",
            provider: "acs"
          }, operation);
        }
      }) ?? null;
    }
    waitForAcsAdmission(operation) {
      let startTimeout;
      let cancel;
      const promise = new Promise((resolve, reject) => {
        let settled = false;
        let timer;
        let unsub;
        const finish = (fn) => {
          if (settled) {
            logCall("call", "admission event ignored: this wait had already settled");
            return;
          }
          settled = true;
          if (timer !== undefined)
            clearTimeout(timer);
          unsub?.();
          fn();
        };
        let sawJoin = false;
        cancel = () => finish(() => reject(new Error("Join cancelled")));
        startTimeout = () => {
          if (settled || timer !== undefined)
            return;
          timer = setTimeout(() => {
            warnCall("call", "admission timed out", { timeoutMs: JOIN_TIMEOUT_MS, sawJoin });
            finish(() => reject(new Error("The meeting was not admitted within two minutes")));
          }, JOIN_TIMEOUT_MS);
        };
        unsub = this.meetingHost.onState((state) => {
          if (operation !== this.operation) {
            logCall("call", "admission abandoned: something newer owns the call", {
              operation,
              active: this.operation,
              nativeState: state.state
            });
            finish(() => reject(new Error("Join cancelled")));
            return;
          }
          const failedAdmission = state.state === "disconnected" || state.state === "error" || sawJoin && state.state === "idle";
          this.applyMeetingState(failedAdmission ? { ...state, state: "error", error: state.error || "The ACS meeting ended before admission" } : state);
          logCall("call", "acs native", {
            nativeState: state.state,
            muted: state.muted,
            error: state.error,
            audioSource: state.audioSource,
            audioSourceReason: state.audioSourceReason,
            activeStream: state.activeStream,
            audioSafety: state.audioSafety,
            mediaSource: state.mediaSource,
            participants: state.participants?.length
          });
          if (state.state === "connecting" || state.state === "lobby" || state.state === "connected") {
            sawJoin = true;
          }
          if (state.state === "connected") {
            finish(() => {
              this.subscribeMeeting(operation);
              resolve();
            });
          } else if (state.state === "error" || state.state === "disconnected") {
            warnCall("call", "admission failed before we were let in", {
              nativeState: state.state,
              error: state.error
            });
            finish(() => reject(new Error(state.error || "The ACS meeting ended before admission")));
          } else if (sawJoin && state.state === "idle") {
            warnCall("call", "admission failed: the host went idle after joining", { error: state.error });
            finish(() => reject(new Error(state.error || "The ACS meeting ended before admission")));
          } else {
            logChange("call", "call.awaitingAdmission", state.state, { sawJoin });
          }
        });
        if (settled) {
          unsub?.();
          logCall("call", "admission settled inside the subscribe call");
        }
      });
      return { promise, startTimeout, cancel };
    }
    applyBackendCall(call) {
      this.setState({
        ...this.state,
        phase: phaseForBackend(call.status),
        callId: call.callId,
        botId: call.botId,
        meetingUrl: call.meetingUrl,
        platform: call.platform,
        provider: "recall",
        recallStatus: call.recallStatus,
        startedAt: call.startedAt ? Date.parse(call.startedAt) : this.state.startedAt,
        error: call.lastError,
        errorKind: call.status === "error" ? "remote" : undefined,
        watchUrl: call.watchUrl ?? this.state.watchUrl
      });
    }
    queueStreamUpdate(args) {
      this.streamUpdateQueue = this.streamUpdateQueue.then(() => {
        const updateRpc = beginRpc("backend.updateStream", {
          reconnecting: args.reconnecting,
          joinId: args.joinId,
          webrtc: Boolean(args.webrtcUrl)
        });
        return this.backend.updateStream(args).then((value) => {
          updateRpc.ok();
          return value;
        }, (error) => {
          updateRpc.failed(error);
          throw error;
        });
      }).then(() => {
        return;
      }).catch((error) => {
        warnCall("call", "backend stream update failed", {
          error: error instanceof Error ? error.message : String(error)
        });
      });
    }
    startStatusMonitor(operation) {
      if (this.statusMonitorOperation === operation) {
        logChange("call", "call.statusMonitor", operation, { reason: "already running" });
        return;
      }
      logCall("call", "status monitor started", { operation, pollMs: STATUS_POLL_MS });
      this.statusMonitorOperation = operation;
      const monitor = this.monitorCallStatus(operation).finally(() => {
        if (this.statusMonitorOperation === operation) {
          this.statusMonitorOperation = -1;
          this.statusMonitor = null;
        }
      });
      this.statusMonitor = monitor;
    }
    async monitorCallStatus(operation) {
      let failures = 0;
      while (operation === this.operation) {
        await delay(STATUS_POLL_MS);
        if (operation !== this.operation) {
          logCall("call", "status monitor stopped: something newer owns the call", {
            operation,
            active: this.operation
          });
          return;
        }
        try {
          const { call } = await this.backend.getCallStatus(false);
          failures = 0;
          if (operation !== this.operation) {
            logCall("call", "status monitor discarded a read: something newer owns the call", {
              operation,
              active: this.operation
            });
            return;
          }
          logChange("call", "call.backendStatus", call?.status ?? "missing", { recallStatus: call?.recallStatus });
          if (!call) {
            warnCall("call", "the backend lost the call record; treating it as a remote end", { operation });
            await this.finishRemoteCall({ phase: "ended", audioStatus: "off" }, operation);
            return;
          }
          this.applyBackendCall(call);
          if (call.status === "in-call")
            this.startMeetingAudio();
          if (call.status === "ended" || call.status === "error") {
            const finalState = {
              ...this.state,
              phase: call.status,
              error: call.status === "error" ? call.lastError || "The meeting bot stopped" : undefined,
              errorKind: call.status === "error" ? "remote" : undefined,
              audioStatus: "off"
            };
            logCall("call", "status monitor saw the call end remotely", {
              status: call.status,
              lastError: call.lastError
            });
            await this.finishRemoteCall(finalState, operation);
            return;
          }
        } catch (error) {
          failures += 1;
          warnCall("call", "background status check failed", {
            failures,
            error: error instanceof Error ? error.message : String(error)
          });
          await delay(Math.min(1e4, STATUS_POLL_MS * 2 ** Math.min(failures, 3)));
        }
      }
      logCall("call", "status monitor exited", { operation, active: this.operation });
    }
    async finishRemoteCall(finalState, operation) {
      await this.finishCall({
        reason: "remote-ended",
        sessionId: operation,
        errorKind: finalState.errorKind,
        finalState
      });
    }
    startMeetingAudio() {
      try {
        this.meetingAudio.start();
        logChange("call", "call.meetingAudio", "requested", { phase: this.state.phase });
      } catch (error) {
        warnCall("call", "meeting audio unavailable", {
          error: error instanceof Error ? error.message : String(error)
        });
      }
    }
    handleStreamFailure(message) {
      return this.handleFatalFailure(message, "stream");
    }
    async handleFatalFailure(message, errorKind) {
      if (this.handlingStreamFailure) {
        logCall("call", "fatal failure dropped: one is already tearing the call down", { errorKind, message });
        return;
      }
      warnCall("call", "fatal failure; tearing the call down", { errorKind, message, phase: this.state.phase });
      this.handlingStreamFailure = true;
      try {
        await this.finishCall({
          reason: "error",
          sessionId: this.operation,
          message,
          errorKind,
          finalState: { streamPhase: "error" }
        });
      } finally {
        this.handlingStreamFailure = false;
      }
    }
    assertCurrent(operation) {
      if (operation !== this.operation) {
        logCall("call", "join cancelled at a checkpoint", { operation, active: this.operation });
        throw new Error("Join cancelled");
      }
    }
    setState(next) {
      const prev = this.state;
      const origin = next.phase === "idle" ? undefined : next.origin ?? prev.origin;
      const photo = next.phase === "in-call" ? "photo" in next ? next.photo : prev.phase === "in-call" && prev.callId === next.callId ? prev.photo : undefined : undefined;
      this.state = { ...next, origin, photo, ownsMeeting: false };
      this.state = { ...this.state, ownsMeeting: this.ownedMeeting() !== null };
      const meetingUrl = this.joinRequest?.operation === this.operation ? this.joinRequest.meetingUrl : this.state.meetingUrl;
      if (this.state.phase === "in-call" && meetingUrl && this.admittedCall?.operation !== this.operation) {
        this.admittedCall = {
          operation: this.operation,
          meetingUrl,
          origin: this.state.origin ?? "joined",
          platform: this.state.platform
        };
        this.lastCall.clear("a new call was admitted");
      }
      const snapshot = this.getState();
      logChange("call", "call.phase", snapshot.phase, {
        endReason: snapshot.endReason,
        errorKind: snapshot.errorKind,
        transport: snapshot.transport
      });
      logChange("call", "call.streamPhase", snapshot.streamPhase, {
        reason: snapshot.streamReason,
        error: snapshot.streamError
      });
      if (prev.phase !== snapshot.phase || prev.streamPhase !== snapshot.streamPhase || prev.audioStatus !== snapshot.audioStatus || prev.recallStatus !== snapshot.recallStatus || prev.error !== snapshot.error || prev.botId !== snapshot.botId) {
        logCall("call", "state", {
          phase: snapshot.phase,
          streamPhase: snapshot.streamPhase,
          audio: snapshot.audioStatus,
          recall: snapshot.recallStatus,
          platform: snapshot.platform,
          provider: snapshot.provider,
          botId: snapshot.botId,
          error: snapshot.error,
          errorKind: snapshot.errorKind,
          ...summarizeStream(snapshot.stream)
        });
      }
      this.onEvent(snapshot);
    }
  }

  // src/background/managers/PhotoManager.ts
  var PHOTO_SHOW_MS = 4000;
  var PHOTO_DELIVERY_BUDGET_MS = 60000;
  var PHOTO_FAILED_COPY = "Photo couldn't be shared";
  var PHOTO_RESULT_LINGER_MS = 3000;
  function photoCallKey(state) {
    if (state.callId)
      return state.callId;
    return state.provider === "acs" ? `acs:${state.meetingUrl ?? "teams"}` : undefined;
  }
  function abortError() {
    const error = new Error("aborted");
    error.name = "AbortError";
    return error;
  }
  function isAbort(error) {
    return error instanceof Error && error.name === "AbortError";
  }
  var sleep = (ms, signal) => new Promise((resolve, reject) => {
    const timer = setTimeout(resolve, ms);
    const onAbort = () => {
      clearTimeout(timer);
      reject(abortError());
    };
    if (signal.aborted)
      onAbort();
    else
      signal.addEventListener("abort", onAbort, { once: true });
  });
  function stillUnsupported(error) {
    const failure = error;
    return failure?.reason === "unsupported" || failure?.code === "NOT_IMPLEMENTED";
  }

  class PhotoManager {
    host;
    onChip;
    showMs;
    resultLingerMs;
    unsubButton = null;
    unsubExpired = null;
    operation = null;
    generation = 0;
    chipTimer = null;
    stillRefused = false;
    snapshot = {
      phase: "idle",
      usesAcs: false,
      shareHdPhoto: false,
      hostCanHold: false,
      hostCanCaptureStill: false
    };
    constructor(host, onChip, showMs = PHOTO_SHOW_MS, resultLingerMs = PHOTO_RESULT_LINGER_MS) {
      this.host = host;
      this.onChip = onChip;
      this.showMs = showMs;
      this.resultLingerMs = resultLingerMs;
    }
    sync(snapshot) {
      const previous = this.snapshot;
      this.snapshot = snapshot;
      const callEnded = snapshot.phase !== "in-call" || !snapshot.callId;
      const replaced = Boolean(this.operation && snapshot.callId && this.operation.callId !== snapshot.callId);
      if (callEnded || replaced || previous.phase === "in-call" && snapshot.phase !== "in-call") {
        this.abort("leave");
      } else if (!this.shouldSubscribe() && this.operation) {
        this.abort("cancel");
      }
      if (this.shouldSubscribe()) {
        if (!this.unsubButton)
          this.unsubButton = this.host.onButton((press) => void this.onPress(press));
        if (!this.unsubExpired) {
          this.unsubExpired = this.host.onPublisherExpired((event) => this.onExpired(event.pauseId));
        }
        return;
      }
      this.releaseSubscription();
    }
    subscriberCount() {
      return this.unsubButton ? 1 : 0;
    }
    dispose() {
      this.abort("leave");
      this.releaseSubscription();
      this.cancelChipClear();
    }
    cancelChipClear() {
      if (this.chipTimer)
        clearTimeout(this.chipTimer);
      this.chipTimer = null;
    }
    clearChipLater() {
      this.cancelChipClear();
      this.chipTimer = setTimeout(() => {
        this.chipTimer = null;
        if (!this.operation)
          this.onChip(undefined);
      }, this.resultLingerMs);
    }
    shouldSubscribe() {
      if (this.snapshot.phase !== "in-call" || !this.snapshot.callId || !this.snapshot.shareHdPhoto)
        return false;
      if (this.snapshot.usesAcs && !this.snapshot.hostCanHold)
        return false;
      return true;
    }
    usesStillCapture() {
      return this.snapshot.usesAcs && this.snapshot.transport === "softap" && this.snapshot.hostCanCaptureStill && !this.stillRefused;
    }
    releaseSubscription() {
      this.unsubButton?.();
      this.unsubButton = null;
      this.unsubExpired?.();
      this.unsubExpired = null;
    }
    abort(mode) {
      const operation = this.operation;
      if (!operation)
        return;
      operation.abort.abort();
      if (mode === "cancel")
        this.finish(operation, true);
      else
        this.operation = null;
      this.onChip(undefined);
    }
    owns(operation) {
      return this.operation === operation && !operation.abort.signal.aborted;
    }
    onExpired(pauseId) {
      const operation = this.operation;
      if (!operation || operation.pauseId !== pauseId)
        return;
      operation.pauseId = undefined;
      operation.abort.abort();
      this.onChip({ phase: "failed", message: PHOTO_FAILED_COPY });
      this.host.showLive().catch(() => {
        return;
      });
      this.host.postPhase({ callId: operation.callId, generation: operation.generation, phase: "live" }).catch(() => {
        return;
      });
    }
    async onPress(press) {
      if (press.pressType !== "short" || this.operation || !this.shouldSubscribe())
        return;
      const callId = this.snapshot.callId;
      if (!callId)
        return;
      const operation = {
        callId,
        generation: ++this.generation,
        streamPaused: false,
        hostOwnsTile: false,
        abort: new AbortController
      };
      this.operation = operation;
      this.cancelChipClear();
      let shown = false;
      try {
        this.onChip({ phase: "taking" });
        if (this.usesStillCapture() && await this.captureStill(operation)) {
          shown = true;
          return;
        }
        if (!this.owns(operation))
          return;
        await this.holdCard(operation);
        if (!this.owns(operation))
          return;
        await this.pause(operation);
        if (!this.owns(operation))
          return;
        this.onChip({ phase: "sharing" });
        const photo = await this.host.takePhoto(PHOTO_DELIVERY_BUDGET_MS);
        if (!this.owns(operation))
          return;
        await this.show(operation, photo.photoUrl);
        shown = true;
        this.onChip({ phase: "shared", photoUrl: photo.photoUrl });
        await sleep(this.showMs, operation.abort.signal);
      } catch (error) {
        if (!this.owns(operation))
          return;
        if (!isAbort(error))
          this.onChip({ phase: "failed", message: PHOTO_FAILED_COPY });
      } finally {
        const finishedHere = this.operation === operation;
        await this.finish(operation, !shown);
        if (finishedHere && !operation.abort.signal.aborted)
          this.clearChipLater();
      }
    }
    async captureStill(operation) {
      operation.hostOwnsTile = true;
      try {
        await this.host.captureStill(this.showMs, (phase) => {
          if (!this.owns(operation))
            return;
          if (phase === "uploading")
            this.onChip({ phase: "sharing" });
          else if (phase === "shown")
            this.onChip({ phase: "shared" });
        });
      } catch (error) {
        if (!stillUnsupported(error))
          throw error;
        this.stillRefused = true;
        operation.hostOwnsTile = false;
        return false;
      }
      if (this.owns(operation))
        this.onChip({ phase: "shared" });
      return true;
    }
    async holdCard(operation) {
      if (this.snapshot.usesAcs)
        await this.host.showCard();
      else {
        await this.host.postPhase({ callId: operation.callId, generation: operation.generation, phase: "card" });
      }
    }
    async pause(operation) {
      if (this.snapshot.usesAcs) {
        const paused = await this.host.pausePublisher();
        operation.pauseId = paused.pauseId;
      }
      if (this.snapshot.transport !== "softap") {
        await this.host.pauseStream();
        operation.streamPaused = true;
      }
    }
    async show(operation, photoUrl) {
      if (this.snapshot.usesAcs) {
        await this.host.showImage(photoUrl, this.showMs);
        return;
      }
      await this.host.postPhase({
        callId: operation.callId,
        generation: operation.generation,
        phase: "photo",
        photoUrl,
        durationMs: this.showMs
      });
    }
    async finish(operation, returnLive) {
      const current = this.operation === operation;
      if (current)
        this.operation = null;
      if (!current)
        return;
      if (operation.hostOwnsTile)
        return;
      if (returnLive) {
        if (this.snapshot.usesAcs)
          await this.host.showLive().catch(() => {
            return;
          });
        else {
          await this.host.postPhase({ callId: operation.callId, generation: operation.generation, phase: "live" }).catch(() => {
            return;
          });
        }
      } else if (this.snapshot.usesAcs) {
        await this.host.showLive().catch(() => {
          return;
        });
      }
      if (operation.pauseId && this.snapshot.phase === "in-call" && this.snapshot.callId === operation.callId) {
        await this.host.resumePublisher(operation.pauseId).catch(() => {
          return;
        });
      }
      if (operation.streamPaused && this.snapshot.phase === "in-call" && this.snapshot.callId === operation.callId) {
        await this.host.resumeStream().catch(() => {
          return;
        });
      }
    }
  }

  // src/background/managers/GlassesLinkMonitor.ts
  var LINK_GRACE_MS = 45000;
  var SOFTAP_RETURN_DEADLINE_MS = 60000;
  var RECOVERY_LINK_GRACE_MS = SOFTAP_RETURN_DEADLINE_MS + 5000;

  class GlassesLinkMonitor {
    session;
    graceMs;
    snapshot = { state: "unknown", since: null };
    graceTimer = null;
    unsub = null;
    recovering = false;
    listeners = new Set;
    waiters = new Set;
    constructor(session, graceMs = LINK_GRACE_MS) {
      this.session = session;
      this.graceMs = graceMs;
    }
    setRecovering(recovering) {
      if (this.recovering === recovering)
        return;
      this.recovering = recovering;
      logCall("link", recovering ? "grace paused: SoftAP recovery is holding the call" : "SoftAP recovery ended", {
        state: this.snapshot.state,
        graceArmed: this.graceTimer !== null
      });
      if (recovering) {
        this.clearGrace();
        return;
      }
      if (this.snapshot.state === "reconnecting")
        this.armGrace("recovery-ended");
    }
    setGraceMs(graceMs) {
      if (this.graceMs === graceMs)
        return;
      this.graceMs = graceMs;
      logCall("link", "grace duration changed", { graceMs, state: this.snapshot.state, recovering: this.recovering });
      if (this.graceTimer && this.snapshot.state === "reconnecting" && !this.recovering) {
        this.armGrace("grace-ms");
      }
    }
    start() {
      if (this.unsub) {
        logCall("link", "start ignored: already watching the connection feed", { state: this.snapshot.state });
        return;
      }
      logCall("link", "watching the glasses connection feed", { graceMs: this.graceMs, state: this.snapshot.state });
      this.unsub = this.session.glasses.onConnection((data) => {
        const up = connectionFromEvent(data);
        if (up === null) {
          logChange("link", "link.unreadableEvent", data && typeof data === "object" ? Object.keys(data) : typeof data);
          return;
        }
        this.apply(up, "onConnection");
      });
    }
    get state() {
      return this.snapshot.state;
    }
    get connected() {
      if (this.snapshot.state === "unknown")
        return null;
      return this.snapshot.state === "connected";
    }
    get current() {
      return { ...this.snapshot };
    }
    onChange(listener) {
      this.listeners.add(listener);
      return () => {
        this.listeners.delete(listener);
      };
    }
    waitForConnected(timeoutMs, cancelled = () => false) {
      if (this.snapshot.state === "connected") {
        logCall("link", "wait skipped: the link is already up");
        return Promise.resolve(true);
      }
      if (cancelled()) {
        logCall("link", "wait refused: the caller had already moved on", { state: this.snapshot.state });
        return Promise.resolve(false);
      }
      const startedAt = Date.now();
      logCall("link", "waiting for the link", { timeoutMs, state: this.snapshot.state });
      return new Promise((resolve) => {
        let unsub = null;
        const timer = setTimeout(() => finish(false), timeoutMs);
        const finish = (value) => {
          clearTimeout(timer);
          unsub?.();
          this.waiters.delete(check);
          const waitedMs = Date.now() - startedAt;
          if (value)
            logCall("link", "wait satisfied: link up", { waitedMs });
          else
            warnCall("link", "wait gave up", { waitedMs, timeoutMs, state: this.snapshot.state });
          resolve(value);
        };
        const check = () => {
          if (cancelled())
            finish(false);
          else if (this.snapshot.state === "connected")
            finish(true);
        };
        this.waiters.add(check);
        unsub = this.onChange(check);
      });
    }
    interrupt() {
      if (this.waiters.size)
        logCall("link", "re-checking pending waits", { waiters: this.waiters.size });
      for (const check of [...this.waiters])
        check();
    }
    observeLink(connected) {
      this.apply(connected, "wifi-hint");
    }
    dispose() {
      logCall("link", "dispose", { state: this.snapshot.state, listeners: this.listeners.size, waiters: this.waiters.size });
      this.unsub?.();
      this.unsub = null;
      this.recovering = false;
      this.clearGrace();
      this.interrupt();
      this.listeners.clear();
    }
    apply(connected, source) {
      logChange("link", "link.reported", connected, { source, state: this.snapshot.state });
      if (connected) {
        this.clearGrace();
        this.set("connected");
        return;
      }
      if (this.snapshot.state === "reconnecting" || this.snapshot.state === "disconnected") {
        logChange("link", "link.downRepeat", this.snapshot.state, { source, graceArmed: this.graceTimer !== null });
        return;
      }
      this.set("reconnecting");
      if (this.recovering) {
        logCall("link", "grace skipped: SoftAP recovery is holding the call", { source });
        return;
      }
      this.armGrace(source);
    }
    armGrace(source) {
      this.clearGrace();
      logCall("link", "grace armed: the host is auto-reconnecting", { graceMs: this.graceMs, source });
      this.graceTimer = setTimeout(() => {
        this.graceTimer = null;
        if (this.recovering) {
          logCall("link", "grace expired but SoftAP recovery is still holding the call");
          return;
        }
        if (this.snapshot.state === "reconnecting") {
          warnCall("link", "grace expired: treating the glasses as disconnected", { graceMs: this.graceMs });
          this.set("disconnected");
          return;
        }
        logCall("link", "grace expired but the link had already moved on", { state: this.snapshot.state });
      }, this.graceMs);
    }
    set(state) {
      if (this.snapshot.state === state)
        return;
      const previous = this.snapshot.state;
      const heldMs = this.snapshot.since === null ? null : Date.now() - this.snapshot.since;
      this.snapshot = { state, since: Date.now() };
      logCall("link", `${previous} → ${state}`, { heldMs, listeners: this.listeners.size, waiters: this.waiters.size });
      for (const listener of [...this.listeners])
        listener(this.current);
    }
    clearGrace() {
      if (this.graceTimer)
        clearTimeout(this.graceTimer);
      this.graceTimer = null;
    }
  }
  function connectionFromEvent(data) {
    if (!data || typeof data !== "object")
      return null;
    const rec = data;
    if (typeof rec.connected === "boolean")
      return rec.connected;
    if (rec.connection && typeof rec.connection.state === "string") {
      return rec.connection.state === "connected";
    }
    return null;
  }

  // src/background/managers/DeviceManager.ts
  function batteryBand(level) {
    if (level === null)
      return "unknown";
    if (level <= 5)
      return "critical";
    if (level <= 15)
      return "low";
    if (level <= 40)
      return "fair";
    return "good";
  }
  function modelNameOf(capabilities) {
    const name = capabilities?.modelName;
    return typeof name === "string" && name.trim() ? name.trim() : null;
  }

  class DeviceManager {
    session;
    onChange;
    link;
    state = {
      connected: false,
      link: "unknown",
      linkSince: null,
      wifiConnected: false,
      wifiKnown: false,
      batteryLevel: null,
      charging: null,
      hasCamera: false,
      hasSpeaker: false,
      modelName: null
    };
    unsubs = [];
    constructor(session, onChange, link = new GlassesLinkMonitor(session)) {
      this.session = session;
      this.onChange = onChange;
      this.link = link;
    }
    start() {
      this.state.hasCamera = Boolean(this.session.capabilities?.hasCamera);
      this.state.hasSpeaker = Boolean(this.session.capabilities?.hasSpeaker);
      this.state.modelName = modelNameOf(this.session.capabilities);
      this.link.start();
      this.applyLink(this.link.current);
      logCall("device", "start", this.getState());
      this.unsubs.push(this.link.onChange((snapshot) => {
        this.applyLink(snapshot);
        this.update({});
      }), this.session.glasses.onBattery((data) => {
        logChange("device", "device.battery", `${batteryBand(data.level ?? null)}${data.charging ? " charging" : ""}`, {
          level: data.level,
          charging: data.charging
        });
        this.update({ batteryLevel: data.level, charging: data.charging });
      }), this.session.glasses.onWifi((data) => this.applyWifi(data)), this.session.onCapabilitiesChange((capabilities) => {
        const modelName = modelNameOf(capabilities);
        if (modelName !== this.state.modelName)
          this.update({ modelName });
      }));
    }
    getState() {
      return { ...this.state };
    }
    applyLink(snapshot) {
      logChange("device", "device.link", snapshot.state, { since: snapshot.since });
      this.state = {
        ...this.state,
        link: snapshot.state,
        linkSince: snapshot.since,
        connected: snapshot.state === "connected"
      };
    }
    applyWifi(data) {
      const hinted = data.linkConnected;
      if (typeof hinted === "boolean")
        this.link.observeLink(hinted);
      const linkDown = hinted === false || this.link.connected === false;
      if (!data.connected && linkDown) {
        logChange("device", "device.wifiHeld", this.state.wifiConnected, {
          hinted,
          link: this.state.link,
          wifiKnown: this.state.wifiKnown
        });
        return;
      }
      logChange("device", "device.wifi", data.connected, { ssid: data.ssid, known: this.state.wifiKnown });
      this.update({ wifiConnected: data.connected, wifiKnown: true });
    }
    update(patch) {
      const prev = this.state;
      this.state = { ...this.state, ...patch };
      if (prev.connected !== this.state.connected || prev.link !== this.state.link || prev.wifiConnected !== this.state.wifiConnected || prev.hasCamera !== this.state.hasCamera) {
        logCall("device", "state", this.getState());
      }
      logChange("device", "device.push", `${this.state.link}/wifi=${this.state.wifiConnected}`, {
        patch: Object.keys(patch),
        wifiKnown: this.state.wifiKnown,
        battery: batteryBand(this.state.batteryLevel),
        hasCamera: this.state.hasCamera,
        hasSpeaker: this.state.hasSpeaker
      });
      this.onChange(this.getState());
    }
    dispose() {
      logCall("device", "dispose", { subscriptions: this.unsubs.length, ...this.getState() });
      for (const unsub of this.unsubs)
        unsub();
      this.unsubs = [];
    }
  }

  // src/background/managers/MeetingAudioManager.ts
  var RETRY_BASE_MS = 750;
  var EMPTY_POLL_DELAY_MS = 250;
  var delay2 = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  class MeetingAudioManager {
    session;
    backend;
    onStatus;
    desired = false;
    generation = 0;
    writer = null;
    loopDone = null;
    pollController = null;
    constructor(session, backend, onStatus) {
      this.session = session;
      this.backend = backend;
      this.onStatus = onStatus;
    }
    report(status, error) {
      logChange("audio", "audio.status", status, { error, generation: this.generation });
      this.onStatus(status, error);
    }
    start() {
      if (this.desired) {
        logChange("audio", "audio.startIgnored", this.generation, { reason: "already relaying" });
        return;
      }
      if (this.session.capabilities && !this.session.capabilities.hasSpeaker) {
        const message = "These glasses do not have a speaker";
        warnCall("audio", "start refused: these glasses have no speaker");
        this.report("error", message);
        throw new Error(message);
      }
      this.desired = true;
      const generation = ++this.generation;
      logCall("audio", "start", { generation });
      this.loopDone = this.loop(generation).finally(() => {
        if (generation === this.generation)
          this.loopDone = null;
      });
    }
    async stop() {
      if (!this.desired && !this.writer && !this.loopDone) {
        logChange("audio", "audio.stopIgnored", this.generation, { reason: "nothing relaying" });
        return;
      }
      logCall("audio", "stop requested", {
        generation: this.generation,
        desired: this.desired,
        writer: Boolean(this.writer),
        polling: Boolean(this.pollController)
      });
      this.desired = false;
      ++this.generation;
      this.pollController?.abort();
      this.pollController = null;
      const writer = this.writer;
      this.writer = null;
      await writer?.abort().catch((error) => {
        warnCall("audio", "writer abort failed", { error: error instanceof Error ? error.message : String(error) });
      });
      await this.loopDone?.catch(() => {});
      this.loopDone = null;
      this.report("off");
      logCall("audio", "stopped", { generation: this.generation });
    }
    async speakChat(text) {
      const resume = this.desired;
      logCall("audio", "speaking a chat message", { chars: text.length, truncated: text.length > 500, resume });
      await this.stop();
      try {
        await this.session.speaker.speak(text.slice(0, 500), { stopOtherAudio: true });
        logCall("audio", "chat message spoken");
      } catch (error) {
        warnCall("audio", "chat message failed", { error: error instanceof Error ? error.message : String(error) });
        throw error;
      } finally {
        if (resume)
          this.start();
      }
    }
    async speakCue(text) {
      if (this.session.capabilities && !this.session.capabilities.hasSpeaker) {
        logCall("audio", "cue skipped: these glasses have no speaker", { text });
        return;
      }
      const startedAt = Date.now();
      logCall("audio", "cue", { text, relaying: this.desired });
      try {
        await this.session.speaker.speak(text, { stopOtherAudio: false });
        logCall("audio", "cue spoken", { text, ms: Date.now() - startedAt });
      } catch (error) {
        logCall("audio", "cue failed", {
          text,
          ms: Date.now() - startedAt,
          error: error instanceof Error ? error.message : String(error)
        });
      }
    }
    async loop(generation) {
      let failures = 0;
      while (this.desired && generation === this.generation) {
        let cursor = -1;
        let callId = null;
        try {
          this.report(failures ? "reconnecting" : "connecting");
          this.writer = await tracedRpc("speaker.createStream", () => this.session.speaker.createStream({
            sampleRate: 16000,
            channels: 1,
            stopOtherAudio: true
          }), { request: { generation, sampleRate: 16000, attempt: failures + 1 } });
          this.report("playing");
          logCall("audio", "playing", { generation });
          while (this.desired && generation === this.generation && this.writer) {
            this.pollController = new AbortController;
            const response = await this.backend.pollMeetingAudio(cursor, this.pollController.signal);
            this.pollController = null;
            logChange("audio", "audio.poll", response.chunks.length ? "chunks" : "empty", { generation });
            if (response.sampleRate !== 16000)
              throw new Error(`Unsupported meeting audio rate: ${response.sampleRate}`);
            if (callId && response.callId && callId !== response.callId) {
              logCall("audio", "call changed; skipping to live edge", { generation });
              callId = response.callId;
              cursor = -1;
              continue;
            }
            callId = response.callId;
            cursor = response.cursor;
            for (const chunk of response.chunks) {
              if (!this.desired || generation !== this.generation || !this.writer) {
                logCall("audio", "dropping the rest of a chunk batch", {
                  generation,
                  desired: this.desired,
                  writer: Boolean(this.writer)
                });
                break;
              }
              await this.writer.writeBase64(chunk);
            }
            if (!response.chunks.length)
              await delay2(EMPTY_POLL_DELAY_MS);
          }
          logCall("audio", "relay loop finished", {
            generation,
            desired: this.desired,
            superseded: generation !== this.generation,
            writer: Boolean(this.writer)
          });
          return;
        } catch (error) {
          if (!this.desired || generation !== this.generation) {
            logCall("audio", "relay stopped mid-poll", {
              generation,
              desired: this.desired,
              error: error instanceof Error ? error.message : String(error)
            });
            return;
          }
          failures += 1;
          const message = error instanceof Error ? error.message : String(error);
          warnCall("audio", "relay failed", { failures, message });
          this.report("reconnecting", message);
          const writer = this.writer;
          this.writer = null;
          await writer?.abort().catch((abortError2) => {
            warnCall("audio", "writer abort failed after a relay failure", {
              error: abortError2 instanceof Error ? abortError2.message : String(abortError2)
            });
          });
          const backoffMs = Math.min(5000, RETRY_BASE_MS * 2 ** Math.min(failures - 1, 3));
          logCall("audio", "retrying the relay", { generation, failures, backoffMs });
          await delay2(backoffMs);
        }
      }
      logCall("audio", "relay loop exited", {
        generation,
        desired: this.desired,
        superseded: generation !== this.generation
      });
    }
  }

  // src/background/managers/PreviewLeaseManager.ts
  var TERMINAL_PHASES = new Set(["leaving", "ended", "idle", "error"]);
  function errorCode(error) {
    const code = error?.code;
    if (typeof code === "string")
      return code;
    return error instanceof Error ? error.message : String(error);
  }

  class PreviewLeaseManager {
    host;
    handle = null;
    unsubscribeHandle = null;
    pendingAttempt = null;
    attempts = 0;
    lastPhase = "idle";
    ids = {};
    constructor(host) {
      this.host = host;
    }
    get held() {
      return this.handle;
    }
    handleCallState(state) {
      try {
        const previous = this.lastPhase;
        this.lastPhase = state.phase;
        if (state.phase === "in-call" && previous !== "in-call") {
          this.ids = { callId: state.callId, joinId: state.stream?.streamId, transport: state.transport };
          if (state.provider === "acs")
            this.arm();
          return;
        }
        if (TERMINAL_PHASES.has(state.phase) && !TERMINAL_PHASES.has(previous)) {
          this.release(`call_${state.phase}`);
        }
      } catch (error) {
        warnPreviewTrace("call_state_failed", { ...this.ids, error: errorCode(error) });
      }
    }
    dispose() {
      this.release("controller_disposed");
    }
    arm() {
      if (this.handle || this.pendingAttempt !== null)
        return;
      const preview = this.host?.preview;
      if (typeof preview !== "function") {
        logPreviewTrace("arm_skipped", { ...this.ids, reason: "sdk_without_preview" });
        return;
      }
      const attempt = ++this.attempts;
      const ids = { ...this.ids, attempt };
      this.pendingAttempt = attempt;
      logPreviewTrace("arm", { ...ids, source: "call" });
      let request;
      try {
        request = preview.call(this.host, { source: "call" });
      } catch (error) {
        request = Promise.reject(error);
      }
      request.then((handle) => this.adopt(attempt, handle, ids), (error) => {
        if (this.pendingAttempt === attempt)
          this.pendingAttempt = null;
        warnPreviewTrace("arm_result", { ...ids, result: "rejected", code: errorCode(error) });
      });
    }
    adopt(attempt, handle, ids) {
      const leaseIds = { ...ids, previewTraceId: handle.previewTraceId, handleId: handle.handleId };
      if (this.pendingAttempt !== attempt) {
        logPreviewTrace("arm_result", { ...leaseIds, result: "held_after_release" });
        this.stopHandle(handle, "call_ended_while_arming", leaseIds);
        return;
      }
      this.pendingAttempt = null;
      this.handle = handle;
      logPreviewTrace("arm_result", { ...leaseIds, result: "held" });
      this.unsubscribeHandle = handle.onStatus((status) => {
        if (status.state !== "ended")
          return;
        logPreviewTrace("lease_ended", { ...leaseIds, reason: status.reason });
        if (this.handle === handle) {
          this.handle = null;
          this.unsubscribeHandle?.();
          this.unsubscribeHandle = null;
        }
      });
    }
    release(reason) {
      this.pendingAttempt = null;
      const handle = this.handle;
      this.handle = null;
      this.unsubscribeHandle?.();
      this.unsubscribeHandle = null;
      if (!handle)
        return;
      this.stopHandle(handle, reason, { ...this.ids, previewTraceId: handle.previewTraceId, handleId: handle.handleId });
    }
    stopHandle(handle, reason, ids) {
      logPreviewTrace("stop", { ...ids, reason });
      let stopping;
      try {
        stopping = handle.stop();
      } catch (error) {
        stopping = Promise.reject(error);
      }
      stopping.then(() => logPreviewTrace("stop_result", { ...ids, result: "released" }), (error) => warnPreviewTrace("stop_result", { ...ids, result: "failed", code: errorCode(error) }));
    }
  }

  // src/shared/types.ts
  var CHAT_TTS_UNLOCKED = false;
  var WATCH_PAINT_ARMS = ["track", "rvfc", "video", "synthetic"];
  function parseWatchPaint(value) {
    return typeof value === "string" && WATCH_PAINT_ARMS.includes(value) ? value : "track";
  }

  // src/background/managers/SettingsManager.ts
  var STORAGE_KEY3 = "settings-v5";
  var LEGACY_STORAGE_KEYS = ["settings-v4", "settings-v3"];
  function parseStored(raw, key) {
    if (!raw) {
      logCall("settings", `${key} is absent`);
      return null;
    }
    try {
      const value = JSON.parse(raw);
      if (value && typeof value === "object" && !Array.isArray(value)) {
        logCall("settings", `${key} read`, { keys: Object.keys(value) });
        return value;
      }
      warnCall("settings", `${key} is not a settings object; ignoring it`, {
        type: Array.isArray(value) ? "array" : typeof value
      });
    } catch (error) {
      warnCall("settings", `${key} is unreadable; ignoring it`, {
        error: error instanceof Error ? error.message : String(error)
      });
    }
    return null;
  }
  var LOGGED_FIELDS = [
    "displayName",
    "chatTts",
    "watchPaint",
    "videoPreset",
    "videoBitrateBps",
    "lastSuccessfulAcsPreset",
    "directLink",
    "meetingHost",
    "shareHdPhoto"
  ];
  function logSettingsDiff(cause, previous, next) {
    const changed = LOGGED_FIELDS.filter((field) => !previous || previous[field] !== next[field]);
    if (!changed.length) {
      logCall("settings", `${cause}: nothing changed`);
      return;
    }
    for (const field of changed) {
      const from = previous ? JSON.stringify(previous[field]) : "unset";
      logCall("settings", `${field} ${from} → ${JSON.stringify(next[field])}`, { cause });
    }
  }

  class SettingsManager {
    session;
    settings;
    constructor(session) {
      this.session = session;
      this.settings = this.validate({
        displayName: this.defaultDisplayName(),
        chatTts: false,
        watchPaint: "track",
        videoPreset: DEFAULT_VIDEO_PRESET,
        videoBitrateBps: DEFAULT_VIDEO_BITRATE_BPS,
        lastSuccessfulAcsPreset: DEFAULT_VIDEO_PRESET,
        accountEmail: session.userId || "Mentra user",
        directLink: true,
        teamsProvider: TEAMS_PROVIDER,
        meetingHost: hasMeetingApi(session),
        shareHdPhoto: true
      });
      logCall("settings", "defaults before load", this.loggable(this.settings));
    }
    async load() {
      const defaults = this.settings;
      try {
        const current = await tracedRpc("storage.get", () => this.session.storage.get(STORAGE_KEY3), {
          request: { storageKey: STORAGE_KEY3 },
          response: (value2) => ({ bytes: value2?.length ?? 0 })
        });
        const value = parseStored(current, STORAGE_KEY3);
        if (value) {
          this.settings = this.validate({
            ...this.settings,
            ...value,
            accountEmail: this.session.userId || this.settings.accountEmail
          });
          logSettingsDiff(`loaded ${STORAGE_KEY3}`, defaults, this.settings);
          return;
        }
        for (const key of LEGACY_STORAGE_KEYS) {
          const stored = await tracedRpc("storage.get", () => this.session.storage.get(key), {
            request: { storageKey: key },
            response: (payload) => ({ bytes: payload?.length ?? 0 })
          });
          const value2 = parseStored(stored, key);
          if (!value2)
            continue;
          this.settings = this.validate({
            ...this.settings,
            ...value2,
            chatTts: false,
            accountEmail: this.session.userId || this.settings.accountEmail
          });
          logSettingsDiff(`migrated ${key}`, defaults, this.settings);
          await tracedRpc("storage.set", () => this.session.storage.set(STORAGE_KEY3, JSON.stringify(this.settings)), {
            request: { storageKey: STORAGE_KEY3, reason: `migrated from ${key}` }
          });
          return;
        }
        logCall("settings", "no stored settings anywhere; a first run", { keys: [STORAGE_KEY3, ...LEGACY_STORAGE_KEYS] });
        this.settings = this.validate({ ...this.settings, displayName: "", chatTts: false });
        logSettingsDiff("first run", defaults, this.settings);
      } catch (error) {
        warnCall("settings", "load failed; keeping the defaults", {
          error: error instanceof Error ? error.message : String(error),
          ...this.loggable(this.settings)
        });
      }
    }
    get() {
      return {
        ...this.settings,
        teamsProvider: TEAMS_PROVIDER,
        meetingHost: hasMeetingApi(this.session)
      };
    }
    async update(patch) {
      const { lastSuccessfulAcsPreset: refused, ...safe } = patch;
      if (refused !== undefined) {
        warnCall("settings", "update dropped lastSuccessfulAcsPreset: only a successful ACS join may write it", {
          requested: refused,
          current: this.settings.lastSuccessfulAcsPreset
        });
      }
      const previous = this.settings;
      this.settings = this.validate({ ...this.settings, ...safe });
      logSettingsDiff(`update(${Object.keys(safe).join(", ") || "empty patch"})`, previous, this.settings);
      await this.persist("update");
      return this.get();
    }
    async markAcsPresetSucceeded() {
      const previous = this.settings;
      this.settings = this.validate({
        ...this.settings,
        lastSuccessfulAcsPreset: this.settings.videoPreset
      });
      logSettingsDiff("acs preset succeeded", previous, this.settings);
      await this.persist("acs-preset-succeeded");
      return this.get();
    }
    async rollbackConfiguredVideoPreset() {
      const previous = this.settings;
      this.settings = this.validate({
        ...this.settings,
        videoPreset: this.settings.lastSuccessfulAcsPreset
      });
      logSettingsDiff("acs preset rollback", previous, this.settings);
      await this.persist("acs-preset-rollback");
      return this.get();
    }
    defaultDisplayName() {
      const model = this.session.capabilities?.modelName;
      return typeof model === "string" && model.trim() || "Mentra user";
    }
    async persist(cause) {
      const payload = JSON.stringify(this.settings);
      await tracedRpc("storage.set", () => this.session.storage.set(STORAGE_KEY3, payload), {
        request: { storageKey: STORAGE_KEY3, bytes: payload.length, cause }
      });
    }
    loggable(settings) {
      return {
        displayName: Boolean(settings.displayName),
        chatTts: settings.chatTts,
        watchPaint: settings.watchPaint,
        videoPreset: settings.videoPreset,
        videoBitrateBps: settings.videoBitrateBps,
        lastSuccessfulAcsPreset: settings.lastSuccessfulAcsPreset,
        directLink: settings.directLink,
        teamsProvider: settings.teamsProvider,
        meetingHost: settings.meetingHost,
        shareHdPhoto: settings.shareHdPhoto
      };
    }
    validate(value) {
      const next = {
        displayName: String(value.displayName || this.defaultDisplayName()).trim().slice(0, 80),
        chatTts: CHAT_TTS_UNLOCKED && Boolean(value.chatTts),
        watchPaint: parseWatchPaint(value.watchPaint),
        videoPreset: parseVideoPreset(value.videoPreset),
        videoBitrateBps: parseVideoBitrate(value.videoBitrateBps),
        lastSuccessfulAcsPreset: parseVideoPreset(value.lastSuccessfulAcsPreset),
        accountEmail: this.session.userId || String(value.accountEmail || "Mentra user"),
        directLink: TEAMS_PROVIDER === "acs" && value.directLink !== false,
        teamsProvider: TEAMS_PROVIDER,
        meetingHost: hasMeetingApi(this.session),
        shareHdPhoto: value.shareHdPhoto !== false
      };
      if (value.chatTts && !next.chatTts) {
        logChange("settings", "settings.chatTtsLocked", CHAT_TTS_UNLOCKED, { requested: true });
      }
      if (value.directLink !== false && !next.directLink) {
        logChange("settings", "settings.directLinkForcedOff", TEAMS_PROVIDER, { requested: value.directLink });
      }
      if (value.videoPreset !== undefined && value.videoPreset !== next.videoPreset) {
        logCall("settings", "video preset coerced", { requested: value.videoPreset, applied: next.videoPreset });
      }
      if (value.lastSuccessfulAcsPreset !== undefined && value.lastSuccessfulAcsPreset !== next.lastSuccessfulAcsPreset) {
        logCall("settings", "last-successful preset coerced", {
          requested: value.lastSuccessfulAcsPreset,
          applied: next.lastSuccessfulAcsPreset
        });
      }
      if (value.videoBitrateBps !== undefined && value.videoBitrateBps !== next.videoBitrateBps) {
        logCall("settings", "video bitrate coerced to Auto", { requested: value.videoBitrateBps });
      }
      if (value.watchPaint !== undefined && value.watchPaint !== next.watchPaint) {
        logCall("settings", "watch paint coerced", { requested: value.watchPaint, applied: next.watchPaint });
      }
      return next;
    }
  }

  // src/background/managers/StreamManager.ts
  var WIFI_STABILIZE_MS = 1500;
  var WIFI_WAIT_MS = 50000;
  var GLASSES_WAIT_MS = LINK_GRACE_MS;
  var RECOVERY_WINDOW_MS = 15000;
  var UPLINK_GRACE_MS = 12000;
  var FOV_ATTEMPTS = 4;
  var FOV_RETRY_DELAY_MS = 1500;
  var FOV_REAPPLY_DELAY_MS = 750;
  var delay3 = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  function isTransientStartFailure(error, message) {
    if (isGlassesLinkError(error, message))
      return false;
    if (requestErrorCode(error) === "STREAM_PROVISION_FAILED")
      return true;
    return /HTTP 5\d\d|ECONNRESET|socket hang up|timed? ?out|ICE did not connect|WHIP media path failed|Unknown camera ID|supportsCameraApi/i.test(message);
  }
  var GLASSES_COPY = {
    waiting: "Waiting for your glasses to reconnect",
    startTimeout: "Your glasses did not reconnect. Bring them closer to your phone and try again.",
    streamLost: "Your glasses disconnected from your phone and did not reconnect in time.",
    publisherGone: "Your glasses turned off or lost power during the call."
  };

  class StreamManager {
    session;
    onStatus;
    link;
    result = null;
    startedAt = 0;
    starting = null;
    opQueue = Promise.resolve();
    generation = 0;
    explicitlyStopped = true;
    photoHold = false;
    recovering = false;
    disposed = false;
    wifiConnected = null;
    recoveryTimer = null;
    wifiGiveUpTimer = null;
    statusUnsub = null;
    wifiUnsub = null;
    linkUnsub = null;
    fovGeneration = 0;
    fovReapplyTimer = null;
    fovLinkConnected = null;
    wifiWaiters = new Set;
    lastIngestLogKey = "";
    heartbeatTimer = null;
    lastEncoderStats = null;
    captureAudio = true;
    profile = resolveConfiguredVideo(DEFAULT_VIDEO_PRESET, DEFAULT_VIDEO_BITRATE_BPS);
    suspended = false;
    uplinkParked = false;
    uplinkGraceTimer = null;
    glassesWaitMs;
    fovReapplyMs;
    fovRetryMs;
    uplinkGraceMs;
    startRetryMs;
    constructor(session, onStatus, link = new GlassesLinkMonitor(session), options = {}) {
      this.session = session;
      this.onStatus = onStatus;
      this.link = link;
      this.glassesWaitMs = options.glassesWaitMs ?? GLASSES_WAIT_MS;
      this.fovReapplyMs = options.fovReapplyMs ?? FOV_REAPPLY_DELAY_MS;
      this.fovRetryMs = options.fovRetryMs ?? FOV_RETRY_DELAY_MS;
      this.uplinkGraceMs = options.uplinkGraceMs ?? UPLINK_GRACE_MS;
      this.startRetryMs = options.startRetryMs ?? STREAM_RETRY_DELAY_MS;
    }
    get linkConnected() {
      return this.link.connected;
    }
    get wifiReady() {
      return this.wifiConnected;
    }
    get hasCamera() {
      if (!this.session.capabilities)
        return null;
      return Boolean(this.session.capabilities.hasCamera);
    }
    onLink(listener) {
      return this.link.onChange(listener);
    }
    waitForLink(timeoutMs, cancelled) {
      return this.link.waitForConnected(timeoutMs, cancelled);
    }
    setCaptureAudio(captureAudio) {
      logChange("stream", "stream.captureAudio", captureAudio);
      this.captureAudio = captureAudio;
    }
    setProfile(profile) {
      const previous = this.profile;
      this.profile = profile;
      logChange("stream", "stream.profile", profile.id, {
        size: `${profile.width}x${profile.height}@${profile.fps}`,
        bitrateBps: profile.bitrateBps,
        fov: profile.fov,
        roi: profile.roiPosition,
        live: this.streamActiveOrStarting
      });
      if (previous.fov === profile.fov && previous.roiPosition === profile.roiPosition)
        return;
      const token = this.nextFovToken();
      if (!this.streamActiveOrStarting) {
        logCall("stream", "profile fov changed with no stream to re-apply it to", {
          to: `${profile.fov}/${profile.roiPosition}`,
          fovGeneration: token.generation
        });
        return;
      }
      logCall("stream", "profile fov changed; re-applying", {
        from: `${previous.fov}/${previous.roiPosition}`,
        to: `${profile.fov}/${profile.roiPosition}`,
        fovGeneration: token.generation
      });
      this.applyCameraFov(token);
    }
    currentProfile() {
      return this.profile;
    }
    start() {
      if (this.statusUnsub || this.wifiUnsub) {
        logCall("stream", "start ignored: already listening", this.snapshot());
        return;
      }
      logCall("stream", "listening for ingest + Wi-Fi status");
      this.link.start();
      this.statusUnsub = this.session.events.subscribe("stream_status", (data) => {
        this.handleRawStatus(data);
      });
      this.wifiUnsub = this.session.glasses.onWifi((data) => this.handleWifiChange(data));
      this.linkUnsub = this.link.onChange((snapshot) => this.handleLinkForFov(snapshot));
    }
    get info() {
      if (!this.result?.webrtcUrl)
        return null;
      return {
        streamId: this.result.streamId,
        webrtcUrl: this.result.webrtcUrl,
        startedAt: this.startedAt
      };
    }
    ensureStarted() {
      if (this.result) {
        logCall("stream", "already live", this.snapshot());
        return Promise.resolve(this.result);
      }
      if (this.starting) {
        logCall("stream", "start already in flight", { generation: this.generation });
        return this.starting;
      }
      this.explicitlyStopped = false;
      this.recovering = false;
      this.uplinkParked = false;
      this.cancelRecoveryTimer();
      const generation = ++this.generation;
      logCall("stream", "starting glasses ingest", { generation, wifi: this.wifiConnected });
      this.starting = this.withLock(() => this.startWithRetries(generation)).finally(() => {
        this.starting = null;
      });
      return this.starting;
    }
    async requestWifiSetup() {
      const id = nextRpcId();
      const startedAt = Date.now();
      logRpcStart("glasses.requestWifiSetup", id);
      try {
        await this.session.glasses.requestWifiSetup("Mentra Call needs glasses Wi-Fi to stream your camera");
        logRpcEnd("glasses.requestWifiSetup", id, "ok", Date.now() - startedAt);
      } catch (error) {
        logRpcEnd("glasses.requestWifiSetup", id, "error", Date.now() - startedAt, {
          error: error instanceof Error ? error.message : String(error)
        });
        throw error;
      }
    }
    async pauseForPhoto() {
      this.photoHold = true;
      this.cancelRecoveryTimer();
      const current = this.result;
      this.result = null;
      if (!current?.streamId)
        return;
      await this.session.stream.stop(current.streamId);
    }
    async resumeForPhoto() {
      if (!this.photoHold)
        return;
      this.photoHold = false;
      if (this.explicitlyStopped || this.disposed)
        return;
      await this.ensureStarted();
    }
    async stop() {
      this.photoHold = false;
      this.explicitlyStopped = true;
      ++this.generation;
      ++this.fovGeneration;
      this.cancelFovReapply();
      this.cancelRecoveryTimer();
      this.stopHeartbeat();
      this.recovering = false;
      this.suspended = false;
      this.uplinkParked = false;
      for (const wake of this.wifiWaiters)
        wake();
      this.wifiWaiters.clear();
      this.link.interrupt();
      logCall("stream", "stop requested", { generation: this.generation, ...summarizeStream(this.result) });
      await this.withLock(async () => {
        const current = this.result;
        this.result = null;
        const id = nextRpcId();
        const startedAt = Date.now();
        logRpcStart("stream.stop", id, { streamId: current?.streamId });
        try {
          await this.session.stream.stop(current?.streamId);
          logRpcEnd("stream.stop", id, "ok", Date.now() - startedAt);
        } catch (error) {
          logRpcEnd("stream.stop", id, "error", Date.now() - startedAt);
          warnCall("stream", "stop failed", { error: error instanceof Error ? error.message : String(error) });
        }
        this.emitStatus({ phase: "offline", active: false, stream: null });
      });
    }
    async dispose() {
      logCall("stream", "dispose", this.snapshot());
      this.disposed = true;
      this.statusUnsub?.();
      this.wifiUnsub?.();
      this.linkUnsub?.();
      this.statusUnsub = null;
      this.wifiUnsub = null;
      this.linkUnsub = null;
      await this.stop();
    }
    async startWithRetries(generation, emitTerminalFailure = true) {
      if (this.hasCamera === false) {
        warnCall("stream", "start refused: these glasses have no camera", { generation });
        throw this.fail(NO_CAMERA_COPY);
      }
      if (this.link.connected !== true) {
        logCall("stream", "waiting for glasses Bluetooth link", { generation, timeoutMs: this.glassesWaitMs });
        this.emitStatus({ phase: "connecting", active: false, stream: null, reason: "glasses" });
        const linked = await this.link.waitForConnected(this.glassesWaitMs, () => generation !== this.generation || this.explicitlyStopped);
        if (generation !== this.generation || this.explicitlyStopped) {
          logCall("stream", "start abandoned while waiting for Bluetooth", {
            generation,
            active: this.generation,
            explicitlyStopped: this.explicitlyStopped
          });
          throw new Error("Stream start cancelled");
        }
        if (!linked) {
          warnCall("stream", "start gave up: the Bluetooth link never came back", {
            generation,
            timeoutMs: this.glassesWaitMs,
            emitTerminalFailure
          });
          const error = new Error(GLASSES_COPY.startTimeout);
          if (emitTerminalFailure)
            this.fail(GLASSES_COPY.startTimeout, "glasses");
          throw error;
        }
      }
      if (this.wifiConnected === false) {
        logCall("stream", "waiting for glasses Wi-Fi", { generation });
        this.emitStatus({ phase: "connecting", active: false, stream: null, reason: "wifi" });
        await this.requestWifiSetup();
        await this.waitForWifi(generation);
      }
      this.emitStatus({ phase: "connecting", active: false, stream: null });
      let lastError;
      for (let attempt = 1;attempt <= STREAM_START_ATTEMPTS; attempt++) {
        if (generation !== this.generation || this.explicitlyStopped) {
          logCall("stream", "start abandoned before attempt", {
            generation,
            active: this.generation,
            attempt,
            explicitlyStopped: this.explicitlyStopped
          });
          throw new Error("Stream start cancelled");
        }
        const loss = this.watchLinkLoss(generation);
        try {
          return await Promise.race([this.startWhip(generation), loss.promise]);
        } catch (error) {
          lastError = error;
          if (generation !== this.generation || this.explicitlyStopped) {
            logCall("stream", "start attempt abandoned: something newer owns the stream", {
              generation,
              active: this.generation,
              attempt,
              explicitlyStopped: this.explicitlyStopped,
              error: error instanceof Error ? error.message : String(error)
            });
            throw error;
          }
          const message = requestErrorMessage(error, "The glasses stream failed to start");
          const transient = isTransientStartFailure(error, message);
          const willRetry = transient && attempt < STREAM_START_ATTEMPTS;
          warnCall("stream", "whip start failed", {
            error: message,
            code: requestErrorCode(error),
            attempt,
            attempts: STREAM_START_ATTEMPTS,
            willRetry
          });
          await this.session.stream.stop().catch(() => {});
          if (!willRetry) {
            const reason = isGlassesLinkError(error, message) ? "glasses" : undefined;
            if (emitTerminalFailure)
              throw this.fail(message, reason);
            throw new Error(message);
          }
          await delay3(this.startRetryMs);
        } finally {
          loss.cancel();
        }
      }
      throw lastError instanceof Error ? lastError : new Error("The glasses stream failed to start");
    }
    async waitForWifi(generation) {
      if (this.wifiConnected === true) {
        logCall("stream", "Wi-Fi wait skipped: already on Wi-Fi", { generation });
        return;
      }
      logCall("stream", "Wi-Fi wait started", { generation, timeoutMs: WIFI_WAIT_MS });
      const startedAt = Date.now();
      await new Promise((resolve, reject) => {
        const finish = () => {
          clearTimeout(timer);
          this.wifiWaiters.delete(finish);
          const waitedMs = Date.now() - startedAt;
          if (generation !== this.generation || this.explicitlyStopped) {
            logCall("stream", "Wi-Fi wait abandoned: something newer owns the stream", {
              generation,
              active: this.generation,
              explicitlyStopped: this.explicitlyStopped,
              waitedMs
            });
            reject(new Error("Stream start cancelled"));
          } else if (this.wifiConnected === true) {
            logCall("stream", "Wi-Fi wait satisfied", { generation, waitedMs });
            resolve();
          } else {
            warnCall("stream", "Wi-Fi wait gave up", { generation, waitedMs, timeoutMs: WIFI_WAIT_MS });
            reject(new Error("Connect your glasses to Wi-Fi, then try again"));
          }
        };
        const timer = setTimeout(finish, WIFI_WAIT_MS);
        this.wifiWaiters.add(finish);
      });
    }
    handleWifiChange(data) {
      const hinted = data.linkConnected;
      if (typeof hinted === "boolean")
        this.link.observeLink(hinted);
      const linkDown = hinted === false || this.link.connected === false;
      if (!data.connected && linkDown) {
        logCall("stream", "ignoring Wi-Fi=false while Bluetooth link is down", {
          suspended: this.suspended,
          ...summarizeStream(this.result)
        });
        return;
      }
      const wasConnected = this.wifiConnected;
      this.wifiConnected = data.connected;
      if (wasConnected !== data.connected) {
        logCall("stream", "glasses Wi-Fi", {
          connected: data.connected,
          ssid: data.ssid,
          ip: data.localIp,
          recovering: this.recovering,
          ...summarizeStream(this.result)
        });
      }
      if (data.connected) {
        if (this.wifiGiveUpTimer)
          clearTimeout(this.wifiGiveUpTimer);
        this.wifiGiveUpTimer = null;
        for (const wake of this.wifiWaiters)
          wake();
        this.wifiWaiters.clear();
        if (wasConnected === false && this.uplinkParked) {
          this.parkUplink("Glasses Wi-Fi back; waiting for the glasses to re-publish");
        }
        if (wasConnected === false && this.recovering && !this.recoveryTimer) {
          logCall("stream", "Wi-Fi back; recovering after stabilize", { delayMs: WIFI_STABILIZE_MS });
          this.recoveryTimer = setTimeout(() => {
            this.recoveryTimer = null;
            this.recover();
          }, WIFI_STABILIZE_MS);
        }
      } else if (this.result && !this.explicitlyStopped) {
        this.parkUplink("Glasses Wi-Fi disconnected");
      } else {
        logChange("stream", "stream.wifiDownIdle", Boolean(this.result), {
          explicitlyStopped: this.explicitlyStopped
        });
      }
    }
    parkUplink(reason) {
      if (!this.result || this.explicitlyStopped || this.disposed) {
        logCall("stream", "uplink park declined: no stream of ours to park", {
          reason,
          hasStream: Boolean(this.result),
          explicitlyStopped: this.explicitlyStopped,
          disposed: this.disposed
        });
        return;
      }
      if (this.recovering || this.suspended) {
        logCall("stream", "uplink park declined: another owner already has the stream", {
          reason,
          recovering: this.recovering,
          suspended: this.suspended
        });
        return;
      }
      const wasParked = this.uplinkParked;
      this.uplinkParked = true;
      this.cancelUplinkGrace();
      this.uplinkGraceTimer = setTimeout(() => {
        this.uplinkGraceTimer = null;
        if (!this.uplinkParked || !this.result || this.explicitlyStopped || this.disposed) {
          logCall("stream", "uplink grace expired with nothing left to restart", {
            reason,
            parked: this.uplinkParked,
            hasStream: Boolean(this.result),
            explicitlyStopped: this.explicitlyStopped,
            disposed: this.disposed
          });
          return;
        }
        this.uplinkParked = false;
        warnCall("stream", "glasses uplink did not come back; restarting the stream", {
          reason,
          graceMs: this.uplinkGraceMs,
          ...summarizeStream(this.result)
        });
        this.beginRecovery(reason, "wifi");
      }, this.uplinkGraceMs);
      if (wasParked) {
        logCall("stream", "glasses uplink still down; extending grace", { reason, graceMs: this.uplinkGraceMs });
        return;
      }
      warnCall("stream", "glasses uplink parked; letting the glasses self-heal", {
        reason,
        graceMs: this.uplinkGraceMs,
        ...summarizeStream(this.result)
      });
      this.emitStatus({ phase: "reconnecting", active: false, stream: this.info, reason: "wifi" });
    }
    resumeUplink(reason) {
      if (!this.uplinkParked) {
        logCall("stream", "uplink resume ignored: nothing was parked", { reason });
        return;
      }
      this.uplinkParked = false;
      this.cancelUplinkGrace();
      if (!this.result || this.explicitlyStopped || this.disposed) {
        logCall("stream", "uplink resumed onto no stream", {
          reason,
          hasStream: Boolean(this.result),
          explicitlyStopped: this.explicitlyStopped,
          disposed: this.disposed
        });
        return;
      }
      logCall("stream", "glasses uplink recovered without a restart", {
        reason,
        ...summarizeStream(this.result)
      });
      this.emitStatus({ phase: "active", active: true, stream: this.info });
    }
    cancelUplinkGrace() {
      if (this.uplinkGraceTimer)
        clearTimeout(this.uplinkGraceTimer);
      this.uplinkGraceTimer = null;
    }
    async handleRawStatus(raw) {
      if (raw.stats)
        this.lastEncoderStats = raw.stats;
      this.logIngestStatus(raw);
      if (raw.source === "cloudflare") {
        logChange("stream", "stream.cloudflareEcho", raw.status ?? "", { kind: raw.kind });
        return;
      }
      const status = (raw.status || "").toLowerCase();
      if (!status) {
        logChange("stream", "stream.statuslessEvent", raw.source ?? "unknown", { kind: raw.kind });
        return;
      }
      if (raw.source === "coordinator" && this.handleLinkStatus(status, raw))
        return;
      if (this.handleUplinkStatus(status, raw))
        return;
      if (this.photoHold)
        return;
      if ((status === "error" || status === "failed") && !this.explicitlyStopped) {
        if (this.starting) {
          logCall("stream", "ingest error during start; leaving in-flight start in place", {
            error: raw.errorDetails,
            generation: this.generation
          });
          return;
        }
        await this.beginRecovery(raw.errorDetails || "The glasses stream disconnected");
        return;
      }
      if (/stop|end|offline/.test(status) && this.result && !this.explicitlyStopped && !this.recovering) {
        await this.beginRecovery(raw.errorDetails || "The glasses stream stopped", "ingest");
        return;
      }
      logChange("stream", "stream.eventNotActedOn", `${raw.source ?? "unknown"}/${status}`, {
        kind: raw.kind,
        hasStream: Boolean(this.result),
        explicitlyStopped: this.explicitlyStopped,
        recovering: this.recovering,
        starting: Boolean(this.starting)
      });
    }
    handleUplinkStatus(status, raw) {
      if (!this.result || this.explicitlyStopped || this.recovering || this.suspended) {
        logChange("stream", "stream.uplinkWindowClosed", status, {
          hasStream: Boolean(this.result),
          explicitlyStopped: this.explicitlyStopped,
          recovering: this.recovering,
          suspended: this.suspended
        });
        return false;
      }
      if (status === "reconnecting" || raw.kind === "reconnect") {
        this.parkUplink(raw.errorDetails || "The glasses are reconnecting their stream");
        return true;
      }
      if (!this.uplinkParked) {
        logChange("stream", "stream.uplinkHealthy", status, { kind: raw.kind });
        return false;
      }
      if (status === "reconnected" || status === "streaming" || status === "connected") {
        this.resumeUplink(`ingest ${status}`);
        return true;
      }
      if (status === "error" || status === "failed") {
        warnCall("stream", "glasses gave up on their own uplink; ending the grace window early", {
          status,
          error: raw.errorDetails,
          ...summarizeStream(this.result)
        });
        this.uplinkParked = false;
        this.cancelUplinkGrace();
        return false;
      }
      logCall("stream", "ingest event held while the glasses self-heal", {
        status,
        kind: raw.kind,
        error: raw.errorDetails
      });
      return true;
    }
    handleLinkStatus(status, raw) {
      if (status === "suspended") {
        if (!this.result || this.explicitlyStopped) {
          logCall("stream", "engine suspend ignored: no stream of ours", {
            hasStream: Boolean(this.result),
            explicitlyStopped: this.explicitlyStopped
          });
          return true;
        }
        this.uplinkParked = false;
        this.cancelUplinkGrace();
        this.suspended = true;
        warnCall("stream", "engine suspended stream: Bluetooth link down", {
          graceMs: raw.graceMs,
          ...summarizeStream(this.result)
        });
        this.emitStatus({ phase: "reconnecting", active: false, stream: this.info, reason: "glasses" });
        return true;
      }
      if (status === "resumed") {
        if (!this.result || this.explicitlyStopped) {
          logCall("stream", "engine resume ignored: no stream of ours", {
            hasStream: Boolean(this.result),
            explicitlyStopped: this.explicitlyStopped,
            suspendedMs: raw.suspendedMs
          });
          return true;
        }
        this.suspended = false;
        this.uplinkParked = false;
        this.cancelUplinkGrace();
        logCall("stream", "engine resumed stream: Bluetooth link back", {
          suspendedMs: raw.suspendedMs,
          ...summarizeStream(this.result)
        });
        this.emitStatus({ phase: "active", active: true, stream: this.info });
        return true;
      }
      if (status === "error" && raw.reason === "glasses_disconnected") {
        if (this.explicitlyStopped) {
          logCall("stream", "engine teardown ignored: this stream was already stopped", {
            teardownReason: raw.teardownReason
          });
          return true;
        }
        const reason = raw.publisherGone ? "publisher-gone" : "glasses";
        warnCall("stream", "engine gave up on suspended stream", {
          teardownReason: raw.teardownReason,
          publisherGone: raw.publisherGone,
          ...summarizeStream(this.result)
        });
        ++this.generation;
        this.stopHeartbeat();
        this.result = null;
        this.suspended = false;
        this.uplinkParked = false;
        this.recovering = false;
        this.cancelRecoveryTimer();
        this.emitStatus({
          phase: "error",
          active: false,
          stream: null,
          error: raw.publisherGone ? GLASSES_COPY.publisherGone : GLASSES_COPY.streamLost,
          reason
        });
        return true;
      }
      return false;
    }
    async beginRecovery(reason, kind = "ingest") {
      if (this.recovering || this.explicitlyStopped || this.disposed) {
        logCall("stream", "recovery declined", {
          reason,
          kind,
          recovering: this.recovering,
          explicitlyStopped: this.explicitlyStopped,
          disposed: this.disposed
        });
        return;
      }
      if (this.suspended) {
        logCall("stream", "recovery declined: the engine has this stream parked", { reason, kind });
        return;
      }
      this.uplinkParked = false;
      this.cancelUplinkGrace();
      this.recovering = true;
      ++this.generation;
      this.stopHeartbeat();
      const current = this.result;
      this.result = null;
      warnCall("stream", "recovery pending", { reason, kind, generation: this.generation, wifi: this.wifiConnected });
      this.emitStatus({ phase: "reconnecting", active: false, stream: null, reason: kind });
      try {
        await this.session.stream.stop(current?.streamId);
      } catch (error) {
        logCall("stream", "pre-recovery stop rejected; the stream was probably already gone", {
          streamId: current?.streamId,
          error: error instanceof Error ? error.message : String(error)
        });
      }
      if (this.wifiConnected !== false) {
        await this.recover();
      } else {
        logCall("stream", "recovery deferred: the glasses are off Wi-Fi", { reason, kind });
        this.holdRecoveryForWifi();
      }
    }
    holdRecoveryForWifi() {
      if (this.wifiGiveUpTimer || this.explicitlyStopped || this.disposed) {
        logCall("stream", "Wi-Fi hold not armed", {
          alreadyArmed: Boolean(this.wifiGiveUpTimer),
          explicitlyStopped: this.explicitlyStopped,
          disposed: this.disposed
        });
        return;
      }
      logCall("stream", "holding recovery until Wi-Fi returns", { timeoutMs: WIFI_WAIT_MS });
      this.wifiGiveUpTimer = setTimeout(() => {
        this.wifiGiveUpTimer = null;
        if (!this.recovering || this.wifiConnected !== false || this.explicitlyStopped) {
          logCall("stream", "Wi-Fi hold expired with nothing to fail", {
            recovering: this.recovering,
            wifi: this.wifiConnected,
            explicitlyStopped: this.explicitlyStopped
          });
          return;
        }
        warnCall("stream", "Wi-Fi hold gave up", { timeoutMs: WIFI_WAIT_MS });
        this.recovering = false;
        this.emitStatus({
          phase: "error",
          active: false,
          stream: null,
          error: "Glasses Wi-Fi did not reconnect within 50 seconds",
          reason: "wifi"
        });
      }, WIFI_WAIT_MS);
    }
    async recover() {
      if (!this.recovering || this.explicitlyStopped || this.disposed) {
        logCall("stream", "recovery attempt declined", {
          recovering: this.recovering,
          explicitlyStopped: this.explicitlyStopped,
          disposed: this.disposed
        });
        return;
      }
      if (this.link.connected === false) {
        logCall("stream", "holding recovery until Bluetooth link returns", { timeoutMs: this.glassesWaitMs });
        this.emitStatus({ phase: "reconnecting", active: false, stream: null, reason: "glasses" });
        const generationAtHold = this.generation;
        const linked = await this.link.waitForConnected(this.glassesWaitMs, () => generationAtHold !== this.generation || this.explicitlyStopped);
        if (!this.recovering || generationAtHold !== this.generation || this.explicitlyStopped || this.disposed) {
          logCall("stream", "recovery abandoned while holding for Bluetooth", {
            recovering: this.recovering,
            generationAtHold,
            generation: this.generation,
            explicitlyStopped: this.explicitlyStopped,
            disposed: this.disposed
          });
          return;
        }
        if (!linked) {
          warnCall("stream", "recovery gave up: the Bluetooth link never came back", { timeoutMs: this.glassesWaitMs });
          this.recovering = false;
          this.emitStatus({
            phase: "error",
            active: false,
            stream: null,
            error: GLASSES_COPY.streamLost,
            reason: "glasses"
          });
          return;
        }
      }
      if (this.isWifiDisconnected()) {
        logCall("stream", "recovery attempt deferred: the glasses left Wi-Fi while we waited");
        this.holdRecoveryForWifi();
        return;
      }
      const generation = ++this.generation;
      const deadline = Date.now() + RECOVERY_WINDOW_MS;
      logCall("stream", "recovery attempt", { generation, windowMs: RECOVERY_WINDOW_MS });
      let lastError;
      let attempt = 0;
      try {
        while (Date.now() < deadline && !this.explicitlyStopped && !this.isWifiDisconnected()) {
          attempt += 1;
          try {
            await this.withLock(() => this.startWithRetries(generation, false));
            this.recovering = false;
            logCall("stream", "recovery succeeded", { attempt, ...this.snapshot() });
            return;
          } catch (error) {
            lastError = error;
            if (generation !== this.generation || this.explicitlyStopped) {
              logCall("stream", "recovery cycle abandoned: something newer owns the stream", {
                generation,
                active: this.generation,
                attempt,
                explicitlyStopped: this.explicitlyStopped
              });
              this.recovering = false;
              return;
            }
            const retryInMs = Math.min(STREAM_RETRY_DELAY_MS, Math.max(0, deadline - Date.now()));
            warnCall("stream", "recovery cycle failed", {
              attempt,
              retryInMs,
              windowLeftMs: Math.max(0, deadline - Date.now()),
              error: error instanceof Error ? error.message : String(error)
            });
            await delay3(retryInMs);
          }
        }
        if (this.explicitlyStopped || this.disposed) {
          logCall("stream", "recovery stood down: the call is over", {
            attempt,
            explicitlyStopped: this.explicitlyStopped,
            disposed: this.disposed
          });
          this.recovering = false;
          return;
        }
        if (this.isWifiDisconnected()) {
          logCall("stream", "recovery window ended off Wi-Fi; holding instead of failing", { attempt });
          this.holdRecoveryForWifi();
          return;
        }
        const message = lastError instanceof Error ? lastError.message : "Unable to reconnect the glasses stream";
        warnCall("stream", "recovery window exhausted", { attempt, windowMs: RECOVERY_WINDOW_MS, error: message });
        this.recovering = false;
        this.emitStatus({ phase: "error", active: false, stream: null, error: message, reason: "ingest" });
      } catch (error) {
        warnCall("stream", "recovery threw outside its own retry loop", {
          attempt,
          error: error instanceof Error ? error.message : String(error)
        });
        this.recovering = false;
        this.emitStatus({ phase: "error", active: false, stream: null, error: String(error), reason: "ingest" });
      }
    }
    withLock(operation) {
      const result = this.opQueue.then(operation, operation);
      this.opQueue = result.then(() => {
        return;
      }, () => {
        return;
      });
      return result;
    }
    cancelRecoveryTimer() {
      if (this.recoveryTimer)
        clearTimeout(this.recoveryTimer);
      if (this.wifiGiveUpTimer)
        clearTimeout(this.wifiGiveUpTimer);
      this.recoveryTimer = null;
      this.wifiGiveUpTimer = null;
      this.cancelUplinkGrace();
    }
    isWifiDisconnected() {
      return this.wifiConnected === false;
    }
    emitStatus(event) {
      logChange("stream", "stream.latches", `${this.recovering ? "recovering" : ""}${this.suspended ? " suspended" : ""}${this.uplinkParked ? " parked" : ""}${this.explicitlyStopped ? " stopped" : ""}`.trim() || "clear", { generation: this.generation });
      logCall("stream", `phase ${event.phase}`, {
        active: event.active,
        error: event.error,
        reason: event.reason,
        recovering: this.recovering,
        suspended: this.suspended,
        uplinkParked: this.uplinkParked,
        link: this.link.state,
        wifi: this.wifiConnected,
        generation: this.generation,
        ...summarizeStream(event.stream ?? this.result)
      });
      this.onStatus(event);
    }
    logIngestStatus(raw) {
      const key = [
        raw.source ?? "unknown",
        raw.status ?? "",
        raw.kind ?? "",
        String(raw.isConnected ?? ""),
        raw.errorDetails ?? ""
      ].join("|");
      if (key === this.lastIngestLogKey)
        return;
      this.lastIngestLogKey = key;
      logCall("stream", "ingest status", {
        source: raw.source ?? "unknown",
        status: raw.status,
        kind: raw.kind,
        streamId: raw.streamId,
        connected: raw.isConnected,
        error: raw.errorDetails,
        stats: raw.stats,
        local: this.snapshot()
      });
    }
    snapshot() {
      return {
        generation: this.generation,
        recovering: this.recovering,
        suspended: this.suspended,
        uplinkParked: this.uplinkParked,
        link: this.link.state,
        wifi: this.wifiConnected,
        uptimeMs: this.result ? Date.now() - this.startedAt : 0,
        ...summarizeStream(this.result)
      };
    }
    nextFovToken() {
      return {
        generation: ++this.fovGeneration,
        fov: this.profile.fov,
        roiPosition: this.profile.roiPosition
      };
    }
    get streamActiveOrStarting() {
      return this.result !== null || this.starting !== null || this.recovering;
    }
    staleFovReason(token) {
      if (this.disposed)
        return "disposed";
      if (this.explicitlyStopped)
        return "stopped";
      if (token.generation !== this.fovGeneration)
        return "superseded";
      if (!this.streamActiveOrStarting)
        return "no-stream";
      if (this.link.connected !== true)
        return "link-down";
      if (token.fov !== this.profile.fov || token.roiPosition !== this.profile.roiPosition)
        return "profile-changed";
      return null;
    }
    async applyCameraFov(token) {
      for (let attempt = 1;attempt <= FOV_ATTEMPTS; attempt++) {
        const before = this.staleFovReason(token);
        if (before) {
          logCall("stream", "camera fov abandoned", {
            reason: before,
            attempt,
            fov: token.fov,
            roi: token.roiPosition,
            fovGeneration: token.generation
          });
          return;
        }
        try {
          logCall("stream", "camera fov write", {
            fov: token.fov,
            roi: token.roiPosition,
            attempt,
            fovGeneration: token.generation
          });
          await this.session.camera.setFov({ fov: token.fov, roiPosition: token.roiPosition });
          const after = this.staleFovReason(token);
          if (after) {
            logCall("stream", "camera fov resolved after being superseded", {
              reason: after,
              attempt,
              fov: token.fov,
              fovGeneration: token.generation
            });
            return;
          }
          logCall("stream", "camera fov applied", {
            fov: token.fov,
            roi: token.roiPosition,
            attempt,
            fovGeneration: token.generation
          });
          return;
        } catch (error) {
          warnCall("stream", "setFov failed", {
            error: error instanceof Error ? error.message : String(error),
            attempt,
            attempts: FOV_ATTEMPTS,
            fovGeneration: token.generation
          });
          if (attempt === FOV_ATTEMPTS)
            return;
          await delay3(this.fovRetryMs);
        }
      }
    }
    handleLinkForFov(snapshot) {
      const connected = snapshot.state === "connected";
      const previous = this.fovLinkConnected;
      this.fovLinkConnected = connected;
      if (!connected || previous === true) {
        logChange("stream", "stream.fovLink", snapshot.state, { wasConnected: previous });
        return;
      }
      if (this.explicitlyStopped || this.disposed || !this.streamActiveOrStarting) {
        logCall("stream", "glasses link up, but there is no stream to re-assert fov for", {
          explicitlyStopped: this.explicitlyStopped,
          disposed: this.disposed
        });
        return;
      }
      this.cancelFovReapply();
      logCall("stream", "glasses link up; scheduling camera fov re-apply", {
        from: previous === null ? "unknown" : "down",
        delayMs: this.fovReapplyMs,
        fov: this.profile.fov,
        roi: this.profile.roiPosition
      });
      this.fovReapplyTimer = setTimeout(() => {
        this.fovReapplyTimer = null;
        if (this.explicitlyStopped || this.disposed || !this.streamActiveOrStarting) {
          logCall("stream", "camera fov re-apply dropped: the stream went away while we waited", {
            explicitlyStopped: this.explicitlyStopped,
            disposed: this.disposed
          });
          return;
        }
        this.applyCameraFov(this.nextFovToken());
      }, this.fovReapplyMs);
    }
    cancelFovReapply() {
      if (this.fovReapplyTimer)
        clearTimeout(this.fovReapplyTimer);
      this.fovReapplyTimer = null;
    }
    startHeartbeat() {
      this.stopHeartbeat();
      this.heartbeatTimer = setInterval(() => {
        if (!this.result) {
          this.stopHeartbeat();
          return;
        }
        logCall("stream", "heartbeat", this.snapshot());
        if (ENABLE_PIPELINE_FPS_TELEMETRY)
          this.logEncoderStats();
      }, 15000);
    }
    logEncoderStats() {
      if (!ENABLE_PIPELINE_FPS_TELEMETRY || !this.result)
        return;
      const stats = this.lastEncoderStats;
      logJoin(this.result.streamId, "encoder-stats", {
        sourceFps: stats?.fps,
        bitrate: stats?.bitrate,
        droppedFrames: stats?.droppedFrames,
        requestedFps: this.profile.fps,
        requested: `${this.profile.width}x${this.profile.height}`,
        uptimeMs: Date.now() - this.startedAt,
        reported: Boolean(stats)
      });
    }
    stopHeartbeat() {
      if (this.heartbeatTimer)
        clearInterval(this.heartbeatTimer);
      this.heartbeatTimer = null;
      this.lastEncoderStats = null;
    }
    async startWhip(generation) {
      await this.applyCameraFov(this.nextFovToken());
      if (generation !== this.generation || this.explicitlyStopped) {
        logCall("stream", "whip not sent: cancelled while fov was in flight", {
          generation,
          active: this.generation,
          explicitlyStopped: this.explicitlyStopped
        });
        throw new Error("Stream start cancelled");
      }
      if (this.link.connected !== true) {
        warnCall("stream", "whip not sent: the Bluetooth link went down during the fov write", {
          generation,
          link: this.link.state
        });
        throw Object.assign(new Error(GLASSES_COPY.streamLost), { code: "GLASSES_NOT_CONNECTED" });
      }
      const video = toWhipVideo(this.profile);
      const pixels = video.width * video.height;
      const eisMaxPixels = 500000;
      logCall("stream", `whip start (${video.width}x${video.height}@${video.fps})`, {
        generation,
        captureAudio: this.captureAudio,
        preset: this.profile.id,
        fov: this.profile.fov,
        roi: this.profile.roiPosition,
        eisPixels: pixels,
        eisMaxPixels,
        eisExpected: pixels < eisMaxPixels
      });
      const whipRpc = nextRpcId();
      const whipStartedAt = Date.now();
      logRpcStart("stream.startStream", whipRpc, { generation, ingest: "whip", preset: this.profile.id });
      let result;
      try {
        result = await this.session.stream.startStream({
          ingest: "whip",
          video,
          audio: { echoCancellation: false, noiseSuppression: false },
          sound: true,
          ...this.session.hostFeatures?.captureAudio ? { captureAudio: this.captureAudio } : {}
        });
      } catch (error) {
        logRpcEnd("stream.startStream", whipRpc, "error", Date.now() - whipStartedAt, {
          error: error instanceof Error ? error.message : String(error)
        });
        throw error;
      }
      logRpcEnd("stream.startStream", whipRpc, "ok", Date.now() - whipStartedAt, {
        mode: result.mode,
        status: result.status,
        webrtc: Boolean(result.webrtcUrl)
      });
      if (result.mode === "hls" || !result.webrtcUrl && result.hlsUrl) {
        warnCall("stream", "whip rejected: the ingest was downgraded to RTMP", { generation, mode: result.mode });
        throw new Error("The glasses stream started over RTMP instead of WebRTC, which this meeting cannot play");
      }
      if (!result.webrtcUrl) {
        warnCall("stream", "whip rejected: no playback URL on the live input", { generation, mode: result.mode });
        throw new Error("The streaming service returned no playback URL");
      }
      if (generation !== this.generation || this.explicitlyStopped) {
        warnCall("stream", "whip live but already superseded; stopping it again", {
          generation,
          active: this.generation,
          explicitlyStopped: this.explicitlyStopped,
          ...summarizeStream(result)
        });
        await this.session.stream.stop(result.streamId).catch(() => {});
        throw new Error("Stream start cancelled");
      }
      this.result = result;
      this.startedAt = Date.now();
      this.suspended = false;
      this.startHeartbeat();
      logCall("stream", "whip live", {
        generation,
        status: result.status,
        liveInputId: result.liveInputId,
        ...summarizeStream(result)
      });
      this.emitStatus({ phase: "active", active: true, stream: this.info });
      return result;
    }
    watchLinkLoss(generation) {
      let unsub = null;
      const promise = new Promise((_, reject) => {
        unsub = this.link.onChange((snapshot) => {
          if (generation !== this.generation || this.explicitlyStopped)
            return;
          if (snapshot.state === "connected")
            return;
          warnCall("stream", "losing the start race: Bluetooth dropped mid-start", {
            generation,
            link: snapshot.state
          });
          reject(Object.assign(new Error(GLASSES_COPY.streamLost), { code: "GLASSES_NOT_CONNECTED" }));
        });
      });
      return {
        promise,
        cancel: () => {
          unsub?.();
          unsub = null;
        }
      };
    }
    fail(message, reason) {
      this.emitStatus({ phase: "error", active: false, stream: null, error: message, reason });
      return new Error(message);
    }
  }

  // src/background/MentraCallController.ts
  function exitOutcome(result) {
    return { success: result.success, reason: result.reason ?? null, error: result.error ?? null };
  }
  function joinShapingSettings(settings) {
    return {
      directLink: settings.directLink,
      videoPreset: settings.videoPreset,
      videoBitrateBps: settings.videoBitrateBps,
      watchPaint: settings.watchPaint,
      chatTts: settings.chatTts,
      teamsProvider: settings.teamsProvider,
      meetingHost: settings.meetingHost
    };
  }
  async function applyAcsJoinVideoOutcome(args) {
    if (!args.result.error && args.provider === "acs") {
      args.emit(await args.settings.markAcsPresetSucceeded());
      return;
    }
    if (args.result.error && isAcsFormatJoinError(args.result.error)) {
      const next = await args.settings.rollbackConfiguredVideoPreset();
      args.streams.setProfile(resolveConfiguredVideo(next.videoPreset, next.videoBitrateBps));
      args.emit(next);
      logCall("acs", "video format rollback", {
        from: args.previousPreset,
        to: next.videoPreset,
        error: args.result.error
      });
    }
  }

  class MentraCallController {
    session;
    ui;
    backend;
    settings;
    streams;
    meetingAudio;
    call;
    device;
    link;
    calendar;
    preview;
    photos;
    lastCall;
    unsubs = [];
    started = false;
    meetingConfiguration = null;
    meetingPolicyError = null;
    meetingIdentity;
    getSettings() {
      const settings = this.settings.get();
      return this.meetingConfiguration?.externalBackendAllowed === false ? {
        ...settings,
        privateDeployment: true,
        runtimeCreation: this.meetingConfiguration?.creationSource === "runtime",
        directLink: true,
        teamsProvider: "acs",
        meetingUnavailableReason: this.meetingPolicyError ?? undefined
      } : settings;
    }
    publishSettings() {
      const settings = this.getSettings();
      this.ui.send("settings:event", settings);
      return settings;
    }
    async loadMeetingConfiguration() {
      if (typeof this.session.meeting?.getConfiguration !== "function") {
        this.requireMeetingHostUpdate();
        return;
      }
      try {
        const configuration = await this.session.meeting.getConfiguration();
        if (!configuration || typeof configuration.enabled !== "boolean" || typeof configuration.externalBackendAllowed !== "boolean" || !["runtime", "miniapp"].includes(configuration.credentialSource)) {
          throw new Error("The Mentra App returned an invalid meeting configuration");
        }
        this.meetingConfiguration = configuration;
      } catch (error) {
        if (error?.code !== "NOT_IMPLEMENTED")
          throw error;
        this.requireMeetingHostUpdate();
      }
    }
    requireMeetingHostUpdate() {
      this.meetingConfiguration = {
        enabled: false,
        credentialSource: "runtime",
        externalBackendAllowed: false,
        managedStreams: false
      };
      this.meetingPolicyError = "Update the Mentra App to use this version of Mentra Call.";
    }
    constructor(session) {
      this.session = session;
      this.meetingIdentity = new MeetingIdentityCache(() => this.session.meeting.getIdentity());
      this.ui = session.ui;
      this.backend = new BackendClient(session, () => this.meetingConfiguration?.externalBackendAllowed === true);
      this.settings = new SettingsManager(session);
      this.link = new GlassesLinkMonitor(session);
      this.streams = new StreamManager(session, (event) => {
        this.ui.send("stream:status", event);
        this.call?.handleStreamStatus(event);
      }, this.link);
      this.meetingAudio = new MeetingAudioManager(session, this.backend, (status, error) => {
        this.call?.handleAudioStatus(status, error);
      });
      this.preview = new PreviewLeaseManager(session.stream);
      this.lastCall = new LastCallStore(session, (lastCall) => this.ui.send("call:last", lastCall));
      this.call = new CallManager(this.backend, this.streams, this.meetingAudio, (state) => {
        this.ui.send("call:event", state);
        this.preview.handleCallState(state);
        this.syncPhotos(state);
      }, this.session.meeting, {
        directLink: () => this.getSettings().directLink,
        meetingConfiguration: () => {
          if (!this.meetingConfiguration)
            throw new Error("Meeting configuration is not ready");
          return this.meetingConfiguration;
        },
        preparePhoneWifi: () => preparePhoneWifi(session.phone),
        activeCall: new ActiveCallStore(session),
        lastCall: this.lastCall,
        onSoftapRecovery: (active) => this.link.setRecovering(active),
        micHost: session.mic
      });
      this.photos = new PhotoManager({
        onButton: (handler) => session.input.onButtonPress(handler),
        onPublisherExpired: (handler) => session.meeting.onVideoPublisher(handler),
        showCard: async () => {
          await session.meeting.showCard({ kind: "taking-photo" });
        },
        showImage: (imageUrl, durationMs) => session.meeting.showImage({ imageUrl, durationMs }),
        showLive: () => session.meeting.showLive(),
        pausePublisher: () => session.meeting.pauseVideoPublisher({ reason: "photo" }),
        resumePublisher: (pauseId) => session.meeting.resumeVideoPublisher(pauseId),
        pauseStream: () => this.streams.pauseForPhoto(),
        resumeStream: () => this.streams.resumeForPhoto(),
        takePhoto: async (timeoutMs) => {
          const photo = await session.camera.takePhoto({ size: "max", timeoutMs, sound: false });
          return { photoUrl: photo.photoUrl };
        },
        captureStill: async (durationMs, onProgress) => {
          const result = await session.meeting.captureStill({ durationMs, onProgress });
          logCall("call", "photo.captureStill", { bytes: result.bytes, ...result.timings });
          return { bytes: result.bytes };
        },
        postPhase: async (body) => {
          await this.backend.sharePhoto(body);
        }
      }, (photo) => this.call.setPhoto(photo));
      this.device = new DeviceManager(session, (state) => this.ui.send("device:state", state), this.link);
      this.calendar = new CalendarManager(session);
    }
    photoSnapshot(state = this.call.getState()) {
      const settings = this.getSettings();
      return {
        phase: state.phase,
        callId: photoCallKey(state),
        transport: state.transport,
        usesAcs: settings.teamsProvider === "acs",
        shareHdPhoto: settings.shareHdPhoto,
        hostCanHold: typeof this.session.meeting.showImage === "function",
        hostCanCaptureStill: typeof this.session.meeting.captureStill === "function"
      };
    }
    syncPhotos(state) {
      if (!this.photos)
        return;
      const snapshot = this.photoSnapshot(state);
      this.photos.sync(snapshot);
      logChange("call", "photo.buttonSubscribed", this.photos.subscriberCount() > 0, {
        phase: snapshot.phase,
        callKey: Boolean(snapshot.callId),
        shareHdPhoto: snapshot.shareHdPhoto,
        usesAcs: snapshot.usesAcs,
        hostCanHold: snapshot.hostCanHold,
        hostCanCaptureStill: snapshot.hostCanCaptureStill
      });
    }
    async start() {
      if (this.started) {
        warnCall("boot", "start called again on a controller that is already running");
        return;
      }
      this.started = true;
      const startedAt = Date.now();
      logCall("boot", "controller starting", {
        user: this.session.userId || "not yet resolved",
        packageName: this.session.packageName,
        model: this.session.capabilities?.modelName ?? "none",
        backendHost: hostnameFromMeetingUrl(BACKEND_URL) ?? "not configured",
        authDisabled: AUTH_DISABLED,
        teamsProvider: TEAMS_PROVIDER,
        transportPin: pinnedCallTransport() ?? "none",
        investigationArm: INVESTIGATION_ARM,
        ...describeAcsMic()
      });
      await this.loadMeetingConfiguration();
      if (!this.meetingPolicyError && this.meetingConfiguration?.credentialSource === "runtime") {
        this.meetingIdentity.get().catch(() => {});
      }
      await this.settings.load();
      const loaded = this.getSettings();
      logCall("boot", "settings loaded", joinShapingSettings(loaded));
      this.streams.setProfile(resolveConfiguredVideo(loaded.videoPreset, loaded.videoBitrateBps));
      const capabilities = this.session.capabilities;
      const meetingHost = logMeetingHostSelection(this.session);
      logCall("acs", "session", {
        model: capabilities?.modelName ?? "none",
        camera: Boolean(capabilities?.hasCamera),
        speaker: Boolean(capabilities?.hasSpeaker),
        teamsProvider: TEAMS_PROVIDER,
        meetingHost,
        joinPathBuild: JOIN_PATH_BUILD,
        urlCtor: typeof URL === "function",
        ...describeMeetingApi(this.session)
      });
      logCall("call", "session started", {
        model: capabilities?.modelName ?? "none",
        camera: Boolean(capabilities?.hasCamera),
        speaker: Boolean(capabilities?.hasSpeaker),
        teamsProvider: TEAMS_PROVIDER,
        meetingHost,
        joinPathBuild: JOIN_PATH_BUILD,
        urlCtor: typeof URL === "function",
        ...describeMeetingApi(this.session)
      });
      this.streams.start();
      this.device.start();
      this.wireRpcHandlers();
      this.wireUiLifecycle();
      this.session.onBeforeDisconnect((reason) => {
        logCall("boot", "session is disconnecting", { reason });
        this.dispose();
      });
      this.publishSettings();
      this.session.waitForReady().then(() => {
        logCall("boot", "session ready", {
          user: this.session.userId || "unresolved",
          model: this.session.capabilities?.modelName ?? "none",
          waitedMs: Date.now() - startedAt
        });
        return this.probeMeetingHost();
      });
      if (!this.meetingPolicyError)
        await this.call.restore();
      this.syncPhotos();
      logCall("boot", "controller started", { ms: Date.now() - startedAt, phase: this.call.getState().phase });
    }
    async probeMeetingHost() {
      if (this.meetingPolicyError || !hasMeetingApi(this.session)) {
        logCall("acs", "host probe skipped", {
          reason: "bundled SDK has no session.meeting.join — rebuild vendor/miniapp dist"
        });
        return;
      }
      try {
        const state = await tracedRpc("meeting.getState", () => this.session.meeting.getState(), {
          request: { at: "boot probe" },
          response: (value) => ({ nativeState: value.state, muted: value.muted })
        });
        logCall("acs", "host probe ok", { nativeState: state.state, muted: state.muted, error: state.error });
      } catch (error) {
        const mapped = error;
        logCall("acs", "host probe failed", {
          code: mapped.code,
          message: error instanceof Error ? error.message : String(mapped.message ?? error)
        });
      }
    }
    handle(channel, handler, describe) {
      const name = String(channel);
      this.ui.handle(channel, async (payload, ctx) => {
        const summarize = describe?.polled;
        if (!summarize) {
          return tracedRpc(name, async () => handler(payload, ctx), {
            request: describe?.request?.(payload),
            response: describe?.response
          });
        }
        try {
          const value = await handler(payload, ctx);
          logChange("rpc", name, summarize(value));
          return value;
        } catch (error) {
          warnCall("rpc", `${name} failed`, { error: error instanceof Error ? error.message : String(error) });
          throw error;
        }
      });
    }
    wireRpcHandlers() {
      this.handle("call:join", async ({ meetingUrl, origin }) => {
        if (this.meetingPolicyError)
          return { error: this.meetingPolicyError };
        const settings = this.getSettings();
        const result = await this.call.join(meetingUrl, settings.displayName, settings.watchPaint, { origin });
        await applyAcsJoinVideoOutcome({
          result,
          provider: this.call.getState().provider,
          previousPreset: settings.videoPreset,
          settings: this.settings,
          streams: this.streams,
          emit: () => this.publishSettings()
        });
        return result;
      }, {
        request: ({ meetingUrl, origin }) => ({
          host: hostnameFromMeetingUrl(meetingUrl) ?? "unparseable",
          platform: platformFromUrl(meetingUrl) ?? "unrecognised",
          origin: origin ?? "unset"
        }),
        response: (result) => ({
          blocked: result.blocked ?? null,
          error: result.error ?? null,
          botId: Boolean(result.botId)
        })
      });
      this.handle("call:leave", () => this.call.leave(), { response: exitOutcome });
      this.handle("call:end", () => this.call.endCall(), { response: exitOutcome });
      this.handle("call:admit", ({ participantId }) => this.call.admitParticipant(participantId));
      this.handle("call:quota", async () => {
        if (shouldSkipCallQuota({
          credentialSource: this.meetingConfiguration?.credentialSource,
          privateDeployment: this.getSettings().privateDeployment
        })) {
          return { skipped: true };
        }
        return this.backend.getQuota();
      });
      this.handle("call:get-state", () => this.call.getState(), {
        response: (state) => ({
          phase: state.phase,
          provider: state.provider ?? null,
          transport: state.transport ?? null,
          streamPhase: state.streamPhase ?? null
        })
      });
      this.handle("call:get-last", () => this.lastCall.get(), {
        response: (lastCall) => lastCall ? { endReason: lastCall.endReason, ageMs: Date.now() - lastCall.endedAt } : { present: false }
      });
      this.handle("call:participants", () => this.backend.getParticipants(), {
        polled: (value) => `${value.participants.length} participants`
      });
      this.handle("call:chat", () => this.backend.getChatMessages(), {
        polled: (value) => `${value.messages.length} messages`
      });
      this.handle("call:chat-send", async ({ text }) => {
        try {
          return { message: (await this.backend.sendChatMessage(text)).message };
        } catch (error) {
          return { error: error instanceof Error ? error.message : String(error) };
        }
      }, { request: ({ text }) => ({ chars: text.length }), response: (result) => ({ error: result.error ?? null }) });
      this.handle("call:chat-tts", async ({ text }) => {
        if (!this.getSettings().chatTts)
          return { success: false, error: "Chat TTS is disabled" };
        try {
          await this.meetingAudio.speakChat(text);
          return { success: true };
        } catch (error) {
          return { success: false, error: error instanceof Error ? error.message : String(error) };
        }
      }, { request: ({ text }) => ({ chars: text.length }), response: (result) => ({ success: result.success }) });
      this.handle("preview:stats", async ({ joinId, stats }) => {
        try {
          return await this.backend.reportStats({ joinId, source: "preview", stats });
        } catch {
          return { accepted: false };
        }
      }, { polled: (result) => result.accepted ? "accepted" : "rejected" });
      this.handle("call:mute", () => this.call.setMuted(true), { response: (result) => ({ muted: result.muted }) });
      this.handle("call:unmute", () => this.call.setMuted(false), { response: (result) => ({ muted: result.muted }) });
      this.handle("call:mute-status", () => this.call.muteStatus(), { response: (result) => ({ muted: result.muted }) });
      this.handle("call:set-video", ({ enabled }) => this.call.setVideoEnabled(enabled), {
        request: ({ enabled }) => ({ enabled }),
        response: (result) => ({ videoEnabled: result.videoEnabled })
      });
      this.handle("teams:identity", async (args) => {
        if (this.meetingPolicyError)
          throw new Error(this.meetingPolicyError);
        return this.meetingIdentity.get(args?.refresh === true);
      }, { response: (identity) => ({ identityMode: identity.identityMode, guestReason: identity.guestReason }) });
      this.handle("teams:create", async (args) => {
        try {
          const privateDeployment = this.meetingConfiguration?.externalBackendAllowed === false;
          if (privateDeployment && this.meetingConfiguration?.creationSource !== "runtime") {
            throw new Error("Update the Mentra App to create meetings in this workspace");
          }
          const created = privateDeployment ? await this.session.meeting.create({ provider: "acs-teams", ...args }) : await this.backend.createTeamsMeeting(args ?? {});
          const { meetingRef, ...result } = created;
          logCall("meeting", "teams meeting created", {
            meetingId: result.meetingId,
            owned: Boolean(meetingRef || result.meetingId),
            hasRef: Boolean(meetingRef),
            error: result.error
          });
          if (result.joinUrl) {
            this.call.noteCreatedMeeting(result.joinUrl, {
              ref: meetingRef,
              meetingId: result.meetingId,
              source: privateDeployment ? "runtime" : "backend"
            });
          }
          return result;
        } catch (error) {
          const message = requestErrorMessage(error, "Couldn’t create the meeting");
          warnCall("meeting", "teams meeting create failed", { error: message });
          return { error: humanizeTeamsCreateError(message) };
        }
      }, {
        request: (args) => ({ durationMinutes: args?.durationMinutes ?? null, hasSubject: Boolean(args?.subject) }),
        response: (result) => ({ hasJoinUrl: Boolean(result.joinUrl), error: result.error ?? null })
      });
      this.handle("system:share", (args) => this.session.system.share(args ?? {}), {
        request: (args) => ({ hasUrl: Boolean(args?.url), hasText: Boolean(args?.text) }),
        response: (result) => ({ success: result.success, cancelled: Boolean(result.cancelled) })
      });
      this.handle("system:scan-qr", () => requestHostQrScan((options) => this.session.system.scanQr(options)), {
        response: (result) => ({
          decoded: Boolean(result.data),
          cancelled: Boolean(result.cancelled),
          error: result.error ?? null
        })
      });
      this.handle("meet:create", async () => {
        try {
          return await this.backend.createGoogleMeeting();
        } catch (error) {
          return {
            error: error instanceof Error ? error.message : String(error),
            notConnected: error instanceof BackendRequestError ? error.notConnected : undefined
          };
        }
      }, {
        response: (result) => ({
          hasJoinUrl: Boolean(result.joinUrl),
          notConnected: Boolean(result.notConnected),
          error: result.error ?? null
        })
      });
      this.handle("google:status", async () => {
        try {
          return await this.backend.googleStatus();
        } catch {
          return { connected: false, email: null };
        }
      }, { response: (result) => ({ connected: result.connected, hasEmail: Boolean(result.email) }) });
      this.handle("google:connect", async () => {
        try {
          const { url } = await this.backend.googleConnectUrl();
          this.session.system.openUrl(url);
          return { success: true };
        } catch (error) {
          return { success: false, error: error instanceof Error ? error.message : String(error) };
        }
      }, { response: (result) => ({ success: result.success, error: result.error ?? null }) });
      this.handle("google:disconnect", async () => {
        try {
          return await this.backend.googleDisconnect();
        } catch {
          return { success: false };
        }
      }, { response: (result) => ({ success: result.success }) });
      this.handle("stream:start", async () => {
        try {
          const result = await this.streams.ensureStarted();
          return { status: "active", urls: { webrtcUrl: result.webrtcUrl } };
        } catch (error) {
          return { status: "error", error: error instanceof Error ? error.message : String(error) };
        }
      }, { response: (result) => ({ status: result.status, error: result.error ?? null }) });
      this.handle("stream:stop", () => this.streams.stop());
      this.handle("stream:get", () => {
        const info = this.streams.info;
        return info ? { webrtcUrl: info.webrtcUrl } : null;
      }, { response: (result) => ({ present: Boolean(result?.webrtcUrl) }) });
      this.handle("device:get-state", () => this.device.getState(), {
        response: (state) => ({
          link: state.link,
          wifiConnected: state.wifiConnected,
          hasCamera: state.hasCamera,
          batteryLevel: state.batteryLevel
        })
      });
      this.handle("device:request-wifi", async () => {
        try {
          await this.streams.requestWifiSetup();
          return { success: true };
        } catch (error) {
          return { success: false, error: error instanceof Error ? error.message : String(error) };
        }
      }, { response: (result) => ({ success: result.success, error: result.error ?? null }) });
      this.handle("device:request-phone-wifi", () => this.session.phone.requestWifiEnable("Wi-Fi is required to join the call. After you turn it on and return, the call continues."));
      this.handle("calendar:get", async () => ({ meetings: await this.calendar.list() }), {
        response: (result) => ({ meetings: result.meetings.length })
      });
      this.handle("settings:get", () => this.getSettings(), { response: joinShapingSettings });
      this.handle("settings:update", async (patch) => {
        await this.settings.update(patch ?? {});
        const next = this.getSettings();
        this.streams.setProfile(resolveConfiguredVideo(next.videoPreset, next.videoBitrateBps));
        this.syncPhotos();
        this.publishSettings();
        return next;
      }, { request: (patch) => ({ changed: Object.keys(patch ?? {}) }), response: joinShapingSettings });
    }
    wireUiLifecycle() {
      this.unsubs.push(this.ui.onOpen(() => {
        logCall("boot", "webview attached", {
          phase: this.call.getState().phase,
          link: this.device.getState().link
        });
        this.ui.send("call:event", this.call.getState());
        this.ui.send("device:state", this.device.getState());
        this.publishSettings();
        this.lastCall.get().then((lastCall) => this.ui.send("call:last", lastCall));
      }), this.ui.onClose(() => logCall("boot", "webview detached", { phase: this.call.getState().phase })));
    }
    async dispose() {
      logCall("boot", "teardown started", { phase: this.call.getState().phase, subscriptions: this.unsubs.length });
      for (const unsubscribe of this.unsubs)
        unsubscribe();
      this.unsubs = [];
      this.photos.dispose();
      this.device.dispose();
      this.preview.dispose();
      await this.call.dispose();
      this.link.dispose();
      logCall("boot", "teardown finished");
    }
  }

  // src/background/index.ts
  logCall("boot", "background bundle evaluated");
  registerMiniapp((session) => {
    logCall("boot", "miniapp init handler fired");
    new MentraCallController(session).start().catch((error) => {
      warnCall("boot", "controller start failed", { error: error instanceof Error ? error.message : String(error) });
      throw error;
    });
  });
})();
